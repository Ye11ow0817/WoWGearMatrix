﻿// ==========================================================================
// Dedmonwakeen's Raid DPS/TPS Simulator.
// Send questions to natehieter@gmail.com
// ==========================================================================
#include "player.hpp"

#include "action/action.hpp"
#include "action/action_callback.hpp"
#include "action/action_state.hpp"
#include "action/attack.hpp"
#include "action/dbc_proc_callback.hpp"
#include "action/dot.hpp"
#include "action/heal.hpp"
#include "action/residual_action.hpp"
#include "action/sequence.hpp"
#include "action/snapshot_stats.hpp"
#include "action/spell.hpp"
#include "action/variable.hpp"
#include "buff/buff.hpp"
#include "dbc/class_spells.hpp"
#include "dbc/azerite.hpp"
#include "dbc/character_loadout.hpp"
#include "dbc/dbc.hpp"
#include "dbc/item_database.hpp"
#include "dbc/item_set_bonus.hpp"
#include "dbc/mastery_spells.hpp"
#include "dbc/rank_spells.hpp"
#include "dbc/sc_spell_info.hpp"
#include "dbc/specialization_spell.hpp"
#include "dbc/temporary_enchant.hpp"
#include "dbc/trait_data.hpp"
#include "item/item.hpp"
#include "item/special_effect.hpp"
#include "player/action_priority_list.hpp"
#include "player/action_variable.hpp"
#include "player/actor_target_data.hpp"
#include "player/azerite_data.hpp"
#include "player/consumable.hpp"
#include "player/ground_aoe.hpp"
#include "player/instant_absorb.hpp"
#include "player/pet.hpp"
#include "player/player_demise_event.hpp"
#include "player/player_event.hpp"
#include "player/player_scaling.hpp"
#include "player/sample_data_helper.hpp"
#include "player/scaling_metric_data.hpp"
#include "player/set_bonus.hpp"
#include "player/spawner_base.hpp"
#include "player/stats.hpp"
#include "player/unique_gear.hpp"
#include "player/unique_gear_midnight.hpp"
#include "report/decorators.hpp"
#include "sim/benefit.hpp"
#include "sim/cooldown.hpp"
#include "sim/cooldown_waste_data.hpp"
#include "sim/event.hpp"
#include "sim/expressions.hpp"
#include "sim/plot.hpp"
#include "sim/proc.hpp"
#include "sim/proc_rng.hpp"
#include "sim/scale_factor_control.hpp"
#include "sim/sim.hpp"
#include "util/io.hpp"
#include "util/plot_data.hpp"
#include "util/util.hpp"
#include "class_modules/class_module.hpp"

#include <cctype>
#include <cerrno>
#include <limits>
#include <memory>
#include <sstream>
#include <stdexcept>
#include <utility>

namespace
{

bool prune_specialized_execute_actions_internal( std::vector<action_t*>& apl, execute_type e,
  std::vector<std::vector<action_t*>*>& visited )
{
  if ( range::find( visited, &apl ) != visited.end() )
    return true;
  else
    visited.push_back( &apl );

  auto it = apl.begin();
  // Prune out any call/run/swap_action list call from the list of actions, if the called apl has no
  // actions of the required type.
  while ( it != apl.end() )
  {
    action_priority_list_t* alist = nullptr;
    action_t* action = *it;

    if ( action->type == ACTION_CALL )
    {
      alist = static_cast<const call_action_list_t*>( action )->alist;
    }
    else if ( util::str_compare_ci( action->name_str, "run_action_list" ) ||
              util::str_compare_ci( action->name_str, "swap_action_list" ) )
    {
      alist = static_cast<const swap_action_list_t*>( action )->alist;
    }

    if ( alist )
    {
      bool state;
      switch ( e )
      {
        case execute_type::OFF_GCD:
          alist->player->sim->print_debug( "{} traversing APL {}, n_actions={} ({})",
            alist->player->name(), alist->name_str, alist->off_gcd_actions.size(),
            e == execute_type::OFF_GCD ? "off-gcd" : "cast-while-casting" );
          state = prune_specialized_execute_actions_internal( alist->off_gcd_actions, e, visited );
          break;
        case execute_type::CAST_WHILE_CASTING:
          alist->player->sim->print_debug( "{} traversing APL {}, n_actions={} ({})",
            alist->player->name(), alist->name_str, alist->cast_while_casting_actions.size(),
            e == execute_type::OFF_GCD ? "off-gcd" : "cast-while-casting" );
          state = prune_specialized_execute_actions_internal( alist->cast_while_casting_actions, e, visited );
          break;
        default:
          state = false;
          break;
      }

      if ( !state )
      {
        alist->player->sim->print_debug( "{} pruning {} from APL ({})",
          alist->player->name(), (*it)->signature_str,
          e == execute_type::OFF_GCD ? "off-gcd" : "cast-while-casting" );
        it = apl.erase( it );
      }
      else
      {
        ++it;
      }
    }
    else
    {
      ++it;
    }
  }

  return !apl.empty();
}

bool prune_specialized_execute_actions( std::vector<action_t*>& apl, execute_type e )
{
  std::vector<std::vector<action_t*>*> visited;
  return prune_specialized_execute_actions_internal( apl, e, visited );
}

// Specialized execute for off-gcd and cast-while-casting execution of abilities. Both cases need to
// perform a subset of the normal foreground execution process, and also have to take into account
// execution-type specific bookkeeping on the actor level.
template <typename T>
struct special_execute_event_t : public player_event_t
{
  special_execute_event_t( player_t& p, timespan_t delta_time ) :
    player_event_t( p, delta_time )
  { }

  void execute() override
  {
    ptr() = nullptr;

    execute_action();

    // Create a new specialized execute check event only in the case we didnt find anything to queue
    // (could use an ability right away) and the action we executed was not a run_action_list.
    //
    // Note also that a new specialized execute check event may have been created in do_execute() if
    // this event execution found an off gcd action to execute, in this case, do not create new
    // event.
    reschedule();
  }

  // Select and execute a specialized action based on the execution type (currently off-gcd or cast
  // while casting)
  virtual void execute_action()
  {
    // Dynamically regenerating actors must be regenerated before selecting an action, otherwise
    // resource-specific expressions may not function properly.
    if ( p()->resource_regeneration == regen_type::DYNAMIC)
    {
      p()->do_dynamic_regen();
    }

    p()->visited_apls_ = 0;

    action_t* a = p()->select_action( apl(), type() );

    if ( p()->restore_action_list != nullptr )
    {
      p()->activate_action_list( p()->restore_action_list, p()->restore_action_list_type );
      p()->restore_action_list = nullptr;
    }

    if ( a == nullptr )
    {
      return;
    }

    // Don't attempt to execute an action that's already being queued (this should not happen
    // anyhow)
    if ( p()->queueing && p()->queueing->internal_id == a->internal_id )
    {
      return;
    }

    // Don't queue the action if the specialized execution interval would elapse before the action
    // is usable again
    if ( usable( a ) )
    {
      // If we're queueing something, it's something different from what we are about to do.
      // Cancel existing queued action, and queue the new one.
      if ( p()->queueing )
      {
        event_t::cancel( p()->queueing->queue_event );
        p()->queueing = nullptr;
      }

      a->queue_execute( type() );
    }
  }

  // Type of specialized action execute
  virtual execute_type type() const = 0;
  // Base list of actions that is being run for the action execute
  virtual action_priority_list_t& apl() const = 0;
  // Pointer to the player-object event tracking member variable (holds this event object)
  virtual event_t*& ptr() = 0;
  // Is a selected action usable during the specialized execute interval (a GCD, or a cast/channel
  // time)
  virtual bool usable( const action_t* a ) const = 0;
  // Perform a reschedule of the polling event if applicable
  virtual void reschedule() = 0;
};

struct player_gcd_event_t : public special_execute_event_t<player_gcd_event_t>
{
  player_gcd_event_t( player_t& p, timespan_t delta_time ) :
    special_execute_event_t( p, delta_time )
  {
    sim().print_debug( "New Player-Ready-GCD Event: {}", p.name() );
  }

  const char* name() const override
  { return "Player-Ready-GCD"; }

  execute_type type() const override
  { return execute_type::OFF_GCD; }

  action_priority_list_t& apl() const override
  { return *p()->active_off_gcd_list; }

  event_t*& ptr() override
  { return p()->off_gcd; }

  void reschedule() override
  { p()->schedule_off_gcd_ready(); }

  // Action is only usable while a GCD is elapsing, and the action is queueable before the ready
  // event occurs
  bool usable( const action_t* a ) const override
  { return a->usable_during_current_gcd(); }

  void execute_action() override
  {
    // It is possible to orchestrate events such that an action is currently executing when an
    // off-gcd event occurs, if this is the case, don't do anything
    if ( p()->executing )
    {
      return;
    }

    special_execute_event_t<player_gcd_event_t>::execute_action();
  }
};

struct player_cwc_event_t : public special_execute_event_t<player_cwc_event_t>
{
  player_cwc_event_t( player_t& p, timespan_t delta_time ) :
    special_execute_event_t( p, delta_time )
  {
    sim().print_debug( "New Player-Ready-Cast-While-Casting Event: {}", p.name() );
  }

  const char* name() const override
  { return "Player-Ready-Cast-While-Casting"; }

  execute_type type() const override
  { return execute_type::CAST_WHILE_CASTING; }

  action_priority_list_t& apl() const override
  { return *p()->active_cast_while_casting_list; }

  event_t*& ptr() override
  { return p()->cast_while_casting_poll_event; }

  bool usable( const action_t* a ) const override
  { return a->usable_during_current_cast(); }

  void reschedule() override
  { p()->schedule_cwc_ready(); }

};

// Player Ready Event =======================================================

struct player_ready_event_t : public player_event_t
{
  player_ready_event_t( player_t& p, timespan_t delta_time ) : player_event_t( p, delta_time )
  {
    if ( sim().debug )
      sim().print_debug( "New Player-Ready Event: {}", p.name() );
  }
  const char* name() const override
  {
    return "Player-Ready";
  }
  void execute() override
  {
    p()->readying = nullptr;
    p()->current_execute_type = execute_type::FOREGROUND;

    // There are certain chains of events where an off-gcd ability can be queued such that the queue
    // time for the action exceeds Player-Ready event (essentially end of GCD). In this case, the
    // simple solution is to just cancel the queue execute and let the actor select an action from
    // the action list as normal.
    if ( p()->queueing )
    {
      event_t::cancel( p()->queueing->queue_event );
      p()->queueing = nullptr;
    }
    // Player that's checking for off gcd actions to use, cancels that checking when there's a ready event firing.
    event_t::cancel( p()->off_gcd );
    // Also cancel checks during casting, since player-ready event by definition means that the
    // actor is not going to be casting.
    event_t::cancel( p()->cast_while_casting_poll_event );

    if ( !p()->execute_action() )
    {
      if ( p()->ready_type == READY_POLL )
      {
        timespan_t x = p()->available();

        p()->schedule_ready( x, true );

        // Waiting Debug
        sim().print_debug( "{} is waiting for {} resource={}", p()->name(), x,
                                  p()->resources.current[ p()->primary_resource() ] );
      }
      else
      {
        p()->started_waiting = sim().current_time();
        p()->min_threshold_trigger();
      }
    }
  }
};

// Trigger a wakeup based on a resource treshold. Only used by trigger_ready=1 actors
struct resource_threshold_event_t : public event_t
{
  player_t* player;

  resource_threshold_event_t( player_t* p, timespan_t delay ) : event_t( *p, delay ), player( p )
  {
  }

  const char* name() const override
  {
    return "Resource-Threshold";
  }

  void execute() override
  {
    player->trigger_ready();
    player->resource_threshold_trigger = nullptr;
  }
};

// Execute Pet Action =======================================================

struct execute_pet_action_t : public action_t
{
  action_t* pet_action;
  pet_t* pet;
  std::string action_str;

  std::string pet_name;

  execute_pet_action_t( player_t* player, util::string_view name, util::string_view as,
                        util::string_view options_str ) :
    action_t( ACTION_OTHER, fmt::format( "execute_{}_{}", name, as ), player ),
    pet_action( nullptr ),
    pet( nullptr ),
    action_str( as ),
    pet_name( name )
  {
    parse_options( options_str );
    trigger_gcd = timespan_t::zero();
  }

  void init_finished() override
  {
    pet = player->find_pet( pet_name );
    // No pet found, finish init early, the action will never be ready() and never executed.
    if ( !pet )
    {
      return;
    }

    for ( auto& action : pet->action_list )
    {
      if ( action->name_str == action_str )
      {
        action->background = true;
        pet_action    = action;
      }
    }

    if ( !pet_action )
    {
      throw sc_invalid_apl_argument(
        fmt::format( "{} refers to unknown action {} for pet {}.", *player, action_str, pet->name() ) );
    }

    action_t::init_finished();
  }

  void execute() override
  {
    assert(pet_action);
    pet_action->execute();
  }

  bool ready() override
  {
    if ( !pet )
    {
      return false;
    }

    if ( !pet_action )
      return false;

    if ( !action_t::ready() )
      return false;

    if ( pet_action->player->is_sleeping() )
      return false;

    return pet_action->action_ready();
  }
};

struct leech_t : public heal_t
{
  leech_t( player_t* player ) : heal_t( "leech", player, player->find_spell( 143924 ) )
  {
    background = proc = true;
    callbacks = may_crit = may_miss = may_dodge = may_parry = may_block = false;
    target = player;
  }

  void init() override
  {
    heal_t::init();

    snapshot_flags = update_flags =
      STATE_MUL_SPELL_DA | STATE_MUL_PLAYER_DAM | STATE_TGT_MUL_DA | STATE_VERSATILITY | STATE_MUL_PERSISTENT;

    player->register_combat_begin( []( player_t* p ) {
      make_repeating_event( *p->sim,
          [ p ] { return p->base_gcd * p->cache.spell_cast_speed(); },
          [ p ] {
            if ( p->leech_pool > 0 )
              p->spells.leech->schedule_execute();
          } );
    } );
  }

  void execute() override
  {
    heal_t::execute();

    player->leech_pool = 0;
  }

  double base_da_min( const action_state_t* ) const override { return player->leech_pool; }

  double base_da_max( const action_state_t* ) const override { return player->leech_pool; }
};

struct invulnerable_debuff_t : public buff_t
{
  invulnerable_debuff_t( player_t* p ) : buff_t( p, "invulnerable" )
  {
    set_max_stack( 1 );
  }

  void start( int stacks, double value, timespan_t duration ) override
  {
    buff_t::start( stacks, value, duration );
    if ( sim->ignore_invulnerable_targets && range::contains( sim->target_non_sleeping_list, player ) )
    {
      sim->target_non_sleeping_list.find_and_erase_unordered( player );
      sim->active_enemies--;
    }
  }

  void expire_override( int expiration_stacks, timespan_t remaining_duration ) override
  {
    buff_t::expire_override( expiration_stacks, remaining_duration );
    if ( sim->ignore_invulnerable_targets && !range::contains( sim->target_non_sleeping_list, player ) )
    {
      sim->target_non_sleeping_list.push_back( player );
      sim->active_enemies++;
    }
  }
};

/**
 * Get sorted list of action priorirty lists
 *
 * APLs need to always be initialized in the same order, otherwise copy= profiles may break in some cases.
 * Order will be: precombat -> default -> alphabetical list of custom apls
 */
std::vector<action_priority_list_t*> sorted_action_priority_lists( const player_t* p )
{
  std::vector<action_priority_list_t*> apls = p->action_priority_list;
  range::sort( apls, []( const action_priority_list_t* l, const action_priority_list_t* r ) {
    if ( l->name_str == "precombat" && r->name_str != "precombat" )
    {
      return true;
    }
    else if ( l->name_str != "precombat" && r->name_str == "precombat" )
    {
      return false;
    }
    else if ( l->name_str == "default" && r->name_str != "default" )
    {
      return true;
    }
    else if ( l->name_str != "default" && r->name_str == "default" )
    {
      return false;
    }
    else
    {
      return l->name_str < r->name_str;
    }
  } );

  return apls;
}

bool has_foreground_actions( const player_t& p )
{
  return ( p.active_action_list && !p.active_action_list->foreground_action_list.empty() );
}

// parse_talent_string ======================================================

bool parse_talent_string( sim_t* sim, std::string_view, std::string_view string )
{
  player_t* p = sim->active_player;

  p->talents_str = std::string( string );

  return true;
}

// parse_timeofday ====================================================

bool parse_timeofday( sim_t* sim, std::string_view, std::string_view override_str )
{
  player_t* p = sim->active_player;

  if ( util::str_compare_ci( override_str, "night" ) || util::str_compare_ci( override_str, "nighttime" ) )
  {
    p->timeofday = player_t::NIGHT_TIME;
  }
  else if ( util::str_compare_ci( override_str, "day" ) || util::str_compare_ci( override_str, "daytime" ) )
  {
    p->timeofday = player_t::DAY_TIME;
  }
  else
  {
    sim->error( "{} timeofday string '{}' not valid.", sim->active_player->name(), override_str );
    return false;
  }

  return true;
}

// parse_loa ====================================================

bool parse_loa( sim_t* sim, std::string_view, std::string_view override_str )
{
  player_t* p = sim->active_player;

  if ( util::str_compare_ci( override_str, "akunda" ) || util::str_compare_ci( override_str, "embrace_of_akunda" ) )
  {
    p->zandalari_loa = player_t::AKUNDA;
  }
  else if ( util::str_compare_ci( override_str, "bwonsamdi" ) || util::str_compare_ci( override_str, "embrace_of_bwonsamdi" ) )
  {
    p->zandalari_loa = player_t::BWONSAMDI;
  }
  else if ( util::str_compare_ci( override_str, "gonk" ) || util::str_compare_ci( override_str, "embrace_of_gonk" ) )
  {
    p->zandalari_loa = player_t::GONK;
  }
  else if ( util::str_compare_ci( override_str, "kimbul" ) || util::str_compare_ci( override_str, "embrace_of_kimbul" ) )
  {
    p->zandalari_loa = player_t::KIMBUL;
  }
  else if ( util::str_compare_ci( override_str, "kragwa" ) || util::str_compare_ci( override_str, "embrace_of_kragwa" ) )
  {
    p->zandalari_loa = player_t::KRAGWA;
  }
  else if ( util::str_compare_ci( override_str, "paku" ) || util::str_compare_ci( override_str, "embrace_of_paku" ) )
  {
    p->zandalari_loa = player_t::PAKU;
  }
  else
  {
    sim->error( "{} zandalari_loa string '{}' not valid.", sim->active_player->name(), override_str );
    return false;
  }

  return true;
}

// parse_tricks
bool parse_tricks( sim_t* sim, std::string_view, std::string_view override_str )
{
  player_t* p = sim->active_player;

  if ( util::str_compare_ci( override_str, "corrosive" ) || util::str_compare_ci( override_str, "corrosive_vial" ) )
  {
    p->vulpera_tricks = player_t::CORROSIVE;
  }
  else if ( util::str_compare_ci( override_str, "flames" ) || util::str_compare_ci( override_str, "flames_of_fury" ) )
  {
    p->vulpera_tricks = player_t::FLAMES;
  }
  else if ( util::str_compare_ci( override_str, "shadows" ) ||
            util::str_compare_ci( override_str, "sinister_shadows" ) )
  {
    p->vulpera_tricks = player_t::SHADOWS;
  }
  else if ( util::str_compare_ci( override_str, "healing" ) || util::str_compare_ci( override_str, "healing_vial" ) )
  {
    p->vulpera_tricks = player_t::HEALING;
  }
  else if ( util::str_compare_ci( override_str, "holy" ) || util::str_compare_ci( override_str, "holy_relic" ) )
  {
    p->vulpera_tricks = player_t::HOLY;
  }
  else
  {
    sim->error( "{} vulpera_tricks string '{}' not valid.", sim->active_player->name(), override_str );
    return false;
  }

  return true;
}

// parse_mineral
bool parse_mineral( sim_t* sim, std::string_view, std::string_view override_str )
{
  player_t*p = sim->active_player;

  if ( util::str_compare_ci( override_str, "amber" ) || util::str_prefix_ci( override_str, "sta" ) )
  {
    p->earthen_mineral = player_t::AMBER;
  }
  else if ( util::str_compare_ci( override_str, "emerald" ) || util::str_prefix_ci( override_str, "has" ) )
  {
    p->earthen_mineral = player_t::EMERALD;
  }
  else if ( util::str_compare_ci( override_str, "onyx" ) || util::str_prefix_ci( override_str, "mas" ) )
  {
    p->earthen_mineral = player_t::ONYX;
  }
  else if ( util::str_compare_ci( override_str, "ruby" ) || util::str_prefix_ci( override_str, "crit" ) )
  {
    p->earthen_mineral = player_t::RUBY;
  }
  else if ( util::str_compare_ci( override_str, "sapphire" ) || util::str_prefix_ci( override_str, "vers" ) )
  {
    p->earthen_mineral = player_t::SAPPHIRE;
  }
  else
  {
    sim->error( "{} earthen_mineral string '{}' not valid.", sim->active_player->name(), override_str );
    return false;
  }

  return true;
}

// parse_role_string ========================================================

bool parse_role_string( sim_t* sim, std::string_view, std::string_view value )
{
  sim->active_player->role = util::parse_role_type( value );

  return true;
}

// parse_world_lag ==========================================================

bool parse_world_lag( sim_t* sim, std::string_view, std::string_view value )
{
  sim->active_player->world_lag.mean = timespan_t::from_seconds( util::to_double( value ) );

  if ( sim->active_player->world_lag.mean < 0_ms )
  {
    sim->active_player->world_lag.mean = 0_ms;
  }

  return true;
}

// parse_world_lag ==========================================================

bool parse_world_lag_stddev( sim_t* sim, std::string_view, std::string_view value )
{
  sim->active_player->world_lag.stddev = timespan_t::from_seconds( util::to_double( value ) );

  if ( sim->active_player->world_lag.stddev < 0_ms )
  {
    sim->active_player->world_lag.stddev = 0_ms;
  }

  return true;
}

// parse_brain_lag ==========================================================

bool parse_brain_lag( sim_t* sim, std::string_view, std::string_view value )
{
  sim->active_player->brain_lag.mean = timespan_t::from_seconds( util::to_double( value ) );

  if ( sim->active_player->brain_lag.mean < 0_ms )
  {
    sim->active_player->brain_lag.mean = 0_ms;
  }

  return true;
}

// parse_brain_lag_stddev ===================================================

bool parse_brain_lag_stddev( sim_t* sim, std::string_view, std::string_view value )
{
  sim->active_player->brain_lag.stddev = timespan_t::from_seconds( util::to_double( value ) );

  if ( sim->active_player->brain_lag.stddev < 0_ms )
  {
    sim->active_player->brain_lag.stddev = 0_ms;
  }

  return true;
}

// parse_specialization =====================================================

bool parse_specialization( sim_t* sim, std::string_view, std::string_view value )
{
  sim->active_player->_spec = dbc::translate_spec_str( sim->active_player->type, value );

  if ( sim->active_player->_spec == SPEC_NONE )
  {
    sim->error( "{} specialization string '{}' not valid.", sim->active_player->name(), value );
    return false;
  }

  return true;
}

// parse stat timelines =====================================================

bool parse_stat_timelines( sim_t* sim, std::string_view, std::string_view value )
{
  auto stats = util::string_split<std::string_view>( value, "," );

  for ( auto& stat_type : stats )
  {
    stat_e st = util::parse_stat_type( stat_type );
    if ( st == STAT_NONE )
    {
      sim->error( "'{}' could not parse timeline stat '{}' ({}).\n", sim->active_player->name(), stat_type, value );
      return false;
    }

    sim->active_player->stat_timelines.push_back( st );
  }

  return true;
}

// parse_origin =============================================================

bool parse_origin( sim_t* sim, std::string_view, std::string_view origin )
{
  player_t& p = *sim->active_player;

  p.origin_str = std::string( origin );

  std::string region, server, name;
  if ( util::parse_origin( region, server, name, origin ) )
  {
    p.region_str = region;
    p.server_str = server;
  }

  return true;
}

// parse_source ===============================================================

bool parse_source( sim_t* sim, std::string_view, std::string_view value )
{
  player_t& p = *sim->active_player;

  p.profile_source_ = util::parse_profile_source( value );

  return true;
}

bool parse_set_bonus( sim_t* sim, std::string_view, std::string_view value )
{
  player_t* p = sim->active_player;

  if ( !p->set_bonus_str.empty() )
  {
    sim->error( error_level_e::MODERATE,
                "Starting with 12.0, multiples lines of the 'set_bonus=' option must be either A) on a single line, delimited by '/', or B) have extra lines concatenated by using 'set_bonus+=', note the '+='." );

    p->set_bonus_str += fmt::format( "/{}", value );
  }
  else
  {
    p->set_bonus_str = std::string{ value };
  }

  return true;
}

bool parse_initial_resource( sim_t* sim, std::string_view, std::string_view value )
{
  player_t* player = sim->active_player;
  auto opts        = util::string_split<std::string_view>( value, ":/" );
  for ( const auto& opt_str : opts )
  {
    auto resource_split = util::string_split<std::string_view>( opt_str, "=" );
    if ( resource_split.size() != 2 )
    {
      sim->error( "{} unknown initial_resources option '{}'", player->name(), opt_str );
      return false;
    }

    resource_e resource = util::parse_resource_type( resource_split[ 0 ] );
    if ( resource == RESOURCE_NONE )
    {
      sim->error( "{} could not parse valid resource from '{}'", player->name(), resource_split[ 0 ] );
      return false;
    }

    double amount = util::to_double( resource_split[ 1 ] );
    if ( amount < 0 )
    {
      sim->error( "{} too low initial_resources option '{}'", player->name(), opt_str );
      return false;
    }

    player->resources.initial_opt[ resource ] = amount;
  }

  return true;
}
}  // namespace

/**
 * This is a template for Ignite like mechanics, like of course Ignite, Hunter Piercing Shots, Priest Echo of Light,
 * etc.
 *
 * It should get specialized in the class module.
 * Detailed MoP Ignite Mechanic description at http://us.battle.net/wow/en/forum/topic/5889309137?page=40#787
 * There is still a delay between the impact of the triggering spell and the dot application/refresh and damage
 * calculation.
 */
void residual_action::trigger( action_t* residual_action, player_t* t, double amount )
{
  struct delay_event_t : public event_t
  {
    double additional_residual_amount;
    player_t* target;
    action_t* action;

    static timespan_t delay_duration( player_t* p )
    {
      // Use same delay as in buff application
      return p->sim->rng().gauss( p->sim->default_aura_delay );
    }

    delay_event_t( player_t* t, action_t* a, double amount ) :
      event_t( *a->player, delay_duration( a->player ) ),
      additional_residual_amount( amount ),
      target( t ),
      action( a )
    {
      if ( sim().debug )
        sim().out_debug.printf( "%s %s residual_action delay_event_start amount=%f", a->player->name(), action->name(),
                                amount );
    }

    const char* name() const override
    {
      return "residual_action_delay_event";
    }

    void execute() override
    {
      // Don't ignite on targets that are not active
      if ( target->is_sleeping() )
        return;

      dot_t* dot     = action->get_dot( target );
      auto dot_state = debug_cast<residual_periodic_state_t*>( dot->state );

      assert( action->dot_duration > timespan_t::zero() );

      if ( sim().debug )
      {
        if ( dot->is_ticking() )
        {
          sim().out_debug.printf(
              "%s %s residual_action delay_event_execute target=%s amount=%f current_ticks=%d current_tick=%f",
              action->player->name(), action->name(), target->name(), additional_residual_amount, dot->ticks_left(),
              dot_state->tick_amount );
        }
        else
        {
          sim().out_debug.printf( "%s %s residual_action delay_event_execute target=%s amount=%f",
                                  action->player->name(), action->name(), target->name(), additional_residual_amount );
        }
      }

      // Pass total amount of damage to the ignite action, and let it divide it by the correct number of ticks!
      action_state_t* s = action->get_state();
      s->target         = target;
      s->result         = RESULT_HIT;
      action->snapshot_state( s, action->type == ACTION_HEAL ? result_amount_type::HEAL_OVER_TIME : result_amount_type::DMG_OVER_TIME );
      s->result_amount = additional_residual_amount;
      action->schedule_travel( s );
      if ( !action->dual )
        action->stats->add_execute( timespan_t::zero(), s->target );
    }
  };

  assert( residual_action );

  make_event<delay_event_t>( *residual_action->sim, t, residual_action, amount );
}

player_t::player_t( sim_t* s, player_e t, util::string_view n, race_e r )
  : actor_t( s, n ),
    type( t ),
    parent( nullptr ),
    index( -1 ),
    creation_iteration( sim->current_iteration ),
    actor_spawn_index( -1 ),
    race( r ),
    role( ROLE_NONE ),
    true_level( default_level ),
    party( 0 ),
    ready_type( READY_POLL ),
    _spec( SPEC_NONE ),
    bugs( true ),
    disable_hotfixes( 0 ),
    scale_player( true ),
    death_pct( 0.0 ),
    height( 0 ),
    combat_reach( 1.0 ),
    profile_source_( profile_source::DEFAULT ),
    default_target( nullptr ),
    target( nullptr ),
    initialized( false ),
    precombat_initialized( false ),
    potion_used( false ),
    leech_pool( 0 ),
    region_str( s->default_region_str ),
    server_str( s->default_server_str ),
    origin_str(),
    timeofday( NIGHT_TIME ),  // Depends on server time, default to night that's more common for raid hours
    zandalari_loa( PAKU ),  // Default to Paku as it has some non-zero dps benefit for all specs
    vulpera_tricks( CORROSIVE ),  // default trick for damage
    earthen_mineral( RUBY ),  // default mineral is ruby (crit)
    gcd_ready( 0_ms ),
    base_gcd( 1.5_s ),
    min_gcd( 750_ms ),
    gcd_type( gcd_haste_type::NONE ),
    gcd_current_haste_value( 1.0 ),
    started_waiting( timespan_t::min() ),
    pet_list(),
    active_pets(),
    invert_scaling( 0 ),
    // Reaction
    reaction( 250_ms, 0_ms ),
    reaction_offset( 100_ms ),
    reaction_max( 1.4_s ),
    reaction_nu( 150_ms ),
    // Latency
    world_lag( s->world_lag ),
    brain_lag( 0_ms, timespan_t::min() ),
    cooldown_tolerance_( timespan_t::min() ),
    enable_spell_queue( false ),
    spell_queue_window( 400_ms ),
    dbc( new dbc_t(*(s->dbc)) ),
    dbc_override( sim->dbc_override.get() ),
    profession(),
    azerite( nullptr ),
    base(),
    initial(),
    current(),
    last_cast( 0_ms),
    // Defense Mechanics
    def_dr( diminishing_returns_constants_t() ),
    // Attacks
    main_hand_attack( nullptr ),
    off_hand_attack( nullptr ),
    current_auto_attack_speed( 1.0 ),
    // Resources
    resources(),
    // Consumables
    // Events
    executing( nullptr ),
    queueing( nullptr ),
    channeling( nullptr ),
    strict_sequence( nullptr ),
    demise_event(),
    readying( nullptr ),
    off_gcd( nullptr ),
    cast_while_casting_poll_event(),
    spell_queue_event(),
    off_gcd_ready( timespan_t::min() ),
    cast_while_casting_ready( timespan_t::min() ),
    in_combat( false ),
    in_boss_encounter( 1 ),
    action_queued( false ),
    first_cast( true ),
    last_foreground_action( nullptr ),
    spell_queued_action( nullptr ),
    prev_gcd_actions( 0 ),
    off_gcdactions(),
    cast_delay_reaction( 0_ms ),
    cast_delay_occurred( 0_ms ),
    callbacks( s ),
    use_apl( "" ),
    // Actions
    use_default_action_list( false ),
    use_blizzard_action_list( false ),
    use_cds_with_blizzard_action_list( true ),
    one_button_mode( false ),
    precombat_action_list( 0 ),
    active_action_list(),
    default_action_list(),
    active_off_gcd_list(),
    active_cast_while_casting_list(),
    restore_action_list(),
    restore_action_list_type( execute_type::FOREGROUND ),
    no_action_list_provided(),
    // Reporting
    quiet( false ),
    report_extension(),
    mixin_reports(),
    arise_time( timespan_t::min() ),
    iteration_fight_length(),
    iteration_waiting_time(),
    iteration_pooling_time(),
    iteration_executed_foreground_actions( 0 ),
    iteration_resource_lost(),
    iteration_resource_gained(),
    iteration_resource_overflowed(),
    rps_gain( 0 ),
    rps_loss( 0 ),
    collected_data( this ),
    collect_pet_sequence_data( false ),
    // Damage
    iteration_dmg( 0 ),
    priority_iteration_dmg( 0 ),
    iteration_dmg_taken( 0 ),
    dpr( 0 ),
    // Heal
    iteration_heal( 0 ),
    iteration_heal_taken( 0 ),
    iteration_absorb(),
    iteration_absorb_taken(),
    hpr( 0 ),
    report_information(),
    // Gear
    sets( ( !is_pet() && !is_enemy() ) ? new set_bonus_t( this ) : nullptr ),
    matching_gear( false ),
    item_cooldown( new cooldown_t("item_cd", *this) ),
    default_item_group_cooldown( 20_s ),
    load_default_gear( false ),
    load_default_talents( false ),
    auto_attack_modifier( 0.0 ),
    auto_attack_base_modifier( 0.0 ),
    auto_attack_multiplier( 1.0 ),
    scaling( ( !is_pet() || sim->report_pets_separately ) ? new player_scaling_t() : nullptr ),
    // Position
    x_position( 0.0 ),
    y_position( 0.0 ),
    default_x_position( std::numeric_limits<double>::lowest() ),
    default_y_position( std::numeric_limits<double>::lowest() ),
    consumables(),
    buffs(),
    debuffs(),
    external_buffs(),
    gains(),
    spells(),
    procs(),
    uptimes(),
    racials(),
    active_during_iteration( false ),
    spec_spell( spell_data_t::nil() ),
    single_button_assistant( spell_data_t::nil() ),
    _mastery( &spelleffect_data_t::nil() ),
    cache( this ),
    resource_regeneration( regen_type::STATIC ),
    last_regen( timespan_t::zero() ),
    regen_caches( CACHE_MAX ),
    dynamic_regen_pets( false ),
    visited_apls_( 0 ),
    action_list_id_( 0 ),
    current_execute_type( execute_type::FOREGROUND ),
    has_active_resource_callbacks( false ),
    disable_class_spell_auto_cloning( false ),
    resource_threshold_trigger()
{
  actor_index = sim->actor_list.size();
  sim->actor_list.push_back( this );

  if ( ! is_enemy() && ! is_pet() )
  {
    azerite = azerite::create_state( this );
    azerite_essence = azerite::create_essence_state( this );
    dbc_override_ = std::make_unique<dbc_override_t>( dbc_override );
    dbc_override = dbc_override_.get();
  }

  // Set the gear object to a special default value, so we can support gear_x=0 properly.
  // player_t::init_items will replace the defaulted gear_stats_t object with a computed one once
  // the item stats have been computed.
  gear.initialize( std::numeric_limits<double>::lowest() );

  base.skill              = sim->default_skill;
  base.mastery            = 8.0;
  base.movement_direction = movement_direction_type::NONE;

  if ( !is_enemy() && type != HEALING_ENEMY )
  {
    sim->print_debug( "Creating Player {}.", name_str );
    sim->player_list.push_back( this );
    if ( !is_pet() )
    {
      sim->player_no_pet_list.push_back( this );
    }
    index = ++( sim->num_players );
  }
  else
  {
    if ( type != HEALING_ENEMY )  // Not actually a enemy target.
    {
      ++( sim->enemy_targets );
    }
    index = -( ++( sim->num_enemies ) );
  }

  // Fill healing lists with all non-enemy players.
  if ( !is_enemy() )
  {
    if ( !is_pet() )
    {
      sim->healing_no_pet_list.push_back( this );
    }
    else
    {
      sim->healing_pet_list.push_back( this );
    }
  }

  if ( !is_pet() && sim->stat_cache != -1 )
  {
    cache.active = sim->stat_cache != 0;
  }
  if ( is_pet() )
    current.skill = 1.0;

  resources.infinite_resource[ RESOURCE_HEALTH ] = true;

  if ( !is_pet() )
  {
    items.resize( SLOT_MAX );
    for ( slot_e i = SLOT_MIN; i < SLOT_MAX; i++ )
    {
      items[ i ].slot   = i;
      items[ i ].sim    = sim;
      items[ i ].player = this;
    }
  }

  main_hand_weapon.slot = SLOT_MAIN_HAND;
  off_hand_weapon.slot  = SLOT_OFF_HAND;

  if ( reaction.stddev == 0_ms )
    reaction.stddev = reaction.mean * 0.2;

  action_list_information =
      "\n"
      "# This default action priority list is automatically created based on your character.\n"
      "# It is a attempt to provide you with a action list that is both simple and practicable,\n"
      "# while resulting in a meaningful and good simulation. It may not result in the absolutely highest possible "
      "dps.\n"
      "# Feel free to edit, adapt and improve it to your own needs.\n"
      "# SimulationCraft is always looking for updates and improvements to the default action lists.\n";

  if ( !is_pet() && !is_enemy() )
  {
    sim->register_heartbeat_event_callback( [ this ]( sim_t* ) {
      if ( in_combat )
        trigger_callbacks( PROC1_HEARTBEAT, PROC2_LANDED, proc_data_t::nil(), this, TRIGGER_HEARTBEAT );

      for ( auto& pet : active_pets )
      {
        pet->update_stats();
      }
    } );
  }
}

// Added in source file to get full definitions of all objects to destruct here;
player_t::~player_t() = default;

player_t::base_initial_current_t::base_initial_current_t() :
  stats(),
  spell_power_per_intellect( 0 ),
  spell_power_per_attack_power( 0 ),
  attack_power_per_strength( 0 ),
  attack_power_per_agility( 0 ),
  attack_power_per_spell_power( 0 ),
  dodge_per_agility( 0 ),
  parry_per_strength( 0 ),
  parry_rating_per_crit_rating( 0 ),
  health_per_stamina( 0 ),
  resource_reduction(),
  miss( 0 ),
  dodge( 0 ),
  parry( 0 ),
  block( 0 ),
  hit( 0 ),
  expertise( 0 ),
  leech( 0 ),
  avoidance( 0 ),
  crit_avoidance( 0 ),
  spell_crit_chance(),
  attack_crit_chance(),
  block_value(),
  mastery( 0 ),
  versatility( 0 ),
  all_crit( 0 ),
  all_haste( 1.0 ),
  melee_haste( 1.0 ),
  spell_haste( 1.0 ),
  ranged_haste( 1.0 ),
  skill( 1.0 ),
  skill_debuff( 0.0 ),
  distance( 0 ),
  distance_to_move( 0 ),
  moving_away( 0 ),
  movement_direction(),
  armor_coeff( 0 ),
  sleeping( false ),
  rating(),
  attribute_multiplier(),
  matching_armor_multiplier(),
  rating_multiplier(),
  spell_power_multiplier( 1.0 ),
  attack_power_multiplier( 1.0 ),
  base_armor_multiplier( 1.0 ),
  armor_multiplier( 1.0 ),
  crit_damage_multiplier(),
  crit_healing_multiplier( 1.0 ),
  attack_speed_multiplier( 1.0 ),
  healing_multiplier( 1.0 ),
  damage_multiplier(),
  pet_damage_multiplier( 1.0 ),
  guardian_damage_multiplier( 1.0 ),
  absorb_multiplier( 1.0 ),
  absorb_received_multiplier( 1.0 ),
  healing_received_multiplier( 1.0 ),
  armor_penetration( 1.0 ),
  movement_speed( 0 ),
  stacking_movement_speed_modifier( 0.0 ),
  non_stacking_movement_speed_modifier( 0.0 ),
  position( POSITION_BACK )
{
  range::fill( attribute_multiplier, 1.0 );
  range::fill( matching_armor_multiplier, 1.0 );
  range::fill( rating_multiplier, 1.0 );
  range::fill( crit_damage_multiplier, 1.0 );
  range::fill( damage_multiplier, 1.0 );
}

void sc_format_to( const player_t::base_initial_current_t& s, fmt::format_context::iterator out )
{
  fmt::format_to( out, "{}", s.stats );
  fmt::format_to( out, " spell_power_per_intellect={:.6g}", s.spell_power_per_intellect );
  fmt::format_to( out, " spell_power_per_attack_power={:.6g}", s.spell_power_per_attack_power );
  fmt::format_to( out, " attack_power_per_strength={:.6g}", s.attack_power_per_strength );
  fmt::format_to( out, " attack_power_per_agility={:.6g}", s.attack_power_per_agility );
  fmt::format_to( out, " attack_power_per_spell_power={:.6g}", s.attack_power_per_spell_power );
  fmt::format_to( out, " dodge_per_agility={:.6g}", s.dodge_per_agility );
  fmt::format_to( out, " parry_per_strength={:.6g}", s.parry_per_strength );
  fmt::format_to( out, " parry_rating_per_crit_rating={:.6g}", s.parry_rating_per_crit_rating );
  fmt::format_to( out, " health_per_stamina={:.6g}", s.health_per_stamina );
  // resource_reduction
  fmt::format_to( out, " miss={:.6g}", s.miss );
  fmt::format_to( out, " dodge={:.6g}", s.dodge );
  fmt::format_to( out, " parry={:.6g}", s.parry );
  fmt::format_to( out, " block={:.6g}", s.block );
  fmt::format_to( out, " spell_crit_chance={:.6g}", s.spell_crit_chance );
  fmt::format_to( out, " attack_crit_chance={:.6g}", s.attack_crit_chance );
  fmt::format_to( out, " block_value={:.6g}", s.block_value );
  fmt::format_to( out, " mastery={:.6g}", s.mastery );
  fmt::format_to( out, " versatility={:.6g}", s.versatility );
  fmt::format_to( out, " all_haste={:.6g}", s.all_haste );
  fmt::format_to( out, " melee_haste={:.6g}", s.melee_haste );
  fmt::format_to( out, " spell_haste={:.6g}", s.spell_haste );
  fmt::format_to( out, " ranged_haste={:.6g}", s.ranged_haste );
  fmt::format_to( out, " leech={:.6g}", s.leech );
  fmt::format_to( out, " expertise={:.6g}", s.expertise );
  fmt::format_to( out, " skill={:.6g}", s.skill );
  fmt::format_to( out, " distance={:.6g}", s.distance );
  fmt::format_to( out, " armor_coeff={:.6g}", s.armor_coeff );
  fmt::format_to( out, " sleeping={}", s.sleeping );
  // attribute_multiplier
  for ( auto i : { ATTR_STRENGTH, ATTR_AGILITY, ATTR_STAMINA, ATTR_INTELLECT, ATTR_SPIRIT } )
  {
    fmt::format_to( out, " {}_multiplier={:.6g}", util::attribute_type_string( i ), s.attribute_multiplier[ i ] );
    fmt::format_to( out, " matching_armor_{}_multiplier={:.6g}", util::attribute_type_string( i ),
                    s.matching_armor_multiplier[ i ] );
  }
  // rating_multiplier
  for ( auto i = RATING_BLOCK; i < RATING_MAX; i++ )
    fmt::format_to( out, " {}_multiplier={:.6g}", util::rating_type_string( i ), s.rating_multiplier[ i ] );

  fmt::format_to( out, " spell_power_multiplier={:.6g}", s.spell_power_multiplier );
  fmt::format_to( out, " attack_power_multiplier={:.6g}", s.attack_power_multiplier );
  fmt::format_to( out, " base_armor_multiplier={:.6g}", s.base_armor_multiplier );
  fmt::format_to( out, " armor_multiplier={:.6g}", s.armor_multiplier );
  for ( auto school = SCHOOL_NONE; school < SCHOOL_MAX_PRIMARY; ++school )
  {
    fmt::format_to( out, " {}_damage_multiplier={:.6g}", util::school_type_string( school ),
                    s.damage_multiplier[ school ] );
    fmt::format_to( out, " {}_crit_damage_multiplier={:.6g}", util::school_type_string( school ),
                    s.crit_damage_multiplier[ school ] );
  }
  fmt::format_to( out, " healing_multiplier={:.6g}", s.healing_multiplier );
  fmt::format_to( out, " crit_healing_multiplier={:.6g}", s.crit_healing_multiplier );
  fmt::format_to( out, " attack_speed_multiplier={:.6g}", s.attack_speed_multiplier );
  fmt::format_to( out, " pet_damage_multiplier={:.6g}", s.pet_damage_multiplier );
  fmt::format_to( out, " guardian_damage_multiplier={:.6g}", s.guardian_damage_multiplier );
  fmt::format_to( out, " absorb_multiplier={:.6g}", s.absorb_multiplier );
  fmt::format_to( out, " absorb_received_multiplier={:.6g}", s.absorb_received_multiplier );
  fmt::format_to( out, " healing_received_multiplier={:.6g}", s.healing_received_multiplier );
  fmt::format_to( out, " movement_speed={:.6g}_yards/s", s.movement_speed );
  fmt::format_to( out, " stacking_movement_speed_modifier={:.6g}", s.stacking_movement_speed_modifier );
  fmt::format_to( out, " non_stacking_movement_speed_modifier={:.6g}", s.non_stacking_movement_speed_modifier );
  fmt::format_to( out, " position={}", s.position );
}

void player_t::init()
{
  sim->print_debug( "Initializing {}.", *this );

  // Validate current fight style is supported by the actor's module.
  if ( !validate_fight_style( sim->fight_style ) )
  {
    sim->error( error_level_e::SEVERE,
                "{} does not support fight style {}, results are inaccurate and should not be used.", *this,
                util::fight_style_string( sim->fight_style ) );
  }

  // Ensure the precombat and default lists are the first listed
  auto pre_combat = get_action_priority_list( "precombat", "Executed before combat begins. Accepts non-harmful actions only." );
  pre_combat->used = true;
  get_action_priority_list( "default", "Executed every time the actor is available." );

  if ( !use_blizzard_action_list )
  {
    for ( auto& elem : alist_map )
    {
      if ( elem.first == "default" )
        sim->error( "Ignoring action list named default." );
      else
        get_action_priority_list( elem.first )->action_list_str = elem.second;
    }
  }

  // If the owner is regenerating using dynamic resource regen, we need to
  // ensure that pets that regen dynamically also get updated correctly. Thus,
  // we copy any CACHE_x enum values from pets to the owner. Also, if we have
  // no dynamically regenerating pets, we do not need to go through extra work
  // in do_dynamic_regen() to call the pets do_dynamic_regen(), saving some cpu
  // cycles.
  if (resource_regeneration == regen_type::DYNAMIC)
  {
    for ( auto pet : pet_list )
    {
      if ( pet->resource_regeneration != regen_type::DYNAMIC)
        continue;

      for ( cache_e c = CACHE_NONE; c < CACHE_MAX; c++ )
      {
        if ( pet->regen_caches[ c ] )
          regen_caches[ c ] = true;
      }

      dynamic_regen_pets = true;
    }
  }

  // If Single-actor batch mode is used, player_collected_data_t::fight_length has to be
  // unconditionally made to record full data on actor fight lengths. This is to get proper
  // information on timelines in reports, since the sim-wide fight lengths ar no longer usable as
  // the "timeline adjustor" during analysis phase. This operation is done here so the
  // single_actor_batch does not become a positional parameter, since relying on it's state in
  // player_collected_data_t constructor would require it to be parsed before any actors are
  // defined.
  if ( sim->single_actor_batch )
  {
    collected_data.fight_length.change_mode( false );  // Not simple
  }

  if ( world_lag.stddev < 0_ms )
    world_lag.stddev = world_lag.mean * 0.1;
  if ( brain_lag.stddev < 0_ms )
    brain_lag.stddev = brain_lag.mean * 0.1;
}

/**
 * Initialize base variables from database or other sources
 *
 * After player_t::init_base is executed, you can modify the base member until init_initial is called
 */
void player_t::init_base_stats()
{
  sim->print_debug( "Initializing base stats for {}.", *this );

  // Ensure base stats have not been tampered with.
  for ( stat_e stat = STAT_NONE; stat < STAT_MAX; ++stat )
  {
    double stat_value = base.stats.get_stat( stat );
    if ( stat_value > 0 )
    {
      sim->error( "{} stat {} is {} != 0.0", name(), stat, stat_value );
      sim->error( " Please do not modify player_t::base before init_base_stats is called\n" );
    }
  }

  if ( !is_enemy() )
    base.rating.init( *dbc, level() );

  sim->print_debug( "{} base ratings initialized: {}", *this, base.rating );

  if ( !is_enemy() )
  {
    base.stats.attribute[ ATTR_STRENGTH ] =
      dbc->race_base( race ).strength + dbc->attribute_base( type, level() ).strength;
    base.stats.attribute[ ATTR_AGILITY ] =
      dbc->race_base( race ).agility + dbc->attribute_base( type, level() ).agility;
    base.stats.attribute[ ATTR_STAMINA ] =
      dbc->race_base( race ).stamina + dbc->attribute_base( type, level() ).stamina;
    base.stats.attribute[ ATTR_INTELLECT ] =
      dbc->race_base( race ).intellect + dbc->attribute_base( type, level() ).intellect;
    base.stats.attribute[ ATTR_SPIRIT ] =
      dbc->race_base( race ).spirit + dbc->attribute_base( type, level() ).spirit;

    // Passive Flat Stat Modifiers
    for( auto attr : { ATTR_STRENGTH, ATTR_AGILITY, ATTR_STAMINA, ATTR_INTELLECT, ATTR_SPIRIT } )
    {
      base.stats.attribute[ attr ] *= get_passive_player_value( 1.0, "base_attribute_multiplier", attr );
      base.stats.attribute[ attr ] = get_passive_player_value( base.stats.attribute[ attr ], "attribute_value", attr );
    }

    // Passive Attribute Multipliers
    for ( auto attr : { ATTR_STRENGTH, ATTR_AGILITY, ATTR_STAMINA, ATTR_INTELLECT, ATTR_SPIRIT } )
    {
      base.attribute_multiplier[ attr ] =
        get_passive_player_value( base.attribute_multiplier[ attr ], "attribute_multiplier", attr );
      base.matching_armor_multiplier[ attr ] =
        get_passive_player_value( base.matching_armor_multiplier[ attr ], "armor_type_multiplier", attr );
    }

    for ( auto rating = static_cast<rating_e>( 0 ); rating < RATING_MAX; ++rating )
    {
      // Rating Multipliers
      base.rating_multiplier[ rating ] =
        get_passive_player_value( base.rating_multiplier[ rating ], "rating_multiplier", rating );
    }

    // Core Stats
    base.all_haste    /= get_passive_player_value( base.all_haste, "all_haste" );
    base.melee_haste  = base.all_haste;
    base.spell_haste  = base.all_haste;
    base.ranged_haste = base.all_haste;

    base.all_crit           = get_passive_player_value( dbc->all_crit_base( type, level() ), "all_crit" );
    base.spell_crit_chance  = get_passive_player_value( base.all_crit, "spell_crit" );
    base.attack_crit_chance = base.all_crit;

    base.mastery     = get_passive_player_value( 8.0, "mastery" );
    base.versatility = get_passive_player_value( base.versatility, "versatility" );

    base.leech          = get_passive_player_value( base.leech, "leech" );
    base.avoidance      = 0.0;
    base.crit_avoidance = get_passive_player_value( base.crit_avoidance, "crit_avoidance" );

    base.base_armor_multiplier = get_passive_player_value( base.base_armor_multiplier, "base_armor_multiplier" );
    base.armor_multiplier      = get_passive_player_value( base.armor_multiplier, "armor_multiplier" );

    // school based multipliers
    for ( auto school = SCHOOL_NONE; school < SCHOOL_MAX_PRIMARY; ++school )
    {
      base.damage_multiplier[ school ] =
        get_passive_player_value( base.damage_multiplier[ school ], "damage_multiplier", school );
      base.damage_multiplier[ school ] *= get_passive_player_value( 1.0, "damage_multiplier", -1 );

      base.crit_damage_multiplier[ school ] =
        get_passive_player_value( base.crit_damage_multiplier[ school ], "crit_damage_multiplier", school );
      base.crit_damage_multiplier[ school ] *= get_passive_player_value( 1.0, "crit_damage_multiplier", -1 );
    }

    double attack_speed_multiplier = base.attack_speed_multiplier;
    base.attack_speed_multiplier /= get_passive_player_value( attack_speed_multiplier, "attack_speed" );
    base.attack_speed_multiplier *= get_passive_player_value( attack_speed_multiplier, "attack_speed_modifier" );
    base.attack_power_multiplier = get_passive_player_value( base.attack_power_multiplier, "attack_power_multiplier" );

    base.absorb_multiplier       = get_passive_player_value( base.absorb_multiplier, "absorb_multiplier" );
    base.healing_multiplier      = get_passive_player_value( base.healing_multiplier, "healing_multiplier" );
    base.crit_healing_multiplier = get_passive_player_value( base.crit_healing_multiplier, "crit_heal_multiplier" );

    base.absorb_received_multiplier =
      get_passive_player_value( base.absorb_received_multiplier, "absorb_received_multiplier" );
    base.healing_received_multiplier =
      get_passive_player_value( base.healing_received_multiplier, "healing_received_multiplier" );

    // Base Pet Damage Modifiers
    base.pet_damage_multiplier =
      get_passive_player_value( base.pet_damage_multiplier, "pet_damage_multiplier" );
    base.guardian_damage_multiplier =
      get_passive_player_value( base.guardian_damage_multiplier, "guardian_damage_multiplier" );

    // Resources
    for ( auto rt = RESOURCE_HEALTH; rt < RESOURCE_MAX; rt++ )
    {
      auto _data = power_type_data_t::find( rt, dbc->ptr );

      // skip resources not active for class
      if ( ( rt != RESOURCE_HEALTH && !_data.is_active_for_class( type ) ) || !resources.active_resource[ rt ] )
      {
        resources.active_resource[ rt ] = false;
        continue;
      }

      double rt_base = 0.0;
      double rt_mul = 1.0;
      double rt_regen = 0.0;
      double rt_start = -1.0;  // -1 == start at computed max

      switch ( rt )
      {
        case RESOURCE_HEALTH:
          break;
        case RESOURCE_MANA:  // 1% of base mana as mana regen per second for all classes.
          rt_base = dbc->resource_base( type, level() );
          rt_regen = dbc->resource_base( type, level() ) * 0.01;
          break;
        case RESOURCE_RUNE:  // rune regeneration is handled in dk module
          rt_base = _data.base();
          break;
        default:
          rt_base = _data.base();
          rt_regen = _data.regen_per_second();
          if ( _data.start() != _data.base() )
            rt_start = _data.start();
          break;
      }

      resources.base[ rt ]                  = get_passive_player_value( rt_base, "resource_max", rt );
      resources.base_multiplier[ rt ]       = get_passive_player_value( rt_mul, "resource_multiplier", rt );
      resources.base_regen_per_second[ rt ] = get_passive_player_value( rt_regen, "resource_regen", rt );
      resources.hasted[ rt ]                = _data.is_hasted_regen();
      // Starting amount, the actual start-of-combat resource is min( computed_max, start_at )
      resources.start_at[ rt ] = rt_start == -1.0 ? std::numeric_limits<double>::max() : rt_start;
    }

    base.health_per_stamina = dbc->health_per_stamina( level() );

    // players have a base 7.5% hit/exp
    base.hit       = 0.075;
    base.expertise = 0.075;
    base.expertise = get_passive_player_value( base.expertise, "expertise" );
    base.armor_penetration = get_passive_player_value( base.armor_penetration, "armor_penetration" );

    if ( base.distance < 1 )
      base.distance = 5;

    // Armor Coefficient, based on level (1054 @ 50; 2500 @ 60-63)
    base.armor_coeff = dbc->armor_mitigation_constant( level() );
    sim->print_debug( "{} base armor coefficient set to {}.", *this, base.armor_coeff );
  }

  base.attack_power_per_spell_power =
    get_passive_player_value( base.attack_power_per_spell_power, "attack_power_per_spell_power" );
  base.spell_power_per_attack_power =
    get_passive_player_value( base.spell_power_per_attack_power, "spell_power_per_attack_power" );

  // only certain classes get Agi->Dodge conversions, dodge_per_agility defaults to 0.00
  // exact values given by Blizzard, only have L90-L100 data
  if ( type == MONK || type == DRUID || type == ROGUE || type == HUNTER || type == SHAMAN || type == DEMON_HUNTER )
    base.dodge_per_agility = dbc->avoid_per_str_agi_by_level( level() ) / 100.0;

  // only certain classes get Str->Parry conversions, parry_per_strength defaults to 0.00
  // exact values given by Blizzard, only have L90-L100 data
  if ( type == PALADIN || type == WARRIOR || type == DEATH_KNIGHT )
    base.parry_per_strength = dbc->avoid_per_str_agi_by_level( level() ) / 100.0;

  // All classes get 3% dodge and miss
  base.dodge = 0.03;
  base.miss = 0.03;

  // Dodge from base agility isn't affected by diminishing returns and is added here
  if ( base.dodge_per_agility > 0 )
  {
    base.dodge +=
      ( dbc->race_base( race ).agility + dbc->attribute_base( type, level() ).agility ) * base.dodge_per_agility;
  }

  base.dodge = get_passive_player_value( base.dodge, "dodge" );

  switch ( type )
  {
    // Only Warriors and Paladins can block, defaults to 0
    case PALADIN:
    case WARRIOR:
      // Base block chance is 3%, increased in warriors' and paladins' class aura and protection warrior's spec aura
      // Further increased by mastery for both Protection specs
      base.block = 0.03;
      base.block = get_passive_player_value( base.block, "block" );

      // Currently block reduction is 2.5x the armor value of the shield
      if ( items[ SLOT_OFF_HAND ].dbc_inventory_type() == INVTYPE_SHIELD )
        base.block_value = items[ SLOT_OFF_HAND ].stats.armor * 2.5;
      else
        base.block_value = 0;

      base.block_value = get_passive_player_value( base.block_value, "block_value" );
      SC_FALLTHROUGH;
    // Only certain classes can parry, and get 3% base parry, default is 0
    case DEATH_KNIGHT:
      // Parry from base strength isn't affected by diminishing returns and is added here
      base.parry = ( dbc->race_base( race ).strength + dbc->attribute_base( type, level() ).strength ) * base.parry_per_strength;
      SC_FALLTHROUGH;
    case DEMON_HUNTER:
    case MONK:
    case ROGUE:
      base.parry += 0.03;
      base.parry = get_passive_player_value( base.parry, "parry" );
      base.parry_rating_per_crit_rating = get_passive_player_value( base.parry_rating_per_crit_rating, "parry_from_crit_rating" );
      break;
    case ENEMY:
    case TANK_DUMMY:
      base.parry = 0.03;
      break;
    default:
      break;
  }

  // Movement Speed
  base.movement_speed = 7.0;  // yards per second
  base.stacking_movement_speed_modifier =
    get_passive_player_value( base.stacking_movement_speed_modifier, "move_speed_modifier_-_stacking" );
  base.non_stacking_movement_speed_modifier =
    get_passive_player_value( base.non_stacking_movement_speed_modifier, "move_speed_modifier_-_exclusive" );

  // Extract avoidance DR values from table in sc_extra_data.inc
  def_dr.horizontal_shift       = dbc->horizontal_shift( type );
  def_dr.block_vertical_stretch = dbc->block_vertical_stretch( type );
  def_dr.vertical_stretch       = dbc->vertical_stretch( type );
  def_dr.dodge_factor           = dbc->dodge_factor( type );
  def_dr.parry_factor           = dbc->parry_factor( type );
  def_dr.miss_factor            = dbc->miss_factor( type );
  def_dr.block_factor           = dbc->block_factor( type );

  if ( primary_role() == ROLE_TANK )
  {
    // Collect DTPS data for tanks even for statistics_level == 1
    if ( sim->statistics_level >= 1 )
      collected_data.dtps.change_mode( false );
  }

  sim->print_debug( "{} generic base stats: {}", *this, base );

  // Set auto attack modifiers here, even though they're on player_t instead of base stats
  auto_attack_multiplier = get_passive_player_value( auto_attack_multiplier, "auto_attack_multiplier" );
}

/**
 * Initialize initial stats from base + gear
 *
 * After player_t::init_initial is executed, you can modify the initial member until combat starts
 */
void player_t::init_initial_stats()
{
  sim->print_debug( "Initializing initial stats for {}.", *this );

  // Ensure initial stats have not been tampered with.
  for ( stat_e stat = STAT_NONE; stat < STAT_MAX; ++stat )
  {
    double stat_value = initial.stats.get_stat( stat );
    if ( stat_value > 0 )
    {
      sim->error( "{} initial stat {} is {} != 0", *this, stat, stat_value );
      sim->error( " Please do not modify player_t::initial before init_initial_stats is called\n" );
    }
  }

  initial = base;
  initial.stats += passive;

  // Compute current "total from gear" into total gear. Per stat, this is either the amount of stats
  // the items for the actor gives or the overridden value from gear_x_rating player scoped option or dps plot stat
  // initial value override (player_t::gear + player_t::enchant + sim_t::enchant).
  if ( !is_pet() && !is_enemy() )
  {
    gear_stats_t item_stats = range::accumulate( items, gear_stats_t{}, &item_t::total_stats );

    for ( stat_e stat = STAT_NONE; stat < STAT_MAX; ++stat )
    {
      double scale_override = -1;
      if ( scale_player && sim->scaling->scale_stat == stat && sim->plot->dps_plot_stats.count( stat ) )
        scale_override = sim->plot->dps_plot_stats.at( stat );

      if ( scale_override >= 0 )
        total_gear.add_stat( stat, scale_override );
      else if ( gear.get_stat( stat ) < 0 )
        total_gear.add_stat( stat, item_stats.get_stat( stat ) );
      else
        total_gear.add_stat( stat, gear.get_stat( stat ) );
    }

    sim->print_debug( "{} total gear stats: {}", *this, total_gear );

    initial.stats += enchant;
    initial.stats += sim->enchant;
  }

  initial.stats += total_gear;

  sim->print_debug( "{} generic initial stats: {}", *this, initial );
}

void player_t::parse_temporary_enchants()
{
  std::string tench_str = temporary_enchant_str.empty() ? default_temporary_enchant() : temporary_enchant_str;

  if ( util::str_compare_ci( tench_str, "disabled" ) )
  {
    return;
  }

  auto split = util::string_split<util::string_view>( tench_str, "/" );
  for ( const auto& token : split )
  {
    std::string expr_str, options_str, value_str;
    std::unique_ptr<expr_t> if_expr;
    std::vector<std::unique_ptr<option_t>> temp_options;

    temp_options.emplace_back( opt_string( "if", expr_str ) );

    auto cut_pt = token.find_first_of( ',' );
    if ( cut_pt != std::string::npos )
    {
      options_str = token.substr( cut_pt + 1 );
      value_str = token.substr( 0, cut_pt );
    }
    else
    {
      value_str = token;
    }

    try
    {
      opts::parse( sim, value_str, temp_options, options_str );

      if ( !expr_str.empty() )
      {
        if_expr = expr_t::parse( this, expr_str, false );
      }
    }
    catch ( const std::exception& )
    {
      std::throw_with_nested(
        sc_invalid_player_argument( fmt::format( "Invalid temporary enchant '{}'.", token ) ) );
    }

    auto token_split = util::string_split<util::string_view>( value_str, ":" );
    if ( token_split.size() != 2 )
    {
      if ( sim->strict_parsing )
      {
        throw sc_invalid_player_argument(
          fmt::format( "Invalid temporary enchant '{}', format is 'slot:name'.", token ) );
      }
      else
      {
        sim->error( "{} invalid temporary enchant '{}', format is 'slot:name', ignoring.", *this, token );
        continue;
      }
    }
    auto slot = util::parse_slot_type( token_split[ 0 ] );
    util::string_view enchant_str = token_split[ 1 ];
    unsigned rank = 0;

    auto it = token_split[ 1 ].rfind( '_' );
    if ( it != std::string_view::npos )
    {
      auto rank_str = token_split[ 1 ].substr( it + 1 );
      auto parsed_rank = util::to_unsigned_ignore_error( rank_str,
                                                        std::numeric_limits<unsigned>::max() );

      if ( parsed_rank != std::numeric_limits<unsigned>::max() )
      {
        enchant_str = token_split[ 1 ].substr( 0, it );
        rank = parsed_rank;
      }
    }

    const auto& temp_enchant = temporary_enchant_entry_t::find( enchant_str, rank, dbc->ptr );
    if ( slot == SLOT_INVALID || temp_enchant.enchant_id == 0 )
    {
      if ( sim->strict_parsing )
      {
        throw sc_invalid_player_argument( fmt::format( "Invalid temporary enchant '{}' (slot={}, enchant_id={}).",
                                                       token, util::slot_type_string( slot ),
                                                       temp_enchant.enchant_id ) );
      }
      else
      {
        sim->error( "{} invalid temporary enchant '{}' (slot={}, enchant_id={}), ignoring.", *this, token,
                    util::slot_type_string( slot ), temp_enchant.enchant_id );
        continue;
      }
    }

    items[ slot ].parsed.temporary_enchants.emplace_back( temp_enchant.enchant_id, if_expr );
  }
}

void player_t::init_items()
{
  sim->print_debug( "Initializing items for {}.", *this );

  std::array<bool, SLOT_MAX> matching_gear_slots;  // true if the given item is equal to the highest armor type the player can wear
  for ( slot_e i = SLOT_MIN; i < SLOT_MAX; i++ )
    matching_gear_slots[ i ] = !util::is_match_slot( i );

  // Override with item slot overrides. Note this will completely replace any player-scoped item options
  if ( is_player() && type != PLAYER_SIMPLIFIED )
  {
    for ( const auto& [ override_slot, override_str ] : sim->item_slot_overrides )
    {
      if ( auto slot = util::parse_slot_type( override_slot ); slot != SLOT_INVALID )
      {
        items[ slot ].options_str = override_str;
      }
      else
      {
        sim->error( "{} overriding unknown item slot '{}={}'; ignoring.", *this, override_slot, override_str );
      }
    }

    if ( load_default_gear )
    {
      uint32_t class_, spec_;
      if ( !dbc->spec_idx( specialization(), class_, spec_ ) )
      {
        sim->error( "{} cannot load default gear, invalid class and/or specialization.", *this );
        return;
      }

      for ( const auto& equipment : character_loadout_data_t::data( class_, spec_, is_ptr() ) )
      {
        const auto& item = dbc->item( equipment.id_item );
        auto inv_type = static_cast<inventory_type>( item.inventory_type );
        auto slot = util::translate_invtype( inv_type );

        if ( !items[ slot ].options_str.empty() )
        {
          if ( inv_type == INVTYPE_WEAPON && slot == SLOT_MAIN_HAND && items[ SLOT_OFF_HAND ].options_str.empty() )
            slot = SLOT_OFF_HAND;
          else if ( inv_type == INVTYPE_FINGER && slot == SLOT_FINGER_1 && items[ SLOT_FINGER_2 ].options_str.empty() )
            slot = SLOT_FINGER_2;
          else if ( inv_type == INVTYPE_TRINKET && slot == SLOT_TRINKET_1 && items[ SLOT_TRINKET_2 ].options_str.empty() )
            slot = SLOT_TRINKET_2;
          else
            continue;
        }

        items[ slot ].options_str = fmt::format( ",id={},ilevel={}", equipment.id_item,
                                                 character_loadout_data_t::default_item_level( is_ptr() ) );
      }

      // TODO: temporary hack since fury only gets a single weapon
      if ( specialization() == WARRIOR_FURY && items[ SLOT_OFF_HAND ].options_str.empty() )
        items[ SLOT_OFF_HAND ].options_str = items[ SLOT_MAIN_HAND ].options_str;

    }

    // Legendary Shadoweave Shirt used as base item for enable_all_item_effects
    if ( sim->enable_all_item_effects )
    {
      items[ SLOT_SHIRT ].options_str =
          fmt::format( ",id=45037,ilevel={}", character_loadout_data_t::default_item_level( is_ptr() ) );
    }
  }
  // We need to simple-parse the items first, this will set up some base information, and parse out
  // simple options
  for ( auto& item : items )
  {
    try
    {
      // If the item has been specified in options we want to start from scratch, forgetting about
      // lingering stuff from profile copy
      if ( !item.options_str.empty() )
      {
        auto slot = item.slot;
        item      = item_t( this, item.options_str );
        item.slot = slot;
      }

      item.parse_options();

      if ( !item.initialize_data() )
      {
        throw std::invalid_argument( "Cannot initialize data." );
      }
    }
    catch ( const std::exception& )
    {
      std::throw_with_nested(
        sc_invalid_item_string( fmt::format( "Item '{}' Slot '{}'", item.name(), item.slot_name() ) ) );
    }
  }

  parse_temporary_enchants();

  // Once item data is initialized, initialize the parent - child relationships of each item
  range::for_each( items, [this]( item_t& i ) {
    i.parent_slot = parent_item_slot( i );
  } );

  // Slot initialization order vector. Needed to ensure parents of children get initialized first
  std::vector<slot_e> init_slots;
  range::for_each( items, [&init_slots]( const item_t& i ) { init_slots.push_back( i.slot ); } );

  // Sort items with children before items without children
  range::sort( init_slots, [this]( slot_e first, slot_e second ) {
    const item_t &fi = items[ first ];
    const item_t &si = items[ second ];
    if ( fi.parent_slot != SLOT_INVALID && si.parent_slot == SLOT_INVALID )
    {
      return false;
    }
    else if ( fi.parent_slot == SLOT_INVALID && si.parent_slot != SLOT_INVALID )
    {
      return true;
    }

    return false;
  } );

  for ( slot_e slot : init_slots )
  {
    item_t& item = items[ slot ];

    try
    {
      item.init();
      if ( !item.is_valid_type() )
      {
        throw std::invalid_argument( "Invalid type." );
      }
    }
    catch ( const std::exception& )
    {
      std::throw_with_nested(
        sc_invalid_item_string( fmt::format( "Item '{}' Slot '{}'", item.name(), item.slot_name() ) ) );
    }

    matching_gear_slots[ item.slot ] = item.is_matching_type();
  }

  matching_gear = true;
  for ( slot_e i = SLOT_MIN; i < SLOT_MAX; i++ )
  {
    if ( !matching_gear_slots[ i ] )
    {
      matching_gear = false;
      break;
    }
  }

  // Needs to be initialized after old set bonus system
  if ( sets != nullptr )
  {
    sets->initialize();
  }

  // these initialize the weapons, but don't have a return value (yet?)
  init_weapon( main_hand_weapon );
  init_weapon( off_hand_weapon );
}

/**
 * Initializes the Azerite-related support structures for an actor if there are any.
 *
 * Since multiple instances of the same azerite power can be worn by an actor, we need to ensure
 * that only one instance of the azerite power gets initialized. Ensure this by building a simple
 * map that keeps initialization status for all azerite powers defined for the actor from different
 * sources (currently only items). Initialization status changes automatically when an
 * azerite_power_t object is created for the actor.
 *
 * Note, guards against invocation from non-player actors (enemies, adds, pets ...)
 */
void player_t::init_azerite()
{
  if ( is_enemy() || is_pet() )
  {
    return;
  }

  sim->print_debug( "Initializing Azerite sub-system for {}.", *this );

  azerite->initialize();
}

void player_t::init_position()
{
  sim->print_debug( "Initializing position for {}.", *this );

  if ( !position_str.empty() )
  {
    base.position = util::parse_position_type( position_str );
    if ( base.position == POSITION_NONE )
    {
      throw sc_invalid_player_argument( fmt::format( "Invalid position '{}'.", position_str ) );
    }
    else
    {
      initial.position = base.position;
      change_position( base.position );
    }
  }
  // if the position string is empty and we're a tank, assume they want to be in front
  else if ( primary_role() == ROLE_TANK )
  {
    // set position to front
    base.position    = POSITION_FRONT;
    initial.position = POSITION_FRONT;
    change_position( POSITION_FRONT );
  }

  // default to back when we have an invalid position
  if ( base.position == POSITION_NONE )
    base.position = POSITION_BACK;

  position_str = util::position_type_string( base.position );

  sim->print_debug( "{} position set to {}.", *this, position_str );
}

void player_t::init_race()
{
  sim->print_debug( "Initializing race for {}.", *this );

  if ( race_str.empty() )
  {
    race_str = util::race_type_string( race );
  }
  else
  {
    race = util::parse_race_type( race_str );
    if ( race == RACE_UNKNOWN )
    {
      throw sc_invalid_player_argument( fmt::format( "Unknown race '{}'.", race_str ) );
    }
  }
}

/**
 * Initialize defensive properties (role, position, data collection, etc.)
 */
void player_t::init_defense()
{
  sim->print_debug( "Initializing defense for {}.", *this );

  if ( primary_role() == ROLE_TANK )
  {
    initial.position = POSITION_FRONT;
    sim->print_debug( "{} initial position set to front because primary_role() == ROLE_TANK", *this );
  }

  if ( !is_pet() && primary_role() == ROLE_TANK )
    collected_data.health_changes.collect = true;

}

void player_t::init_weapon( weapon_t& w )
{
  sim->print_debug( "Initializing weapon ( type {} ) for {}.", w.type, *this );

  if ( w.type == WEAPON_NONE )
    return;

  if ( w.slot == SLOT_MAIN_HAND )
    assert( w.type >= WEAPON_NONE && w.type < WEAPON_RANGED );
  if ( w.slot == SLOT_OFF_HAND )
    assert( w.type >= WEAPON_NONE && w.type < WEAPON_2H );
}

void player_t::create_special_effects()
{
  if ( is_pet() || is_enemy() )
  {
    return;
  }

  sim->print_debug( "Creating special effects for {}.", *this );

  // Initialize all item-based special effects. This includes any DBC-backed enchants, gems, as well
  // as inherent item effects that use a spell
  for ( auto& item : items )
  {
    item.init_special_effects();
  }

  // Set bonus initialization. Note that we err on the side of caution here and
  // require that the set bonus is "custom" (and as such, specified in the
  // master list of custom special effect in unique gear). This is to avoid
  // false positives with class-specific set bonuses that have to always be
  // implemented inside the class module anyhow.
  for ( const auto& set_bonus : sets->enabled_set_bonus_data() )
  {
    special_effect_t effect( this );
    unique_gear::initialize_special_effect( effect, set_bonus->spell_id );

    if ( effect.custom_init_object.empty() )
    {
      continue;
    }

    special_effects.push_back( new special_effect_t( effect ) );
  }

  if ( sim->enable_all_item_effects && type != PLAYER_SIMPLIFIED )
  {
    for ( auto id : unique_gear::midnight::__mid_special_effect_ids )
    {
      if ( unique_gear::find_special_effect( this, id ) )
        continue;

      special_effect_t effect( &items[ SLOT_SHIRT ] );
      unique_gear::initialize_special_effect( effect, id );

      special_effects.push_back( new special_effect_t( effect ) );
    }
  }

  unique_gear::initialize_racial_effects( this );

  if ( sim->overrides.skyfury && may_benefit_from_skyfury() )
  {
    special_effect_t effect( this );

    unique_gear::initialize_special_effect( effect, 462854 );
    if ( !effect.custom_init_object.empty() )
    {
      special_effects.push_back( new special_effect_t( effect ) );
    }
  }

  // Initialize generic azerite powers. Note that this occurs later in the process than the class
  // module spell initialization (init_spells()), which is where the core presumes that each class
  // module gets the state their azerite powers (through the invocation of find_azerite_spells).
  // This means that any enabled azerite power that is not referenced in a class module will be
  // initialized here.
  azerite::initialize_azerite_powers( this );

  // 12.0.7 omnium folio talents
  unique_gear::initialize_expansion_trait_effects( this, omnium_talents_str );

  // Once all special effects are first-phase initialized, do a pass to first-phase initialize any
  // potential fallback special effects for the actor.
  unique_gear::initialize_special_effect_fallbacks( this );
}

void player_t::init_special_effects()
{
  if ( is_pet() || is_enemy() )
  {
    return;
  }

  sim->print_debug( "Initializing special effects for {}.", *this );

  // ..and then move on to second phase initialization of all special effects.
  unique_gear::init( this );

  for ( auto& elem : callbacks.all_callbacks )
  {
    elem->initialize();
  }
}

void player_t::init_special_effect( special_effect_t& /* effect */ )
{
}

namespace
{
/**
 * Compute max resource r for an actor, based on their set base resources
 */
double compute_max_resource( player_t* p, resource_e r )
{
  double value = p->resources.base[ r ];
  value *= p->resources.base_multiplier[ r ];
  value += p->total_gear.resource[ r ];

  // re-ordered 2016-06-19 by Theck - initial_multiplier should do something for RESOURCE_HEALTH
  if ( r == RESOURCE_HEALTH )
    value += std::floor( p->stamina() ) * p->current.health_per_stamina;

  value *= p->resources.initial_multiplier[ r ];
  value = std::floor( value );

  return value;
}
}  // namespace

void player_t::init_resources( bool force )
{
  sim->print_debug( "Initializing resources for {}.", *this );

  for ( resource_e resource = RESOURCE_NONE; resource < RESOURCE_MAX; resource++ )
  {
    // Don't reset non-forced and already-reset initial resources
    if ( !force && resources.initial[ resource ] != 0 )
    {
      continue;
    }

    double max_resource = compute_max_resource( this, resource );

    resources.initial[ resource ] = max_resource;
    resources.max[ resource ]     = max_resource;

    if ( resources.initial_opt[ resource ] != -1.0 )
    {
      double actual_resource = std::min( max_resource, resources.initial_opt[ resource ] );

      sim->print_debug( "{} resource {} overridden to {}", *this, resource, actual_resource );

      resources.current[ resource ] = actual_resource;
    }
    else if ( !is_enemy() )
    {
      // Actual "current" resource can never exceed the computed maximum resource for the actor
      resources.current[ resource ] = std::min( max_resource, resources.start_at[ resource ] );
    }
    else
      resources.current[ resource ] = max_resource;
  }

  // Only collect pet resource timelines if they get reported separately
  if ( !is_pet() || sim->report_pets_separately )
  {
    if ( collected_data.resource_timelines.empty() )
    {
      for ( resource_e resource = RESOURCE_NONE; resource < RESOURCE_MAX; ++resource )
      {
        if ( resources.max[ resource ] > 0 )
        {
          collected_data.resource_timelines.emplace_back( resource );
        }
      }
    }
  }
}

void player_t::init_professions()
{
  if ( professions_str.empty() )
    return;

  sim->print_debug( "Initializing professions for {}.", *this );

  auto splits = util::string_split<util::string_view>( professions_str, ",/" );

  for ( auto& split : splits )
  {
    util::string_view prof_name;
    int prof_value = 0;

    auto subsplit = util::string_split<util::string_view>( split, "=" );
    if ( subsplit.size() == 2 )
    {
      prof_name = subsplit[ 0 ];
      try
      {
        prof_value = util::to_int( subsplit[ 1 ] );
      }
      catch ( const std::exception& )
      {
        std::throw_with_nested( sc_invalid_player_argument(
          fmt::format( "Invalid level '{}' for profession '{}'.", subsplit[ 1 ], prof_name ) ) );
      }
    }
    else
    {
      prof_name  = split;
      prof_value = true_level > 85 ? 600 : 525;
    }

    auto prof_type = util::parse_profession_type( prof_name );
    if ( prof_type == PROFESSION_NONE )
    {
      throw sc_invalid_player_argument( fmt::format( "Invalid profession '{}'.", prof_name ) );
    }

    profession[ prof_type ] = prof_value;
  }
}

void player_t::init_target()
{
  if ( !target_str.empty() )
  {
    target = sim->find_player( target_str );
  }
  if ( !target )
  {
    target = sim->target;
  }

  default_target = target;
}

std::vector<std::string> player_t::get_item_actions()
{
  std::vector<std::string> actions;

  for ( const auto& item : items )
  {
    // This will skip Addon and Enchant-based on-use effects. Addons especially are important to
    // skip from the default APLs since they will interfere with the potion timer, which is almost
    // always preferred over an Addon.
    if ( item.has_special_effect( SPECIAL_EFFECT_SOURCE_ITEM, SPECIAL_EFFECT_USE ) )
    {
      actions.push_back( fmt::format( "use_item,slot={}", item.slot_name() ) );
    }
  }

  return actions;
}

std::vector<std::string> player_t::get_profession_actions()
{
  std::vector<std::string> actions;

  return actions;
}

std::vector<std::string> player_t::get_racial_actions()
{
  std::vector<std::string> actions;

  actions.emplace_back( "blood_fury" );
  actions.emplace_back( "berserking" );
  actions.emplace_back( "arcane_torrent" );
  actions.emplace_back( "lights_judgment" );
  actions.emplace_back( "fireblood" );
  actions.emplace_back( "ancestral_call" );
  actions.emplace_back( "bag_of_tricks" );
  actions.emplace_back( "thorn_bloom" );

  return actions;
}

/**
 * Add action to action list.
 *
 * Helper function to add actions with spell data of the same name to the action list,
 * and check if that spell data is ok()
 * returns true if spell data is ok(), false otherwise
 */
bool player_t::add_action( util::string_view action, util::string_view opt_str, util::string_view alist )
{
  return add_action( find_class_spell( action ), opt_str, alist );
}

/**
 * Add action to action list
 *
 * Helper function to add actions to the action list if given spell data is ok()
 * returns true if spell data is ok(), false otherwise
 */
bool player_t::add_action( const spell_data_t* s, util::string_view opt_str, util::string_view alist )
{
  if ( s->ok() )
  {
    std::string& str =
        ( alist == "default" ) ? action_list_str : ( get_action_priority_list( alist )->action_list_str );
    auto name = util::tokenize_fn( s->name_cstr() );
    str += "/" + name;
    if ( !opt_str.empty() )
    {
      str += ",";
      str.append( opt_str.data(), opt_str.size() );
    }
    return true;
  }
  return false;
}

void player_t::add_option( std::unique_ptr<option_t> o )
{
  // Push_front so derived classes (eg. enemy_t) can override existing options
  options.insert( options.begin(), std::move( o ) );
}

/**
 * Adds all on use item actions for all items with their on use effect not excluded in the exclude_effects string.
 */
void player_t::activate_action_list( action_priority_list_t* a, execute_type et )
{
  if ( et == execute_type::OFF_GCD )
    active_off_gcd_list = a;
  else if ( et == execute_type::CAST_WHILE_CASTING )
    active_cast_while_casting_list = a;
  else
    active_action_list = a;
  a->used = true;
}

static void allocate_trait( player_t* player, const trait_data_t* trait, talent_tree tree, unsigned ranks )
{
  auto it = range::find_if( player->player_traits, [ trait ]( const auto& entry ) {
    return std::get<1>( entry ) == trait->id_trait_node_entry;
  } );

  auto id_entry = trait->id_trait_node_entry;

  if ( it != player->player_traits.end() )
  {
    auto entry = std::make_tuple( tree, id_entry, std::min( ranks, trait->max_ranks ) );

    if ( std::get<2>( *it ) != std::get<2>( entry ) )
    {
      player->sim->print_log( "Overwriting talent {} ({}), rank {} -> {}", trait->name, id_entry,
                              std::get<2>( *it ), std::get<2>( entry ) );
    }

    *it = entry;
  }
  else if ( ranks )
  {
    auto entry = std::make_tuple( tree, id_entry, std::min( ranks, trait->max_ranks ) );

    player->player_traits.push_back( entry );
    player->sim->print_debug( "{} adding {} talent {} (node={} entry={} rank={}/{})", *player,
                              util::talent_tree_string( tree ), trait->name, trait->id_node, trait->id_trait_node_entry,
                              ranks, trait->max_ranks );

    if ( tree == talent_tree::HERO )
    {
      player->player_sub_traits.push_back( id_entry );

      auto _ret = player->player_sub_trees.insert( trait->id_sub_tree );
      if ( _ret.second )
      {
        player->sim->print_debug( "{} activating sub tree {} ({})", *player,
                                  trait_data_t::get_hero_tree_name( trait->id_sub_tree, player->is_ptr() ),
                                  trait->id_sub_tree );
      }
    }
  }
}

// Blizzard in-game talent tree export hash
static bool generate_tree_nodes( player_t* player,
                                 std::map<unsigned, std::vector<std::pair<const trait_data_t*, unsigned>>>& tree_nodes )
{
  specialization_e spec = player->specialization();

  uint32_t class_idx, spec_idx;
  if ( !player->dbc->spec_idx( spec, class_idx, spec_idx ) )
    return false;

  for ( auto i = talent_tree::INVALID; i != talent_tree::MAX; i++ )
  {
    for ( const auto& trait : trait_data_t::data( class_idx, i, maybe_ptr( player->dbc->ptr ) ) )
      tree_nodes[ trait.id_node ].emplace_back( &trait, 0 );
  }

  // Different entries within the same node are allowed to have non-unique selection indices.
  // Manually resolve such conflicts here by re-arranging tree_nodes[ node id ] to match in-game ordering.
  // ***THIS WILL NEED TO BE CONFIRMED AND UPDATED EVERY NEW BUILD***

  player->sim->print_debug( "{}: {} tree nodes generated for spec {}.", *player, tree_nodes.size(),
                            util::specialization_string( spec ) );

  return true;
}

namespace
{
// MakeBase64ConversionTable() from Interface/AddOns/Blizzard_SharedXMLBase/ExportUtil.lua
static constexpr std::string_view base64_char = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
// hardcoded values from Interface/AddOns/Blizzard_PlayerSpells/ClassTalents/Blizzard_ClassTalentImportExport.lua
static constexpr unsigned LOADOUT_SERIALIZATION_VERSION = 2;
static constexpr size_t version_bits = 8;    // serialization version
static constexpr size_t spec_bits    = 16;   // specialization id
static constexpr size_t tree_bits    = 128;  // C_Traits.GetTreeHash(), optionally can be 0-filled
static constexpr size_t rank_bits    = 6;    // ranks purchased if node is partially filled
static constexpr size_t choice_bits  = 2;    // choice index, 0-based
// hardcoded value from Interface/AddOns/Blizzard_SharedXMLBase/ExportUtil.lua
static constexpr size_t byte_size    = 6;
}

static std::string generate_traits_hash( player_t* player )
{
  std::string export_str;
  auto ptr = player->is_ptr();

  if ( player->player_traits.empty() )
    return export_str;

  size_t head = 0;
  size_t byte = 0;
  auto put_bit = [ &export_str, &head, &byte ]( size_t bits, unsigned value ) {
    for ( size_t i = 0; i < bits; i++ )
    {
      size_t bit = head % byte_size;
      head++;
      byte += ( ( value >> std::min( i, sizeof( value ) * 8 - 1 ) ) & 0b1 ) << bit;
      if ( bit == byte_size - 1 )
      {
        export_str += base64_char[ byte ];
        byte = 0;
      }
    }
  };

  put_bit( version_bits, LOADOUT_SERIALIZATION_VERSION );
  put_bit( spec_bits, static_cast<unsigned>( player->specialization() ) );
  put_bit( tree_bits, 0 );  // 0-filled to bypass validation, as GetTreeHash() is unavailable externally

  std::map<unsigned, std::vector<std::pair<const trait_data_t*, unsigned>>> tree_nodes;

  generate_tree_nodes( player, tree_nodes );

  // populate tree_nodes with rank info from player_traits
  for ( const auto& trait : player->player_traits )
  {
    auto id_entry = std::get<1>( trait );
    auto ranks = std::get<2>( trait );

    if ( !ranks )
      continue;

    auto trait_data = trait_data_t::find( id_entry, ptr );
    auto tree_entry = &tree_nodes[ trait_data->id_node ];

    for ( auto& entry : *tree_entry )
    {
      if ( entry.first->id_trait_node_entry == id_entry )
      {
        entry.second = ranks;
        break;
      }
    }
  }

  for ( auto& [ id, node ] : tree_nodes )
  {
    unsigned rank = 0;
    unsigned max_rank = 0;
    unsigned init_rank = 0;
    unsigned index = 0;
    bool is_choice = node.size() > 0
                       ? node[ 0 ].first->node_type == NODE_CHOICE || node[ 0 ].first->node_type == NODE_SELECTION
                       : false;

    for ( size_t i = 0; i < node.size(); i++ )
    {
      auto _entry_trait = node[ i ].first;
      auto _entry_rank = node[ i ].second;

      // tiered nodes add up ranks of all entries
      if ( _entry_trait->node_type == NODE_TIERED )
      {
        rank += _entry_rank;
        max_rank += _entry_trait->max_ranks;
      }
      else if ( _entry_rank )
      {
        rank = _entry_rank;
        max_rank = _entry_trait->max_ranks;
        init_rank = trait_data_t::is_granted( _entry_trait, player->specialization() ) ? 1U : 0U;
        index = as<unsigned>( i );
        break;
      }
    }

    if ( rank )  // is node selected?
    {
      put_bit( 1, 1 );
    }
    else
    {
      put_bit( 1, 0 );
      continue;
    }

    // is node purchased? granted nodes are baseline 1 rank.
    if ( rank > init_rank )
    {
      put_bit( 1, 1 );
    }
    else
    {
      put_bit( 1, 0 );
      continue;
    }

    if ( rank == max_rank )  // is node partially ranked?
    {
      put_bit( 1, 0 );
    }
    else
    {
      put_bit( 1, 1 );
      put_bit( rank_bits, rank );
    }

    if ( is_choice )  // is choice node?
    {
      put_bit( 1, 1 );
      put_bit( choice_bits, index );
    }
    else
    {
      put_bit( 1, 0 );
    }
  }

  if ( head % byte_size )
    export_str += base64_char[ byte ];

  return export_str;
}

static void parse_traits_hash( const std::string& talents_str, player_t* player )
{
  auto do_error = []( std::string_view msg ) {
    throw std::invalid_argument( fmt::format( "{}", msg ) );
  };

  if ( auto _z = talents_str.find_first_not_of( base64_char ); _z != std::string::npos )
  {
    do_error( fmt::format( "Invalid character '{}' found.", talents_str.at( _z ) ) );
    return;
  }

  if ( version_bits + spec_bits + tree_bits > talents_str.size() * byte_size )
  {
    do_error( "Not enough characters." );
    return;
  }

  size_t head = 0;
  size_t byte = base64_char.find( talents_str[ 0 ] );
  auto get_bit = [ &talents_str, &head, &byte ]( size_t bits ) {
    size_t val = 0;
    for ( size_t i = 0; i < bits; i++ )
    {
      size_t bit = head % byte_size;
      head++;
      val += ( byte >> bit & 0b1 ) << std::min( i, sizeof( byte ) * 8 - 1 );
      if ( bit == byte_size - 1 )
      {
        if ( ( head / byte_size ) >= talents_str.size() )
          byte = 0;
        else
          byte = base64_char.find( talents_str[ head / byte_size ] );
      }
    }
    return val;
  };

  auto version_id = get_bit( version_bits );
  auto spec_id    = get_bit( spec_bits );

  if ( version_id != LOADOUT_SERIALIZATION_VERSION )
  {
    do_error( "Invalid serialization version." );
    return;
  }

  if ( spec_id != player->specialization() )
  {
    do_error( "Wrong specialization." );
    return;
  }

  // Clear all existing traits
  player->player_traits.clear();
  player->player_sub_trees.clear();
  player->player_sub_traits.clear();

  // As per Interface/AddOns/Blizzard_PlayerSpells/ClassTalents/Blizzard_ClassTalentImportExport.lua: treeHash is a
  // 128bit hash, passed as an array of 16, 8-bit values. For SimC purposes we can ignore it, as invalid/outdated
  // strings can error in later checks
  get_bit( tree_bits );

  std::map<unsigned, std::vector<std::pair<const trait_data_t*, unsigned>>> tree_nodes;

  generate_tree_nodes( player, tree_nodes );

  for ( auto& [ id, node ] : tree_nodes )
  {
    if ( get_bit( 1 ) )  // selected
    {
      auto trait = node.front().first;
      auto max_rank = trait->node_type == NODE_TIERED
                        ? range::accumulate( node, 0U, []( const auto& n ) { return n.first->max_ranks; } )
                        : trait->max_ranks;
      size_t rank = max_rank;
      auto _tree = static_cast<talent_tree>( trait->tree_index );
      bool throwaway = false;  // read bits but don't add to player_traits

      // hero talents and selection talents don't seem to require a matching id_spec_set
      // TODO: utilize logic in trait_data_t::is_granted() to check against id_spec_set of the subtree selection trait
      if ( _tree != talent_tree::HERO &&
           !std::all_of( trait->id_spec.begin(), trait->id_spec.end(), []( unsigned i ) { return i == 0; } ) &&
           !range::contains( trait->id_spec, player->specialization() ) )
      {
        if ( _tree == talent_tree::SELECTION )
        {
          throwaway = true;
          do_error( fmt::format( "Hero tree selection node {} entry {} is not for the player's spec, ignoring.", id,
                                 trait->id_trait_node_entry ) );
        }
        else
        {
          do_error( fmt::format( "Selected node {} entry {} is not available to player's spec.", id,
                                 trait->id_trait_node_entry ) );
          return;
        }
      }

      if ( !get_bit( 1 ) )  // purchased
      {
        rank = 1;  // non-purchased nodes are granted at rank 1
      }
      else
      {
        if ( get_bit( 1 ) )  // partially ranked normal trait
        {
          if ( trait->node_type != NODE_TIERED && node.size() > 1 )
          {
            do_error( fmt::format( "Non-choice node {} has multiple entries.", id ) );
            return;
          }

          rank = get_bit( rank_bits );

          if ( rank > max_rank )
          {
            do_error( fmt::format( "{} ranks selected for node {}, {} ranks max.", rank, id, max_rank ) );
            return;
          }

          if ( rank == max_rank )
          {
            do_error( fmt::format( "Partial rank for node {} but all {} ranks are allocated.", id, rank ) );
            return;
          }
        }

        if ( get_bit( 1 ) )  // choice trait
        {
          if ( node[ 0 ].first->node_type != NODE_CHOICE && node[ 0 ].first->node_type != NODE_SELECTION )
          {
            do_error( fmt::format( "Node {} is not a choice node but has index selection.", id ) );
            return;
          }

          size_t index = get_bit( choice_bits );
          if ( index >= node.size() )
          {
            do_error( fmt::format( "Index {} for choice node {} out of bounds.", index, id ) );
            return;
          }

          trait = node[ index ].first;
        }
      }

      if ( throwaway )
        continue;

      if ( trait->node_type == NODE_TIERED )
      {
        for ( const auto& n : node )
        {
          auto allocated = std::min( as<unsigned>( rank ), n.first->max_ranks );
          player->player_traits.emplace_back( _tree, n.first->id_trait_node_entry, allocated );

          rank -= allocated;
          if ( !rank )
            break;
        }
      }
      else
      {
        player->player_traits.emplace_back( _tree, trait->id_trait_node_entry, as<unsigned>( rank ) );
      }

      if ( _tree == talent_tree::SELECTION )
      {
        player->player_sub_trees.insert( trait->id_sub_tree );

        player->sim->print_debug( "{} activating sub tree {} (id={})", *player,
                                  trait_data_t::get_hero_tree_name( trait->id_sub_tree, player->is_ptr() ),
                                  trait->id_sub_tree );
      }

      player->sim->print_debug( "{} adding {} talent {} (node={} entry={} rank={}/{})", *player,
                                util::talent_tree_string( _tree ), trait->name, trait->id_node,
                                trait->id_trait_node_entry, rank, trait->max_ranks );
    }
  }
}

static void enable_all_talents( player_t* player, std::function<bool( const trait_data_t* )> fn = nullptr )
{
  std::map<unsigned, std::vector<std::pair<const trait_data_t*, unsigned>>> tree_nodes;

  generate_tree_nodes( player, tree_nodes );

  for ( auto& [ id, node ] : tree_nodes )
  {
    for ( auto& entry : node )
    {
      auto trait = entry.first;

      // assume 'off-screen' nodes are invalid
      if ( trait->row <= 0 || trait->col <= 0 || trait->max_ranks <= 0 )
        continue;

      if ( fn && !fn( trait ) )
        continue;

      if ( std::all_of( trait->id_spec.begin(), trait->id_spec.end(), []( unsigned i ) { return i == 0; } ) ||
           range::contains( trait->id_spec, player->specialization() ) ||
           trait_data_t::is_hero_trait_available( trait, player->type, player->specialization(), player->is_ptr() ) )
      {
        auto _tree = static_cast<talent_tree>( trait->tree_index );

        player->player_traits.emplace_back( _tree, trait->id_trait_node_entry, trait->max_ranks );

        if ( _tree == talent_tree::SELECTION )
        {
          player->player_sub_trees.insert( trait->id_sub_tree );
          player->sim->print_debug( "{} activating sub tree {} ({})", *player,
                                    trait_data_t::get_hero_tree_name( trait->id_sub_tree, player->is_ptr() ),
                                    trait->id_sub_tree );
        }
        else
        {
          player->sim->print_debug( "{} adding {} talent {} (node={} entry={} rank={}/{})", *player,
                                    util::talent_tree_string( _tree ), trait->name, trait->id_node,
                                    trait->id_trait_node_entry, trait->max_ranks, trait->max_ranks );
        }
      }
    }
  }
}

static void enable_default_talents( player_t* player, std::function<bool( const trait_data_t* )> fn = nullptr )
{
  player->sim->print_debug( "Loading default talents for {}.", *player );

  auto traits = trait_loadout_data_t::data( player->specialization(), player->is_ptr() );

  for ( size_t i = 0; i < traits.size(); i++ )
  {
    while ( ( i + 1 ) < traits.size() && traits[ i ].id_trait_node_entry == traits[ i + 1 ].id_trait_node_entry )
      i++;

    auto trait = trait_data_t::find( traits[ i ].id_trait_node_entry, player->is_ptr() );

    if ( fn && !fn( trait ) )
      continue;

    if ( !trait->id_node )
    {
      player->sim->error( "{} default talent not found: id_trait_node_entry={} order={}", *player,
                          traits[ i ].id_trait_node_entry, traits[ i ].order );
    }
    else
    {
      auto tree = static_cast<talent_tree>( trait->tree_index );
      auto ranks = traits[ i ].rank;

      player->player_traits.emplace_back( tree, traits[ i ].id_trait_node_entry, ranks );
      player->sim->print_debug( "{} adding {} talent {} (node={} entry={} rank={}/{})", *player,
                                util::talent_tree_string( tree ), trait->name, trait->id_node,
                                trait->id_trait_node_entry, ranks, trait->max_ranks );
    }
  }
}

static void enable_hero_tree( player_t* player, unsigned hero_tree_id )
{
  player->sim->print_debug( "Loading all {} hero tree talents for {}.",
                            trait_data_t::get_hero_tree_name( hero_tree_id ), *player );

  auto traits = trait_data_t::data( util::class_id( player->type ), talent_tree::SELECTION, player->is_ptr() );
  for ( const auto& trait : traits )
  {
    if ( trait.id_sub_tree == hero_tree_id && range::contains( trait.id_spec, player->specialization() ) )
    {
      player->player_traits.emplace_back( talent_tree::SELECTION, trait.id_trait_node_entry, trait.max_ranks );
      player->player_sub_trees.insert( hero_tree_id );
      player->sim->print_debug( "{} activating sub tree {} ({})", *player,
                                trait_data_t::get_hero_tree_name( hero_tree_id, player->is_ptr() ), hero_tree_id );
    }
  }

  traits = trait_data_t::data( util::class_id( player->type ), talent_tree::HERO, player->is_ptr() );
  for ( const auto& trait : traits )
  {
    // assume 'off-screen' nodes are invalid
    if ( trait.row <= 0 || trait.col <= 0 || trait.max_ranks <= 0 )
      continue;

    player->player_traits.emplace_back( talent_tree::HERO, trait.id_trait_node_entry, trait.max_ranks );
    player->sim->print_debug( "{} adding hero talent {}", *player, trait.name );
  }
}

static void parse_traits( talent_tree tree, const std::string& opt_str, player_t* player )
{
  auto talents = util::string_split<std::string_view>( opt_str, "/" );
  for ( const auto talent : talents )
  {
    // handle special tokens
    if ( util::str_compare_ci( talent, "all" ) )
    {
      enable_all_talents( player, [ tree ]( const trait_data_t* t ) {
        return static_cast<talent_tree>( t->tree_index ) == tree;
      } );

      continue;
    }
    else if ( util::str_compare_ci( talent, "default" ) )
    {
      enable_default_talents( player, [ tree ]( const trait_data_t* t ) {
        return static_cast<talent_tree>( t->tree_index ) == tree;
      } );

      continue;
    }

    auto talent_split = util::string_split<std::string_view>( talent, ":" );
    if ( talent_split.size() != 2 )
    {
      throw std::invalid_argument( fmt::format( "'{}' is invalid, format must be '<talent>:<rank>'.", talent ) );
    }

    bool is_spell_id = false;
    auto entry_id = 0U;
    if ( !talent_split[ 0 ].empty() && ( talent_split[ 0 ][ 0 ] == 's' || talent_split[ 0 ][ 0 ] == 'S' ) )
    {
      entry_id = util::to_unsigned_ignore_error( talent_split[ 0 ].substr( 1 ), 0 );
      is_spell_id = true;
    }
    else
    {
      entry_id = util::to_unsigned_ignore_error( talent_split[ 0 ], 0 );
    }

    auto ranks = util::to_unsigned( talent_split[ 1 ] );
    const trait_data_t* trait_obj = nullptr;
    if ( entry_id != 0 )
    {
      if ( is_spell_id )
      {
        auto objs = trait_data_t::find_by_spell( tree, entry_id, util::class_id( player->type ),
                                                 player->specialization(), player->is_ptr() );
        if ( objs.empty() )
        {
          trait_obj = &( trait_data_t::nil() );
        }
        else if ( objs.size() > 1U )
        {
          throw std::invalid_argument(
            fmt::format( "Multiple talents for spell id '{}' found.", talent_split[ 0 ].substr( 1 ) ) );
        }
        else
        {
          trait_obj = objs[ 0 ];
        }
      }
      else
      {
        trait_obj = trait_data_t::find( entry_id, player->is_ptr() );
      }
    }
    else
    {
      trait_obj = trait_data_t::find( tree, talent_split[ 0 ], util::class_id( player->type ), player->specialization(),
                                      player->is_ptr(), true );
    }

    if ( trait_obj->id_spell == 0 )
    {
      throw std::invalid_argument(
        fmt::format( "Unable to find {} talent '{}'.", util::talent_tree_string( tree ), talent_split[ 0 ] ) );
    }
    else
    {
      if ( !entry_id && trait_obj->node_type == NODE_TIERED )
      {
        auto _entries = trait_data_t::data( trait_obj->id_node, util::class_id( player->type ), tree, player->is_ptr() );
        for ( const auto& trait : _entries )
        {
          auto allocated = !ranks ? ranks : std::min( ranks, trait.max_ranks );
          allocate_trait( player, &trait, tree, allocated );

          ranks -= allocated;
        }
      }
      else
      {
        allocate_trait( player, trait_obj, tree, ranks );
      }
    }
  }

  // add any freely granted traits
  for ( const auto& trait : trait_data_t::data( util::class_id( player->type ), tree, player->is_ptr() ) )
  {
    if ( trait_data_t::is_granted( &trait, player->specialization() ) )
    {
      auto id = trait.id_trait_node_entry;
      auto it = range::find_if( player->player_traits, [ id ]( const auto& e ) { return std::get<1>( e ) == id; } );
      if ( it == player->player_traits.end() )
      {
        player->player_traits.emplace_back( tree, id, 1 );

        player->sim->print_debug( "{} granted free {} talent {} (node={} entry={})", *player,
                                  util::talent_tree_string( tree ), trait.name, trait.id_node,
                                  trait.id_trait_node_entry );
      }
    }
  }
}

void player_t::init_talents()
{
  sim->print_debug( "Initializing talents for {}.", *this );

  if ( !is_player() )
  {
    sim->print_debug( "Not a player, halting further talent initialization." );
    return;
  }

  if ( sim->enable_all_talents )
  {
    enable_all_talents( this );
  }
  else if ( load_default_talents )
  {
    enable_default_talents( this );
  }
  else if ( !talents_str.empty() )
  {
    // check for special tokens, clear talents_str if found to force reconstitution of hash for html talent render
    auto splits = util::string_split( talents_str, "/" );

    for ( auto split : splits )
    {
      if ( util::str_compare_ci( split, "class" ) )
      {
        talents_str.clear();
        enable_all_talents( this, []( const trait_data_t* t ) {
          return static_cast<talent_tree>( t->tree_index ) == talent_tree::CLASS;
        } );
      }
      else if ( util::str_compare_ci( split, "spec" ) )
      {
        talents_str.clear();
        enable_all_talents( this, []( const trait_data_t* t ) {
          return static_cast<talent_tree>( t->tree_index ) == talent_tree::SPECIALIZATION;
        } );
      }
      else if ( auto _id = trait_data_t::get_hero_tree_id( split, is_ptr() );
                trait_data_t::is_hero_tree_valid( static_cast<hero_tree_e>( _id ), specialization(), is_ptr() ) )
      {
        talents_str.clear();
        enable_hero_tree( this, _id );
      }
      else
      {
        // if no special tokens are found, parse as hash string
        try
        {
          parse_traits_hash( talents_str, this );
        }
        catch ( const std::exception& )
        {
          std::throw_with_nested( sc_invalid_talent_string( fmt::format( "Hash '{}'", talents_str ) ) );
        }
      }
    }
  }

  auto parsed_sub_trees = player_sub_trees;

  // parse_traits MUST BE CALLED for all talent trees to ensure that freely granted traits are properly processed, as
  // the trait hash may not always encode this information
  try
  {
    parse_traits( talent_tree::CLASS, class_talents_str, this );
  }
  catch ( const std::exception& )
  {
    std::throw_with_nested( sc_invalid_talent_string( "Invalid 'class_talents'" ) );
  }

  try
  {
    parse_traits( talent_tree::SPECIALIZATION, spec_talents_str, this );
  }
  catch ( const std::exception& )
  {
    std::throw_with_nested( sc_invalid_talent_string( "Invalid 'spec_talents'" ) );
  }

  if ( !hero_talents_str.empty() )
  {
    try
    {
      // enable all hero tree, tokenized name
      if ( auto hero_tree_id = trait_data_t::get_hero_tree_id( hero_talents_str, is_ptr() );
           trait_data_t::is_hero_tree_valid( static_cast<hero_tree_e>( hero_tree_id ), specialization(), is_ptr() ) )
      {
        enable_hero_tree( this, hero_tree_id );
      }
      // enable all hero tree, index (1 or 2)
      else if ( util::is_number( hero_talents_str ) )
      {
        auto _id = util::to_unsigned( hero_talents_str );
        auto hero_trees = trait_data_t::get_valid_hero_tree_ids( specialization(), is_ptr() );

        if ( _id > hero_trees.size() )
        {
          throw std::invalid_argument(
            fmt::format( "Invalid hero tree index '{}', {} has {} hero trees.", _id, *this, hero_trees.size() ) );
        }

        auto hero_id = trait_data_t::get_valid_hero_tree_ids( specialization(), is_ptr() ).at( _id - 1 );
        enable_hero_tree( this, hero_id );
      }
      // standard talent:rank/ format
      else
      {
        parse_traits( talent_tree::HERO, hero_talents_str, this );
      }
    }
    catch ( const std::exception& )
    {
      std::throw_with_nested( sc_invalid_talent_string( "Invalid 'hero_talents'" ) );
    }
  }
  else
  {
    // call with empty string to add freely granted traits
    parse_traits( talent_tree::HERO, hero_talents_str, this );
  }

  // Add selection traits for any manually added hero traits from new trees
  if ( player_sub_trees.size() > parsed_sub_trees.size() )
  {
    std::vector<unsigned> diff;
    std::set_difference( player_sub_trees.begin(), player_sub_trees.end(),
                        parsed_sub_trees.begin(), parsed_sub_trees.end(), std::back_inserter( diff ) );

    for ( const auto& trait : trait_data_t::data( util::class_id( type ), talent_tree::SELECTION, is_ptr() ) )
      if ( range::contains( trait.id_spec, specialization() ) && range::contains( diff, trait.id_sub_tree ) )
        player_traits.emplace_back( talent_tree::SELECTION, trait.id_trait_node_entry, 1 );
  }

  if ( talents_str.empty() || !class_talents_str.empty() || !spec_talents_str.empty() || !hero_talents_str.empty() )
  {
    talents_str = generate_traits_hash( this );
  }

  // Generate talent effect overrides based on parsed trait information
  for ( const auto& player_trait : player_traits )
  {
    auto trait_node_entry_id = std::get<1>( player_trait );
    auto rank = std::get<2>( player_trait );
    if ( rank == 0U )
    {
      continue;
    }

    const auto trait = trait_data_t::find( trait_node_entry_id, is_ptr() );
    assert( trait );
    const auto effect_points = trait_definition_effect_entry_t::find( trait->id_trait_definition, is_ptr() );
    auto spell = dbc::find_spell( this, trait->id_spell );

    if ( spell->id() != trait->id_spell )
    {
      sim->print_debug( "{} talent {} (spell_id={}, trait_node_entry_id={}) rank {} "
                        "trait spell not found",
        name(), trait->name, spell->id(), trait->id_trait_node_entry, rank );
      continue;
    }

    for ( const auto& effect_point : effect_points )
    {
      auto eff_idx = effect_point.effect_index + 1U;
      // Skip if more effect point entries exist than there are effects
      if ( spell->effect_count() < eff_idx )
        continue;

      auto effect_id = spell->effectN( eff_idx ).id();
      // Don't adjust already overridden effects, as those are defined by player options from the
      // command line (i.e., using override.spell_data or override.player.spell_data options).
      if ( dbc_override_->is_overridden_effect( *dbc, effect_id, "base_value" ) )
      {
          sim->print_debug( "{} talent {} (spell_id={}, trait_node_entry_id={}) rank {} "
                            "effect id {} (index={}) manually overridden, ignoring",
            name(), trait->name, spell->id(), trait->id_trait_node_entry, rank, effect_id,
            effect_point.effect_index + 1U );
        continue;
      }

      if ( effect_point.effect_index + 1U > spell->effect_count() )
      {
        sim->print_debug( "{} talent {} (spell_id={}, trait_node_entry_id={}) rank {} "
                          "effect id {} (index={}) effect index out of bounds, max effects {}",
          name(), trait->name, spell->id(), trait->id_trait_node_entry, rank, effect_id,
          effect_point.effect_index + 1U , spell->effect_count() );
        continue;
      }

      auto curve_data = curve_point_t::find( effect_point.id_curve, is_ptr() );
      auto value = 0.0f;
      auto it = range::find_if( curve_data, [rank]( const auto& point ) {
        return point.primary1 == as<float>( rank );
      } );

      if ( it == curve_data.end() )
      {
        sim->print_debug( "{} talent {} (spell_id={}, trait_node_entry_id={}) rank {} "
                          "effect id {} (index={}) curve data for rank not found for curve {}",
          name(), trait->name, spell->id(), trait->id_trait_node_entry, rank, effect_id,
          effect_point.effect_index + 1U, effect_point.id_curve );
        continue;
      }

      value = it->primary2;

      switch ( effect_point.operation )
      {
        case TRAIT_OP_NONE:
          sim->print_debug( "{} not affecting talent {} (spell_id={}, trait_node_entry_id={}) rank {} "
                            "effect id {} (index={}), effect={}, curve={}",
            name(), trait->name, spell->id(), trait->id_trait_node_entry, rank, effect_id,
            effect_point.effect_index + 1U,
            spell->effectN( effect_point.effect_index + 1U ).base_value(), value );
            break;
        case TRAIT_OP_SET:
          sim->print_debug( "{} setting talent {} (spell_id={}, trait_node_entry_id={}) rank {} "
                            "effect id {} (index={}) value, old={}, new={}",
            name(), trait->name, spell->id(), trait->id_trait_node_entry, rank, effect_id,
            effect_point.effect_index + 1U,
            spell->effectN( effect_point.effect_index + 1U ).base_value(), value );
          dbc_override_->register_effect( *dbc, effect_id, "base_value", value );
          break;
        case TRAIT_OP_MUL:
          sim->print_debug( "{} multiplying talent {} (spell_id={}, trait_node_entry_id={}) rank {} "
                            "effect id {} (index={}) value, multiplier={}, old={}, new={}",
            name(), trait->name, spell->id(), trait->id_trait_node_entry, rank, effect_id,
            effect_point.effect_index + 1U, value,
            spell->effectN( effect_point.effect_index + 1U ).base_value(),
            spell->effectN( effect_point.effect_index + 1U ).base_value() * value );
          dbc_override_->register_effect( *dbc, effect_id, "base_value",
              spell->effectN( effect_point.effect_index + 1U ).base_value() * value );
          break;
        default:
          assert( 0 );
      }
    }
  }
}

void player_t::init_spells()
{
  sim->print_debug( "Initializing spells for {}.", *this );

  // Racials
  racials.might_of_the_mountain = find_racial_spell( "Might of the Mountain" );
  racials.brawn                 = find_racial_spell( "Brawn" );

  if ( is_player() )
  {
    spec_spell = find_spell( util::specialization_string( specialization() ) );

    const spell_data_t* s = find_mastery_spell( specialization() );
    if ( s->ok() )
      _mastery = &( s->effectN( 1 ) );

    if ( sim->dbc->wowv() >= wowv_t{ 11, 1, 7 } )
      single_button_assistant = find_specialization_spell( "Single-Button Assistant" );
  }
}

void player_t::init_gains()
{
  sim->print_debug( "Initializing gains for {}.", *this );

  for ( resource_e r = RESOURCE_NONE; r < RESOURCE_MAX; ++r )
  {
    std::string name = util::resource_type_string( r );
    name += "_regen";
    gains.resource_regen[ r ] = get_gain( util::inverse_tokenize( name ) );
  }

  if ( !is_pet() )
    gains.health = get_gain( "external_healing" );
}

void player_t::init_procs()
{
  sim->print_debug( "Initializing procs for {}.", *this );

  procs.parry_haste = get_proc( "parry_haste" );
  procs.delayed_aa_cast = get_proc( "delayed_aa_cast" );
  procs.delayed_aa_channel = get_proc( "delayed_aa_channel" );
  procs.reset_aa_cast = get_proc( "reset_aa_cast" );
  procs.reset_aa_channel = get_proc( "reset_aa_channel" );
}

void player_t::init_uptimes()
{
  sim->print_debug( "Initializing uptimes for {}.", *this );

  if ( primary_resource() )
  {
    uptimes.primary_resource_cap =
      get_uptime( util::inverse_tokenize( util::resource_type_string( primary_resource() ) ) + " Cap" );
  }
}

void player_t::init_benefits()
{
  sim->print_debug( "Initializing benefits for {}.", *this );
}

void player_t::init_rng()
{
  sim->print_debug( "Initializing random number generators for {}.", *this );
}

void player_t::init_stat_data()
{
  sim->print_debug( "Initializing stat data for {}.", *this );

  if ( sim->maximize_reporting )
  {
    for ( stat_e s = STAT_NONE; s < STAT_MAX; ++s )
    {
      stat_timelines.push_back( s );
    }
  }
  if ( !is_pet() || sim->report_pets_separately )
  {
    if ( collected_data.stat_timelines.empty() )
    {
      for ( stat_e stat : stat_timelines )
      {
        collected_data.stat_timelines.emplace_back( stat );
      }
    }
  }

  collected_data.reserve_memory( *this );
}

/**
 * Define absorb priority.
 *
 * Absorbs with the high priority flag will follow the order in absorb_priority vector when resolving.
 * This method should be overwritten in class modules to declare the order of spec-specific high priority absorbs.
 */
void player_t::init_absorb_priority()
{
}

void player_t::init_scaling()
{
  sim->print_debug( "Initializing scaling for {}.", *this );

  if ( !is_pet() && !is_enemy() )
  {
    invert_scaling = 0;

    bool attack = false, spell = false, tank = false, heal = false;

    switch ( primary_role() )
    {
      case ROLE_ATTACK: attack = true;               break;
      case ROLE_SPELL:  spell = true;                break;
      case ROLE_HYBRID:
      case ROLE_DPS:    attack = true; spell = true; break;
      case ROLE_TANK:   attack = true; tank = true;  break;
      case ROLE_HEAL:   spell = true;  heal = true;  break;
      default:          break;
    }

    scaling->set( STAT_STRENGTH, attack );
    scaling->set( STAT_AGILITY, attack );
    scaling->set( STAT_STAMINA, tank );
    scaling->set( STAT_INTELLECT, spell );
    scaling->set( STAT_SPIRIT, heal );

    scaling->set( STAT_SPELL_POWER, spell );
    scaling->set( STAT_ATTACK_POWER, attack );
    scaling->enable( STAT_CRIT_RATING );
    scaling->enable( STAT_HASTE_RATING );
    scaling->enable( STAT_MASTERY_RATING );
    scaling->enable( STAT_VERSATILITY_RATING );

    // scaling->enable( STAT_SPEED_RATING );  // handled in raid_events movement_event_t
    // scaling->set( STAT_AVOIDANCE_RATING, tank ); // can be enabled manually if need be
    scaling->set( STAT_LEECH_RATING, heal );

    scaling->set( STAT_WEAPON_DPS, attack );
    scaling->set( STAT_ARMOR, tank );

    auto add_stat = []( double& to, double value, double lower_limit )
      {
      if ( to + value < lower_limit )
        to = lower_limit;
      else
        to += value;
      };

    if ( sim->scaling->scale_stat != STAT_NONE && scale_player )
    {
      double v = sim->scaling->scale_value;

      switch ( sim->scaling->scale_stat )
      {
        case STAT_STRENGTH:
          add_stat( initial.stats.attribute[ ATTR_STRENGTH ], v, 0 );
          break;
        case STAT_AGILITY:
          add_stat( initial.stats.attribute[ ATTR_AGILITY ], v, 0 );
          break;
        case STAT_STAMINA:
          add_stat( initial.stats.attribute[ ATTR_STAMINA ], v, 0 );
          break;
        case STAT_INTELLECT:
          add_stat( initial.stats.attribute[ ATTR_INTELLECT ], v, 0 );
          break;
        case STAT_SPIRIT:
          add_stat( initial.stats.attribute[ ATTR_SPIRIT ], v, 0 );
          break;

        case STAT_SPELL_POWER:
          add_stat( initial.stats.spell_power, v, 0 );
          break;

        case STAT_ATTACK_POWER:
          add_stat( initial.stats.attack_power, v, 0 );
          break;

        case STAT_CRIT_RATING:
          add_stat( initial.stats.crit_rating, v, 0 );
          break;

        case STAT_HASTE_RATING:
          add_stat( initial.stats.haste_rating, v, 0 );
          break;

        case STAT_MASTERY_RATING:
          add_stat( initial.stats.mastery_rating, v, 0 );
          break;

        case STAT_VERSATILITY_RATING:
          add_stat( initial.stats.versatility_rating, v, 0 );
          break;

        case STAT_DODGE_RATING:
          add_stat( initial.stats.dodge_rating, v, 0 );
          break;

        case STAT_PARRY_RATING:
          add_stat( initial.stats.parry_rating, v, 0 );
          break;

        case STAT_SPEED_RATING:
          add_stat( initial.stats.speed_rating, v, 0 );
          break;

        case STAT_AVOIDANCE_RATING:
          add_stat( initial.stats.avoidance_rating, v, 0 );
          break;

        case STAT_LEECH_RATING:
          add_stat( initial.stats.leech_rating, v, 0 );
          break;

        case STAT_WEAPON_DPS:
          if ( main_hand_weapon.damage > 0 )
          {
            add_stat( main_hand_weapon.damage, main_hand_weapon.swing_time.total_seconds() * v, 1 );
            add_stat( main_hand_weapon.dps, v, 1 );
            add_stat( main_hand_weapon.min_dmg, main_hand_weapon.swing_time.total_seconds() * v, 1 );
            add_stat( main_hand_weapon.max_dmg, main_hand_weapon.swing_time.total_seconds() * v, 1 );
          }
          break;

        case STAT_WEAPON_OFFHAND_DPS:
          if ( off_hand_weapon.damage > 0 )
          {
            add_stat( off_hand_weapon.damage, off_hand_weapon.swing_time.total_seconds() * v, 1 );
            add_stat( off_hand_weapon.dps, v, 1 );
            add_stat( off_hand_weapon.min_dmg, off_hand_weapon.swing_time.total_seconds() * v, 1 );
            add_stat( off_hand_weapon.max_dmg, off_hand_weapon.swing_time.total_seconds() * v, 1 );
          }
          break;

        case STAT_ARMOR:
          add_stat( initial.stats.armor, v, 0 );
          break;

        case STAT_BONUS_ARMOR:
          add_stat( initial.stats.bonus_armor, v, 0 );
          break;

        case STAT_BLOCK_RATING:
          add_stat( initial.stats.block_rating, v, 0 );
          break;

        case STAT_MAX:
          break;

        default:
          assert( false );
          break;
      }
    }
  }
}

void player_t::init_blizzard_action_list()
{
  action_priority_list_t* precombat = get_action_priority_list( "precombat" );
  action_priority_list_t* default_  = get_action_priority_list( "default" );
  action_priority_list_t* cooldowns = get_action_priority_list( "cooldowns",
                                                                "Some cooldowns are not used by the Assisted Combat system. "
                                                                "This simple default cooldown usage has been provided by simc." );
  action_priority_list_t* assisted_combat = get_action_priority_list( "assisted_combat",
                                                                      "This is the default action priority list from the game's Assisted Combat system." );

  precombat->add_action( "snapshot_stats" );

  if ( use_cds_with_blizzard_action_list )
    default_->add_action( "call_action_list,name=cooldowns" );

  default_->add_action( "call_action_list,name=assisted_combat" );

  cooldowns->add_action( "use_items" );
  cooldowns->add_action( "potion" );
  cooldowns->add_action( "blood_fury" );
  cooldowns->add_action( "berserking" );
  cooldowns->add_action( "fireblood" );
  cooldowns->add_action( "ancestral_call" );

  try
  {
    for ( const auto& step : assisted_combat_step_data_t::data( specialization(), is_ptr() ) )
      parse_assisted_combat_step( step, assisted_combat );
  }
  catch ( const std::exception& )
  {
    std::throw_with_nested( sc_initialization_error( "Assisted combat parse error" ) );
  }
}

std::vector<std::string> player_t::action_names_from_spell_id( unsigned int spell_id ) const
{
  std::vector<std::string> names;
  const spell_data_t* spell = find_spell( spell_id );

  if ( spell && !spell->flags( SX_PASSIVE ) )
    names.push_back( util::tokenize_fn( spell->name_cstr() ) );

  return names;
}

std::string player_t::aura_expr_from_spell_id( unsigned int spell_id, bool on_self ) const
{
  const spell_data_t* spell = find_spell( spell_id );
  std::string aura_name = util::tokenize_fn( spell->name_cstr() );
  if ( aura_name.empty() )
    aura_name = fmt::format( "unknown_spell_{}", spell_id );

  if ( on_self )
  {
    if ( spell->flags( SX_PASSIVE ) )
    {
      // check if this is a talent
      for ( const auto& tree : { talent_tree::CLASS, talent_tree::SPECIALIZATION, talent_tree::HERO } )
      {
        const auto& traits = trait_data_t::find_by_spell( tree, spell_id, util::class_id( type ), specialization(), is_ptr() );
        if ( traits.size() > 0 )
          return "talent." + aura_name;
      }
    }

    // use an existing buff with the spell id if available
    for ( const buff_t* buff : buff_list )
    {
      if ( buff->data().id() == spell_id )
        return "buff." + buff->name_str;
    }

    return "buff." + aura_name;
  }

  for ( const auto& e : spell->effects() )
  {
    for ( auto a : { A_PERIODIC_DAMAGE, A_PERIODIC_LEECH } )
    {
      if ( a == e.subtype() )
        return "dot." + aura_name;
    }
  }

  return "debuff." + aura_name;
}

void player_t::parse_assisted_combat_step( const assisted_combat_step_data_t& step, action_priority_list_t* assisted_combat )
{
  std::string expr = "";
  std::string base_expr = "";
  std::string comment = "";
  bool show_diff = false;
  bool cooldown_allow_casting_success = false;
  bool automation_only = false;
  bool allow_duplicates = true;

  for ( const auto& rule : assisted_combat_rule_data_t::data( step.id, is_ptr() ) )
  {
    if ( rule.condition_type == AC_COOLDOWN_ALLOW_CASTING_SUCCESS )
      cooldown_allow_casting_success = true;

    if ( rule.condition_type == AC_AUTOMATION_ONLY )
      automation_only = true;

    parsed_assisted_combat_rule_t derived_combat_rule = parse_assisted_combat_rule( rule, step );
    parsed_assisted_combat_rule_t base_combat_rule = player_t::parse_assisted_combat_rule( rule, step );

    if ( !derived_combat_rule.expr.empty() )
      expr += expr.empty() ? derived_combat_rule.expr : "&" + derived_combat_rule.expr;
    if ( !derived_combat_rule.comment.empty() )
      comment += comment.empty() ? derived_combat_rule.comment : ", " + derived_combat_rule.comment;
    if ( !derived_combat_rule.allow_duplicates )
      allow_duplicates = false;

    if ( !base_combat_rule.expr.empty() )
      base_expr += base_expr.empty() ? base_combat_rule.expr : "&" + base_combat_rule.expr;

    show_diff |= derived_combat_rule.show_diff;
  }

  if ( base_expr != expr && show_diff )
    comment += ( comment.empty() ? ""  : " " ) + fmt::format( "(Overridden from '{}')", base_expr );

  auto action_names = action_names_from_spell_id( step.spell_id );
  if ( action_names.empty() )
  {
    sim->print_debug(
      "{} action name not found for assisted combat step {} with spell id {} and expression '{}', skipping.", *this,
      step.order_index, step.spell_id, expr );
  }

  for ( const auto& name : action_names )
  {
    if ( name.empty() )
      continue;

    std::string action_str = name;

    if ( !expr.empty() )
      action_str += ",if=" + expr;

    if ( cooldown_allow_casting_success )
      action_str += ",cooldown_allow_casting_success=1";

    if ( automation_only )
    {
      if ( !use_cds_with_blizzard_action_list )
        continue;
      if ( !comment.empty() )
        comment += " ";
      comment += "This is for Blizzard automation and is not included in the game's Assisted Combat system.";
    }

    // Optional duplicate filtering for messy action lists or duplicated overriden criteria
    if ( !allow_duplicates && range::contains( assisted_combat->action_list, action_str, []( const auto& entry ) { return entry.action_; } ) )
      continue;

    assisted_combat->add_action( action_str, comment );
  }
}

parsed_assisted_combat_rule_t player_t::parse_assisted_combat_rule( const assisted_combat_rule_data_t& rule,
                                                                    const assisted_combat_step_data_t& step ) const
{
  auto tokenize_spell = [ & ]( unsigned int spell_id ) {
    const spell_data_t* spell = find_spell( spell_id );
    if ( !spell )
    {
      throw std::runtime_error( fmt::format( "Unable to find spell '{}' condition '{}'.", spell_id, rule.id ) );
    }

    std::string spell_name = util::tokenize_fn( spell->name_cstr() );
    if ( spell_name.empty() )
      return fmt::format( "unknown_spell_{}", spell_id );

    return spell_name;
  };

  auto v1 = rule.condition_value_1;
  auto v2 = rule.condition_value_2;
  auto v3 = rule.condition_value_3;
  std::string expr_str;
  std::string expr_str_2;
  std::string expr_str_3;
  bool has_or = false;
  bool is_duplicate_2;
  bool is_duplicate_3;
  bool is_modified;
  // TODO: verify < vs <= and > vs >= on all condition types
  switch ( rule.condition_type )
  {
    case AC_SPELL_LEARNED:
      assert( v2 == 0 && v3 == 0 );
      if ( v1 )
      {
        for ( const auto& tree : { talent_tree::CLASS, talent_tree::SPECIALIZATION, talent_tree::HERO } )
        {
          const auto& traits = trait_data_t::find_by_spell( tree, v1, util::class_id( type ), specialization(), is_ptr() );
          if ( traits.size() > 0 )
          {
            auto tok_name = tokenize_spell( v1 );

            // Resolve tiered talent names by adding a _# suffix to the tokenized name.
            if ( traits.front()->node_type == trait_node_type_e::NODE_TIERED )
            {
              auto _entries = trait_data_t::data( traits.front()->id_node, util::class_id( type ), tree, is_ptr() );
              auto _index = std::distance( _entries.begin(), range::find( _entries, v1, &trait_data_t::id_spell ) );

              tok_name += "_" + util::to_string( _index + 1 );
            }

            return fmt::format( "talent.{}", tok_name );
          }
        }
        // TODO: Are there any other types of passives to check here?
        // TODO: What happens when Blizzard uses an aura here like they did with Mind Flay: Insanity?
      }
      return ""; // no check necessary because simc actions are filtered out if the spell is not known
    case AC_SPELL_ON_COOLDOWN:
      assert( v2 == 0 && v3 == 0 );
      if ( v1 )
        return fmt::format( "!cooldown.{}.ready", tokenize_spell( v1 ) );
      return ""; // no check necessary because simc actions are not ready unless their cooldown is ready
    case AC_SPELL_OFF_COOLDOWN:
      assert( v2 == 0 && v3 == 0 );
      if ( v1 )
        return fmt::format( "cooldown.{}.ready", tokenize_spell( v1 ) );
      return ""; // no check necessary because simc actions are not ready unless their cooldown is ready
    case AC_TARGET_DISTANCE_LESS:
      assert( v2 == 0 && v3 == 0 );
      return fmt::format( "target.distance<={}", v1 );
    case AC_TARGET_DISTANCE_GREATER:
      assert( v2 == 0 && v3 == 0 );
      return fmt::format( "target.distance>{}", v1 );
    case AC_HOSTILE_TARGET:
    case AC_FRIENDLY_TARGET:
      assert( v1 == 0 && v2 == 0 && v3 == 0 );
      return "";
    case AC_HEALTH_PCT_GREATER:
      assert( v2 == 0 && v3 == 0 );
      return fmt::format( "target.health.pct>={}", v1 );
    case AC_HEALTH_PCT_LESS:
      assert( v2 == 0 && v3 == 0 );
      return fmt::format( "target.health.pct<={}", v1 );
    case AC_AURA_ON_PLAYER:
      // TODO: Are there any cases where a passive here would not be a talent?
      expr_str   = v1 ? aura_expr_from_spell_id( v1, true ) : "";
      expr_str_2 = v2 ? aura_expr_from_spell_id( v2, true ) : "";
      expr_str_3 = v3 ? aura_expr_from_spell_id( v3, true ) : "";
      if ( v1 && !( expr_str.find( "talent." ) == 0 ) )
        expr_str += ".up";
      if ( v2 && !( expr_str_2.find( "talent." ) == 0 ) )
        expr_str_2 += ".up";
      if ( v3 && !( expr_str_3.find( "talent." ) == 0 ) )
        expr_str_3 += ".up";
      is_duplicate_2 = v2 && expr_str_2 == expr_str;
      is_duplicate_3 = v3 && ( expr_str_3 == expr_str || expr_str_3 == expr_str_2 );
      if ( v2 && !is_duplicate_2 )
      {
        if ( !expr_str.empty() )
        {
          expr_str += "|";
          has_or = true;
        }
        expr_str += expr_str_2;
      }
      if ( v3 && !is_duplicate_3 )
      {
        if ( !expr_str.empty() )
        {
          expr_str += "|";
          has_or = true;
        }
        expr_str += expr_str_3;
      }
      is_modified = is_duplicate_2 || is_duplicate_3;
      if ( has_or )
        return { fmt::format( "({})", expr_str ), is_modified };
      return { expr_str, is_modified };
    case AC_AURA_ON_TARGET:
      assert( v2 == 0 && v3 == 0 );
      expr_str = aura_expr_from_spell_id( v1, false );
      if ( expr_str.find( "dot." ) == 0 )
        return fmt::format( "{}.ticking", expr_str );
      return fmt::format( "{}.up", expr_str );
    case AC_TARGET_COUNT_NEAR_TARGET_GREATER:
      assert( v3 == 0 );
      // TODO: add distance targeting
      return fmt::format( "active_enemies>{}", v1 );
    case AC_TARGET_COUNT_NEAR_PLAYER_GREATER:
      assert( v3 == 0 );
      // TODO: add distance targeting
      return fmt::format( "active_enemies>{}", v1 );
    case AC_AURA_COUNT_NEAR_PLAYER_GREATER:
      // TODO: add distance check?
      // TODO: currently unused; verify condition value indices
      expr_str = aura_expr_from_spell_id( v3, false );
      if ( expr_str.find( "dot." ) == 0 )
        return fmt::format( "active_{}>={}", expr_str, v1 ); // TODO: > or >=?
      // TODO: support debuffs
      throw std::runtime_error( "Debuffs are unsupported for condition AURA_COUNT_NEAR_PLAYER_GREATER." );
    case AC_AFFORD_COST:
      assert( v2 == 0 && v3 == 0 );
      if ( v1 )
        return fmt::format( "action.{}.cost_affordable", tokenize_spell( v1 ) );
      return ""; // no check necessary because simc actions are not ready unless their cost is affordable
    case AC_AURA_MISSING_TARGET:
      assert( v2 == 0 && v3 == 0 );
      expr_str = aura_expr_from_spell_id( v1, false );
      if ( expr_str.find( "dot." ) == 0 )
        return fmt::format( "!{}.ticking", expr_str );
      return fmt::format( "{}.down", expr_str );
    case AC_AURA_MISSING_PLAYER:
      assert( v2 == 0 && v3 == 0 );
      expr_str = aura_expr_from_spell_id( v1, true );
      // TODO: Are there any cases where a passive here would not be a talent?
      if ( expr_str.find( "talent." ) == 0 )
        return "!" + expr_str;
      return fmt::format( "{}.down", expr_str );
    case AC_AURA_DURATION_PLAYER:
      assert( v3 == 0 );
      expr_str = aura_expr_from_spell_id( v1, true );
      // TODO: Are there any cases where these would be talents we should worry about?
      if ( expr_str.find( "talent." ) == 0 )
        throw std::runtime_error( "Talents are unsupported for condition AURA_DURATION_PLAYER." );
      return fmt::format( "{}.up&{}.remains<={:g}", expr_str, expr_str, v2 / 1000.0 );
    case AC_AURA_DURATION_TARGET:
      assert( v3 == 0 );
      expr_str = aura_expr_from_spell_id( v1, false );
      return fmt::format( "{}.remains<={:g}", expr_str, v2 / 1000.0 );
    case AC_MANA_GREATER:
      assert( v2 == 0 && v3 == 0 );
      return fmt::format( "mana.pct>={:g}", v1 / 10.0 ); // TODO: Double check this
    case AC_MANA_LESS:
      assert( v2 == 0 && v3 == 0 );
      return fmt::format( "mana.pct<={:g}", v1 / 10.0 ); // TODO: Double check this
    case AC_RAGE_GREATER:
      assert( v2 == 0 && v3 == 0 );
      return fmt::format( "rage>={:g}", v1 / 10.0 );
    case AC_RAGE_LESS:
      assert( v2 == 0 && v3 == 0 );
      return fmt::format( "rage<={:g}", v1 / 10.0 );
    case AC_FOCUS_GREATER:
      assert( v2 == 0 && v3 == 0 );
      return fmt::format( "focus>={}", v1 );
    case AC_FOCUS_LESS:
      assert( v2 == 0 && v3 == 0 );
      return fmt::format( "focus<={}", v1 );
    case AC_ENERGY_GREATER:
      assert( v2 == 0 && v3 == 0 );
      return fmt::format( "energy>={}", v1 );
    case AC_ENERGY_LESS:
      assert( v2 == 0 && v3 == 0 );
      return fmt::format( "energy<={}", v1 );
    case AC_COMBO_POINTS_GREATER:
      assert( v2 == 0 && v3 == 0 );
      return fmt::format( "combo_points>={}", v1 );
    case AC_COMBO_POINTS_LESS:
      assert( v2 == 0 && v3 == 0 );
      return fmt::format( "combo_points<={}", v1 );
    case AC_RUNES_GREATER:
      assert( v2 == 0 && v3 == 0 );
      return fmt::format( "rune>={}", v1 );
    case AC_RUNES_LESS:
      assert( v2 == 0 && v3 == 0 );
      return fmt::format( "rune<={}", v1 );
    case AC_RUNIC_POWER_GREATER:
      assert( v2 == 0 && v3 == 0 );
      return fmt::format( "runic_power>={:g}", v1 / 10.0 );
    case AC_RUNIC_POWER_LESS:
      assert( v2 == 0 && v3 == 0 );
      return fmt::format( "runic_power<={:g}", v1 / 10.0 );
    case AC_SOUL_SHARDS_GREATER:
      assert( v2 == 0 && v3 == 0 );
      return fmt::format( "soul_shard>={:g}", v1 / 10.0 );
    case AC_SOUL_SHARDS_LESS:
      assert( v2 == 0 && v3 == 0 );
      return fmt::format( "soul_shard<={:g}", v1 / 10.0 );
    case AC_LUNAR_POWER_GREATER:
      assert( v2 == 0 && v3 == 0 );
      return fmt::format( "astral_power>={:g}", v1 / 10.0 );
    case AC_LUNAR_POWER_LESS:
      assert( v2 == 0 && v3 == 0 );
      return fmt::format( "astral_power<={:g}", v1 / 10.0 );
    case AC_HOLY_POWER_GREATER:
      assert( v2 == 0 && v3 == 0 );
      return fmt::format( "holy_power>={}", v1 );
    case AC_HOLY_POWER_LESS:
      assert( v2 == 0 && v3 == 0 );
      return fmt::format( "holy_power<={}", v1 );
    case AC_MAELSTROM_GREATER:
      assert( v2 == 0 && v3 == 0 );
      return fmt::format( "maelstrom>={}", v1 );
    case AC_MAELSTROM_LESS:
      assert( v2 == 0 && v3 == 0 );
      return fmt::format( "maelstrom<={}", v1 );
    case AC_CHI_GREATER:
      assert( v2 == 0 && v3 == 0 );
      return fmt::format( "chi>={}", v1 );
    case AC_CHI_LESS:
      assert( v2 == 0 && v3 == 0 );
      return fmt::format( "chi<={}", v1 );
    case AC_INSANITY_GREATER:
      assert( v2 == 0 && v3 == 0 );
      return fmt::format( "insanity>={:g}", v1 / 100.0 );
    case AC_INSANITY_LESS:
      assert( v2 == 0 && v3 == 0 );
      return fmt::format( "insanity<={:g}", v1 / 100.0 );
    case AC_ESSENCE_GREATER:
      assert( v2 == 0 && v3 == 0 );
      return fmt::format( "essence>={}", v1 );
    case AC_ESSENCE_LESS:
      assert( v2 == 0 && v3 == 0 );
      return fmt::format( "essence<={}", v1 );
    case AC_ARCANE_CHARGES_GREATER:
      assert( v2 == 0 && v3 == 0 );
      return fmt::format( "buff.arcane_charge.stack>={}", v1 );
    case AC_ARCANE_CHARGES_LESS:
      assert( v2 == 0 && v3 == 0 );
      return fmt::format( "buff.arcane_charge.stack<={}", v1 );
    case AC_TARGET_COUNT_NEAR_TARGET_LESS:
      assert( v3 == 0 );
      // TODO: add distance targeting
      return fmt::format( "active_enemies<={}", v1 );
    case AC_TARGET_COUNT_NEAR_PLAYER_LESS:
      assert( v3 == 0 );
      // TODO: add distance targeting
      return fmt::format( "active_enemies<={}", v1 );
    case AC_AURA_COUNT_NEAR_PLAYER_LESS:
      // TODO: add distance check?
      expr_str = aura_expr_from_spell_id( v3, false );
      if ( expr_str.find( "dot." ) == 0 )
        return fmt::format( "active_{}<={}", expr_str, v1 ); // TODO: < or <=?
      // TODO: support debuffs
      throw std::runtime_error( "Debuffs are unsupported for condition AURA_COUNT_NEAR_PLAYER_LESS." );
    case AC_TARGET_AURA_APPLICATION_GREATER:
      assert( v3 == 0 );
      expr_str = aura_expr_from_spell_id( v1, false );
      return fmt::format( "{}.stack>={}", expr_str, v2 );
    case AC_TARGET_AURA_APPLICATION_LESS:
      assert( v3 == 0 );
      expr_str = aura_expr_from_spell_id( v1, false );
      return fmt::format( "{}.stack<={}", expr_str, v2 );
    case AC_PLAYER_AURA_APPLICATION_GREATER:
      assert( v3 == 0 );
      expr_str = aura_expr_from_spell_id( v1, true );
      return fmt::format( "{}.stack>={}", expr_str, v2 );
    case AC_PLAYER_AURA_APPLICATION_LESS:
      assert( v3 == 0 );
      expr_str = aura_expr_from_spell_id( v1, true );
      return fmt::format( "{}.stack<={}", expr_str, v2 );
    case AC_SPELL_IN_RANGE:
      assert( v2 == 0 && v3 == 0 );
      if ( v1 )
        return fmt::format( "spell_targets.{}>0", tokenize_spell( v1 ) );
      return ""; // no check necessary because simc actions are not ready unless they have a target
    case AC_HAS_PET:
      assert( v1 == 0 && v2 == 0 && v3 == 0 );
      return "pet.any.active";
    case AC_HAS_NO_PET:
      assert( v1 == 0 && v2 == 0 && v3 == 0 );
      return "!pet.any.active";
    case AC_FURY_GREATER:
      assert( v2 == 0 && v3 == 0 );
      return fmt::format( "fury>={}", v1 );
    case AC_FURY_LESS:
      assert( v2 == 0 && v3 == 0 );
      return fmt::format( "fury<={}", v1 );
    case AC_PAIN_GREATER:
      assert( v2 == 0 && v3 == 0 );
      return fmt::format( "pain>={}", v1 );
    case AC_PAIN_LESS:
      assert( v2 == 0 && v3 == 0 );
      return fmt::format( "pain<={}", v1 );
    case AC_SPELL_CHARGES_GREATER:
      assert( v3 == 0 );
      if ( v2 != 0 )
      {
        assisted_combat_rule_data_t fixed_rule = rule;
        fixed_rule.condition_value_2 = 0;
        auto result = player_t::parse_assisted_combat_rule( fixed_rule, step );
        if ( v1 )
          result.comment = fmt::format( "This checks for charges>={} instead of the intended action.{}.charges>={}.",
                                        v1, tokenize_spell( v1 ), v2 );
        else
          result.comment = fmt::format( "This checks for charges>={} instead of the intended charges>={}.", v1, v2 );
        return result;
      }
      return fmt::format( "charges>={}", v1 );
    case AC_SPELL_CHARGES_LESS:
      assert( v2 == 0 && v3 == 0 );
      return fmt::format( "charges<={}", v1 );
    case AC_COOLDOWN_REMAINING_GREATER:
      assert( v3 == 0 );
      return fmt::format( "cooldown.{}.remains>={:g}", tokenize_spell( v1 ), v2 / 1000.0 );
    case AC_COOLDOWN_REMAINING_LESS:
      assert( v3 == 0 );
      return fmt::format( "cooldown.{}.remains<={:g}", tokenize_spell( v1 ), v2 / 1000.0 );
    case AC_COOLDOWN_ALLOW_CASTING_SUCCESS:
      assert( v1 == 0 && v2 == 0 && v3 == 0 );
      // This is handled elsewhere, since it removes a default condition instead of adding a new one.
      return "";
    case AC_PLAYER_HEALTH_PCT_GREATER:
      assert( v2 == 0 && v3 == 0 );
      return fmt::format( "health.pct>={}", v1 );
    case AC_PLAYER_HEALTH_PCT_LESS:
      assert( v2 == 0 && v3 == 0 );
      return fmt::format( "health.pct<={}", v1 );
    case AC_AUTOMATION_ONLY:
      // This is handled elsewhere.
      return "";
    default:
      throw std::runtime_error( fmt::format( "Unknown condition type '{}.'", rule.condition_type ) );
  }
}

void player_t::init_background_actions()
{
  if ( !is_enemy() )
  {
    if ( record_healing() )
    {
      spells.leech = new leech_t( this );
    }
  }
}

void player_t::create_actions()
{
  if( is_player() && !is_enemy() && !is_pet() )
    consumable::create_consumeable_actions( this );

  if ( action_list_str.empty() )
    no_action_list_provided = true;

  if ( use_blizzard_action_list )
  {
    clear_action_priority_lists();
    init_blizzard_action_list();
  }
  else
  {
    try
    {
      init_action_list();  // virtual function which creates the action list string
    }
    catch ( const std::exception& )
    {
      std::throw_with_nested( sc_initialization_error( "Invalid action list" ) );
    }
  }

  std::string modify_action_options;

  if ( !modify_action.empty() )
  {
    std::string::size_type cut_pt = modify_action.find( ',' );

    if ( cut_pt != modify_action.npos )
    {
      modify_action_options = modify_action.substr( cut_pt + 1 );
      modify_action         = modify_action.substr( 0, cut_pt );
    }
  }
  util::tokenize( modify_action );

  std::vector<util::string_view> skip_actions;
  if ( !action_list_skip.empty() )
  {
    sim->print_debug( "{} action_list_skip={}", *this, action_list_skip );

    skip_actions = util::string_split<util::string_view>( action_list_skip, "/" );
  }

  if ( !use_apl.empty() )
    copy_action_priority_list( "default", use_apl );

  if ( !action_list_str.empty() && !use_blizzard_action_list )
    get_action_priority_list( "default" )->action_list_str = action_list_str;

  if ( is_player() && sim->enable_all_item_effects )
  {
    auto& def = get_action_priority_list( "default" )->action_list;
    def.insert( def.begin(), { "use_item,slot=shirt", "" } );
  }

  int j = 0;

  auto apls = sorted_action_priority_lists( this );
  for ( auto apl : apls )
  {
    assert( apl->action_list_str.empty() || apl->action_list.empty() );

    // Convert old style action list to new style, all lines are without comments
    if ( !apl->action_list_str.empty() )
    {
      for ( auto& split : util::string_split<util::string_view>( apl->action_list_str, "/" ) )
        apl->action_list.emplace_back( split, "" );
    }

    sim->print_debug( "{} actions.{}={}", *this, apl->name_str, apl->action_list_str );

    for ( auto& action_priority : apl->action_list )
    {
      std::string& action_str = action_priority.action_;

      std::string::size_type cut_pt = action_str.find( ',' );
      std::string action_name       = action_str.substr( 0, cut_pt );
      std::string action_options;
      if ( cut_pt != std::string::npos )
        action_options = action_str.substr( cut_pt + 1 );

      action_t* a = nullptr;

      cut_pt = action_name.find( ':' );
      if ( cut_pt != std::string::npos )
      {
        auto pet_name   = action_name.substr( 0, cut_pt );
        auto pet_action = util::tokenize_fn( action_name.substr( cut_pt + 1 ) );

        a = new execute_pet_action_t( this, pet_name, pet_action, action_options );
      }
      else
      {
        util::tokenize( action_name );
        if ( action_name == modify_action )
        {
          sim->print_debug( "{}: modify_action={}", *this, modify_action );

          action_options = modify_action_options;
          action_str     = modify_action + "," + modify_action_options;
        }
        a = create_action( action_name, action_options );
      }

      if ( !a )
      {
        throw sc_initialization_error( fmt::format( "Unable to create action '{}'.", action_str ) );
      }

      // When using the assisted combat system, certain action options need different default values.
      // TODO: Should this check for something instead of the name of the action list?
      if ( apl->name_str == "assisted_combat" )
      {
        if ( a->option.can_have_one_button_penalty_str.empty() )
          a->can_have_one_button_penalty = true;
        if ( a->option.cooldown_allow_casting_success_str.empty() )
          a->cooldown_allow_casting_success = false;
      }

      bool skip = false;
      for ( auto& skip_action : skip_actions )
      {
        if ( skip_action == a->name_str )
        {
          skip = true;
          break;
        }
      }

      if ( skip )
      {
        a->background = true;
      }
      else
      {
        // a -> action_list = action_priority_list[ alist ] -> name_str;
        a->action_list = apl;

        a->signature_str = action_str;
        a->signature     = &( action_priority );

        if ( sim->separate_stats_by_actions > 0 && !is_pet() )
        {
          a->marker = (char)( ( j < 10 ) ? ( '0' + j )
                            : ( j < 36 ) ? ( 'A' + j - 10 )
                            : ( j < 66 ) ? ( 'a' + j - 36 )
                            : ( j < 79 ) ? ( '!' + j - 66 )
                            : ( j < 86 ) ? ( ':' + j - 79 )
                                           : '.' );

          a->stats = get_stats( a->name_str + "__" + a->marker, a );
        }
        j++;
      }
    }
  }

  if ( sim->collect_action_sequence && !is_add() && ( !is_pet() || sim->report_pets_separately ) )
  {
    int capacity = std::max( 3000, static_cast<int>( sim->max_time.total_seconds() ) );
    collected_data.action_sequence.reserve( capacity );
    collected_data.action_sequence.clear();
  }
}

namespace
{
// Only "real" off gcd actions should trigger the off gcd apl behavior since it has a performance
// impact. Some meta-actions (call_action_list, variable, run_action_list, swap_action_list) alone
// cannot trigger off-gcd apl behavior.
bool is_real_action( const action_t* a )
{
  return a -> type != ACTION_CALL && a -> type != ACTION_VARIABLE &&
         ! util::str_compare_ci( a->name_str, "run_action_list" ) &&
         ! util::str_compare_ci( a->name_str, "swap_action_list" );
}
} // Anonymous namespace ends

void player_t::init_actions()
{
  for ( size_t i = 0; i < action_list.size(); ++i )
  {
    action_t* action = action_list[ i ];
    try
    {
      action->init();
    }
    catch ( const std::exception& )
    {
      std::throw_with_nested( std::runtime_error( fmt::format( "{}", *action ) ) );
    }
  }

  bool have_off_gcd_actions = false;
  bool have_cast_while_casting_actions = false;
  for ( auto action : action_list )
  {
    if ( action->action_list && action->trigger_gcd == timespan_t::zero() &&
         !action->background && action->use_off_gcd )
    {
      action->action_list->off_gcd_actions.push_back( action );
      // Optimization: We don't need to do off gcd stuff when there are no other off gcd actions
      // than "meta actions"
      if ( is_real_action( action ) )
      {
        have_off_gcd_actions = true;

        auto it = range::find_if( off_gcd_cd, [action]( std::pair<const cooldown_t*, const cooldown_t*> cds ) {
          return cds.first == action->cooldown && cds.second == action->internal_cooldown; }
        );

        if ( it == off_gcd_cd.end() )
        {
          off_gcd_cd.emplace_back( action->cooldown, action->internal_cooldown );
        }
      }
    }

    if ( action->action_list && !action->background && action->use_while_casting &&
         action->usable_while_casting )
    {
      action->action_list->cast_while_casting_actions.push_back( action );

      if ( is_real_action( action ) )
      {
        have_cast_while_casting_actions = true;

        auto it = range::find_if( cast_while_casting_cd, [action]( std::pair<const cooldown_t*, const cooldown_t*> cds ) {
          return cds.first == action->cooldown && cds.second == action->internal_cooldown; }
        );

        if ( it == cast_while_casting_cd.end() )
        {
          cast_while_casting_cd.emplace_back( action->cooldown, action->internal_cooldown );
        }
      }
    }
  }

  if ( choose_action_list.empty() )
    choose_action_list = "default";

  default_action_list = find_action_priority_list( choose_action_list );

  if ( !default_action_list && choose_action_list != "default" )
  {
    sim->error( "Action List '{}' not found, using default action list.", choose_action_list );
    default_action_list = find_action_priority_list( "default" );
  }

  if ( default_action_list )
  {
    prune_specialized_execute_actions( default_action_list->off_gcd_actions, execute_type::OFF_GCD );
    prune_specialized_execute_actions( default_action_list->cast_while_casting_actions,
        execute_type::CAST_WHILE_CASTING );

    activate_action_list( default_action_list );
    if ( have_off_gcd_actions )
      activate_action_list( default_action_list, execute_type::OFF_GCD );

    if ( have_cast_while_casting_actions )
      activate_action_list( default_action_list, execute_type::CAST_WHILE_CASTING );
  }
  else
  {
    sim->error( "No Default Action List available." );
  }
}

void player_t::init_assessors()
{
  // Target related mitigation
  assessor_out_damage.add( assessor::TARGET_MITIGATION, []( result_amount_type dmg_type, action_state_t* state ) {
    state->target->assess_damage( state->action->get_school(), dmg_type, state );
    return assessor::CONTINUE;
  } );

  // Target damage
  assessor_out_damage.add( assessor::TARGET_DAMAGE, []( result_amount_type, action_state_t* state ) {
    state->target->do_damage( state );
    return assessor::CONTINUE;
  } );

  // Logging and debug .. Technically, this should probably be in action_t::assess_damage, but we
  // don't need this piece of code for the vast majority of sims, so it makes sense to yank it out
  // completely from there, and only conditionally include it if logging/debugging is enabled.
  if ( sim->log || sim->debug || !sim->debug_seed.empty() )
  {
    assessor_out_damage.add( assessor::LOG, [this]( result_amount_type type, action_state_t* state ) {
      if ( sim->debug )
      {
        state->debug();
      }

      if ( sim->log )
      {
        if ( type == result_amount_type::DMG_DIRECT )
        {
          sim->print_log( "{} {} hits {} for {:.6f} {} damage ({})", *this, *state->action, *state->target,
                          state->result_amount, state->action->get_school(), state->result );
        }
        else  // result_amount_type::DMG_OVER_TIME
        {
          dot_t* dot = state->action->get_dot( state->target );
          sim->print_log( "{} {} ticks ({} of {}) on {} for {:.6f} {} damage ({})", *this, *state->action,
                          dot->current_tick, dot->num_ticks(), *state->target, state->result_amount,
                          state->action->get_school(), state->result );
        }
      }
      return assessor::CONTINUE;
    } );
  }

  // Leech, if the player has leeching enabled (disabled by default)
  if ( spells.leech )
  {
    assessor_out_damage.add( assessor::LEECH, [ this ]( result_amount_type, action_state_t* state ) {
      // Leeching .. sanity check that the result type is a damaging one, so things hopefully don't
      // break in the future if we ever decide to not separate heal and damage assessing.
      double leech_pct = 0;

      if ( ( state->result_type == result_amount_type::DMG_DIRECT ||
             state->result_type == result_amount_type::DMG_OVER_TIME ) &&
           state->result_amount > 0 && ( leech_pct = state->action->composite_leech( state ) ) > 0 )
      {
        leech_pool += leech_pct * state->result_amount;
      }

      return assessor::CONTINUE;
    } );
  }

  // Generic actor callbacks
  assessor_out_damage.add( assessor::CALLBACKS, [this]( result_amount_type, action_state_t* state ) {
    auto action = state->action;
    if ( action->callbacks && action->caster_callbacks &&
         ( !action->suppress_caster_procs || action->enable_proc_from_suppressed ) )
    {
      proc_types pt   = state->proc_type();
      proc_types2 pt2 = state->impact_proc_type2();

      if ( pt != PROC1_INVALID && pt2 != PROC2_INVALID )
        trigger_callbacks( pt, pt2, action, state, action->proc_trigger_type( pt, TRIGGER_ACTION ) );
    }

    return assessor::CONTINUE;
  } );
}

void player_t::init_finished()
{
  // Add dynamic cooldowns first before action_t::init_finished so actions can adjust their behavior accordingly if
  // necessary.
  range::for_each( cooldown_list, [ this ]( cooldown_t* c ) {
    if ( c->hasted )
    {
      dynamic_cooldown_list.push_back( c );
    }
  } );

  for ( auto action : action_list )
  {
    try
    {
      action_init_finished( *action );
    }
    catch ( const std::exception& )
    {
      std::throw_with_nested( std::runtime_error( fmt::format( "{}", *action ) ) );
    }
  }

  for ( auto action : action_list )
  {
    try
    {
      action->init_finished();
    }
    catch ( const std::exception& )
    {
      std::throw_with_nested( std::runtime_error( fmt::format( "{}", *action ) ) );
    }
  }

  // Naive recording of minimum energy thresholds for the actor.
  // TODO: Energy pooling, and energy-based expressions (energy>=10) are not included yet
  for ( auto action : action_list )
  {
    auto _cost = action->base_costs[ primary_resource() ];

    if ( !action->background && _cost > 0 && !range::contains( resource_thresholds, _cost ) )
      resource_thresholds.push_back( action->base_costs[ primary_resource() ] );
  }

  range::sort( resource_thresholds );

  // Sort outbound assessors
  assessor_out_damage.sort();

  // Trigger init finished callbacks
  for ( const auto& cb : callbacks_on_init_finished )
    cb( this );

  // Print items to debug log
  if ( sim->debug )
  {
    range::for_each( items, [ this ]( const item_t& item ) {
      if ( item.active() )
      {
        sim->print_debug( "{}", item );
      }
    } );
  }

  if ( !precombat_state_map.empty() )
  {
    sim->error(
      "Warning: The 'override.precombat_state' option may not be fully supported for all buffs and cooldowns and may "
      "produce incorrect or misleading results." );

    struct buff_state_t
    {
      int stacks = -1;
      double value = buff_t::DEFAULT_VALUE();
      timespan_t duration = timespan_t::min();
    };

    std::unordered_map<buff_t*, buff_state_t> precombat_buff_state;
    auto update_buff_state = [ this, &precombat_buff_state ]( std::string_view buff_name, std::string_view type,
                                                              std::string_view value ) {
      buff_t* buff = buff_t::find( this, buff_name );
      if ( !buff )
      {
        throw std::invalid_argument( fmt::format( "No buff found for '{}'.", buff_name ) );
      }

      if ( type == "stack" )
        precombat_buff_state[ buff ].stacks = util::to_int( value );
      else if ( type == "value" )
        precombat_buff_state[ buff ].value = util::to_double( value );
      else if ( type == "remains" )
        precombat_buff_state[ buff ].duration = timespan_t::from_seconds( util::to_double( value ) );
      else
        throw std::invalid_argument( fmt::format( "Invalid buff expression type '{}'.", type ) );
    };

    try
    {
      for ( const auto& v : precombat_state_map )
      {
        auto splits = util::string_split<std::string_view>( v.first, "." );

        if ( splits.size() < 2 )
        {
          throw std::invalid_argument( fmt::format( "Invalid option for '{}'.", v.first ) );
        }

        auto type_str = splits[ 0 ];
        auto name = splits[ 1 ];

        if ( type_str == "buff" )
        {
          if ( splits.size() != 3 )
          {
            throw std::invalid_argument( fmt::format( "Invalid buff expression '{}.'", v.first ) );
          }

          update_buff_state( name, splits[ 2 ], v.second );
        }
        else if ( type_str == "cooldown" )
        {
          if ( splits.size() != 2 )
          {
            throw std::invalid_argument( fmt::format( "Invalid cooldown expression '{}'.", v.first ) );
          }

          auto cd = find_cooldown( name );
          if ( !cd )
          {
            throw std::invalid_argument( fmt::format( "No cooldown found for '{}'.", name ) );
          }

          timespan_t duration = timespan_t::from_seconds( util::to_double( v.second ) );
          add_precombat_cooldown_state( cd, duration );
        }
        else
        {
          throw std::invalid_argument( fmt::format( "Invalid option type '{}'.", type_str ) );
        }
      }

      for ( const auto& [ buff, buff_state ] : precombat_buff_state )
      {
        add_precombat_buff_state( buff, buff_state.stacks, buff_state.value, buff_state.duration );
      }
    }
    catch ( const std::exception& )
    {
      std::throw_with_nested( sc_invalid_player_argument( "Invalid 'override.precombat_state'" ) );
    }
  }

  for ( const auto& [ buff_name, c ] : custom_stat_buffs )
  {
    buff_t* custom_buff = nullptr;

    if ( c.is_percentage )
    {
      stat_pct_buff_type stat_pct;
      double stat_amount = c.amount * 0.01;

      switch ( convert_hybrid_stat( c.stat ) )
      {
        case STAT_CRIT_RATING:        stat_pct = STAT_PCT_BUFF_CRIT; break;
        case STAT_HASTE_RATING:       stat_pct = STAT_PCT_BUFF_HASTE; break;
        case STAT_VERSATILITY_RATING: stat_pct = STAT_PCT_BUFF_VERSATILITY; break;
        case STAT_MASTERY_RATING:     stat_pct = STAT_PCT_BUFF_MASTERY; stat_amount = c.amount; break;
        case STAT_STRENGTH:           stat_pct = STAT_PCT_BUFF_STRENGTH; break;
        case STAT_AGILITY:            stat_pct = STAT_PCT_BUFF_AGILITY; break;
        case STAT_STAMINA:            stat_pct = STAT_PCT_BUFF_STAMINA; break;
        case STAT_INTELLECT:          stat_pct = STAT_PCT_BUFF_INTELLECT; break;
        case STAT_SPIRIT:             stat_pct = STAT_PCT_BUFF_SPIRIT; break;
        default:
          throw sc_invalid_player_argument(
            fmt::format( "Invalid 'custom_stat' percentage stat type '{}'.", util::stat_type_string( c.stat ) ) );
      }

      custom_buff = make_buff( this, buff_name )
                      ->set_default_value( stat_amount )
                      ->set_pct_buff_type( stat_pct )
                      ->set_duration( c.duration );
    }
    else
    {
      custom_buff = make_buff<stat_buff_t>( this, buff_name )
                      ->add_stat( convert_hybrid_stat( c.stat ), c.amount )
                      ->set_duration( c.duration );
    }

    if ( !custom_buff )
      continue;

    if ( c.start == timespan_t::min() )
    {
      register_precombat_begin( [ custom_buff ]( player_t* ) {
        custom_buff->execute();
      } );
    }
    else
    {
      register_precombat_begin( [ this, custom_buff, dur = c.start ]( player_t* ) {
        make_event( *sim, dur, [ custom_buff ]() { custom_buff->execute(); } );
      } );
    }
  }
}

void player_t::add_precombat_buff_state( buff_t* buff, int stacks, double value, timespan_t duration )
{
  if ( !buff->allow_precombat )
    throw std::invalid_argument( fmt::format( "Precombat states for buff '{}' are disabled.", buff->name_str ) );

  register_precombat_begin( [ buff, stacks, value, duration ]( player_t* ) {
    buff->execute( stacks, value, duration );
    buff->predict();
  } );
}

void player_t::add_precombat_cooldown_state( cooldown_t* cd, timespan_t duration )
{
  if ( !cd->allow_precombat )
    throw std::invalid_argument( fmt::format( "Precombat states for cooldown '{}' are disabled.", cd->name_str ) );

  // A cooldown may need an action to have its recharge rate properly adjusted.
  // Attempt to find an action with the same name that uses this cooldown.
  auto action = find_action( cd->name_str );
  if ( action->cooldown != cd )
    action = nullptr;

  register_precombat_begin( [ cd, action, duration ]( player_t* ) {
    cd->start( action, duration );
  } );
}

void player_t::action_init_finished(action_t&)
{
}

/**
 * Add a wake-up call at the next resource threshold level, compared to the current resource status of the actor.
 */
void player_t::min_threshold_trigger()
{
  if ( ready_type == READY_POLL )
  {
    return;
  }

  if ( resource_thresholds.empty() )
  {
    return;
  }

  resource_e pres = primary_resource();
  if ( pres != RESOURCE_MANA && pres != RESOURCE_ENERGY && pres != RESOURCE_FOCUS )
  {
    return;
  }

  size_t i = 0, end = resource_thresholds.size();
  double threshold = 0;
  for ( ; i < end; ++i )
  {
    if ( resources.current[ pres ] < resource_thresholds[ i ] )
    {
      threshold = resource_thresholds[ i ];
      break;
    }
  }

  timespan_t time_to_threshold = timespan_t::zero();
  if ( i < resource_thresholds.size() )
  {
    double rps = resource_regen_per_second( pres );

    if ( rps > 0 )
    {
      double diff       = threshold - resources.current[ pres ];
      time_to_threshold = timespan_t::from_seconds( diff / rps );
    }
  }

  // If time to threshold is zero, there's no need to reset anything
  if ( time_to_threshold <= timespan_t::zero() )
  {
    return;
  }

  timespan_t occurs = sim->current_time() + time_to_threshold;
  if ( resource_threshold_trigger )
  {
    // We should never ever be doing threshold-based wake up calls if there already is a
    // Player-ready event.
    assert( !readying );

    if ( occurs > resource_threshold_trigger->occurs() )
    {
      resource_threshold_trigger->reschedule( time_to_threshold );
      sim->print_debug( "{} rescheduling Resource-Threshold event: threshold={} delay={}", *this,
                               threshold, time_to_threshold );
    }
    else if ( occurs < resource_threshold_trigger->occurs() )
    {
      event_t::cancel( resource_threshold_trigger );
      resource_threshold_trigger = make_event<resource_threshold_event_t>( *sim, this, time_to_threshold );

      sim->print_debug( "{} recreating Resource-Threshold event: threshold={} delay={}", *this,
                               threshold, time_to_threshold );
    }
  }
  else
  {
    // We should never ever be doing threshold-based wake up calls if there already is a
    // Player-ready event.
    assert( !readying );

    resource_threshold_trigger = make_event<resource_threshold_event_t>( *sim, this, time_to_threshold );

    sim->print_debug( "{} scheduling new Resource-Threshold event: threshold={} delay={}", *this,
                             threshold, time_to_threshold );
  }
}

/**
 * Create player buffs.
 *
 * Note, these are player and enemy buffs/debuffs. Pet buffs and debuffs are in pet_t::create_buffs
 */
void player_t::create_buffs()
{
  sim->print_debug( "Creating Auras, Buffs, and Debuffs for {}.", *this );

  // Infinite-Stacking Buffs and De-Buffs for everyone
  buffs.stunned = make_buff( this, "stunned" )
    ->set_max_stack( 1 )
    ->set_expire_callback( [ this ]( buff_t*, int, timespan_t d )
      {
        if ( !sim->event_mgr.canceled && d == timespan_t::zero() )
          trigger_ready();
      } );

  buffs.rooted = make_buff( this, "rooted" )->set_max_stack( 1 )->set_quiet( true );

  debuffs.casting = make_buff( this, "casting" )->set_max_stack( 1 )->set_quiet( true );

  // .. for players
  if ( !is_enemy() && type != HEALING_ENEMY )
  {
    // Racials
    buffs.stoneform = make_buff_fallback( race == RACE_DWARF, this, "stoneform", find_spell( 65116 ) )
      ->set_default_value_from_effect_type( A_MOD_DAMAGE_PERCENT_TAKEN );

    buffs.shadowmeld = make_buff_fallback( race == RACE_NIGHT_ELF, this, "shadowmeld", find_spell( 58984 ) )
      ->set_cooldown( 0_ms );

    // fallback for ingest mineral isn't necessary as it's a passive effect that should not have any apl interaction
    if ( race == RACE_EARTHEN_HORDE || race == RACE_EARTHEN_ALLIANCE )
    {
      unsigned _id = 451918;  // crit is default

      switch ( earthen_mineral )
      {
        case player_t::AMBER:    _id = 451921; break;  // stamina
        case player_t::EMERALD:  _id = 451916; break;  // haste
        case player_t::ONYX:     _id = 451920; break;  // mastery
        case player_t::SAPPHIRE: _id = 451917; break;  // versatility
        default:                 break;
      }

      auto ingest_buff = make_buff<stat_buff_t>( this, "ingest_mineral", find_spell( _id ) )
        ->set_name_reporting( "Ingest Mineral" );

      register_on_arise_callback( this, [ ingest_buff ] { ingest_buff->trigger(); } );
    }

    buffs.movement = new movement_buff_t( this );
  }
  // .. for enemies
  else
  {
    debuffs.bleeding      = make_buff( this, "bleeding" )->set_max_stack( 1 );
    debuffs.invulnerable  = make_buff<invulnerable_debuff_t>( this );
    debuffs.vulnerable    = make_buff( this, "vulnerable" )->set_max_stack( 1 );
    debuffs.flying        = make_buff( this, "flying" )->set_max_stack( 1 );
    debuffs.mortal_wounds = make_buff( this, "mortal_wounds", find_spell( 115804 ) )
      ->set_default_value( std::fabs( find_spell( 115804 )->effectN( 1 ).percent() ) );

    // BfA Raid Damage Modifier Debuffs
    debuffs.chaos_brand = make_buff( this, "chaos_brand", find_spell( 1490 ) )
      ->set_default_value_from_effect( 1 )
      ->set_cooldown( timespan_t::from_seconds( 5.0 ) );
    debuffs.mystic_touch = make_buff( this, "mystic_touch", find_spell( 113746 ) )
      ->set_default_value_from_effect( 1 )
      ->set_cooldown( timespan_t::from_seconds( 5.0 ) );

    // Dragonflight Raid Damage Modifier Debuffs
    debuffs.hunters_mark = make_buff( this, "hunters_mark", find_spell( 259556 ) )
      ->disable_ticking( true )
      ->set_default_value_from_effect_type( A_MOD_DAMAGE_PERCENT_TAKEN );
  }

  // set up always since this can be applied by enemy actions and raid events.
  debuffs.damage_taken = make_buff( this, "damage_taken" )
    ->set_duration( timespan_t::from_seconds( 20.0 ) )
    ->set_max_stack( 999 );
}

item_t* player_t::find_item_by_name( util::string_view item_name )
{
  auto it = range::find(items, item_name, &item_t::name );

  if ( it != items.end())
  {
    return &(*it);
  }

  return nullptr;
}

item_t* player_t::find_item_by_id( unsigned item_id )
{
  auto it = range::find_if(items, [item_id](const item_t& item) { return item_id == item.parsed.data.id;});

  if ( it != items.end())
  {
    return &(*it);
  }

  return nullptr;
}

item_t* player_t::find_item_by_use_effect_name( util::string_view effect_name )
{
  auto it = range::find_if(items, [effect_name](const item_t& item) {
    return item.has_use_special_effect() && effect_name == item.special_effect( SPECIAL_EFFECT_SOURCE_NONE, SPECIAL_EFFECT_USE )->name();
  } );

  if ( it != items.end())
  {
    return &(*it);
  }

  return nullptr;
}

/**
 * Scaled player level.
 *
 * Options such as timewalking will affect the players true_level.
 */
int player_t::level() const
{
  if ( sim->timewalk > 0 && !is_enemy() )
    return sim->timewalk;
  else
    return true_level;
}

double player_t::resource_regen_per_second( resource_e r ) const
{
  double reg = resources.base_regen_per_second[ r ];

  if ( resources.hasted[ r ] )
    reg /= cache.attack_haste();

  return reg;
}

double player_t::apply_combat_rating_dr( rating_e rating, double value ) const
{
  switch ( rating )
  {
    case RATING_LEECH:
    case RATING_SPEED:
    case RATING_AVOIDANCE:
      return item_database::curve_point_value( *dbc, DIMINISHING_RETURN_TERTIARY_CR_CURVE, value * 100.0 ) / 100.0;
    case RATING_MASTERY:
      return item_database::curve_point_value( *dbc, DIMINISHING_RETURN_SECONDARY_CR_CURVE, value );
    case RATING_MITIGATION_VERSATILITY:
      return item_database::curve_point_value( *dbc, DIMINISHING_RETURN_VERS_MITIG_CR_CURVE, value * 100.0 ) / 100.0;
    default:
      // Note, curve uses %-based values, not values divided by 100
      return item_database::curve_point_value( *dbc, DIMINISHING_RETURN_SECONDARY_CR_CURVE, value * 100.0 ) / 100.0;
  }
}

double player_t::composite_melee_haste() const
{
  double h;

  h = std::max( 0.0, composite_melee_haste_rating() ) / current.rating.attack_haste;
  h = apply_combat_rating_dr( RATING_MELEE_HASTE, h );

  h = 1.0 / ( 1.0 + h );

  h *= current.melee_haste;

  if ( !is_pet() && !is_enemy() && type != HEALING_ENEMY )
  {
    for ( auto b : buffs.stat_pct_buffs[ STAT_PCT_BUFF_HASTE ] )
      h /= 1.0 + b->check_stack_value();

    if ( buffs.bloodlust->check() )
      h *= 1.0 / ( 1.0 + buffs.bloodlust->check_stack_value() );
  }

  return h;
}

double player_t::composite_melee_auto_attack_speed() const
{
  double h = composite_melee_haste();

  h *= current.attack_speed_multiplier;

  if ( buffs.galeforce_striking && buffs.galeforce_striking->check() )
    h *= 1.0 / ( 1.0 + buffs.galeforce_striking->check_value() );

  if ( buffs.delirious_frenzy && buffs.delirious_frenzy->check() )
    h *= 1.0 / ( 1.0 + buffs.delirious_frenzy->check_stack_value() );

  if ( buffs.way_of_controlled_currents && buffs.way_of_controlled_currents->check() )
    h *= 1.0 / ( 1.0 + buffs.way_of_controlled_currents->check_stack_value() );

  return h;
}

double player_t::composite_melee_attack_power() const
{
  double ap = current.stats.attack_power;

  ap += current.attack_power_per_strength * cache.strength();
  ap += current.attack_power_per_agility * cache.agility();

  return ap;
}

double player_t::composite_weapon_attack_power_by_type( attack_power_type ap_type ) const
{
  double wdps = 0;
  bool has_mh = main_hand_weapon.type != WEAPON_NONE;
  bool has_oh = off_hand_weapon.type != WEAPON_NONE;

  switch ( ap_type )
  {
    case attack_power_type::WEAPON_MAINHAND:
      if ( has_mh )
      {
        wdps = main_hand_weapon.dps;
      }
      else  // Unarmed is apparently a 0.5 dps weapon, Bruce Lee would be ashamed.
      {
        wdps = .5;
      }
      break;

    case attack_power_type::WEAPON_OFFHAND:
      if ( has_oh )
      {
        wdps = off_hand_weapon.dps;
      }
      else
      {
        wdps = .5;
      }
      break;

    case attack_power_type::WEAPON_BOTH:
      // Don't use with weapon = player -> off_hand_weapon or the OH penalty will be applied to the whole spell
      wdps = ( has_mh ? main_hand_weapon.dps : .5 ) + ( has_oh ? off_hand_weapon.dps : .5 ) / 2;
      wdps *= 2.0 / 3.0;
      break;

    default:  // Nohand, just base AP then
      break;
  }

  // 2022-08-25 -- Aura type 141 works as a general base weapon damage modifier which affects AP calculations
  //               This is normalized to AP based on weapon speed in a similar way as base weapon DPS above
  //               Aura type 530 does not apply to this, as it is only added to the result of white hits
  if ( auto_attack_base_modifier > 0 )
  {
    if ( ap_type == attack_power_type::WEAPON_MAINHAND )
    {
      wdps += auto_attack_base_modifier / main_hand_weapon.swing_time.total_seconds();
    }
    else if ( ap_type == attack_power_type::WEAPON_OFFHAND )
    {
      wdps += auto_attack_base_modifier / off_hand_weapon.swing_time.total_seconds();
    }
    else if ( ap_type == attack_power_type::WEAPON_BOTH )
    {
      wdps += ( auto_attack_base_modifier / main_hand_weapon.swing_time.total_seconds()
              + auto_attack_base_modifier / off_hand_weapon.swing_time.total_seconds() * 0.5 ) * ( 2.0 / 3.0 );
    }
  }

  // weapon attack power is truncated to integer
  return static_cast<int>( wdps * WEAPON_POWER_COEFFICIENT );
}

double player_t::composite_total_attack_power_by_type( attack_power_type ap_type ) const
{
  // duplicate code to prevent recursion
  if ( current.attack_power_per_spell_power > 0 )
  {
    // total spell power is rounded to integer
    auto sp = std::round( cache.spell_power( SCHOOL_MAX ) * composite_spell_power_multiplier() );

    return std::round( current.attack_power_per_spell_power * sp );
  }

  auto mul = composite_attack_power_multiplier();

  // total attack power is rounded to integer
  return std::round( cache.attack_power() * mul + cache.weapon_attack_power( ap_type ) * mul );
}

double player_t::composite_attack_power_multiplier() const
{
  if ( is_pet() || is_enemy() || type == HEALING_ENEMY || current.attack_power_per_spell_power > 0 )
  {
    return 1.0;
  }

  double m = current.attack_power_multiplier;

  m *= 1.0 + sim->auras.battle_shout->check_value();

  // multiplier is rounded to 3 digits
  return std::round( m * 1000 ) * 0.001;
}

double player_t::composite_melee_crit_chance() const
{
  double ac = current.attack_crit_chance;

  ac += apply_combat_rating_dr( RATING_MELEE_CRIT, composite_melee_crit_rating() / current.rating.attack_crit );

  for ( auto b : buffs.stat_pct_buffs[ STAT_PCT_BUFF_CRIT ] )
    ac += b->check_stack_value();

  return ac;
}

double player_t::composite_melee_expertise( const weapon_t* ) const
{
  double e = current.expertise;

  // e += composite_expertise_rating() / current.rating.expertise;

  return e;
}

double player_t::composite_melee_hit() const
{
  double ah = current.hit;

  // ah += composite_melee_hit_rating() / current.rating.attack_hit;

  return ah;
}

double player_t::composite_armor() const
{
  double a = current.stats.armor;

  a *= composite_base_armor_multiplier();

  a += cache.bonus_armor();

  // "Modify Armor%" effects affect all armor multiplicatively
  // TODO: What constitutes "bonus armor" and "base armor" in terms of client data?
  a *= composite_armor_multiplier();

  return a;
}

double player_t::composite_base_armor_multiplier() const
{
  double a = current.base_armor_multiplier;

  return a;
}

double player_t::composite_armor_multiplier() const
{
  double a = current.armor_multiplier;

  return a;
}

double player_t::composite_miss() const
{
  // this is sort of academic, since we know of no sources of miss that are actually subject to DR.
  // However, we've been told that it follows the same DR formula as the other avoidance stats, and
  // we've been given the relevant constants (def_dr.miss_factor etc.). I've coded this mostly for symmetry,
  // such that it will be fully-functional if in the future we suddenly gain some source of bonus_miss.

  // Start with sources not subject to DR - base miss (stored in current.miss)
  double total_miss = current.miss;

  // bonus_miss is miss from rating or other sources subject to DR
  double bonus_miss = 0.0;

  // if we have any bonus_miss, apply diminishing returns and add it to total_miss
  if ( bonus_miss > 0 )
    total_miss +=
        bonus_miss / ( def_dr.miss_factor * bonus_miss * 100 * def_dr.vertical_stretch + def_dr.horizontal_shift );

  assert( total_miss >= 0.0 && total_miss <= 1.0 );

  return total_miss;
}

/**
 * Composite block chance.
 *
 * Use composite_block_dr function to apply diminishing returns on the part of your block which is affected by it.
 * See paladin_t::composite_block() to see how this works.
 */
double player_t::composite_block() const
{
  return player_t::composite_block_dr( 0.0 );
}

/**
 * Helper function to calculate block value after diminishing returns.
 */
double player_t::composite_block_dr( double extra_block ) const
{
  // Start with sources not subject to DR - base block (stored in current.block)
  double total_block = current.block;

  // bonus_block is block from rating or other sources subject to DR (passed from class module via extra_block)
  double bonus_block = composite_block_rating() / current.rating.block;
  bonus_block += extra_block;

  // bonus_block gets rounded because that's how blizzard rolls...
  bonus_block = util::round( 12800 * bonus_block ) / 12800;

  // if we have any bonus_block, apply diminishing returns and add it to total_block
  if ( bonus_block > 0 )
    total_block +=
        bonus_block / ( def_dr.block_factor * bonus_block * 100 * def_dr.block_vertical_stretch + def_dr.horizontal_shift );

  return total_block;
}

bool player_t::is_moving() const
{
  return buffs.movement && buffs.movement -> check();
}

bool player_t::in_gcd() const
{
  return gcd_ready > sim -> current_time();
}

double player_t::composite_dodge() const
{
  // Start with sources not subject to DR - base dodge + dodge from base agility (stored in current.dodge)
  double total_dodge = current.dodge;

  // bonus_dodge is from crit (through dodge rating) and bonus Agility
  double bonus_dodge = composite_dodge_rating() / current.rating.dodge;
  if ( !is_enemy() )
  {
    bonus_dodge += ( cache.agility() - dbc->race_base( race ).agility -
        dbc->attribute_base( type, level() ).agility ) * current.dodge_per_agility;
  }

  // if we have any bonus_dodge, apply diminishing returns and add it to total_dodge.
  if ( bonus_dodge != 0 )
    total_dodge +=
        bonus_dodge / ( def_dr.dodge_factor * bonus_dodge * 100 * def_dr.vertical_stretch + def_dr.horizontal_shift );

  return total_dodge;
}

double player_t::composite_parry_rating() const
{
  double r = composite_rating( RATING_PARRY );

  if ( current.parry_rating_per_crit_rating > 0 )
    r += composite_melee_crit_rating() * current.parry_rating_per_crit_rating;

  return r;
}

double player_t::composite_parry() const
{
  // Start with sources not subject to DR - base parry + parry from base strength (stored in current.parry).
  double total_parry = current.parry;

  // bonus_parry is from rating and bonus Strength
  double bonus_parry = composite_parry_rating() / current.rating.parry;
  if ( !is_enemy() )
  {
    bonus_parry += ( cache.strength() - dbc->race_base( race ).strength -
        dbc->attribute_base( type, level() ).strength ) * current.parry_per_strength;
  }

  // if we have any bonus_parry, apply diminishing returns and add it to total_parry.
  if ( bonus_parry != 0 )
    total_parry +=
    bonus_parry / ( def_dr.parry_factor * bonus_parry * 100 * def_dr.vertical_stretch + def_dr.horizontal_shift );

  return total_parry;
}

double player_t::composite_block_value( const action_state_t* ) const
{
  return current.block_value;
}

double player_t::composite_crit_avoidance() const
{
  return current.crit_avoidance;
}

/**
 * This is the subset of the old_spell_haste that applies to RPPM
 */
double player_t::composite_spell_haste() const
{
  double h;

  h = std::max( 0.0, composite_spell_haste_rating() ) / current.rating.spell_haste;
  h = apply_combat_rating_dr( RATING_SPELL_HASTE, h );

  h = 1.0 / ( 1.0 + h );

  h *= current.spell_haste;

  if ( !is_pet() && !is_enemy() && type != HEALING_ENEMY )
  {
    for ( auto b : buffs.stat_pct_buffs[ STAT_PCT_BUFF_HASTE ] )
      h /= 1.0 + b->check_stack_value();

    if ( buffs.bloodlust->check() )
      h *= 1.0 / ( 1.0 + buffs.bloodlust->check_stack_value() );
  }

  return h;
}

/**
 * This is the old spell_haste and incorporates everything that buffs cast speed
 */
double player_t::composite_spell_cast_speed() const
{
  auto speed = cache.spell_haste();

  if ( !is_pet() && !is_enemy() && type != HEALING_ENEMY )
  {
    if ( buffs.nefarious_pact )
    {
      speed *= 1.0 / ( 1.0 + buffs.nefarious_pact->check_stack_value() );
    }

    if ( buffs.devils_due )
    {
      speed *= 1.0 - buffs.devils_due->check_stack_value();
    }
  }

  return speed;
}

double player_t::composite_spell_power( school_e /* school */ ) const
{
  double sp = current.stats.spell_power;

  sp += current.spell_power_per_intellect * cache.intellect();

  return sp;
}

double player_t::composite_total_spell_power( school_e school ) const
{
  // dupplicate code to prevent recursion
  if ( current.spell_power_per_attack_power > 0 )
  {
    auto mul = composite_attack_power_multiplier();

    // total attack power is rounded to integer
    auto ap = std::round( cache.attack_power() * mul +
                          cache.weapon_attack_power( attack_power_type::WEAPON_MAINHAND ) * mul );

    return std::round( current.spell_power_per_attack_power * ap );
  }

  // total spell power is rounded to integer
  return std::round( cache.spell_power( school ) * composite_spell_power_multiplier() );
}

double player_t::composite_spell_power_multiplier() const
{
  if ( is_pet() || is_enemy() || type == HEALING_ENEMY || current.spell_power_per_attack_power > 0 )
  {
    return 1.0;
  }

  // multiplier is rounded to 3 digits
  return std::round( current.spell_power_multiplier * 1000 ) * 0.001;
}

double player_t::matching_gear_multiplier( attribute_e a ) const
{
  return current.matching_armor_multiplier[ a ];
}

double player_t::composite_spell_crit_chance() const
{
  double sc = current.spell_crit_chance;

  sc += apply_combat_rating_dr( RATING_SPELL_CRIT, composite_spell_crit_rating() / current.rating.spell_crit );

  for ( auto b : buffs.stat_pct_buffs[ STAT_PCT_BUFF_CRIT ] )
    sc += b->check_stack_value();

  return sc;
}

double player_t::composite_spell_hit() const
{
  double sh = current.hit;

  // sh += composite_spell_hit_rating() / current.rating.spell_hit;

  sh += composite_melee_expertise();

  return sh;
}

double player_t::composite_mastery() const
{
  double cm = current.mastery;

  cm += apply_combat_rating_dr( RATING_MASTERY, composite_mastery_rating() / current.rating.mastery );

  for ( auto b : buffs.stat_pct_buffs[ STAT_PCT_BUFF_MASTERY ] )
    cm += b->check_stack_value();

  if ( !is_pet() && !is_enemy() && type != HEALING_ENEMY )
  {
    cm += sim->auras.skyfury->check_value();
  }

  return cm;
}

double player_t::composite_bonus_armor() const
{
  return current.stats.bonus_armor;
}

double player_t::composite_damage_versatility() const
{
  double cdv = current.versatility;

  cdv += apply_combat_rating_dr( RATING_DAMAGE_VERSATILITY,
           composite_damage_versatility_rating() / current.rating.damage_versatility );

  for ( auto b : buffs.stat_pct_buffs[ STAT_PCT_BUFF_VERSATILITY ] )
    cdv += b->check_stack_value();

  if ( buffs.dmf_well_fed )
    cdv += buffs.dmf_well_fed->check_value();

  return cdv;
}

double player_t::composite_heal_versatility() const
{
  double chv = current.versatility;

  chv += apply_combat_rating_dr( RATING_HEAL_VERSATILITY,
           composite_heal_versatility_rating() / current.rating.heal_versatility );

  for ( auto b : buffs.stat_pct_buffs[ STAT_PCT_BUFF_VERSATILITY ] )
    chv += b->check_stack_value();

  if ( buffs.dmf_well_fed )
    chv += buffs.dmf_well_fed->check_value();

  return chv;
}

double player_t::composite_mitigation_versatility() const
{
  double cmv = current.versatility / 2;

  cmv += apply_combat_rating_dr( RATING_MITIGATION_VERSATILITY,
           composite_mitigation_versatility_rating() / current.rating.mitigation_versatility );

  for ( auto b : buffs.stat_pct_buffs[ STAT_PCT_BUFF_VERSATILITY ] )
    cmv += b->check_stack_value() / 2;

  if ( buffs.dmf_well_fed )
    cmv += buffs.dmf_well_fed->check_value() / 2;

  return cmv;
}

double player_t::composite_leech() const
{
  return current.leech + apply_combat_rating_dr( RATING_LEECH, composite_leech_rating() / current.rating.leech );
}

double player_t::composite_run_speed() const
{
  // speed DRs using the following formula:
  double pct = apply_combat_rating_dr( RATING_SPEED, composite_speed_rating() / current.rating.speed );

  double coefficient = std::exp( -.0003 * composite_speed_rating() );

  return pct * coefficient * .1;
}

double player_t::composite_avoidance() const
{
  return apply_combat_rating_dr( RATING_AVOIDANCE, composite_avoidance_rating() / current.rating.avoidance );
}

double player_t::composite_corruption() const
{
  return composite_corruption_rating() / current.rating.corruption;
}

double player_t::composite_corruption_resistance() const
{
  return composite_corruption_resistance_rating() / current.rating.corruption_resistance;
}

double player_t::composite_total_corruption() const
{
  return cache.corruption() - cache.corruption_resistance();
}

double player_t::composite_player_pet_damage_multiplier( const action_state_t*, bool guardian ) const
{
  double m = guardian ? current.guardian_damage_multiplier : current.pet_damage_multiplier;

  return m;
}

double player_t::composite_player_target_pet_damage_multiplier( player_t*, bool ) const
{
  return 1.0;
}

double player_t::composite_player_multiplier( school_e school ) const
{
  double m = current.damage_multiplier[ school ];

  if ( buffs.taste_of_mana && buffs.taste_of_mana->has_common_school( school ) )
    m *= 1.0 + buffs.taste_of_mana->check_value();

  if ( buffs.torrent_of_elements && buffs.torrent_of_elements->has_common_school( school ) )
    m *= 1.0 + buffs.torrent_of_elements->check_value();

  if ( buffs.damage_done && buffs.damage_done->check() )
    m *= 1.0 + buffs.damage_done->check_stack_value();

  if ( buffs.echo_of_eonar && buffs.echo_of_eonar->has_common_school( school ) )
    m *= 1.0 + buffs.echo_of_eonar->check_value();

  if ( buffs.entropic_embrace && buffs.entropic_embrace->check() )
    m *= 1.0 + buffs.entropic_embrace->data().effectN( 1 ).percent();

  return m;
}

double player_t::composite_versus_multiplier( player_t* t ) const
{
  double m = 1.0;

  for ( const auto& entry : buffs.creature_type_buffs )
  {
    // check buff if buff exists, otherwise assume passive
    if ( auto buff = std::get<0>( entry ); buff && !buff->check() )
      continue;

    // check against creature type mask
    if ( std::get<1>( entry ) & ( 1 << ( t->race - 1 ) ) )
    {
      m *= 1.0 + std::get<2>( entry );
    }
  }

  return m;
}

double player_t::composite_player_target_multiplier( player_t* t, school_e /* school */ ) const
{
  double m = 1.0;

  auto td = find_target_data( t );
  if ( td )
  {
    // Always created debuffs, TODO: move to target_specific_debuffs
    m *= 1.0 + td->debuff.condensed_lifeforce->check_value();
    m *= 1.0 + td->debuff.sinful_revelation->check_value();
    m *= 1.0 + td->debuff.scouring_touch->check_stack_value();
    m *= 1.0 + td->debuff.exsanguinated->check_value();

    // target specific debuffs, MUST check for null
    if ( td->debuff.unwavering_focus )
      m *= 1.0 + td->debuff.unwavering_focus->check_value();
  }

  return m;
}

double player_t::composite_player_heal_multiplier( const action_state_t* ) const
{
  double m = current.healing_multiplier;

  if ( buffs.entropic_embrace && buffs.entropic_embrace->check() )
    m *= 1.0 + buffs.entropic_embrace->data().effectN( 3 ).percent();

  return m;
}

double player_t::composite_player_th_multiplier( school_e /* school */ ) const
{
  return 1.0;
}

double player_t::composite_player_absorb_multiplier( const action_state_t* ) const
{
  double m = current.absorb_multiplier;

  if ( buffs.entropic_embrace && buffs.entropic_embrace->check() )
    m *= 1.0 + buffs.entropic_embrace->data().effectN( 4 ).percent();

  return m;
}

double player_t::composite_player_healing_received_multiplier() const
{
  auto m = current.healing_received_multiplier;

  if ( buffs.guardian_spirit && buffs.guardian_spirit->up() )
    m *= 1.0 + buffs.guardian_spirit->check_value();

  return m;
}

double player_t::composite_player_absorb_received_multiplier() const
{
  return current.absorb_received_multiplier;
}

double player_t::composite_player_target_crit_chance( player_t* t ) const
{
  double c = 0.0;

  if ( const actor_target_data_t* td = get_owner_or_self()->find_target_data( t ) )
  {
    // Essence: Blood of the Enemy Major debuff
    c += td->debuff.blood_of_the_enemy->check_stack_value();

    // Consumable: Potion of Focused Resolve
    c += td->debuff.focused_resolve->check_stack_value();

    // Darkmoon Deck: Putrescence
    c += td->debuff.putrid_burst->check_stack_value();
  }

  return c;
}

double player_t::composite_player_critical_damage_multiplier( const action_state_t* /* s */, school_e school ) const
{
  double m = current.crit_damage_multiplier[ school ];

  if ( buffs.elemental_chaos_fire && buffs.elemental_chaos_fire->data().effectN( 2 ).has_common_school( school ) )
    m *= 1.0 + buffs.elemental_chaos_fire->check_value();

  if ( buffs.incensed && buffs.incensed->data().effectN( 1 ).has_common_school( school ) )
    m *= 1.0 + buffs.incensed->check_value();

  // Critical hit damage buff from R3 Blood of the Enemy major on-use
  if ( buffs.seething_rage_essence && buffs.seething_rage_essence->data().effectN( 1 ).has_common_school( school ) )
    m *= 1.0 + buffs.seething_rage_essence->check_value();

  return m;
}

double player_t::composite_player_critical_healing_multiplier() const
{
  double m = current.crit_healing_multiplier;

  if ( buffs.elemental_chaos_frost )
    m *= 1.0 + buffs.elemental_chaos_frost->check_value();

  return m;
}

/**
 * Return the non-stacking movement modifier Increase Speed% (31).
 * These speed buffs do not stack with each other and only the highest one will be applied.
 */
double player_t::non_stacking_movement_modifier() const
{
  double speed = current.non_stacking_movement_speed_modifier;

  // check non-stacking buffs with only a single stack
  for ( auto [ v, b ] : buffs.movement_speed_buffs[ 1 ] )
  {
    if ( speed >= v )
      break;  // no need to check further as buffs should be sorted

    if ( b->check() )
    {
      speed = v;
      break;  // save a cycle
    }
  }

  // check non-stacking buffs with multiple buff stacks
  for ( auto [ v, b ] : buffs.movement_speed_buffs[ 2 ] )
    speed = std::max( v * b->check(), speed );

  return speed;
}

/**
 * Return the sum of all stacking movement modifier Increase Movement Speed% (Stacking) (129)
 */
double player_t::stacking_movement_modifier() const
{
  double speed = current.stacking_movement_speed_modifier;

  // speed tertiary rating
  speed += composite_run_speed();

  for ( auto [ v, b ] : buffs.movement_speed_buffs[ 0 ] )
    if ( b->check() )
      speed += v;

  return speed;
}

double player_t::composite_movement_speed() const
{
  double speed = current.movement_speed;

  double non_stacking = non_stacking_movement_modifier();

  double stacking = stacking_movement_modifier();

  speed *= ( 1 + non_stacking + stacking );

  return speed;
}

double player_t::composite_attribute( attribute_e attr ) const
{
  return current.stats.attribute[ attr ];
}

double player_t::composite_attribute_multiplier( attribute_e attr ) const
{
  double m = current.attribute_multiplier[ attr ];

  if ( is_pet() || is_enemy() || type == HEALING_ENEMY )
    return m;

  if ( ( true_level >= 27 ) && matching_gear )
    m *= matching_gear_multiplier( attr );

  stat_pct_buff_type pct_type = STAT_PCT_BUFF_MAX;
  switch ( attr )
  {
    case ATTR_STRENGTH:
      pct_type = STAT_PCT_BUFF_STRENGTH;
      break;
    case ATTR_AGILITY:
      pct_type = STAT_PCT_BUFF_AGILITY;
      break;
    case ATTR_INTELLECT:
      pct_type = STAT_PCT_BUFF_INTELLECT;
      if ( sim->auras.arcane_intellect->check() )
        m *= 1.0 + sim->auras.arcane_intellect->current_value;
      break;
    case ATTR_SPIRIT:
      pct_type = STAT_PCT_BUFF_SPIRIT;
      break;
    case ATTR_STAMINA:
      pct_type = STAT_PCT_BUFF_STAMINA;
      if ( sim->auras.power_word_fortitude->check() )
      {
        m *= 1.0 + sim->auras.power_word_fortitude->current_value;
      }
      break;
    default:
      break;
  }

  if ( pct_type != STAT_PCT_BUFF_MAX )
  {
    for ( auto b : buffs.stat_pct_buffs[ pct_type ] )
      m *= 1.0 + b->check_stack_value();
  }

  return m;
}

double player_t::composite_rating_multiplier( rating_e rating ) const
{
  return current.rating_multiplier[ rating ];
}

double player_t::composite_rating( rating_e rating ) const
{
  double v = 0;

  // Internally, we treat all the primary rating types as a single entity;
  // in game, they are actually split into spell/ranged/melee
  switch ( rating )
  {
    case RATING_SPELL_CRIT:
    case RATING_MELEE_CRIT:
    case RATING_RANGED_CRIT:
      v = current.stats.crit_rating;
      break;
    case RATING_SPELL_HASTE:
    case RATING_MELEE_HASTE:
    case RATING_RANGED_HASTE:
      v = current.stats.haste_rating;
      break;
    case RATING_SPELL_HIT:
    case RATING_MELEE_HIT:
    case RATING_RANGED_HIT:
      v = current.stats.hit_rating;
      break;
    case RATING_MASTERY:
      v = current.stats.mastery_rating;
      break;
    case RATING_DAMAGE_VERSATILITY:
    case RATING_HEAL_VERSATILITY:
    case RATING_MITIGATION_VERSATILITY:
      v = current.stats.versatility_rating;
      break;
    case RATING_EXPERTISE:
      v = current.stats.expertise_rating;
      break;
    case RATING_DODGE:
      v = current.stats.dodge_rating;
      break;
    case RATING_PARRY:
      v = current.stats.parry_rating;
      break;
    case RATING_BLOCK:
      v = current.stats.block_rating;
      break;
    case RATING_LEECH:
      v = current.stats.leech_rating;
      break;
    case RATING_SPEED:
      v = current.stats.speed_rating;
      break;
    case RATING_AVOIDANCE:
      v = current.stats.avoidance_rating;
      break;
    case RATING_CORRUPTION:
      v = current.stats.corruption_rating;
      break;
    case RATING_CORRUPTION_RESISTANCE:
      v = current.stats.corruption_resistance_rating;
      break;
    default:
      break;
  }

  return util::round( v * composite_rating_multiplier( rating ), 0 );
}

double player_t::composite_player_vulnerability( school_e school ) const
{
  double m = debuffs.invulnerable && debuffs.invulnerable->check() ? 0.0 : 1.0;

  if ( debuffs.vulnerable && debuffs.vulnerable->check() )
    m *= 1.0 + debuffs.vulnerable->check_value();

  // 1% damage taken per stack, arbitrary because this buff is completely fabricated!
  if ( debuffs.damage_taken && debuffs.damage_taken->check() )
    m *= 1.0 + debuffs.damage_taken->current_stack * 0.01;

  if ( debuffs.mystic_touch && debuffs.mystic_touch->has_common_school( school ) )
    m *= 1.0 + debuffs.mystic_touch->check_value();

  if ( debuffs.chaos_brand && debuffs.chaos_brand->has_common_school( school ) )
    m *= 1.0 + debuffs.chaos_brand->check_value();

  if ( debuffs.hunters_mark && debuffs.hunters_mark->has_common_school( school ) )
    m *= 1.0 + debuffs.hunters_mark->check_value();

  return m;
}

double player_t::composite_player_target_armor( player_t* t ) const
{
  double a = t->cache.armor();

  a *= current.armor_penetration;

  return a;
}

double player_t::composite_mitigation_multiplier( const action_state_t* s, school_e school, bool ) const
{
  double m = 1.0;

  if ( !is_enemy() && type != HEALING_ENEMY &&
       ( s->result_type == result_amount_type::DMG_DIRECT || s->result_type == result_amount_type::DMG_OVER_TIME ) )
  {
    if ( !is_pet() )
    {
      if ( buffs.stoneform && buffs.stoneform->up() && school == SCHOOL_PHYSICAL )
        m *= 1.0 + buffs.stoneform->check_value();

      if ( buffs.elemental_chaos_earth && buffs.elemental_chaos_earth->up() )
        m *= 1.0 + buffs.elemental_chaos_earth->check_value();

      if ( buffs.pain_suppression && buffs.pain_suppression->up() )
        m *= 1.0 + buffs.pain_suppression->check_value();
    }

    m *= 1.0 - cache.mitigation_versatility();

    if ( sim->debug )
    {
      sim->print_debug( "{} {} damage to {} reduced by {:.7g}% from versatility.", *s->action->player, *s->action,
                        *s->target, cache.mitigation_versatility() * 100 );
    }

    if ( s->action->is_aoe() )
      m *= 1.0 - cache.avoidance();
  }

  return m;
}

double player_t::composite_mitigation_from_player_multiplier( player_t*, const action_state_t*, school_e, bool ) const
{
  double m = 1.0;

  return m;
}

double player_t::composite_mastery_value() const
{
  assert( cache.active && "Infinite recursion if base composite_mastery_value() is called without stat cache active." );

  return cache.mastery() * mastery_coefficient();
}

#if defined( SC_USE_STAT_CACHE )

/**
 * Invalidate a stat cache, resulting in re-calculation of the composite stat value.
 */
void player_t::invalidate_cache( cache_e c )
{
  if ( !cache.active )
    return;

  sim->print_debug( "{} invalidates stat cache for {}.", *this, c );

  // Special linked invalidations
  switch ( c )
  {
    case CACHE_STRENGTH:
      if ( current.attack_power_per_strength > 0 )
        invalidate_cache( CACHE_ATTACK_POWER );
      if ( current.parry_per_strength > 0 )
        invalidate_cache( CACHE_PARRY );
      break;

    case CACHE_AGILITY:
      if ( current.attack_power_per_agility > 0 )
        invalidate_cache( CACHE_ATTACK_POWER );
      if ( current.dodge_per_agility > 0 )
        invalidate_cache( CACHE_DODGE );
      break;

    case CACHE_INTELLECT:
      if ( current.spell_power_per_intellect > 0 )
        invalidate_cache( CACHE_SPELL_POWER );
      break;

    case CACHE_SPELL_POWER:
      if ( current.attack_power_per_spell_power > 0 )
        invalidate_cache( CACHE_ATTACK_POWER );
      break;

    case CACHE_ATTACK_POWER:
      if ( current.spell_power_per_attack_power > 0 )
        invalidate_cache( CACHE_SPELL_POWER );
      break;

    case CACHE_ATTACK_HASTE:
      invalidate_cache( CACHE_AUTO_ATTACK_SPEED );
      invalidate_cache( CACHE_RPPM_HASTE );
      break;

    case CACHE_SPELL_HASTE:
      invalidate_cache( CACHE_SPELL_CAST_SPEED );
      invalidate_cache( CACHE_RPPM_HASTE );
      break;

    case CACHE_BONUS_ARMOR:
      invalidate_cache( CACHE_ARMOR );
      break;

    case CACHE_CRIT_CHANCE:
      if( current.parry_rating_per_crit_rating > 0 )
        invalidate_cache( CACHE_PARRY );
      break;

    case CACHE_ATTACK_CRIT_CHANCE:
      invalidate_cache( CACHE_RPPM_CRIT );
      break;

    case CACHE_SPELL_CRIT_CHANCE:
      invalidate_cache( CACHE_RPPM_CRIT );
      break;

    default:
      break;
  }

  // Normal invalidation of the corresponding Cache
  switch ( c )
  {
    case CACHE_EXP:
      invalidate_cache( CACHE_ATTACK_EXP );
      invalidate_cache( CACHE_SPELL_HIT );
      break;

    case CACHE_HIT:
      invalidate_cache( CACHE_ATTACK_HIT );
      invalidate_cache( CACHE_SPELL_HIT );
      break;

    case CACHE_CRIT_CHANCE:
      invalidate_cache( CACHE_ATTACK_CRIT_CHANCE );
      invalidate_cache( CACHE_SPELL_CRIT_CHANCE );
      break;

    case CACHE_HASTE:
      invalidate_cache( CACHE_ATTACK_HASTE );
      invalidate_cache( CACHE_SPELL_HASTE );
      break;

    case CACHE_VERSATILITY:
      invalidate_cache( CACHE_DAMAGE_VERSATILITY );
      invalidate_cache( CACHE_HEAL_VERSATILITY );
      invalidate_cache( CACHE_MITIGATION_VERSATILITY );
      break;

    default:
      cache.invalidate( c );
      break;
  }
}
#else
void invalidate_cache( cache_e ) {}
#endif

void player_t::sequence_add_wait( timespan_t wait )
{
  if ( !sim->collect_action_sequence )
    return;

  // Collect iteration#1 data, for log/debug/iterations==1 simulation iteration#0 data
  if ( ( sim->iterations <= 1 && sim->current_iteration == 0 ) || ( sim->iterations > 1 && nth_iteration() == 1 ) )
  {
    if ( collected_data.action_sequence.size() <= sim->expected_max_time() * 2.0 + 3.0 )
    {
      if ( in_combat )
      {
        if ( !collected_data.action_sequence.empty() && collected_data.action_sequence.back().wait_time > 0_ms )
          collected_data.action_sequence.back().wait_time += wait;
        else
          collected_data.action_sequence.emplace_back( sim->current_time(), wait, this );
      }
    }
    else
    {
      assert( false &&
              "Collected too much action sequence data."
              "This means there is a serious overflow of executed actions in the first iteration, which should be "
              "fixed." );
    }
  }
}

void player_t::sequence_add( const action_t* a, const player_t* t )
{
  if ( !sim->collect_action_sequence )
    return;

  // Collect iteration#1 data, for log/debug/iterations==1 simulation iteration#0 data
  if ( ( sim->iterations <= 1 && sim->current_iteration == 0 ) || ( sim->iterations > 1 && nth_iteration() == 1 ) )
  {
    if ( collected_data.action_sequence.size() <= sim->expected_max_time() * 2.0 + 3.0 )
    {
      if ( a->is_precombat )
      {
        auto& data = collected_data.action_sequence_precombat.emplace_back( a, t, sim->current_time(), this );
        a->sequence_add_fn( data.action_reporting, data.target_reporting );
      }
      else
      {
        auto& data = collected_data.action_sequence.emplace_back( a, t, sim->current_time(), this );
        a->sequence_add_fn( data.action_reporting, data.target_reporting );
      }
    }
    else
    {
      assert( false &&
              "Collected too much action sequence data."
              "This means there is a serious overflow of executed actions in the first iteration, which should be "
              "fixed." );
    }
  }
}

void player_t::precombat_init()
{
  precombat_initialized = true;

  sim->print_debug( "Precombat begins for {}.", *this );
  if ( !is_pet() && !is_add() )
  {
    arise();
  }

  init_resources( true );
}

void player_t::combat_begin()
{
  if ( !precombat_initialized )
    precombat_init();

  // Trigger registered pre-pull functions
  for ( const auto& f : precombat_begin_functions )
  {
    f( this );
  }

  // Execute pre-combat actions
  if ( !is_pet() && !is_add() )
  {
    for ( auto& action : precombat_action_list )
    {
      if ( action->action_ready() )
      {
        if ( action->harmful )
        {
          if ( first_cast )
          {
            if ( !is_enemy() )
              sequence_add( action, action->target );

            action->execute();
            first_cast = false;
          }
          else
          {
            sim->print_debug( "{} attempting to cast multiple harmful spells during pre-combat.", *this );
          }
        }
        else
        {
          if ( !is_enemy() )
            sequence_add( action, action->target );

          action->execute();
        }
      }
      if ( in_combat && ( action->channeled || action->travel_time() == timespan_t::zero() ) )
        break;
    }
  }
  first_cast = false;

  sim->print_debug( "Combat begins for {}.", *this );

  if ( !precombat_action_list.empty() )
    enter_combat();

  // re-initialize collected_data.health_changes.previous_*_level
  // necessary because food/flask are counted as resource gains, and thus provide phantom
  // gains on the timeline if not corrected
  collected_data.health_changes.previous_gain_level     = 0.0;
  // forcing a resource timeline data collection in combat_end() seems to have rendered this next line unnecessary
  collected_data.health_changes.previous_loss_level     = 0.0;

  for ( size_t i = 0, end = collected_data.combat_start_resource.size(); i < end; ++i )
  {
    collected_data.combat_start_resource[ i ].add( resources.current[ i ] );
  }

  // Trigger registered combat-begin functions
  for ( const auto& f : combat_begin_functions)
  {
    f( this );
  }
}

void player_t::combat_end()
{
  for ( auto* pet : pet_list )
  {
    pet->combat_end();
  }

  if ( !is_pet() )
  {
    demise();
  }
  else
    cast_pet()->dismiss();

  sim->print_debug( "Combat ends for {} at time {} fight_length={}", *this,
                           sim->current_time(), iteration_fight_length );

  // Defer parent actor find to combat end, and ensure it is only performed if the parent sim is
  // initialized. This will avoid a data race in case the main thread for some reason is in init
  // phase, while a child thread is already done (their init). Note that this may mean that with
  // target_error option, some data to estimate the target error can be missed (in the main thread).
  // In turn, lazily finding the parent actor here ensures that the performance hit on the init
  // process is minimal.
  if ( parent == nullptr && !is_pet() && !is_enemy() && sim->parent != nullptr &&
      sim->parent->is_initialized() && sim->thread_index > 0 )
  {
    // NOTE NOTE NOTE: This search can no longer be run based on find_player() because it uses
    // actor_list. Ever since pet_spawner support, the actor_list of the parent sim can (and will)
    // change during run-time. This can cause iterator breakage (vector capacity increase), causing
    // a crash.
    //
    // Since the parent actor is only necessary for real player characters, we can instead look at
    // player_no_pet_list, which is guaranteed to be static after initialization (for now ...).
    auto it = range::find_if( sim->parent->player_no_pet_list, [ this ]( const player_t* p ) {
      return name_str == p->name_str;
    } );

    if ( it != sim->parent->player_no_pet_list.end() )
    {
      parent = *it;
    }
  }
}

/**
 * Begin data collection for statistics.
 */
void player_t::datacollection_begin()
{
  // Check whether the actor was arisen at least once during the _previous_ iteration
  // Note that this check is dependant on sim_t::combat_begin() having
  // sim_t::datacollection_begin() call before the player_t::combat_begin() calls.
  if ( !requires_data_collection() )
    return;

  sim->print_debug( "Data collection begins for {} (id={})", *this, index );

  iteration_fight_length                = timespan_t::zero();
  iteration_waiting_time                = timespan_t::zero();
  iteration_pooling_time                = timespan_t::zero();
  iteration_executed_foreground_actions = 0;
  iteration_dmg                         = 0;
  priority_iteration_dmg                = 0;
  iteration_heal                        = 0;
  iteration_absorb                      = 0.0;
  iteration_absorb_taken                = 0.0;
  iteration_dmg_taken                   = 0;
  iteration_heal_taken                  = 0;
  active_during_iteration               = false;

  range::fill( iteration_resource_lost, 0.0 );
  range::fill( iteration_resource_gained, 0.0 );
  range::fill( iteration_resource_overflowed, 0.0 );

  if ( collected_data.health_changes.collect )
  {
    collected_data.health_changes.timeline.clear();  // Drop Data
    collected_data.health_changes.timeline_normalized.clear();
  }

  range::for_each( buff_list, std::mem_fn( &buff_t::datacollection_begin ) );
  range::for_each( stats_list, std::mem_fn( &stats_t::datacollection_begin ) );
  range::for_each( uptime_list, std::mem_fn( &uptime_t::datacollection_begin ) );
  range::for_each( benefit_list, std::mem_fn( &benefit_t::datacollection_begin ) );
  range::for_each( proc_list, std::mem_fn( &proc_t::datacollection_begin ) );
  range::for_each( pet_list, std::mem_fn( &pet_t::datacollection_begin ) );
  range::for_each( sample_data_list, std::mem_fn( &sample_data_helper_t::datacollection_begin ) );
  range::for_each( cooldown_waste_data_list, std::mem_fn( &cooldown_waste_data_t::datacollection_begin ) );
}

/**
 * End data collection for statistics.
 */
void player_t::datacollection_end()
{
  // This checks if the actor was arisen at least once during this iteration.
  if ( !requires_data_collection() )
    return;

  for ( auto* pet : pet_list )
    pet->datacollection_end();

  if ( arise_time >= timespan_t::zero() )
  {
    // If we collect data while the player is still alive, capture active time up to now
    assert( sim->current_time() >= arise_time );
    iteration_fight_length += sim->current_time() - arise_time;
    arise_time = sim->current_time();
  }

  range::for_each( spawners, []( spawner::base_actor_spawner_t* spawn ) {
    spawn->datacollection_end();
  } );

  sim->print_debug( "Data collection ends for {} (id={}) at time {} fight_length={}", *this, index,
                           sim->current_time(), iteration_fight_length );

  for ( auto& stats : stats_list )
  {
    stats->datacollection_end();
  }

  if ( !is_enemy() && !is_add() && type != HEALING_ENEMY )
  {
    sim->iteration_dmg += iteration_dmg;
    sim->priority_iteration_dmg += priority_iteration_dmg;
    sim->iteration_heal += iteration_heal;
    sim->iteration_absorb += iteration_absorb;
  }

  // make sure TMI-relevant timeline lengths all match for tanks
  if ( !is_enemy() && !is_pet() && type != HEALING_ENEMY && primary_role() == ROLE_TANK )
  {
    collected_data.timeline_healing_taken.add( sim->current_time(), 0.0 );
    collected_data.timeline_dmg_taken.add( sim->current_time(), 0.0 );
    collected_data.health_changes.timeline.add( sim->current_time(), 0.0 );
    collected_data.health_changes.timeline_normalized.add( sim->current_time(), 0.0 );
  }
  collected_data.collect_data( *this );

  range::for_each( buff_list, std::mem_fn( &buff_t::datacollection_end ) );

  for ( auto& uptime : uptime_list )
  {
    uptime->datacollection_end( iteration_fight_length );
  }

  range::for_each( benefit_list, std::mem_fn( &benefit_t::datacollection_end ) );
  range::for_each( proc_list, std::mem_fn( &proc_t::datacollection_end ) );
  range::for_each( sample_data_list, std::mem_fn( &sample_data_helper_t::datacollection_end ) );
  range::for_each( cooldown_waste_data_list, std::mem_fn( &cooldown_waste_data_t::datacollection_end ) );
}

// player_t::merge ==========================================================

namespace
{
namespace buff_merge
{
// a < b iff ( a.name < b.name || ( a.name == b.name && a.source < b.source ) )
bool compare( const buff_t* a, const buff_t* b )
{
  assert( a );
  assert( b );

  if ( a->name_str < b->name_str )
    return true;
  if ( b->name_str < a->name_str )
    return false;

  // NULL and player are identically considered "bottom" for source comparison
  bool a_is_bottom = ( !a->source || a->source == a->player );
  bool b_is_bottom = ( !b->source || b->source == b->player );

  if ( a_is_bottom )
    return !b_is_bottom;

  if ( b_is_bottom )
    return false;

  // If neither source is bottom, order by source index
  return a->source->index < b->source->index;
}

// Sort buff_list and check for uniqueness
void prepare( player_t& p )
{
  range::sort( p.buff_list, compare );
  // For all i, p.buff_list[ i ] <= p.buff_list[ i + 1 ]

#ifndef NDEBUG
  if ( p.buff_list.empty() )
    return;

  for ( size_t i = 0, last = p.buff_list.size() - 1; i < last; ++i )
  {
    // We know [ i ] <= [ i + 1 ] due to sorting; if also
    // ! ( [ i ] < [ i + 1 ] ), then [ i ] == [ i + 1 ].
    if ( !compare( p.buff_list[ i ], p.buff_list[ i + 1 ] ) )
    {
      p.sim->error( "{} has duplicate buffs named '{}' with source '{}' - the end is near.", p,
                     p.buff_list[ i ]->name(), p.buff_list[ i ]->source_name() );
    }
  }
#endif
}

void report_unmatched( [[maybe_unused]] const buff_t& b )
{
#ifndef NDEBUG
  /* Don't complain about targetdata buffs, since it is perfectly viable that the buff
   * is not created in another thread, because of our on-demand targetdata creation
   */
  if ( !b.source || b.source == b.player )
  {
    b.sim->error( "{} can't merge buff '{}' with source '{}'.", *b.player, b.name(), b.source_name() );
  }
#endif
}

void check_tail( [[maybe_unused]] player_t& p, [[maybe_unused]] size_t first )
{
#ifndef NDEBUG
  for ( size_t last = p.buff_list.size(); first < last; ++first )
    report_unmatched( *p.buff_list[ first ] );
#endif
}

// Merge stats of matching buffs from right into left.
void merge( player_t& left, player_t& right )
{
  prepare( left );
  prepare( right );

  // Both buff_lists are sorted, join them mergesort-style.
  size_t i = 0;
  size_t j = 0;
  while ( i < left.buff_list.size() && j < right.buff_list.size() )
  {
    if ( compare( left.buff_list[ i ], right.buff_list[ j ] ) )
    {
      // [ i ] < [ j ]
      report_unmatched( *left.buff_list[ i ] );
      ++i;
    }
    else if ( compare( right.buff_list[ j ], left.buff_list[ i ] ) )
    {
      // [ i ] > [ j ]
      report_unmatched( *right.buff_list[ j ] );
      ++j;
    }
    else
    {
      // [ i ] == [ j ]
      left.buff_list[ i ]->merge( *right.buff_list[ j ] );
      ++i, ++j;
    }
  }

  check_tail( left, i );
  check_tail( right, j );
}

}  // namespace buff_merge
}  // namespace

/**
 * Merge player data with player from other thread.
 *
 * After simulating the same setup in multiple sim/threads, this function will merge the same player (and its
 * collected data) from two simulations together, aggregating the collected data.
 */
void player_t::merge( player_t& other )
{
  collected_data.merge( other );

  for ( resource_e i = RESOURCE_NONE; i < RESOURCE_MAX; ++i )
  {
    iteration_resource_lost[ i ] += other.iteration_resource_lost[ i ];
    iteration_resource_gained[ i ] += other.iteration_resource_gained[ i ];
    iteration_resource_overflowed[ i ] += other.iteration_resource_overflowed[ i ];
  }

  buff_merge::merge( *this, other );

  // Procs
  for ( size_t i = 0; i < proc_list.size(); ++i )
  {
    proc_t& proc = *proc_list[ i ];
    if ( proc_t* other_proc = other.find_proc( proc.name_str ) )
      proc.merge( *other_proc );
    else
    {
#ifndef NDEBUG
      sim->error( "{} can't merge proc '{}'.", *this, proc.name() );
#endif
    }
  }

  // Gains
  for ( size_t i = 0; i < gain_list.size(); ++i )
  {
    gain_t& gain = *gain_list[ i ];
    if ( gain_t* other_gain = other.find_gain( gain.name_str ) )
      gain.merge( *other_gain );
    else
    {
#ifndef NDEBUG
      sim->error( "{} can't merge gain '{}'.", *this, gain.name() );
#endif
    }
  }

  // Stats
  for ( size_t i = 0; i < stats_list.size(); ++i )
  {
    stats_t& stats = *stats_list[ i ];
    if ( stats_t* other_stats = other.find_stats( stats.name_str ) )
      stats.merge( *other_stats );
    else
    {
#ifndef NDEBUG
      sim->error( "{} can't merge stats '{}'", *this, stats.name() );
#endif
    }
  }

  // Uptimes
  for ( size_t i = 0; i < uptime_list.size(); ++i )
  {
    uptime_t& uptime = *uptime_list[ i ];
    if ( uptime_t* other_uptime = other.find_uptime( uptime.name_str ) )
      uptime.merge( *other_uptime );
    else
    {
#ifndef NDEBUG
      sim->error( "{} can't merge uptime '{}'.", *this, uptime.name() );
#endif
    }
  }

  // Benefits
  for ( size_t i = 0; i < benefit_list.size(); ++i )
  {
    benefit_t& benefit = *benefit_list[ i ];
    if ( benefit_t* other_benefit = other.find_benefit( benefit.name_str ) )
      benefit.merge( *other_benefit );
    else
    {
#ifndef NDEBUG
      sim->error( "{} can't merge benefit '{}'.", *this, benefit.name() );
#endif
    }
  }

  // Sample Data
  for ( size_t i = 0; i < sample_data_list.size(); ++i )
  {
    sample_data_helper_t& sd = *sample_data_list[ i ];
    if ( sample_data_helper_t* other_sd = other.find_sample_data( sd.name_str ) )
      sd.merge( *other_sd );
    else
    {
#ifndef NDEBUG
      sim->error("{} can't merge proc '{}'.", *this, sd.name_str );
#endif
    }
  }

  // Action Map
  size_t n_entries = std::min( action_list.size(), other.action_list.size() );
  if ( action_list.size() != other.action_list.size() )
  {
    sim->error( "{} can't merge action lists: size differs (other={}, size={}, other.size={})!", *this,
                 other.name(), action_list.size(), other.action_list.size() );
  }

  for ( size_t i = 0; i < n_entries; ++i )
  {
    if ( action_list[ i ]->internal_id == other.action_list[ i ]->internal_id )
    {
      action_list[ i ]->total_executions += other.action_list[ i ]->total_executions;
    }
    else
    {
      sim->error(
          "{} can't merge action {}::{} with {}::{} because ids do not match.", *this,
          action_list[ i ]->action_list ? action_list[ i ]->action_list->name_str.c_str() : "(none)",
          action_list[ i ]->signature_str,
          other.action_list[ i ]->action_list ? other.action_list[ i ]->action_list->name_str.c_str() : "(none)",
          other.action_list[ i ]->signature_str );
    }
  }

  // Cooldown waste data
  for ( size_t i = 0; i < cooldown_waste_data_list.size(); i++ )
  {
    const auto& ours   = cooldown_waste_data_list[ i ];
    const auto& theirs = other.cooldown_waste_data_list[ i ];
    assert( ours->cd->name_str == theirs->cd->name_str );
    ours->merge( *theirs );
  }
}

/**
 * Reset player. Called after each iteration to reset the player to its initial state.
 */
void player_t::reset()
{
  sim->print_debug( "Resetting {}.", *this );

  last_cast = timespan_t::zero();
  gcd_ready = timespan_t::zero();
  off_gcd_ready = timespan_t::min();
  cast_while_casting_ready = timespan_t::min();

  cache.invalidate_all();

  // Reset current stats to initial stats
  current = initial;

  current.sleeping = true;

  change_position( initial.position );

  // Restore default target
  target = default_target;

  sim->print_debug( "{} resets current stats ( reset to initial ): {}", *this, current );

  for ( auto& buff : buff_list )
    buff->reset();

  last_foreground_action = nullptr;
  spell_queued_action = nullptr;
  spell_queue_event = nullptr;
  prev_gcd_actions.clear();
  off_gcdactions.clear();

  first_cast = true;

  executing       = nullptr;
  queueing        = nullptr;
  channeling      = nullptr;
  demise_event    = nullptr;
  readying        = nullptr;
  strict_sequence = nullptr;
  off_gcd         = nullptr;
  cast_while_casting_poll_event = nullptr;
  in_combat       = false;

  if ( sim->fight_style == FIGHT_STYLE_DUNGEON_ROUTE || sim->fight_style == FIGHT_STYLE_DUNGEON_SLICE )
    in_boss_encounter = 0;
  else
    in_boss_encounter = 1;

  current_execute_type = execute_type::FOREGROUND;

  current_auto_attack_speed = 1.0;
  gcd_current_haste_value   = 1.0;
  gcd_type = gcd_haste_type::NONE;

  cast_delay_reaction = timespan_t::zero();
  cast_delay_occurred = timespan_t::zero();

  main_hand_weapon.buff_type  = 0;
  main_hand_weapon.buff_value = 0;
  main_hand_weapon.bonus_dmg  = 0;

  off_hand_weapon.buff_type  = 0;
  off_hand_weapon.buff_value = 0;
  off_hand_weapon.bonus_dmg  = 0;

  assert( default_x_position != std::numeric_limits<decltype(default_x_position)>::lowest() );
  assert( default_y_position != std::numeric_limits<decltype(default_y_position)>::lowest() );
  x_position = default_x_position;
  y_position = default_y_position;

  callbacks.reset();

  init_resources( true );

  // Variable optimization must be done before action expression optimization (occurs in
  // action_t::reset) since action expression optimization may reference the variables.
  if ( sim->optimize_expressions && nth_iteration() == 1 )
  {
    range::for_each( variables, []( action_variable_t* var ) { var->optimize(); } );
  }

  range::for_each( action_list, []( action_t* action ) { action->reset(); } );

  range::for_each( cooldown_list, []( cooldown_t* cooldown ) { cooldown->reset_init(); } );

  range::for_each( target_specific_cooldown_list, []( target_specific_cooldown_t* tcd ) { tcd->reset(); } );

  range::for_each( dot_list, []( dot_t* dot ) { dot->reset(); } );

  range::for_each( stats_list, []( stats_t* stat ) { stat->reset(); } );

  range::for_each( uptime_list, []( uptime_t* uptime ) { uptime->reset(); } );

  range::for_each( proc_list, []( proc_t* proc ) { proc->reset(); } );

  range::for_each( proc_rng_list, []( proc_rng_t* prng ) { prng->reset( reset_type_e::ITERATION ); } );

  range::for_each( spawners, []( spawner::base_actor_spawner_t* obj ) { obj->reset(); } );

  precombat_initialized = false;
  potion_used = false;
  leech_pool = 0;

  item_cooldown -> reset( false );

  incoming_damage.clear();

  resource_threshold_trigger = nullptr;

  for ( auto& elem : variables )
    elem->reset();

#ifndef NDEBUG
  for ( auto& elem : active_dots )
  {
    assert( elem == 0 );
  }
#endif

  if ( active_action_list != default_action_list )
  {
    active_action_list = default_action_list;
  }

  if ( active_off_gcd_list && active_off_gcd_list != default_action_list )
  {
    active_off_gcd_list = default_action_list;
  }

  if ( active_cast_while_casting_list && active_cast_while_casting_list != default_action_list )
  {
    active_cast_while_casting_list = default_action_list;
  }

  reset_resource_callbacks();
}

void player_t::trigger_ready()
{
  if ( ready_type == READY_POLL )
    return;

  if ( readying )
    return;
  if ( executing )
    return;
  if ( queueing )
    return;
  if ( channeling )
    return;
  if ( started_waiting < timespan_t::zero() )
    return;
  if ( current.sleeping )
    return;
  if ( !active_during_iteration )
    return;
  if ( sim->event_mgr.canceled )
    return;

  if ( buffs.stunned->check() )
    return;
  if ( is_moving() )
    return;

  sim->print_debug( "{} is triggering ready, interval={}", *this, ( sim->current_time() - started_waiting ) );

  iteration_waiting_time += sim->current_time() - started_waiting;
  started_waiting = timespan_t::min();

  schedule_ready( available() );
}

void player_t::schedule_off_gcd_ready( timespan_t delta_time )
{
  if ( delta_time < 0_ms )
    delta_time = timespan_t::from_millis( rng().gauss( 100, 10 ) );

  if ( active_off_gcd_list == nullptr )
  {
    return;
  }

  if ( current_execute_type != execute_type::OFF_GCD )
  {
    return;
  }

  // Already polling, do nothing
  if ( off_gcd )
  {
    return;
  }

  // Casting or channeling something
  if ( executing || channeling )
  {
    return;
  }

  if ( !readying )
  {
    return;
  }

  // No time left to perform a poll event before GCD elapses
  if ( sim->current_time() + delta_time >= readying->occurs() )
  {
    return;
  }

  // No off-gcd cooldown will be ready during this GCD interval
  if ( off_gcd_ready >= readying->occurs() )
  {
    return;
  }

  assert( cast_while_casting_poll_event == nullptr );

  off_gcd = make_event<player_gcd_event_t>( *sim, *this, delta_time );
}

void player_t::schedule_cwc_ready( timespan_t delta_time )
{
  if ( delta_time < 0_ms )
    delta_time = timespan_t::from_millis( rng().gauss( 100, 10 ) );

  if ( active_cast_while_casting_list == nullptr )
  {
    return;
  }

  if ( current_execute_type != execute_type::CAST_WHILE_CASTING )
  {
    return;
  }

  // Already polling, do nothing
  if ( cast_while_casting_poll_event )
  {
    return;
  }

  // Not casting, or channeling anything, nor trying to find something to do
  if ( ( !executing || !executing->execute_event ) && !channeling && !readying )
  {
    return;
  }

  // Figure out a safe threshold where the poller should not trigger any more, based on the next
  // ready event (actor finding something to do), when the channel ends, or when the current cast
  // ends.
  timespan_t threshold;
  if ( readying )
  {
    threshold = readying->occurs();
  }
  else if ( channeling )
  {
    threshold = sim->current_time() + channeling->get_dot()->remains();
    threshold += sim->channel_lag.mean + 4 * sim->channel_lag.stddev;
  }
  else
  {
    threshold = executing->execute_event->occurs();
  }

  // No cast while casting ability cd ready before the threshold finishes
  if ( cast_while_casting_ready >= threshold )
  {
    return;
  }

  // No time left to perform a poll event before the threshold finishes
  if ( sim->current_time() + delta_time >= threshold )
  {
    return;
  }

  assert( off_gcd == nullptr );

  cast_while_casting_poll_event = make_event<player_cwc_event_t>( *sim, *this, delta_time );
}

/**
 * Player is ready to perform another action.
 */
void player_t::schedule_ready( timespan_t delta_time, bool waiting )
{
  if ( readying )
  {
    throw sc_runtime_error( fmt::format( "{} scheduled ready while already ready.", *this ) );
  }

  action_t* was_executing = ( channeling ? channeling : executing );

  if ( queueing )
  {
    sim->print_debug( "{} canceling queued action '{}' at {}", *this, queueing->name(),
                      queueing->queue_event->occurs() );
    event_t::cancel( queueing->queue_event );
    queueing = nullptr;
  }

  if ( current.sleeping )
    return;

  executing     = nullptr;
  queueing      = nullptr;
  channeling    = nullptr;
  action_queued = false;

  started_waiting = timespan_t::min();

  timespan_t gcd_adjust = gcd_ready - ( sim->current_time() + delta_time );
  if ( gcd_adjust > 0_ms )
    delta_time += gcd_adjust;

  if ( waiting )
  {
    if ( !is_enemy() )
      sequence_add_wait( delta_time );

    iteration_waiting_time += delta_time;
  }
  else
  {
    timespan_t lag = 0_ms;

    if ( last_foreground_action )
    {
      if ( last_foreground_action->ability_lag.mean > 0_ms )
      {
        timespan_t ability_lag = rng().gauss( last_foreground_action->ability_lag );
        timespan_t gcd_lag = rng().gauss( sim->gcd_lag );
        timespan_t diff    = ( gcd_ready + gcd_lag ) - ( sim->current_time() + ability_lag );
        if ( diff > 0_ms && sim->strict_gcd_queue )
        {
          lag = gcd_lag;
        }
        else
        {
          lag           = ability_lag;
          action_queued = true;
        }
      }
      else if ( last_foreground_action->channeled && last_foreground_action->apply_channel_lag &&
                !last_foreground_action->interrupt_immediate_occurred )
      {
        lag = rng().gauss( sim->channel_lag );
      }
      else if ( last_foreground_action->gcd() == 0_ms && !last_foreground_action->add_queue_lag )
      {
        lag = 0_ms;
      }
      else
      {
        timespan_t gcd_lag   = rng().gauss( sim->gcd_lag );
        timespan_t queue_lag = rng().gauss( sim->queue_lag );

        timespan_t diff = ( gcd_ready + gcd_lag ) - ( sim->current_time() + queue_lag );

        if ( diff > timespan_t::zero() && sim->strict_gcd_queue )
        {
          lag = gcd_lag;
        }
        else
        {
          lag           = queue_lag;
          action_queued = true;
        }
      }
    }

    if ( lag < 0_ms )
      lag = 0_ms;

    if ( type == PLAYER_GUARDIAN )
      lag = 0_ms;  // Guardians do not seem to feel the effects of queue/gcd lag in WoD.

    delta_time += lag;
  }

  if ( last_foreground_action && last_foreground_action->gcd() > 0_ms )
  {
    // This is why "total_execute_time" is not tracked per-target!
    last_foreground_action->stats->iteration_total_execute_time += delta_time;
  }

  readying = make_event<player_ready_event_t>( *sim, *this, delta_time );

  if ( was_executing && was_executing->gcd() > 0_ms && !was_executing->background &&
       !was_executing->proc && !was_executing->repeating )
  {
    // Record the last ability use time for cast_react
    cast_delay_occurred = readying->occurs();
    if ( !is_pet() )
    {
      cast_delay_reaction = rng().gauss( brain_lag );
    }
    else
    {
      cast_delay_reaction = 0_ms;
    }

    sim->print_debug( "{} {} schedule_ready(): cast_finishes={} cast_delay={}", *this,
                             was_executing->name_str, readying->occurs(),
                             cast_delay_reaction );
  }
}

/**
 * Player arises from the dead.
 */
void player_t::arise()
{
  sim->print_log( "{} tries to arise.", *this );

  if ( !initial.sleeping )
    current.sleeping = false;

  if ( current.sleeping )
    return;

  actor_spawn_index = sim->global_spawn_index++;

  sim->print_log( "{} arises. Spawn Index={}", *this, actor_spawn_index );

  init_resources( true );

  cache.invalidate_all();

  demise_event = nullptr;
  readying = nullptr;
  off_gcd  = nullptr;
  cast_while_casting_poll_event = nullptr;

  arise_time = sim->current_time();
  last_regen = sim->current_time();

  if ( is_enemy() )
  {
    sim->active_enemies++;
    sim->target_non_sleeping_list.push_back( this );

    // When an enemy arises, trigger players to potentially acquire a new target
    range::for_each( sim->player_non_sleeping_list, [this]( player_t* p ) { p->acquire_target( retarget_source::ACTOR_ARISE, this ); } );

    if ( sim->overrides.chaos_brand && debuffs.chaos_brand )
      debuffs.chaos_brand->override_buff();
    if ( sim->overrides.mystic_touch && debuffs.mystic_touch )
      debuffs.mystic_touch->override_buff();
    if ( sim->overrides.bleeding && debuffs.bleeding )
      debuffs.bleeding->override_buff( 1, 1.0 );
    if ( sim->overrides.mortal_wounds && debuffs.mortal_wounds )
      debuffs.mortal_wounds->override_buff();
  }
  else
  {
    sim->active_allies++;
    sim->player_non_sleeping_list.push_back( this );

    // Find a target to shoot on. This is to ensure that transient friendly allies (such as dynamic
    // pets) can cope with a situation, where the primary target for example is invulnerable, so
    // they need to figure out a (more valid) target to shoot spells on.
    acquire_target( retarget_source::SELF_ARISE );
  }

  // ready_type READY_TRIGGER may already have scheduled a ready event, so we need to check if we are already
  // readying.
  if ( !readying && has_foreground_actions( *this ) )
    schedule_ready();

  active_during_iteration = true;

  for ( auto callback : callbacks.all_callbacks )
  {
    dbc_proc_callback_t* cb = debug_cast<dbc_proc_callback_t*>( callback );

    if ( cb->cooldown && cb->effect.item && cb->effect.item->parsed.initial_cd > timespan_t::zero() )
    {
      timespan_t initial_cd = std::min( cb->effect.cooldown(), cb->effect.item->parsed.initial_cd );
      cb->cooldown->start( initial_cd );

      if ( sim->log )
      {
        sim->out_log.printf( "%s sets initial cooldown for %s to %.2f seconds.", name(), cb->effect.name().c_str(),
                             initial_cd.total_seconds() );
      }
    }
  }

  current_auto_attack_speed = cache.auto_attack_speed();

  if ( consumables.flask && consumables.flask_action )
    consumables.flask_action->execute();
  if ( consumables.food && consumables.food_action )
    consumables.food_action->execute();
  if ( consumables.augmentation && consumables.augmentation_action )
    consumables.augmentation_action->execute();

  // Requires index-based lookup since on-arise callbacks may
  // insert new on-arise callbacks to the vector.
  for ( size_t i = 0; i < callbacks_on_arise.size(); ++i ) // NOLINT(modernize-loop-convert)
  {
    auto& cb = callbacks_on_arise[ i ];
    // If the callback comes from a different actor, execute it only
    // if that actor is active.
    if ( this == cb.first || cb.first->is_active() )
      cb.second();
  }
}

timespan_t player_t::available() const
{
  return timespan_t::from_millis( rng().gauss( 100, 10 ) );
}

/**
 * Player dies.
 */
void player_t::demise()
{
  // No point in demising anything if we're not even active
  if ( current.sleeping )
    return;

  leave_combat();

  current.sleeping = true;

  if ( sim->log )
    sim->out_log.printf( "%s demises.. Spawn Index=%u", name(), actor_spawn_index );

  /* Do not reset spawn index, because the player can still have damaging events ( dots ) which
   * need to be associated with eg. resolve Diminishing Return list.
   */

  if ( arise_time >= 0_ms )
  {
    iteration_fight_length += sim->current_time() - arise_time;
  }
  // Arise time has to be set to default value before actions are canceled.
  arise_time               = timespan_t::min();
  current.distance_to_move = 0;

  event_t::cancel( readying );
  event_t::cancel( off_gcd );
  event_t::cancel( cast_while_casting_poll_event );

  if ( is_enemy() )
  {
    sim->active_enemies--;
    sim->target_non_sleeping_list.find_and_erase( this );

    // When an enemy dies, trigger players to acquire a new target
    range::for_each( sim->player_non_sleeping_list,
                     [ this ]( player_t* p ) { p->acquire_target( retarget_source::ACTOR_DEMISE, this ); } );
  }
  else
  {
    sim->active_allies--;
    sim->player_non_sleeping_list.find_and_erase_unordered( this );
  }

  // If an enemy mob dies, trigger on-kill callback on all active players
  if ( is_enemy() )
  {
    for ( auto p : sim->player_non_sleeping_list )
    {
      // Use index-based lookup since on-kill callbacks may insert new on-kill callbacks to the vector
      for ( size_t i = 0; i < p->callbacks_on_kill.size(); ++i )  // NOLINT(modernize-loop-convert)
      {
        p->callbacks_on_kill[ i ]( this );
      }
    }
  }

  // Requires index-based lookup since on-demise callbacks may
  // insert new on-demise callbacks to the vector.
  for ( size_t i = 0; i < callbacks_on_demise.size(); ++i ) // NOLINT(modernize-loop-convert)
  {
    auto& cb = callbacks_on_demise[ i ];
    // If the callback comes from a different actor, execute it only
    // if that actor is active.
    if ( this == cb.first || cb.first->is_active() )
      cb.second( this );
  }

  for ( size_t i = 0; i < buff_list.size(); ++i )
    buff_list[ i ]->cancel();

  for ( size_t i = 0; i < action_list.size(); ++i )
    action_list[ i ]->cancel();

  // sim -> cancel_events( this );

  for ( auto* pet : pet_list )
  {
    pet->demise();
  }

  for ( size_t i = 0; i < dot_list.size(); ++i )
    dot_list[ i ]->cancel();

}

// Player enters/leaves "combat". Primarily relevant for DungeonSlice/DungeonRoute sims where "combat" is defined as
// sim_t::target_non_sleeping_list.size() > 0
// Use index-based lookup since enter/leaving combat may insert new combat state callbacks to the vector
void player_t::enter_combat()
{
  if ( in_combat )
    return;

  if ( sim->target_non_sleeping_list.size() == 0 )
    return;

  in_combat = true;

  sim->print_log( "{} enters combat.", *this );

  for ( size_t i = 0; i < callbacks_on_combat_state.size(); ++i )
    callbacks_on_combat_state[ i ]( this, in_combat );

  if ( race == RACE_NIGHT_ELF && buffs.shadowmeld->check() )
    buffs.shadowmeld->expire();
}

void player_t::leave_combat()
{
  if ( !in_combat )
    return;

  in_combat = false;

  sim->print_log( "{} leaves combat.", *this );

  for ( size_t i = 0; i < callbacks_on_combat_state.size(); ++i )
    callbacks_on_combat_state[ i ]( this, in_combat );
}

/**
 * Player is being interrupted.
 */
void player_t::interrupt()
{
  // FIXME! Players will need to override this to handle background repeating actions.

  if ( sim->log )
    sim->out_log.printf( "%s is interrupted", name() );

  if ( executing )
    executing->interrupt_action();
  if ( queueing )
    queueing->interrupt_action();
  if ( channeling )
    channeling->interrupt_action();

  event_t::cancel( cast_while_casting_poll_event );

  if ( strict_sequence )
  {
    strict_sequence->cancel();
    strict_sequence = nullptr;
  }
  if ( buffs.stunned->check() )
  {
    if ( readying )
      event_t::cancel( readying );
    if ( off_gcd )
      event_t::cancel( off_gcd );

    current_execute_type = execute_type::FOREGROUND;
  }
  else
  {
    if ( !readying && !current.sleeping )
      schedule_ready();

    if ( current_execute_type == execute_type::CAST_WHILE_CASTING )
    {
      current_execute_type = execute_type::OFF_GCD;
      schedule_off_gcd_ready( timespan_t::zero() );
    }
  }
}

void player_t::halt()
{
  if ( sim->log )
    sim->out_log.printf( "%s is halted", name() );

  interrupt();

  if ( main_hand_attack )
    main_hand_attack->cancel();
  if ( off_hand_attack )
    off_hand_attack->cancel();
}

void player_t::stun()
{
  halt();
}

void player_t::moving()
{
  halt();
}

void player_t::finish_moving()
{
}

void player_t::clear_debuffs()
{
  if ( sim->log )
    sim->out_log.printf( "%s clears debuffs", name() );

  // Clear Dots
  for ( size_t i = 0; i < dot_list.size(); ++i )
  {
    dot_t* dot = dot_list[ i ];
    dot->cancel();
  }

  // Clear all debuffs
  for ( buff_t* buff : buff_list )
  {
    if ( buff->source != this )
    {
      buff->expire();
    }
  }
}

action_t* player_t::execute_action()
{
  assert( !readying );

  action_t* action = nullptr;

  if (resource_regeneration == regen_type::DYNAMIC)
    do_dynamic_regen();

  if ( strict_sequence )
  {
    // Committed to a strict sequence of actions, just perform them instead of a priority list
    action = strict_sequence;
  }
  else if ( enable_spell_queue && spell_queued_action )
  {
    if ( spell_queued_action->ready() )
      action = spell_queued_action;
    spell_queued_action = nullptr;
  }
  else
  {
    visited_apls_ = 0;  // Reset visited apl list
    action = select_action( *active_action_list, execute_type::FOREGROUND );
  }

  last_foreground_action = action;

  if ( restore_action_list != nullptr )
  {
    activate_action_list( restore_action_list, restore_action_list_type );
    restore_action_list = nullptr;
  }

  if ( action )
  {
    action->line_cooldown->start();
    action->queue_execute( execute_type::FOREGROUND );
    if ( !action->quiet )
    {
      iteration_executed_foreground_actions++;
      action->total_executions++;

      if ( action->trigger_gcd > timespan_t::zero() )
        prev_gcd_actions.push_back( action );
      else
        off_gcdactions.push_back( action );

      if ( !is_add() && ( !is_pet() || collect_pet_sequence_data ) )
        sequence_add( action, action->target );
    }
  }

  return action;
}

void player_t::regen( timespan_t periodicity )
{
  if (resource_regeneration == regen_type::DYNAMIC&& sim->debug )
  {
    sim->print_debug( "{} dynamic regen, last={:.3f} interval={:.3f}", name(), last_regen.total_seconds(),
                      periodicity.total_seconds() );
  }

  for ( resource_e r = RESOURCE_HEALTH; r < RESOURCE_MAX; r++ )
  {
    if ( resources.active_resource[ r ] )
    {
      double regen  = resource_regen_per_second( r );
      gain_t* gain = gains.resource_regen[ r ];

      if ( gain && regen )
        resource_gain( r, regen * periodicity.total_seconds(), gain );
    }
  }
}

double player_t::get_stat_value(stat_e stat)
{
  switch (stat)
  {
  case STAT_STRENGTH:
    return cache.strength();
  case STAT_AGILITY:
    return cache.agility();
  case STAT_INTELLECT:
    return cache.intellect();
  case STAT_SPELL_POWER:
    return cache.spell_power( SCHOOL_NONE );
  case STAT_ATTACK_POWER:
    return cache.attack_power();
  case STAT_CRIT_RATING:
    return composite_melee_crit_rating();
  case STAT_HASTE_RATING:
    return composite_melee_haste_rating();
  case STAT_MASTERY_RATING:
    return composite_mastery_rating();
  case STAT_VERSATILITY_RATING:
    return composite_damage_versatility_rating();
  case STAT_ARMOR:
    return cache.armor();
  default:
    break;
  }

  return 0.0;
}

void player_t::collect_resource_timeline_information()
{
  for ( auto& elem : collected_data.resource_timelines )
  {
    elem.timeline.add( sim->current_time(), resources.current[ elem.type ] );
  }

  collected_data.health_pct.add( sim->current_time(), health_percentage() );

  for ( auto& elem : collected_data.stat_timelines )
  {
    auto value = get_stat_value(elem.type);
    elem.timeline.add(sim->current_time(), value);
  }
}

double player_t::resource_loss( resource_e resource_type, double amount, gain_t* source, action_t* )
{
  if ( amount == 0 )
    return 0.0;

  if ( current.sleeping )
    return 0.0;

  if ( resource_type && resource_type == primary_resource() )
    uptimes.primary_resource_cap->update( false, sim->current_time() );

  double actual_amount;
  double previous_amount;
  double previous_pct_points;
  bool check_callbacks = has_active_resource_callbacks;

  if ( check_callbacks )
  {
    previous_amount = resources.current[ resource_type ];
    previous_pct_points = resources.current[ resource_type ] / resources.max[ resource_type ] * 100.0;
  }

  if ( !resources.is_infinite( resource_type ) || is_enemy() )
  {
    actual_amount = std::min( amount, resources.current[ resource_type ] );
    resources.current[ resource_type ] -= actual_amount;
    iteration_resource_lost[ resource_type ] += actual_amount;
  }
  else
  {
    actual_amount = amount;
    resources.current[ resource_type ] -= actual_amount;
    iteration_resource_lost[ resource_type ] += actual_amount;
  }

  if ( source )
  {
    source->add( resource_type, actual_amount * -1, ( amount - actual_amount ) * -1 );
  }

  if ( resource_type == RESOURCE_MANA )
  {
    last_cast = sim->current_time();
  }

  if ( check_callbacks )
  {
    check_resource_change_for_callback( resource_type, previous_amount, previous_pct_points );
  }

  if ( sim->debug )
    sim->print_debug( "Player {} loses {:.2f} ({:.2f}) {}. pct={:.2f}% ({:.2f}/{:.2f})",
                      name(), actual_amount, amount, resource_type,
                      resources.max[ resource_type ] ? resources.pct( resource_type ) * 100 : 0,
                      resources.current[ resource_type ], resources.max[ resource_type ] );

  return actual_amount;
}

double player_t::resource_gain( resource_e resource_type, double amount, gain_t* source, action_t* action )
{
  if ( current.sleeping || amount == 0.0 )
    return 0.0;

  double actual_amount = std::min( amount, resources.max[ resource_type ] - resources.current[ resource_type ] );
  double previous_amount;
  double previous_pct_points;
  bool check_callbacks = has_active_resource_callbacks;

  if ( check_callbacks )
  {
    previous_amount     = resources.current[ resource_type ];
    previous_pct_points = resources.current[ resource_type ] / resources.max[ resource_type ] * 100.0;
  }

  if ( actual_amount > 0.0 )
  {
    resources.current[ resource_type ] += actual_amount;
    iteration_resource_gained[ resource_type ] += actual_amount;
  }
  double overflow_amount = amount - actual_amount;
  if ( overflow_amount > 0 )
  {
    iteration_resource_overflowed[ resource_type ] += overflow_amount;
  }

  if ( resource_type && resource_type == primary_resource() &&
       resources.max[ resource_type ] <= resources.current[ resource_type ] )
    uptimes.primary_resource_cap->update( true, sim->current_time() );

  if ( source )
  {
    source->add( resource_type, actual_amount, amount - actual_amount );
  }

  if ( check_callbacks )
  {
    check_resource_change_for_callback( resource_type, previous_amount, previous_pct_points );
  }

  if ( sim->log )
  {
    sim->print_log( "{} gains {:.2f} ({:.2f}) {} from {} ({:.2f}/{:.2f})",
                    name(), actual_amount, amount, resource_type,
                    source ? source->name() : action ? action->name() : "unknown",
                    resources.current[ resource_type ], resources.max[ resource_type ] );
  }

  return actual_amount;
}

bool player_t::resource_available( resource_e resource_type, double cost ) const
{
  if ( resource_type == RESOURCE_NONE || cost <= 0 || resources.is_infinite( resource_type ) )
  {
    return true;
  }

  bool available = resources.current[ resource_type ] >= cost;

#ifndef NDEBUG
  if ( !resources.active_resource[ resource_type ] )
  {
    assert( available && "Insufficient inactive resource to cast!" );
  }
#endif

  return available;
}

void player_t::recalculate_resource_max( resource_e resource_type, gain_t* source )
{
  double old_amount = resources.current[ resource_type ];
  double old_max    = resources.max[ resource_type ];

  resources.max[ resource_type ] = resources.base[ resource_type ];
  resources.max[ resource_type ] *= resources.base_multiplier[ resource_type ];
  resources.max[ resource_type ] += total_gear.resource[ resource_type ];
  resources.max[ resource_type ] += resources.temporary[ resource_type ];

  switch ( resource_type )
  {
    case RESOURCE_HEALTH:
    {
      // Calculate & set maximum health
      resources.max[ resource_type ] += floor( stamina() ) * current.health_per_stamina;

      // Make sure the player starts combat with full health
      if ( !in_combat )
        resources.current[ resource_type ] = resources.max[ resource_type ];
      break;
    }
    default:
      break;
  }

  resources.max[ resource_type ] *= resources.initial_multiplier[ resource_type ];

  // Sanity check on current values
  if ( source && resources.current[ resource_type ] > resources.max[ resource_type ] )
  {
    // Track overflow from loss if applicable
    source->add( resource_type, 0, resources.current[ resource_type ] - resources.max[ resource_type ] );
  }
  resources.current[ resource_type ] = std::min( resources.current[ resource_type ], resources.max[ resource_type ] );

  sim->print_debug( "Recalculated maximum {} for {}: old={:.2f}/{:.2f}, new={:.2f}/{:.2f}",
                    util::resource_type_string( resource_type ), name(), old_amount, old_max,
                    resources.current[ resource_type ], resources.max[ resource_type ] );
}

role_e player_t::primary_role() const
{
  return role;
}

const char* player_t::primary_tree_name() const
{
  return dbc::specialization_string( specialization() );
}

bool player_t::has_hero_tree( hero_tree_e hero ) const
{
  return player_sub_trees.count( static_cast<unsigned>( hero ) );
}

bool player_t::has_shield_equipped() const
{
  return items[ SLOT_OFF_HAND ].parsed.data.item_class == ITEM_CLASS_ARMOR &&
         items[ SLOT_OFF_HAND ].parsed.data.item_subclass == ITEM_SUBCLASS_ARMOR_SHIELD;
}

bool player_t::record_healing() const
{
  return role == ROLE_TANK || role == ROLE_HEAL || sim -> enable_dps_healing;
}

/**
 * Scale factor normalization stat.
 *
 * Determine the stat by which scale factors are normalized, so that this stat will get a value of 1.0.
 */
stat_e player_t::normalize_by() const
{
  if ( sim->normalized_stat != STAT_NONE )
    return sim->normalized_stat;

  const scale_metric_e sm = this->sim->scaling->scaling_metric;

  switch ( primary_role() )
  {
    case ROLE_SPELL:
    case ROLE_HEAL:
      return STAT_INTELLECT;
    case ROLE_TANK:
      if ( sm == SCALE_METRIC_DEATHS && scaling->scaling[ sm ].get_stat( STAT_STAMINA ) != 0.0 )
        return STAT_STAMINA;
      SC_FALLTHROUGH;
    default:
      switch ( type )
      {
        case DRUID:
        case HUNTER:
        case SHAMAN:
        case ROGUE:
        case MONK:
        case DEMON_HUNTER:
          return STAT_AGILITY;
        case DEATH_KNIGHT:
        case PALADIN:
        case WARRIOR:
          return STAT_STRENGTH;
        default:
          return STAT_ATTACK_POWER;
      }
  }
}

double player_t::health_percentage() const
{
  return resources.pct( RESOURCE_HEALTH ) * 100;
}

double player_t::max_health() const
{
  return resources.max[ RESOURCE_HEALTH ];
}

double player_t::current_health() const
{
  return resources.current[ RESOURCE_HEALTH ];
}

timespan_t player_t::time_to_percent( double percent ) const
{
  // Adjust time_to_0/time_to_die expressions to point to the death_pct, if applicable
  if ( percent == 0.0 )
    percent = death_pct;

  // Early exit if we're already at the relevant health percentage
  if ( health_percentage() <= percent )
    return timespan_t::zero();

  timespan_t time_to_percent;

  if ( iteration_dmg_taken > 0.0 && resources.base[ RESOURCE_HEALTH ] > 0 &&
       sim->current_time() >= timespan_t::from_seconds( 1.0 ) && !sim->fixed_time )
  {
    // If not using fixed_time and we have tracked damage intake, use the incoming DPS to predict
    double ttp = ( resources.current[ RESOURCE_HEALTH ] - ( percent * 0.01 * resources.base[ RESOURCE_HEALTH ] ) ) /
      ( iteration_dmg_taken / sim->current_time().total_seconds() );
    time_to_percent = timespan_t::from_seconds( ttp );
  }
  else
  {
    // Otherwise, just use the simulation length as a basis for the predictions
    time_to_percent = sim->expected_iteration_time * ( 1.0 - percent * 0.01 ) - sim->current_time();
  }

  if ( time_to_percent < timespan_t::zero() )
    return timespan_t::zero();

  return time_to_percent;
}

timespan_t player_t::total_reaction_time()
{
  return std::min( reaction_max, reaction_offset + rng().exgauss( reaction, reaction_nu ) );
}

void player_t::stat_gain( stat_e stat, double amount, gain_t* gain, action_t* action, bool temporary_stat )
{
  if ( amount <= 0 )
    return;

  // bail out if this is a stat that doesn't work for this class
  if ( convert_hybrid_stat( stat ) == STAT_NONE )
    return;

  int temp_value = temporary_stat ? 1 : 0;

  cache_e cache_type = cache_from_stat( stat );
  if (resource_regeneration == regen_type::DYNAMIC&& regen_caches[ cache_type ] )
    do_dynamic_regen( true );

  sim->print_log( "{} gains {:.2f} {}{}", name(), amount, stat,
                  temporary_stat ? " (temporary)" : "" );

  switch ( stat )
  {
    case STAT_STAMINA:
    case STAT_STRENGTH:
    case STAT_AGILITY:
    case STAT_INTELLECT:
    case STAT_AGI_INT:
    case STAT_STR_AGI:
    case STAT_STR_INT:
    case STAT_STR_AGI_INT:
    case STAT_SPIRIT:
    case STAT_SPELL_POWER:
    case STAT_ATTACK_POWER:
    case STAT_EXPERTISE_RATING:
    case STAT_HIT_RATING:
    case STAT_CRIT_RATING:
    case STAT_ARMOR:
    case STAT_BONUS_ARMOR:
    case STAT_DODGE_RATING:
    case STAT_PARRY_RATING:
    case STAT_BLOCK_RATING:
    case STAT_MASTERY_RATING:
    case STAT_VERSATILITY_RATING:
    case STAT_LEECH_RATING:
    case STAT_AVOIDANCE_RATING:
    case STAT_SPEED_RATING:
    case STAT_CORRUPTION_RESISTANCE:
      current.stats.add_stat( stat, amount );
      invalidate_cache( cache_type );
      break;

    case STAT_HASTE_RATING:
    {
      current.stats.add_stat( stat, amount );
      invalidate_cache( cache_type );

      adjust_dynamic_cooldowns();
      // adjust_global_cooldown( gcd_type::HASTE_ANY );
      adjust_auto_attack(gcd_haste_type::HASTE );
      break;
    }

    case STAT_ALL:
      for ( attribute_e i = ATTRIBUTE_NONE; i < ATTRIBUTE_MAX; i++ )
      {
        current.stats.attribute[ i ] += amount;
        invalidate_cache( static_cast<cache_e>( i ) );
      }
      break;

    case STAT_HEALTH:
    case STAT_MANA:
    case STAT_RAGE:
    case STAT_ENERGY:
    case STAT_FOCUS:
    case STAT_RUNIC:
    {
      resource_e r =
          ( ( stat == STAT_HEALTH )
                ? RESOURCE_HEALTH
                : ( stat == STAT_MANA )
                      ? RESOURCE_MANA
                      : ( stat == STAT_RAGE ) ? RESOURCE_RAGE
                                              : ( stat == STAT_ENERGY )
                                                    ? RESOURCE_ENERGY
                                                    : ( stat == STAT_FOCUS ) ? RESOURCE_FOCUS : RESOURCE_RUNIC_POWER );
      resource_gain( r, amount, gain, action );
    }
    break;

    case STAT_MAX_HEALTH:
    case STAT_MAX_MANA:
    case STAT_MAX_RAGE:
    case STAT_MAX_ENERGY:
    case STAT_MAX_FOCUS:
    case STAT_MAX_RUNIC:
    {
      resource_e r = ( ( stat == STAT_MAX_HEALTH )
                           ? RESOURCE_HEALTH
                           : ( stat == STAT_MAX_MANA )
                                 ? RESOURCE_MANA
                                 : ( stat == STAT_MAX_RAGE )
                                       ? RESOURCE_RAGE
                                       : ( stat == STAT_MAX_ENERGY )
                                             ? RESOURCE_ENERGY
                                             : ( stat == STAT_MAX_FOCUS ) ? RESOURCE_FOCUS : RESOURCE_RUNIC_POWER );

      resources.temporary[ r ] += temp_value * amount;
      recalculate_resource_max( r );
      resource_gain( r, amount, gain, action );
    }
    break;

    // Unused but known stats to prevent asserting
    case STAT_RESILIENCE_RATING:
      break;

    default:
      assert( false );
      break;
  }

  switch ( stat )
  {
    case STAT_STAMINA:
    case STAT_ALL:
    {
      recalculate_resource_max( RESOURCE_HEALTH );
      // Adjust current health to new max on stamina gains, if the actor is not in combat
      if ( !in_combat )
      {
        double delta = resources.max[ RESOURCE_HEALTH ] - resources.current[ RESOURCE_HEALTH ];
        resource_gain( RESOURCE_HEALTH, delta );
      }
      break;
    }
    default:
      break;
  }

  if ( sim->debug )
  {
    sim->out_debug.print( "{} stats: {}", name(), current.stats );
  }
}

void player_t::stat_loss( stat_e stat, double amount, gain_t* gain, action_t* action, bool temporary_buff )
{
  if ( amount <= 0 )
    return;

  // bail out if this is a stat that doesn't work for this class
  if ( convert_hybrid_stat( stat ) == STAT_NONE )
    return;

  cache_e cache_type = cache_from_stat( stat );
  if (resource_regeneration == regen_type::DYNAMIC&& regen_caches[ cache_type ] )
    do_dynamic_regen( true );

  sim->print_log( "{} loses {:.2f} {}{}", name(), amount, stat,
                  temporary_buff ? " (temporary)" : "" );

  int temp_value = temporary_buff ? 1 : 0;
  switch ( stat )
  {
    case STAT_STAMINA:
    case STAT_STRENGTH:
    case STAT_AGILITY:
    case STAT_INTELLECT:
    case STAT_AGI_INT:
    case STAT_STR_AGI:
    case STAT_STR_INT:
    case STAT_STR_AGI_INT:
    case STAT_SPIRIT:
    case STAT_SPELL_POWER:
    case STAT_ATTACK_POWER:
    case STAT_EXPERTISE_RATING:
    case STAT_HIT_RATING:
    case STAT_CRIT_RATING:
    case STAT_ARMOR:
    case STAT_BONUS_ARMOR:
    case STAT_DODGE_RATING:
    case STAT_PARRY_RATING:
    case STAT_BLOCK_RATING:
    case STAT_MASTERY_RATING:
    case STAT_VERSATILITY_RATING:
    case STAT_LEECH_RATING:
    case STAT_AVOIDANCE_RATING:
    case STAT_SPEED_RATING:
    case STAT_CORRUPTION_RESISTANCE:
      current.stats.add_stat( stat, -amount );
      invalidate_cache( cache_type );
      break;

    case STAT_ALL:
      for ( attribute_e i = ATTRIBUTE_NONE; i < ATTRIBUTE_MAX; i++ )
      {
        current.stats.attribute[ i ] -= amount;
        invalidate_cache( (cache_e)i );
      }
      break;

    case STAT_HEALTH:
    case STAT_MANA:
    case STAT_RAGE:
    case STAT_ENERGY:
    case STAT_FOCUS:
    case STAT_RUNIC:
    {
      resource_e r =
          ( ( stat == STAT_HEALTH )
                ? RESOURCE_HEALTH
                : ( stat == STAT_MANA )
                      ? RESOURCE_MANA
                      : ( stat == STAT_RAGE ) ? RESOURCE_RAGE
                                              : ( stat == STAT_ENERGY )
                                                    ? RESOURCE_ENERGY
                                                    : ( stat == STAT_FOCUS ) ? RESOURCE_FOCUS : RESOURCE_RUNIC_POWER );
      resource_loss( r, amount, gain, action );
    }
    break;

    case STAT_MAX_HEALTH:
    case STAT_MAX_MANA:
    case STAT_MAX_RAGE:
    case STAT_MAX_ENERGY:
    case STAT_MAX_FOCUS:
    case STAT_MAX_RUNIC:
    {
      resource_e r = ( ( stat == STAT_MAX_HEALTH )
                           ? RESOURCE_HEALTH
                           : ( stat == STAT_MAX_MANA )
                                 ? RESOURCE_MANA
                                 : ( stat == STAT_MAX_RAGE )
                                       ? RESOURCE_RAGE
                                       : ( stat == STAT_MAX_ENERGY )
                                             ? RESOURCE_ENERGY
                                             : ( stat == STAT_MAX_FOCUS ) ? RESOURCE_FOCUS : RESOURCE_RUNIC_POWER );

      resources.temporary[ r ] -= temp_value * amount;
      recalculate_resource_max( r );
      double delta = resources.current[ r ] - resources.max[ r ];
      if ( delta > 0 )
        resource_loss( r, delta, gain, action );
    }
    break;

    case STAT_HASTE_RATING:
    {
      current.stats.haste_rating -= amount;
      invalidate_cache( cache_type );

      adjust_dynamic_cooldowns();
      // adjust_global_cooldown( gcd_type::HASTE_ANY );
      adjust_auto_attack(gcd_haste_type::HASTE );
      break;
    }

    // Unused but known stats to prevent asserting
    case STAT_RESILIENCE_RATING:
      break;

    default:
      assert( false );
      break;
  }

  switch ( stat )
  {
    case STAT_STAMINA:
    case STAT_ALL:
    {
      recalculate_resource_max( RESOURCE_HEALTH );
      // Adjust current health to new max on stamina gains
      double delta = resources.current[ RESOURCE_HEALTH ] - resources.max[ RESOURCE_HEALTH ];
      if ( delta > 0 )
        resource_loss( RESOURCE_HEALTH, delta, gain, action );
      break;
    }
    default:
      break;
  }

  if ( sim->debug )
  {
    sim->out_debug.print( "{} stats: {}", name(), current.stats );
  }
}

void player_t::cost_reduction_gain( school_e school, double amount, gain_t* /* gain */, action_t* /* action */ )
{
  if ( amount <= 0 )
    return;

  sim->print_log( "{} gains a cost reduction of {:.1f} on abilities of school {}", name(), amount, school );

  if ( school > SCHOOL_MAX_PRIMARY )
  {
    for ( school_e i = SCHOOL_NONE; ++i < SCHOOL_MAX_PRIMARY; )
    {
      if ( util::school_type_component( school, i ) )
      {
        current.resource_reduction[ i ] += amount;
      }
    }
  }
  else
  {
    current.resource_reduction[ school ] += amount;
  }
}

void player_t::cost_reduction_loss( school_e school, double amount, action_t* /* action */ )
{
  if ( amount <= 0 )
    return;

  sim->print_log( "{} loses a cost reduction of {:.1f} on abilities of school {}", name(), amount, school );

  if ( school > SCHOOL_MAX_PRIMARY )
  {
    for ( school_e i = SCHOOL_NONE; ++i < SCHOOL_MAX_PRIMARY; )
    {
      if ( util::school_type_component( school, i ) )
      {
        current.resource_reduction[ i ] -= amount;
      }
    }
  }
  else
  {
    current.resource_reduction[ school ] -= amount;
  }
}

namespace {
namespace assess_dmg_helper_functions
{
void account_parry_haste( player_t& p, action_state_t* s )
{
  if ( !p.is_enemy() )
  {
    // Parry Haste accounting
    if ( s->result == RESULT_PARRY )
    {
      if ( p.main_hand_attack && p.main_hand_attack->execute_event )
      {
        // Parry haste mechanics:  When parrying an attack, the game subtracts 40% of the player's base swing timer
        // from the time remaining on the current swing timer.  However, this effect cannot reduce the current swing
        // timer to less than 20% of the base value.  The game uses hasted values.  To illustrate that, two examples:
        // base weapon speed: 2.6, 30% haste, thus base swing timer is 2.6/1.3=2.0 seconds
        // 1) if we parry when the current swing timer has 1.8 seconds remaining, then it gets reduced by 40% of 2.0,
        // or 0.8 seconds,
        //    and the current swing timer becomes 1.0 seconds.
        // 2) if we parry when the current swing timer has 1.0 second remaining the game tries to subtract 0.8
        // seconds, but hits the
        //    minimum value (20% of 2.0, or 0.4 seconds.  The current swing timer becomes 0.4 seconds.
        // Thus, the result is that the current swing timer becomes
        // max(current_swing_timer-0.4*base_swing_timer,0.2*base_swing_timer)

        // the reschedule_execute(x) function we call to perform this tries to reschedule the effect such that it
        // occurs at (sim->current_time() + x).  Thus we need to give it the difference between sim->current_time()
        // and the new target of execute_event->occurs(). That value is simply the remaining time on the current swing
        // timer.

        // first, we need the hasted base swing timer, swing_time
        timespan_t swing_time = p.main_hand_attack->time_to_execute;

        // and we also need the time remaining on the current swing timer
        timespan_t current_swing_timer = p.main_hand_attack->execute_event->occurs() - p.sim->current_time();

        // next, check that the current swing timer is longer than 0.2*swing_time - if not we do nothing
        if ( current_swing_timer > 0.20 * swing_time )
        {
          // now we apply parry-hasting.  Subtract 40% of base swing timer from current swing timer
          current_swing_timer -= 0.40 * swing_time;

          // enforce 20% base swing timer minimum
          current_swing_timer = std::max( current_swing_timer, 0.20 * swing_time );

          // now reschedule the event and log a parry haste
          p.main_hand_attack->reschedule_execute( current_swing_timer );
          p.procs.parry_haste->occur();
        }
      }
    }
  }
}

bool absorb_sort( absorb_buff_t* a, absorb_buff_t* b )
{
  double lv = a->current_value;
  double rv = b->current_value;
  if ( lv == rv )
  {
    return a->name_str < b->name_str;
  }

  return lv < rv;
}

void account_absorb_buffs( player_t& p, action_state_t* s, school_e school )
{
  /* ABSORB BUFFS

     std::vector<absorb_buff_t*> absorb_buff_list; is a dynamic vector, which contains
     the currently active absorb buffs of a player.

     std:map<int,instant_absorb_t*> instant_absorb_list; is a map by spell id that contains
     the data for instant absorb effects.

     std::vector<int> absorb_priority; is a vector that contains the sequencing for
     high priority (tank) absorbs and instant absorbs, by spell ID. High priority and
     instant absorbs MUST be pushed into this array inside init_absorb_priority() to
     function.

  */

  if ( !( p.absorb_buff_list.empty() && p.instant_absorb_list.empty() ) )
  {
    /* First, handle high priority absorbs and instant absorbs. These absorbs should
       obey the sequence laid out in absorb_priority. To achieve this, we loop through
       absorb_priority in order, then find and apply the appropriate high priority
       or instant absorb. */
    for ( size_t i = 0; i < p.absorb_priority.size(); i++ )
    {
      // Check for the absorb ID in instantaneous absorbs first, since its low cost.
      auto it = p.instant_absorb_list.find( p.absorb_priority[ i ] );
      if ( it != p.instant_absorb_list.end() )
      {
        instant_absorb_t& ab = it->second;

        // eligibility is handled in the instant absorb's handler
        double absorbed = ab.consume( s );

        s->result_amount -= absorbed;
        s->self_absorb_amount += absorbed;

        if ( p.sim->debug && s->action && !s->target->is_enemy() && !s->target->is_add() && absorbed != 0 )
          p.sim->print_debug( "Damage to {} after {} is {:.6f}", s->target->name(), ab.name, s->result_amount );
      }
      else
      {
        // Check for the absorb ID in high priority absorbs.
        for ( size_t j = 0; j < p.absorb_buff_list.size(); j++ )
        {
          if ( p.absorb_buff_list[ j ]->data().id() == p.absorb_priority[ i ] )
          {
            absorb_buff_t* ab = p.absorb_buff_list[ j ];

            assert( ab->high_priority && "Absorb buff with set priority is not flagged for high priority." );

            if ( ( ( ab->eligibility && ab->eligibility( s ) )  // Use the eligibility function if there is one
                   || ( school == SCHOOL_NONE ||
                        dbc::is_school( ab->absorb_school, school ) ) )  // Otherwise check by school
                 && ab->up() )
            {
              double absorbed = ab->consume( s->result_amount, s );

              s->result_amount -= absorbed;

              // track result using only self-absorbs separately
              if ( ab->source == &p || p.is_my_pet( ab->source ) )
                s->self_absorb_amount += absorbed;

              if ( p.sim->debug && s->action && !s->target->is_enemy() && !s->target->is_add() && absorbed != 0 )
                p.sim->print_debug( "Damage to {} after {} is {:.6f}", s->target->name(), ab->name(), s->result_amount );
            }

            if ( ab->current_value <= 0 )
              ab->expire();

            break;
          }
        }
      }

      if ( s->result_amount <= 0 )
      {
        assert( s->result_amount == 0 );
        break;
      }
    }

    // Second, we handle any low priority absorbs. These absorbs obey the rule of "smallest first".

    // Sort the absorbs by size, then we can loop through them in order.
    range::sort( p.absorb_buff_list, absorb_sort );
    size_t offset = 0;

    while ( offset < p.absorb_buff_list.size() && s->result_amount > 0 && !p.absorb_buff_list.empty() )
    {
      absorb_buff_t* ab = p.absorb_buff_list[ offset ];

      /* Check absorb eligbility by school and custom eligibility function, skipping high priority
         absorbs since those have already been processed above. */
      if ( ab->high_priority ||
           ( ab->eligibility && !ab->eligibility( s ) )  // Use the eligibility function if there is one
           || ( school != SCHOOL_NONE && !dbc::is_school( ab->absorb_school, school ) ) )  // Otherwise check by school
      {
        offset++;
        continue;
      }

      // Don't be too paranoid about inactive absorb buffs in the list. Just expire them
      if ( ab->up() )
      {
        // Consume the absorb and grab the effective amount consumed.
        double absorbed = ab->consume( s->result_amount, s );

        s->result_amount -= absorbed;

        // track result using only self-absorbs separately
        if ( ab->source == &p || p.is_my_pet( ab->source ) )
          s->self_absorb_amount += absorbed;

        if ( p.sim->debug && s->action && !s->target->is_enemy() && !s->target->is_add() )
          p.sim->print_debug( "Damage to {} after {} is {:.6f}", s->target->name(), ab->name(), s->result_amount );

        if ( s->result_amount <= 0 )
        {
          // Buff is not fully consumed
          assert( s->result_amount == 0 );
          break;
        }
      }

      // So, it turns out it's possible to have absorb buff behavior, where
      // there's a "minimum value" for the absorb buff, even after absorbing
      // damage more than its current value. In this case, the absorb buff should
      // not be expired, as the current_value still has something left.
      if ( ab->current_value <= 0 )
      {
        ab->expire();
        assert( p.absorb_buff_list.empty() || p.absorb_buff_list[ 0 ] != ab );
      }
      else
        offset++;
    }  // end of absorb list loop
  }

  p.iteration_absorb_taken += s->self_absorb_amount;

  s->result_absorbed = s->result_amount;
}

/**
 * Statistical data collection for damage taken.
 */
void collect_dmg_taken_data( player_t& p, const action_state_t* s, double /* result_ignoring_external_absorbs */ )
{
  p.iteration_dmg_taken += s->result_amount;

  // collect data for timelines
  p.collected_data.timeline_dmg_taken.add( p.sim->current_time(), s->result_amount );

  // tank-specific data storage
  if ( p.collected_data.health_changes.collect )
  {
    // health_changes covers everything, used for ETMI and other things
    p.collected_data.health_changes.timeline.add( p.sim->current_time(), s->result_amount );
    p.collected_data.health_changes.timeline_normalized.add( p.sim->current_time(),
                                                             s->result_amount / p.resources.max[ RESOURCE_HEALTH ] );

    // store value in incoming damage array for conditionals
    p.incoming_damage.push_back( {p.sim->current_time(), s->result_amount, s->action->get_school()} );
  }
}
}  // namespace assess_dmg_helper_functions

}

void player_t::assess_damage( school_e school, result_amount_type rt, action_state_t* s )
{
  using namespace assess_dmg_helper_functions;

  account_parry_haste( *this, s );

  if ( s->result_amount <= 0.0 )
    return;

  target_mitigation( school, rt, s );

  // store post-mitigation, pre-absorb value
  s->result_mitigated = s->result_amount;

  if ( sim->debug && s->action && !s->target->is_enemy() && !s->target->is_add() )
  {
    sim->print_debug( "{} {} damage to {} after mitigation is {}.", *s->action->player, *s->action, *this,
                      s->result_amount );
  }

  assess_damage_imminent_pre_absorb( school, rt, s );

  account_absorb_buffs( *this, s, school );

  assess_damage_imminent( school, rt, s );
}

void player_t::do_damage( action_state_t* incoming_state )
{
  using namespace assess_dmg_helper_functions;

  action_t* incoming_action = incoming_state->action;

  collect_dmg_taken_data( *this, incoming_state,
                          incoming_state->result_mitigated - incoming_state->self_absorb_amount );

  if ( incoming_state->result_amount > 0.0 )
    resource_loss( RESOURCE_HEALTH, incoming_state->result_amount, nullptr, incoming_action );

  // New callback system; proc abilities on incoming events.
  if ( incoming_action && incoming_action->callbacks && incoming_action->target_callbacks &&
       ( !incoming_action->suppress_target_procs || incoming_action->enable_proc_from_suppressed ) )
  {
    proc_types pt = incoming_state->proc_type();
    if ( pt != PROC1_INVALID )
    {
      // On damage/heal in. Proc flags are arranged as such that the "incoming"
      // version of the primary proc flag is always follows the outgoing version...
      proc_types pt_taken = static_cast<proc_types>( pt + 1 );
      // ...except for PROC1_HELPFUL_PERIODIC_TAKEN
      if ( pt == PROC1_HELPFUL_PERIODIC )
        pt_taken = PROC1_HELPFUL_PERIODIC_TAKEN;

      // only direct damage triggers obey proc-related trigger attributes
      auto pt_type = incoming_action->proc_trigger_type( pt_taken, TRIGGER_ACTION_TAKEN );

      // Because most procs in simc default to using PROC2_LANDED for most proc types,
      // trigger the execute_proc_type2() here to ensure that those procs will work.
      proc_types2 execute_pt2 = incoming_state->execute_proc_type2();
      if ( execute_pt2 != PROC2_INVALID )
        trigger_callbacks( pt_taken, execute_pt2, incoming_action, incoming_state, pt_type );

      // Additionally, trigger the impact_proc_type2() so that periodic effects and
      // procs not using execute proc types will also work.
      proc_types2 impact_pt2 = incoming_state->impact_proc_type2();
      if ( impact_pt2 != PROC2_INVALID )
        trigger_callbacks( pt_taken, impact_pt2, incoming_action, incoming_state, pt_type );
    }
  }

  // Check if target is dying
  if ( !demise_event && health_percentage() <= death_pct && !resources.is_infinite( RESOURCE_HEALTH ) )
  {
    if ( !current.sleeping )
      collected_data.deaths.add( sim->current_time().total_seconds() );

    if ( sim->log )
      sim->out_log.printf( "%s has died.", name() );

    make_event<player_demise_event_t>( *sim, *this );
  }
}

void player_t::assess_damage_imminent_pre_absorb( school_e, result_amount_type, action_state_t* )
{
}

void player_t::assess_damage_imminent( school_e, result_amount_type, action_state_t* )
{
}

void player_t::target_mitigation( school_e, result_amount_type dmg_type, action_state_t* s )
{
  if ( s->result_amount == 0 )
    return;

  if ( debuffs.invulnerable && debuffs.invulnerable->check() )
  {
    s->result_amount = 0;
    return;
  }

  if ( dmg_type == result_amount_type::DMG_OVER_TIME )
  {
    s->result_amount *= s->target_mitigation_ta_multiplier;
  }
  else if ( dmg_type == result_amount_type::DMG_DIRECT )
  {
    s->result_amount *= s->target_mitigation_da_multiplier;

    if ( !s->action )
      return;

    // Armor
    if ( auto armor = s->target_armor )
    {
      double resist = util::calculate_armor_resist( armor, s->action->player->current.armor_coeff );
      s->result_amount *= 1.0 - resist;

      if ( sim->debug )
      {
        sim->print_debug( "{} {} damage to {} reduced by {:.7g}% from armor (armor={:.7g}, armor coeff={:.7g}).",
                          *s->action->player, *s->action, *s->target, resist * 100, armor,
                          s->action->player->current.armor_coeff );
      }
    }

    // Block and Crit Block work in the same manner as armor and are affected by the same cap
    if ( s->block_result == BLOCK_RESULT_BLOCKED )
    {
      double block_value = s->target_block_value;
      double block_resist = util::calculate_armor_resist( block_value, s->action->player->current.armor_coeff );

      block_resist = clamp( block_resist, 0.0, MAX_ARMOR_DAMAGE_REDUCTION );
      s->result_amount *= 1.0 - block_resist;

      if ( sim->debug )
      {
        sim->print_debug( "{} {} damage to {} reduced by {:.7g}% from block (block value={:.7g}, armor coeff={:.7g}).",
                          *s->action->player, *s->action, *s->target, block_resist * 100, block_value,
                          s->action->player->current.armor_coeff );
      }
    }
  }
}

void player_t::assess_heal( school_e, result_amount_type, action_state_t* s )
{
  // process heal
  s->result_amount = resource_gain( RESOURCE_HEALTH, s->result_total, nullptr, s->action );

  // if the target is a tank record this event on damage timeline
  if ( !is_pet() && primary_role() == ROLE_TANK )
  {
    // health_changes and timeline_healing_taken record everything, accounting for overheal and so on
    collected_data.timeline_healing_taken.add( sim->current_time(), -( s->result_amount ) );
    collected_data.health_changes.timeline.add( sim->current_time(), -( s->result_amount ) );
    double normalized =
        resources.max[ RESOURCE_HEALTH ] ? -( s->result_amount ) / resources.max[ RESOURCE_HEALTH ] : 0.0;
    collected_data.health_changes.timeline_normalized.add( sim->current_time(), normalized );
  }

  // store iteration heal taken
  iteration_heal_taken += s->result_amount;
}

void player_t::trigger_callbacks( proc_types pt, proc_types2 pt2, action_t* action, action_state_t* state,
                                  proc_trigger_type_e pt_type )
{
  assert( action && state && state->target );
  action_callback_t::trigger( callbacks.procs[ pt ][ pt2 ], action->proc_data, this, state->target, state, pt_type );
}

void player_t::trigger_callbacks( proc_types pt, proc_types2 pt2, buff_t* buff, proc_trigger_type_e pt_type )
{
  assert( buff && buff->player );
  action_callback_t::trigger( callbacks.procs[ pt ][ pt2 ], buff->proc_data, this, buff->player, nullptr, pt_type );
}

void player_t::trigger_callbacks( proc_types pt, proc_types2 pt2, const proc_data_t& data, player_t* t,
                                  proc_trigger_type_e pt_type )
{
  assert( t );
  action_callback_t::trigger( callbacks.procs[ pt ][ pt2 ], data, this, t, nullptr, pt_type );
}

void player_t::trigger_aura_applied_callbacks( const proc_data_t& data, player_t* t )
{
  assert( t );
  trigger_callbacks( PROC1_NONE_HELPFUL, PROC2_LANDED, data, t, TRIGGER_AURA_APPLIED );
}

void player_t::summon_pet( util::string_view pet_name, const timespan_t duration )
{
  if ( pet_t* p = find_pet( pet_name ) )
    p->summon( duration );
  else
    sim->error( "Player {} is unable to summon pet '{}'\n", name(), pet_name );
}

void player_t::dismiss_pet( util::string_view pet_name )
{
  pet_t* p = find_pet( pet_name );
  if ( !p )
  {
    sim->error( "Player {}: Could not find pet with name '{}' to dismiss.", name(), pet_name );
    return;
  }
  p->dismiss();
}

bool player_t::recent_cast() const
{
  return ( last_cast > timespan_t::zero() ) &&
         ( ( last_cast + timespan_t::from_seconds( 5.0 ) ) > sim->current_time() );
}

dot_t* player_t::find_dot( util::string_view name, player_t* source ) const
{
  for ( dot_t* d : dot_list )
  {
    if ( d->source == source && d->name_str == name )
      return d;
  }
  return nullptr;
}

void player_t::clear_action_priority_lists() const
{
  for ( size_t i = 0; i < action_priority_list.size(); i++ )
  {
    action_priority_list_t* a = action_priority_list[ i ];
    a->action_list_str.clear();
    a->action_list.clear();
  }
}

/**
 * Replaces "old_list" action_priority_list data with "new_list" action_priority_list data
 */
void player_t::copy_action_priority_list( util::string_view old_list, util::string_view new_list )
{
  action_priority_list_t* ol = find_action_priority_list( old_list );
  action_priority_list_t* nl = find_action_priority_list( new_list );

  if ( ol && nl )
  {
    ol->action_list            = nl->action_list;
    ol->action_list_str        = nl->action_list_str;
    ol->foreground_action_list = nl->foreground_action_list;
    ol->off_gcd_actions        = nl->off_gcd_actions;
    ol->random                 = nl->random;
  }
}

template <typename T>
T* find_vector_member( const std::vector<T*>& list, util::string_view name )
{
  for ( auto t : list )
  {
    if ( t->name_str == name )
      return t;
  }
  return nullptr;
}

action_priority_list_t* player_t::find_action_priority_list( util::string_view name ) const
{
  return find_vector_member( action_priority_list, name );
}

pet_t* player_t::find_pet( util::string_view name ) const
{
  return find_vector_member( pet_list, name );
}

stats_t* player_t::find_stats( util::string_view name ) const
{
  return find_vector_member( stats_list, name );
}

gain_t* player_t::find_gain( util::string_view name ) const
{
  return find_vector_member( gain_list, name );
}

proc_t* player_t::find_proc( util::string_view name ) const
{
  return find_vector_member( proc_list, name );
}

sample_data_helper_t* player_t::find_sample_data( util::string_view name ) const
{
  return find_vector_member( sample_data_list, name );
}

benefit_t* player_t::find_benefit( util::string_view name ) const
{
  return find_vector_member( benefit_list, name );
}

uptime_t* player_t::find_uptime( util::string_view name ) const
{
  return find_vector_member( uptime_list, name );
}

cooldown_t* player_t::find_cooldown( util::string_view name ) const
{
  return find_vector_member( cooldown_list, name );
}

target_specific_cooldown_t* player_t::find_target_specific_cooldown( util::string_view name ) const
{
  return find_vector_member( target_specific_cooldown_list, name );
}

action_t* player_t::find_action( util::string_view name ) const
{
  return find_vector_member( action_list, name );
}

cooldown_t* player_t::get_cooldown( util::string_view name, action_t* a )
{
  cooldown_t* c = find_cooldown( name );

  if ( !c )
  {
    c = new cooldown_t( name, *this );

    cooldown_list.push_back( c );
  }

  if ( a )
    c->action = a;

  return c;
}

target_specific_cooldown_t* player_t::get_target_specific_cooldown( util::string_view name, timespan_t duration )
{
  target_specific_cooldown_t* tcd = find_target_specific_cooldown( name );

  if ( !tcd )
  {
    tcd = new target_specific_cooldown_t( name, *this, duration );
    target_specific_cooldown_list.push_back( tcd );
  }

  return tcd;
}

target_specific_cooldown_t* player_t::get_target_specific_cooldown( cooldown_t& base_cooldown )
{
  target_specific_cooldown_t* tcd = find_target_specific_cooldown( base_cooldown.name() );

  if ( !tcd )
  {
    tcd = new target_specific_cooldown_t( *this, base_cooldown );
    target_specific_cooldown_list.push_back( tcd );
  }

  return tcd;
}

simple_proc_t* player_t::get_simple_proc_rng( std::string_view name, double chance )
{
  return get_rng<simple_proc_t>( name, chance );
}

real_ppm_t* player_t::get_rppm( std::string_view name, double frequency, double modifier, unsigned scales_with,
                                real_ppm_t::blp blp_state )
{
  return get_rng<real_ppm_t>( name, frequency, modifier, scales_with, blp_state );
}

real_ppm_t* player_t::get_rppm( std::string_view name, const spell_data_t* spell_data, const item_t* item )
{
  return get_rng<real_ppm_t>( name, spell_data, item );
}

shuffled_rng_t* player_t::get_shuffled_rng( std::string_view name, shuffled_rng_t::initializer data )
{
  return get_rng<shuffled_rng_t>( name, data );
}

shuffled_rng_t* player_t::get_shuffled_rng( std::string_view name, int success_entries, int total_entries )
{
  return get_rng<shuffled_rng_t>( name, success_entries, total_entries );
}

accumulated_rng_t* player_t::get_accumulated_rng( std::string_view name, double chance, unsigned cap,
                                                  accumulated_rng_fn accumulator_fn,
                                                  unsigned initial_count )
{
  return get_rng<accumulated_rng_t>( name, chance, cap, accumulator_fn, initial_count );
}

threshold_rng_t* player_t::get_threshold_rng( std::string_view name, double increment_max,
                                              threshold_rng_fn accumulator_fn,
                                              bool random_initial_state, bool roll_over )
{
  return get_rng<threshold_rng_t>( name, increment_max, accumulator_fn, random_initial_state, roll_over );
}

dot_t* player_t::get_dot( util::string_view name, player_t* source )
{
  dot_t* d = find_dot( name, source );

  if ( !d )
  {
    d = new dot_t( name, this, source );
    dot_list.push_back( d );
  }

  return d;
}

gain_t* player_t::get_gain( util::string_view name )
{
  gain_t* g = find_gain( name );

  if ( !g )
  {
    g = new gain_t( name );

    gain_list.push_back( g );
  }

  return g;
}

proc_t* player_t::get_proc( util::string_view name, unsigned flags )
{
  proc_t* p = find_proc( name );

  if ( !p )
  {
    p = new proc_t( *sim, name, flags );

    proc_list.push_back( p );
  }

  return p;
}

sample_data_helper_t* player_t::get_sample_data( util::string_view name )
{
  sample_data_helper_t* sd = find_sample_data( name );

  if ( !sd )
  {
    sd = new sample_data_helper_t( name, player_collected_data_t::generic_container_type( this, 3 ) );

    sample_data_list.push_back( sd );
  }

  return sd;
}

stats_t* player_t::get_stats( util::string_view n, action_t* a )
{
  stats_t* stats = find_stats( n );

  if ( !stats )
  {
    stats = new stats_t( n, this );

    stats_list.push_back( stats );
  }

  assert( stats->player == this );

  if ( a )
    stats->action_list.push_back( a );

  return stats;
}

benefit_t* player_t::get_benefit( util::string_view name )
{
  benefit_t* u = find_benefit( name );

  if ( !u )
  {
    u = new benefit_t( name );

    benefit_list.push_back( u );
  }

  return u;
}

uptime_t* player_t::get_uptime( util::string_view name )
{
  uptime_t* u = find_uptime( name );

  if ( !u )
  {
    u = new uptime_t( name );

    uptime_list.push_back( u );
  }

  return u;
}

action_priority_list_t* player_t::get_action_priority_list( util::string_view name, util::string_view comment )
{
  action_priority_list_t* a = find_action_priority_list( name );
  if ( !a )
  {
    if ( action_list_id_ == 64 )
    {
      throw sc_invalid_apl_argument( "Maximum number of action lists is 64." );
    }

    a                   = new action_priority_list_t( name, this, comment );
    a->internal_id      = action_list_id_++;
    a->internal_id_mask = 1ULL << ( a->internal_id );

    action_priority_list.push_back( a );
  }
  return a;
}

int player_t::find_action_id( util::string_view name ) const
{
  for ( size_t i = 0; i < action_map.size(); i++ )
  {
    if ( util::str_compare_ci( name, action_map[ i ] ) )
      return static_cast<int>( i );
  }

  return -1;
}

int player_t::get_action_id( util::string_view name )
{
  auto id = find_action_id( name );
  if ( id != -1 )
  {
    return id;
  }

  action_map.emplace_back( name );
  return static_cast<int>(action_map.size() - 1);
}

int player_t::find_dot_id( util::string_view name ) const
{
  for ( size_t i = 0; i < dot_map.size(); i++ )
  {
    if ( util::str_compare_ci( name, dot_map[ i ] ) )
      return static_cast<int>( i );
  }

  return -1;
}

int player_t::get_dot_id( util::string_view name )
{
  auto id = find_dot_id( name );
  if ( id != -1 )
  {
    return id;
  }

  dot_map.emplace_back( name );
  return static_cast<int>( dot_map.size() - 1 );
}

cooldown_waste_data_t* player_t::get_cooldown_waste_data( const cooldown_t* cd )
{
  for ( const auto& cdw : cooldown_waste_data_list )
  {
    if ( cdw->cd->name_str == cd->name_str )
      return cdw.get();
  }

  cooldown_waste_data_list.push_back( std::make_unique<cooldown_waste_data_t>( cd ) );
  return cooldown_waste_data_list.back().get();
}

namespace
{  // ANONYMOUS

// Chosen Movement Actions ==================================================

struct start_moving_t : public action_t
{
  start_moving_t( player_t* player, util::string_view options_str ) : action_t( ACTION_OTHER, "start_moving", player )
  {
    parse_options( options_str );
    trigger_gcd           = timespan_t::zero();
    cooldown->duration    = timespan_t::from_seconds( 0.5 );
    harmful               = false;
    ignore_false_positive = true;
  }

  void execute() override
  {
    player->buffs.movement->trigger();

    if ( sim->log )
      sim->out_log.printf( "%s starts moving.", player->name() );

    update_ready();
  }

  bool ready() override
  {
    if ( player->buffs.movement->check() )
      return false;

    return action_t::ready();
  }
};

struct stop_moving_t : public action_t
{
  stop_moving_t( player_t* player, util::string_view options_str ) : action_t( ACTION_OTHER, "stop_moving", player )
  {
    parse_options( options_str );
    trigger_gcd           = timespan_t::zero();
    cooldown->duration    = timespan_t::from_seconds( 0.5 );
    harmful               = false;
    ignore_false_positive = true;
  }

  void execute() override
  {
    player->buffs.movement->expire();

    if ( sim->log )
      sim->out_log.printf( "%s stops moving.", player->name() );
    update_ready();
  }

  bool ready() override
  {
    if ( !player->buffs.movement->check() )
      return false;

    return action_t::ready();
  }
};


// ===== Racial Abilities ===================================================

struct racial_spell_t : public spell_t
{
  racial_spell_t( player_t* p, util::string_view token, const spell_data_t* spell ) :
    spell_t( token, p, spell )
  {
  }

  void init() override
  {
    spell_t::init();

    if ( &data() == spell_data_t::not_found() )
      background = true;
  }
};

struct racial_heal_t : public heal_t
{
  racial_heal_t( player_t* p, util::string_view token, const spell_data_t* spell ) :
    heal_t( token, p, spell )
  { }

  void init() override
  {
    heal_t::init();

    if ( &data() == spell_data_t::not_found() )
      background = true;
  }
};

// Shadowmeld ===============================================================

struct shadowmeld_t : public racial_spell_t
{
  shadowmeld_t( player_t* p, util::string_view options_str ) :
    racial_spell_t( p, "shadowmeld", p->find_racial_spell( "Shadowmeld" ) )
  {
    parse_options( options_str );
  }

  void execute() override
  {
    racial_spell_t::execute();

    player->buffs.shadowmeld->trigger();

    // Shadowmeld stops autoattacks
    player->cancel_auto_attacks();

    if ( !player->in_boss_encounter || sim->fight_style == FIGHT_STYLE_DUNGEON_ROUTE || sim->fight_style == FIGHT_STYLE_DUNGEON_SLICE )
      player->leave_combat();
  }
};

// Arcane Torrent ===========================================================

struct arcane_torrent_t : public racial_spell_t
{
  double gain_pct;
  double gain_energy;

  arcane_torrent_t( player_t* p, util::string_view options_str ) :
    racial_spell_t( p, "arcane_torrent", p->find_racial_spell( "Arcane Torrent" ) ),
    gain_pct( 0 ),
    gain_energy( 0 )
  {
    parse_options( options_str );
    harmful = false;
    energize_type = action_energize::ON_CAST;

    target = p;

    // Some specs need special handling here
    switch ( p->specialization() )
    {
      case MAGE_FROST:
      case MAGE_FIRE:
      case MAGE_ARCANE:
      case WARLOCK_AFFLICTION:
      case WARLOCK_DEMONOLOGY:
      case WARLOCK_DESTRUCTION:
        gain_pct = data().effectN( 2 ).percent();
        break;
      case MONK_MISTWEAVER:
        gain_pct = data().effectN( 3 ).percent();
        break;
      case MONK_BREWMASTER:
        gain_energy = data().effectN( 4 ).base_value();
        break;
      default:
        break;
    }
  }

  void execute() override
  {
    racial_spell_t::execute();

    if ( gain_pct > 0 )
    {
      double gain_mana = player->resources.max[ RESOURCE_MANA ] * gain_pct;
      player->resource_gain( RESOURCE_MANA, gain_mana, gain );
    }

    if ( gain_energy > 0 )
      player->resource_gain( RESOURCE_ENERGY, gain_energy, gain );
  }
};

// Berserking ===============================================================

struct berserking_t : public racial_spell_t
{
  buff_t* buff;

  berserking_t( player_t* p, util::string_view options_str ) :
    racial_spell_t( p, "berserking", p->find_racial_spell( "Berserking" ) )
  {
    parse_options( options_str );
    harmful = false;
    target = p;

    // Make a fallback since it's possible some APLs may want to use haste buffs like this as a conditional
    buff = make_buff_fallback( data().ok(), p, "berserking", &data() )
      ->set_cooldown( 0_ms )
      ->set_pct_buff_type_from_data( true );
  }

  void execute() override
  {
    racial_spell_t::execute();

    buff->trigger();
  }
};

// Blood Fury ===============================================================

struct blood_fury_t : public racial_spell_t
{
  buff_t* buff;

  blood_fury_t( player_t* p, util::string_view options_str )
    : racial_spell_t( p, "blood_fury", p->find_racial_spell( "Blood Fury" ) )
  {
    parse_options( options_str );
    harmful = false;
    target = p;

    if ( data().ok() )
    {
      buff = make_buff<stat_buff_t>( p, "blood_fury", &data() )
        ->add_invalidate( CACHE_SPELL_POWER )
        ->add_invalidate( CACHE_ATTACK_POWER )
        ->set_cooldown( 0_ms );
    }
  }

  void execute() override
  {
    racial_spell_t::execute();

    buff->trigger();
  }
};

// Darkflight ==============================================================

struct darkflight_t : public racial_spell_t
{
  buff_t* buff;

  darkflight_t( player_t* p, util::string_view options_str ) :
    racial_spell_t( p, "darkflight", p->find_racial_spell( "Darkflight" ) )
  {
    parse_options( options_str );
    target = p;

    if ( data().ok() )
      buff = make_buff( p, "darkflight", &data() )->set_movement_speed_buff_from_data();
  }

  void execute() override
  {
    racial_spell_t::execute();

    buff->trigger();
  }
};

// Rocket Barrage ===========================================================

struct rocket_barrage_t : public racial_spell_t
{
  rocket_barrage_t( player_t* p, util::string_view options_str ) :
    racial_spell_t( p, "rocket_barrage", p->find_racial_spell( "Rocket Barrage" ) )
  {
    parse_options( options_str );
    // This extra damage is hardcoded in the tooltip.
    base_dd_min = base_dd_max = 2 * p->level();
  }
};

// Stoneform ================================================================

struct stoneform_t : public racial_spell_t
{
  stoneform_t( player_t* p, util::string_view options_str ) :
    racial_spell_t( p, "stoneform", p->find_racial_spell( "Stoneform" ) )
  {
    parse_options( options_str );
    harmful = false;
    target = p;
  }

  void execute() override
  {
    racial_spell_t::execute();

    player->buffs.stoneform->trigger();
  }
};

// Light's Judgment =========================================================

struct lights_judgment_t : public racial_spell_t
{
  struct lights_judgment_damage_t : public spell_t
  {
    lights_judgment_damage_t( player_t* p ) : spell_t( "lights_judgment_damage", p, p->find_spell( 256893 ) )
    {
      background = may_crit = true;
      aoe                   = -1;
      reduced_aoe_targets   = 8;
      // these are sadly hardcoded in the tooltip
      attack_power_mod.direct = 4.2;
      spell_power_mod.direct = 4.2;
    }

    double attack_direct_power_coefficient( const action_state_t* s ) const override
    {
      auto ap = composite_total_attack_power();
      auto sp = composite_total_spell_power();

      if ( ap <= sp )
        return 0;
      return spell_t::attack_direct_power_coefficient( s );
    }

    double spell_direct_power_coefficient( const action_state_t* s ) const override
    {
      auto ap = composite_total_attack_power();
      auto sp = composite_total_spell_power();

      if ( ap > sp )
        return 0;
      return spell_t::spell_direct_power_coefficient( s );
    }
  };

  action_t* damage;

  lights_judgment_t( player_t* p, util::string_view options_str ) :
    racial_spell_t( p, "lights_judgment", p->find_racial_spell( "Light's Judgment" ) )
  {
    parse_options( options_str );
    // The cast doesn't trigger combat
    may_miss = callbacks = harmful = false;

    damage = p->find_action( "lights_judgment_damage" );
    if ( damage == nullptr )
      damage = new lights_judgment_damage_t( p );

    add_child( damage );
  }

  void execute() override
  {
    racial_spell_t::execute();
    // Reduce the cooldown by the player's gcd when used during precombat
    if ( ! player -> in_combat && is_precombat )
    {
      cooldown -> adjust( - player -> base_gcd );

      sim -> print_debug( "{} used Light's Judgment in precombat with precombat time = {}, adjusting travel time and remaining cooldown.",
                          player -> name(), player -> base_gcd.total_seconds() );
    }
  }

  // Missile travels for 3 seconds, stored in missile speed
  timespan_t travel_time() const override
  {
    // Reduce the delay before the hit by the player's gcd when used during precombat
    if ( ! player -> in_combat && is_precombat )
      return racial_spell_t::travel_time() - player -> base_gcd;

    return racial_spell_t::travel_time();
  }

  void impact( action_state_t* state ) override
  {
    racial_spell_t::impact( state );

    damage->set_target( state->target );
    damage->execute();
  }
};

// Arcane Pulse =============================================================

struct arcane_pulse_t : public racial_spell_t
{
  arcane_pulse_t( player_t* p, util::string_view options_str ) :
    // Prevent name conflict with the Mage's Arcane Pulse action
    racial_spell_t( p, p->type == MAGE ? "arcane_pulse_racial" : "arcane_pulse", p->find_racial_spell( "Arcane Pulse" ) )
  {
    parse_options( options_str );
    may_crit = true;
    aoe      = -1;
    // these are sadly hardcoded in the tooltip
    attack_power_mod.direct = 1.5;
    spell_power_mod.direct = 0.75;
  }

  double attack_direct_power_coefficient( const action_state_t* s ) const override
  {
    auto ap = composite_total_attack_power();
    auto sp = composite_total_spell_power();

    if ( ap <= sp )
      return 0;
    return racial_spell_t::attack_direct_power_coefficient( s );
  }

  double spell_direct_power_coefficient( const action_state_t* s ) const override
  {
    auto ap = composite_total_attack_power();
    auto sp = composite_total_spell_power();

    if ( ap > sp )
      return 0;
    return racial_spell_t::spell_direct_power_coefficient( s );
  }
};

// Gift of the Naaru ========================================================

struct gift_of_the_naaru : public racial_heal_t
{
  gift_of_the_naaru( player_t* p, util::string_view options_str ) :
    racial_heal_t( p, "gift_of_the_naaru", p->find_racial_spell( "Gift of the Naaru" ) )
  {
    parse_options( options_str );
    target = p;
  }

  double base_ta( const action_state_t* /* state */ ) const override
  {
    return player->max_health() * data().effectN( 2 ).percent();
  }
};

// Ancestral Call ===========================================================

struct ancestral_call_t : public racial_spell_t
{
  static constexpr std::array<unsigned, 4> spell_ids = { 274739, 274740, 274741, 274742 };

  std::vector<std::tuple<buff_t*, stat_e, double>> stat_values;

  ancestral_call_t( player_t* p, util::string_view options_str ) :
    racial_spell_t( p, "ancestral_call", p->find_racial_spell( "Ancestral Call" ) )
  {
    parse_options( options_str );
    harmful = false;
    target = p;

    if ( data().ok() )
    {
      for ( auto id : spell_ids )
      {
        auto data_ = p->find_spell( id );
        auto stat_ = util::translate_all_rating_mod( data_->effectN( 1 ).misc_value1() ).front();
        auto name_ = util::tokenize_fn( data_->name_cstr() );

        stat_values.emplace_back( make_buff<stat_buff_t>( p, name_, data_ ), stat_, 0.0 );
      }
    }
  }

  void execute() override
  {
    racial_spell_t::execute();

    for ( auto& stat : stat_values )
      std::get<double>( stat ) = util::stat_value( player, std::get<stat_e>( stat ) );

    range::sort( stat_values, []( const auto& a, const auto& b ) {
      return std::get<double>( a ) > std::get<double>( b );
    } );

    std::get<buff_t*>( stat_values[ rng().range( 2 ) ] )->trigger();
  }
};

// Fireblood ================================================================

struct fireblood_t : public racial_spell_t
{
  buff_t* buff;

  fireblood_t( player_t* p, util::string_view options_str ) :
    racial_spell_t( p, "fireblood", p->find_racial_spell( "Fireblood" ) )
  {
    parse_options( options_str );
    harmful = false;
    target = p;

    if ( data().ok() )
    {
      auto stat_amount = p->find_spell( 265226 )->effectN( 1 ).average( p ) * 3.0;

      buff = make_buff<stat_buff_t>( p, "fireblood", p->find_spell( 273104 ) )
        ->add_stat( p->convert_hybrid_stat( STAT_STR_AGI_INT ), stat_amount );
    }
  }

  void execute() override
  {
    racial_spell_t::execute();

    buff->trigger();
  }
};

// Haymaker =================================================================

struct haymaker_t : public racial_spell_t
{
  haymaker_t( player_t* p, util::string_view options_str ) :
    racial_spell_t( p, "haymaker", p->find_racial_spell( "Haymaker" ) )
  {
    parse_options( options_str );
    may_crit = true;
    // Hardcoded in the tooltip.
    attack_power_mod.direct = 0.75;
    spell_power_mod.direct = 0.75;
  }

  double attack_direct_power_coefficient( const action_state_t* s ) const override
  {
    auto ap = composite_total_attack_power();
    auto sp = composite_total_spell_power();

    if ( ap <= sp )
      return 0;

    return racial_spell_t::attack_direct_power_coefficient( s );
  }

  double spell_direct_power_coefficient( const action_state_t* s ) const override
  {
    auto ap = composite_total_attack_power();
    auto sp = composite_total_spell_power();

    if ( ap > sp )
      return 0;

    return racial_spell_t::spell_direct_power_coefficient( s );
  }
};

// Bag of Tricks ===========================================================
struct bag_of_tricks_t : public racial_spell_t
{
  bag_of_tricks_t( player_t* p, util::string_view options_str )
    : racial_spell_t( p, "bag_of_tricks", p->find_racial_spell( "Bag of Tricks" ) )
  {
    parse_options( options_str );
    // This either a healing or damage spell depending on the chosen trick
    //Values for damage are hardcoded in tooltip
    if ( p->vulpera_tricks == player_t::HEALING || p->vulpera_tricks == player_t::HOLY )
    {
      attack_power_mod.direct = 0;
      spell_power_mod.direct  = 0;
    }
    else
    {
      attack_power_mod.direct = 2.52;
      spell_power_mod.direct  = 2.52;
    }

    may_crit = true;

    if ( p->vulpera_tricks == player_t::CORROSIVE )
    {
      school = SCHOOL_NATURE;
    }
    else if ( p->vulpera_tricks == player_t::FLAMES )
    {
      school = SCHOOL_FIRE;
    }
    else if ( p->vulpera_tricks == player_t::SHADOWS )
    {
      school = SCHOOL_SHADOW;
    }
  }

  double attack_direct_power_coefficient( const action_state_t* s ) const override
  {
    auto ap = composite_total_attack_power();
    auto sp = composite_total_spell_power();

    if ( ap <= sp )
      return 0;

    return racial_spell_t::attack_direct_power_coefficient( s );
  }

  double spell_direct_power_coefficient( const action_state_t* s ) const override
  {
    auto ap = composite_total_attack_power();
    auto sp = composite_total_spell_power();

    if ( ap > sp )
      return 0;

    return racial_spell_t::spell_direct_power_coefficient( s );
  }
};

// Thorn Bloom ==============================================================

struct thorn_bloom_t : public racial_spell_t
{
  template <typename BASE>
  struct thorn_bloom_trigger_t : BASE
  {
    using base_t = thorn_bloom_trigger_t<BASE>;

    thorn_bloom_trigger_t( player_t* p, std::string_view n, const spell_data_t* s ) : BASE( n, p, s ) {}

    double attack_direct_power_coefficient( const action_state_t* s ) const override
    {
      return s->composite_spell_power() > s->composite_attack_power() ? 0.0 : BASE::attack_direct_power_coefficient( s );
    }

    double spell_direct_power_coefficient( const action_state_t* s ) const override
    {
      return s->composite_spell_power() > s->composite_attack_power() ? BASE::spell_direct_power_coefficient( s ) : 0.0;
    }

    double attack_tick_power_coefficient( const action_state_t* s ) const override
    {
      return s->composite_spell_power() > s->composite_attack_power() ? 0.0 : BASE::attack_tick_power_coefficient( s );
    }

    double spell_tick_power_coefficient( const action_state_t* s ) const override
    {
      return s->composite_spell_power() > s->composite_attack_power() ? BASE::spell_tick_power_coefficient( s ): 0.0;
    }
  };

  struct thorn_bloom_damage_t : public thorn_bloom_trigger_t<spell_t>
  {
    thorn_bloom_damage_t( player_t* p, const spell_data_t* s ) : base_t( p, "thorn_bloom_damage", s )
    {
      attack_power_mod.direct = 0.5;
      spell_power_mod.direct = 0.5;
      attack_power_mod.tick = 0.125;
      spell_power_mod.tick = 0.125;

      name_str_reporting = "Damage";
    }
  };

  struct thorn_bloom_heal_t : public thorn_bloom_trigger_t<heal_t>
  {
    thorn_bloom_heal_t( player_t* p, const spell_data_t* s ) : base_t( p, "thorn_bloom_heal", s )
    {
      attack_power_mod.direct = 0.65;
      spell_power_mod.direct = 0.65;
      attack_power_mod.tick = 0.15;
      spell_power_mod.tick = 0.15;

      name_str_reporting = "Heal";
    }
  };

  action_t* damage;
  action_t* heal;

  thorn_bloom_t( player_t* p, std::string_view opt_str ) :
    racial_spell_t( p, "thorn_bloom", p->find_racial_spell( "Thorn Bloom" ) )
  {
    parse_options( opt_str );

    damage = p->find_action( "thorn_bloom_damage" );
    if ( !damage )
      damage = new thorn_bloom_damage_t( p, data().effectN( 1 ).trigger() );

    heal = p->find_action( "thorn_bloom_heal" );
    if ( !heal )
      heal = new thorn_bloom_damage_t( p, data().effectN( 2 ).trigger() );

    add_child( damage );
    add_child( heal );
  }

  void execute() override
  {
    racial_spell_t::execute();

    // TODO: determine if these are ground targetted and should be ground_aoe instead
    damage->execute_on_target( target );
    heal->execute_on_target( target );
  }
};

// Restart Sequence Action ==================================================

struct restart_sequence_t : public action_t
{
  sequence_t* seq;
  std::string seq_name_str;

  restart_sequence_t( player_t* player, util::string_view options_str ) :
    action_t( ACTION_OTHER, "restart_sequence", player ),
    seq( nullptr ),
    seq_name_str( "default" )  // matches default name for sequences
  {
    add_option( opt_string( "name", seq_name_str ) );
    parse_options( options_str );
    ignore_false_positive = true;
    trigger_gcd           = timespan_t::zero();
  }

  void init() override
  {
    action_t::init();

    if ( !seq )
    {
      for ( size_t i = 0; i < player->action_list.size() && !seq; ++i )
      {
        action_t* a = player->action_list[ i ];
        if ( a && a->type != ACTION_SEQUENCE )
          continue;

        if ( !seq_name_str.empty() )
          if ( a && seq_name_str != a->name_str )
            continue;

        seq = dynamic_cast<sequence_t*>( a );
      }

      if ( !seq )
      {
        throw sc_invalid_apl_argument(
          fmt::format( "{} can't find sequence '{}'.", *player, seq_name_str.empty() ? "(default)" : seq_name_str ) );
      }
    }
  }

  void execute() override
  {
    if ( sim->debug )
      sim->print_debug( "{} restarting sequence {}", *player, seq_name_str );

    seq->restart();
  }

  bool ready() override
  {
    bool ret = seq && seq->can_restart();
    if ( ret )
      return action_t::ready();

    return ret;
  }
};

// Restore Mana Action ======================================================

struct restore_mana_t : public action_t
{
  double mana;

  restore_mana_t( player_t* player, util::string_view options_str ) :
    action_t( ACTION_OTHER, "restore_mana", player ),
    mana( 0 )
  {
    add_option( opt_float( "mana", mana ) );
    parse_options( options_str );

    trigger_gcd = timespan_t::zero();

    target = player;
  }

  void execute() override
  {
    double mana_missing = player->resources.max[ RESOURCE_MANA ] - player->resources.current[ RESOURCE_MANA ];
    double mana_gain    = mana;

    if ( mana_gain == 0 || mana_gain > mana_missing )
      mana_gain = mana_missing;

    if ( mana_gain > 0 )
    {
      player->resource_gain( RESOURCE_MANA, mana_gain, gain );
    }
  }
};

// Base Wait Action =========================================================

struct wait_action_base_t : public action_t
{
  wait_action_base_t(player_t* player, util::string_view name) :
    action_t(ACTION_OTHER, name, player, spell_data_t::nil())
  {
    trigger_gcd = timespan_t::zero();
    harmful = interrupt_auto_attack = false;
    quiet = true;
    target = player;
  }

  void execute() override
  {
    player->iteration_waiting_time += time_to_execute;
    total_executions++;
  }
};

// Wait For Cooldown Action =================================================

struct wait_for_cooldown_t : public wait_action_base_t
{
  cooldown_t* wait_cd;
  action_t* a;

  wait_for_cooldown_t( player_t* player, util::string_view options_str ) :
    wait_action_base_t( player, "wait_for_cooldown" )
  {
    std::string cd_name;
    add_option( opt_string( "name", cd_name ) );
    parse_options( options_str );

    wait_cd = player->get_cooldown( cd_name );
    a = player->find_action( cd_name );
  }

  bool usable_moving() const override
  {
    return !a || a->usable_moving();
  }

  timespan_t execute_time() const override
  {
    // Ensures that the cooldown exists and has been given a default duration
    assert( wait_cd->duration > timespan_t::zero() );
    return wait_cd->remains();
  }

  bool ready() override
  {
    // Don't attempt to wait for a cooldown that is already up
    if ( wait_cd -> is_ready() )
      return false;
    return wait_action_base_t::ready();
  }
};


// Wait Fixed Action ========================================================

struct wait_fixed_t : public wait_action_base_t
{
  std::unique_ptr<expr_t> time_expr;
  std::string sec_str;

  wait_fixed_t( player_t* player, util::string_view options_str ) :
    wait_action_base_t( player, "wait" ), time_expr(), sec_str( "1.0" )
  {
    add_option( opt_string( "sec", sec_str ) );
    parse_options( options_str );
  }

  void init_finished() override
  {
    wait_action_base_t::init_finished();

    try
    {
      time_expr = expr_t::parse( this, sec_str );
      if ( !time_expr )
        background = true;
    }
    catch ( const std::exception& )
    {
      std::throw_with_nested( sc_invalid_apl_argument( "Invalid 'sec' expression" ) );
    }
  }

  timespan_t execute_time() const override
  {
    timespan_t wait = timespan_t::from_seconds( time_expr->eval() );
    if ( wait <= timespan_t::zero() )
      wait = player->available();
    return wait;
  }
};

// Wait Until Ready Action ==================================================

// wait until actions *before* this wait are ready.
struct wait_until_ready_t : public wait_fixed_t
{
  wait_until_ready_t( player_t* player, util::string_view options_str ) :
    wait_fixed_t( player, options_str )
  {
  }

  timespan_t execute_time() const override
  {
    timespan_t wait    = wait_fixed_t::execute_time();
    timespan_t remains = timespan_t::zero();

    for ( size_t i = 0; i < player->action_list.size(); ++i )
    {
      action_t* a = player->action_list[ i ];
      assert( a );
      if ( a == nullptr )  // For release builds.
        break;
      if ( a == this )
        break;
      if ( a->background )
        continue;

      remains = a->cooldown->remains();
      if ( remains > timespan_t::zero() && remains < wait )
        wait = remains;

      remains = a->get_dot()->remains();
      if ( remains > timespan_t::zero() && remains < wait )
        wait = remains;
    }

    if ( wait <= timespan_t::zero() )
      wait = player->available();

    return wait;
  }
};

// Use Item Action ==========================================================

struct use_item_t : public action_t
{
  item_t* item;
  std::string use_name;
  action_t* action;
  buff_t* buff;
  cooldown_t* cooldown_group;
  timespan_t cooldown_group_duration;
  std::string item_name, item_slot, effect_name;

  use_item_t( player_t* player, util::string_view options_str ) :
    action_t( ACTION_OTHER, "use_item", player ),
    item( nullptr ),
    action( nullptr ),
    buff( nullptr ),
    cooldown_group( nullptr ),
    cooldown_group_duration( timespan_t::zero() )
  {
    add_option( opt_string( "name", item_name ) );
    add_option( opt_string( "slot", item_slot ) );
    add_option( opt_string( "effect_name", effect_name ) );
    parse_options( options_str );

    special = true;

    if ( !item_name.empty() )
    {
      item = player->find_item_by_name( item_name );
      if ( !item )
      {
        if ( sim->debug )
        {
          sim->errorf( "Player %s attempting 'use_item' action with item '%s' which is not currently equipped.\n",
                       player->name(), item_name.c_str() );
        }
        background = true;
        return;
      }

      name_str = name_str + "_" + item_name;
    }
    else if ( !item_slot.empty() )
    {
      slot_e s = util::parse_slot_type( item_slot );
      if ( s == SLOT_INVALID )
      {
        sim->errorf( "Player %s attempting 'use_item' action with invalid slot name '%s'.", player->name(),
                     item_slot.c_str() );
        background = true;
        return;
      }

      item = &( player->items[ s ] );

      if ( !item || !item->active() )
      {
        if ( sim->debug )
        {
          sim->errorf( "Player %s attempting 'use_item' action with invalid item '%s' in slot '%s'.", player->name(),
                       item->name(), item_slot.c_str() );
        }
        item       = nullptr;
        background = true;
      }
      else
      {
        name_str = name_str + "_" + item->name();
      }
    }
    else if ( !effect_name.empty() )
    {
      item = player->find_item_by_use_effect_name( effect_name );
      if ( !item )
      {
        if ( sim->debug )
        {
          sim->errorf( "Player %s attempting 'use_item' action with effect '%s' which cannot be found.\n",
                       player->name(), effect_name.c_str() );
        }
        background = true;
        return;
      }

      name_str = name_str + "_" + item->name();
    }
    else
    {
      sim->errorf( "Player %s has 'use_item' action with no 'name=' or 'slot=' option.\n", player->name() );
      background = true;
    }
  }

  void erase_action( action_priority_list_t* apl )
  {
    if ( apl == nullptr )
    {
      return;
    }

    auto it = range::find( apl->foreground_action_list, this );

    if ( it != apl->foreground_action_list.end() )
    {
      apl->foreground_action_list.erase( it );
    }
  }

  void init() override
  {
    action_priority_list_t* apl = nullptr;
    if ( action_list )
    {
      apl = player->find_action_priority_list( action_list->name_str );
    }

    if ( !item )
    {
      action_t::init();
      erase_action( apl );
      background = true;
      return;
    }

    // Parse Special Effect
    const special_effect_t* e = item->special_effect( SPECIAL_EFFECT_SOURCE_NONE, SPECIAL_EFFECT_USE );
    if ( e && e->type == SPECIAL_EFFECT_USE )
    {
      // Create a buff
      buff = e->create_buff();

      // On-use buff cooldowns are unconditionally handled by the action, so as a precaution, reset any cooldown
      // associated with the buff itself
      if ( buff )
        buff->set_cooldown( 0_ms );

      // Create an action
      action = e->create_action();

      // if the action is the same as the driver, has a direct/periodic damage effect, and the driver has a cast time,
      // then the action is not considered a proc
      if ( action && action->id == e->spell_id && e->driver()->cast_time() > 0_ms &&
           ( action_t::has_direct_damage_effect( *e->driver() ) ||
             action_t::has_periodic_damage_effect( *e->driver() ) ) )
      {
        action->not_a_proc = true;
      }

      stats = player->get_stats( name_str, this );

      // Setup the long-duration cooldown for this item effect
      cooldown           = player->get_cooldown( e->cooldown_name() );
      cooldown->duration = e->cooldown();
      trigger_gcd        = timespan_t::zero();

      // Use DBC-backed item cooldown system for any item data coming from our local database that
      // has no user-given 'use' option on items.
      if ( e->item && util::str_compare_ci( e->item->source_str, "local" ) && e->item->option_use_str.empty() )
      {
        std::string cdgrp = e->cooldown_group_name();
        // No cooldown group will not trigger a shared cooldown
        if ( !cdgrp.empty() )
        {
          cooldown_group          = player->get_cooldown( cdgrp );
          cooldown_group_duration = e->cooldown_group_duration();
        }
        else
        {
          cooldown_group = player->item_cooldown.get();
        }
      }
      else
      {
        cooldown_group = player->item_cooldown.get();
        cooldown_group_duration = player->default_item_group_cooldown;
      }
    }

    if ( action )
    {
      interrupt_auto_attack = action->interrupt_auto_attack;
      reset_auto_attack = action->reset_auto_attack;
    }

    if ( !buff && !action )
    {
      if ( sim->debug )
      {
        sim->errorf( "Player %s has 'use_item' action with no custom buff or action setup.\n", player->name() );
      }
      background = true;

      erase_action( apl );
    }

    action_t::init();

    if ( action )
      action->is_precombat = is_precombat;
  }

  timespan_t execute_time() const override
  {
    return action ? action->execute_time() : action_t::execute_time();
  }

  void execute() override
  {
    bool triggered = buff == nullptr;
    if ( buff )
      triggered = buff->trigger();

    if ( triggered && action && ( !buff || buff->check() == buff->max_stack() ) )
    {
      action->target = target;
      action->execute();

      // Decide whether to expire the buff even with 1 max stack
      if ( buff && buff->max_stack() > 1 )
      {
        buff->expire();
      }
    }

    // Enable to report use_item ability
    // if ( ! dual ) stats -> add_execute( time_to_execute );

    update_ready();

    // Start the shared cooldown
    if ( cooldown_group_duration > timespan_t::zero() )
    {
      cooldown_group->start( cooldown_group_duration );
      if ( sim->debug )
      {
        sim->out_debug.print( "{} starts shared cooldown for {} ({}). Will be ready at {}", *player, name(),
                               cooldown_group->name(), cooldown_group->ready );
      }
    }
  }

  bool ready() override
  {
    if ( !item )
      return false;

    if ( cooldown_group && cooldown_group->remains() > timespan_t::zero() )
    {
      return false;
    }

    if ( action && ( !action->ready() || !action->cooldown->up() ) )
    {
      return false;
    }

    if ( if_expr && !if_expr->success() )
      return false;

    return action_t::ready();
  }

  bool target_ready( player_t* t ) override
  {
    if ( !item )
      return false;

    if ( action )
      return action->target_ready( t );

    return action_t::target_ready( t );
  }

  std::unique_ptr<expr_t> create_special_effect_expr( util::span<const util::string_view> data_str_split )
  {
    struct use_item_buff_type_expr_t : public expr_t
    {
      double v;

      use_item_buff_type_expr_t( bool state ) : expr_t( "use_item_buff_type" ), v( state ? 1.0 : 0 )
      {
      }

      bool is_constant() override
      {
        return true;
      }

      double evaluate() override
      {
        return v;
      }
    };

    if ( data_str_split.size() != 2 || !util::str_compare_ci( data_str_split[ 0 ], "use_buff" ) )
    {
      return nullptr;
    }

    stat_e stat = util::parse_stat_type( data_str_split[ 1 ] );
    if ( stat == STAT_NONE )
    {
      return nullptr;
    }

    const special_effect_t* e = item->special_effect( SPECIAL_EFFECT_SOURCE_NONE, SPECIAL_EFFECT_USE );
    if ( !e )
    {
      return nullptr;
    }

    return std::make_unique<use_item_buff_type_expr_t>( e->stat_type() == stat );
  }

  std::unique_ptr<expr_t> create_expression( util::string_view name ) override
  {
    auto split = util::string_split<util::string_view>( name, "." );

    if ( split.size() > 1 && split[ 0 ] == "other_trinket" )
    {
      auto tail = name.substr( 14 );
      slot_e s = util::parse_slot_type( item_slot );

      if ( s == SLOT_TRINKET_1 )
        return unique_gear::create_expression( *player, fmt::format("trinket.2.{}", tail ) );

      if ( s == SLOT_TRINKET_2 )
        return unique_gear::create_expression( *player, fmt::format("trinket.1.{}", tail ) );

      throw std::invalid_argument( fmt::format( "Unsupported expression 'other_trinket' for '{}' slot.", item_slot ) );
    }

    if ( split.size() > 1 && split[ 0 ] == "this_trinket" )
    {
      auto tail = name.substr( 13 );
      slot_e s = util::parse_slot_type( item_slot );

      if ( s == SLOT_TRINKET_1 )
        return unique_gear::create_expression( *player, fmt::format("trinket.1.{}", tail ) );

      if ( s == SLOT_TRINKET_2 )
        return unique_gear::create_expression( *player, fmt::format("trinket.2.{}", tail ) );

      throw std::invalid_argument( fmt::format( "Unsupported expression 'this_trinket' for '{}' slot.", item_slot ) );
    }

    if ( split.size() == 1 && split[ 0 ] == "this_trinket_slot" )
    {
      slot_e s = util::parse_slot_type( item_slot );

      if ( s == SLOT_TRINKET_1 )
        return std::make_unique<const_expr_t>( name, 1 );

      if ( s == SLOT_TRINKET_2 )
        return std::make_unique<const_expr_t>( name, 2 );

      throw std::invalid_argument( fmt::format( "Unsupported expression 'this_trinket_slot' for '{}' slot.", item_slot ) );
    }

    if ( auto e = create_special_effect_expr( split ) )
    {
      return e;
    }

    return action_t::create_expression( name );
  }
};

// Use Items Action =========================================================

struct use_items_t : public action_t
{
  std::vector<use_item_t*> use_actions;  // List of proxy use_item_t actions to execute
  std::vector<slot_e> priority_slots;    // Slot priority, or custom slots to check
  bool custom_slots;                     // Custom slots= parameter passed. Only check priority_slots.
  bool check_existing = true;            // Ignore a slot if a matching use_item already exists for it

  use_items_t( player_t* player, util::string_view options_str ) :
    action_t( ACTION_USE, "use_items", player ),
    // Ensure trinkets are checked before all other items by default
    priority_slots( {SLOT_TRINKET_1, SLOT_TRINKET_2} ),
    custom_slots( false )
  {
    callbacks = may_miss = may_crit = may_block = may_parry = false;
    special = true;

    trigger_gcd = timespan_t::zero();

    add_option( opt_func( "slots", std::bind( &use_items_t::parse_slots, this, std::placeholders::_1,
                                              std::placeholders::_2, std::placeholders::_3 ) ) );
    add_option( opt_bool( "check_existing", check_existing ) );

    parse_options( options_str );
  }

  result_e calculate_result( action_state_t* ) const override
  {
    return RESULT_HIT;
  }

  timespan_t execute_time() const override
  {
    for ( auto action : use_actions )
    {
      if ( action->ready() && action->action )
      {
        return action->action->execute_time();
      }
    }

    return action_t::execute_time();
  }

  void execute() override
  {
    // Execute first ready sub-action. Note that technically an on-use action can go "unavailable"
    // between the ready check and the execution, meaning this action actually executes no
    // sub-action
    for ( auto action : use_actions )
    {
      if ( action->ready() && action->target_ready( target ) )
      {
        action->set_target( target );
        action->execute();
        break;
      }
    }

    update_ready();
  }

  // Init creates the sub-actions (use_item_t). The sub-action creation is deferred to here (instead
  // of the constructor) to be able to skip actor slots that already have an use_item action defiend
  // in the action list.
  void init() override
  {
    create_use_subactions();
    option.if_expr_str = "";

    // No use_item sub-actions created here, so this action does not need to execute ever. The
    // parent init() call below will filter it out from the "foreground action list".
    if ( use_actions.empty() )
    {
      background = true;
    }

    action_t::init();
  }

  bool ready() override
  {
    // use_items action itself is not ready
    if ( !action_t::ready() )
    {
      return false;
    }

    // Check all use_item actions, if at least one of them is ready, this use_items action is ready
    for ( const auto action : use_actions )
    {
      if ( action->ready() && action->cooldown->up() )
      {
        return true;
      }
    }

    return false;
  }

  bool target_ready( player_t* t ) override
  {
    if ( !action_t::target_ready( t ) )
      return false;

    for ( const auto action : use_actions )
    {
      if ( action->ready() && action->target_ready( t ) )
        return true;
    }

    return false;
  }

  bool parse_slots( sim_t* /* sim */, util::string_view /* opt_name */, util::string_view opt_value )
  {
    // Empty out default priority slots. slots= option will change the use_items action logic so
    // that only the designated slots will be checked/executed for a special effect
    priority_slots.clear();

    auto split = util::string_split<util::string_view>( opt_value, ":|" );
    range::for_each( split, [this]( util::string_view slot_str ) {
      auto slot = util::parse_slot_type( slot_str );
      if ( slot != SLOT_INVALID )
      {
        priority_slots.push_back( slot );
      }
    } );

    custom_slots = true;

    // If slots= option is given, presume that at aleast one of those slots is a valid slot name
    return !priority_slots.empty();
  }

  // Creates "use_item" actions for all usable special effects on the actor. Note that the creation
  // is done in a specified slot order (by default trinkets before other slots).
  void create_use_subactions()
  {
    std::vector<const use_item_t*> use_item_actions;
    // Collect a list of existing use_item actions in the APL.
    range::for_each( player->action_list, [&use_item_actions]( const action_t* action ) {
      if ( const use_item_t* use_item = dynamic_cast<const use_item_t*>( action ) )
      {
        use_item_actions.push_back( use_item );
      }
    } );

    std::vector<slot_e> slot_order = priority_slots;
    // Add in the rest of the slots, if no slots= parameter is given. If a slots= parameter is
    // given, only the slots in that parameter value will be checked.
    for ( auto slot = SLOT_MIN; !custom_slots && slot < SLOT_MAX; ++slot )
    {
      if ( range::find( slot_order, slot ) == slot_order.end() )
      {
        slot_order.push_back( slot );
      }
    }

    // Remove any slots from the slot list that have custom use item actions. Note that this search
    // looks for use_item,slot=X.
    if ( check_existing )
    {
      range::for_each( use_item_actions, [ &slot_order ]( const use_item_t* action ) {
        slot_e slot = util::parse_slot_type( action->item_slot );
        if ( slot == SLOT_INVALID )
        {
          return;
        }

        auto it = range::find( slot_order, slot );
        if ( it != slot_order.end() )
        {
          slot_order.erase( it );
        }
      } );
    }

    // Remove any slots from the list, where the actor has an item equipped, and corresponding a
    // use_item,name=X action for the item.
    if ( check_existing )
    {
      range::for_each( use_item_actions, [ this, &slot_order ]( const use_item_t* action ) {
        if ( action->item_name.empty() )
        {
          return;
        }

        // As precombat /use_item,name=X are only used once, don't remove them.
        if ( action->action_list && action->action_list->name_str == "precombat" && action->action )
          return;

        // Find out if the item is worn
        auto it = range::find_if( player->items, [ action ]( const item_t& i ) {
          return util::str_compare_ci( i.name(), action->item_name );
        } );

        // Worn item, remove slot if necessary
        if ( it != player->items.end() )
        {
          auto slot_it = range::find( slot_order, it->slot );
          if ( slot_it != slot_order.end() )
          {
            slot_order.erase( slot_it );
          }
        }
      } );
    }

    // Remove any slots from the list, where the actor has an item equipped, and corresponding a
    // use_item,effect_name=X action for the item.
    if ( check_existing )
    {
      range::for_each( use_item_actions, [ this, &slot_order ]( const use_item_t* action ) {
        if ( action->effect_name.empty() )
        {
          return;
        }

        // As precombat /use_item,effect_name=X are only used once, don't remove them.
        if ( action->action_list && action->action_list->name_str == "precombat" && action->action )
          return;

        // Find out if the item is worn
        auto it = range::find_if( player->items, [ action ]( const item_t& i ) {
          return i.has_use_special_effect() &&
                 util::str_compare_ci( i.special_effect( SPECIAL_EFFECT_SOURCE_NONE, SPECIAL_EFFECT_USE )->name(),
                                       action->effect_name );
        } );

        // Worn item, remove slot if necessary
        if ( it != player->items.end() )
        {
          auto slot_it = range::find( slot_order, it->slot );
          if ( slot_it != slot_order.end() )
          {
            slot_order.erase( slot_it );
          }
        }
      } );
    }

    // Create use_item actions for each remaining slot, if the user has an on-use item in that slot.
    // Note that this only looks at item-sourced on-use actions (e.g., no engineering addons).
    range::for_each( slot_order, [this]( slot_e slot ) {
      const auto& item     = player->items[ slot ];
      const auto has_effect = range::any_of( item.parsed.special_effects, []( const special_effect_t* e ) {
        return (e->source == SPECIAL_EFFECT_SOURCE_ITEM || e->source == SPECIAL_EFFECT_SOURCE_GEM ||
                e->source == SPECIAL_EFFECT_SOURCE_ENCHANT) && e->type == SPECIAL_EFFECT_USE;
      } );

      // No item-based on-use effect in the slot, skip
      if ( !has_effect )
      {
        return;
      }

      if ( sim->debug )
      {
        sim->print_debug( "{} use_items in action list '{}' creating proxy action for {} (slot={})", *player,
                          action_list->name_str, item.full_name(), item.slot_name() );
      }

      auto use_action = new use_item_t( player, std::string( "slot=" ) + item.slot_name() );
      use_action->option.if_expr_str = option.if_expr_str;
      use_actions.push_back( use_action );

      auto action = use_actions.back();
      // The use_item action is not triggered by the actor (through the APL), so background it
      action->background = true;
    } );
  }
};

// Cancel Buff ==============================================================

struct cancel_buff_t : public action_t
{
  std::string buff_name;
  buff_t* buff;

  cancel_buff_t( player_t* player, util::string_view options_str ) :
    action_t( ACTION_OTHER, "cancel_buff", player ),
    buff_name(),
    buff( nullptr )
  {
    add_option( opt_string( "name", buff_name ) );
    parse_options( options_str );
    ignore_false_positive = true;
    harmful = false;
    trigger_gcd = timespan_t::zero();
  }

  void init_finished() override
  {
    action_t::init_finished();

    if ( buff_name.empty() )
    {
      throw sc_invalid_apl_argument( "Missing buff name." );
    }

    buff = buff_t::find( player, buff_name );

    // if the buff isn't in the player_t::buff_list, try again in the player_td_t::target::buff_list
    if ( !buff )
    {
      buff = buff_t::find( player->get_target_data( player )->target, buff_name );
    }

    if ( !buff )
    {
      throw sc_invalid_apl_argument( fmt::format( "Buff '{}' not found.", buff_name ) );
    }
    else if ( !buff->is_fallback && !buff->can_cancel )
    {
      throw sc_invalid_apl_argument( fmt::format( "Buff '{}' cannot be cancelled.", buff_name ) );
    }
  }

  void execute() override
  {
    if ( sim->log )
      sim->out_log.printf( "%s cancels buff %s", player->name(), buff->name() );
    buff->expire();
  }

  bool ready() override
  {
    if ( !buff || !buff->check() )
      return false;

    return action_t::ready();
  }
};

struct cancel_action_t : public action_t
{
  cancel_action_t( player_t* player, util::string_view options_str ) :
    action_t( ACTION_OTHER, "cancel_action", player )
  {
    parse_options( options_str );
    harmful = false;
    usable_while_casting = use_while_casting = ignore_false_positive = true;
    trigger_gcd = timespan_t::zero();
    action_skill = 1;
  }

  void execute() override
  {
    sim->print_log( "{} performs {}", player->name(), name() );
    player->interrupt();
  }

  bool ready() override
  {
    if ( !player->executing && !player->channeling )
      return false;

    return action_t::ready();
  }
};

struct dismiss_pet_t final : public action_t
{
  std::string pet_name;
  pet_t* pet;

  dismiss_pet_t( player_t* player, util::string_view options_str ) :
    action_t( ACTION_OTHER, "dismiss_pet", player ),
    pet_name(),
    pet()
  {
    add_option( opt_string( "name", pet_name ) );
    parse_options( options_str );
    harmful = false;
    usable_while_casting = use_while_casting = ignore_false_positive = true;
    trigger_gcd = timespan_t::zero();
  }

  void init_finished() override
  {
    action_t::init_finished();

    if ( pet_name.empty() )
    {
      throw sc_invalid_apl_argument( "Missing pet name." );
    }

    pet = player->find_pet( pet_name );
    if ( !pet )
    {
      throw sc_invalid_apl_argument( fmt::format( "Pet '{}' not found.", pet_name ) );
    }

    if ( !pet->can_dismiss )
    {
      throw sc_invalid_apl_argument( fmt::format( "Pet '{}' cannot be dismissed.", pet->name() ) );
    }
  }

  void execute() override
  {
    assert( pet );
    assert( !pet->is_sleeping() );
    sim->print_log( "{} performs {} on {}", player->name(), name(), pet->name() );
    pet->dismiss( false );
  }

  bool ready() override
  {
    if ( !pet || pet->is_sleeping() )
      return false;

    return action_t::ready();
  }
};

/**
 * Pool Resource
 *
 * If the next action in the list would be "ready" if it was not constrained by resource,
 * then this command will pool resource until we have enough.
 */

struct pool_resource_t : public action_t
{
  resource_e resource;
  std::string resource_str;
  timespan_t wait, wait_override;
  bool for_next;
  action_t* next_action;
  bool force_wait;
  std::string amount_str;
  std::unique_ptr<expr_t> amount_expr;

  pool_resource_t( player_t* p, util::string_view options_str, resource_e r = RESOURCE_NONE ) :
    action_t( ACTION_OTHER, "pool_resource", p ),
    resource( r != RESOURCE_NONE ? r : p->primary_resource() ),
    wait( 0_ms ),
    wait_override( 0_ms ),
    for_next( false ),
    next_action( nullptr ),
    force_wait( false ),
    amount_expr()
  {
    quiet = true;
    add_option( opt_timespan( "wait", wait_override ) );
    add_option( opt_bool( "for_next", for_next ) );
    add_option( opt_bool( "force_wait", force_wait ) );
    add_option( opt_string( "resource", resource_str ) );
    add_option( opt_string( "extra_amount", amount_str ) );
    parse_options( options_str );

    if ( !resource_str.empty() )
    {
      resource_e res = util::parse_resource_type( resource_str );
      if ( res != RESOURCE_NONE )
        resource = res;
    }

    if ( force_wait )
    {
      if ( !for_next )
      {
        force_wait = false;
        sim->error( "'for_next=1' is required to pool with force_wait, ignoring." );
      }

      if ( resource != RESOURCE_MANA && resource != RESOURCE_ENERGY && resource != RESOURCE_FOCUS )
      {
        force_wait = false;
        sim->error( "Only Mana, Energy, and Focus can pool with force_wait, ignoring." );
      }

      if ( wait_override != 0_ms )
      {
        force_wait = false;
        sim->error( "Cannot force_wait with set wait time, ignoring." );
      }
    }
  }

  void init_finished() override
  {
    action_t::init_finished();

    if ( !amount_str.empty() )
    {
      try
      {
        amount_expr = expr_t::parse( this, amount_str, false );
      }
      catch ( const std::exception& )
      {
        std::throw_with_nested( sc_invalid_apl_argument( "Invalid 'extra_amount' expression" ) );
      }
    }
  }

  void reset() override
  {
    action_t::reset();

    if ( !next_action && !background && for_next )
    {
      for ( size_t i = 0; i < player->action_priority_list.size(); i++ )
      {
        for ( size_t j = 0; j < player->action_priority_list[ i ]->foreground_action_list.size(); j++ )
        {
          if ( player->action_priority_list[ i ]->foreground_action_list[ j ] != this )
            continue;

          if ( ++j != player->action_priority_list[ i ]->foreground_action_list.size() )
          {
            next_action = player->action_priority_list[ i ]->foreground_action_list[ j ];
            break;
          }
        }
      }

      if ( !next_action )
      {
        sim->error( "{} can't find next action.", *this );
        background = true;
      }
    }
  }

  void execute() override
  {
    if ( sim->log )
      sim->print_log( "{} performs {}", *player, *this );

    player->iteration_pooling_time += wait;
    total_executions++;
  }

  timespan_t gcd() const override
  {
    return wait;
  }

  bool ready() override
  {
    if ( !action_t::ready() )
      return false;

    // If the next action in the list would be "ready" if it was not constrained by energy, then this command will pool
    // energy until we have enough.
    if ( next_action )
    {
      // cache current resource amount while we do evaluations
      double current = player->resources.current[ resource ];
      double extra = amount_expr ? amount_expr->eval() : 0.0;

      // must at least have more current resources than the extra amount
      if ( current >= extra )
      {
        // check if we can cast next ability after accounting for the extra amount required
        player->resources.current[ resource ] -= extra;
        bool next_is_ready = next_action->action_ready();
        player->resources.current[ resource ] = current;

        // if next action is ready, we'll have enough resource remaining after cost so we don't need to pool
        if ( next_is_ready )
          return false;

        // check against maximum resource to see if we're resource limited
        player->resources.current[ resource ] = player->resources.max[ resource ];
        bool next_is_resource_limited = next_action->action_ready();
        player->resources.current[ resource ] = current;

        // if next action still can't be cast with max resources, we're not resource limited and don't need to pool
        if ( !next_is_resource_limited )
          return false;

        // force_wait suspends APL re-evaluation until the next ability can be cast
        if ( force_wait )
        {
          assert( next_action->current_resource() == resource &&
                  "Cannot pool to force_wait with mismatched resources." );

          double next_cost = next_action->cost();
          double diff = next_cost + extra - current;
          double regen = player->resource_regen_per_second( resource );

          wait = timespan_t::from_seconds( std::max( 0.0, diff ) / regen ) + player->available();
          return true;
        }
      }
      else
      {
        // not enough resources to cover the extra, even if next action has 0 cost
        return false;
      }
    }

    wait = wait_override + player->available();
    return true;
  }
};

// Auto-Attack Retargeting ==================================================

struct retarget_auto_attack_t : public action_t
{
  retarget_auto_attack_t( player_t* player, util::string_view options_str ) :
    action_t( ACTION_OTHER, "retarget_auto_attack", player )
  {
    parse_options( options_str );
    use_off_gcd = quiet = true;
    trigger_gcd = timespan_t::zero();
  }

  void execute() override
  {
    if ( player->main_hand_attack && player->main_hand_attack->target != target )
    {
      sim->print_debug( "{} MH auto attack changed from target {} to {}.", name(), player->main_hand_attack->target->name(), target->name() );
      player->main_hand_attack->set_target( target );
    }

    if ( player->off_hand_attack && player->off_hand_attack->target != target )
    {
      sim->print_debug( "{} OH auto attack changed from target {} to {}.", name(), player->off_hand_attack->target->name(), target->name() );
      player->off_hand_attack->set_target( target );
    }
  }

  bool action_ready() override
  {
    if ( !action_t::action_ready() )
      return false;

    if ( player->main_hand_attack && player->main_hand_attack->target != target )
      return true;

    if ( player->off_hand_attack && player->off_hand_attack->target != target )
      return true;

    return false;
  }
};

// Player Retargeting ==================================================

struct retarget_t : public action_t
{
  retarget_t( player_t* player, util::string_view options_str )
    : action_t( ACTION_OTHER, "retarget", player )
  {
    parse_options( options_str );
    quiet = true;
    trigger_gcd = timespan_t::zero();
  }

  void execute() override
  {
    player->target = target;
    for ( auto action : player->action_list )
      action->acquire_target( retarget_source::SELF_RETARGET, player, target );

    for ( auto pet : player->pet_list )
    {
      pet->target = target;
      for ( auto action : pet->action_list )
        action->acquire_target( retarget_source::SELF_RETARGET, player, target );
    }
  }
};

// Invoke External Buff ==================================================

struct invoke_external_buff_t : public action_t
{
  std::string buff_str;

  timespan_t buff_duration;
  int buff_stacks;
  bool use_pool;

  buff_t* buff;
  std::vector<cooldown_t*>* invoke_cds;

  invoke_external_buff_t( player_t* player, util::string_view options_str )
    : action_t( ACTION_OTHER, "invoke_external_buff", player ),
      buff_str(),
      buff_duration( timespan_t::min() ),
      buff_stacks( -1 ),
      use_pool( true ),
      buff( nullptr ),
      invoke_cds( nullptr )
  {
    add_option( opt_string( "name", buff_str ) );
    add_option( opt_timespan( "duration", buff_duration ) );
    add_option( opt_int( "stacks", buff_stacks ) );
    add_option( opt_bool( "use_pool", use_pool ) );
    parse_options( options_str );

    trigger_gcd           = timespan_t::zero();
    ignore_false_positive = true;

  }

  void init_finished() override
  {
    action_t::init_finished();

    if ( buff_str.empty() )
    {
      throw sc_invalid_apl_argument( "Missing external buff name." );
    }

    buff = buff_t::find( player, buff_str );
    if ( !buff )
    {
      throw sc_invalid_apl_argument( fmt::format( "External buff '{}' not found.", buff_str ) );
    }

    // Initialise an action cooldown per buff type.
    cooldown = player->get_cooldown( "invoke_external_buff_" + buff_str );

    if ( use_pool )
    {
      if ( player->external_buffs.invoke_cds.empty() )
      {
        // Run initialisation code
        auto splits_buffs = util::string_split<util::string_view>( player->external_buffs.pool, "/" );

        for ( auto split_buffs : splits_buffs )
        {
          auto splits = util::string_split<util::string_view>( split_buffs, ":" );
          // Min arguments Name and CD - without both, skip
          if ( splits.size() < 2 )
            continue;

          // Buff name is empty - skip
          if ( splits[ 0 ].empty() )
            continue;

          auto external_buff = buff_t::find( player, splits[ 0 ] );

          // If the buff cannot be found, skip
          if ( !external_buff )
            continue;

          // Number of buffs to create (third arugment)
          int num = splits.size() >= 3 ? util::to_int( splits[ 2 ] ) : 1;

          auto cds = &player->external_buffs.invoke_cds[ external_buff ];

          timespan_t cd_time = timespan_t::from_seconds( util::to_double( splits[ 1 ] ) );

          for ( auto i = 0; i < num; i++ )
          {
            auto cd =
                cds->emplace_back( player->get_cooldown( fmt::format( "invoke_{}_{}", splits[ 0 ], cds->size() ) ) );
            cd->duration = cd->base_duration = cd_time;

            sim->print_debug( "{} creates cooldown {} with cd {} ", *player, cd->name(), cd->duration );
          }
        }
      }

      auto cds = &player->external_buffs.invoke_cds[ buff ];

      if ( !cds->empty() )
      {
        // External buffs initialised and buff found - set cooldown object to this
        invoke_cds = cds;
      }
      else
      {
        // External buffs initialied and buffs not found - set buff to nullptr, this action will never be used.
        buff = nullptr;
      }
    }
  }

  bool ready() override
  {
    if ( !buff )
      return false;

    return action_t::ready();
  }

  cooldown_t* get_shortest_cd()
  {
    if ( !use_pool )
      return nullptr;

    auto comp = []( cooldown_t* a, cooldown_t* b ) {
      if ( a->remains() < b->remains() )
        return true;
      if ( a->remains() > b->remains() )
        return false;

      return a->duration < b->duration;
    };

    auto min = min_element( invoke_cds->begin(), invoke_cds->end(), comp );
    if ( min != invoke_cds->end() )
      return *min;

    return nullptr;
  }

  void execute() override
  {
    if ( sim->log )
      sim->print_log( "{} invokes {}", *player, *buff );

    buff->trigger( buff_stacks, buff_duration );

    if ( use_pool )
    {
      auto shortest = get_shortest_cd();
      if ( shortest )
        shortest->start();

      shortest = get_shortest_cd();
      if ( shortest && shortest->remains() > timespan_t::zero() )
      {
        cooldown->duration = shortest->remains();
        cooldown->start();
      }
    }
  }
};


}  // UNNAMED NAMESPACE

action_t* player_t::create_action( util::string_view name, util::string_view options_str )
{
  if ( name == "ancestral_call" )
    return new ancestral_call_t( this, options_str );
  if ( name == "arcane_pulse" || name == "arcane_pulse_racial" )
    return new arcane_pulse_t( this, options_str );
  if ( name == "arcane_torrent" )
    return new arcane_torrent_t( this, options_str );
  if ( name == "berserking" )
    return new berserking_t( this, options_str );
  if ( name == "blood_fury" )
    return new blood_fury_t( this, options_str );
  if ( name == "darkflight" )
    return new darkflight_t( this, options_str );
  if ( name == "fireblood" )
    return new fireblood_t( this, options_str );
  if ( name == "gift_of_the_naaru" )
    return new gift_of_the_naaru( this, options_str );
  if ( name == "haymaker" )
    return new haymaker_t( this, options_str );
  if ( name == "lights_judgment" )
    return new lights_judgment_t( this, options_str );
  if ( name == "rocket_barrage" )
    return new rocket_barrage_t( this, options_str );
  if ( name == "shadowmeld" )
    return new shadowmeld_t( this, options_str );
  if ( name == "stoneform" )
    return new stoneform_t( this, options_str );
  if ( name == "bag_of_tricks" )
    return new bag_of_tricks_t( this, options_str );
  if ( name == "thorn_bloom" )
    return new thorn_bloom_t( this, options_str );

  if ( name == "cancel_action" )
    return new cancel_action_t( this, options_str );
  if ( name == "cancel_buff" )
    return new cancel_buff_t( this, options_str );
  if ( name == "dismiss_pet" )
    return new dismiss_pet_t( this, options_str );
  if ( name == "invoke_external_buff" )
    return new invoke_external_buff_t( this, options_str );
  if ( name == "swap_action_list" )
    return new swap_action_list_t( this, options_str );
  if ( name == "run_action_list" )
    return new run_action_list_t( this, options_str );
  if ( name == "call_action_list" )
    return new call_action_list_t( this, options_str );
  if ( name == "restart_sequence" )
    return new restart_sequence_t( this, options_str );
  if ( name == "restore_mana" )
    return new restore_mana_t( this, options_str );
  if ( name == "sequence" )
    return new sequence_t( this, options_str );
  if ( name == "strict_sequence" )
    return new strict_sequence_t( this, options_str );
  if ( name == "snapshot_stats" )
    return new snapshot_stats_t( this, options_str );
  if ( name == "start_moving" )
    return new start_moving_t( this, options_str );
  if ( name == "stop_moving" )
    return new stop_moving_t( this, options_str );
  if ( name == "use_item" )
    return new use_item_t( this, options_str );
  if ( name == "use_items" )
    return new use_items_t( this, options_str );
  if ( name == "wait" )
    return new wait_fixed_t( this, options_str );
  if ( name == "wait_until_ready" )
    return new wait_until_ready_t( this, options_str );
  if ( name == "pool_resource" )
    return new pool_resource_t( this, options_str );
  if ( name == "variable" )
    return new variable_t( this, options_str );
  if ( name == "cycling_variable" )
    return new cycling_variable_t( this, options_str );
  if ( name == "wait_for_cooldown" )
    return new wait_for_cooldown_t( this, options_str );
  if ( name == "retarget" )
    return new retarget_t( this, options_str );
  if ( name == "retarget_auto_attack" )
    return new retarget_auto_attack_t( this, options_str );

  if ( auto action = unique_gear::create_action( this, name, options_str ) )
    return action;

  if ( auto action = azerite::create_action( this, name, options_str ) )
    return action;

  return consumable::create_action( this, name, options_str );
}

void player_t::create_permanent_actors()
{
  if ( sim->fight_style == FIGHT_STYLE_DUNGEON_ROUTE && sim->dungeon_route_simple_dps_members > 0 && is_player() && type != PLAYER_SIMPLIFIED )
  {
    // keep it simple and require one input player
    int players = 0;
    for ( player_t* p : sim->player_no_pet_list )
    {
      if ( p->is_player() && type != PLAYER_SIMPLIFIED )
      {
        players++;
      }
    }

    if ( players > 1 )
    {
      sim->error( "Warning: ignoring dungeon_route_simple_dps_members since more than one player was defined" );
      sim->dungeon_route_simple_dps_members = 0;
      return;
    }

    // make sure we are actually simming the whole party together
    if ( sim->single_actor_batch )
    {
      sim->error( "Warning: ignoring dungeon_route_simple_dps_members since single_actor_batch was enabed" );
      sim->dungeon_route_simple_dps_members = 0;
      return;
    }

    const module_t* module = module_t::get( PLAYER_SIMPLIFIED );

    bool dps_role = primary_role() != ROLE_TANK && primary_role() != ROLE_HEAL && primary_role() != ROLE_HYBRID;

    if ( dps_role && sim->dungeon_route_simple_dps_members > 2 )
    {
      sim->error( "Warning: clamping dungeon_route_simple_dps_members to 2 since player is dps" );
      sim->dungeon_route_simple_dps_members = 2;
    }

    for ( int i = 1; i <= sim->dungeon_route_simple_dps_members; i++ )
    {
      player_t* p = module->create_player( sim, "Dungeon Buddy " + util::to_string( i ) );
      p->true_level = level();
    }
  }
}

pet_t* player_t::create_pet( util::string_view, util::string_view )
{
  return nullptr;
}

/**
 * Get average item level the player is wearing
 */
double player_t::avg_item_level() const
{
  double avg_ilvl    = 0.0;
  int num_ilvl_items = 0;
  for ( const auto& item : items )
  {
    if ( item.slot != SLOT_SHIRT && item.slot != SLOT_TABARD && item.slot != SLOT_RANGED && item.active() )
    {
      avg_ilvl += item.item_level();
      num_ilvl_items++;
    }
  }

  if ( num_ilvl_items > 1 )
    avg_ilvl /= num_ilvl_items;

  return avg_ilvl;
}

double player_t::get_attribute( attribute_e a ) const
{
  return util::floor( composite_attribute( a ) * composite_attribute_multiplier( a ) );
}

static bool parse_min_gcd( sim_t* sim, util::string_view name, util::string_view value )
{
  if ( name != "min_gcd" )
    return false;

  double v = util::to_double( value );
  if ( v <= 0 )
  {
    sim->error( "{}: Invalid value '{}' for global minimum cooldown.", sim->active_player->name(), value );
    return false;
  }

  sim->active_player->min_gcd = timespan_t::from_seconds( v );
  return true;
}

// TODO: HOTFIX handling
void player_t::replace_spells()
{
  uint32_t class_idx;
  uint32_t spec_index;

  if ( !dbc->spec_idx( _spec, class_idx, spec_index ) )
    return;

  // Search spec spells for spells to replace.
  if ( _spec != SPEC_NONE )
  {
    range::for_each( specialization_spell_entry_t::data( dbc->ptr ),
      [this]( const specialization_spell_entry_t& entry ) {
        if ( static_cast<unsigned>( _spec ) != entry.specialization_id )
        {
          return;
        }

        if ( entry.override_spell_id == 0 )
        {
          return;
        }

        const spell_data_t* s = dbc->spell( entry.spell_id );
        if ( as<int>( s->level() ) <= true_level )
        {
          dbc->replace_id( entry.override_spell_id, entry.spell_id );
        }
    } );
  }

  // Search general spells for spells to replace (a spell you learn earlier might be
  // replaced by one you learn later)
  if ( _spec != SPEC_NONE )
  {
    range::for_each( active_class_spell_t::data( dbc->ptr ),
      [this, class_idx]( const active_class_spell_t& entry ) {
        if ( class_idx != entry.class_id )
        {
          return;
        }

        if ( entry.spec_id != 0 && static_cast<unsigned>( _spec ) != entry.spec_id )
        {
          return;
        }

        if ( entry.override_spell_id == 0 )
        {
          return;
        }

        const spell_data_t* s = dbc->spell( entry.spell_id );
        if ( as<int>( s->level() ) <= true_level )
        {
          dbc->replace_id( entry.override_spell_id, entry.spell_id );
        }
    } );

    range::for_each( rank_class_spell_t::data( dbc->ptr ),
      [this, class_idx]( const rank_class_spell_t& entry ) {
        if ( class_idx != entry.class_id )
        {
          return;
        }

        if ( entry.spec_id != 0 && static_cast<unsigned>( _spec ) != entry.spec_id )
        {
          return;
        }

        if ( entry.override_spell_id == 0 )
        {
          return;
        }

        const spell_data_t* s = dbc->spell( entry.spell_id );
        if ( as<int>( s->level() ) <= true_level )
        {
          dbc->replace_id( entry.override_spell_id, entry.spell_id );
        }
    } );
  }

  for ( const auto& talent : player_traits )
  {
    if ( std::get<2>( talent ) == 0U )
    {
      continue;
    }

    auto talent_obj = find_talent_spell( std::get<1>( talent ) );
    if ( !talent_obj.ok() )
    {
      continue;
    }

    if ( talent_obj.trait()->id_replace_spell )
    {
      dbc->replace_id( talent_obj.trait()->id_replace_spell,
          talent_obj.trait()->id_spell );
    }
  }
}

static player_talent_t create_talent_obj( const player_t* player, const trait_data_t* trait )
{
  auto it = range::find_if( player->player_traits, [ trait ]( const auto& entry ) {
    return std::get<1>( entry ) == trait->id_trait_node_entry;
  } );

  auto _tree = static_cast<talent_tree>( trait->tree_index );
  auto rank = it == player->player_traits.end() ? 0U : std::get<2>( *it );

  // all allocated hero talents are present but disabled if the control talent is not active unless it has been manually
  // added to the profile or sim_t::enable_all_talents is set
  if ( _tree == talent_tree::HERO && !player->player_sub_trees.count( trait->id_sub_tree ) &&
       !range::contains( player->player_sub_traits, trait->id_trait_node_entry ) && !player->sim->enable_all_talents )
  {
    rank = 0U;
  }

  if ( !rank )
  {
    return { player };  // Trait not found on player
  }

  return { player, trait, rank };
}

player_talent_t player_t::find_talent_spell( hero_tree_e tree, std::string_view name, bool name_tokenized,
                                             unsigned idx ) const
{
  return find_talent_spell( talent_tree::HERO, name, _spec, name_tokenized, idx, tree );
}

player_talent_t player_t::find_talent_spell( talent_tree tree, std::string_view name, specialization_e s,
                                             bool name_tokenized, unsigned idx, hero_tree_e hero_tree ) const
{
  auto trait = trait_data_t::find( tree, name, util::class_id( type ), s == SPEC_NONE ? _spec : s, dbc->ptr,
                                   name_tokenized, idx, static_cast<unsigned>( hero_tree ) );

  if ( trait == &trait_data_t::nil() )
  {
    sim->print_debug( "{} can't find {} talent with name '{}'.", *this, util::talent_tree_string( tree ), name );

    return {};  // Invalid trait
  }

  return create_talent_obj( this, trait );
}

player_talent_t player_t::find_talent_spell( talent_tree tree, std::string_view name, unsigned idx ) const
{
  return find_talent_spell( tree, name, SPEC_NONE, false, idx );
}

player_talent_t player_t::find_talent_spell( talent_tree tree, unsigned spell_id, specialization_e s ) const
{
  auto traits =
    trait_data_t::find_by_spell( tree, spell_id, util::class_id( type ), s == SPEC_NONE ? _spec : s, dbc->ptr );

  if ( traits.empty() )
  {
    sim->print_debug( "{} can't find {} talent with spell_id '{}'.", *this, util::talent_tree_string( tree ),
                      spell_id );

    return {};  // Invalid trait
  }

  return create_talent_obj( this, traits[ 0 ] );
}

player_talent_t player_t::find_talent_spell( unsigned trait_node_entry_id ) const
{
  const trait_data_t* trait = trait_data_t::find( trait_node_entry_id, dbc->ptr );

  if ( trait == &trait_data_t::nil() )
  {
    sim->print_debug( "{} can't find talent with node_entry_id '{}'.", *this, trait_node_entry_id );

    return {};  // Invalid trait
  }

  return create_talent_obj( this, trait );
}

const spell_data_t* player_t::find_specialization_spell( util::string_view name,
                                                         specialization_e s ) const
{
  return find_specialization_spell( name, "", s );
}

const spell_data_t* player_t::find_specialization_spell( util::string_view name,
                                                         util::string_view desc,
                                                         specialization_e s ) const
{
  if ( s == SPEC_NONE || s == _spec )
  {
    if ( unsigned spell_id = dbc->specialization_ability_id( _spec, name, desc ) )
    {
      auto spell = dbc::find_spell( this, spell_id );

      if ( as<int>( spell->level() ) <= true_level )
      {
        return spell;
      }
    }
  }

  return spell_data_t::not_found();
}

const spell_data_t* player_t::find_specialization_spell( unsigned spell_id, specialization_e s ) const
{
  if ( s == SPEC_NONE || s == _spec )
  {
    if ( dbc->is_specialization_ability( _spec, spell_id ) )
    {
      auto spell = dbc::find_spell( this, spell_id );

      if ( as<int>( spell->level() ) <= true_level )
      {
        return spell;
      }
    }
  }

  return spell_data_t::not_found();
}

const spell_data_t* player_t::find_mastery_spell( specialization_e s ) const
{
  if ( s == SPEC_NONE || s != _spec )
  {
    return spell_data_t::not_found();
  }

  if ( auto spell_id = dbc->mastery_ability_id( s != SPEC_NONE ? s : _spec ) )
  {
    const auto spell = dbc::find_spell( this, spell_id );
    if ( spell->ok() && as<int>( spell->level() ) <= true_level )
    {
      return spell;
    }
  }

  return spell_data_t::not_found();
}

azerite_power_t player_t::find_azerite_spell( unsigned id ) const
{
  if ( ! azerite )
  {
    return {};
  }

  return azerite -> get_power( id );
}

azerite_power_t player_t::find_azerite_spell( util::string_view name, bool tokenized ) const
{
  if ( ! azerite )
  {
    return {};
  }

  // Note, no const propagation here, so this works
  return azerite -> get_power( name, tokenized );
}

azerite_essence_t player_t::find_azerite_essence( unsigned id ) const
{
  if ( !azerite_essence )
  {
    return { this };
  }

  return azerite_essence->get_essence( id );
}

azerite_essence_t player_t::find_azerite_essence( util::string_view name, bool tokenized ) const
{
  if ( !azerite_essence )
  {
    return { this };
  }

  return azerite_essence->get_essence( name, tokenized );
}

/**
 * 8.2 Vision of Perfection proc handler
 *
 * Carries out class & spec-specific code when Vision of Perfection Procs.
 * Overridden in class modules.
 */
void player_t::vision_of_perfection_proc()
{
  return;
}

/**
 * Tries to find spell data by name.
 *
 * It does this by going through various spell lists in following order:
 * class spell, specialization spell, mastery spell, class/spec/hero talent spell, racial spell, pet_spell
 */
const spell_data_t* player_t::find_spell( util::string_view name, specialization_e s ) const
{
  const spell_data_t* sp = find_class_spell( name, s );
  if ( sp->ok() )
    return sp;

  sp = find_specialization_spell( name );
  if ( sp->ok() )
    return sp;

  if ( s != SPEC_NONE )
  {
    sp = find_mastery_spell( s );
    if ( sp->ok() )
      return sp;
  }

  sp = find_talent_spell( talent_tree::CLASS, name );
  if ( sp->ok() )
    return sp;

  sp = find_talent_spell( talent_tree::SPECIALIZATION, name );
  if ( sp->ok() )
    return sp;

  sp = find_talent_spell( talent_tree::HERO, name );
  if ( sp->ok() )
    return sp;

  sp = find_racial_spell( name );
  if ( sp->ok() )
    return sp;

  sp = find_pet_spell( name );
  if ( sp->ok() )
    return sp;

  return spell_data_t::not_found();
}

const spell_data_t* player_t::find_racial_spell( util::string_view name, race_e r ) const
{
  if ( unsigned spell_id = dbc->race_ability_id( type, ( r != RACE_NONE ) ? r : race, name ) )
  {
    const spell_data_t* s = dbc->spell( spell_id );
    if ( s->id() == spell_id )
    {
      return dbc::find_spell( this, s );
    }
  }

  return spell_data_t::not_found();
}

const spell_data_t* player_t::find_class_spell( util::string_view name, specialization_e s ) const
{
  if ( s == SPEC_NONE || s == _spec )
  {
    if ( unsigned spell_id = dbc->class_ability_id( type, _spec, name ) )
    {
      const spell_data_t* spell = dbc->spell( spell_id );
      if ( spell->id() == spell_id && as<int>( spell->level() ) <= true_level )
      {
        return dbc::find_spell( this, spell );
      }
    }
  }

  return spell_data_t::not_found();
}

const spell_data_t* player_t::find_rank_spell( util::string_view name,
                                               util::string_view rank,
                                               specialization_e spec ) const
{
  if ( spec == SPEC_NONE || spec == _spec )
  {
    const auto& entry = rank_class_spell_t::find( name, rank, util::class_id( type ),
        static_cast<unsigned>( _spec ), dbc->ptr );
    if ( entry.spell_id == 0 )
    {
      return spell_data_t::not_found();
    }

    if ( entry.class_id != as<unsigned>( util::class_id( type ) ) )
    {
      return spell_data_t::not_found();
    }

    if ( entry.spec_id > 0 && entry.spec_id != static_cast<unsigned>( _spec ) )
    {
      return spell_data_t::not_found();
    }

    if ( entry.override_spell_id )
    {
      const auto replace_spell = dbc::find_spell( this, entry.override_spell_id );
      if ( replace_spell->ok() && as<int>( replace_spell->level() ) <= true_level )
      {
        return spell_data_t::not_found();
      }
    }

    const spell_data_t* spell = dbc::find_spell( this, entry.spell_id );
    if ( !spell->ok() || as<int>( spell->level() ) > true_level )
    {
      return spell_data_t::not_found();
    }

    return spell;
  }

  return spell_data_t::not_found();
}

const spell_data_t* player_t::find_pet_spell( util::string_view name ) const
{
  if ( unsigned spell_id = dbc->pet_ability_id( type, name ) )
  {
    const spell_data_t* s = dbc->spell( spell_id );
    if ( s->id() == spell_id )
    {
      return dbc::find_spell( this, s );
    }
  }

  return spell_data_t::not_found();
}

const spell_data_t* player_t::find_spell( unsigned int id ) const
{
  if ( id )
  {
    auto spell = dbc::find_spell( this, id );
    if ( spell->id() && as<int>( spell->level() ) <= true_level &&
         ( spell->max_aura_level() == 0 || as<int>( spell->max_aura_level() ) >= true_level ) )
    {
      return spell;
    }
  }

  return spell_data_t::not_found();
}

const spell_data_t* player_t::find_spell( unsigned int id, specialization_e s ) const
{
  if ( s == SPEC_NONE || s == _spec )
  {
    return find_spell( id );
  }

  return spell_data_t::not_found();
}

namespace
{
std::unique_ptr<expr_t> deprecate_expression( player_t& p, util::string_view old_name, util::string_view new_name, action_t* a = nullptr  )
{
  p.sim->error( "Use of \"{}\" ( action {} ) in action expressions is deprecated: use \"{}\" instead.\n",
                  old_name, a?a->name() : "unknown", new_name );

  return p.create_expression( new_name );
}

struct player_expr_t : public expr_t
{
  player_t& player;

  player_expr_t( util::string_view n, player_t& p ) : expr_t( n ), player( p )
  {
  }
};

struct position_expr_t : public player_expr_t
{
  int mask;
  position_expr_t( util::string_view n, player_t& p, int m ) : player_expr_t( n, p ), mask( m )
  {
  }
  double evaluate() override
  {
    return ( 1 << player.position() ) & mask;
  }
};

std::unique_ptr<expr_t> deprecated_player_expressions( player_t& player, util::string_view expression_str )
{
  if ( expression_str == "health_pct" )
    return deprecate_expression( player, expression_str, "health.pct" );

  if ( expression_str == "mana_pct" )
    return deprecate_expression( player, expression_str, "mana.pct" );

  if ( expression_str == "energy_regen" )
    return deprecate_expression( player, expression_str, "energy.regen" );

  if ( expression_str == "focus_regen" )
    return deprecate_expression( player, expression_str, "focus.regen" );

  if ( expression_str == "time_to_max_energy" )
    return deprecate_expression( player, expression_str, "energy.time_to_max" );

  if ( expression_str == "time_to_max_focus" )
    return deprecate_expression( player, expression_str, "focus.time_to_max" );

  if ( expression_str == "max_mana_nonproc" )
    return deprecate_expression( player, expression_str, "mana.max_nonproc" );

  return {};
}

}  // namespace

/**
 * Player specific action expressions
 *
 * Use this function for expressions which are bound to some action property (eg. target, cast_time, etc.) and not
 * just to the player itself.
 */
std::unique_ptr<expr_t> player_t::create_action_expression( action_t&, util::string_view expression_str )
{
  return create_expression( expression_str );
}

std::unique_ptr<expr_t> player_t::create_expression( util::string_view expression_str )
{
  if (auto e = deprecated_player_expressions(*this, expression_str))
  {
    return e;
  }

  if ( expression_str == "level" )
    return expr_t::create_constant( "level", true_level );

  if ( expression_str == "name" )
    return expr_t::create_constant( "name", actor_index );

  if ( expression_str == "self" )
    return expr_t::create_constant( "self", actor_index );

  if ( expression_str == "target" )
    return make_fn_expr( expression_str, [ this ] { return target->actor_index; } );

  if ( expression_str == "in_combat" )
    return make_ref_expr( "in_combat", in_combat );

  if ( expression_str == "in_boss_encounter" )
    return make_ref_expr( "in_boss_encounter", in_boss_encounter );

  if ( expression_str == "ptr" )
    return expr_t::create_constant( "ptr", dbc->ptr );

  if ( expression_str == "bugs" )
    return expr_t::create_constant( "bugs", bugs );

  if ( expression_str == "is_add" )
    return expr_t::create_constant( "is_add", is_add() );

  if ( expression_str == "is_boss" )
    return expr_t::create_constant( "is_boss", is_boss() );

  if ( expression_str == "is_enemy" )
    return expr_t::create_constant( "is_enemy", is_enemy() );

  if ( expression_str == "has_absorb" )
    return make_fn_expr( expression_str, [ this ] { return has_absorb() ? 1.0 : 0.0; } );

  if ( expression_str == "attack_haste" )
    return make_fn_expr( expression_str, [this] { return cache.attack_haste(); } );

  if ( expression_str == "auto_attack_speed" )
    return make_fn_expr( expression_str, [this] { return cache.auto_attack_speed(); } );

  if ( expression_str == "spell_haste" )
    return make_fn_expr( expression_str, [this] { return cache.spell_haste(); } );

  if ( expression_str == "spell_cast_speed" )
    return make_fn_expr( expression_str, [this] { return cache.spell_cast_speed(); } );

  if ( expression_str == "mastery_value" )
    return make_mem_fn_expr( expression_str, this->cache, &player_stat_cache_t::mastery_value );

  if ( expression_str == "attack_crit" )
    return make_fn_expr( expression_str, [this] { return cache.attack_crit_chance(); } );

  if ( expression_str == "spell_crit" )
    return make_fn_expr( expression_str, [this] { return cache.spell_crit_chance(); } );

  if ( expression_str == "parry_chance" )
    return make_fn_expr( expression_str, [ this ] { return cache.parry(); } );

  if ( expression_str == "dodge_chance" )
    return make_fn_expr( expression_str, [ this ] { return cache.dodge(); } );

  if ( expression_str == "block_chance" )
    return make_fn_expr( expression_str, [ this ] { return cache.block(); } );

  if ( expression_str == "position_front" )
    return std::make_unique<position_expr_t>( "position_front", *this, ( 1 << POSITION_FRONT ) | ( 1 << POSITION_RANGED_FRONT ) );
  if ( expression_str == "position_back" )
    return std::make_unique<position_expr_t>( "position_back", *this, ( 1 << POSITION_BACK ) | ( 1 << POSITION_RANGED_BACK ) );

  if ( expression_str == "time_to_bloodlust" )
    return make_fn_expr( expression_str, [this] { return calculate_time_to_bloodlust(); } );

  // Get the actor's raw initial haste percent
  if ( expression_str == "raw_haste_pct" )
  {
    return make_fn_expr( expression_str, [this]() {
      return std::max( 0.0, initial.stats.haste_rating ) / initial.rating.spell_haste;
    } );
  }

  // Resource expressions
  if ( auto q = create_resource_expression( expression_str ) )
    return q;

  // time_to_pct expressions
  if ( util::str_prefix_ci( expression_str, "time_to_" ) )
  {
    auto parts = util::string_split<util::string_view>( expression_str, "_" );
    double percent = -1.0;

    if ( util::str_in_str_ci( parts[ 2 ], "die" ) )
    {
      percent = 0.0;
    }
    else if ( util::str_in_str_ci( parts[ 2 ], "pct" ) )
    {
      if (parts.size() == 4 )
      {
        // eg. time_to_pct_90.1
        percent = util::to_double( parts[ 3 ] );
      }
      else
      {
        throw sc_invalid_apl_argument( "No pct value given for 'time_to_pct_' expression." );
      }
    }
    else
    {
      throw sc_invalid_apl_argument( fmt::format( "Invalid 'time_to_' expression '{}'.", parts[ 2 ] ) );
    }

    return make_fn_expr( expression_str, [ this, percent ] {
      return time_to_percent( percent ).total_seconds();
    } );
  }

  // incoming_damage_X expressions
  if ( util::str_in_str_ci( expression_str, "incoming_damage_" ) ||
       util::str_in_str_ci( expression_str, "incoming_magic_damage_" ) )
  {
    bool magic_damage = util::str_in_str_ci( expression_str, "incoming_magic_damage_" );
    auto parts = util::string_split<util::string_view>( expression_str, "_" );
    timespan_t window_duration;

    if ( util::str_in_str_ci( parts.back(), "ms" ) )
      window_duration = timespan_t::from_millis( util::to_int( parts.back() ) );
    else
      window_duration = timespan_t::from_seconds( util::to_double( parts.back() ) );

    // skip construction if the duration is nonsensical
    if ( window_duration > timespan_t::zero() )
    {
      if ( magic_damage )
      {
        return make_fn_expr( expression_str, [ this, window_duration ] {
          return compute_incoming_magic_damage( window_duration );
        } );
      }
      else
      {
        return make_fn_expr( expression_str, [ this, window_duration ] {
          return compute_incoming_damage( window_duration );
        } );
      }
    }
    else
    {
      throw sc_invalid_apl_argument(
        fmt::format( "Non-positive 'incoming_damage_' window duration '{}'.", window_duration ) );
    }
  }

  // everything from here on requires splits
  auto splits = util::string_split<util::string_view>( expression_str, "." );

  if ( splits.size() == 2 )
  {
    // player variables
    if ( splits[ 0 ] == "variable"  )
    {
      struct variable_expr_t : public expr_t
      {
        const action_variable_t* var_;

        variable_expr_t( player_t* p, util::string_view name ) : expr_t( "variable" ),
          var_( nullptr )
        {
          auto it = range::find_if( p->variables, [&name]( const action_variable_t* var ) {
            return util::str_compare_ci( name, var->name_ );
          } );

          if ( it == p->variables.end() )
          {
            throw sc_invalid_apl_argument( fmt::format( "Variable '{}' not found.", name ) );
          }
          else
          {
            var_ = *it;
          }
        }

        bool is_constant() override
        { return var_->is_constant(); }

        double evaluate() override
        { return var_->current_value_; }
      };

      return std::make_unique<variable_expr_t>( this, splits[ 1 ] );
    }

    // item equipped by item_id or name or effect_name
    if ( splits[ 0 ] == "equipped" )
    {
      unsigned item_id = util::to_unsigned_ignore_error( splits[ 1 ], 0 );
      for ( const auto& item : items )
      {
        if ( item_id > 0 && item.parsed.data.id == item_id )
        {
          return expr_t::create_constant( "item_equipped", 1 );
        }
        else if ( util::str_compare_ci( item.name_str, splits[ 1 ] ) )
        {
          return expr_t::create_constant( "item_equipped", 1 );
        }
        else if ( item.special_effect_with_name( splits[ 1 ] ) )
        {
          return expr_t::create_constant( "item_equipped", 1 );
        }
      }

      return expr_t::create_constant( "item_equipped", 0 );
    }

    // check weapon type
    if ( ( splits[ 0 ] == "main_hand" || splits[ 0 ] == "off_hand" ) )
    {
      double weapon_status = -1;

      if ( splits[ 0 ] == "main_hand" && util::str_compare_ci( splits[ 1 ], "2h" ) )
      {
        weapon_status = static_cast<double>( main_hand_weapon.group() == WEAPON_2H );
      }
      else if ( splits[ 0 ] == "main_hand" && util::str_compare_ci( splits[ 1 ], "1h" ) )
      {
        weapon_status =
            static_cast<double>( main_hand_weapon.group() == WEAPON_1H || main_hand_weapon.group() == WEAPON_SMALL );
      }
      else if ( splits[ 0 ] == "off_hand" && util::str_compare_ci( splits[ 1 ], "2h" ) )
      {
        weapon_status = static_cast<double>( off_hand_weapon.group() == WEAPON_2H );
      }
      else if ( splits[ 0 ] == "off_hand" && util::str_compare_ci( splits[ 1 ], "1h" ) )
      {
        weapon_status =
            static_cast<double>( off_hand_weapon.group() == WEAPON_1H || off_hand_weapon.group() == WEAPON_SMALL );
      }
      else 
      {
        weapon_e weapon_type = util::parse_weapon_type( splits[ 1 ] );
        if ( weapon_type != WEAPON_NONE )
        {
          weapon_status = static_cast<double>( ( splits[ 0 ] == "main_hand" ?
                                                 main_hand_weapon.type : off_hand_weapon.type ) == weapon_type );
        }
      }

      if ( weapon_status > -1 )
      {
        return expr_t::create_constant( "weapon_type_expr", weapon_status );
      }
    }

    // race
    if ( splits[ 0 ] == "race" )
    {
      return expr_t::create_constant(expression_str, race_str == splits[ 1 ]);
    }

    // spec
    if ( splits[ 0 ] == "spec" )
    {
      return expr_t::create_constant( "spec", dbc::translate_spec_str( type, splits[1]) == specialization() );
    }

    // role
    if ( splits[ 0 ] == "role" )
    {
      return expr_t::create_constant(expression_str, util::str_compare_ci( util::role_type_string( primary_role() ), splits[ 1 ] ));
    }

    // stat
    if ( splits[ 0 ] == "stat" )
    {
      if ( util::str_compare_ci( "spell_haste", splits[ 1 ] ) )
        return make_fn_expr( expression_str, [ this ] { return 1.0 / cache.spell_haste() - 1.0; } );

      stat_e stat = util::parse_stat_type( splits[ 1 ] );
      switch ( stat )
      {
        case STAT_STRENGTH:
        case STAT_AGILITY:
        case STAT_STAMINA:
        case STAT_INTELLECT:
        case STAT_SPIRIT:
        {
          return make_fn_expr( expression_str, [ this, stat ] {
            return cache.get_attribute( static_cast<attribute_e>( stat ) );
          } );
        }

        case STAT_SPELL_POWER:
        {
          return make_fn_expr( expression_str, [ this ] {
            return static_cast<int>( cache.spell_power( SCHOOL_MAX ) * composite_spell_power_multiplier() );
          } );
        }

        case STAT_ATTACK_POWER:
        {
          return make_fn_expr( expression_str, [ this ] {
            return static_cast<int>( cache.attack_power() * composite_attack_power_multiplier() );
          } );
        }

        case STAT_EXPERTISE_RATING:
          return make_mem_fn_expr( expression_str, *this, &player_t::composite_expertise_rating );
        case STAT_HIT_RATING:
          return make_mem_fn_expr( expression_str, *this, &player_t::composite_melee_hit_rating );
        case STAT_CRIT_RATING:
          return make_mem_fn_expr( expression_str, *this, &player_t::composite_melee_crit_rating );
        case STAT_HASTE_RATING:
          return make_mem_fn_expr( expression_str, *this, &player_t::composite_melee_haste_rating );
        case STAT_ARMOR:
          return make_ref_expr( expression_str, current.stats.armor );
        case STAT_BONUS_ARMOR:
          return make_ref_expr( expression_str, current.stats.bonus_armor );
        case STAT_DODGE_RATING:
          return make_mem_fn_expr( expression_str, *this, &player_t::composite_dodge_rating );
        case STAT_PARRY_RATING:
          return make_mem_fn_expr( expression_str, *this, &player_t::composite_parry_rating );
        case STAT_BLOCK_RATING:
          return make_mem_fn_expr( expression_str, *this, &player_t::composite_block_rating );
        case STAT_MASTERY_RATING:
          return make_mem_fn_expr( expression_str, *this, &player_t::composite_mastery_rating );
        case STAT_VERSATILITY_RATING:
          return make_mem_fn_expr( expression_str, *this, &player_t::composite_damage_versatility_rating );
        default:
          break;
      }

      throw sc_invalid_apl_argument( fmt::format( "Stat '{}' not found.", splits[ 1 ] ) );
    }

    if ( splits[ 0 ] == "using_apl" )
      return expr_t::create_constant( expression_str, util::str_compare_ci( splits[ 1 ], use_apl ) );

    if ( splits[ 0 ] == "set_bonus" )
      return sets->create_expression( this, splits[ 1 ] );

    if ( splits[ 0 ] == "active_dot" || splits[ 0 ] == "active_dots" )
    {
      action_t* action = find_action( splits[ 1 ] );
      if ( action )
      {
        return make_fn_expr( expression_str, [ this, action ] {
          return !action->data().ok() ? 0 : get_active_dots( action->get_dot() );
        } );
      }

      throw sc_invalid_apl_argument( fmt::format( "Action '{}' not found.", splits[ 1 ] ) );
    }

    if ( splits[ 0 ] == "movement" )
    {
      if ( splits[ 1 ] == "remains" )
      {
        return make_fn_expr( expression_str, [ this ] {
          if ( current.distance_to_move > 0 )
            return ( current.distance_to_move / composite_movement_speed() );
          else
            return buffs.movement->remains().total_seconds();
        } );
      }
      else if ( splits[ 1 ] == "distance" )
      {
        return make_fn_expr( expression_str, [ this ] { return current.distance_to_move; } );
      }
      else if ( splits[ 1 ] == "speed" )
      {
        return make_mem_fn_expr( splits[ 1 ], *this, &player_t::composite_movement_speed );
      }

      throw sc_invalid_apl_argument( fmt::format( "Invalid 'movement' expression '{}'.", splits[ 1 ] ) );
    }

    // Expansion specific option expressions
    if ( splits[ 0 ] == "bfa" )
    {
      if ( splits[ 1 ] == "font_of_power_precombat_channel" )
      {
        return make_fn_expr( expression_str, [ this ] {
          return sim->bfa_opts.font_of_power_precombat_channel.total_seconds();
        } );
      }

      throw sc_invalid_apl_argument( fmt::format( "Invalid 'bfa.' option '{}'.", splits[ 1 ] ) );
    }

    if ( splits[ 0 ] == "shadowlands" )
    {
      if ( splits[ 1 ] == "shadowed_orb_of_torment_precombat_channel" )
      {
        return make_fn_expr( expression_str, [ this ] {
          return sim->shadowlands_opts.shadowed_orb_of_torment_precombat_channel.total_seconds();
        } );
      }

      throw sc_invalid_apl_argument( fmt::format( "Invalid 'shadowlands.' option '{}'.", splits[ 1 ] ) );
    }

    if ( splits[ 0 ] == "dragonflight" )
    {
      if ( splits[ 1 ] == "screaming_black_dragonscale_damage" )
      {
        return make_fn_expr( expression_str, [ this ] {
          return sim->dragonflight_opts.screaming_black_dragonscale_damage;
        } );
      }

      if ( splits[ 1 ] == "rallied_to_victory_ally_estimate" )
      {
        return make_fn_expr( expression_str, [ this ] {
          return dragonflight_opts.rallied_to_victory_ally_estimate;
        } );
      }

      if (splits[ 1 ] == "string_of_delicacies_ally_estimate")
      {
        return make_fn_expr( expression_str, [ this ] {
           return dragonflight_opts.string_of_delicacies_ally_estimate;
        } );
      }

      throw sc_invalid_apl_argument( fmt::format( "Invalid 'dragonflight.' option '{}'.", splits[ 1 ] ) );
    }

    if ( splits[ 0 ] == "hero_tree" )
    {
      if ( auto id = trait_data_t::get_hero_tree_id( splits[ 1 ] ) )
      {
        // check hash-activated hero trees
        if ( player_sub_trees.count( id ) )
          return expr_t::create_constant( expression_str, 1 );

        // check manually added hero talents
        for ( auto trait_id : player_sub_traits )
        {
          auto trait = trait_data_t::find( trait_id, is_ptr() );
          if ( trait->id_sub_tree == id )
            return expr_t::create_constant( expression_str, 1 );
        }

        return expr_t::create_constant( expression_str, 0 );
      }

      throw sc_invalid_apl_argument( fmt::format( "Hero tree '{}' not found.", splits[ 1 ] ) );
    }
  }

  if ( splits.size() == 3 )
  {
    if ( splits[ 0 ] == "buff" || splits[ 0 ] == "debuff" )
    {
      // Universal PvP rules aura check, primarily used in Blizzard rotations
      if ( splits[ 1 ] == "pvp_rules_enabled_hardcoded" )
      {
        if ( splits[ 2 ] == "up" )
          return expr_t::create_constant( "pvp_enabled", as<double>( sim->pvp_rules && sim->pvp_rules->ok() ) );
        else if ( splits[ 2 ] == "down" )
          return expr_t::create_constant( "pvp_disabled", as<double>( !sim->pvp_rules || !sim->pvp_rules->ok() ) );

        throw sc_invalid_apl_argument( fmt::format( "Invalid PvP rule check '{}.{}'.", splits[ 1 ], splits[ 2 ] ) );
      }

      // buff.buff_name.buff_property
      get_target_data( this );
      buff_t* buff = buff_t::find_expressable( buff_list, splits[ 1 ], this );
      if ( !buff )
        buff = buff_t::find( this, splits[ 1 ], this );  // Raid debuffs & fallback buffs
      if ( buff )
        return buff_t::create_expression( splits[ 1 ], splits[ 2 ], *buff );

      throw sc_invalid_apl_argument( fmt::format( "Buff '{}' not found.", splits[ 1 ] ) );
    }
    else if ( splits[ 0 ] == "cooldown" )
    {
      // since we have no fallback system for cooldowns, all cooldowns must be created if not found.
      auto _cooldown = find_cooldown( splits[ 1 ] );

      if ( !_cooldown )
      {
        sim->print_debug( "{} cooldown '{}' not found, creating placeholder.", *this, splits[ 1 ] );
        _cooldown = get_cooldown( splits[ 1 ] );
        _cooldown->duration = timespan_t::min();
        _cooldown->base_duration = timespan_t::min();
      }

      return _cooldown->create_expression( splits[ 2 ] );
    }
    else if ( splits[ 0 ] == "swing" )
    {
      const auto s = splits[ 1 ];
      slot_e hand    = SLOT_INVALID;
      if ( s == "mh" || s == "mainhand" || s == "main_hand" )
        hand = SLOT_MAIN_HAND;
      if ( s == "oh" || s == "offhand" || s == "off_hand" )
        hand = SLOT_OFF_HAND;
      if ( hand == SLOT_INVALID )
        throw sc_invalid_apl_argument( fmt::format( "Invalid 'swing' slot '{}'.", splits[ 1 ] ) );

      if ( splits[ 2 ] == "remains" )
      {
        struct swing_remains_expr_t : public player_expr_t
        {
          slot_e slot;

          swing_remains_expr_t( player_t& p, slot_e s ) : player_expr_t( "swing_remains", p ), slot( s )
          {}

          double evaluate() override
          {
            attack_t* attack = ( slot == SLOT_MAIN_HAND ) ? player.main_hand_attack : player.off_hand_attack;
            if ( attack && attack->execute_event )
              return attack->execute_event->remains().total_seconds();
            return 9999;
          }
        };
        return std::make_unique<swing_remains_expr_t>( *this, hand );
      }
    }

    if ( splits[ 0 ] == "spell" && splits[ 2 ] == "exists" )
    {
      return expr_t::create_constant(expression_str, find_spell( splits[ 1 ] )->ok());
    }
  } // splits.size() == 3

  // *** Variable-Length expressions from here on ***

  // talents
  if ( splits.size() >= 2 && ( splits[ 0 ] == "apex" || splits[ 0 ] == "talent" ) )
  {
    player_talent_t _talent;

    if ( splits[ 0 ] == "apex" )
    {
      // assume apex talents are always on the spec tree, and that each spec tree only has a single apex talent
      std::vector<const trait_data_t*> apex_traits;

      for ( const auto& _entry : trait_data_t::data( util::class_id( type ), talent_tree::SPECIALIZATION, is_ptr() ) )
      {
        if ( _entry.node_type == trait_node_type_e::NODE_TIERED &&
             range::contains( _entry.id_spec, static_cast<unsigned>( specialization() ) ) )
        {
          apex_traits.push_back( &_entry );
        }
      }

      auto _index = util::to_unsigned( splits[ 1 ] ) - 1;
      if ( _index >= apex_traits.size() )
        throw sc_invalid_apl_argument( fmt::format( "Apex talent index '{}' not found.", splits[ 1 ] ) );

      _talent = create_talent_obj( this, apex_traits[ _index ] );
    }
    else if ( splits[ 0 ] == "talent" )
    {
      auto _name = splits[ 1 ];  // make a copy view
      auto _index = 0U;

      if ( auto _split = util::string_split<std::string_view>( splits[ 1 ], "_" );
           _split.size() >= 2 && util::is_number( _split.back() ) )
      {
        _name = _name.substr( 0, _name.size() - _split.back().size() - 1 );
        _index = util::to_unsigned( _split.back() );
      }

      _talent = find_talent_spell( talent_tree::SPECIALIZATION, _name, specialization(), true, _index );
      if ( _talent.invalid() )
        _talent = find_talent_spell( talent_tree::HERO, _name, specialization(), true, _index );
      if ( _talent.invalid() )
        _talent = find_talent_spell( talent_tree::CLASS, _name, specialization(), true, _index );

      if ( _talent.invalid() )
        throw sc_invalid_apl_argument( fmt::format( "Talent '{}' not found.", splits[ 1 ] ) );
    }

    if ( splits.size() == 2 )
    {
      return expr_t::create_constant( expression_str, _talent.enabled() );
    }
    else if ( splits.size() == 3 )
    {
      if ( splits[ 2 ] == "enabled" )
        return expr_t::create_constant( expression_str, _talent.enabled() );
      else if ( splits[ 2 ] == "disabled" )
        return expr_t::create_constant( expression_str, !_talent.enabled() );
      else if ( splits[ 2 ] == "rank" )
        return expr_t::create_constant( expression_str, _talent.rank() );
    }

    throw sc_invalid_apl_argument( fmt::format( "Invalid talent expression '{}'.", splits[ 2 ] ) );
  }

  if ( splits.size() == 2 && splits[ 0 ] == "potion" )
  {
    std::string_view potion_view;
    std::string default_potion = this->default_potion();

    if ( !potion_str.empty() )
    {
      potion_view = potion_str;
    }
    else if ( !default_potion.empty() )
    {
      potion_view = default_potion;
    }
    else
    {
      return expr_t::create_constant( expression_str, false );
    }

    if ( util::str_compare_ci( potion_view, splits[ 1 ] ) )
      return expr_t::create_constant( expression_str, true );

    if ( potion_view.size() < 2 )
      return expr_t::create_constant( expression_str, false );

    auto last_char = std::prev( potion_view.end() );
    if ( std::isdigit( *last_char ) && *std::prev( last_char ) == '_' )
    {
      potion_view.remove_suffix( 2 );

      if ( util::str_compare_ci( potion_view, splits[ 1 ] ) )
        return expr_t::create_constant( expression_str, true );
    }

    return expr_t::create_constant( expression_str, false );
  }

  // trinkets
  if ( !splits.empty() && splits[ 0 ] == "trinket" )
  {
    if ( auto expr = unique_gear::create_expression( *this, expression_str ) )
      return expr;
  }

  // pet
  if ( splits.size() >= 2 && splits[ 0 ] == "pet" )
  {
    if ( splits[ 1 ] == "any" && splits[ 2 ] == "active" )
    {
      return make_fn_expr( expression_str, [ this ]
      {
        for ( auto p : active_pets )
        {
          if ( p->type == PLAYER_PET && !p->is_sleeping() )
            return 1.0;
        }

        return 0.0;
      } );
    }

    pet_t* pet = find_pet( splits[ 1 ] );
    spawner::base_actor_spawner_t* pet_spawner = nullptr;

    if ( !pet )
    {
      pet_spawner = find_spawner( splits[ 1 ] );
    }

    if ( !pet && !pet_spawner )
    {
      throw sc_invalid_apl_argument( fmt::format( "Pet or pet spawner '{}' not found.", splits[ 1 ] ) );
    }

    if ( pet )
    {
      if ( splits.size() == 2 )
      {
        return expr_t::create_constant( "pet_index_expr", static_cast<double>( pet->actor_index ) );
      }
      // pet.foo.blah
      else
      {
        if ( splits[ 2 ] == "active" )
        {
          return make_fn_expr( expression_str, [ pet ] { return !pet->is_sleeping(); } );
        }
        else if ( splits[ 2 ] == "remains" )
        {
          return make_fn_expr( expression_str, [ pet ] {
            if ( pet->expiration && pet->expiration->remains() > timespan_t::zero() )
            {
              return pet->expiration->remains().total_seconds();
            }
            else
            {
              return 0.0;
            };
          } );
        }

        // build player/pet expression from the tail of the expression string.
        auto tail = expression_str.substr( splits[ 1 ].length() + 5 );
        if ( auto e = pet->create_expression( tail ) )
        {
          return e;
        }

        throw sc_invalid_apl_argument( fmt::format( "Invalid pet expression '{}'.", tail ) );
      }
    }
    // No pet found, but a pet spawner was found. Make a pet-spawner based expression out of the
    // rest of the info
    else
    {
      auto expr = pet_spawner->create_expression( util::make_span( splits ).subspan( 2 ), expression_str );
      if ( expr )
      {
        return expr;
      }
    }
  }

  // owner
  if ( splits.size() > 1 && splits[ 0 ] == "owner" )
  {
    if ( pet_t* pet = dynamic_cast<pet_t*>( this ) )
    {
      if ( pet->owner )
      {
        auto tail = expression_str.substr( 6 );
        if ( auto e = pet->owner->create_expression( tail ) )
        {
          return e;
        }
        throw sc_invalid_apl_argument( fmt::format( "Invalid owner expression '{}'.", tail ) );
      }
      throw sc_invalid_apl_argument( "Pet has no owner." );
    }
    else
    {
      throw sc_invalid_apl_argument( "Player is not a pet." );
    }
  }

  // dbc
  if ( splits.size() == 4 && util::str_compare_ci( splits[ 0 ], "dbc" ) )
  {
    double value = -std::numeric_limits<double>::max();

    if ( util::str_compare_ci( splits[ 1 ], "spell" ) )
    {
      unsigned spell_id = util::to_int( splits[ 2 ] );
      auto field = splits[ 3 ];
      const spell_data_t* s = find_spell( spell_id );
      if ( s->ok() )
        value = s->get_field( field );
      return expr_t::create_constant( name_str, value );
    }

    if ( util::str_compare_ci( splits[ 1 ], "effect" ) )
    {
      unsigned effect_id = util::to_int( splits[ 2 ] );
      auto field = splits[ 3 ];
      const spelleffect_data_t* e = dbc::find_effect( this, effect_id );
      if ( e->ok() )
        value = e->get_field( field );
      return expr_t::create_constant( name_str, value );
    }

    if ( util::str_compare_ci( splits[ 1 ], "power" ) )
    {
      unsigned power_id = util::to_int( splits[ 2 ] );
      auto field = splits[ 3 ];
      const spellpower_data_t* p = dbc::find_power( this, power_id );
      if ( p->id() != 0 )
        value = p->get_field( field );
      return expr_t::create_constant( name_str, value );
    }
  }

  if ( splits[ 0 ] == "azerite" )
  {
    return azerite -> create_expression( splits );
  }

  if ( splits[ 0 ] == "essence" )
  {
    return azerite_essence->create_expression( splits );
  }

  if ( splits[ 0 ] == "hyperthread_wristwraps" )
  {
    return unique_gear::create_expression( *this, expression_str );
  }

  return sim->create_expression( expression_str );
}

std::unique_ptr<expr_t> player_t::create_resource_expression( util::string_view expression_str )
{
  auto splits = util::string_split<util::string_view>( expression_str, "." );
  if ( splits.empty() )
    return nullptr;

  resource_e r = util::parse_resource_type( splits[ 0 ] );
  if ( r == RESOURCE_NONE )
    return nullptr;

  if ( splits.size() == 1 )
    return make_ref_expr( expression_str, resources.current[ r ] );

  if ( splits.size() == 2 )
  {
    if ( splits[ 1 ] == "deficit" )
    {
      return make_fn_expr( expression_str, [ this, r ] { return resources.max[ r ] - resources.current[ r ]; } );
    }

    else if ( splits[ 1 ] == "pct" || splits[ 1 ] == "percent" )
    {
      if ( r == RESOURCE_HEALTH )
      {
        return make_mem_fn_expr( expression_str, *this, &player_t::health_percentage );
      }
      else
      {
        return make_fn_expr( expression_str, [ this, r ] { return resources.pct( r ) * 100.0; } );
      }
    }

    else if ( splits[ 1 ] == "max" )
      return make_ref_expr( expression_str, resources.max[ r ] );

    else if ( splits[ 1 ] == "max_nonproc" )
      return make_ref_expr( expression_str, collected_data.buffed_stats_snapshot.resource[ r ] );

    else if ( splits[ 1 ] == "pct_nonproc" )
    {
      return make_fn_expr( expression_str, [ this, r ] {
        return resources.current[ r ] / collected_data.buffed_stats_snapshot.resource[ r ] * 100.0;
      } );
    }

    else if ( splits[ 1 ] == "net_regen" )
    {
      return make_fn_expr( expression_str, [ this, r ] {
        timespan_t now = sim->current_time();
        if ( now != timespan_t::zero() )
          return ( iteration_resource_gained[ r ] - iteration_resource_lost[ r ] ) / now.total_seconds();
        else
          return 0.0;
      } );
    }

    else if ( splits[ 1 ] == "regen" )
    {
      return make_fn_expr( expression_str, [ this, r ] { return resource_regen_per_second( r ); } );
    }

    else if ( util::str_prefix_ci( splits[ 1 ], "time_to_" ) )
    {
      auto parts = util::string_split<util::string_view>( splits[ 1 ], "_" );

      // foo.time_to_max
      if ( util::str_in_str_ci( parts[ 2 ], "max" ) )
      {
        return make_fn_expr( expression_str, [ this, r ] {
          return ( resources.max[ r ] - resources.current[ r ] ) / resource_regen_per_second( r );
        } );
      }

      // foo.time_to_x
      const double amount = util::to_double( parts[ 2 ] );
      return make_fn_expr( expression_str, [ this, r, amount ] {
        if ( resources.current[ r ] >= amount )
        {
          return timespan_t::zero().total_seconds();
        }
        else if ( amount > resources.max[ r ] )
        {
          // If the value is impossible to reach, return functional infinity
          return timespan_t::max().total_seconds();
        }

        return ( amount - resources.current[ r ] ) / resource_regen_per_second( r );
      } );
    }
  }

  auto tail = expression_str.substr( splits[ 0 ].length() + 1 );
  throw sc_invalid_apl_argument( fmt::format( "Invalid resource expression '{}'.", tail ) );
}

double player_t::compute_incoming_damage( timespan_t interval ) const
{
  double amount = 0;

  if ( !incoming_damage.empty() )
  {
    for ( auto i = incoming_damage.rbegin(), end = incoming_damage.rend(); i != end; ++i )
    {
      if ( sim->current_time() - ( *i ).time > interval )
        break;

      amount += ( *i ).amount;
    }
  }

  return amount;
}

double player_t::compute_incoming_magic_damage( timespan_t interval ) const
{
  double amount = 0;

  if ( !incoming_damage.empty() )
  {
    for ( auto i = incoming_damage.rbegin(), end = incoming_damage.rend(); i != end; ++i )
    {
      if ( sim->current_time() - ( *i ).time > interval )
        break;

      if ( (*i).school == SCHOOL_PHYSICAL )
        continue;

      amount += ( *i ).amount;
    }
  }

  return amount;
}

double player_t::calculate_time_to_bloodlust() const
{
  // only bother if the sim is automatically casting bloodlust. Otherwise error out
  if ( sim->overrides.bloodlust )
  {
    timespan_t time_to_bl  = timespan_t::from_seconds( -1 );
    timespan_t bl_pct_time = timespan_t::from_seconds( -1 );

    // first, check bloodlust_time.  If it's >0, we just compare to current_time()
    // if it's <0, then use time_to_die estimate
    if ( sim->bloodlust_time > timespan_t::zero() )
      time_to_bl = sim->bloodlust_time - sim->current_time();
    else if ( sim->bloodlust_time < timespan_t::zero() )
      time_to_bl = target->time_to_percent( 0.0 ) + sim->bloodlust_time;

    // check bloodlust_percent, if >0 then we need to estimate time based on time_to_die and health_percentage
    if ( sim->bloodlust_percent > 0 && target->health_percentage() > 0 )
      bl_pct_time = ( target->health_percentage() - sim->bloodlust_percent ) * target->time_to_percent( 0.0 ) /
                    target->health_percentage();

    // now that we have both times, we want to check for the Exhaustion buff.  If either time is shorter than
    // the remaining duration on Exhaustion, we won't get that bloodlust and should ignore it
    if ( buffs.exhaustion->check() )
    {
      if ( time_to_bl < buffs.exhaustion->remains() )
        time_to_bl = timespan_t::from_seconds( -1 );
      if ( bl_pct_time < buffs.exhaustion->remains() )
        bl_pct_time = timespan_t::from_seconds( -1 );
    }
    else
    {
      // the sim's bloodlust_check event fires every second, so negative times under 1 second should be treated as
      // zero for safety. without this, time_to_bloodlust can spike to the next target value up to a second before
      // bloodlust is actually cast. probably a non-issue since the worst case is likely to be casting something 1
      // second too early, but we may as well account for it
      if ( time_to_bl < timespan_t::zero() && -time_to_bl < timespan_t::from_seconds( 1.0 ) )
        time_to_bl = timespan_t::zero();
      if ( bl_pct_time < timespan_t::zero() && -bl_pct_time < timespan_t::from_seconds( 1.0 ) )
        bl_pct_time = timespan_t::zero();
    }

    // if both times are non-negative, take the shortest one since that will happen first
    if ( bl_pct_time >= timespan_t::zero() && time_to_bl >= timespan_t::zero() )
      time_to_bl = std::min( bl_pct_time, time_to_bl );
    // otherwise, at least one is negative, so take the larger of the two
    else
      time_to_bl = std::max( bl_pct_time, time_to_bl );

    // if both are negative, time_to_bl will still be negative and we won't be benefitting from another BL cast.
    // Otherwise we return the positive time until BL is being cast.
    if ( time_to_bl >= timespan_t::zero() )
      return time_to_bl.total_seconds();
  }
  else if ( sim->debug )
    sim->errorf( "Trying to call time_to_bloodlust conditional with overrides.bloodlust=0" );

  // Return a nonsensical time that's much longer than the simulation.  This happens if time_to_bl was negative
  // or if overrides.bloodlust was 0
  return 3 * sim->expected_iteration_time.total_seconds();
}

std::string player_t::create_profile( save_e stype )
{
  std::string profile_str;
  std::string term;

  term = "\n";

  if ( !report_information.comment_str.empty() )
  {
    profile_str += "# " + report_information.comment_str + term;
  }

  if ( stype & SAVE_PLAYER )
  {
    profile_str += util::player_type_string( type );
    profile_str += "=\"" + name_str + '"' + term;
    profile_str += "source=" + util::profile_source_string( profile_source_ ) + term;

    if ( !origin_str.empty() )
      profile_str += "origin=\"" + origin_str + '"' + term;
    if ( !report_information.thumbnail_url.empty() )
      profile_str += "thumbnail=\"" + report_information.thumbnail_url + '"' + term;

    profile_str += "spec=";
    profile_str += dbc::specialization_string( specialization() ) + term;
    profile_str += "level=" + util::to_string( true_level ) + term;
    profile_str += "race=" + race_str + term;

    if ( race == RACE_NIGHT_ELF )
    {
      profile_str += "timeofday=" + util::to_string( timeofday == player_t::NIGHT_TIME ? "night" : "day" ) + term;
    }
    else if ( race == RACE_ZANDALARI_TROLL )
    {
      profile_str += "zandalari_loa=" +
                     util::to_string( zandalari_loa == player_t::AKUNDA      ? "akunda"
                                      : zandalari_loa == player_t::BWONSAMDI ? "bwonsamdi"
                                      : zandalari_loa == player_t::GONK      ? "gonk"
                                      : zandalari_loa == player_t::KIMBUL    ? "kimbul"
                                      : zandalari_loa == player_t::KRAGWA    ? "kragwa"
                                                                             : "paku" ) + term;
    }
    else if ( race == RACE_VULPERA )
    {
      profile_str += "vulpera_tricks=" +
                     util::to_string( vulpera_tricks == player_t::HOLY      ? "holy"
                                      : vulpera_tricks == player_t::FLAMES  ? "flames"
                                      : vulpera_tricks == player_t::SHADOWS ? "shadows"
                                      : vulpera_tricks == player_t::HEALING ? "healing"
                                                                            : "corrosive" ) + term;
    }
    else if ( race == RACE_EARTHEN_HORDE || race == RACE_EARTHEN_ALLIANCE )
    {
      profile_str += "earthen_mineral=" +
                     util::to_string( earthen_mineral == player_t::AMBER      ? "amber"
                                      : earthen_mineral == player_t::EMERALD  ? "emerald"
                                      : earthen_mineral == player_t::ONYX     ? "onyx"
                                      : earthen_mineral == player_t::SAPPHIRE ? "sapphire"
                                                                              : "ruby" ) + term;
    }

    profile_str += "role=";
    profile_str += util::role_type_string( primary_role() ) + term;
    profile_str += "position=" + position_str + term;

    if ( !professions_str.empty() )
    {
      profile_str += "professions=" + professions_str + term;
    }
  }

  if ( stype & SAVE_TALENTS )
  {
    if ( !talents_str.empty() )
    {
      profile_str += "talents=" + talents_str + term;
    }

    if ( !class_talents_str.empty() )
    {
      profile_str += "class_talents=" + class_talents_str + term;
    }

    if ( !spec_talents_str.empty() )
    {
      profile_str += "spec_talents=" + spec_talents_str + term;
    }

    if ( !hero_talents_str.empty() )
    {
      profile_str += "hero_talents=" + hero_talents_str + term;
    }

    if ( !omnium_talents_str.empty() )
    {
      profile_str += "omnium_talents=" + omnium_talents_str + term;
    }

    if ( azerite )
    {
      std::string azerite_overrides = azerite -> overrides_str();
      if ( ! azerite_overrides.empty() )
      {
        profile_str += "azerite_override=" + azerite_overrides + term;
      }
    }

    if ( azerite_essence )
    {
      std::string azerite_essence_str = azerite_essence->option_str();
      if ( !azerite_essence_str.empty() )
      {
        profile_str += "azerite_essences=" + azerite_essence_str + term;
      }
    }

    auto print_option = [ &profile_str, term ]( std::string_view n, auto option ) {
      if ( !option.is_default() )
      {
        if constexpr ( std::is_same_v<decltype( option ), default_value_t<bool>> )
          profile_str += fmt::format( "{}={}{}", n, static_cast<int>( option ), term );
        else
          profile_str += fmt::format( "{}={}{}", n, option, term );
      }
    };

    // Shadowlands
    print_option( "shadowlands.soleahs_secret_technique_type_override", shadowlands_opts.soleahs_secret_technique_type );

    // Dragonflight
    print_option( "dragonflight.gyroscopic_kaleidoscope_stat", dragonflight_opts.gyroscopic_kaleidoscope_stat );
    print_option( "dragonflight.player.ruby_whelp_shell_training", dragonflight_opts.ruby_whelp_shell_training );
    print_option( "dragonflight.player.ruby_whelp_shell_context", dragonflight_opts.ruby_whelp_shell_context );
    print_option( "dragonflight.ominous_chromatic_essence_dragonflight", dragonflight_opts.ominous_chromatic_essence_dragonflight );
    print_option( "dragonflight.ominous_chromatic_essence_allies", dragonflight_opts.ominous_chromatic_essence_allies );
    print_option( "dragonflight.ashkandur_humanoid", dragonflight_opts.ashkandur_humanoid );
    print_option( "dragonflight.flowstone_starting_state", dragonflight_opts.flowstone_starting_state );
    print_option( "dragonflight.spoils_of_neltharus_initial_type", dragonflight_opts.spoils_of_neltharus_initial_type );

    // The War Within
    print_option( "thewarwithin.ovinaxs_mercurial_egg_desired_primary_stacks", thewarwithin_opts.ovinaxs_mercurial_egg_desired_primary_stacks );
  }

  if ( stype & SAVE_PLAYER )
  {
    std::string potion_option = potion_str.empty() ? default_potion() : potion_str;
    std::string flask_option  = flask_str.empty() ? default_flask() : flask_str;
    std::string food_option   = food_str.empty() ? default_food() : food_str;
    std::string rune_option   = rune_str.empty() ? default_rune() : rune_str;
    std::string tench_option  = temporary_enchant_str.empty() ? default_temporary_enchant() : temporary_enchant_str;

    if ( !potion_option.empty() || !flask_option.empty() || !food_option.empty() || !rune_option.empty() )
    {
      profile_str += term;
      profile_str += "# Default consumables" + term;

      if ( !potion_option.empty() )
        profile_str += "potion=" + potion_option + term;
      if ( !flask_option.empty() )
        profile_str += "flask=" + flask_option + term;
      if ( !food_option.empty() )
        profile_str += "food=" + food_option + term;
      if ( !rune_option.empty() )
        profile_str += "augmentation=" + rune_option + term;
      if ( !tench_option.empty() )
        profile_str += "temporary_enchant=" + tench_option + term;
    }

    std::vector<std::string> initial_resources;
    for ( resource_e r = RESOURCE_NONE; r < RESOURCE_MAX; ++r )
    {
      if ( resources.initial_opt[ r ] >= 0.0 )
      {
        std::string resource_str = util::resource_type_string( r );
        std::string amount_str   = util::to_string( resources.initial_opt[ r ] );
        initial_resources.push_back( resource_str + "=" + amount_str );
      }
    }

    if ( !initial_resources.empty() )
    {
      profile_str += term;
      profile_str += "initial_resource=";
      for ( size_t i = 0; i < initial_resources.size(); ++i )
      {
        profile_str += initial_resources[ i ];
        if ( i < initial_resources.size() - 1 )
        {
          profile_str += '/';
        }
      }
      profile_str += term;
    }

    if ( !apl_variable_map.empty() )
    {
      profile_str += term;
      profile_str += "# Custom default values for APL variables." + term;
      for ( const auto& v : apl_variable_map )
      {
        profile_str += "apl_variable." + v.first + "=" + v.second + term;
      }
    }
  }

  if ( stype & SAVE_ACTIONS )
  {
    if ( !action_list_str.empty() || use_default_action_list || use_blizzard_action_list )
    {
      // If we created a default action list, add comments
      if ( no_action_list_provided && !use_blizzard_action_list )
        profile_str += action_list_information;

      auto apls = sorted_action_priority_lists( this );
      for ( const auto apl : apls )
      {
        if ( !apl->action_list_comment_str.empty() )
        {
          profile_str += term + "# " + apl->action_list_comment_str;
        }
        profile_str += term;

        bool first = true;
        for ( const auto& action : apl->action_list )
        {
          if ( !action.comment_.empty() )
          {
            profile_str += "# " + action.comment_ + term;
          }

          profile_str += "actions";
          if ( !util::str_compare_ci( apl->name_str, "default" ) )
          {
            profile_str += "." + apl->name_str;
          }

          profile_str += first ? "=" : "+=/";
          profile_str += action.action_ + term;

          first = false;
        }
      }
    }
  }

  if ( ( stype & SAVE_GEAR ) && !items.empty() )
  {
    profile_str += "\n";
    const slot_e SLOT_OUT_ORDER[] = {
        SLOT_HEAD,      SLOT_NECK,      SLOT_SHOULDERS, SLOT_BACK,     SLOT_CHEST,  SLOT_SHIRT,    SLOT_TABARD,
        SLOT_WRISTS,    SLOT_HANDS,     SLOT_WAIST,     SLOT_LEGS,     SLOT_FEET,   SLOT_FINGER_1, SLOT_FINGER_2,
        SLOT_TRINKET_1, SLOT_TRINKET_2, SLOT_MAIN_HAND, SLOT_OFF_HAND, SLOT_RANGED,
    };

    for ( auto& slot : SLOT_OUT_ORDER )
    {
      item_t& item = items[ slot ];
      if ( item.active() )
      {
        profile_str += item.slot_name();
        profile_str += "=" + item.encoded_item() + term;
        if ( sim->save_gear_comments && !item.encoded_comment().empty() )
          profile_str += "# " + item.encoded_comment() + term;
      }
    }

    profile_str += "\n# Gear Summary" + term;
    double avg_ilvl = util::round( avg_item_level(), 2 );
    profile_str += "# gear_ilvl=" + util::to_string( avg_ilvl, 2 ) + term;
    for ( stat_e i = STAT_NONE; i < STAT_MAX; i++ )
    {
      if ( i == STAT_NONE || i == STAT_ALL )
        continue;

      if ( gear.get_stat( i ) < 0 && total_gear.get_stat( i ) > 0 )
      {
        profile_str += "# gear_";
        profile_str += util::stat_type_string( i );
        profile_str += "=" + util::to_string( total_gear.get_stat( i ), 0 ) + term;
      }
      else if ( gear.get_stat( i ) >= 0 )
      {
        profile_str += "# gear_";
        profile_str += util::stat_type_string( i );
        profile_str += "=" + util::to_string( gear.get_stat( i ), 0 ) + term;
      }
    }

    // Set Bonus
    if ( sets != nullptr )
    {
      profile_str += sets->to_profile_string( term );
    }

    if ( enchant.attribute[ ATTR_STRENGTH ] != 0 )
      profile_str += "enchant_strength=" + util::to_string( enchant.attribute[ ATTR_STRENGTH ] ) + term;

    if ( enchant.attribute[ ATTR_AGILITY ] != 0 )
      profile_str += "enchant_agility=" + util::to_string( enchant.attribute[ ATTR_AGILITY ] ) + term;

    if ( enchant.attribute[ ATTR_STAMINA ] != 0 )
      profile_str += "enchant_stamina=" + util::to_string( enchant.attribute[ ATTR_STAMINA ] ) + term;

    if ( enchant.attribute[ ATTR_INTELLECT ] != 0 )
      profile_str += "enchant_intellect=" + util::to_string( enchant.attribute[ ATTR_INTELLECT ] ) + term;

    if ( enchant.attribute[ ATTR_SPIRIT ] != 0 )
      profile_str += "enchant_spirit=" + util::to_string( enchant.attribute[ ATTR_SPIRIT ] ) + term;

    if ( enchant.spell_power != 0 )
      profile_str += "enchant_spell_power=" + util::to_string( enchant.spell_power ) + term;

    if ( enchant.attack_power != 0 )
      profile_str += "enchant_attack_power=" + util::to_string( enchant.attack_power ) + term;

    if ( enchant.expertise_rating != 0 )
      profile_str += "enchant_expertise_rating=" + util::to_string( enchant.expertise_rating ) + term;

    if ( enchant.armor != 0 )
      profile_str += "enchant_armor=" + util::to_string( enchant.armor ) + term;

    if ( enchant.haste_rating != 0 )
      profile_str += "enchant_haste_rating=" + util::to_string( enchant.haste_rating ) + term;

    if ( enchant.hit_rating != 0 )
      profile_str += "enchant_hit_rating=" + util::to_string( enchant.hit_rating ) + term;

    if ( enchant.crit_rating != 0 )
      profile_str += "enchant_crit_rating=" + util::to_string( enchant.crit_rating ) + term;

    if ( enchant.mastery_rating != 0 )
      profile_str += "enchant_mastery_rating=" + util::to_string( enchant.mastery_rating ) + term;

    if ( enchant.versatility_rating != 0 )
      profile_str += "enchant_versatility_rating=" + util::to_string( enchant.versatility_rating ) + term;

    if ( enchant.resource[ RESOURCE_HEALTH ] != 0 )
      profile_str += "enchant_health=" + util::to_string( enchant.resource[ RESOURCE_HEALTH ] ) + term;

    if ( enchant.resource[ RESOURCE_MANA ] != 0 )
      profile_str += "enchant_mana=" + util::to_string( enchant.resource[ RESOURCE_MANA ] ) + term;

    if ( enchant.resource[ RESOURCE_RAGE ] != 0 )
      profile_str += "enchant_rage=" + util::to_string( enchant.resource[ RESOURCE_RAGE ] ) + term;

    if ( enchant.resource[ RESOURCE_ENERGY ] != 0 )
      profile_str += "enchant_energy=" + util::to_string( enchant.resource[ RESOURCE_ENERGY ] ) + term;

    if ( enchant.resource[ RESOURCE_FOCUS ] != 0 )
      profile_str += "enchant_focus=" + util::to_string( enchant.resource[ RESOURCE_FOCUS ] ) + term;

    if ( enchant.resource[ RESOURCE_RUNIC_POWER ] != 0 )
      profile_str += "enchant_runic=" + util::to_string( enchant.resource[ RESOURCE_RUNIC_POWER ] ) + term;
  }
  return profile_str;
}

void player_t::copy_from( player_t* source )
{
  origin_str                        = source->origin_str;
  profile_source_                   = source->profile_source_;
  true_level                        = source->true_level;
  race_str                          = source->race_str;
  timeofday                         = source->timeofday;
  zandalari_loa                     = source->zandalari_loa;
  vulpera_tricks                    = source->vulpera_tricks;
  earthen_mineral                   = source->earthen_mineral;
  race                              = source->race;
  role                              = source->role;
  _spec                             = source->_spec;
  base.distance                     = source->base.distance;
  position_str                      = source->position_str;
  professions_str                   = source->professions_str;
  talents_str                       = source->talents_str;
  class_talents_str                 = source->class_talents_str;
  spec_talents_str                  = source->spec_talents_str;
  hero_talents_str                  = source->hero_talents_str;
  omnium_talents_str                = source->omnium_talents_str;
  set_bonus_str                     = source->set_bonus_str;
  player_traits                     = source->player_traits;
  player_sub_trees                  = source->player_sub_trees;
  player_sub_traits                 = source->player_sub_traits;
  shadowlands_opts                  = source->shadowlands_opts;
  dragonflight_opts                 = source->dragonflight_opts;
  thewarwithin_opts                 = source->thewarwithin_opts;
  midnight_opts                     = source->midnight_opts;
  load_default_gear                 = source->load_default_gear;
  load_default_talents              = source->load_default_talents;
  use_blizzard_action_list          = source->use_blizzard_action_list;
  one_button_mode                   = source->one_button_mode;
  use_cds_with_blizzard_action_list = source->use_cds_with_blizzard_action_list;
  enable_spell_queue                = source->enable_spell_queue;
  spell_queue_window                = source->spell_queue_window;

  if ( azerite )
  {
    azerite -> copy_overrides( source -> azerite );
  }
  if ( azerite_essence )
  {
    azerite_essence -> copy_state( source -> azerite_essence );
  }

  if ( source->dbc_override_ )
  {
    dbc_override_ = source->dbc_override_->clone();
    dbc_override = dbc_override_.get();
  }

  action_list_str      = source->action_list_str;
  alist_map            = source->alist_map;
  use_apl              = source->use_apl;
  apl_variable_map     = source->apl_variable_map;
  precombat_state_map  = source->precombat_state_map;
  custom_stat_buffs    = source->custom_stat_buffs;

  for ( size_t i = 0; i < items.size(); i++ )
  {
    items[ i ]        = source->items[ i ];
    items[ i ].player = this;
  }

  if ( sets != nullptr )
  {
    sets        = std::make_unique<set_bonus_t>( *source->sets );
    sets->actor = this;
  }

  gear    = source->gear;
  enchant = source->enchant;
  bugs    = source->bugs;

  potion_str = source->potion_str;
  flask_str  = source->flask_str;
  food_str   = source->food_str;
  rune_str   = source->rune_str;
  temporary_enchant_str = source->temporary_enchant_str;

  external_buffs = source->external_buffs;
}

void player_t::create_options()
{
  options.reserve( 180 );
  add_option( opt_string( "name", name_str ) );
  add_option( opt_func( "origin", parse_origin ) );
  add_option( opt_func( "source", parse_source ) );
  add_option( opt_string( "region", region_str ) );
  add_option( opt_string( "server", server_str ) );
  add_option( opt_string( "thumbnail", report_information.thumbnail_url ) );
  add_option( opt_string( "id", id_str ) );
  add_option( opt_func( "talents", parse_talent_string ) );
  add_option( opt_string( "race", race_str ) );
  add_option( opt_func( "timeofday", parse_timeofday ) );
  add_option( opt_func( "zandalari_loa", parse_loa ) );
  add_option( opt_func( "vulpera_tricks", parse_tricks ) );
  add_option( opt_func( "earthen_mineral", parse_mineral ) );
  add_option( opt_int( "level", true_level, 1, MAX_LEVEL ) );
  add_option( opt_bool( "ready_trigger", ready_type ) );
  add_option( opt_func( "role", parse_role_string ) );
  add_option( opt_string( "target", target_str ) );
  add_option( opt_float( "skill", base.skill, 0, 1.0 ) );
  add_option( opt_float( "distance", base.distance, 5, std::numeric_limits<double>::max() ) );
  add_option( opt_string( "position", position_str ) );
  add_option( opt_string( "professions", professions_str ) );
  add_option( opt_string( "actions", action_list_str ) );
  add_option( opt_append( "actions+", action_list_str ) );
  add_option( opt_map( "actions.", alist_map ) );
  add_option( opt_map( "apl_variable.", apl_variable_map ) );
  add_option( opt_string( "action_list", choose_action_list ) );
  add_option( opt_bool( "sleeping", base.sleeping ) );
  add_option( opt_bool( "quiet", quiet ) );
  add_option( opt_string( "save", report_information.save_str ) );
  add_option( opt_string( "save_gear", report_information.save_gear_str ) );
  add_option( opt_string( "save_talents", report_information.save_talents_str ) );
  add_option( opt_string( "save_actions", report_information.save_actions_str ) );
  add_option( opt_string( "comment", report_information.comment_str ) );
  add_option( opt_bool( "bugs", bugs ) );
  add_option( opt_func( "world_lag", parse_world_lag ) );
  add_option( opt_func( "world_lag_stddev", parse_world_lag_stddev ) );
  add_option( opt_func( "brain_lag", parse_brain_lag ) );
  add_option( opt_func( "brain_lag_stddev", parse_brain_lag_stddev ) );
  add_option( opt_timespan( "cooldown_tolerance", cooldown_tolerance_ ) );
  add_option( opt_bool( "enable_spell_queue", enable_spell_queue ) );
  add_option( opt_timespan( "spell_queue_window", spell_queue_window ) );
  add_option( opt_bool( "scale_player", scale_player ) );
  add_option( opt_func( "spec", parse_specialization ) );
  add_option( opt_func( "specialization", parse_specialization ) );
  add_option( opt_func( "stat_timelines", parse_stat_timelines ) );
  add_option( opt_bool( "disable_hotfixes", disable_hotfixes ) );
  add_option( opt_func( "min_gcd", parse_min_gcd ) );
  add_option( opt_bool( "load_default_gear", load_default_gear ) );
  add_option( opt_bool( "collect_pet_sequence_data", collect_pet_sequence_data ) );

  // Talents
  add_option( opt_string( "class_talents", class_talents_str ) );
  add_option( opt_append( "class_talents+", class_talents_str ) );
  add_option( opt_string( "spec_talents", spec_talents_str ) );
  add_option( opt_append( "spec_talents+", spec_talents_str ) );
  add_option( opt_string( "hero_talents", hero_talents_str ) );
  add_option( opt_append( "hero_talents+", hero_talents_str ) );
  add_option( opt_string( "omnium_talents", omnium_talents_str ) );
  add_option( opt_append( "omnium_talents+", omnium_talents_str ) );
  add_option( opt_bool( "load_default_talents", load_default_talents ) );

  // Consumables
  add_option( opt_string( "potion", potion_str ) );
  add_option( opt_string( "flask", flask_str ) );
  add_option( opt_string( "phial", flask_str ) );
  add_option( opt_string( "food", food_str ) );
  add_option( opt_string( "augmentation", rune_str ) );
  add_option( opt_string( "temporary_enchant", temporary_enchant_str ) );

  // Positioning
  add_option( opt_float( "x_pos", default_x_position ) );
  add_option( opt_float( "y_pos", default_y_position ) );

  // Items
  add_option( opt_deprecated( "items", "use individual slot options" ) );
  add_option( opt_deprecated( "items+", "use individual slot options" ) );
  add_option( opt_string( "head", items[ SLOT_HEAD ].options_str ) );
  add_option( opt_string( "neck", items[ SLOT_NECK ].options_str ) );
  add_option( opt_string( "shoulders", items[ SLOT_SHOULDERS ].options_str ) );
  add_option( opt_string( "shoulder", items[ SLOT_SHOULDERS ].options_str ) );
  add_option( opt_string( "shirt", items[ SLOT_SHIRT ].options_str ) );
  add_option( opt_string( "chest", items[ SLOT_CHEST ].options_str ) );
  add_option( opt_string( "waist", items[ SLOT_WAIST ].options_str ) );
  add_option( opt_string( "legs", items[ SLOT_LEGS ].options_str ) );
  add_option( opt_string( "leg", items[ SLOT_LEGS ].options_str ) );
  add_option( opt_string( "feet", items[ SLOT_FEET ].options_str ) );
  add_option( opt_string( "foot", items[ SLOT_FEET ].options_str ) );
  add_option( opt_string( "wrists", items[ SLOT_WRISTS ].options_str ) );
  add_option( opt_string( "wrist", items[ SLOT_WRISTS ].options_str ) );
  add_option( opt_string( "hands", items[ SLOT_HANDS ].options_str ) );
  add_option( opt_string( "hand", items[ SLOT_HANDS ].options_str ) );
  add_option( opt_string( "finger1", items[ SLOT_FINGER_1 ].options_str ) );
  add_option( opt_string( "finger2", items[ SLOT_FINGER_2 ].options_str ) );
  add_option( opt_string( "ring1", items[ SLOT_FINGER_1 ].options_str ) );
  add_option( opt_string( "ring2", items[ SLOT_FINGER_2 ].options_str ) );
  add_option( opt_string( "trinket1", items[ SLOT_TRINKET_1 ].options_str ) );
  add_option( opt_string( "trinket2", items[ SLOT_TRINKET_2 ].options_str ) );
  add_option( opt_string( "back", items[ SLOT_BACK ].options_str ) );
  add_option( opt_string( "main_hand", items[ SLOT_MAIN_HAND ].options_str ) );
  add_option( opt_string( "off_hand", items[ SLOT_OFF_HAND ].options_str ) );
  add_option( opt_string( "tabard", items[ SLOT_TABARD ].options_str ) );

  // Set Bonus
  add_option( opt_func( "set_bonus", parse_set_bonus ) );
  add_option( opt_append( "set_bonus+", set_bonus_str ) );

  // Gear Stats
  add_option( opt_float( "gear_strength", gear.attribute[ ATTR_STRENGTH ] ) );
  add_option( opt_float( "gear_agility", gear.attribute[ ATTR_AGILITY ] ) );
  add_option( opt_float( "gear_stamina", gear.attribute[ ATTR_STAMINA ] ) );
  add_option( opt_float( "gear_intellect", gear.attribute[ ATTR_INTELLECT ] ) );
  add_option( opt_float( "gear_spirit", gear.attribute[ ATTR_SPIRIT ] ) );
  add_option( opt_float( "gear_spell_power", gear.spell_power ) );
  add_option( opt_float( "gear_attack_power", gear.attack_power ) );
  add_option( opt_float( "gear_expertise_rating", gear.expertise_rating ) );
  add_option( opt_float( "gear_haste_rating", gear.haste_rating ) );
  add_option( opt_float( "gear_hit_rating", gear.hit_rating ) );
  add_option( opt_float( "gear_crit_rating", gear.crit_rating ) );
  add_option( opt_float( "gear_parry_rating", gear.parry_rating ) );
  add_option( opt_float( "gear_dodge_rating", gear.dodge_rating ) );
  add_option( opt_float( "gear_health", gear.resource[ RESOURCE_HEALTH ] ) );
  add_option( opt_float( "gear_mana", gear.resource[ RESOURCE_MANA ] ) );
  add_option( opt_float( "gear_rage", gear.resource[ RESOURCE_RAGE ] ) );
  add_option( opt_float( "gear_energy", gear.resource[ RESOURCE_ENERGY ] ) );
  add_option( opt_float( "gear_focus", gear.resource[ RESOURCE_FOCUS ] ) );
  add_option( opt_float( "gear_runic", gear.resource[ RESOURCE_RUNIC_POWER ] ) );
  add_option( opt_float( "gear_armor", gear.armor ) );
  add_option( opt_float( "gear_mastery_rating", gear.mastery_rating ) );
  add_option( opt_float( "gear_versatility_rating", gear.versatility_rating ) );
  add_option( opt_float( "gear_bonus_armor", gear.bonus_armor ) );
  add_option( opt_float( "gear_leech_rating", gear.leech_rating ) );
  add_option( opt_float( "gear_run_speed_rating", gear.speed_rating ) );
  add_option( opt_float( "gear_corruption", gear.corruption_rating ) );
  add_option( opt_float( "gear_corruption_resistance", gear.corruption_resistance_rating ) );

  // Stat Enchants
  add_option( opt_float( "enchant_strength", enchant.attribute[ ATTR_STRENGTH ] ) );
  add_option( opt_float( "enchant_agility", enchant.attribute[ ATTR_AGILITY ] ) );
  add_option( opt_float( "enchant_stamina", enchant.attribute[ ATTR_STAMINA ] ) );
  add_option( opt_float( "enchant_intellect", enchant.attribute[ ATTR_INTELLECT ] ) );
  add_option( opt_float( "enchant_spirit", enchant.attribute[ ATTR_SPIRIT ] ) );
  add_option( opt_float( "enchant_spell_power", enchant.spell_power ) );
  add_option( opt_float( "enchant_attack_power", enchant.attack_power ) );
  add_option( opt_float( "enchant_expertise_rating", enchant.expertise_rating ) );
  add_option( opt_float( "enchant_armor", enchant.armor ) );
  add_option( opt_float( "enchant_haste_rating", enchant.haste_rating ) );
  add_option( opt_float( "enchant_hit_rating", enchant.hit_rating ) );
  add_option( opt_float( "enchant_crit_rating", enchant.crit_rating ) );
  add_option( opt_float( "enchant_mastery_rating", enchant.mastery_rating ) );
  add_option( opt_float( "enchant_versatility_rating", enchant.versatility_rating ) );
  add_option( opt_float( "enchant_bonus_armor", enchant.bonus_armor ) );
  add_option( opt_float( "enchant_leech_rating", enchant.leech_rating ) );
  add_option( opt_float( "enchant_run_speed_rating", enchant.speed_rating ) );
  add_option( opt_float( "enchant_health", enchant.resource[ RESOURCE_HEALTH ] ) );
  add_option( opt_float( "enchant_mana", enchant.resource[ RESOURCE_MANA ] ) );
  add_option( opt_float( "enchant_rage", enchant.resource[ RESOURCE_RAGE ] ) );
  add_option( opt_float( "enchant_energy", enchant.resource[ RESOURCE_ENERGY ] ) );
  add_option( opt_float( "enchant_focus", enchant.resource[ RESOURCE_FOCUS ] ) );
  add_option( opt_float( "enchant_runic", enchant.resource[ RESOURCE_RUNIC_POWER ] ) );
  add_option( opt_float( "enchant_corruption", enchant.corruption_rating ) );
  add_option( opt_float( "enchant_corruption_resistance", enchant.corruption_resistance_rating ) );

  // Regen
  add_option( opt_bool( "infinite_energy", resources.infinite_resource[ RESOURCE_ENERGY ] ) );
  add_option( opt_bool( "infinite_focus", resources.infinite_resource[ RESOURCE_FOCUS ] ) );
  add_option( opt_bool( "infinite_health", resources.infinite_resource[ RESOURCE_HEALTH ] ) );
  add_option( opt_bool( "infinite_mana", resources.infinite_resource[ RESOURCE_MANA ] ) );
  add_option( opt_bool( "infinite_rage", resources.infinite_resource[ RESOURCE_RAGE ] ) );
  add_option( opt_bool( "infinite_runic", resources.infinite_resource[ RESOURCE_RUNIC_POWER ] ) );
  add_option( opt_bool( "infinite_astral_power", resources.infinite_resource[ RESOURCE_ASTRAL_POWER ] ) );

  // Resources
  add_option( opt_func( "initial_resource", parse_initial_resource ) );

  // Misc
  add_option( opt_string( "skip_actions", action_list_skip ) );
  add_option( opt_string( "modify_action", modify_action ) );
  add_option( opt_string( "use_apl", use_apl ) );
  add_option( opt_bool( "use_blizzard_action_list", use_blizzard_action_list ) );
  add_option( opt_bool( "use_cds_with_blizzard_action_list", use_cds_with_blizzard_action_list ) );
  add_option( opt_bool( "one_button_mode", one_button_mode ) );
  add_option( opt_timespan( "reaction_time_mean", reaction.mean ) );
  add_option( opt_timespan( "reaction_time_stddev", reaction.stddev ) );
  add_option( opt_timespan( "reaction_time_nu", reaction_nu ) );
  add_option( opt_timespan( "reaction_time_offset", reaction_offset ) );
  add_option( opt_timespan( "reaction_time_max", reaction_max ) );
  add_option( opt_bool( "stat_cache", cache.active ) );
  add_option( opt_timespan( "default_item_group_cooldown", default_item_group_cooldown, 0_ms, timespan_t::max() ) );
  add_option( opt_func( "override.precombat_state", [ this ]( sim_t*, std::string_view, std::string_view value ) {
    auto splits = util::string_split<std::string>( value, "=" );
    if ( splits.size() != 2 )
      throw std::invalid_argument( fmt::format( "Invalid value '{}'.", value ) );
    precombat_state_map[ splits[ 0 ] ] = splits[ 1 ];
    return true;
  } ) );
  add_option( opt_func( "set_custom_buff", [ this ]( sim_t*, std::string_view, std::string_view value ) {
    if ( value.empty() )
      return true;

    auto splits = util::string_split<std::string>( value, "," );
    std::string name{};
    bool has_data = false;
    std::string stat_value{};
    timespan_t start = timespan_t::min();
    timespan_t duration = 0_ms;
    for ( auto s : splits )
    {
      auto sub_splits = util::string_split<std::string>( s, "=" );

      if ( sub_splits.size() == 1 )
      {
        name = fmt::format( "custom_buff_{}", sub_splits[ 0 ] );
        continue;
      }

      if ( sub_splits.size() != 2 )
        throw std::invalid_argument( fmt::format( "Invalid sub option '{}'.", s ) );

      if ( sub_splits[ 0 ] == "name" )
      {
      }
      else if ( sub_splits[ 0 ] == "stat_value" )
      {
        stat_value = sub_splits[ 1 ];
        has_data = true;
      }
      else if ( sub_splits[ 0 ] == "start" )
      {
        start = timespan_t::from_seconds( util::to_double( sub_splits[ 1 ] ) );
      }
      else if ( sub_splits[ 0 ] == "duration" )
      {
        duration = timespan_t::from_seconds( util::to_double( sub_splits[ 1 ] ) );
      }
      else
      {
        throw std::invalid_argument( fmt::format( "Invalid option '{}'.", sub_splits[ 0 ] ) );
      }
    }

    if ( name.empty() )
      throw std::invalid_argument( fmt::format( "Missing buff name from '{}'.", value ) );

    // If the custom buff has no data, remove any existing buffs with the name.
    if ( !has_data )
    {
      custom_stat_buffs.erase( name );
      return true;
    }

    // Parse the data for the stat buff
    if ( !stat_value.empty() )
    {
      splits = util::string_split<std::string>( stat_value, "_" );
      if ( splits.size() != 2 )
        throw std::invalid_argument( fmt::format( "Invalid value option '{}'.", stat_value ) );

      stat_e stat = util::parse_stat_type( splits[ 1 ] );
      if ( stat == STAT_NONE )
        throw std::invalid_argument( fmt::format( "Invalid stat type '{}'.", splits[ 1 ] ) );

      bool is_percentage = false;
      if ( splits[ 0 ].back() == '%' )
      {
        // The stat type will be checked later when creating the buff to ensure that it supports percentage buffs.
        is_percentage = true;
        splits[ 0 ].pop_back();
      }
      double amount = util::to_double( splits[ 0 ] );
      custom_stat_buffs[ name ] = { stat, amount, start, duration, is_percentage };
    }

    return true;
  } ) );

  // Invoke External Buffs
  add_option( opt_string( "external_buffs.pool", external_buffs.pool ) );

  // Permanent External Buffs
  add_option( opt_int( "external_buffs.soleahs_secret_technique_ilevel", external_buffs.soleahs_secret_technique, 1, MAX_ILEVEL ) );

  // Timed External Buffs
  auto opt_external_buff_times = [] ( std::string_view name, std::vector<timespan_t>& times )
  {
    return opt_func( name, [ & times ] ( sim_t*, std::string_view, std::string_view val )
    {
      times.clear();
      auto splits = util::string_split<std::string_view>( val, "/" );
      for ( auto split : splits )
      {
        double t = util::to_double( split );
        if ( t < 0.0 )
          throw std::invalid_argument( fmt::format( "Invalid external buff application time '{}'.", t ) );

        times.push_back( timespan_t::from_seconds( t ) );
      }
      return true;
    } );
  };

  add_option( opt_external_buff_times( "external_buffs.power_infusion", external_buffs.power_infusion ) );
  add_option( opt_external_buff_times( "external_buffs.rallying_cry", external_buffs.rallying_cry ) );
  add_option( opt_external_buff_times( "external_buffs.potion_bomb_of_power", external_buffs.potion_bomb_of_power ) );

  // Additional Options for Timed External Buffs
  add_option( opt_obsoleted( "external_buffs.the_long_summer_rank" ) );

  // Player only options
  if ( !is_enemy() && !is_pet() )
  {
    add_option( opt_func( "azerite_override", std::bind( &azerite::azerite_state_t::parse_override,
      azerite.get(), std::placeholders::_1, std::placeholders::_2, std::placeholders::_3 ) ) );
    add_option( opt_func( "azerite_essences", std::bind( &azerite::azerite_essence_state_t::parse_azerite_essence,
      azerite_essence.get(), std::placeholders::_1, std::placeholders::_2, std::placeholders::_3 ) ) );

    add_option( opt_func( "override.player.spell_data", [ this ]( sim_t*, std::string_view, std::string_view value ) {
      dbc_override_->parse( *dbc, value );
      return true;
    } ) );
  }

  // Shadowlands options
  add_option( opt_string( "shadowlands.soleahs_secret_technique_type_override", shadowlands_opts.soleahs_secret_technique_type ) );

  // Dragonflight options
  add_option( opt_string( "dragonflight.gyroscopic_kaleidoscope_stat", dragonflight_opts.gyroscopic_kaleidoscope_stat ) );
  add_option( opt_string( "dragonflight.player.ruby_whelp_shell_training", dragonflight_opts.ruby_whelp_shell_training ) );
  add_option( opt_string( "dragonflight.player.ruby_whelp_shell_context", dragonflight_opts.ruby_whelp_shell_context ) );
  add_option( opt_string( "dragonflight.ominous_chromatic_essence_dragonflight", dragonflight_opts.ominous_chromatic_essence_dragonflight ) );
  add_option( opt_string( "dragonflight.ominous_chromatic_essence_allies", dragonflight_opts.ominous_chromatic_essence_allies ) );
  add_option( opt_bool( "dragonflight.ashkandur_humanoid", dragonflight_opts.ashkandur_humanoid ) );
  add_option( opt_string( "dragonflight.flowstone_starting_state", dragonflight_opts.flowstone_starting_state ) );
  add_option( opt_string( "dragonflight.spoils_of_neltharus_initial_type", dragonflight_opts.spoils_of_neltharus_initial_type ) );
  add_option( opt_float( "dragonflight.igneous_flowstone_double_lava_wave_chance", dragonflight_opts.igneous_flowstone_double_lava_wave_chance ) );
  add_option( opt_bool( "dragonflight.voice_of_the_silent_star_enable", dragonflight_opts.voice_of_the_silent_star_enable ) );
  add_option( opt_bool( "dragonflight.nymue_forced_immobilized", dragonflight_opts.nymue_forced_immobilized ) );
  add_option( opt_func( "dragonflight.witherbarks_branch_timing", [ this ]( sim_t*, std::string_view, std::string_view value ) {
    auto splits = util::string_split<std::string>( value, "/" );
    if ( splits.size() != 3 )
      throw std::invalid_argument( "Requires three timings separated by '/'." );

    for ( size_t i = 0; i < 3; i++ )
      dragonflight_opts.witherbarks_branch_timing[ i ] = timespan_t::from_seconds( util::to_double( splits[ i ] ) );

    return true;
  } ) );
  add_option( opt_bool( "dragonflight.rallied_to_victory_ally_estimate", dragonflight_opts.rallied_to_victory_ally_estimate ) );
  add_option( opt_float( "dragonflight.rallied_to_victory_min_allies", dragonflight_opts.rallied_to_victory_min_allies, 0.0, 4 ) );
  add_option( opt_bool( "dragonflight.player.embersoul_debuff_immune", dragonflight_opts.embersoul_debuff_immune ) );
  add_option( opt_float( "dragonflight.rallied_to_victory_multi_actor_skip_chance", dragonflight_opts.rallied_to_victory_multi_actor_skip_chance, 0.0, 1 ) );
  add_option( opt_bool( "dragonflight.string_of_delicacies_ally_estimate", dragonflight_opts.string_of_delicacies_ally_estimate ) );
  add_option( opt_float( "dragonflight.string_of_delicacies_min_allies", dragonflight_opts.string_of_delicacies_min_allies, 0.0, 4 ) );
  add_option( opt_float( "dragonflight.string_of_delicacies_multi_actor_skip_chance", dragonflight_opts.string_of_delicacies_multi_actor_skip_chance, 0.0, 1 ) );
  add_option( opt_string( "dragonflight.balefire_branch_loss_rng_type", dragonflight_opts.balefire_branch_loss_rng_type ) );
  add_option( opt_float( "dragonflight.balefire_branch_loss_rppm", dragonflight_opts.balefire_branch_loss_rppm, 0.0, std::numeric_limits<double>::max() ) );
  add_option( opt_float( "dragonflight.balefire_branch_loss_percent", dragonflight_opts.balefire_branch_loss_percent, 0.0, 1.0 ) );
  add_option( opt_timespan( "dragonflight.balefire_branch_loss_tick", dragonflight_opts.balefire_branch_loss_tick, 1_ms, 20_s ) );
  add_option( opt_int( "dragonflight.balefire_branch_loss_stacks", dragonflight_opts.balefire_branch_loss_stacks, 0, 20 ) );
  add_option( opt_uint( "dragonflight.verdant_conduit_allies", dragonflight_opts.verdant_conduit_allies, 0, 2 ) );
  add_option( opt_bool( "dragonflight.rashoks_use_true_overheal", dragonflight_opts.rashoks_use_true_overheal ) );
  add_option( opt_float( "dragonflight.rashoks_fake_overheal", dragonflight_opts.rashoks_fake_overheal, 0.0, 1.0 ) );
  add_option( opt_string( "dragonflight.timerunners_advantage", dragonflight_opts.timerunners_advantage ) );
  add_option( opt_int( "dragonflight.brilliance_party", dragonflight_opts.brilliance_party, 0, 4 ) );
  add_option( opt_int( "dragonflight.windweaver_party", dragonflight_opts.windweaver_party, 0, 4 ) );
  add_option( opt_string( "dragonflight.windweaver_party_ilvls", dragonflight_opts.windweaver_party_ilvls ) );
  add_option( opt_int( "dragonflight.emerald_coachs_whistle_ally_ilvl", dragonflight_opts.emerald_coachs_whistle_ally_ilvl ) );
  add_option( opt_bool( "dragonflight.emerald_coachs_whistle_ally_is_healer", dragonflight_opts.emerald_coachs_whistle_ally_is_healer ) );

  // The War Within options
  add_option( opt_string( "thewarwithin.sikrans_endless_arsenal_stance",
                          thewarwithin_opts.sikrans_endless_arsenal_stance ) );
  add_option( opt_int( "thewarwithin.ovinaxs_mercurial_egg_initial_primary_stacks",
                       thewarwithin_opts.ovinaxs_mercurial_egg_initial_primary_stacks, 0, 30 ) );
  add_option( opt_int( "thewarwithin.ovinaxs_mercurial_egg_desired_primary_stacks",
                       thewarwithin_opts.ovinaxs_mercurial_egg_desired_primary_stacks, 0, 30 ) );
  add_option( opt_int( "thewarwithin.ovinaxs_mercurial_egg_desired_primary_stacks_leeway",
                       thewarwithin_opts.ovinaxs_mercurial_egg_desired_primary_stacks_leeway, 0, 30 ) );
  add_option( opt_timespan( "thewarwithin.entropic_skardyn_core_pickup_delay",
                            thewarwithin_opts.entropic_skardyn_core_pickup_delay, 0_ms, 30_s ) );
  add_option( opt_timespan( "thewarwithin.entropic_skardyn_core_pickup_stddev",
                            thewarwithin_opts.entropic_skardyn_core_pickup_stddev, 0_ms, 30_s ) );
  add_option( opt_timespan( "thewarwithin.carved_blazikon_wax_enter_light_delay",
                            thewarwithin_opts.carved_blazikon_wax_enter_light_delay, 0_ms, 15_s ) );
  add_option( opt_timespan( "thewarwithin.carved_blazikon_wax_enter_light_stddev",
                            thewarwithin_opts.carved_blazikon_wax_enter_light_stddev, 0_ms, 15_s ) );
  add_option( opt_timespan( "thewarwithin.carved_blazikon_wax_stay_in_light_duration",
                            thewarwithin_opts.carved_blazikon_wax_stay_in_light_duration, 0_ms, 15_s ) );
  add_option( opt_timespan( "thewarwithin.carved_blazikon_wax_stay_in_light_stddev",
                            thewarwithin_opts.carved_blazikon_wax_stay_in_light_stddev, 0_ms, 15_s ) );
  add_option( opt_string( "thewarwithin.signet_of_the_priory_party_stats",
                          thewarwithin_opts.signet_of_the_priory_party_stats ) );
  add_option( opt_timespan( "thewarwithin.signet_of_the_priory_party_use_cooldown",
                            thewarwithin_opts.signet_of_the_priory_party_use_cooldown, 120_s, 240_s ) );
  add_option( opt_timespan( "thewarwithin.signet_of_the_priory_party_use_stddev",
                            thewarwithin_opts.signet_of_the_priory_party_use_stddev, 0_ms, 120_s ) );
  add_option( opt_float( "thewarwithin.harvesters_edict_intercept_chance",
                         thewarwithin_opts.harvesters_edict_intercept_chance, 0.0, 1.0 ) );
  add_option( opt_float( "thewarwithin.dawn_dusk_thread_lining_uptime",
                         thewarwithin_opts.dawn_dusk_thread_lining_uptime, 0.0, 1.0 ) );
  add_option( opt_timespan( "thewarwithin.dawn_dusk_thread_lining_update_interval",
                            thewarwithin_opts.dawn_dusk_thread_lining_update_interval, 1_s, timespan_t::max() ) );
  add_option( opt_timespan( "thewarwithin.dawn_dusk_thread_lining_update_interval_stddev",
                            thewarwithin_opts.dawn_dusk_thread_lining_update_interval_stddev, 1_s, timespan_t::max() ) );
  add_option( opt_timespan( "thewarwithin.embrace_of_the_cinderbee_timing",
                            thewarwithin_opts.embrace_of_the_cinderbee_timing, 100_ms, 10_s ) );
  add_option( opt_float( "thewarwithin.embrace_of_the_cinderbee_miss_chance",
                         thewarwithin_opts.embrace_of_the_cinderbee_miss_chance, 0, 1 ) );
  add_option( opt_int( "thewarwithin.nerubian_pheromone_secreter_pheromones",
                       thewarwithin_opts.nerubian_pheromone_secreter_pheromones, 0, 3 ) );
  add_option( opt_int( "thewarwithin.binding_of_binding_on_you",
                       thewarwithin_opts.binding_of_binding_on_you, 0, 29 ) );
  add_option( opt_float( "thewarwithin.binding_of_binding_ally_trigger_chance",
                         thewarwithin_opts.binding_of_binding_ally_trigger_chance, 0, 1 ) );
  add_option( opt_timespan( "thewarwithin.concoction_kiss_of_death_buff_remaining_min",
                            thewarwithin_opts.concoction_kiss_of_death_buff_remaining_min, 0_ms, 30_s ) );
  add_option( opt_timespan( "thewarwithin.concoction_kiss_of_death_buff_remaining_max",
                            thewarwithin_opts.concoction_kiss_of_death_buff_remaining_max, 0_ms, 30_s ) );
  add_option( opt_timespan( "thewarwithin.fury_of_the_stormrook_pickup_delay",
                            thewarwithin_opts.fury_of_the_stormrook_pickup_delay, 0_ms, 10_s ) );
  add_option( opt_timespan( "thewarwithin.fury_of_the_stormrook_pickup_stddev",
                            thewarwithin_opts.fury_of_the_stormrook_pickup_stddev, 0_ms, 10_s ) );
  add_option( opt_float( "thewarwithin.mereldars_toll_ally_trigger_chance",
                         thewarwithin_opts.mereldars_toll_ally_trigger_chance, 0, 1 ) );
  add_option( opt_float( "thewarwithin.sureki_zealots_insignia_rppm_multiplier",
                         thewarwithin_opts.sureki_zealots_insignia_rppm_multiplier, 0, 1 ) );
  add_option( opt_string( "thewarwithin.windsingers_passive_stat",
                           thewarwithin_opts.windsingers_passive_stat ) );
  add_option( opt_string( "thewarwithin.mister_locknstalk_mode",
                           thewarwithin_opts.mister_locknstalk_mode ) );
  add_option( opt_string( "thewarwithin.jastor_diamond_ally_stat",
                           thewarwithin_opts.jastor_diamond_ally_stat ) );
  add_option( opt_float( "thewarwithin.suspicious_energy_drink_bonus_chance",
                         thewarwithin_opts.suspicious_energy_drink_bonus_chance, 0, 1 ) );
  add_option( opt_timespan( "thewarwithin.additional_gcd_time",
                             thewarwithin_opts.additional_gcd_time, 0_s, 10_s ) );
  add_option( opt_string( "thewarwithin.alchemical_chaos_initial_stat",
                           thewarwithin_opts.alchemical_initial_stat ) );
  add_option( opt_string( "thewarwithin.alchemical_chaos_initial_penalty_stats",
                          thewarwithin_opts.alchemical_initial_penalty ) );
  add_option( opt_bool( "thewarwithin.incorporeal_essence_gorger_ethereal", thewarwithin_opts.incorporeal_essence_gorger_ethereal ) );
  add_option( opt_float( "thewarwithin.astral_antenna_miss_chance", thewarwithin_opts.astral_antenna_miss_chance, 0.0, 1.0 ) );
  add_option( opt_int( "thewarwithin.screams_of_a_forgotten_sky_initial_stacks",
                       thewarwithin_opts.screams_of_a_forgotten_sky_initial_stacks, 0, 99 ) );
  add_option( opt_bool( "thewarwithin.brand_of_ceaseless_ire_force_full_uptime",
                        thewarwithin_opts.brand_of_ceaseless_ire_force_full_uptime ) );
  add_option( opt_bool( "thewarwithin.attuned_to_the_aether",
                        thewarwithin_opts.attuned_to_the_aether ) );

  // Midnight options
  add_option(   opt_string( "midnight.darkmoon_hunt_race",
                            midnight_opts.darkmoon_hunt_race ) );
  add_option( opt_timespan( "midnight.sealed_chaos_urn_dispell_time",
                            midnight_opts.sealed_chaos_urn_dispell_time, 500_ms, 5_s ) );
  add_option(     opt_bool( "midnight.sealed_chaos_urn_dispell",
                            midnight_opts.sealed_chaos_urn_dispell ) );
  add_option(    opt_float( "midnight.refueling_orb_heal_chance",
                            midnight_opts.refueling_orb_heal_chance, 0, 1 ) );
  add_option(     opt_bool( "midnight.crucible_of_erratic_energies_violence",
                            midnight_opts.crucible_of_erratic_energies_violence ) );
  add_option(     opt_bool( "midnight.crucible_of_erratic_energies_sustenance",
                            midnight_opts.crucible_of_erratic_energies_sustenance ) );
  add_option(     opt_bool( "midnight.crucible_of_erratic_energies_predation",
                            midnight_opts.crucible_of_erratic_energies_predation ) );
  add_option(    opt_float( "midnight.vessel_of_tortured_souls_miss_chance",
                            midnight_opts.vessel_of_tortured_souls_miss_chance, 0, 1 ) );
  add_option(    opt_float( "midnight.arcanoweave_trappings_uptime",
                            midnight_opts.arcanoweave_trappings_uptime, 0.0, 1.0 ) );
  add_option( opt_timespan( "midnight.arcanoweave_trappings_update_interval",
                            midnight_opts.arcanoweave_trappings_update_interval, 1_s, timespan_t::max() ) );
  add_option( opt_timespan( "midnight.arcanoweave_trappings_update_interval_stddev",
                            midnight_opts.arcanoweave_trappings_update_interval_stddev, 1_s, timespan_t::max() ) );
  add_option(    opt_float( "midnight.lightspire_core_duration_multiplier",
                            midnight_opts.lightspire_core_duration_multiplier, 0.1, 1.0 ) );
  add_option(    opt_float( "midnight.rite_of_the_hashey_uptime",
                            midnight_opts.rite_of_the_hashey_uptime, 0.0, 1.0 ) );
  add_option(    opt_float( "midnight.permafrost_essence_shield_proc_chance",
                            midnight_opts.permafrost_essence_shield_proc_chance, 0.0, 1.0 ) );
  add_option(     opt_bool( "midnight.permafrost_essence_use_health_threshold",
                            midnight_opts.permafrost_essence_use_health_threshold ) );
}

player_t* player_t::create( sim_t*, const player_description_t& )
{
  return nullptr;
}

/**
 * Analyze statistical data of a player
 */
void player_t::analyze( sim_t& s )
{
  assert( s.iterations > 0 );

  range::for_each( buff_list, []( buff_t* b ) { b->analyze(); } );

  range::for_each( proc_list, []( proc_t* pr ) { pr->analyze(); } );
  range::for_each( uptime_list, []( uptime_t* up ) { up->analyze(); } );
  range::for_each( benefit_list, []( benefit_t* ben ) { ben->analyze(); } );
  range::for_each( cooldown_waste_data_list, std::mem_fn( &cooldown_waste_data_t::analyze ) );

  range::sort( stats_list, []( const stats_t* l, const stats_t* r ) { return l->name_str < r->name_str; } );
  range::sort( gain_list, []( const gain_t* l, const gain_t* r ) { return l->name_str < r-> name_str; } );

  if ( quiet )
    return;

  // If we have no data collected for an actor, also verify thier pets have data collected
  // Relevant for fight styles with an initial sleeping target
  if ( collected_data.fight_length.mean() == 0 )
  {
    auto it = range::find_if( pet_list, []( pet_t* pet ) {
      return pet->collected_data.fight_length.mean() > 0 ||
             pet->iteration_fight_length.total_seconds() > 0;
    });

    if ( it == pet_list.end() )
      return;
  }

  range::for_each( sample_data_list, []( sample_data_helper_t* sd ) { sd->analyze(); } );

  // Pet Chart Adjustment ===================================================
  size_t max_buckets = static_cast<size_t>( collected_data.fight_length.max() );

  // Make the pet graphs the same length as owner's
  if ( is_pet() )
  {
    player_t* o = cast_pet()->owner;
    max_buckets = static_cast<size_t>( o->collected_data.fight_length.max() );
  }

  // Stats Analysis =========================================================
  std::vector<stats_t*> tmp_stats_list( stats_list.begin(), stats_list.end() );

  for ( const auto* pet : pet_list )
  {
     // Append pet -> stats_list to stats_list
    tmp_stats_list.insert( tmp_stats_list.end(), pet->stats_list.begin(), pet->stats_list.end() );
  }

  if ( !is_pet() )
  {
    range::for_each( tmp_stats_list, [this]( stats_t* stats ) {
      stats->analyze();

      if ( stats->type == STATS_DMG )
      {
        stats->portion_amount =
            collected_data.compound_dmg.mean() ? stats->actual_amount.mean() / collected_data.compound_dmg.mean() : 0.0;
      }
      else if ( stats->type == STATS_HEAL || stats->type == STATS_ABSORB )
      {
        stats->portion_amount = collected_data.compound_heal.mean()
                                    ? stats->actual_amount.mean()
                                    : collected_data.compound_absorb.mean() ? stats->actual_amount.mean() : 0.0;

        double total_heal_and_absorb = collected_data.compound_heal.mean() + collected_data.compound_absorb.mean();

        if ( total_heal_and_absorb )
        {
          stats->portion_amount /= total_heal_and_absorb;
        }
      }
    } );
  }

  // Actor Lists ============================================================

  if ( !quiet && !is_enemy() && !is_add() && !( is_pet() && s.report_pets_separately ) )
  {
    s.players_by_dps.push_back( this );
    s.players_by_priority_dps.push_back( this );
    s.players_by_hps.push_back( this );
    s.players_by_hps_plus_aps.push_back( this );
    s.players_by_dtps.push_back( this );
    s.players_by_name.push_back( this );
    s.players_by_apm.push_back( this );
    s.players_by_variance.push_back( this );
  }

  if ( !quiet && ( is_enemy() || is_add() ) && !( is_pet() && s.report_pets_separately ) )
  {
    s.targets_by_name.push_back( this );
  }

  // Resources & Gains ======================================================

  if ( static_cast<size_t>( primary_resource() ) < collected_data.resource_lost.size() )
  {
    double rl = collected_data.resource_lost[ primary_resource() ].mean();

    dpr = ( rl > 0 ) ? ( collected_data.dmg.mean() / rl ) : -1.0;
    hpr = ( rl > 0 ) ? ( collected_data.heal.mean() / rl ) : -1.0;

    rps_loss = rl / collected_data.fight_length.mean();
  }

  if ( static_cast<size_t>( primary_resource() ) < collected_data.resource_gained.size() )
  {
    double rg = collected_data.resource_gained[ primary_resource() ].mean();

    rps_gain = rg / collected_data.fight_length.mean();
  }

  // When single_actor_batch=1 is used in conjunction with target_error, each actor has run varying
  // number of iterations to finish. The total number of iterations ran for each actor (when
  // single_actor_batch=1) is stored in the actor-collected data structure.
  //
  // Note, gain_t objects do not currently skip the first iteration for data collection. Thus, to
  // have information consistent in the reports, we use actor total iterations + the number of
  // threads as the divisor for resource-related data.
  int iterations =
      collected_data.total_iterations > 0 ? collected_data.total_iterations + sim->threads : sim->iterations;

  range::for_each( gain_list, [iterations]( gain_t* g ) { g->analyze( iterations ); } );

  range::for_each( pet_list, [iterations]( pet_t* p ) {
    range::for_each( p->gain_list, [iterations]( gain_t* g ) { g->analyze( iterations ); } );
  } );

  // Damage Timelines =======================================================

  if ( sim->report_details != 0 )
  {
    collected_data.timeline_dmg.init( max_buckets );
    bool is_hps = primary_role() == ROLE_HEAL;
    range::for_each( tmp_stats_list, [this, is_hps, max_buckets]( stats_t* stats ) {
      if ( stats->timeline_amount == nullptr )
      {
        return;
      }

      if ( ( stats->type != STATS_DMG ) == is_hps )
      {
        size_t j_max = std::min( max_buckets, stats->timeline_amount->data().size() );
        for ( size_t j = 0; j < j_max; j++ )
        {
          collected_data.timeline_dmg.add( j, stats->timeline_amount->data()[ j ] );
        }
      }
    } );
  }
  else
  {
    if ( !sim->single_actor_batch )
    {
      collected_data.timeline_dmg.adjust( *sim );
    }
    else
    {
      collected_data.timeline_dmg.adjust( collected_data.fight_length );
    }
  }
}

/**
 * Return the scaling metric over which this player gets scaled.
 *
 * This is used for scale factors, reforge plots, etc. as the default metric to display/calculate.
 * By default this will be personal dps or hps, but can also be dtps, tmi, etc.
 */
scaling_metric_data_t player_t::scaling_for_metric( scale_metric_e metric ) const
{
  const player_t* q = nullptr;
  if ( !sim->scaling->scale_over_player.empty() )
    q = sim->find_player( sim->scaling->scale_over_player );
  if ( !q )
    q = this;

  switch ( metric )
  {
    case SCALE_METRIC_DPS:
      return { metric, q->collected_data.dps };
    case SCALE_METRIC_DPSE:
      return { metric, q->collected_data.dpse };
    case SCALE_METRIC_HPS:
      return { metric, q->collected_data.hps };
    case SCALE_METRIC_HPSE:
      return { metric, q->collected_data.hpse };
    case SCALE_METRIC_APS:
      return { metric, q->collected_data.aps };
    case SCALE_METRIC_DPSP:
      return { metric, q->collected_data.prioritydps };
    case SCALE_METRIC_HAPS:
    {
      double mean   = q->collected_data.hps.mean() + q->collected_data.aps.mean();
      double stddev = sqrt( q->collected_data.hps.mean_variance + q->collected_data.aps.mean_variance );
      return { metric, "Healing + Absorb per second", mean, stddev };
    }
    case SCALE_METRIC_DHAPS:
    {
      double hps_value = q->sim->dhaps_healing_weight;
      double mean   = ( q->collected_data.hps.mean() + q->collected_data.aps.mean() ) * hps_value + q->collected_data.dps.mean();
      double stddev = sqrt( ( q->collected_data.hps.mean_variance + q->collected_data.aps.mean_variance ) * hps_value + q->collected_data.dps.mean_variance );
      return { metric, "Damage + Healing + Absorb per second (haps weight: " + std::to_string( hps_value ) + ")", mean, stddev };
    }
    case SCALE_METRIC_DTPS:
      return { metric, q->collected_data.dtps };
    case SCALE_METRIC_DMG_TAKEN:
      return { metric, q->collected_data.dmg_taken };
    case SCALE_METRIC_HTPS:
      return { metric, q->collected_data.htps };
    case SCALE_METRIC_DEATHS:
      return { metric, q->collected_data.deaths };
    case SCALE_METRIC_TIME:
      return { metric, q->collected_data.fight_length };
    case SCALE_METRIC_RAID_DPS:
      return { metric, q->sim->raid_dps };
    default:
      if ( q->primary_role() == ROLE_TANK )
        return { SCALE_METRIC_DTPS, q->collected_data.dtps };
      else if ( q->primary_role() == ROLE_HEAL )
        return scaling_for_metric( SCALE_METRIC_HAPS );
      else
        return { SCALE_METRIC_DPS, q->collected_data.dps };
  }
}

bool player_t::requires_data_collection() const
{
  if ( active_during_iteration )
    return true;

  for ( const auto* pet : pet_list )
  {
    if ( pet->requires_data_collection() )
      return true;
  }

  return false;
}

/**
 * Change the player position ( fron/back, etc. ) and update attack hit table
 */
void player_t::change_position( position_e new_pos )
{
  sim->print_debug( "{} changes position from {} to {}.", name(), position(), new_pos );

  current.position = new_pos;
}

/**
 * Add a new resource callback, firing when a specified threshold for a resource is crossed.
 * Can either be a absolute value, or if use_pct is set, a percent-point value.
 *
 * Warning: Does not work for main enemy target on sim->iterations==0 or sim->fixed_time==1
 */
void player_t::register_resource_callback(resource_e resource, double value, resource_callback_function_t callback,
    bool use_pct, bool fire_once)
{
  resource_callback_entry_t entry{resource, value, use_pct, fire_once, false, std::move(callback)};
  resource_callbacks.push_back(entry);
  has_active_resource_callbacks = true;
  sim->print_debug("{} resource callback registered. resource={} value={} pct={} fire_once={}",
      name(), resource, value, use_pct, fire_once);
}

/**
 * If we have trigered all active resource callbacks in a iteration, disable the player-wide flag to check for
 * resource callbacks.
 */
void player_t::check_resource_callback_deactivation()
{
  for (auto& callback : resource_callbacks)
  {
    if (!callback.is_consumed)
      return;
  }
  has_active_resource_callbacks = false;
}

/**
 * Reset resource callback system.
 */
void player_t::reset_resource_callbacks()
{
  for (auto& callback : resource_callbacks)
  {
    callback.is_consumed = false;
    has_active_resource_callbacks = true;
  }
}

/**
 * Checks if a resource callback condition has been met and if yes activate it.
 */
void player_t::check_resource_change_for_callback( resource_e resource, double previous_amount,
                                                   double previous_pct_points )
{
  for ( auto& callback : resource_callbacks )
  {
    if ( callback.is_consumed )
      continue;

    if ( callback.resource != resource )
      continue;

    // Evaluate if callback condition is met.
    bool callback_condition_valid = false;
    bool increasing;

    if ( callback.is_pct )
    {
      double current_pct_points = resources.current[ resource ] / resources.max[ resource ] * 100.0;
      if ( callback.value < previous_pct_points && callback.value >= current_pct_points )
      {
        callback_condition_valid = true;
        increasing = false;
      }
      else if ( callback.value >= previous_pct_points && callback.value < current_pct_points )
      {
        callback_condition_valid = true;
        increasing = true;
      }
    }
    else
    {
      double current_amount = resources.current[ resource ];
      if ( callback.value < previous_amount && callback.value >= current_amount )
      {
        callback_condition_valid = true;
        increasing = false;
      }
      else if ( callback.value >= previous_amount && callback.value < current_amount )
      {
        callback_condition_valid = true;
        increasing = true;
      }
    }

    if ( !callback_condition_valid )
    {
      continue;
    }

    sim->print_debug( "{} resource callback triggered.", name() );

    // We have a callback event, trigger stuff.
    callback.callback( increasing );

    if ( callback.fire_once )
    {
      callback.is_consumed = true;
    }
  }

  check_resource_callback_deactivation();
}

rng::rng_t& player_t::rng()
{
  return sim -> rng();
}

rng::rng_t& player_t::rng() const
{
  return sim -> rng();
}

timespan_t player_t::time_to_move() const
{
  if ( current.distance_to_move > 0 || current.moving_away > 0 )
  {
    // Add 1ms of time to ensure that we finish this run. This is necessary due to the millisecond accuracy in our
    // timing system.
    return timespan_t::from_seconds( ( current.distance_to_move + current.moving_away ) / composite_movement_speed() +
                                     0.001 );
  }
  else
    return timespan_t::zero();
}

void player_t::trigger_movement( double distance, movement_direction_type direction )
{
  // Distance of 0 disables movement
  if ( distance == 0 )
    do_update_movement( 9999 );
  else
  {
    if ( direction == movement_direction_type::AWAY )
      current.moving_away = distance;
    else
      current.distance_to_move = distance;
    current.movement_direction = direction;
    if ( buffs.movement )
    {
      buffs.movement->trigger();
    }
  }
}

void player_t::update_movement( timespan_t duration )
{
  // Presume stunned players don't move
  if ( buffs.stunned->check() )
    return;

  double yards = duration.total_seconds() * composite_movement_speed();
  do_update_movement( yards );

  if ( sim->debug )
  {
    if ( current.movement_direction == movement_direction_type::TOWARDS )
    {
      sim->out_debug.printf(
          "Player %s movement towards target, direction=%s speed=%f distance_covered=%f to_go=%f duration=%f", name(),
          util::movement_direction_string( movement_direction() ), composite_movement_speed(), yards,
          current.distance_to_move, duration.total_seconds() );
    }
    else
    {
      sim->out_debug.printf(
          "Player %s movement away from target, direction=%s speed=%f distance_covered=%f to_go=%f duration=%f", name(),
          util::movement_direction_string( movement_direction() ), composite_movement_speed(), yards,
          current.moving_away, duration.total_seconds() );
    }
  }
}

/**
 * Instant teleport. No overshooting support for now.
 */
void player_t::teleport( double yards, timespan_t )
{
  do_update_movement( yards );

  if ( sim->debug )
    sim->out_debug.printf( "Player %s warp, direction=%s speed=LIGHTSPEED! distance_covered=%f to_go=%f", name(),
                           util::movement_direction_string( movement_direction() ), yards, current.distance_to_move );
}

/**
 * Update movement data, and also control the buff
 */
void player_t::do_update_movement( double yards )
{
  if ( ( yards >= current.distance_to_move ) && current.moving_away <= 0 )
  {
    // x_position += current.distance_to_move;
    current.distance_to_move   = 0;
    current.movement_direction = movement_direction_type::NONE;
    if ( buffs.movement )
    {
      buffs.movement->expire();
    }
  }
  else
  {
    if ( current.moving_away > 0 )
    {
      // x_position -= yards;
      current.moving_away -= yards;
      current.distance_to_move += yards;
    }
    else
    {
      // x_position += yards;
      current.moving_away        = 0;
      current.movement_direction = movement_direction_type::TOWARDS;
      current.distance_to_move -= yards;
    }
  }
}

// Note, root call needs to set player_t::visited_apls_ to 0
action_t* player_t::select_action( const action_priority_list_t& list,
                                   execute_type                  et,
                                   const action_t*               context )
{
  // Mark this action list as visited with the APL internal id
  visited_apls_ |= list.internal_id_mask;

  // Cached copy for recursion, we'll need it if we come back from a
  // call_action_list tree, with nothing to show for it.
  uint64_t _visited       = visited_apls_;
  size_t attempted_random = 0;

  util::span<action_t* const> a_list;
  switch ( et )
  {
    case execute_type::OFF_GCD:
      a_list = list.off_gcd_actions;
      break;
    case execute_type::CAST_WHILE_CASTING:
      a_list = list.cast_while_casting_actions;
      break;
    default:
      a_list = list.foreground_action_list;
      break;
  }

  for ( action_t* a : a_list )
  {
    visited_apls_ = _visited;

    if ( list.random == 1 )
    {
      a = rng().range( a_list );
    }
    else
    {
      double skill = list.player->current.skill - list.player->current.skill_debuff;
      if ( skill != 1 && rng().roll( ( 1 - skill ) * 0.5 ) )
      {
        size_t max_random_attempts = static_cast<size_t>( a_list.size() * ( skill * 0.5 ) );
        a = rng().range( a_list );
        attempted_random++;
        // Limit the amount of attempts to select a random action based on skill, then bail out and try again in 100
        // ms.
        if ( attempted_random > max_random_attempts )
          break;
      }
    }

    if ( context && a == context )
    {
      return nullptr;
    }

    if ( a->background )
      continue;

    if ( a->option.wait_on_ready == 1 )
      break;

    if ( a->action_ready() )
    {
      // Execute variable operation, and continue processing
      if ( a->type == ACTION_VARIABLE )
      {
        a->execute();
        continue;
      }
      // Call_action_list action, don't execute anything, but rather recurse
      // into the called action list.
      else if ( a->type == ACTION_CALL )
      {
        call_action_list_t* call = static_cast<call_action_list_t*>( a );
        // If the called APLs bitflag (based on internal id) is up, we're in an
        // infinite loop, and need to cancel the sim
        if ( visited_apls_ & call->alist->internal_id_mask )
        {
          throw sc_runtime_error( fmt::format( "{} {} in infinite loop.", *this, *call ) );
        }

        // We get an action from the call, return it
        if ( action_t* real_a = select_action( *call->alist, et, context ) )
        {
          if ( context == nullptr && real_a->action_list )
            real_a->action_list->used = true;
          return real_a;
        }
      }
      // .. in branch prediction, we trust
      else
      {
        return a;
      }
    }
  }

  return nullptr;
}

player_t* player_t::actor_by_name_str( util::string_view name ) const
{
  // Check player pets first
  for ( auto* pet : pet_list )
  {
    if ( util::str_compare_ci( pet->name_str, name ) )
      return pet;
  }

  // Check harmful targets list
  for ( auto* t : sim->target_list )
  {
    if ( util::str_compare_ci( t->name_str, name ) )
      return t;
  }

  // Finally, check player (non pet list), don't support targeting other
  // people's pets for now
  for ( auto* p : sim->player_no_pet_list )
  {
    if ( util::str_compare_ci( p->name_str, name ) )
      return p;
  }

  return nullptr;
}

slot_e player_t::parent_item_slot( const item_t& item ) const
{
  unsigned parent_id = dbc->parent_item( item.parsed.data.id );
  if ( parent_id == 0 )
  {
    return SLOT_INVALID;
  }

  auto it = range::find_if( items, [ parent_id ]( const item_t& item ) { return parent_id == item.parsed.data.id; } );
  if ( it != items.end() )
  {
    return ( *it ).slot;
  }

  return SLOT_INVALID;
}

slot_e player_t::child_item_slot( const item_t& item ) const
{
  unsigned child_id = dbc->child_item( item.parsed.data.id );
  if ( child_id == 0 )
  {
    return SLOT_INVALID;
  }

  auto it = range::find_if( items, [ child_id ]( const item_t& item ) { return child_id == item.parsed.data.id; } );
  if ( it != items.end() )
  {
    return ( *it ).slot;
  }

  return SLOT_INVALID;
}

timespan_t player_t::cooldown_tolerance() const
{
  return cooldown_tolerance_ < timespan_t::zero() ? sim -> default_cooldown_tolerance : cooldown_tolerance_;
}

pet_t* player_t::cast_pet()
{
  return debug_cast<pet_t*>( this );
}

const pet_t* player_t::cast_pet() const
{
  return debug_cast<const pet_t*>( this );
}

void player_t::add_active_dot( const dot_t* dot )
{
  assert( dot );
  if ( !dot )
    return;

  if ( active_dots.size() < as<size_t>( dot->internal_id + 1 ) )
    active_dots.resize( dot->internal_id + 1 );

  active_dots[ dot->internal_id ]++;
  if ( sim->debug )
    sim->out_debug.printf( "%s Increasing %s dot count to %u", name(), dot_map[ dot->internal_id ].c_str(), active_dots[ dot->internal_id ] );
}

void player_t::remove_active_dot( const dot_t* dot )
{
  assert( dot );
  assert( active_dots.size() > as<size_t>( dot->internal_id ) );
  assert( active_dots[ dot->internal_id ] > 0 );

  if ( !dot )
    return;

  active_dots[ dot->internal_id ]--;
  if ( sim->debug )
    sim->out_debug.printf( "%s Decreasing %s dot count to %u", name(), dot_map[ dot->internal_id ].c_str(), active_dots[ dot->internal_id ] );
}

unsigned player_t::get_active_dots( const dot_t* dot ) const
{
  assert( dot );

  if ( !dot || active_dots.size() <= as<size_t>( dot->internal_id ) )
    return 0;

  return active_dots[ dot->internal_id ];
}

void player_t::adjust_dynamic_cooldowns()
{
  range::for_each( dynamic_cooldown_list, []( cooldown_t* cd ) { cd -> adjust_recharge_multiplier(); } );
}

// TODO: This currently does not take minimum GCD into account, should it?
void player_t::adjust_global_cooldown( gcd_haste_type ht )
{
  // Don't adjust if the current gcd isnt hasted
  if ( ht == gcd_haste_type::NONE )
  {
    return;
  }

  // Don't adjust if the changed haste type isnt current GCD haste scaling type
  if ( ht != gcd_haste_type::HASTE && ht != gcd_type )
  {
    return;
  }

  // Don't adjust elapsed GCDs
  if ( ( readying && readying->occurs() <= sim->current_time() ) || ( gcd_ready <= sim->current_time() ) )
  {
    return;
  }

  double new_haste = 0;
  switch ( ht )
  {
    case gcd_haste_type::SPELL_HASTE:
      new_haste = cache.spell_haste();
      break;
    case gcd_haste_type::ATTACK_HASTE:
      new_haste = cache.attack_haste();
      break;
    case gcd_haste_type::SPELL_CAST_SPEED:
      new_haste = cache.spell_cast_speed();
      break;
    case gcd_haste_type::AUTO_ATTACK_SPEED:
      new_haste = cache.auto_attack_speed();
      break;
    // SPEED_ANY and HASTE_ANY are nonsensical, actions have to have a correct GCD haste type so
    // they can be adjusted on state changes.
    default:
      assert( 0 && "player_t::adjust_global_cooldown called without proper haste type" );
      break;
  }

  // Haste did not change, don't do anything
  if ( new_haste == gcd_current_haste_value )
  {
    return;
  }

  double delta           = new_haste / gcd_current_haste_value;
  timespan_t remains     = readying ? readying->remains() : ( gcd_ready - sim->current_time() );
  timespan_t new_remains = remains * delta;

  // Don't bother processing too small (less than a millisecond) granularity changes
  if ( remains == new_remains )
  {
    return;
  }

  if ( sim->debug )
  {
    sim->out_debug.printf(
        "%s adjusting GCD due to haste change: old_ready=%.3f new_ready=%.3f old_haste=%f new_haste=%f delta=%f",
        name(), ( sim->current_time() + remains ).total_seconds(),
        ( sim->current_time() + new_remains ).total_seconds(), gcd_current_haste_value, new_haste, delta );
  }

  // We need to adjust the event (GCD is already elapsing)
  if ( readying )
  {
    // GCD speeding up, recreate the event
    if ( delta < 1 )
    {
      event_t::cancel( readying );
      readying = make_event<player_ready_event_t>( *sim, *this, new_remains );
    }
    // GCD slowing down, just reschedule into future
    else
    {
      readying->reschedule( new_remains );
    }
  }

  gcd_ready               = sim->current_time() + new_remains;
  gcd_current_haste_value = new_haste;
}

void player_t::adjust_auto_attack( gcd_haste_type ht )
{
  // Don't adjust autoattacks on spell-derived haste
  if ( ht == gcd_haste_type::SPELL_CAST_SPEED || ht == gcd_haste_type::SPELL_HASTE )
  {
    return;
  }

  if ( main_hand_attack )
    main_hand_attack->reschedule_auto_attack( current_auto_attack_speed );
  if ( off_hand_attack )
    off_hand_attack->reschedule_auto_attack( current_auto_attack_speed );

  current_auto_attack_speed = cache.auto_attack_speed();
}

timespan_t find_minimum_cd( const std::vector<std::pair<const cooldown_t*, const cooldown_t*>>& list )
{
  timespan_t min_ready = timespan_t::min();

  range::for_each( list, [ &min_ready ]( std::pair<const cooldown_t*, const cooldown_t*> cds ) {
    // Take the larger of the primary cooldown and the internal cooldown for a given ability
    timespan_t action_cd = std::max( cds.first ? cds.first->queueable() : timespan_t::min(),
                                     cds.second ? cds.second->queueable() : timespan_t::min() );
    if ( min_ready == timespan_t::min() || action_cd < min_ready )
    {
      min_ready = action_cd;
    }
  } );

  return min_ready;
}

// Calculate the minimum readiness time for all off gcd actions that are flagged as usable during
// gcd (i.e., action_t::use_off_gcd == true). Note that this does not take into account
// line_cooldown option, since that is APL-line specific.
void player_t::update_off_gcd_ready()
{
  if ( off_gcd_cd.empty() )
  {
    return;
  }

  off_gcd_ready = find_minimum_cd( off_gcd_cd );

  sim->print_debug( "{} next off-GCD cooldown ready at {}", *this, off_gcd_ready.total_seconds() );

  schedule_off_gcd_ready();
}

// Calculate the minimum readiness time for all off gcd actions that are flagged as usable during
// gcd (i.e., action_t::use_off_gcd == true). Note that this does not take into account
// line_cooldown option, since that is APL-line specific.
void player_t::update_cast_while_casting_ready()
{
  if ( cast_while_casting_cd.empty() )
  {
    return;
  }

  cast_while_casting_ready = find_minimum_cd( cast_while_casting_cd );

  sim->print_debug( "{} next cast while casting cooldown ready at {}",
                    *this, cast_while_casting_ready.total_seconds() );

  schedule_cwc_ready();
}

/**
 * Verify that the user input (APL) contains an use-item line for all on-use items
 */
bool player_t::verify_use_items() const
{
  if ( !sim->use_item_verification || ( action_list_str.empty() && action_priority_list.empty() ) )
  {
    return true;
  }

  std::vector<const use_item_t*> use_actions;
  std::vector<const item_t*> missing_actions;

  // Collect use_item actions
  range::for_each( action_list, [&use_actions]( const action_t* action ) {
    if ( auto ptr = dynamic_cast<const use_item_t*>( action ) )
    {
      use_actions.push_back( ptr );
    }
  } );

  // For all items that have on-use effects, ensure that there's a use action
  range::for_each( items, [&use_actions, &missing_actions]( const item_t& item ) {
    auto effect_it = range::find_if( item.parsed.special_effects, []( const special_effect_t* effect ) {
      return effect->source == SPECIAL_EFFECT_SOURCE_ITEM && effect->type == SPECIAL_EFFECT_USE;
    } );

    if ( effect_it != item.parsed.special_effects.end() )
    {
      // Each use_item action will have an associated item_t pointer for the item used, so just
      // compare the effect and use_item "item" pointers
      auto action_it = range::find_if(
          use_actions, [&effect_it]( const use_item_t* action ) { return action->item == ( *effect_it )->item; } );

      if ( action_it == use_actions.end() )
      {
        missing_actions.push_back( &item );
      }
    }
  } );

  // Nag about any items that are missing on-use actions
  range::for_each( missing_actions, [this]( const item_t* item ) {
    sim->errorf( "%s missing 'use_item' action for item \"%s\" (slot=%s)", name(), item->name(), item->slot_name() );
  } );

  return missing_actions.empty();
}

/**
 * Cancel the main hand (and off hand, if applicable) swing timer
 */
void player_t::cancel_auto_attacks()
{
  if ( main_hand_attack || off_hand_attack )
  {
    sim->print_debug( "Cancelling auto attack swings" );
  }

  if ( main_hand_attack && main_hand_attack->execute_event )
  {
    event_t::cancel( main_hand_attack->execute_event );
  }

  if ( off_hand_attack && off_hand_attack->execute_event )
  {
    event_t::cancel( off_hand_attack->execute_event );
  }
}

/**
 * Reset the main hand (and off hand, if applicable) swing timer
 * Optionally delay by a set amount
 */
void player_t::reset_auto_attacks( timespan_t delay, proc_t* proc )
{
  if( main_hand_attack || off_hand_attack )
  {
    if ( delay == timespan_t::zero() )
      sim->print_debug( "Resetting auto attack swing timers" );
    else
      sim->print_debug( "Resetting auto attack swing timers with an additional delay of {}", delay );

    if ( proc )
      proc->occur();
  }

  if ( main_hand_attack && main_hand_attack->execute_event )
  {
    event_t::cancel( main_hand_attack->execute_event );
    main_hand_attack->schedule_execute();
    if ( delay > timespan_t::zero() && main_hand_attack->execute_event )
    {
      main_hand_attack->execute_event->reschedule( main_hand_attack->execute_event->remains() + delay );
    }
  }

  if ( off_hand_attack && off_hand_attack->execute_event )
  {
    event_t::cancel( off_hand_attack->execute_event );
    off_hand_attack->schedule_execute();
    if ( delay > timespan_t::zero() && off_hand_attack->execute_event )
    {
      off_hand_attack->execute_event->reschedule( off_hand_attack->execute_event->remains() + delay );
    }
  }
}

/**
 * Delay the main hand (and off hand, if applicable) swing timer
 */
void player_t::delay_auto_attacks( timespan_t delay, proc_t* proc )
{
  if ( delay == timespan_t::zero() )
    return;

  bool delayed = false;

  if ( main_hand_attack && main_hand_attack->execute_event )
  {
    sim->print_debug( "Delaying MH auto attack swing timer by {} to {}", delay, main_hand_attack->execute_event->remains() + delay );
    main_hand_attack->execute_event->reschedule( main_hand_attack->execute_event->remains() + delay );
    delayed = true;
  }

  if ( off_hand_attack && off_hand_attack->execute_event )
  {
    sim->print_debug( "Delaying OH auto attack swing timer by {} to {}", delay, off_hand_attack->execute_event->remains() + delay );
    off_hand_attack->execute_event->reschedule( off_hand_attack->execute_event->remains() + delay );
    delayed = true;
  }

  if ( proc && delayed )
    proc->occur();
}

/**
* Delay ranged swing timer
*/
void player_t::delay_ranged_auto_attacks( timespan_t delay, proc_t* proc )
{
  if ( delay == timespan_t::zero() )
    return;

  bool delayed = false;

  if ( main_hand_attack && main_hand_attack->execute_event && dynamic_cast<ranged_attack_t*>(main_hand_attack) )
  {
    sim->print_debug( "Delaying ranged auto attack swing timer by {} to {}", delay, main_hand_attack->execute_event->remains() + delay );
    main_hand_attack->execute_event->reschedule( main_hand_attack->execute_event->remains() + delay );
    delayed = true;
  }

  if ( proc && delayed )
    proc->occur();
}

/**
 * Poor man's targeting support. Acquire_target is triggered by various events (see retarget_event_e) in the core.
 * Context contains the triggering entity (if relevant). Figures out a target out of all non-sleeping targets.
 * Skip "invulnerable" ones for now, anything else is fair game.
 */
void player_t::acquire_target( retarget_source event, player_t* context )
{
  // TODO: This skips certain very custom targets (such as Soul Effigy), is it a problem (since those
  // usually are handled in action target cache regeneration)?
  if ( sim->debug )
  {
    sim->out_debug.printf( "%s retargeting event=%s context=%s current_target=%s", name(),
        util::retarget_event_string( event ),
        context ? context->name() : "NONE", target ? target->name() : "NONE" );
  }

  player_t* candidate_target = nullptr;
  player_t* first_invuln_target = nullptr;

  // TODO: Fancier system
  for ( auto enemy : sim->target_non_sleeping_list )
  {
    if ( enemy->debuffs.invulnerable != nullptr && enemy->debuffs.invulnerable->check() )
    {
      if ( first_invuln_target == nullptr )
      {
        first_invuln_target = enemy;
      }
      continue;
    }

    candidate_target = enemy;
    break;
  }

  // Invulnerable targets are currently not in the target_non_sleeping_list, so fall back to
  // checking if the first target has the invulnerability buff up, and use that as the fallback
  auto first_target = sim->target_list.data().front();
  if ( !first_invuln_target && first_target->debuffs.invulnerable->check() )
  {
    first_invuln_target = first_target;
  }

  // Only perform target acquisition if the actor's current target would change (to the candidate
  // target).
  if ( candidate_target && candidate_target != target )
  {
    if ( sim->debug )
    {
      sim->out_debug.printf( "%s acquiring (new) target, current=%s candidate=%s", name(),
                             target ? target->name() : "NONE", candidate_target ? candidate_target->name() : "NONE" );
    }

    target = candidate_target;
    range::for_each( action_list, [event, context, candidate_target]( action_t* action ) {
      action->acquire_target( event, context, candidate_target );
    } );

    trigger_ready();
  }
  // If we really cannot find any sensible target, fall back to the first invulnerable target
  else if ( ! candidate_target && first_invuln_target && first_invuln_target != target )
  {
    if ( sim->debug )
    {
      sim->out_debug.printf( "%s acquiring (new) target, current=%s candidate=%s [invulnerable fallback]",
          name(), target ? target->name() : "NONE",
          first_invuln_target ? first_invuln_target->name() : "NONE" );
    }

    target = first_invuln_target;
    range::for_each( action_list, [event, context, first_invuln_target]( action_t* action ) {
      action->acquire_target( event, context, first_invuln_target );
    } );

    trigger_ready();
  }

  if ( candidate_target || first_invuln_target )
  {
    // Finally, re-acquire targeting for all dynamic targeting actions. This needs to be done
    // separately, as their targeting is not strictly bound to player_t::target (i.e., "the players
    // target")
    range::for_each( dynamic_target_action_list, [event, context, candidate_target, first_invuln_target]( action_t* action ) {
      action->acquire_target( event, context, candidate_target ? candidate_target : first_invuln_target );
    } );
  }
}

/**
 * A method to "activate" an actor in the simulator. Single actor batch mode activates one primary actor at a time,
 * while normal simulation mode activates all actors at the beginning of the sim.
 *
 * NOTE: Currently, the only thing that occurs during activation of an actor is the registering of various state
 * change callbacks (via the action_t::activate method) to the global actor lists. Actor pets are also activated by
 * default.
 */
void player_t::activate()
{
  // Activate all actions of the actor
  range::for_each( action_list, []( action_t* a ) { a->activate(); } );

  // .. and activate all actor pets
  range::for_each( pet_list, []( player_t* p ) { p->activate(); } );

  // .. aaand activate any special effect with an activation callback
  range::for_each( special_effects, []( special_effect_t* e ) {
    if ( e->activation_cb )
    {
      e->activation_cb();
    }
  } );
}

void player_t::deactivate()
{
  // Record total number of iterations ran for this actor. Relevant in target_error cases for data
  // analysis at the end of simulation
  collected_data.total_iterations = nth_iteration();
}

void player_t::register_combat_begin( buff_t* b )
{
  combat_begin_functions.emplace_back([ b ]( player_t* ) { b -> trigger(); } );
}

void player_t::register_precombat_begin( buff_t* b )
{
  precombat_begin_functions.emplace_back( [ b ]( player_t* ) { b->trigger(); } );
}

void player_t::register_combat_begin( action_t* a )
{
  combat_begin_functions.emplace_back([ a ]( player_t* ) { a -> execute(); } );
}

void player_t::register_combat_begin( const combat_begin_fn_t& fn )
{
  combat_begin_functions.push_back( fn );
}

void player_t::register_precombat_begin( const combat_begin_fn_t& fn )
{
  precombat_begin_functions.push_back( fn );
}

void player_t::register_combat_begin( double amount, resource_e resource, gain_t* g )
{
  combat_begin_functions.emplace_back([ amount, resource, g ]( player_t* p ) {
    p -> resource_gain( resource, amount, g );
  });
}

void player_t::register_on_demise_callback( player_t* source, std::function<void( player_t* )> fn )
{
  callbacks_on_demise.emplace_back( source, std::move( fn ) );
}

void player_t::register_on_arise_callback( player_t* source, std::function<void( void )> fn )
{
  callbacks_on_arise.emplace_back( source, std::move( fn ) );
}

void player_t::register_on_kill_callback( std::function<void( player_t* )> fn )
{
  callbacks_on_kill.emplace_back( std::move( fn ) );
}

void player_t::register_on_combat_state_callback( std::function<void( player_t*, bool )> fn )
{
  callbacks_on_combat_state.emplace_back( std::move( fn ) );
}

void player_t::register_movement_callback( std::function<void( bool )> fn )
{
  callbacks_on_movement.emplace_back( std::move( fn ) );
}

void player_t::register_init_finished_callback( std::function<void( player_t* )> fn )
{
  callbacks_on_init_finished.emplace_back( std::move( fn ) );
}

void player_t::register_creature_type_buff( buff_t* buff, const spell_data_t* s_data )
{
  if ( !s_data->ok() )
    s_data = &buff->data();

  if ( !s_data->ok() )
    return;

  auto effect = spell_data_t::find_spelleffect( *s_data, E_APPLY_AURA, A_MOD_DAMAGE_DONE_VERSUS );
  if ( !effect.ok() )
    return;

  std::vector<std::string> _strs;
  auto _mask = effect.misc_value1();

  for ( auto i = 1; _mask; _mask >>= 1, i++ )
    if ( _mask & 1 )
      _strs.emplace_back( util::race_type_string( static_cast<race_e>( i ) ) );

  assert( _strs.size() );

  sim->print_debug( "{} {} granting {}% increased damage {}against creature type: {}", *this, *s_data,
                    effect.base_value(), buff ? "with buff '" + std::string( buff->name() ) + "' " : "",
                    fmt::join( _strs, ", " ) );

  buffs.creature_type_buffs.emplace_back( buff, effect.misc_value1(), effect.percent() );
}

void player_t::register_timed_buff_triggers( buff_t* buff, const std::vector<timespan_t>& times, timespan_t duration )
{
  if ( !buff || times.empty() )
    return;

  register_combat_begin( [ buff, &times, duration ]( player_t* p ) {
    for ( auto t : times )
      make_event( *p->sim, t, [ buff, duration ] { buff->trigger( duration ); } );
  } );
}

spawner::base_actor_spawner_t* player_t::find_spawner( util::string_view id ) const
{
  auto it = range::find_if( spawners, [ id ]( spawner::base_actor_spawner_t* o ) {
    return util::str_compare_ci( id, o -> name() );
  } );

  if ( it != spawners.end() )
  {
    return *it;
  }

  return nullptr;
}

int player_t::nth_iteration() const
{
  return creation_iteration == -1
          ? sim -> current_iteration
          : sim -> current_iteration - creation_iteration;
}

bool player_t::is_my_pet(const player_t* t) const
{
  return t->is_pet() && t->cast_pet()->owner == this;
}

bool player_t::is_active() const
{
  if ( sim->single_actor_batch )
  {
    if ( is_enemy() || is_pet() )
    {
      return !is_sleeping();
    }
    else
    {
      return sim->player_no_pet_list[ sim->current_index ] == this;
    }
  }
  else
  {
    return !is_sleeping();
  }
}

/**
 * Perform dynamic resource regeneration
 *
 * The forced parameter indicates whether the resource regen would
 * also occur in game at the same time.
 */
void player_t::do_dynamic_regen( bool forced )
{
  if (sim->current_time() == last_regen)
    return;

  regen(sim->current_time() - last_regen);
  last_regen = sim->current_time();

  if (dynamic_regen_pets)
  {
    for (auto& elem : active_pets)
    {
      if (elem->resource_regeneration == regen_type::DYNAMIC)
        elem->do_dynamic_regen( forced );
    }
  }
}

double player_t::get_position_distance(double m, double v) const
{
  double delta_x = this->x_position - m;
  double delta_y = this->y_position - v;
  double sqrtnum = delta_x * delta_x + delta_y * delta_y;
  return util::approx_sqrt(sqrtnum);
}

double player_t::mastery_coefficient() const
{
  return _mastery->mastery_value();
}

double player_t::get_player_distance( const player_t& t ) const
{
  if ( sim->distance_targeting_enabled )
    return get_position_distance( t.x_position, t.y_position );
  else
    return current.distance;
}

double player_t::get_ground_aoe_distance( const action_state_t& a ) const
{
  return get_position_distance( a.original_x, a.original_y );
}

void player_t::init_distance_targeting()
{
  if (default_x_position == std::numeric_limits<decltype(default_x_position)>::lowest())
  {
    default_x_position = -1 * base.distance;
  }
  if (default_y_position == std::numeric_limits<decltype(default_y_position)>::lowest())
  {
    default_y_position = 0;
  }
}

void sc_format_to( const player_t& player, fmt::format_context::iterator out )
{
  fmt::format_to( out, "{} '{}'", player.is_enemy() ? "Enemy" : "Player", player.name() );
}

bool player_t::is_ptr() const
{
  return maybe_ptr( dbc->ptr );
}

/* Passive spells DBC parsing

player_t::parse_passive_effects( const spell_data_t* ) is the main entry point. Only spells with the `SX_PASSIVE` flag
will be parsed, unless `true` is passed as an optional second argument.

Since modifications are directly made onto the DBC (or pre-registered) it's not necessary to wait until object
construction to parse, but it is recommended you wait until various named class module spell_t pointer structs are
populated by the end of `init_spells()`.

player_t::get_passive_value( const spell_data_t&, field )
player_t::get_passive_value( const spelleffect_data_t&, field )
player_t::get_passive_value( const spellpower_data_t&, field )
These are used to get the final modified value from the modified DBC for the stat specified. Stat strings can be found
in `field_type_map` in player.cpp. A 3-value array will be returned, representing `{ original, flat add, pct mult }`.
Variables of type `parsed_value_t<T>` can directly be assigned this array.

player_t::get_passive_player_value( base value, field[, misc type = 0]) will return player stat values. If no
modifications exist, base value will be returns. Otherwise the modified value will be returned. Some player stat
modifying effects have an associate misc type (such as resources) which can be passed as an optional argument.

player_t::parse_all_class_passives() will automatically parse all class/spec auras, including additional ones added
beyond the first. The table of auras can be found in `_class_passives` in `sc_const_data.cpp`.
player_t::parse_all_passive_talents() will automatically parse all talents active for the current player, including
those from the trait hash, manual talent strings, and enable_all_talents. player_t::parse_all_passive_sets() will
automatically parse all tier set bonuses for the current expansion. It is recommended you call these three functions for
both convenience and to ensure that no errant effects are missed.

player_t::deregister_passive_spell( const spell_data_t* ) will retroactively remove any existing parsing of the spell
and prevent all future parsing of the spell.

player_t::deregister_passive_effect( const spelleffect_data_t& ) will retroactively remove any existing parsing of the
effect and prevent all future parsing of the effect.

player_t::register_passive_effect_mask( const spell_data_t*, effect_mask_t ) will allow you to filter out which effects
to be parsed. It uses the same `effect_mask_t` syntax used in `parse_effects()`. This will retroactively adjust any
existing parsing of the spell. If the spell has not been parsed yet, `parse_passive_effects()` will still need to be
called.
```
// skip effect#1 and effect#5 of the spec spell
register_passive_effect_mask( spec_spell, effect_mask_t( true ).disable( 1, 5 ) )
```

player_t::register_passive_affect_list( const spell_data_t*, affect_list_t ) will allow you to modify which spells are
affected by the parsed spell. It uses the same `affect_list_t` syntax used in `parse_effects()`. This will retroactively
adjust any existing parsing of the spell. If the spell has not been parsed yet, `parse_passive_effects()` will still
need to be called.
```
// also apply family flag 2 to effect#1 of the spec spell
register_passive_affect_list( spec_spell, affect_list_t( 1 ).add_family( 2 ) )
```

player_t::register_passive_spell_override( const spell_data_t&, value, field )
player_t::register_passive_power_override( const spellpower_data_t& value[, field = "cost" ] )
player_t::register_passive_effect_override( const spelleffect_data_t&, value[, field = "base_value"] )
These provide a method within the scope of `player_t` that you can use to directly override the values. Unlike the
hotfix system, this can be called as a normal `player_t` method allowing you to use any conditional flows as needed. As
this directly manipulates the DBC without any processing, it should be called before any other parse methods are used.

*/
namespace
{
static constexpr std::pair<int, std::string_view> field_type_map[] = {
  { P_GENERIC,                                "direct_damage"                    },  // 0
  { P_DURATION,                               "duration"                         },  // 1
  { P_RANGE,                                  "max_range"                        },  // 5
  { P_RADIUS,                                 "max_radius"                       },  // 6
  { P_CRIT,                                   "crit"                             },  // 7
  { P_CAST_TIME,                              "cast_time"                        },  // 10
  { P_COOLDOWN,                               "cooldown"                         },  // 11
  { P_RESOURCE_COST_1,                        "cost"                             },  // 14
  { P_CRIT_BONUS,                             "crit_bonus"                       },  // 15
  { P_CHAIN_TARGETS,                          "chain_target"                     },  // 17
  { P_PROC_CHANCE,                            "proc_chance"                      },  // 18
  { P_TICK_TIME,                              "period"                           },  // 19
  { P_CHAIN_MULTIPLIER,                       "chain_multiplier"                 },  // 20
  { P_GCD,                                    "gcd"                              },  // 21
  { P_TICK_DAMAGE,                            "periodic_damage"                  },  // 22
  { A_MOD_STAT,                               "attribute_value"                  },  // 29
  { P_DOSES,                                  "proc_charges"                     },  // 31
  { A_MOD_INCREASE_SPEED,                     "move_speed_modifier_-_exclusive"  },  // 31
  { A_MOD_INCREASE_RESOURCE,                  "resource_max"                     },  // 35
  { P_MAX_STACKS,                             "max_stack"                        },  // 37
  { P_PROC_COOLDOWN,                          "internal_cooldown"                },  // 38
  { P_MAX_TARGETS,                            "max_targets"                      },  // 40
  { A_MOD_PARRY_PERCENT,                      "parry"                            },  // 47
  { A_MOD_DODGE_PERCENT,                      "dodge"                            },  // 49
  { A_MOD_CRITICAL_HEALING_AMOUNT,            "crit_heal_multiplier"             },  // 50
  { A_MOD_BLOCK_PERCENT,                      "block"                            },  // 51
  { A_MOD_SPELL_CRIT_CHANCE,                  "spell_crit"                       },  // 57
  { A_MOD_DAMAGE_PERCENT_DONE,                "damage_multiplier"                },  // 79
  { A_MOD_PERCENT_STAT,                       "base_attribute_multiplier"        },  // 80
  { A_MOD_RESISTANCE_PCT,                     "armor_multiplier"                 },  // 101
  { A_MOD_POWER_REGEN_PERCENT,                "resource_regen"                   },  // 110
  { A_MOD_HEALING_RECEIVED_PCT,               "healing_received_multiplier"      },  // 118
  { A_INCREASE_RESOURCE_PCT,                  "resource_multiplier"              },  // 119
  { A_MOD_SPEED_ALWAYS,                       "move_speed_modifier_-_stacking"   },  // 129
  { A_INCREASE_RESOURCE_PCT,                  "resource_multiplier"              },  // 132
  { A_MOD_HEALING_DONE_PERCENT,               "healing_multiplier"               },  // 136
  { A_MOD_TOTAL_STAT_PERCENTAGE,              "attribute_multiplier"             },  // 137
  { -(int)A_MOD_TOTAL_STAT_PERCENTAGE,        "armor_type_multiplier"            },  // -137
  { A_MOD_BASE_RESISTANCE_PCT,                "base_armor_multiplier"            },  // 142
  { A_MOD_CRIT_DAMAGE_MULTIPLIER,             "crit_damage_multiplier"           },  // 163
  { A_MOD_ATTACK_POWER_PCT,                   "attack_power_multiplier",         },  // 166
  { A_MOD_RECHARGE_TIME_PCT_CATEGORY_MASK,    "charge_cooldown"                  },  // 173
  { A_MOD_MAX_MANA_PCT,                       "resource_multiplier"              },  // 178
  { A_MOD_ATTACKER_MELEE_CRIT_CHANCE,         "crit_avoidance"                   },  // 187
  { A_HASTE_ALL,                              "all_haste"                        },  // 193
  { A_MOD_RECHARGE_TIME_CATEGORY_MASK,        "charge_cooldown"                  },  // 205
  { A_MODIFY_SCHOOL,                          "school"                           },  // 220
  { A_MOD_EXPERTISE,                          "expertise"                        },  // 240
  { A_MOD_BLOCK_PCT,                          "block_value"                      },  // 272
  { A_MOD_MECHANIC_DAMAGE_DONE_PERCENT,       "mechanic_damage_done"             },  // 276
  { A_MOD_TARGET_ARMOR_PCT,                   "armor_penetration"                },  // 280
  { A_MOD_ALL_CRIT_CHANCE,                    "all_crit"                         },  // 290
  { A_MOD_MASTERY_PCT,                        "mastery"                          },  // 318
  { A_MOD_MELEE_AUTO_ATTACK_SPEED,            "attack_speed"                     },  // 319
  { A_APPLY_HASTED_GCD_LABEL,                 "hasted_gcd"                       },  // 320
  { A_MODIFY_CATEGORY_COOLDOWN,               "category_cooldown"                },  // 341
  { A_MOD_RANGED_AND_MELEE_AUTO_ATTACK_SPEED, "attack_speed_modifier"            },  // 342
  { A_MOD_AUTO_ATTACK_PCT,                    "auto_attack_multiplier"           },  // 344
  { A_OVERRIDE_SP_PER_AP,                     "spell_power_per_attack_power"     },  // 366
  { A_MOD_MANA_REGEN_PCT,                     "resource_regen"                   },  // 379
  { A_OVERRIDE_AP_PER_SP,                     "attack_power_per_spell_power"     },  // 404
  { A_MOD_RATING_MULTIPLIER,                  "rating_multiplier"                },  // 405
  { A_MOD_MAX_CHARGES,                        "charges"                          },  // 411
  { A_HASTED_COOLDOWN,                        "hasted_cooldown"                  },  // 416
  { A_HASTED_GCD,                             "hasted_gcd"                       },  // 417
  { A_MOD_MAX_RESOURCE,                       "resource_max"                     },  // 418
  { A_MOD_MAX_RESOURCE_PCT,                   "resource_multiplier"              },  // 419
  { A_MOD_ABSORB_DONE_PERCENT,                "absorb_multiplier"                },  // 421
  { A_MOD_ABSORB_RECEIVED_PERCENT,            "absorb_received_multiplier"       },  // 422
  { A_MOD_PET_DAMAGE_DONE,                    "pet_damage_multiplier"            },  // 429
  { A_MOD_LEECH_PERCENT,                      "leech"                            },  // 443
  { A_MOD_RECHARGE_TIME_CATEGORY,             "charge_cooldown"                  },  // 453
  { A_MOD_RECHARGE_TIME_PCT_CATEGORY,         "charge_cooldown"                  },  // 454
  { A_HASTED_CATEGORY,                        "hasted_cooldown"                  },  // 457
  { A_MOD_PARRY_FROM_CRIT_RATING,             "parry_from_crit_rating"           },  // 463
  { A_MOD_VERSATILITY_PCT,                    "versatility"                      },  // 471
  { A_MOD_AUTO_ATTACK_DAMAGE_PCT,             "auto_attack_multiplier"           },  // 530
  { A_MOD_GUARDIAN_DAMAGE_DONE,               "guardian_damage_multiplier"       },  // 531
};

std::string attr_formatter( int type )
{
  return util::attribute_type_string( static_cast<attribute_e>( type ) );
}

std::string rating_formatter( int type )
{
  return util::rating_type_string( static_cast<rating_e>( type ) );
}

std::string school_formatter( int type )
{
  return type == -1 ? "all" : util::school_type_string( static_cast<school_e>( type ) );
}

std::string resource_formatter( int type )
{
  return util::resource_type_string( static_cast<resource_e>( type ) );
}

std::string mechanic_formatter( int type )
{
  return std::string( spell_info::mechanic_str( as<unsigned>( type ) ) );
}

enum misc_expansion_e
{
  MISC_EXPANSION_NONE = -1,
  MISC_TYPE_RESOURCE,
  MISC_TYPE_MECHANIC,
  MISC_LIST_ATTR,
  MISC_BITMAP_ATTR,
  MISC_BITMAP_RATING,
  MISC_BITMAP_SCHOOL,
};

struct misc_expansion_t
{
  std::string_view field;
  misc_expansion_e type;
  std::function<std::string( int )> formatter;
};

static const std::array<misc_expansion_t, 11> misc_expansion_map = { {
  { "attribute_value",           MISC_LIST_ATTR,     &attr_formatter     },
  { "base_attribute_multiplier", MISC_LIST_ATTR,     &attr_formatter     },
  { "attribute_multiplier",      MISC_BITMAP_ATTR,   &attr_formatter     },
  { "armor_type_multiplier",     MISC_BITMAP_ATTR,   &attr_formatter     },
  { "rating_multiplier",         MISC_BITMAP_RATING, &rating_formatter   },
  { "crit_damage_multiplier",    MISC_BITMAP_SCHOOL, &school_formatter   },
  { "damage_multiplier",         MISC_BITMAP_SCHOOL, &school_formatter   },
  { "resource_max",              MISC_TYPE_RESOURCE, &resource_formatter },
  { "resource_multiplier",       MISC_TYPE_RESOURCE, &resource_formatter },
  { "resource_regen",            MISC_TYPE_RESOURCE, &resource_formatter },
  { "mechanic_damage_done",      MISC_TYPE_MECHANIC, &mechanic_formatter },
} };

std::string_view get_field_from_type( int type )
{
  for ( auto [ t, f ] : field_type_map )
    if ( t == type )
      return f;

  throw sc_initialization_error( fmt::format( "Invalid parse type '{}', field not found.", type ) );
  return {};
}

int get_type_from_field( std::string_view field )
{
  for ( auto [ t, f ] : field_type_map )
    if ( f == field )
      return t;

  throw sc_initialization_error( fmt::format( "Invalid parse field '{}', type not found.", field ) );
  return -1;
}
}

std::array<double, 3> player_t::get_passive_value( const spell_data_t& spell, std::string_view field, double mul ) const
{
  assert( !is_pet() || get_owner_or_self() != this );
  if ( is_pet() )
    return get_owner_or_self()->get_passive_value( spell, field );

  auto id = as<int>( spell.id() );
  auto field_type = get_type_from_field( field );

  auto it = range::find_if( passive_spell_modifiers_, [ id, field_type ]( const auto& mod ) {
    return mod.id == id && mod.field_id == field_type;
  } );
  if ( it == passive_spell_modifiers_.end() )
    return { spell.get_field( field ) * mul, 0.0, 1.0 };
  else
    return { it->orig * mul, it->flat * mul, it->pct };
}

std::array<double, 3> player_t::get_passive_value( const spellpower_data_t& power, std::string_view field ) const
{
  assert( !is_pet() || get_owner_or_self() != this );
  if ( is_pet() )
    return get_owner_or_self()->get_passive_value( power, field );

  auto id = as<int>( power.id() );
  auto field_type = get_type_from_field( field );

  auto it = range::find_if( passive_power_modifiers_, [ id, field_type ]( const auto& mod ) {
    return mod.id == id && mod.field_id == field_type;
  } );
  if ( it == passive_power_modifiers_.end() )
    return { power.get_field( field ) / power.cost_divisor( false ), 0.0, 1.0 };
  else
    return { it->orig, it->flat, it->pct };
}

std::array<double, 3> player_t::get_passive_value( const spelleffect_data_t& eff, std::string_view field ) const
{
  assert( !is_pet() || get_owner_or_self() != this );
  if ( is_pet() )
    return get_owner_or_self()->get_passive_value( eff, field );

  auto id = as<int>( eff.id() );
  auto field_type = get_type_from_field( field );

  auto it = range::find_if( passive_effect_modifiers_, [ id, field_type ]( const auto& mod ) {
    return mod.id == id && mod.field_id == field_type;
  } );
  if ( it == passive_effect_modifiers_.end() )
    return { eff.get_field( field ), 0.0, 1.0 };
  else
    return { it->orig, it->flat, it->pct };
}

double player_t::get_passive_player_value( double base_val, std::string_view field, int misc_type ) const
{
  assert( !is_pet() || get_owner_or_self() != this );
  if ( is_pet() )
    return get_owner_or_self()->get_passive_player_value( base_val, field, misc_type );

  auto field_type = get_type_from_field( field );

  auto it = range::find_if( passive_player_modifiers_, [ field_type, misc_type ]( const auto& mod ) {
    return mod.id == field_type && mod.field_id == misc_type;
  } );
  if ( it == passive_player_modifiers_.end() )
    return base_val;
  else
    return ( base_val + it->flat ) * it->pct;
}

std::vector<const spell_data_t*> player_t::spells_affected_by_passive( const spelleffect_data_t& eff, bool& prop ) const
{
  std::vector<const spell_data_t*> affected_spells;

  switch ( eff.subtype() )
  {
    case A_ADD_FLAT_MODIFIER:  // 107
    case A_ADD_PCT_MODIFIER:  // 108
      prop = true;
      SC_FALLTHROUGH;
    case A_MODIFY_SCHOOL:  // 220
    case A_HASTED_COOLDOWN:  // 416
    case A_HASTED_GCD:  // 417
      affected_spells = dbc->effect_affects_spells( eff.spell()->class_family(), &eff );
      break;
    case A_MOD_RECHARGE_TIME_PCT_CATEGORY_MASK:  // 173
    case A_MOD_RECHARGE_TIME_CATEGORY_MASK:  // 205
      if ( auto _mask = as<unsigned>( eff.misc_value1() ) )
      {
        for ( unsigned i = 1; _mask; _mask >>= 1, i++ )
        {
          if ( _mask & 1 )
          {
            auto span_ = dbc->spells_by_category_mask_bit( i );
            affected_spells.insert( affected_spells.end(), span_.begin(), span_.end() );
          }
        }
      }
      break;
    case A_ADD_PCT_LABEL_MODIFIER:  // 218
    case A_ADD_FLAT_LABEL_MODIFIER:  // 219
    case A_APPLY_HASTED_GCD_LABEL:  // 320
    {
      auto span_ = dbc->spells_by_label( eff.misc_value2() );
      affected_spells.assign( span_.begin(), span_.end() );
      prop = true;
      break;
    }
    case A_MODIFY_CATEGORY_COOLDOWN:  // 341
    case A_MOD_MAX_CHARGES:  // 411
    case A_MOD_RECHARGE_TIME_CATEGORY:  // 453
    case A_MOD_RECHARGE_TIME_PCT_CATEGORY:  // 454
    case A_HASTED_CATEGORY:  // 457
    {
      auto span_ = dbc->spells_by_category( eff.misc_value1() );
      affected_spells.assign( span_.begin(), span_.end() );
      break;
    }
    default:
      break;
  }

  for ( const auto& list : registered_affected_spell_list_ )
  {
    if ( list.first == eff.id() )
    {
      for ( auto spell_id : list.second )
      {
        auto it = range::find( affected_spells, as<unsigned>( abs( spell_id ) ), &spell_data_t::id );
        if ( spell_id > 0 && it == affected_spells.end() )
          affected_spells.push_back( dbc::find_spell( this, spell_id ) );
        else if ( spell_id < 0 && it != affected_spells.end() )
          affected_spells.erase( it );
      }

      break;
    }
  }

  return affected_spells;
}

std::pair<player_t::modified_value_t, const player_t::modified_value_t&> player_t::add_passive_effect_modifier(
  std::vector<player_t::modified_value_t>& modifiers, int id, int field_id, double orig_val, double flat_val,
  double pct_val )
{
  auto it = range::find_if( modifiers, [ id, field_id ]( const auto& mod ) {
    return mod.id == id && mod.field_id == field_id;
  } );
  if ( it == modifiers.end() )  // cache original value if new modification
  {
    modifiers.emplace_back( id, field_id, orig_val );
    it = std::prev( modifiers.end() );
  }

  auto prev = *it;  // make a copy

  it->flat += flat_val;
  it->pct *= 1.0 + pct_val;

  return { prev, *it };
}

bool player_t::register_passive_effect( const spelleffect_data_t& modifying_eff, bool remove )
{
  auto modifying_spell = modifying_eff.spell();
  auto sub_type = modifying_eff.subtype();
  auto success = false;
  auto property = false;

  // find all affected spells
  auto affected_spells = spells_affected_by_passive( modifying_eff, property );
  if ( affected_spells.empty() )
  {
    // check player affecting subtypes
    auto misc_type = modifying_eff.misc_value1();
    std::string id_field;
    double flat_val = 0.0;
    double pct_val = 0.0;  // initially set in percent value, then multiplied by 0.01 later

    switch ( sub_type )
    {
      // special handling
      case A_MOD_STAT:  // 29
        // parse scaling value if necessary
        flat_val = modifying_eff.average( this );
        break;
      case A_MOD_INCREASE_SPEED:  // 31
        id_field = "move_speed_modifier_-_exclusive";
        flat_val = modifying_eff.average( this ) * 0.01;
        break;
      case A_MOD_INCREASE_RESOURCE: // 35
      case A_MOD_MAX_RESOURCE:  // 418
        misc_type = util::power_type_to_resource( static_cast<power_e>( modifying_eff.misc_value1() ) );
        // resource divisor adjusted value
        flat_val = modifying_eff.average( this ) * modifying_eff.resource_multiplier();
        break;
      case A_MOD_RESISTANCE_PCT:  // 101
      case A_MOD_BASE_RESISTANCE_PCT:  // 142
        if ( ( misc_type & SCHOOL_MASK_PHYSICAL ) == 0 )  // only parse armor
          return false;
        pct_val = modifying_eff.average( this );
        break;
      case A_MOD_TOTAL_STAT_PERCENTAGE:  // 137
        if ( modifying_spell->equipped_class() == ITEM_CLASS_ARMOR &&
             modifying_spell->flags( SX_REQUIRES_EQUIPPED_ARMOR_TYPE ) )
        {
          auto armor_bit = 1U << static_cast<unsigned>( util::matching_armor_type( type ) );
          if ( ( modifying_spell->equipped_subclass_mask() & armor_bit ) == 0 )
            return false;

          id_field = "armor_type_multiplier";
        }

        misc_type = modifying_eff.misc_value2();  // Stat type is in misc_value2
        pct_val = modifying_eff.average( this );
        break;
      case A_MOD_MAX_MANA_PCT:  // 178
      case A_MOD_MANA_REGEN_PCT:  // 379
        misc_type = RESOURCE_MANA;  // hardcode to mana
        pct_val = modifying_eff.average( this );
        break;
      case A_MOD_TARGET_ARMOR_PCT:  // 280
      case A_MOD_RANGED_AND_MELEE_AUTO_ATTACK_SPEED:  // 342
        pct_val = -modifying_eff.average( this );  // reversed value
        break;

      // percent multipliers
      case A_MOD_POWER_REGEN_PERCENT:  // 110
      case A_INCREASE_RESOURCE_PCT:  // 132
      case A_MOD_MAX_RESOURCE_PCT:  // 419
        misc_type = util::power_type_to_resource( static_cast<power_e>( modifying_eff.misc_value1() ) );
        SC_FALLTHROUGH;
      case A_MOD_CRITICAL_HEALING_AMOUNT:  // 50
      case A_MOD_DAMAGE_PERCENT_DONE:  // 79
      case A_MOD_HEALING_RECEIVED_PCT:  // 118
      case A_MOD_HEALING_DONE_PERCENT:  // 136
      case A_MOD_CRIT_DAMAGE_MULTIPLIER:  // 163
      case A_MOD_ATTACK_POWER_PCT:  // 166
      case A_HASTE_ALL:  // 193
      case A_MOD_MECHANIC_DAMAGE_DONE_PERCENT:  // 276
      case A_MOD_MELEE_AUTO_ATTACK_SPEED:  // 319
      case A_MOD_AUTO_ATTACK_PCT:  // 344
      case A_MOD_RATING_MULTIPLIER:  // 405
      case A_MOD_ABSORB_DONE_PERCENT:  // 421
      case A_MOD_ABSORB_RECEIVED_PERCENT:  // 422
      case A_MOD_PET_DAMAGE_DONE:  // 429
      case A_MOD_AUTO_ATTACK_DAMAGE_PCT:  // 530
      case A_MOD_GUARDIAN_DAMAGE_DONE:  // 531
        pct_val = modifying_eff.average( this );
        break;

      // flat modifiers
      case A_MOD_PARRY_PERCENT:  // 47
      case A_MOD_DODGE_PERCENT:  // 49
      case A_MOD_BLOCK_PERCENT:  // 51
      case A_MOD_SPELL_CRIT_CHANCE:  // 57
      case A_MOD_SPEED_ALWAYS:  // 129
      case A_MOD_ATTACKER_MELEE_CRIT_CHANCE:  // 187
      case A_MOD_EXPERTISE:  // 240
      case A_MOD_BLOCK_PCT:  // 272
      case A_MOD_ALL_CRIT_CHANCE:  // 290
      case A_OVERRIDE_SP_PER_AP:  // 366
      case A_OVERRIDE_AP_PER_SP:  // 404
      case A_MOD_VERSATILITY_PCT:  // 417
      case A_MOD_LEECH_PERCENT:  // 443
      case A_MOD_PARRY_FROM_CRIT_RATING:  // 463
        flat_val = modifying_eff.average( this ) * 0.01;
        break;
      case A_MOD_MASTERY_PCT:  // 318
        flat_val = modifying_eff.average( this );
        break;

      case A_MOD_PERCENT_STAT:  // 80
        pct_val = modifying_eff.average( this );
        sim->error( SEVERE,
                    "{}(id={}) effect #:{} is utilizing aura subtype 80, rather than 137. This is a bug, as it only "
                    "modifies base attributes.",
                    modifying_spell->name_cstr(), modifying_spell->id(), modifying_eff.index() + 1 );
        break;

      default:
        return false;
    }

    if ( !flat_val && !pct_val )
      return false;

    pct_val *= 0.01;  // convert from percent value to decimal

    if ( id_field.empty() )
      id_field = get_field_from_type( sub_type );

    assert( !id_field.empty() && "subtype not found in field_type_map!" );

    if ( remove )
    {
      flat_val = -flat_val;
      pct_val = 1.0 / ( 1.0 + pct_val ) - 1.0;
    }

    auto do_debug = [ & ]( std::string type_str, const auto& prev, const auto& now ) {
      if ( !sim->debug )
        return;

      std::string field_str = type_str.empty() ? id_field : fmt::format( "{}_{}", type_str, id_field );
      std::string _tmp_full_message_tmp_ = fmt::format(
        "{} eff#{} {} {} {} by {:.7g}{} (orig={:.7g} prev={:.7g}[{:.7g}/{:.7g}%] now={:.7g}[{:.7g}/{:.7g}%])",
        *modifying_spell, modifying_eff.index() + 1, remove ? "reverting" : "modifying", *this, field_str,
        flat_val ? flat_val : pct_val * 100, flat_val ? "" : "%", now.orig, prev.value(), prev.flat, prev.pct * 100,
        now.value(), now.flat, now.pct * 100 );
      sim->print_debug( "{}", _tmp_full_message_tmp_ );
      registered_passive_debug_printout.push_back( _tmp_full_message_tmp_ );
    };

    auto add_reporting = [ & ]( int type ) {
      if ( sim->parent || sim->profileset_enabled || sim->report_details == 0 || sim->html_file_str.empty() )
        return;

      if ( remove )
        range::erase_remove( reporting_parse_player[ id_field ][ type ], &modifying_eff );
      else
        reporting_parse_player[ id_field ][ type ].push_back( &modifying_eff );
    };

    auto id_type = get_type_from_field( id_field );

    // check for misc_value expansion
    auto m_it = range::find( misc_expansion_map, id_field, &misc_expansion_t::field );
    if ( m_it == misc_expansion_map.end() )
    {
      // special handling for A_MOD_INCREASE_SPEED (non_stacking_movement_modifier)
      if ( sub_type == A_MOD_INCREASE_SPEED )
      {
        auto _it = range::find_if( passive_player_modifiers_, []( const auto& mod ) {
          return mod.id == A_MOD_INCREASE_SPEED;
        } );
        if ( _it == passive_player_modifiers_.end() )
        {
          passive_player_modifiers_.emplace_back( A_MOD_INCREASE_SPEED, 0, 0 );
          _it = std::prev( passive_player_modifiers_.end() );
        }

        auto prev = *_it;  // make a copy

        if ( _it->flat < flat_val )
          _it->flat = flat_val;
        else
          flat_val = 0.0;

        do_debug( "", prev, *_it );
        add_reporting( 0 );

        return true;
      }

      // no expansion needed, default handling
      auto [ prev, now ] = add_passive_effect_modifier( passive_player_modifiers_, id_type, 0, 0, flat_val, pct_val );

      do_debug( "", prev, now );
      add_reporting( 0 );

      return true;
    }

    switch ( m_it->type )
    {
      case MISC_LIST_ATTR:
      {
        std::vector<attribute_e> attr_list;

        if ( misc_type == -2 )
          attr_list = { ATTR_STRENGTH, ATTR_AGILITY, ATTR_INTELLECT };
        else if ( misc_type == -1 )
          attr_list = { ATTR_STRENGTH, ATTR_AGILITY, ATTR_STAMINA, ATTR_INTELLECT, ATTR_SPIRIT };
        else
          attr_list.push_back( static_cast<attribute_e>( misc_type + 1 ) );

        for ( auto attr : attr_list )
        {
          auto attr_int = static_cast<int>( attr );
          auto [ prev, now ] =
            add_passive_effect_modifier( passive_player_modifiers_, id_type, attr_int, 0, flat_val, pct_val );

          do_debug( m_it->formatter( attr_int ), prev, now );
          add_reporting( attr_int );
        }

        return true;
      }
      case MISC_BITMAP_ATTR:
      {
        for ( auto attr : { ATTR_STRENGTH, ATTR_AGILITY, ATTR_STAMINA, ATTR_INTELLECT, ATTR_SPIRIT } )
        {
          if ( misc_type & ( 1 << ( attr - 1 ) ) )
          {
            auto attr_int = static_cast<int>( attr );
            auto [ prev, now ] =
              add_passive_effect_modifier( passive_player_modifiers_, id_type, attr_int, 0, flat_val, pct_val );

            do_debug( m_it->formatter( attr_int ), prev, now );
            add_reporting( attr_int );
          }
        }

        return true;
      }
      case MISC_BITMAP_RATING:
      {
        for ( auto rating = static_cast<rating_e>( 0 ); rating < RATING_MAX; ++rating )
        {
          if ( misc_type & util::rating_to_rating_mod( rating ) )
          {
            auto rating_int = static_cast<int>( rating );
            auto [ prev, now ] =
              add_passive_effect_modifier( passive_player_modifiers_, id_type, rating_int, 0, flat_val, pct_val );

            do_debug( m_it->formatter( rating_int ), prev, now );
            add_reporting( rating_int );
          }
        }

        return true;
      }
      case MISC_BITMAP_SCHOOL:
      {
        if ( ( misc_type & 0x7F ) == 0x7F )  // special handling for all schools
        {
          auto [ prev, now ] =
            add_passive_effect_modifier( passive_player_modifiers_, id_type, -1, 0, flat_val, pct_val );

          do_debug( "all", prev, now );
          add_reporting( -1 );

          return true;
        }

        for ( auto school = SCHOOL_NONE; school < SCHOOL_MAX_PRIMARY; ++school )
        {
          if ( misc_type & dbc::get_school_mask( school ) )
          {
            auto school_int = static_cast<int>( school );
            auto [ prev, now ] =
              add_passive_effect_modifier( passive_player_modifiers_, id_type, school_int, 0, flat_val, pct_val );

            do_debug( m_it->formatter( school_int ), prev, now );
            add_reporting( school_int );
          }
        }

        return true;
      }
      case MISC_TYPE_RESOURCE:
      case MISC_TYPE_MECHANIC:
      {
        auto [ prev, now ] =
          add_passive_effect_modifier( passive_player_modifiers_, id_type, misc_type, 0, flat_val, pct_val );

        do_debug( m_it->formatter( misc_type ), prev, now );
        add_reporting( misc_type );

        return true;
      }
      default:
        assert( false && "Invalid misc_exanpsion_map entry" );
        return false;
    }
  }

  for ( auto spell_ : affected_spells )
  {
    // grab the override/hotfix variant
    auto spell = dbc::find_spell( this, spell_ );

    std::string field;
    std::string field2;
    std::string eff_field;
    std::string eff_field2;
    std::string pow_field;
    int field_type = -1;
    int field_type2 = -1;
    int eff_idx = 0;
    unsigned pow_idx_bit = 0U;
    double flat_val = 0.0;
    double pct_val = 0.0;    // initially set in percent value, then multiplied by 0.01 later
    bool is_dbc = true;      // modifies the dbc
    bool is_damage = false;  // only modifies E_SCHOOL_DAMAGE
    bool allow_zero = true;  // modify even if base dbc value is 0

    switch ( sub_type )
    {
      case A_ADD_FLAT_MODIFIER:  // 107
      case A_ADD_FLAT_LABEL_MODIFIER:  // 219
        flat_val = modifying_eff.average( this );
        break;
      case A_ADD_PCT_MODIFIER:  // 108
      case A_ADD_PCT_LABEL_MODIFIER:  // 218
        pct_val = modifying_eff.average( this );
        break;
      case A_MODIFY_SCHOOL:  // 220
        field = get_field_from_type( sub_type );
        flat_val = modifying_eff.misc_value1();
        break;
      case A_APPLY_HASTED_GCD_LABEL:  // 320
      case A_HASTED_COOLDOWN:  // 416
      case A_HASTED_GCD:  // 417
      case A_HASTED_CATEGORY:  // 457
        is_dbc = false;
        flat_val = 1.0;
        field = get_field_from_type( sub_type );
        break;
      case A_MODIFY_CATEGORY_COOLDOWN:  // 341
        field = "category_cooldown";
        flat_val = modifying_eff.average( this );
        // if a spell has category_cooldown but no cooldown, category_cooldown value will be used for cooldown field.
        // if category_cooldown == cooldown assume this happened and modify both.
        if ( spell->get_field( "category_cooldown" ) == spell->get_field( "cooldown" ) )
        {
          field2 = "cooldown";
          field_type2 = P_COOLDOWN;
        }
        break;
      case A_MOD_RECHARGE_TIME_CATEGORY_MASK:  // 205
      case A_MOD_MAX_CHARGES:  // 411
      case A_MOD_RECHARGE_TIME_CATEGORY:  // 453
        flat_val = modifying_eff.average( this );
        field = get_field_from_type( sub_type );
        break;
      case A_MOD_RECHARGE_TIME_PCT_CATEGORY_MASK:  // 173
      case A_MOD_RECHARGE_TIME_PCT_CATEGORY:  // 454
        pct_val = modifying_eff.average( this );
        field = get_field_from_type( sub_type );
        break;
      default:
        continue;
    }

    // filter out zero value
    if ( !flat_val && !pct_val )
      continue;

    pct_val *= 0.01;  // convert from percent value to decimal

    if ( !field.empty() && !property )
    {
      field_type = get_type_from_field( field );
    }
    else if ( property )
    {
      field_type = modifying_eff.property_type();

      switch ( field_type )
      {
        // effect modifier
        case P_EFFECT_1: eff_idx =  1; break;
        case P_EFFECT_2: eff_idx =  2; break;
        case P_EFFECT_3: eff_idx =  3; break;
        case P_EFFECT_4: eff_idx =  4; break;
        case P_EFFECT_5: eff_idx =  5; break;
        case P_EFFECTS:  eff_idx = -1; break;
        // spell_data_t modifiers
        case P_DURATION:  // 1
          if ( spell->_duration == -1 )
            continue;
          field = "duration";
          break;
        case P_STACK:  // 4
          field = "proc_charges";
          field_type = P_DOSES;
          field2 = "max_stack";
          field_type2 = P_MAX_STACKS;
          break;
        case P_COOLDOWN:  // 11
          if ( spell->_cooldown == 0 && flat_val < 0 )
            continue;
          field = "cooldown";
          break;
        case P_PROC_CHANCE:  // 18
          if ( spell->_proc_chance == 101 )
            continue;
          allow_zero = false;
          SC_FALLTHROUGH;
        case P_RANGE:  // 5
        case P_CAST_TIME:  // 10
        case P_GCD:  // 21
        case P_DOSES:  // 31
        case P_MAX_STACKS:  // 37
        case P_PROC_COOLDOWN:  // 38
        case P_MAX_TARGETS:  // 40
          field = get_field_from_type( field_type );
          break;
        // spelleffect_data_t modifiers
        case P_CHAIN_TARGETS:  // 17
        case P_CHAIN_MULTIPLIER:  // 20
          is_damage = true;
          eff_field = get_field_from_type( field_type );
          break;
        case P_RADIUS:  // 6
        case P_TICK_TIME:  // 19
          allow_zero = false;
          eff_field = get_field_from_type( field_type );
          break;
        case P_COEFFICIENT:  // 24
          eff_field = "sp_coefficient";
          eff_field2 = "ap_coefficient";
          allow_zero = false;
          break;
        // spellpower_data_t modifiers
        case P_RESOURCE_COST_1:  // 14
          pow_idx_bit = 1U << 0;
          pow_field = "cost";
          break;
        case P_RESOURCE_COST_2:  // 34
          pow_idx_bit = 1U << 1;
          pow_field = "cost";
          break;
        case P_RESOURCE_COST_3:  // 39
          pow_idx_bit = 1U << 2;
          pow_field = "cost";
          break;
        // action_t modifiers, these don't modify spell data
        case P_CRIT:  // 7
        case P_CRIT_BONUS:  // 15
          flat_val *= 0.01;
          SC_FALLTHROUGH;
        case P_GENERIC:  // 0
        case P_TICK_DAMAGE:  // 22
          is_dbc = false;
          field = get_field_from_type( field_type );
          break;
        default:
          continue;
      }
    }

    if ( remove )
    {
      flat_val = -flat_val;
      pct_val = 1.0 / ( 1.0 + pct_val ) - 1.0;
    }

    auto do_debug = [ & ]( std::string msg ) {
      if ( !sim->debug )
        return;

      std::string _tmp_full_message_tmp_ =
        fmt::format( "{} eff#{} {} {} {}", *modifying_spell, modifying_eff.index() + 1,
                     remove ? "reverting" : "modifying", *spell, msg );
      sim->print_debug( "{}", _tmp_full_message_tmp_ );
      registered_passive_debug_printout.push_back( _tmp_full_message_tmp_ );
    };

    auto add_reporting = [ & ]( std::string field ) {
      if ( sim->parent || sim->profileset_enabled || sim->report_details == 0 || sim->html_file_str.empty() )
        return;

      if ( remove )
        range::erase_remove( reporting_parse_action[ spell->id() ][ field ], &modifying_eff );
      else
        reporting_parse_action[ spell->id() ][ field ].push_back( &modifying_eff );
    };

    if ( !field.empty() )  // modify spell_data_t
    {
      auto id = as<int>( spell->id() );
      double now_val;

      // special cases
      if ( field == "school" || field == "hasted_gcd" || field == "hasted_cooldown" )
      {
        double prev_val;
        auto it = range::find_if( passive_spell_modifiers_, [ id, field_type ]( const auto& mod ) {
          return mod.id == id && mod.field_id == field_type;
        } );

        if ( remove )
        {
          assert( it != passive_spell_modifiers_.end() );
          prev_val = it->flat;
          it->flat = it->orig;
          now_val = it->orig;
        }
        else if ( it == passive_spell_modifiers_.end() )
        {
          prev_val = is_dbc ? spell->get_field( field ) : 0.0;
          now_val = flat_val;
          passive_spell_modifiers_.emplace_back( id, field_type, prev_val, now_val, 1.0 );
        }
        else
        {
          prev_val = it->flat;
          now_val = flat_val;
          it->flat = now_val;
        }

        do_debug( fmt::format( "{} (prev={} now={})", field,
          sub_type == A_MODIFY_SCHOOL ? util::school_type_string( dbc::get_school_type( as<uint32_t>( prev_val ) ) )
                                      : util::to_string( prev_val ),
          sub_type == A_MODIFY_SCHOOL ? util::school_type_string( dbc::get_school_type( as<uint32_t>( now_val ) ) )
                                      : util::to_string( now_val ) ) );

        add_reporting( field );

        if ( is_dbc )
          dbc_override_->register_spell( *dbc, id, field, now_val );
      }
      else
      {
        auto data_val = is_dbc ? spell->get_field( field ) : 0.0;
        if ( data_val == 0 && !allow_zero )
          continue;

        auto [ prev, now ] =
          add_passive_effect_modifier( passive_spell_modifiers_, id, field_type, data_val, flat_val, pct_val );

        now_val = now.value();

        do_debug( fmt::format( "{} by {:.7g}{} (orig={:.7g} prev={:.7g}[{:.7g}/{:.7g}%] now={:.7g}[{:.7g}/{:.7g}%])",
                               field, flat_val ? flat_val : pct_val * 100, flat_val ? "" : "%", now.orig, prev.value(),
                               prev.flat, prev.pct * 100, now_val, now.flat, now.pct * 100 ) );

        add_reporting( field );

        if ( is_dbc )
          dbc_override_->register_spell( *dbc, id, field, now_val );

        if ( !field2.empty() )
        {
          auto data_val2 = spell->get_field( field2 );

          auto [ prev2, now2 ] =
            add_passive_effect_modifier( passive_spell_modifiers_, id, field_type2, data_val2, flat_val, pct_val );

          auto now_val2 = now2.value();

          do_debug( fmt::format( "{} by {:.7g}{} (orig={:.7g} prev={:.7g}[{:.7g}/{:.7g}%] now={:.7g}[{:.7g}/{:.7g}%])",
                                 field2, flat_val ? flat_val : pct_val * 100, flat_val ? "" : "%", now2.orig,
                                 prev2.value(), prev2.flat, prev2.pct * 100, now_val2, now2.flat, now2.pct * 100 ) );

          add_reporting( field );

          if ( is_dbc )
            dbc_override_->register_spell( *dbc, id, field2, now_val2 );
        }
      }

      success = true;
    }
    // TODO: implement for _pct_cost
    else if ( !pow_field.empty() )  // modify spellpower_data_t
    {
      // populate selected power(s)
      std::vector<const spellpower_data_t*> pow_list;
      for ( size_t i = 0; i < spell->power_count(); i++ )
      {
        if ( pow_idx_bit & ( 1U << i ) )
        {
          auto pow = spell->powerN( i + 1 );
          auto id = pow.id();
          if ( !id )
            continue;

          auto data_val = pow.get_field( pow_field ) / pow.cost_divisor( false );
          if ( data_val == 0 && !allow_zero )
            continue;

          auto flat_pow = flat_val / pow.cost_divisor( false );

          auto [ prev, now ] = add_passive_effect_modifier(
            passive_power_modifiers_, id, get_type_from_field( pow_field ), data_val, flat_pow, pct_val );

          do_debug( fmt::format(
            "pow#{} {} ({}) {} by {:.7g}{} (orig={:.7g} prev={:.7g}[{:.7g}/{:.7g}%] now={:.7g}[{:.7g}/{:.7g}%])", i + 1,
            util::resource_type_string( pow.resource() ), id, pow_field, flat_pow ? flat_pow : pct_val * 100,
            flat_pow ? "" : "%", now.orig, prev.value(), prev.flat, prev.pct * 100, now.value(), now.flat,
            now.pct * 100 ) );

          add_reporting( fmt::format( "{} {}", util::resource_type_string( pow.resource() ), pow_field ) );

          dbc_override_->register_power( *dbc, id, pow_field, now.value() );

          if ( pow_field == "cost" )
          {
            auto prev_val2 = pow.get_field( "cost_per_tick" );
            if ( prev_val2 )
            {
              auto now_val2 = ( prev_val2 + flat_val ) * ( 1.0 + pct_val );

              do_debug( fmt::format( "pow#{} {} ({}) {} by {:.7g}{} (prev={:.7g} now={:.7g})", i + 1,
                                     util::resource_type_string( pow.resource() ), id, "cost_per_tick",
                                     flat_val ? flat_val : pct_val * 100, flat_val ? "" : "%", prev_val2, now_val2 ) );

              add_reporting( fmt::format( "{} cost_per_tick", util::resource_type_string( pow.resource() ) ) );

              dbc_override_->register_power( *dbc, id, "cost_per_tick", now_val2 );
            }
          }

          success = true;
        }
      }
    }
    else if ( !eff_field.empty() )  // modify spelleffect_data_t
    {
      for ( const auto& eff : spell->effects() )
      {
        auto id = eff.id();
        if ( !id )
          continue;

        auto field_ = eff_field;
        auto data_val = eff.get_field( field_ );
        if ( !data_val && !eff_field2.empty() )
        {
          field_ = eff_field2;
          data_val = eff.get_field( field_ );
        }

        if ( data_val == 0 )
        {
          if ( is_damage )
          {
            if ( eff.type() != E_SCHOOL_DAMAGE )
              continue;
          }
          else if ( !allow_zero )
          {
            continue;
          }
        }

        auto [ prev, now ] =
          add_passive_effect_modifier( passive_effect_modifiers_, id, field_type, data_val, flat_val, pct_val );

        do_debug( fmt::format( "{} by {:.7g}{} (orig={:.7g} prev={:.7g}[{:.7g}/{:.7g}%] now={:.7g}[{:.7g}/{:.7g}%])",
                               field_, flat_val ? flat_val : pct_val * 100, flat_val ? "" : "%", now.orig, prev.value(),
                               prev.flat, prev.pct * 100, now.value(), now.flat, now.pct * 100 ) );

        add_reporting( field_ );

        dbc_override_->register_effect( *dbc, id, field_, now.value() );
        success = true;
      }
    }
    else if ( eff_idx != 0 )  // modify another effect
    {
      if ( as<int>( spell->effect_count() ) < eff_idx )
      {
        sim->print_debug( "{} only has {} effects, but {} is trying to modify eff#{}, ignoring.", *spell,
                          spell->effect_count(), *modifying_spell, eff_idx );
        continue;
      }
      // populate all effects in case of P_EFFECTS
      std::vector<const spelleffect_data_t*> eff_list;
      if ( eff_idx == -1 )
        range::for_each( spell->effects(), [ & ]( const auto& e ) { eff_list.push_back( &e ); } );
      else
        eff_list.push_back( &spell->effectN( eff_idx ) );

      for ( auto eff : eff_list )
      {
        auto id = eff->id();
        if ( !id )
          continue;

        // if the effect's spell has already been registered, de-register, modify, then re-register
        bool deregister = range::contains( registered_passive_spells_, eff->spell()->id(),
                                           &std::pair<unsigned, parse_source_e>::first );
        if ( deregister )
        {
          if ( sim->debug )
          {
            sim->print_debug( "De-register {} eff#{}", *eff->spell(), eff->index() + 1 );
          }

          register_passive_effect( *eff, true );
        }

        auto data_val = eff->average( this );
        auto [ prev, now ] =
          add_passive_effect_modifier( passive_effect_modifiers_, id, field_type, data_val, flat_val, pct_val );

        do_debug(
          fmt::format( "eff#{} by {:.7g}{} (orig={:.7g} prev={:.7g}[{:.7g}/{:.7g}%] now={:.7g}[{:.7g}/{:.7g}%])",
                       eff->index() + 1, flat_val ? flat_val : pct_val * 100, flat_val ? "" : "%", now.orig,
                       prev.value(), prev.flat, prev.pct * 100, now.value(), now.flat, now.pct * 100 ) );

        if ( !sim->parent && !sim->profileset_enabled && sim->report_details > 0 && !sim->html_file_str.empty() )
        {
          if ( remove )
            range::erase_remove( reporting_parse_effect[ spell->id() ][ eff->index() + 1 ], &modifying_eff );
          else
            reporting_parse_effect[ spell->id() ][ eff->index() + 1 ].push_back( &modifying_eff );
        }

        dbc_override_->register_effect( *dbc, id, "base_value", now.value() );
        success = true;

        // re-register if necessary
        if ( deregister )
        {
          sim->print_debug( "Re-register {} eff#{}", *eff, eff->index() + 1 );

          register_passive_effect( *eff );
        }
      }
    }
  }

  return success;
}

void player_t::parse_passive_effects( const spell_data_t* spell, bool force, parse_source_e source )
{
  if ( !spell || !spell->ok() )
    return;

  if ( !force &&
       range::contains( registered_passive_spells_, spell->id(), &std::pair<unsigned, parse_source_e>::first ) )
  {
    sim->error( "Unable to register {}, spell already registered.", *spell );
    return;
  }

  if ( !force && range::contains( deregistered_passive_spells_, spell->id() ) )
  {
    sim->print_debug( "Unable to register {}, spell has been de-registered.", *spell );
    return;
  }

  if ( !force && !spell->flags( SX_PASSIVE ) )
  {
    sim->error( "Unable to register {}, spell is not passive.", *spell );
    return;
  }

  bool success = false;

  // go thru all the effects on the modifying spell
  for ( const auto& eff : spell->effects() )
  {
    // filter out ignore list
    if ( range::contains( registered_effect_ignore_list_, eff.id() ) )
    {
      sim->print_debug( "Skipping {} eff#{} ({}), effect has been de-registered.", *spell, eff.index() + 1, eff.id() );
      continue;
    }

    // filter out non-aura applications
    if ( eff.type() != E_APPLY_AURA && eff.type() != E_APPLY_AREA_AURA_PARTY && eff.type() != E_APPLY_AURA_PLAYER_AND_PET )
      continue;

    success = register_passive_effect( eff ) ? true : success;
  }

  if ( success )
    registered_passive_spells_.emplace_back( spell->id(), source );
}

void player_t::deregister_passive_spell( const spell_data_t* spell )
{
  if ( !spell || !spell->ok() || range::contains( deregistered_passive_spells_, spell->id() ) )
    return;

  sim->print_debug( "De-registering {}, current and all future parsing on this spell blocked.", *spell );

  deregistered_passive_spells_.push_back( spell->id() );

  if ( range::contains( registered_passive_spells_, spell->id(), &std::pair<unsigned, parse_source_e>::first ) )
  {
    // go thru all the effects on the modifying spell
    for ( const auto& eff : spell->effects() )
    {
      // filter out ignore list
      if ( range::contains( registered_effect_ignore_list_, eff.id() ) )
        continue;

      // filter out non-effect-modifying effects
      if ( eff.type() != E_APPLY_AURA && eff.type() != E_APPLY_AREA_AURA_PARTY &&
           eff.type() != E_APPLY_AURA_PLAYER_AND_PET )
        continue;

      register_passive_effect( eff, true );
    }

    range::erase_remove( registered_passive_spells_, [ id = spell->id() ]( const auto& e ) { return e.first == id; } );
  }
}

void player_t::deregister_passive_effect( const spelleffect_data_t& effect )
{
  if ( !effect.ok() || range::contains( registered_effect_ignore_list_, effect.id() ) )
    return;

  bool deregister =
    range::contains( registered_passive_spells_, effect.spell()->id(), &std::pair<unsigned, parse_source_e>::first );

  sim->print_debug( "De-registering {} eff#{} ({}), current and all future parsing of this effect blocked.",
                    *effect.spell(), effect.index() + 1, effect.id() );

  registered_effect_ignore_list_.push_back( effect.id() );

  if ( deregister )
    register_passive_effect( effect, true );
}

void player_t::register_passive_effect_mask( const spell_data_t* spell, uint32_t mask )
{
  if ( !spell || !spell->ok() || !mask )
    return;

  bool deregister =
    range::contains( registered_passive_spells_, spell->id(), &std::pair<unsigned, parse_source_e>::first );

  std::vector<std::string> msg;
  auto mask_ = mask;
  for ( size_t i = 1; mask_ && i <= spell->effect_count(); mask_ >>= 1, i++ )
    if ( mask_ & 1 )
      msg.push_back( std::to_string( i ) );

  sim->print_debug( "Registering {} effect_mask eff#{} ({:#b})", *spell, util::string_join( msg, "," ), mask );

  for ( const auto& eff : spell->effects() )
  {
    if ( mask & ( 1U << eff.index() ) && !range::contains( registered_effect_ignore_list_, eff.id() ) )
    {
      registered_effect_ignore_list_.push_back( eff.id() );

      if ( deregister )
      {
        sim->print_debug( "De-register {} eff#{} ({})", *spell, eff.index() + 1, eff.id() );
        register_passive_effect( eff, true );
      }
    }
  }
}

void player_t::register_passive_affect_list( const spell_data_t* spell, const affect_list_t& mod )
{
  if ( !spell || !spell->ok() || mod.idx.empty() || ( mod.spell.empty() && mod.label.empty() && mod.family.empty() ) )
    return;

  bool deregister =
    range::contains( registered_passive_spells_, spell->id(), &std::pair<unsigned, parse_source_e>::first );

  std::vector<std::string> list_str;
  if ( !mod.spell.empty() )
    list_str.push_back( fmt::format( "spell={}", fmt::join( mod.spell, ", " ) ) );
  if ( !mod.label.empty() )
    list_str.push_back( fmt::format( "label={}", fmt::join( mod.label, ", " ) ) );
  if ( !mod.family.empty() )
    list_str.push_back( fmt::format( "family_flag={}", fmt::join( mod.family, ", " ) ) );

  sim->print_debug( "Registering {} eff#{} affect_list ({})", *spell, fmt::join( mod.idx, "," ),
                    fmt::join( list_str, ", " ) );

  for ( auto idx : mod.idx )
  {
    if ( const auto& eff = spell->effectN( idx ); eff.ok() )
    {
      std::vector<int> list;

      range::for_each( mod.spell, [ & ]( auto id ) {
        list.push_back( id );
      } );

      range::for_each( mod.label, [ & ]( auto l ) {
        range::for_each( dbc->spells_by_label( abs( l ) ), [ & ]( auto s ) {
          list.push_back( as<int>( s->id() ) * ( l < 0 ? -1 : 1 ) );
        } );
      } );

      range::for_each( mod.family, [ & ]( auto f ) {
        range::for_each( dbc->family_flag_affects_spells( spell->class_family(), abs( f ) - 1 ), [ & ]( auto s ) {
          list.push_back( as<int>( s->id() ) * ( f < 0 ? -1 : 1 ) );
        } );
      } );

      if ( !list.empty() )
      {
        if ( deregister )
        {
          sim->print_debug( "De-register {} eff#{}", *spell, idx );
          register_passive_effect( eff, true );
        }

        registered_affected_spell_list_.emplace_back( eff.id(), std::move( list ) );

        if ( deregister )
        {
          sim->print_debug( "Re-register {} eff#{}", *spell, idx );
          register_passive_effect( eff );
        }
      }
    }
  }
}

void player_t::parse_all_class_passives()
{
  // class passives
  for ( const auto& passive_spell : passive_class_spell_t::data( dbc->ptr ) )
  {
    if ( as<int>( passive_spell.class_id ) == util::class_id( type ) )
    {
      auto spell = find_spell( passive_spell.spell_id );
      parse_passive_effects( spell, false, PARSE_SOURCE_CLASS );
    }
  }

  // spec passives & spec-only rank spells
  auto mastery_id = mastery_spell_entry_t::find( specialization(), dbc->ptr ).spell_id;

  for ( const auto& spec_entry : specialization_spell_entry_t::data( dbc->ptr ) )
  {
    if ( spec_entry.specialization_id == static_cast<unsigned>( specialization() ) &&
         spec_entry.spell_id != mastery_id )
    {
      auto spell = find_spell( spec_entry.spell_id );
      if ( spell->flags( SX_PASSIVE ) )
        parse_passive_effects( spell, false, PARSE_SOURCE_SPEC );
    }
  }

  // racials
  for ( const auto& racial_spell : racial_spell_entry_t::data( dbc->ptr ) )
  {
    if ( util::race_mask( race ) & racial_spell.mask_race &&
         ( !racial_spell.mask_class || util::class_id_mask( type ) & racial_spell.mask_class ) )
    {
      auto spell = find_spell( racial_spell.spell_id );
      if ( spell->flags( SX_PASSIVE ) )
        parse_passive_effects( spell, false, PARSE_SOURCE_RACIAL );
    }
  }

  // handle touch of elune day/night buff
  if ( find_racial_spell( "Touch of Elune" )->ok() )
    parse_passive_effects( find_spell( timeofday == DAY_TIME ? 154796 : 154797 ), true, PARSE_SOURCE_RACIAL );

  // may as well handle this here
  if ( auto sub_pred = find_racial_spell( "Subterranean Predator" ); sub_pred->ok() )
    register_creature_type_buff( nullptr, sub_pred );
}

void player_t::parse_all_passive_talents()
{
  for ( auto [ tree, entry_id, rank ] : player_traits )
  {
    if ( !rank || tree == talent_tree::SELECTION )
      continue;

    auto obj = find_talent_spell( entry_id );
    if ( !obj.ok() || !obj.spell()->ok() || !obj.spell()->flags( SX_PASSIVE ) )
      continue;

    parse_passive_effects( obj.spell(), false, PARSE_SOURCE_TALENT );
  }
}

void player_t::parse_all_passive_sets()
{
  for ( const auto& bonus_type : sets->set_bonus_spec_data )
    for ( const auto& bonus : bonus_type )
      for ( const auto& data : bonus )
        if ( data.enabled )
          parse_passive_effects( data.spell, false, PARSE_SOURCE_SET );
}

void player_t::parse_raid_buffs()
{
  // blessing of the bronze
  if ( sim->overrides.blessing_of_the_bronze )
  {
    // classes are assigned alphabetically starting from eff#1
    auto spell = find_spell( 364342 )->effectN( static_cast<unsigned>( type ) ).trigger();
    parse_passive_effects( spell, true );

    auto buff = make_buff( this, "blessing_of_the_bronze", spell );
    register_precombat_begin( [ buff ]( auto ) { buff->override_buff(); } );
  }

  // mark of the wild
  if ( sim->overrides.mark_of_the_wild )
  {
    // if overrides are registered for the 'self-buff' talents, use the cloned spell_data_t
    auto spell = dbc_override->find_spell( sim->auras.mark_of_the_wild->data().id(), is_ptr() );

    parse_passive_effects( spell ? spell : &sim->auras.mark_of_the_wild->data(), true );
  }
}

void player_t::register_passive_spell_override( const spell_data_t& spell, double value, std::string_view field )
{
  if ( spell.ok() )
    dbc_override_->register_spell( *dbc, spell.id(), field, value );
}

void player_t::register_passive_power_override( const spellpower_data_t& power, double value, std::string_view field )
{
  if ( power.id() != 0 )
  dbc_override_->register_power( *dbc, power.id(), field, value );
}

void player_t::register_passive_effect_override( const spelleffect_data_t& effect, double value, std::string_view field )
{
  if ( effect.ok() )
    dbc_override_->register_effect( *dbc, effect.id(), field, value );
}

const spell_data_t* player_t::clone_dbc_override_spell( const player_t* p, const spell_data_t* s )
{
  return p->dbc_override_->clone_spell( s, p->dbc->ptr );
}

std::string_view player_t::get_parsed_source( unsigned spell_id ) const
{
  for ( auto [ id, source ] : registered_passive_spells_ )
  {
    if ( id == spell_id )
    {
      switch ( source )
      {
        case PARSE_SOURCE_MANUAL: return "Manual";
        case PARSE_SOURCE_CLASS:  return "Class Spell";
        case PARSE_SOURCE_SPEC:   return "Spec Spell";
        case PARSE_SOURCE_RACIAL: return "Racial";
        case PARSE_SOURCE_TALENT: return "Talent";
        case PARSE_SOURCE_SET:    return "Set Bonus";
        case PARSE_SOURCE_ITEM:   return "Item";
        default:                  return "BAD_SOURCE";
      }
    }
  }

  return "NO_SOURCE";
}

void player_t::print_parsed_effects( report::sc_html_stream& os ) const
{
  if ( !sim->report_details )
    return;

  os << R"(<div class="player-section parsed_effects">)"
     << R"(<h3 class="toggle">Parsed Player Effects</h3>)"
     << R"(<div class="toggle-content hide">)";

  os << R"(<table class="sc left even"><thead><tr><th colspan="2" class="left">Passive Effects</th>)"
     << R"(<th>Spell</th><th colspan="2">ID</th><th>Value</th><th>Source</th></tr></thead>)";

  for ( const auto& [ field, misc_list ] : reporting_parse_player )
  {
    auto m_it = range::find( misc_expansion_map, field, &misc_expansion_t::field );
    bool has_misc = m_it != misc_expansion_map.end();

    auto rows = range::accumulate( misc_list, 0, []( const auto& m ) { return m.second.size(); } );
    bool row_open = true;

    os.format( R"(<tr><td colspan="{}" rowspan="{}" class="dark">{}</td>)", has_misc ? "1" : "2", rows,
               util::inverse_tokenize( field ) );

    for ( const auto& [ misc, eff_list ] : misc_list )
    {
      if ( eff_list.empty() )
        continue;

      if ( has_misc )
      {
        auto m_rows = eff_list.size();

        if ( !row_open )
        {
          row_open = true;
          os << "<tr>";
        }

        os.format( R"(<td rowspan="{}" class="dark">{}</td>)", m_rows,
                   util::inverse_tokenize( m_it->formatter( misc ) ) );
      }

      for ( auto eff : eff_list )
      {
        if ( !row_open )
          os << "<tr>";

        os.format( R"(<td>{}</td><td class="right">{}</td><td>#{}</td><td class="right">{:.2f}{}</td><td>{}</td>)",
                   report_decorators::decorated_spell_data( *sim, eff->spell() ), eff->spell()->id(), eff->index() + 1,
                   eff->average( this ), eff->default_multiplier() == 0.01 ? "%" : "",
                   get_parsed_source( eff->spell()->id() ) );

        os << "</tr>\n";
        row_open = false;
      }
    }
  }

  os << "</table>\n";

  os << R"(<table class="sc left even"><thead><tr><th class="left">Passive Modified Spell</th>)"
     << R"(<th colspan="2">ID</th><th>Effect Type</th><th>Modified By</th><th colspan="2">ID</th>)"
     << "<th>Value</th><th>Source</th></tr></thead>\n";

  for ( const auto& [ spell_id, spell_indices ] : reporting_parse_effect )
  {
    auto spell = find_spell( spell_id );
    auto rows = range::accumulate( spell_indices, 0, []( const auto& e ) { return e.second.size(); } );
    bool row_open = true;

    os.format( R"(<tr><td rowspan="{}" class="dark">{}</td><td rowspan="{}" class="dark right">{}</td>)", rows,
               report_decorators::decorated_spell_data( *sim, spell ), rows, spell_id );

    for ( const auto& [ idx, eff_list ] : spell_indices )
    {
      auto spell_eff = spell->effectN( idx );
      auto i_rows = eff_list.size();
      std::string eff_str;

      switch ( spell_eff.type() )
      {
        case E_APPLY_AURA:
        case E_APPLY_AURA_PET:
        case E_APPLY_AREA_AURA_PET:
        case E_APPLY_AREA_AURA_PARTY:
          switch ( spell_eff.subtype() )
          {
            case A_ADD_FLAT_MODIFIER:
            case A_ADD_FLAT_LABEL_MODIFIER:
              eff_str = fmt::format( "Flat {}", spell_info::effect_property_str( &spell_eff ) );
              break;
            case A_ADD_PCT_MODIFIER:
            case A_ADD_PCT_LABEL_MODIFIER:
              eff_str = fmt::format( "Percent {}", spell_info::effect_property_str( &spell_eff ) );
              break;
            default:
              eff_str = spell_info::effect_subtype_str( &spell_eff );
              break;
          }
          break;
        default:
          eff_str = spell_info::effect_type_str( &spell_eff );
          break;
      }

      if ( !row_open )
      {
        row_open = true;
        os << "<tr>";
      }

      os.format( R"(<td rowspan="{}" class="dark">#{}</td><td rowspan="{}" class="dark">{}</td>)", i_rows, idx, i_rows,
                 eff_str );

      for ( auto eff : eff_list )
      {
        std::string e_td_str = R"(class="right")";
        bool is_pct = eff->subtype() == A_ADD_PCT_MODIFIER || eff->subtype() == A_ADD_PCT_LABEL_MODIFIER;

        if ( !row_open )
          os << "<tr>";

        os.format( R"(<td>{}</td><td class="right">{}</td><td>#{}</td><td class="right">{:.1f}{}</td><td>{}</td>)",
                   report_decorators::decorated_spell_data( *sim, eff->spell() ), eff->spell()->id(), eff->index() + 1,
                   eff->average( this ), is_pct ? "%" : "", get_parsed_source( eff->spell()->id() ) );

        os << "</tr>\n";
        row_open = false;
      }
    }
  }

  os << "</table>\n";

  print_custom_parsed_effects( os );

  os << "</div></div>\n";
}

void player_t::parse_passive_item_effect( const spell_data_t* spell )
{
  parse_passive_effects( spell, true, PARSE_SOURCE_ITEM );
}

void player_t::register_passive_item_effect_override( const spelleffect_data_t& effect, double value )
{
  register_passive_effect_override( effect, value );
}
