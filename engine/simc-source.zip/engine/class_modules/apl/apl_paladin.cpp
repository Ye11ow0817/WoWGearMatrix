#include "class_modules/apl/apl_paladin.hpp"

#include "player/action_priority_list.hpp"
#include "player/player.hpp"
#include "dbc/dbc.hpp"
#include "sim/sim.hpp"

namespace paladin_apl
{

//retribution_apl_start
void retribution( player_t* p )
{
  action_priority_list_t* default_ = p->get_action_priority_list( "default" );
  action_priority_list_t* precombat = p->get_action_priority_list( "precombat" );
  action_priority_list_t* cooldowns = p->get_action_priority_list( "cooldowns" );
  action_priority_list_t* finishers = p->get_action_priority_list( "finishers" );
  action_priority_list_t* generators = p->get_action_priority_list( "generators" );

  precombat->add_action( "snapshot_stats", "Snapshot raid buffed stats before combat begins and pre-potting is done." );
  precombat->add_action( "variable,name=trinket_1_buffs,value=trinket.1.has_buff.strength|trinket.1.has_buff.mastery|trinket.1.has_buff.versatility|trinket.1.has_buff.haste|trinket.1.has_buff.crit" );
  precombat->add_action( "variable,name=trinket_2_buffs,value=trinket.2.has_buff.strength|trinket.2.has_buff.mastery|trinket.2.has_buff.versatility|trinket.2.has_buff.haste|trinket.2.has_buff.crit" );
  precombat->add_action( "variable,name=trinket_1_sync,op=setif,value=1,value_else=0.5,condition=variable.trinket_1_buffs&(trinket.1.cooldown.duration%%cooldown.avenging_wrath.duration=0|cooldown.avenging_wrath.duration%%trinket.1.cooldown.duration=0)" );
  precombat->add_action( "variable,name=trinket_2_sync,op=setif,value=1,value_else=0.5,condition=variable.trinket_2_buffs&(trinket.2.cooldown.duration%%cooldown.avenging_wrath.duration=0|cooldown.avenging_wrath.duration%%trinket.2.cooldown.duration=0)" );
  precombat->add_action( "variable,name=trinket_priority,op=setif,value=2,value_else=1,condition=!variable.trinket_1_buffs&variable.trinket_2_buffs|variable.trinket_2_buffs&((trinket.2.cooldown.duration%trinket.2.proc.any_dps.duration)*(1.5+trinket.2.has_buff.strength)*(variable.trinket_2_sync))>((trinket.1.cooldown.duration%trinket.1.proc.any_dps.duration)*(1.5+trinket.1.has_buff.strength)*(variable.trinket_1_sync))" );
  precombat->add_action( "use_item,name=algethar_puzzle_box,if=(trinket.1.is.algethar_puzzle_box|trinket.2.is.algethar_puzzle_box)" );
  precombat->add_action( "variable,name=pre_es_wake,op=reset,default=0" );

  default_->add_action( "auto_attack" );
  default_->add_action( "rebuke" );
  default_->add_action( "call_action_list,name=cooldowns" );
  default_->add_action( "call_action_list,name=generators" );

  cooldowns->add_action( "use_item,name=algethar_puzzle_box,if=(cooldown.avenging_wrath.remains=0&!talent.radiant_glory|(!talent.execution_sentence&cooldown.wake_of_ashes.remains=0|cooldown.execution_sentence.remains=0)&talent.radiant_glory)" );
  cooldowns->add_action( "potion,if=buff.avenging_wrath.up|fight_remains<30|talent.radiant_glory&cooldown.wake_of_ashes.remains=0&(!talent.holy_flames|dot.expurgation.ticking)" );
  cooldowns->add_action( "use_item,slot=trinket1,if=((buff.avenging_wrath.up&cooldown.avenging_wrath.remains>40)&!talent.radiant_glory|talent.radiant_glory&(!talent.execution_sentence&cooldown.wake_of_ashes.remains=0|debuff.execution_sentence_debuff.up))&(!trinket.2.has_cooldown|trinket.2.cooldown.remains|variable.trinket_priority=1)|trinket.1.proc.any_dps.duration>=fight_remains" );
  cooldowns->add_action( "use_item,slot=trinket2,if=((buff.avenging_wrath.up&cooldown.avenging_wrath.remains>40)&!talent.radiant_glory|talent.radiant_glory&(!talent.execution_sentence&cooldown.wake_of_ashes.remains=0|debuff.execution_sentence_debuff.up))&(!trinket.1.has_cooldown|trinket.1.cooldown.remains|variable.trinket_priority=2)|trinket.2.proc.any_dps.duration>=fight_remains" );
  cooldowns->add_action( "use_item,slot=trinket1,if=!variable.trinket_1_buffs&(trinket.2.cooldown.remains|!variable.trinket_2_buffs|!buff.avenging_wrath.up&cooldown.avenging_wrath.remains>20)" );
  cooldowns->add_action( "use_item,slot=trinket2,if=!variable.trinket_2_buffs&(trinket.1.cooldown.remains|!variable.trinket_1_buffs|!buff.avenging_wrath.up&cooldown.avenging_wrath.remains>20)" );
  cooldowns->add_action( "invoke_external_buff,name=power_infusion,if=buff.avenging_wrath.up|talent.radiant_glory&cooldown.wake_of_ashes.remains=0&(!talent.holy_flames|dot.expurgation.ticking)" );
  cooldowns->add_action( "lights_judgment,if=!raid_event.adds.exists|raid_event.adds.in>75|raid_event.adds.up" );
  cooldowns->add_action( "fireblood,if=buff.avenging_wrath.up|talent.radiant_glory&cooldown.wake_of_ashes.remains=0&(!talent.holy_flames|dot.expurgation.ticking)" );
  cooldowns->add_action( "execution_sentence,if=(cooldown.avenging_wrath.remains>15|talent.radiant_glory)&(target.time_to_die>10)&(cooldown.wake_of_ashes.remains<gcd|variable.pre_es_wake=1)&(!talent.holy_flames|dot.expurgation.ticking)&(!talent.crusade|buff.avenging_wrath.stack>=7|variable.pre_es_wake=0)" );
  cooldowns->add_action( "avenging_wrath,if=(!raid_event.adds.up|target.time_to_die>10)&(!talent.holy_flames|dot.expurgation.ticking)&(!equipped.algethar_puzzle_box|trinket.1.is.algethar_puzzle_box&trinket.1.cooldown.remains>5|trinket.2.is.algethar_puzzle_box&trinket.2.cooldown.remains>5)" );

  finishers->add_action( "variable,name=ds_castable,value=(active_enemies>=2|buff.divine_arbiter_verdict.up)&!buff.empyrean_legacy.up&!buff.divine_arbiter_divine_storm.up" );
  finishers->add_action( "hammer_of_light,if=!buff.hammer_of_light_free.up|buff.hammer_of_light_free.up&(buff.undisputed_ruling.remains<gcd*1.5&(talent.radiant_glory|cooldown.avenging_wrath.remains>4)|buff.avenging_wrath.up&(buff.avenging_wrath.remains<gcd*2|cooldown.wake_of_ashes.remains=0)|buff.hammer_of_light_free.remains<gcd*2|target.time_to_die<gcd*2)" );
  finishers->add_action( "divine_storm,if=variable.ds_castable" );
  finishers->add_action( "templars_verdict" );

  generators->add_action( "call_action_list,name=finishers,if=holy_power=5&cooldown.wake_of_ashes.remains|buff.hammer_of_light_free.remains<gcd*2" );
  generators->add_action( "wake_of_ashes,if=(cooldown.avenging_wrath.remains>6|talent.radiant_glory)&(!talent.execution_sentence|cooldown.execution_sentence.remains>4|target.time_to_die<10|variable.pre_es_wake=1)&(!raid_event.adds.exists|raid_event.adds.in>10|raid_event.adds.up)" );
  generators->add_action( "divine_toll,if=(!raid_event.adds.exists|raid_event.adds.in>10|raid_event.adds.up)&(cooldown.avenging_wrath.remains>15|talent.radiant_glory|fight_remains<8)" );
  generators->add_action( "blade_of_justice,if=(buff.art_of_war.stack=2|buff.righteous_cause.stack=2)&(!talent.walk_into_light|!buff.avenging_wrath.up)" );
  generators->add_action( "hammer_of_wrath,if=talent.walk_into_light&cooldown.hammer_of_wrath.charges=2" );
  generators->add_action( "call_action_list,name=finishers" );
  generators->add_action( "hammer_of_wrath,if=talent.walk_into_light" );
  generators->add_action( "blade_of_justice" );
  generators->add_action( "hammer_of_wrath" );
  generators->add_action( "judgment" );
  generators->add_action( "templar_strike" );
  generators->add_action( "templar_slash" );
  generators->add_action( "crusader_strike" );
  generators->add_action( "arcane_torrent" );
}
//retribution_apl_end

//protection_apl_start
void protection( player_t* p )
{
  action_priority_list_t* default_ = p->get_action_priority_list( "default" );
  action_priority_list_t* precombat = p->get_action_priority_list( "precombat" );
  action_priority_list_t* trinkets = p->get_action_priority_list( "trinkets" );

  precombat->add_action( "rite_of_sanctification" );
  precombat->add_action( "rite_of_adjuration" );
  precombat->add_action( "snapshot_stats" );
  precombat->add_action( "devotion_aura" );
  precombat->add_action( "variable,name=trinket_1_buffs,value=trinket.1.has_use_buff" );
  precombat->add_action( "variable,name=trinket_2_buffs,value=trinket.2.has_use_buff" );
  precombat->add_action( "variable,name=trinket_1_duration,op=setif,value=0,value_else=trinket.1.proc.any_dps.duration,condition=0" );
  precombat->add_action( "variable,name=trinket_2_duration,op=setif,value=0,value_else=trinket.2.proc.any_dps.duration,condition=0" );
  precombat->add_action( "variable,name=trinket_1_high_value,op=setif,value=3,value_else=1,condition=trinket.1.is.voracious_heart_of_ulatek" );
  precombat->add_action( "variable,name=trinket_2_high_value,op=setif,value=3,value_else=1,condition=trinket.2.is.voracious_heart_of_ulatek" );
  precombat->add_action( "variable,name=trinket_1_sync,op=setif,value=1,value_else=0.5,condition=variable.trinket_1_buffs&trinket.1.cooldown.duration%%cooldown.avenging_wrath.duration=0" );
  precombat->add_action( "variable,name=trinket_2_sync,op=setif,value=1,value_else=0.5,condition=variable.trinket_2_buffs&trinket.2.cooldown.duration%%cooldown.avenging_wrath.duration=0" );
  precombat->add_action( "variable,name=trinket_priority,op=setif,value=2,value_else=1,condition=!variable.trinket_1_buffs&variable.trinket_2_buffs&(trinket.2.has_cooldown|!trinket.1.has_cooldown)|variable.trinket_2_buffs&((trinket.2.cooldown.duration%variable.trinket_2_duration)*(1.5+trinket.2.has_buff.strength)*(variable.trinket_2_sync)*(variable.trinket_2_high_value)*(1+((trinket.2.ilvl-trinket.1.ilvl)%100)))>((trinket.1.cooldown.duration%variable.trinket_1_duration)*(1.5+trinket.1.has_buff.strength)*(variable.trinket_1_sync)*(variable.trinket_1_high_value)*(1+((trinket.1.ilvl-trinket.2.ilvl)%100)))" );
  precombat->add_action( "variable,name=damage_trinket_priority,op=setif,value=2,value_else=1,condition=!variable.trinket_1_buffs&!variable.trinket_2_buffs&trinket.2.ilvl>=trinket.1.ilvl" );
  precombat->add_action( "potion,pre_pot_time=8,if=potion.liquid_luster" );
  precombat->add_action( "consecration" );
  precombat->add_action( "holy_armaments,if=next_armament=holy_bulwark" );

  default_->add_action( "auto_attack" );
  default_->add_action( "call_action_list,name=trinkets" );
  default_->add_action( "potion,if=potion.liquid_luster&cooldown.avenging_wrath.remains<8" );
  default_->add_action( "potion,if=!potion.liquid_luster&(buff.avenging_wrath.up|cooldown.avenging_wrath.up)" );
  default_->add_action( "ardent_defender,if=talent.eye_for_an_eye" );
  default_->add_action( "variable,use_off_gcd=1,name=wants_to_hammer,value=buff.hammer_of_light_ready.up&debuff.judgment.up&(buff.undisputed_ruling.remains<=1.8|buff.hammer_of_light_ready.remains<5)" );
  default_->add_action( "holy_armaments,if=cooldown.avenging_wrath.remains<=gcd|time_to_die<30|charges=2" );
  default_->add_action( "fireblood,if=buff.avenging_wrath.up" );
  default_->add_action( "avenging_wrath" );
  default_->add_action( "divine_toll,if=buff.avenging_wrath.up|!apex.3" );
  default_->add_action( "hammer_of_light,if=variable.wants_to_hammer" );
  default_->add_action( "shield_of_the_righteous,if=(!talent.instrument_of_the_divine&buff.divine_guidance.stack<5|holy_power=5|!buff.valor.up&!buff.divine_purpose.up)&(!variable.wants_to_hammer|prev_gcd.1.divine_toll)" );
  default_->add_action( "hammer_of_wrath,if=full_recharge_time<=gcd|buff.hammer_of_light_ready.up&!debuff.judgment.up" );
  default_->add_action( "judgment,if=full_recharge_time<=gcd|buff.hammer_of_light_ready.up&!debuff.judgment.up" );
  default_->add_action( "avengers_shield,if=buff.vanguard.up|(buff.avenging_wrath.up&apex.3)" );
  default_->add_action( "consecration,if=buff.divine_guidance.stack>=5|!consecration.up" );
  default_->add_action( "hammer_of_wrath" );
  default_->add_action( "judgment" );
  default_->add_action( "avengers_shield" );
  default_->add_action( "blessed_hammer" );
  default_->add_action( "hammer_of_the_righteous" );
  default_->add_action( "arcane_torrent" );
  default_->add_action( "word_of_glory,if=buff.shining_light_free.up&!buff.divine_purpose.up" );
  default_->add_action( "consecration" );

  trinkets->add_action( "variable,name=cds_active,value=buff.avenging_wrath.up&buff.avenging_wrath.remains>5", "Trinkets" );
  trinkets->add_action( "use_item,slot=trinket1,if=variable.trinket_1_buffs&(variable.trinket_priority=1|!variable.trinket_2_buffs|!trinket.2.has_cooldown|variable.trinket_2_buffs&trinket.2.cooldown.remains)&(trinket.1.cast_time>0&trinket.1.cast_time>cooldown.avenging_wrath.remains|trinket.1.cast_time=0&variable.cds_active)" );
  trinkets->add_action( "use_item,slot=trinket2,if=variable.trinket_2_buffs&(variable.trinket_priority=2|!variable.trinket_1_buffs|!trinket.1.has_cooldown|variable.trinket_1_buffs&trinket.1.cooldown.remains)&(trinket.2.cast_time>0&trinket.2.cast_time>cooldown.avenging_wrath.remains|trinket.2.cast_time=0&variable.cds_active)" );
  trinkets->add_action( "use_item,slot=trinket1,if=!variable.trinket_1_buffs&(!trinket.2.has_cooldown|trinket.2.cooldown.remains|!variable.trinket_2_buffs)&(variable.damage_trinket_priority=1|trinket.2.cooldown.remains)" );
  trinkets->add_action( "use_item,slot=trinket2,if=!variable.trinket_2_buffs&(!trinket.1.has_cooldown|trinket.1.cooldown.remains|!variable.trinket_1_buffs)&(variable.damage_trinket_priority=2|trinket.1.cooldown.remains)" );
}
//protection_apl_end
}  // namespace paladin_apl
