// ==========================================================================
// Dedmonwakeen's Raid DPS/TPS Simulator.
// Send questions to natehieter@gmail.com
// ==========================================================================

#pragma once

#include "config.hpp"

#include "action/action_callback.hpp"
#include "dbc/data_enums.hh"
#include "player/actor_pair.hpp"
#include "sc_enums.hpp"
#include "sim/uptime.hpp"
#include "util/parse_util.hpp"
#include "util/sample_data.hpp"
#include "util/span.hpp"
#include "util/string_view.hpp"
#include "util/timeline.hpp"
#include "util/timespan.hpp"

#include <functional>
#include <memory>
#include <string>
#include <utility>
#include <vector>

struct buff_t;
struct cooldown_t;
struct event_t;
struct expr_t;
struct gain_t;
struct item_t;
struct real_ppm_t;
struct spelleffect_data_t;
struct stats_t;
namespace rng
{
struct rng_t;
}

using buff_tick_callback_t = std::function<void(buff_t* buff, int remaining_ticks, timespan_t tick_time)>;
using buff_tick_time_callback_t = std::function<timespan_t(const buff_t*, unsigned)>;
using buff_refresh_duration_callback_t = std::function<timespan_t(const buff_t*, timespan_t)>;
using buff_stack_change_callback_t = std::function<void(buff_t*, int old_stack, int new_stack)>;
using buff_expire_callback_t = std::function<void( buff_t* buff, int stacks, timespan_t duration )>;

// Buffs ====================================================================

struct buff_t : private noncopyable
{
public:
  sim_t* const sim;
  player_t* const player;
  const item_t* const item;
  const std::string name_str;
  std::string name_str_reporting;
  const spell_data_t* s_data;
  const spell_data_t* s_data_reporting;
  player_t* const source;
  std::vector<event_t*> expiration;
  std::vector<event_t*> delay;
  event_t* expiration_delay;
  cooldown_t* cooldown;
  std::unique_ptr<cooldown_t> internal_cooldown;
  sc_timeline_t uptime_array;
  real_ppm_t* rppm;

  // static values
private: // private because changing max_stacks requires resizing some stack-dependant vectors
  int _max_stack;
  int _initial_stack;

public:
  double default_value;
  size_t default_value_effect_idx;
  double default_value_effect_multiplier;
  unsigned schools;
  gcd_haste_type gcd_type;

  /**
   * Is buff manually activated or not (eg. a proc).
   * non-activated player buffs have a delayed trigger event
   */
  bool activated;
  bool reactable;
  bool reverse, constant, quiet, overridden, can_cancel, is_fallback;
  bool requires_invalidation;
  bool expire_at_max_stack, consume_all_stacks;
  bool ignore_time_modifier;

  int reverse_stack_reduction; /// Number of stacks reduced when reverse = true

  bool proc_callbacks;  // set false to disable triggering proc callbacks

  proc_data_t proc_data;
  bool& can_only_proc_from_class_abilities;
  bool& can_proc_from_procs;
  bool& can_proc_from_suppressed;
  bool& suppress_caster_procs;
  bool& enable_proc_from_suppressed;

  proc_data_t trigger_data;
  bool& trigger_can_only_proc_from_class_abilities;
  bool& trigger_can_proc_from_procs;
  bool& trigger_can_proc_from_suppressed;

  // dynamic values
  double current_value;
  int current_stack;
  parsed_value_t<timespan_t> base_buff_duration;
  double buff_duration_multiplier;
  double default_chance;
  double manual_chance; // user-specified "overridden" proc-chance
  double base_time_duration_multiplier;
  double dynamic_time_duration_multiplier;
  std::vector<timespan_t> stack_react_time;
  std::vector<event_t*> stack_react_ready_triggers;

  buff_constant_behavior constant_behavior;
  buff_refresh_behavior refresh_behavior;
  bool refresh_behavior_overridden;
  buff_refresh_duration_callback_t refresh_duration_callback;
  buff_stack_behavior stack_behavior;
  std::vector<buff_stack_change_callback_t> stack_change_callback;
  buff_expire_callback_t expire_callback;
  bool allow_precombat;

  // Ticking buff values
  unsigned current_tick;
  parsed_value_t<timespan_t> buff_period;
  buff_tick_time_behavior tick_time_behavior;
  buff_tick_behavior tick_behavior;
  event_t* tick_event;
  buff_tick_callback_t tick_callback;
  buff_tick_time_callback_t tick_time_callback;
  bool tick_zero;
  bool tick_on_application; // Immediately tick when the buff first goes up, but not on refreshes
  bool partial_tick; // Allow non-full duration ticks at the end of the buff period
  bool freeze_stacks; // Do not increment/decrement stack on each tick
  bool disable_tick_effects;

  // tmp data collection
protected:
  timespan_t last_start;
  timespan_t last_trigger;
  timespan_t last_expire;
  timespan_t last_stack_change;
  timespan_t iteration_uptime_sum;
  timespan_t last_benefite_update;
  unsigned int up_count, down_count, start_count, refresh_count, expire_count;
  unsigned int overflow_count, overflow_total;
  int trigger_attempts, trigger_successes;
  int simulation_max_stack;
  std::vector<cache_e> invalidate_list;

  // report data
public:
  simple_sample_data_t benefit_pct, trigger_pct;
  simple_sample_data_t avg_start, avg_refresh, avg_expire;
  simple_sample_data_t avg_overflow_count, avg_overflow_total;
  simple_sample_data_with_min_max_t uptime_pct;
  simple_sample_data_with_min_max_t start_intervals, trigger_intervals, duration_lengths;
  std::vector<uptime_simple_t> stack_uptime;

  virtual ~buff_t();

  buff_t( actor_pair_t q, std::string_view name );
  buff_t( actor_pair_t q, std::string_view name, const spell_data_t*, const item_t* = nullptr );
  buff_t( sim_t* sim, std::string_view name );
  buff_t( sim_t* sim, std::string_view name, const spell_data_t*, const item_t* = nullptr );

protected:
  buff_t( sim_t* sim, player_t* target, player_t* source, std::string_view name, const spell_data_t*, const item_t* );

public:
  const spell_data_t& data() const { return *s_data; }
  const spell_data_t& data_reporting() const;

  /**
   * Get current number of stacks, no benefit tracking.
   * Use check() inside of ready() and cost() methods to prevent skewing of "benefit" calculations.
   * Use up() where the presence of the buff affects the action mechanics.
   */
  int check() const
  {
    return current_stack;
  }

  /**
   * Get current number of stacks + benefit tracking.
   * Use check() inside of ready() and cost() methods to prevent skewing of "benefit" calculations.
   * This will only modify the benefit counters once per sim time unit.
   * Use up()/down where the presence of the buff affects the action mechanics.
   */
  int stack();

  /**
   * Check if buff is up
   * Use check() inside of ready() and cost() methods to prevent skewing of "benefit" calculations.
   * Use up()/down where the presence of the buff affects the action mechanics.
   */
  bool up()
  {
    return stack() > 0;
  }

  /**
   * Get current buff value + benefit tracking.
   */
  virtual double value()
  {
    stack();
    return check_value();
  }

  /**
   * Get current buff value  multiplied by current stacks + benefit tracking.
   */
  double stack_value()
  {
    return current_stack * value();
  }

  /**
   * Get current buff value + NO benefit tracking.
   */
  virtual double check_value() const
  {
    return current_value;
  }

  /**
   * Get current buff value  multiplied by current stacks + NO benefit tracking.
   */
  double check_stack_value() const
  {
    return current_stack * check_value();
  }

  // Get the base buff duration modified by the duration multiplier, if applicable
  virtual timespan_t buff_duration() const
  {
    return base_buff_duration * buff_duration_multiplier;
  }

  timespan_t remains() const;
  timespan_t tick_time_remains() const;
  timespan_t elapsed( timespan_t t ) const { return last_start == timespan_t::min() ? 0_ms : t - last_start; }
  timespan_t last_trigger_time() const { return last_trigger; }
  timespan_t last_expire_time() const { return last_expire; }
  bool remains_gt( timespan_t time ) const;
  bool remains_lt( timespan_t time ) const;
  bool has_common_school( school_e ) const;
  bool at_max_stacks( int mod = 0 ) const { return check() + mod >= max_stack(); }
  // For trigger()/execute(), default value of stacks is -1, since we want to allow for explicit calls of stacks=1 to
  // override using buff_t::_initial_stack
  int _resolve_stacks( int stacks );
  bool trigger( timespan_t duration );
  bool trigger( int stacks, timespan_t duration );
  virtual bool trigger( int stacks = -1, double value = DEFAULT_VALUE(), double chance = -1.0, timespan_t duration = timespan_t::min() );
  virtual void execute( int stacks = -1, double value = DEFAULT_VALUE(), timespan_t duration = timespan_t::min() );
  // For increment()/decrement(), default value of stack is 1, since expectation when calling these with default value
  // is that the stack count will be adjusted by a single stack, regardless of buff_t::_initial_stack
  virtual void increment( int stacks = 1, double value = DEFAULT_VALUE(), timespan_t duration = timespan_t::min() );
  virtual void decrement( int stacks = 1, double value = DEFAULT_VALUE() );
  virtual void extend_duration( timespan_t seconds );
  virtual void extend_async_duration( timespan_t seconds );
  virtual void extend_duration_or_trigger( timespan_t duration = timespan_t::min() );
  virtual void reschedule_tick( timespan_t delta );

  virtual void start( int stacks = 1, double value = DEFAULT_VALUE(), timespan_t duration = timespan_t::min() );
  virtual void refresh( int stacks = 0, double value = DEFAULT_VALUE(), timespan_t duration = timespan_t::min() );
  virtual void bump( int stacks = 1, double value = DEFAULT_VALUE() );
  virtual void override_buff ( int stacks = 1, double value = DEFAULT_VALUE() );
  virtual bool may_react( int stacks = 1 );
  virtual int stack_react();
  // NOTE: If you need to override behavior on buff expire, use expire_override. Override "expire"
  // method only if you _REALLY_ know what you are doing.
  virtual void expire( timespan_t d = timespan_t::zero() );
  // TODO: are these the same checks and can be combined?
  // check if the action matches the trigger spell's proc flags
  virtual bool can_trigger( action_t* ) const;
  // check if the action matches the buff's proc flags
  virtual bool can_consume( action_t* ) const;
  // trigger the buff only if the action matches the trigger_spell's proc flags
  bool trigger( action_t*, int stacks = -1, double value = DEFAULT_VALUE(), double chance = -1.0,
                timespan_t = timespan_t::min() );
  // remove stacks if the action match the buff's proc flags
  int consume( action_t*, int stacks = -1 );
  // Completely remove the buff, including any delayed applications and expirations.
  void cancel();

  // Called only if previously active buff expires
  virtual void expire_override( int /* expiration_stacks */, timespan_t /* remaining_duration */ ) {}
  virtual void predict();
  virtual void reset();
  virtual void aura_gain();
  virtual void aura_loss();
  virtual void merge( const buff_t& other_buff );
  virtual void analyze();
  virtual void datacollection_begin();
  virtual void datacollection_end();

  virtual timespan_t refresh_duration( timespan_t new_duration ) const;
  virtual timespan_t tick_time() const;

  timespan_t iteration_uptime() const
  { return iteration_uptime_sum; }

#if defined(SC_USE_STAT_CACHE)
  virtual void invalidate_cache();
#else
  void invalidate_cache() {}
#endif

  virtual int total_stack();

  static std::unique_ptr<expr_t> create_expression( util::string_view buff_name,
                                    util::string_view type,
                                    action_t& action );
  static std::unique_ptr<expr_t> create_expression( util::string_view buff_name,
                                    util::string_view type,
                                    buff_t& static_buff );
  std::string to_str() const;

  static double DEFAULT_VALUE() { return -std::numeric_limits< double >::min(); }
  static buff_t* find( util::span<buff_t* const>, util::string_view name, player_t* source = nullptr );
  static buff_t* find( sim_t*, util::string_view name );
  static buff_t* find( player_t*, util::string_view name, player_t* source = nullptr );
  static buff_t* find_expressable( util::span<buff_t* const>, util::string_view name, player_t* source = nullptr );
  static buff_t* make_fallback( player_t* player, std::string_view name, player_t* source = nullptr );

  // If first argument is true, create a buff per normal
  // If first argument is false, add name to fallback buffs and return the generic sim fallback
  // NOTE: this returns a base buff_t* pointer as the generic fallback buff is type buff_t
  template <typename Buff, typename Player, typename... Args>
  static buff_t* make_buff_fallback( bool true_buff, Player&& player, std::string_view name, Args&&... args )
  {
    static_assert( std::is_base_of_v<buff_t, Buff>, "Buff must be derived from buff_t" );
    static_assert( std::is_base_of_v<player_t, std::remove_pointer_t<std::remove_reference_t<Player>>> ||
                   std::is_base_of_v<actor_pair_t, std::remove_reference_t<Player>>,
                   "Player must be derived from player_t or actor_pair_t" );

    if ( true_buff )
    {
      if constexpr ( std::is_constructible_v<Buff, Player, Args...> )
        return new Buff( std::forward<Player>( player ), std::forward<Args>( args )... );
      else
        return new Buff( std::forward<Player>( player ), name, std::forward<Args>( args )... );
    }
    else
    {
      if constexpr ( std::is_base_of_v<actor_pair_t, std::remove_reference_t<Player>> )
        return make_fallback( player.target, name, player.source );
      else
        return make_fallback( player, name, player );
    }
  }

  const char* name() const { return name_str.c_str(); }
  const char* name_reporting() const;
  util::string_view source_name() const;
  int max_stack() const { return _max_stack; }
  int initial_stack() const { return _initial_stack; }
  const spell_data_t* get_trigger_data() const { return trigger_data; }
  double get_dynamic_time_duration_multiplier() const { return dynamic_time_duration_multiplier; };
  double get_time_duration_multiplier() const { return base_time_duration_multiplier * dynamic_time_duration_multiplier; };

  rng::rng_t& rng();
  rng::rng_t& rng() const;

  bool change_regen_rate;
  bool disable_async_expire_events_removal;

  buff_t* set_chance( double chance );
  buff_t* set_duration( timespan_t duration );
  buff_t* modify_duration( timespan_t duration );
  buff_t* set_duration_multiplier( double );
  buff_t* set_dynamic_time_duration_multiplier( double multiplier );
  buff_t* set_max_stack( int max_stack );
  buff_t* modify_max_stack( int max_stack );
  buff_t* increase_max_stack_uptime( int max_stack_uptime );
  buff_t* set_initial_stack( int initial_stack );
  buff_t* modify_initial_stack( int initial_stack );
  buff_t* set_initial_stack_to_max_stack();
  buff_t* set_expire_at_max_stack( bool );
  buff_t* set_consume_all_stacks( bool );
  buff_t* set_cooldown( timespan_t duration );
  buff_t* set_internal_cooldown( timespan_t );
  buff_t* modify_cooldown( timespan_t duration );
  buff_t* set_period( timespan_t );
  buff_t* modify_period( timespan_t );
  buff_t* disable_ticking( bool v );
  //virtual buff_t* set_chance( double chance );
  buff_t* set_quiet( bool quiet );
  buff_t* add_invalidate( cache_e );
  buff_t* set_schools( unsigned );
  buff_t* set_schools_from_effect( size_t );
  buff_t* add_school( school_e );
  // Treat the buff's value as stat % increase and apply it automatically in the relevant player_t functions.
  buff_t* set_pct_buff_type( stat_pct_buff_type );
  buff_t* set_pct_buff_type_from_effect( size_t, bool set_default = false );
  buff_t* set_pct_buff_type_from_data( bool set_default = false );
  // Movement buffs to calculate automatically in the relevant player_t functions.
  buff_t* set_movement_speed_buff( bool stacking, double );
  buff_t* set_movement_speed_buff_from_effect( size_t, double = 0.0 );
  buff_t* set_movement_speed_buff_from_data( double = 0.0 );
  buff_t* set_default_value( double, size_t = 0 );
  virtual buff_t* set_default_value_from_effect( size_t, double = 0.0 );
  virtual buff_t* set_default_value_from_effect_type( effect_subtype_t a_type,
                                                      property_type_t p_type = P_MAX,
                                                      double multiplier      = 0.0,
                                                      effect_type_t e_type   = E_APPLY_AURA );
  buff_t* modify_default_value( double );
  buff_t* set_reverse( bool );
  buff_t* set_activated( bool );
  buff_t* set_can_cancel( bool cc );
  buff_t* set_tick_behavior( buff_tick_behavior );
  buff_t* set_tick_callback( buff_tick_callback_t );
  buff_t* set_tick_time_callback( buff_tick_time_callback_t );
  buff_t* set_affects_regen( bool state );
  buff_t* set_constant_behavior( buff_constant_behavior );
  buff_t* set_refresh_behavior( buff_refresh_behavior );
  buff_t* set_refresh_duration_callback( buff_refresh_duration_callback_t );
  buff_t* set_tick_zero( bool v ) { tick_zero = v; return this; }
  buff_t* set_tick_on_application( bool v ) { tick_on_application = v; return this; }
  buff_t* set_partial_tick( bool v ) { partial_tick = v; return this; }
  buff_t* set_freeze_stacks( bool v ) { freeze_stacks = v; return this; }
  buff_t* set_tick_time_behavior( buff_tick_time_behavior b ) { tick_time_behavior = b; return this; }
  buff_t* set_rppm( rppm_scale_e scale = RPPM_NONE, double freq = -1, double mod = -1);
  buff_t* set_trigger_spell( const spell_data_t* s );
  buff_t* set_proc_callbacks( bool v ) { proc_callbacks = v; return this; }
  buff_t* set_stack_change_callback( const buff_stack_change_callback_t& cb );
  buff_t* add_stack_change_callback( const buff_stack_change_callback_t& cb );
  buff_t* set_expire_callback( const buff_expire_callback_t& cb );
  buff_t* set_reverse_stack_count( int count );
  buff_t* set_stack_behavior( buff_stack_behavior b );
  buff_t* set_allow_precombat( bool b );
  buff_t* set_name_reporting( std::string_view );

  buff_t* apply_time_rate_modifier( const spell_data_t* spell );

  buff_t* set_disable_async_expire_events_removal( bool b );

  friend void sc_format_to( const buff_t&, fmt::format_context::iterator );
private:
  void update_trigger_calculations();
  void adjust_haste();
  void init_haste_type();

protected:
  void update_stack_uptime_array( timespan_t current_time, int old_stacks );
};

struct stat_buff_t : public buff_t
{
  using stat_check_fn = std::function<bool( const stat_buff_t& )>;

  struct buff_stat_t
  {
    stat_e stat;
    double amount;
    double current_value;
    stat_check_fn check_func;

    buff_stat_t( stat_e s, double a, std::function<bool( const stat_buff_t& )> c = nullptr )
      : stat( s ), amount( a ), current_value( 0 ), check_func( std::move( c ) )
    {}
  };

  std::vector<buff_stat_t> stats;
  gain_t* stat_gain;
  bool manual_stats_added;

  virtual double buff_stat_stack_amount( const buff_stat_t&, int stacks ) const;
  void update_player_buff_stat( buff_stat_t&, int stacks );

  void bump     ( int stacks = 1, double value = -1.0 ) override;
  void decrement( int stacks = 1, double value = -1.0 ) override;
  void expire_override( int expiration_stacks, timespan_t remaining_duration ) override;

  stat_buff_t* add_stat( stat_e s, double a, const stat_check_fn& c = stat_check_fn() );
  stat_buff_t* set_stat( stat_e s, double a, const stat_check_fn& c = stat_check_fn() );
  stat_buff_t* add_stat_from_effect( size_t i, double a, const stat_check_fn& c = stat_check_fn() );
  stat_buff_t* set_stat_from_effect( size_t i, double a, const stat_check_fn& c = stat_check_fn() );
  stat_buff_t* add_stat_from_effect_type( effect_subtype_t a_type, double a, const stat_check_fn& c = stat_check_fn() );
  stat_buff_t* set_stat_from_effect_type( effect_subtype_t a_type, double a, const stat_check_fn& c = stat_check_fn() );

  stat_buff_t( actor_pair_t q, util::string_view name );
  stat_buff_t( actor_pair_t q, util::string_view name, const spell_data_t*, const item_t* item = nullptr );

  // floating point compensation before truncating for final amount to apply to player stats
  static constexpr double stat_fp_epsilon = 1e-3;
};

struct absorb_buff_t : public buff_t
{
  using absorb_eligibility = std::function<bool( const action_state_t* )>;
  school_e absorb_school;
  stats_t* absorb_source;
  gain_t*  absorb_gain;
  bool     high_priority;  // For tank absorbs that should explicitly "go first"
  bool     cumulative;     // when true, each refresh() will add to the existing shield value
  absorb_eligibility eligibility; // A custom function whose result determines if the attack is eligible to be absorbed.

  absorb_buff_t( actor_pair_t q, util::string_view name );
  absorb_buff_t( actor_pair_t q, util::string_view name, const spell_data_t* spell, const item_t* item = nullptr );
protected:

  // Hook for derived classes to recieve notification when some of the absorb is consumed.
  // Called after the adjustment to current_value.
  virtual void absorb_used( double, player_t* ) {}

public:
  void start( int stacks = 1, double value = DEFAULT_VALUE(), timespan_t duration = timespan_t::min() ) override;
  void refresh( int stacks = 0, double value = DEFAULT_VALUE(), timespan_t duration = timespan_t::min() ) override;
  void expire_override( int expiration_stacks, timespan_t remaining_duration ) override;

  virtual double consume( double amount, action_state_t* state = nullptr );
  absorb_buff_t* set_absorb_gain( gain_t* );
  absorb_buff_t* set_absorb_source( stats_t* );
  absorb_buff_t* set_absorb_school( school_e );
  absorb_buff_t* set_absorb_high_priority( bool );
  absorb_buff_t* set_absorb_eligibility( absorb_eligibility );
  absorb_buff_t* set_cumulative( bool );
};

struct cost_reduction_buff_t : public buff_t
{
  double amount;
  school_e school;

  cost_reduction_buff_t( actor_pair_t q, util::string_view name) ;
  cost_reduction_buff_t( actor_pair_t q, util::string_view name, const spell_data_t* spell, const item_t* item = nullptr );
  void bump     ( int stacks = 1, double value = -1.0 ) override;
  void decrement( int stacks = 1, double value = -1.0 ) override;
  void expire_override( int expiration_stacks, timespan_t remaining_duration ) override;
  cost_reduction_buff_t* set_reduction(school_e s, double a);
};

struct movement_buff_t : public buff_t
{
  movement_buff_t( player_t* p ) : buff_t( p, "movement" )
  {
    set_max_stack( 1 );
  }

  bool trigger( int stacks, double value, double chance, timespan_t duration ) override;
  void expire_override( int expiration_stacks, timespan_t remaining_duration ) override;
};

struct damage_buff_t : public buff_t
{
  struct damage_buff_modifier_t
  {
    const spell_data_t* s_data = nullptr;
    size_t effect_idx = 0;
    double multiplier = 1.0;
    double initial_multiplier = 1.0;
    std::vector<int> labels;
    std::vector<std::pair<buff_t*, double>> dynamic_buff_multipliers;
  };

  bool is_stacking;
  damage_buff_modifier_t direct_mod;
  damage_buff_modifier_t periodic_mod;
  damage_buff_modifier_t auto_attack_mod;
  damage_buff_modifier_t crit_chance_mod;

  damage_buff_t( actor_pair_t q, util::string_view name );
  damage_buff_t( actor_pair_t q, util::string_view name, const spell_data_t*, bool parse_data = true );
  damage_buff_t( actor_pair_t q, util::string_view name, const spell_data_t*, double );

  damage_buff_t* parse_spell_data( const spell_data_t*, double = 0.0, double = 0.0 );
  damage_buff_t* apply_dynamic_buff_multiplier( buff_t* buff );
  damage_buff_t* apply_mod_affecting_effect( damage_buff_modifier_t&, const spelleffect_data_t& );

  damage_buff_t* set_is_stacking_mod( bool value );
  damage_buff_t* set_direct_mod( double );
  damage_buff_t* set_direct_mod( const spell_data_t*, size_t, double = 0.0, double = 1.0 );
  damage_buff_t* set_periodic_mod( double );
  damage_buff_t* set_periodic_mod( const spell_data_t*, size_t, double = 0.0, double = 1.0 );
  damage_buff_t* set_auto_attack_mod( double );
  damage_buff_t* set_auto_attack_mod( const spell_data_t*, size_t, double = 0.0, double = 1.0 );
  damage_buff_t* set_crit_chance_mod( double );
  damage_buff_t* set_crit_chance_mod( const spell_data_t*, size_t, double = 0.0 );

  bool is_affecting( const spell_data_t* );
  bool is_affecting_direct( const spell_data_t* );
  bool is_affecting_periodic( const spell_data_t* );
  bool is_affecting_crit_chance( const spell_data_t* );

  // Get final mod multiplier, taking into consideration any dynamic buff multipliers
  double get_mod_multiplier( const damage_buff_modifier_t& ) const;

  // Get current direct damage buff multiplier value + benefit tracking.
  double value_direct()
  {
    buff_t::stack();
    return current_stack ? get_mod_multiplier( direct_mod ) : 1.0;
  }

  // Get current direct damage buff multiplier value multiplied by current stacks + benefit tracking.
  double stack_value_direct()
  {
    buff_t::stack();
    return !current_stack ? 1.0 : direct_mod.initial_multiplier + current_stack * ( value_direct() - 1.0 );
  }

  // Get current direct damage buff multiplier value + NO benefit tracking.
  double check_value_direct() const
  { return current_stack ? get_mod_multiplier( direct_mod ) : 1.0; }

  // Get current direct damage buff multiplier value multiplied by current stacks + NO benefit tracking.
  double check_stack_value_direct() const
  { return !current_stack ? 1.0 : direct_mod.initial_multiplier + current_stack * ( check_value_direct() - 1.0 ); }

  // Get current periodic damage buff multiplier value + benefit tracking.
  double value_periodic()
  {
    buff_t::stack();
    return current_stack ? get_mod_multiplier( periodic_mod ) : 1.0;
  }

  // Get current periodic damage buff multiplier value multiplied by current stacks + benefit tracking.
  double stack_value_periodic()
  { return !current_stack ? 1.0 : periodic_mod.initial_multiplier + current_stack * ( value_periodic() - 1.0 ); }

  // Get current periodic damage buff multiplier value + NO benefit tracking.
  double check_value_periodic() const
  { return current_stack ? get_mod_multiplier( periodic_mod ) : 1.0; }

  // Get current periodic damage buff multiplier value multiplied by current stacks + NO benefit tracking.
  double check_stack_value_periodic() const
  { return !current_stack ? 1.0 : periodic_mod.initial_multiplier + current_stack * ( check_value_periodic() - 1.0 ); }

  // Get current AA damage buff multiplier value + benefit tracking.
  double value_auto_attack()
  {
    buff_t::stack();
    return current_stack ? get_mod_multiplier( auto_attack_mod ) : 1.0;
  }

  // Get current AA damage buff multiplier value multiplied by current stacks + benefit tracking.
  double stack_value_auto_attack()
  { return !current_stack ? 1.0 : auto_attack_mod.initial_multiplier + current_stack * ( value_auto_attack() - 1.0 ); }

  // Get current AA damage buff multiplier value + NO benefit tracking.
  double check_value_auto_attack() const
  { return current_stack ? get_mod_multiplier( auto_attack_mod ) : 1.0; }

  // Get current AA damage buff multiplier value multiplied by current stacks + NO benefit tracking.
  double check_stack_value_auto_attack() const
  { return !current_stack ? 1.0 : auto_attack_mod.initial_multiplier + current_stack * ( check_value_auto_attack() - 1.0 ); }

  // Get current additive crit chance buff value + benefit tracking.
  double value_crit_chance()
  {
    buff_t::stack();
    return current_stack ? get_mod_multiplier( crit_chance_mod ) - 1.0 : 0.0;
  }

  // Get current additive crit chance buff value multiplied by current stacks + benefit tracking.
  double stack_value_crit_chance()
  { return current_stack * value_crit_chance(); }

  // Get current additive crit chance buff value + NO benefit tracking.
  double check_value_crit_chance() const
  { return current_stack ? get_mod_multiplier( crit_chance_mod ) - 1.0 : 0.0; }

  // Get current additive crit chance buff value multiplied by current stacks + NO benefit tracking.
  double check_stack_value_crit_chance() const
  { return current_stack * check_value_crit_chance(); }

protected:
  damage_buff_t* set_buff_mod( damage_buff_modifier_t&, double );
  damage_buff_t* set_buff_mod( damage_buff_modifier_t&, const spell_data_t*, size_t, double, double );
};

/**
 * @brief Creates a buff
 *
 * Small helper function to write
 * buff_t* b = make_buff<buff_t>(player, name, spell); instead of
 * buff_t* b = (new buff_t(player, name, spell));
 */
template <typename Buff = buff_t, typename... Args>
inline Buff* make_buff( Args&&... args )
{
  static_assert( std::is_base_of_v<buff_t, Buff>, "Buff must be derived from buff_t" );
  return new Buff( std::forward<Args>( args )... );
}

template <typename Buff = buff_t, typename... Args>
inline buff_t* make_buff_fallback( Args&&... args )
{
  return buff_t::make_buff_fallback<Buff>( std::forward<Args>( args )... );
}
