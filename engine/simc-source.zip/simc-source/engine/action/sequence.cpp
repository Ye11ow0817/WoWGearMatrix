// ==========================================================================
// Dedmonwakeen's DPS-DPM Simulator.
// Send questions to natehieter@gmail.com
// ==========================================================================

#include "sequence.hpp"

#include "player/player.hpp"
#include "sim/option.hpp"
#include "sim/sim.hpp"
#include "util/util.hpp"

// ==========================================================================
// Sequence Action
// ==========================================================================

namespace
{
void parse_actions( player_t* p, std::vector<std::string_view>& splits, std::vector<action_t*>& sub_actions,
                    size_t first = 1 )
{
  for ( auto i = first; i < splits.size(); i++ )
  {
    auto cut_pt = splits[ i ].find( ',' );
    auto action_name = splits[ i ].substr( 0, cut_pt );
    std::string_view action_options;

    if ( cut_pt != std::string_view::npos )
      action_options = splits[ i ].substr( cut_pt + 1 );

    auto a = p->create_action( action_name, action_options );
    if ( !a )
    {
      if ( p->sim->strict_parsing )
      {
        sub_actions.clear();
        return;
      }

      p->sim->error( "{} unknown sequence action '{}', ignoring.", *p, action_name );
      continue;
    }
    else
    {
      a->sequence = true;
      sub_actions.push_back( a );
    }
  }
}
}  // namespace

// sequence_t::sequence_t ===================================================

sequence_t::sequence_t( player_t* p, util::string_view sub_action_str ) :
  action_t( ACTION_SEQUENCE, "default", p ),
  waiting( false ), sequence_wait_on_ready( -1 ),
  current_action( -1 ), restarted( false ), last_restart( timespan_t::min() ), has_option( false )
{
  trigger_gcd = timespan_t::zero();

  auto splits = util::string_split<util::string_view>( sub_action_str, ":" );
  if ( !splits.empty() && splits[ 0 ].find( '=' ) != std::string::npos )
  {
    add_option( opt_string( "name", name_str ) );
    parse_options( splits[ 0 ] );
    has_option = true;
  }

  // Skip first token if it's an option
  parse_actions( p, splits, sub_actions, has_option );

  sequence_wait_on_ready = option.wait_on_ready;
  option.wait_on_ready = -1;
}

// sequence_t::init_finished ================================================

void sequence_t::init_finished()
{
  action_t::init_finished();

  // Clean-up invalid actions
  range::erase_remove( sub_actions, []( action_t* a ) { return a->background; } );

  if ( sub_actions.empty() )
    throw sc_invalid_apl_argument( "Invalid sequence, actions could not be created or no actions found." );
}

// sequence_t::schedule_execute =============================================

void sequence_t::schedule_execute( action_state_t* state )
{
  assert( 0 <= current_action && as<std::size_t>( current_action ) < sub_actions.size() );

  if ( waiting )
  {
    timespan_t available = player->available();

    if ( sim->log )
    {
      sim->print_log( "Player {} is waiting for {:.3f}, since action #{} ({}) is not ready", player->name(),
                      available.total_seconds(), current_action, sub_actions[ current_action ]->name() );
    }

    player->schedule_ready( available, true );
    waiting = false;
    return;
  }

  if ( sim->log )
  {
    sim->print_log( "Player {} executes Schedule {} action #{} '{}'", player->name(), name(), current_action,
                    sub_actions[ current_action ]->name() );
  }

  sub_actions[ current_action++ ]->schedule_execute( state );

  // No longer restarted
  restarted = false;
}

// sequence_t::reset ========================================================

void sequence_t::reset()
{
  action_t::reset();
  /*
    if ( current_action == -1 )
    {
      for ( size_t i = 0; i < sub_actions.size(); ++i )
      {
        if ( sub_actions[ i ] -> wait_on_ready == -1 )
          sub_actions[ i ] -> wait_on_ready = wait_on_ready;
      }
    }
  */
  waiting = false;
  current_action = 0;
  restarted = false;
  last_restart = timespan_t::min();
}

// sequence_t::action_ready =================================================

bool sequence_t::action_ready()
{
  if ( sub_actions.empty() || current_action >= as<int>( sub_actions.size() ) || !action_t::action_ready() )
    return false;

  for ( int num_sub_actions = as<int>( sub_actions.size() ); current_action < num_sub_actions; ++current_action )
  {
    action_t* a = sub_actions[ current_action ];

    if ( a->action_ready() )
      return true;

    // If the sequence is flagged wait_on_ready, we'll wait for available()
    // amount of time, but do not proceed further in the action list, nor
    // in the sequence
    if ( sequence_wait_on_ready == 1 )
    {
      waiting = true;
      return true;
    }
  }

  return false;
}

bool sequence_t::ready()
{
  return !sub_actions.empty() && current_action < as<int>( sub_actions.size() ) && action_t::ready() &&
         sub_actions[ current_action ]->ready();
}

bool sequence_t::target_ready( player_t* t )
{
  return !sub_actions.empty() && current_action < as<int>( sub_actions.size() ) && action_t::target_ready( t ) &&
         sub_actions[ current_action ]->target_ready( t );
}

// sequence_t::sequence_add_fn ==============================================

void sequence_t::sequence_add_fn( std::string& a_str, std::string& t_str ) const
{
  // current_action is advanced in schedule_execute so we need to use current_action - 1
  auto _idx = current_action - 1;
  a_str = fmt::format( "</b>SEQ {}[{}]<br><b>{}", name_str, _idx, sub_actions[ _idx ]->name_str );
  t_str = target->name_str;
}

// ==========================================================================
// Strict Sequence Action
// ==========================================================================

strict_sequence_t::strict_sequence_t( player_t* p, util::string_view options )
  : action_t( ACTION_SEQUENCE, "strict_sequence", p ), current_action( 0 ), allow_skip( false )
{
  trigger_gcd = timespan_t::zero();

  auto splits = util::string_split<util::string_view>( options, ":" );
  if ( ! splits.empty() )
  {
    add_option( opt_bool( "allow_skip", allow_skip ) );
    add_option( opt_string( "name", seq_name_str ) );
    parse_options( splits[ 0 ] );
  }

  parse_actions( p, splits, sub_actions );
}

void strict_sequence_t::init_finished()
{
  action_t::init_finished();

  // Clean-up invalid actions
  range::erase_remove( sub_actions, []( action_t* a ) { return a->background; } );

  if ( sub_actions.empty() )
    throw sc_invalid_apl_argument( "Invalid strict sequence, actions could not be created or no actions found." );
}

void strict_sequence_t::cancel()
{
  action_t::cancel();

  if ( player -> strict_sequence == this )
    player -> strict_sequence = nullptr;

  current_action = 0;
}

void strict_sequence_t::reset()
{
  action_t::reset();

  if ( player -> strict_sequence == this )
    player -> strict_sequence = nullptr;

  current_action = 0;
}

void strict_sequence_t::interrupt_action()
{
  action_t::interrupt_action();

  if ( player -> strict_sequence == this )
    player -> strict_sequence = nullptr;

  current_action = 0;
}

bool strict_sequence_t::ready()
{
  if ( sub_actions.empty() ) return false;
  if ( ! action_t::ready() ) return false;

  // Strict sequences need all actions to be usable before it commits
  if ( ! allow_skip )
  {
    for (auto & elem : sub_actions)
    {
      if ( ! elem -> ready() )
        return false;
    }

    return true;
  }
  else
  { 
    // Ready if at least one action is usable
    return range::any_of( sub_actions, []( action_t* a ) {
        return ! a -> background && a -> ready();
    } );
  }
}

void strict_sequence_t::schedule_execute( action_state_t* state )
{
  assert( ( current_action == 0 && ! player -> strict_sequence ) ||
          ( current_action < sub_actions.size() && player -> strict_sequence ) );
  // Check that we're not discarding the state since we cannot give it to queue_execute.
  (void)state; assert( ! state );

  if ( current_action == 0 )
    player -> strict_sequence = this;

  bool scheduled = false;
  if ( ! allow_skip )
  {
    if ( sim -> log )
      sim -> out_log.print( "{} executes strict_sequence '{}' action #{} \"{}\"",
                     *player, seq_name_str, current_action, sub_actions[ current_action ] -> name() );

    // Sanity check the strict sequence, so that it does not get stuck
    // mid-sequence. People are expected to write strict_sequences that cannot
    // have this happen, but it's bound to be a problem if some buff for example
    // fades between the first, and last cast (and it's needed by the last cast).
    if ( ! sub_actions[ current_action ] -> ready() )
    {
      if ( sim -> debug )
        sim -> out_debug.print( "{} strict_sequence '{}' action #{} \"{}\" is no longer ready, aborting sequence",
          *player, seq_name_str, current_action, sub_actions[ current_action ] -> name() );
      cancel();
      return;
    }

    sub_actions[ current_action++ ] -> queue_execute( execute_type::FOREGROUND );
    scheduled = true;
  }
  else
  {
    // Allow skipping of unusable actions
    while ( current_action < sub_actions.size() &&
            ! sub_actions[ current_action ] -> background &&
            ! sub_actions[ current_action ] -> ready() )
    {
      if ( sim -> debug )
      {
        sim -> out_debug.print( "{} strict_sequence '{}' action #{} \"{}\" is not ready, skipping... ",
          *player, seq_name_str, current_action, sub_actions[ current_action ] -> name() );
      }
      current_action++;
    }

    if ( current_action < sub_actions.size() )
    {
      sim -> print_log( "{} executes strict_sequence '{}' action #{} \"{}\"",
                       *player, seq_name_str, current_action, sub_actions[ current_action ] -> name() );

      player->sequence_add( sub_actions[ current_action ], sub_actions[ current_action ]->target );
      sub_actions[ current_action++ ]->queue_execute( execute_type::FOREGROUND );
      scheduled = true;
    }
  }

  // Strict sequence is over, normal APL commences on the next ready event
  if ( current_action == sub_actions.size() )
  {
    sim -> print_debug( "{} strict_sequence '{}' end reached, strict sequence over",
        *player, seq_name_str );
    player -> strict_sequence = nullptr;
    current_action = 0;

    // If nothing to scheduled, the skippable strict sequence finished and went to the end. Player
    // ready event must be re-kicked so that the actor will not freeze.
    if ( ! scheduled )
    {
      player -> schedule_ready();
    }
  }
}

void sequence_t::restart() { current_action = 0; restarted = true; last_restart = sim->current_time(); }

bool sequence_t::can_restart()
{
  return !restarted && last_restart < sim->current_time();
}
