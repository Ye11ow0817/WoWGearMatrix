// ==========================================================================
// Dedmonwakeen's Raid DPS/TPS Simulator.
// Send questions to natehieter@gmail.com
// ==========================================================================

#ifndef SC_REPORT_HPP
#define SC_REPORT_HPP

#include "config.hpp"

#include "reports.hpp"
#include "sc_enums.hpp"
#include "util/chrono.hpp"
#include "util/util.hpp"

#include <array>
#include <iosfwd>

struct player_t;
struct action_t;
struct buff_t;
struct item_t;
struct xml_node_t;
struct sc_timeline_t;
struct spell_data_t;
class extended_sample_data_t;
struct player_processed_report_information_t;
struct sim_report_information_t;
struct stats_t;

// Report helpers
namespace report_helper
{
void print_html_sample_data( report::sc_html_stream&, const player_t&, const extended_sample_data_t&,
                             const std::string& name, int columns = 1 );

bool output_scale_factors( const player_t* p );

void generate_player_charts( player_t&, player_processed_report_information_t& );
void generate_player_buff_lists( player_t&, player_processed_report_information_t& );
std::vector<std::string> beta_warnings();
std::string pretty_spell_text( const spell_data_t& default_spell, const std::string& text, const player_t& p );
inline std::string pretty_spell_text( const spell_data_t& default_spell, const char* text, const player_t& p )
{ return text ? pretty_spell_text( default_spell, std::string( text ), p ) : std::string(); }

bool check_gear( player_t& p, sim_t& sim );

void print_distribution_chart( report::sc_html_stream& os, const player_t& p, extended_sample_data_t* data,
                               std::string_view name, std::string_view token, std::string_view suffix,
                               bool time_element = false );

void collect_aps( const stats_t* stats, double& amount, double& amount_pct );

const spell_data_t* find_talent_spell( std::string_view name, const player_t& );
const spell_data_t* find_talent_spell( unsigned spell_id, const player_t& );
}  // namespace report_helper

#endif  // SC_REPORT_HPP
