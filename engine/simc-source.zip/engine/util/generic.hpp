// ==========================================================================
// Dedmonwakeen's Raid DPS/TPS Simulator.
// Send questions to natehieter@gmail.com
// ==========================================================================

// ==========================================================================
// Collection of generic programming code
// ==========================================================================

#ifndef SC_GENERIC_HPP
#define SC_GENERIC_HPP

#include "config.hpp"

#include <algorithm>
#include <cassert>
#include <cmath>
#include <functional>
#include <type_traits>

// iterable enumeration templates ===========================================

/*
 * Enumeration types in C++ implicitly convert to int but not from int (e.g.,
 * "for ( attribute_e i = ATTR_STRENGTH; i < ATTR_MAX; ++i )" won't compile).
 * This is why so much of the code uses int when it really means an enum type.
 * Providing the kind of operations we want to use for enums lets us tighten up
 * our use of the type system and avoid accidentally passing some other thing
 * that converts to int when we really mean an enumeration type.
 *
 * The template functions tell the compiler it can perform prefix and postfix
 * operators ++ and -- on any type by converting it to int and back. The magic
 * with std::enable_if<> restricts those operations to types T for which the
 * type trait "is_iterable_enum<T>" is true. This trait gives us a way to
 * selectively control the functionality for a specific type T by specializing
 * is_iterable_enum<T> as std::true_type or std::false_type.
 */

// All enumerations are iterable by default.
template <typename T>
struct is_iterable_enum : public std::is_enum<T>
{
};

template <typename T>
inline std::enable_if_t<is_iterable_enum<T>::value, T&> operator--( T& s )
{
  return s = static_cast<T>( static_cast<std::underlying_type_t<T>>(s) - 1 );
}

template <typename T>
inline std::enable_if_t<is_iterable_enum<T>::value, T> operator--( T& s, int )
{
  T tmp = s;
  --s;
  return tmp;
}

template <typename T>
inline std::enable_if_t<is_iterable_enum<T>::value, T&> operator++( T& s )
{
  return s = static_cast<T>( static_cast<std::underlying_type_t<T>>(s) + 1 );
}

template <typename T>
inline std::enable_if_t<is_iterable_enum<T>::value, T> operator++( T& s, int )
{
  T tmp = s;
  ++s;
  return tmp;
}

// Generic programming tools ================================================

/**
 * @brief helper class to make a class non-copyable
 *
 * To make your class A non-copyable, define it as such:
 * class A : private noncopyable {}
 */
class noncopyable
{
protected:
  noncopyable() = default;
  noncopyable( noncopyable&& ) = default;
  noncopyable& operator=( noncopyable&& ) = default;

  noncopyable( const noncopyable& ) = delete; // NOLINT(modernize-use-equals-delete)
  noncopyable& operator=( const noncopyable& ) = delete; // NOLINT(modernize-use-equals-delete)
};

/**
 * @brief helper class to make a class non-moveable
 *
 * To make your class A non-moveable, define it as such:
 * class A : private nonmoveable {}
 */
class nonmoveable : private noncopyable
{
protected:
  nonmoveable()                = default;
  nonmoveable( nonmoveable&& ) = delete; // NOLINT(modernize-use-equals-delete)
  nonmoveable& operator=( nonmoveable&& ) = delete; // NOLINT(modernize-use-equals-delete)
};

// Adapted from (read "stolen") boost::checked_deleter
struct delete_disposer_t
{
  template <typename T>
  void operator()( T* t ) const
  {
    using force_T_to_be_complete = int[ sizeof( T ) ? 1 : -1 ]; // NOLINT(modernize-avoid-c-arrays)
    (void)sizeof( force_T_to_be_complete );
    delete t;
  }
};

// Generic algorithms =======================================================

template <typename I, typename D>
void dispose( I first, I last, D disposer )
{
  while ( first != last )
    disposer( *first++ );
}

template <typename I>
inline void dispose( I first, I last )
{
  dispose( first, last, delete_disposer_t() );
}

// Machinery for range-based generic algorithms =============================

namespace range
{  // ========================================================
namespace detail {

struct begin_ {
  template <typename R>
  auto operator()( R&& r ) const {
    using std::begin;
    return begin( std::forward<R>( r ) );
  }
  template <typename T>
  auto operator()( const std::pair<T, T>& p ) const {
    return p.first;
  }
};

struct end_ {
  template <typename R>
  auto operator()( R&& r ) const {
    using std::end;
    return end( std::forward<R>( r ) );
  }
  template <typename T>
  auto operator()( const std::pair<T, T>& p ) const {
    return p.second;
  }
};

} // namespace detail

template <typename T>
auto begin( T&& t )
{
  return detail::begin_{}( std::forward<T>( t ) );
}

template <typename T>
auto cbegin( const T& t )
{
  return range::begin( t );
}

template <typename T>
auto end( T&& t )
{
  return detail::end_{}( std::forward<T>( t ) );
}

template <typename T>
auto cend( const T& t )
{
  return range::end( t );
}

template <typename R>
using iterator_t = decltype(range::begin(std::declval<R&>()));

template <typename R>
using value_type_t = typename std::iterator_traits<iterator_t<R>>::value_type;

template <typename R>
using reference_type_t = typename std::iterator_traits<iterator_t<R>>::reference;

// Default projection for projection-enabled algorithms =====================

struct identity {
  template <typename T>
  constexpr T&& operator()(T&& value) const noexcept {
    return std::forward<T>(value);
  }
  using is_transparent = std::true_type;
};

// Range-based generic algorithms ===========================================

template <typename Range, typename Out>
inline Out copy( const Range& r, Out o )
{
  return std::copy( range::begin( r ), range::end( r ), o );
}

template <typename Range, typename Out, typename UnaryPredicate>
inline Out copy_if( const Range& r, Out o, UnaryPredicate pred )
{
  return std::copy_if( range::begin( r ), range::end( r ), o, pred );
}

template <typename Range, typename D>
inline Range& dispose( Range& r, D disposer )
{
  dispose( range::begin( r ), range::end( r ), disposer );
  return r;
}

template <typename Range>
inline Range& dispose( Range& r )
{
  return dispose( r, delete_disposer_t() );
}

template <typename Range>
inline Range& fill( Range& r, value_type_t<Range> const& t )
{
  std::fill( range::begin( r ), range::end( r ), t );
  return r;
}

template <typename Range, typename T, typename Proj = identity,
          typename U = decltype( std::declval<T&&>() + std::declval<std::invoke_result_t<Proj, reference_type_t<Range>>>() )>
auto accumulate( Range&& r, T init, Proj proj = {} ) -> U
{
  auto first = range::begin( r );
  auto last = range::end( r );

  U accum = std::move( init );
  for ( ; first != last; ++first )
    accum = std::move( accum ) + std::invoke( proj, *first );
  return accum;
}

#if defined( SC_GCC )
// Workaround for GCC 4.6+ optimization ( -O3 ) issue with filling C-arrays
template <typename T, size_t N>
inline T ( &fill( T ( &r )[ N ], const T& t ) )[ N ]
{
  for ( size_t i = 0; i < N; ++i )
  {
    r[ i ] = t;
  }
  return r;
}
#endif

template <typename Range, typename T,
          typename Enable = decltype( std::declval<reference_type_t<Range>>() == std::declval<const T&>() )>
inline iterator_t<Range> find( Range& r, T const& t )
{
  return std::find( range::begin( r ), range::end( r ), t );
}

template <typename Range, typename T, typename Proj,
          typename Enable = decltype( std::declval<std::invoke_result_t<Proj, reference_type_t<Range>>>() == std::declval<const T&>() )>
inline iterator_t<Range> find( Range& r, T const& value, Proj proj )
{
  const auto pred = [&value, &proj]( auto&& v ) {
    return std::invoke( proj, std::forward<decltype(v)>( v ) ) == value;
  };
  return std::find_if( range::begin( r ), range::end( r ), pred );
}

template <typename Range, typename UnaryPredicate>
inline iterator_t<Range> find_if( Range& r, UnaryPredicate p )
{
  return std::find_if( range::begin( r ), range::end( r ), p );
}

template <typename Range, typename UnaryPredicate>
inline bool any_of( Range&& r, UnaryPredicate p )
{
  return std::any_of( range::begin( r ), range::end( r ), p );
}

template <typename Range, typename UnaryPredicate>
inline bool all_of( Range&& r, UnaryPredicate p )
{
  return std::all_of( range::begin( r ), range::end( r ), p );
}

/**
 * Check if a value is contained in a range
 *
 * Equal to std::any_of with equality predicate, or std::find with checking for end of range.
 */
template <typename Range, typename Value, typename Proj = identity>
inline bool contains( Range&& r, const Value& v, Proj proj = Proj{} )
{
  return range::find( r, v, proj ) != range::end( r );
}

template <typename Range, typename F>
inline F for_each( Range&& r, F f )
{
  std::for_each( range::begin( r ), range::end( r ),
                 [ &f ]( auto&& v ) { std::invoke( f, std::forward<decltype(v)>( v ) ); } );
  return f;
}

template <typename Range, typename Out, typename Predicate>
inline Out remove_copy_if( Range& r, Out o, Predicate p )
{
  return std::remove_copy_if( range::begin( r ), range::end( r ), o, p );
}

template <typename Range, typename Out, typename F>
Out transform( Range&& r, Out o, F op )
{
  return std::transform( range::begin( r ), range::end( r ), o,
                         [ &op ]( auto&& v ) { return std::invoke( op, std::forward<decltype(v)>( v ) ); } );
}

template <typename Range, typename Range2, typename Out, typename F>
Out transform( Range&& r, Range2&& r2, Out o, F op_ )
{
  const auto op = [ &op_ ] ( auto&& l, auto&& r ) {
    return std::invoke( op_, std::forward<decltype(l)>( l ), std::forward<decltype(r)>( r ) );
  };
  return std::transform( range::begin( r ), range::end( r ), range::begin( r2 ), o, op );
}

template <typename Range, typename F>
inline iterator_t<Range> transform_self( Range& r, F f )
{
  return std::transform( range::begin( r ), range::end( r ), range::begin( r ),
                         f );
}

template <typename Range1, typename Range2, typename Out>
inline Out set_difference( const Range1& left, const Range2& right, Out o )
{
  return std::set_difference( range::begin( left ), range::end( left ),
                              range::begin( right ), range::end( right ), o );
}

template <typename Range1, typename Range2, typename Out, typename Compare>
inline Out set_difference( const Range1& left, const Range2& right, Out o,
                           Compare c )
{
  return std::set_difference( range::begin( left ), range::end( left ),
                              range::begin( right ), range::end( right ), o,
                              c );
}

template <typename Range1, typename Range2, typename Out>
inline Out set_intersection( const Range1& left, const Range2& right, Out o )
{
  return std::set_intersection( range::begin( left ), range::end( left ),
                                range::begin( right ), range::end( right ), o );
}

template <typename Range1, typename Range2, typename Out, typename Compare>
inline Out set_intersection( const Range1& left, const Range2& right, Out o,
                             Compare c )
{
  return std::set_intersection( range::begin( left ), range::end( left ),
                                range::begin( right ), range::end( right ), o,
                                c );
}

template <typename Range1, typename Range2, typename Out>
inline Out set_union( const Range1& left, const Range2& right, Out o )
{
  return std::set_union( range::begin( left ), range::end( left ),
                         range::begin( right ), range::end( right ), o );
}

template <typename Range1, typename Range2, typename Out, typename Compare>
inline Out set_union( const Range1& left, const Range2& right, Out o,
                      Compare c )
{
  return std::set_union( range::begin( left ), range::end( left ),
                         range::begin( right ), range::end( right ), o, c );
}

template <typename Range>
inline Range& sort( Range& r )
{
  std::sort( range::begin( r ), range::end( r ) );
  return r;
}

template <typename Range, typename Comp>
inline Range& sort( Range& r, Comp c )
{
  std::sort( range::begin( r ), range::end( r ), c );
  return r;
}

template <typename Range>
inline iterator_t<Range> unique( Range& r )
{
  return std::unique( range::begin( r ), range::end( r ) );
}

template <typename Range, typename Comp>
inline iterator_t<Range> unique( Range& r, Comp c )
{
  return std::unique( range::begin( r ), range::end( r ), c );
}

template <typename Range>
inline iterator_t<Range> max_element( Range& r )
{
  return std::max_element( range::begin( r ), range::end( r ) );
}

template <typename Range>
inline iterator_t<Range> min_element( Range& r )
{
  return std::min_element( range::begin( r ), range::end( r ) );
}

template <typename Range1, typename Range2>
inline void append( Range1& destination, Range2&& source )
{
  destination.insert( destination.end(), source.begin(), source.end() );
}

template <typename Range, typename Predicate>
inline auto count_if( Range&& r, Predicate p ) -> typename std::iterator_traits<decltype(range::begin( r ))>::difference_type
{
  return std::count_if( range::begin( r ), range::end( r ), p );
}

template <typename Range, typename T, typename Compare = std::less<>, typename Proj = identity>
iterator_t<Range> lower_bound( Range& r, const T& value, Compare comp = Compare{}, Proj proj = Proj{} )
{
  const auto pred = [&value, &proj, &comp]( auto&& v ) {
    return std::invoke( comp, std::invoke( proj, std::forward<decltype(v)>( v ) ), value );
  };
  return std::partition_point( range::begin( r ), range::end( r ), pred );
}

template <typename Range, typename T, typename Compare = std::less<>, typename Proj = identity>
iterator_t<Range> upper_bound( Range& r, const T& value, Compare comp = Compare{}, Proj proj = Proj{} )
{
  const auto pred = [&value, &proj, &comp]( auto&& v ) {
    return !std::invoke( comp, value, std::invoke( proj, std::forward<decltype(v)>( v ) ) );
  };
  return std::partition_point( range::begin( r ), range::end( r ), pred );
}

template <typename Range, typename T, typename Compare = std::less<>, typename Proj = identity>
std::pair<iterator_t<Range>, iterator_t<Range>>
  equal_range( Range& r, const T& value, Compare comp = Compare{}, Proj proj = Proj{} )
{
  auto b = lower_bound( r, value, comp, proj );
  if ( b == range::end( r ) )
    return { b, b };
  return { b, upper_bound( r, value, comp, proj ) };
}

template <typename Range, typename Pred, typename Proj = identity>
iterator_t<Range> partition( Range& r, Pred pred_, Proj proj = Proj{} )
{
  auto pred = [&pred_, &proj]( auto&& v ) -> bool {
    return std::invoke( pred_, std::invoke( proj, std::forward<decltype(v)>( v ) ) );
  };
  return std::partition( range::begin( r ), range::end( r ), pred );
}

template <typename Range>
inline void erase_remove( Range& r, value_type_t<Range> const& t )
{
  r.erase( std::remove( range::begin( r ), range::end( r ), t ), range::end( r ) );
}

template <typename Range, typename Pred, typename = std::invoke_result_t<Pred, value_type_t<Range>>>
inline void erase_remove( Range& r, Pred p )
{
  r.erase( std::remove_if( range::begin( r ), range::end( r ), p ), range::end( r ) );
}

}  // namespace range ========================================================

// Adapter for container of owned pointers; automatically deletes the
// pointers on destruction.
template <typename Container>
class auto_dispose : public Container
{
private:
  void dispose_()
  {
    range::dispose( *this );
  }

public:
  ~auto_dispose()
  {
    dispose_();
  }
  void dispose()
  {
    dispose_();
    Container::clear();
  }
};

/**
 * Fancy type-casting function to use when we "know" what type an object pointer
 * really is. Makes sure we are right when debugging.
 */
template <typename To, typename From>
inline To debug_cast( From* ptr )
{
#ifdef NDEBUG
  return static_cast<To>( ptr );
#else
  To result = dynamic_cast<To>( ptr );
  if ( ptr )
    assert( result );
  return result;
#endif
}

/**
 * Fancy type-casting function to convert between types of different size and
 * signedness.
 * When debugging, verifies that the value is representable by both types.
 */
template <typename To, typename From>
inline To as( From f )
{
  To t = static_cast<To>( f );
  // Casting between arithmetic types
  static_assert( std::is_arithmetic_v<To>, "Output type is not arithmetic." );
  static_assert( std::is_arithmetic_v<From>, "Input type is not arithmetic." );
  // is "safe" if (a) it's reversible, and
  assert( f == static_cast<From>( t ) );
  // (b) both values have the same sign.
  assert( ( From() < f ) == ( To() < t ) );
  return t;
}

template <typename T>
inline T clamp( T value, T low, T high )
{
  assert( !( high < low ) );
  return ( value < low ? low : ( high < value ? high : value ) );
}

/**
 * Remove in O(1) by copying the last element over the element to be
 * erased and shrinking the sequence. DOES NOT PRESERVE ELEMENT ORDERING.
 */
template <typename Sequence>
void erase_unordered( Sequence& s, typename Sequence::iterator pos )
{
  assert( !s.empty() && pos != s.end() );
  typename Sequence::iterator last = s.end();
  --last;
  if ( pos != last )
    *pos = *last;  // *pos = std::move( *last );
  s.pop_back();
}

// Experimental propagate_const class, which preserves constness for class
// member pointers, as if they were value/reference types.
// Source: http://en.cppreference.com/w/cpp/experimental/propagate_const ,
// simplified adaption by scamille@2017-03-15
template <class T>
class propagate_const
{
public:
  using element_type =
      std::remove_reference_t<decltype( *std::declval<T&>() )>;

  propagate_const() = default;

  propagate_const( const propagate_const& p ) = delete;

  //propagate_const( propagate_const&& p ) = default;

  template <typename U>
  propagate_const( U&& u ) : _M_t( std::forward<U>( u ) )
  {
  }

  explicit operator bool() const
  {
    return static_cast<bool>( _M_t );
  }

  const element_type* operator->() const
  {
    return this->get();
  }

  operator const element_type*() const
  {
    return this->get();
  }

  const element_type& operator*() const
  {
    return *this->get();
  }

  const element_type* get() const
  {
    return _M_t;
  }

  element_type*& get_ref()
  {
    return _M_t;
  }

  // [propagate_const.non_const_observers], non-const observers

  element_type* operator->()
  {
    return this->get();
  }

  operator element_type*()
  {
    return this->get();
  }

  element_type& operator*()
  {
    return *this->get();
  }

  element_type* get()
  {
    return _M_t;
  }

  template <typename U>
  propagate_const& operator=( U&& u )
  {
    this->_M_t = std::forward<U>( u );
    return *this;
  }

private:
  T _M_t;  // exposition only
};

// workaround to allow static_assert( false ) for if constexpr branches
template <typename>
static constexpr bool static_false = false;

// std::experimental::is_detected implementation based on
// https://en.cppreference.com/w/cpp/experimental/is_detected and
// https://en.cppreference.com/w/cpp/experimental/nonesuch
template <class Default, class AlwaysVoid, template <class...> class Op, class... Args>
struct static_detector
{ using value_t = std::false_type; using type = Default; };

template <class Default, template <class...> class Op, class... Args>
struct static_detector<Default, std::void_t<Op<Args...>>, Op, Args...>
{ using value_t = std::true_type; using type = Op<Args...>; };

struct nonesuch
{ ~nonesuch() = delete; nonesuch( const nonesuch& ) = delete; void operator=( const nonesuch& ) = delete; };

template <template <class...> class Op, class... Args>
using is_detected = typename static_detector<nonesuch, void, Op, Args...>::value_t;

template <template <class...> class Op, class... Args>
constexpr inline bool is_detected_v = is_detected<Op, Args...>::value;

template <template <class...> class Op, class... Args>
using detected_t = typename static_detector<nonesuch, void, Op, Args...>::type;

template <class Default, template <class...> class Op, class... Args>
using detected_or = static_detector<Default, void, Op, Args...>;

#endif  // SC_GENERIC_HPP
