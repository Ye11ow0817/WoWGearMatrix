// ==========================================================================
// Dedmonwakeen's DPS-DPM Simulator.
// Send questions to natehieter@gmail.com
// ==========================================================================

#include "buff.hpp"

#include "action/action.hpp"
#include "action/action_state.hpp"
#include "dbc/dbc.hpp"
#include "dbc/item_database.hpp"
#include "dbc/spell_data.hpp"
#include "player/player.hpp"
#include "player/stats.hpp"
#include "player/target_specific.hpp"
#include "sim/cooldown.hpp"
#include "sim/event.hpp"
#include "sim/expressions.hpp"
#include "sim/proc_rng.hpp"
#include "sim/sim.hpp"
#include "util/rng.hpp"

#include <sstream>
#include <utility>

namespace
{  // UNNAMED NAMESPACE

struct buff_expr_t : public expr_t
{
  std::string buff_name;
  action_t* action;
  buff_t* static_buff;
  target_specific_t<buff_t> specific_buff;

  buff_expr_t( util::string_view n, util::string_view bn, action_t* a, buff_t* b )
    : expr_t( get_full_expression_name( n, bn ) ), buff_name( bn ), action( a ),
    static_buff( b ), specific_buff( false )
  {
  }

  virtual buff_t* create() const
  {
    assert( action && "Cannot create dynamic buff expressions without a action." );

    player_t* target = action->get_expression_target();
    action->player->get_target_data( target );
    auto buff = buff_t::find( target, buff_name, action->player );
    if ( !buff )
      buff = buff_t::find( target, buff_name, target );  // Raid debuffs

    if ( !buff )
    {
      throw sc_invalid_apl_argument( fmt::format(
        "Unable to build buff action expression for {}, reference to unknown buff/debuff '{}'.", *action, buff_name ) );
    }

    return buff;
  }

#if !defined( NDEBUG )
  static std::string get_full_expression_name( util::string_view expr, util::string_view buff_name )
  {
    return fmt::format( "{}_{}", buff_name, expr );
  }
#else
  static util::string_view get_full_expression_name( util::string_view expr, util::string_view /* buff_name */ )
  {
    return expr;
  }
#endif

  buff_t* buff() const
  {
    if ( static_buff )
      return static_buff;

    player_t* target = action->get_expression_target();
    buff_t*& buff = specific_buff[ target ];
    if ( !buff )
    {
      buff = create();
    }
    return buff;
  }

  bool is_constant() override
  {
    return buff()->s_data != spell_data_t::nil() && !buff()->s_data->ok();
  }
};

template <typename Fn>
struct fn_buff_expr_t final : public buff_expr_t
{
  Fn fn;

  template <typename T = Fn>
  fn_buff_expr_t( util::string_view n, util::string_view bn, action_t* a, buff_t* b, T&& fn )
    : buff_expr_t( n, bn, a, b ), fn( std::forward<T>( fn ) )
  { }

  double evaluate() override
  {
    return coerce( fn( buff() ) );
  }
};

template <typename Fn, typename K>
struct fn_const_buff_expr_t final : public buff_expr_t
{
  Fn fn;
  K is_const_fn;

  template <typename T = Fn, typename U = K>
  fn_const_buff_expr_t( util::string_view n, util::string_view bn, action_t* a, buff_t* b, T&& fn, U&& is_const_fn )
    : buff_expr_t( n, bn, a, b ), fn( std::forward<T>( fn ) ), is_const_fn( std::forward<U>( is_const_fn ) )
  { }

  double evaluate() override
  {
    return coerce( fn( buff() ) );
  }

  bool is_constant() override
  {
    return is_const_fn( buff() );
  }
};

struct buff_event_t : public event_t
{
  buff_t* buff;

  buff_event_t( buff_t* b, timespan_t d ) : event_t( *b->sim, d ), buff( b )
  {
  }
};

struct react_ready_trigger_t : public buff_event_t
{
  unsigned stack;

  react_ready_trigger_t( buff_t* b, unsigned s, timespan_t d ) : buff_event_t( b, d ), stack( s )
  {
  }

  const char* name() const override
  {
    return "react_ready_trigger";
  }

  void execute() override
  {
    buff->stack_react_ready_triggers[ stack ] = nullptr;

    if ( buff->player )
      buff->player->trigger_ready();
  }
};

struct tick_t : public buff_event_t
{
  double current_value;
  int current_stacks;
  timespan_t tick_time, start_time;

  tick_t( buff_t* b, timespan_t d, double value, int stacks )
    : buff_event_t( b, d ), current_value( value ), current_stacks( stacks ), tick_time( d ),
      start_time( b->sim->current_time() )
  { }

  const char* name() const override
  { return "buff_tick"; }

  void execute() override
  {
    buff->tick_event = nullptr;

    if ( !buff->disable_tick_effects )
    {
      buff->current_tick++;

      int total_ticks =
          buff->expiration.empty() ? -1 : buff->current_tick + static_cast<int>( buff->remains() / buff->tick_time() );

      if ( buff->partial_tick && ( buff->buff_duration().total_millis() % buff->tick_time().total_millis() ) != 0 )
      {
        total_ticks++;
      }

      buff->sim->print_debug( "{} {} ticks ({} of {}).", *buff->player, *buff, buff->current_tick, total_ticks );

      // Tick callback is called before the aura stack count is altered to ensure
      // that the buff is always up during the "tick". Last tick detection can be
      // made through the int arguments passed to the function call.
      if ( buff->tick_callback )
      {
        buff->tick_callback( buff, total_ticks, tick_time );
      }

      if ( !buff->freeze_stacks )
      {
        if ( !buff->reverse )
        {
          buff->bump( current_stacks, current_value );
        }
        else
        {
          buff->decrement( current_stacks, current_value );
        }
      }
    }

    timespan_t period = buff->tick_time();
    // Unconditionally schedule the tick, expiration event will handle the "final tick"
    if ( buff->current_stack > 0 && ( buff->remains() > 0_ms || buff->remains() == timespan_t::min() ) )
    {
      buff->tick_event = make_event<tick_t>( *buff->sim, buff, period, current_value, current_stacks );
    }
  }
};

struct expiration_t : public buff_event_t
{
  unsigned stack;

  expiration_t( buff_t* b, unsigned s, timespan_t d ) : buff_event_t( b, d ), stack( s )
  {}

  expiration_t( buff_t* b, timespan_t d ) : buff_event_t( b, d ), stack( 0 )
  {
    if ( b->stack_behavior == buff_stack_behavior::ASYNCHRONOUS )
    {
      throw sc_runtime_error(
        fmt::format( "{} {} creates asynchronous expiration with no stack count.", *buff->player, *buff ) );
    }
  }

  const char* name() const override
  { return "buff_expiration"; }

  void execute() override
  {
    assert( !buff->expiration.empty() );
    assert( *buff->expiration.begin() == this );

    // For non-async buffs, this is always unconditionally the "last tick" since we expire the buff
    auto last_tick = buff->stack_behavior != buff_stack_behavior::ASYNCHRONOUS ||
      ( buff->stack_behavior == buff_stack_behavior::ASYNCHRONOUS && buff->current_stack == 1 );
    auto actual_tick_time = 0_ms;
    tick_t* tick_event = nullptr;
    if ( buff->tick_event )
    {
      tick_event = debug_cast<tick_t*>( buff->tick_event );
      actual_tick_time = sim().current_time() - tick_event->start_time;
    }

    bool can_tick = tick_event && !buff->disable_tick_effects &&
      ( ( buff->partial_tick && actual_tick_time > 0_ms ) ||
        ( !buff->partial_tick && tick_event->tick_time == actual_tick_time ) );

    if ( last_tick && can_tick )
    {
      buff->current_tick++;
      buff->sim->print_debug( "{} {} ticks ({} of {}).",
          *buff->player, *buff, buff->current_tick, buff->current_tick );

      if ( buff->tick_callback )
      {
        buff->tick_callback( buff, buff->current_tick, actual_tick_time );
      }
    }

    buff->expiration.erase( buff->expiration.begin() );

    if ( buff->stack_behavior == buff_stack_behavior::ASYNCHRONOUS )
    {
      buff->decrement( stack );
    }
    else
    {
      buff->expire();
    }
  }
};

struct buff_delay_t : public buff_event_t
{
  double value;
  timespan_t duration;
  int stacks;

  buff_delay_t( buff_t* b, int stacks, double value, timespan_t d )
    : buff_event_t( b, b->rng().gauss( b->sim->default_aura_delay ) ),
      value( value ),
      duration( d ),
      stacks( stacks )
  {
  }

  const char* name() const override
  {
    return "buff_delay_event";
  }

  void execute() override
  {
    // Add a Cooldown check here to avoid extra processing due to delays
    if ( buff->cooldown->remains() == timespan_t::zero() )
      buff->execute( stacks, value, duration );

    auto it = range::find_if( buff->delay, [ this ]( const event_t* e ) {
      return e == this;
    } );
    assert( it != buff->delay.end() );
    buff->delay.erase( it );
  }
};

struct expiration_delay_t : public buff_event_t
{
  expiration_delay_t( buff_t* b, timespan_t d ) : buff_event_t( b, d )
  {
  }

  void execute() override
  {
    buff->expiration_delay = nullptr;
    // Call real expire after a delay
    buff->expire();
  }
};

std::unique_ptr<expr_t> create_buff_expression( util::string_view buff_name, util::string_view type, action_t* action, buff_t* static_buff )
{
  if ( !static_buff && !action )
  {
    assert( false && "Buff expressions require either a valid action or a valid static buff" );
    return nullptr;
  }

  auto make_buff_expr = [buff_name, action, static_buff]( util::string_view n, auto&& fn ) {
    using Fn = decltype(fn);
    return std::make_unique<fn_buff_expr_t<std::decay_t<Fn>>>(
            n, buff_name, action, static_buff, std::forward<Fn>( fn ) );
  };
  auto make_const_buff_expr = [buff_name, action, static_buff]( util::string_view n, auto&& fn, auto&& is_const_fn ) {
    using Fn = decltype(fn);
    using Fn_const = decltype(is_const_fn);
    return std::make_unique<fn_const_buff_expr_t<std::decay_t<Fn>, std::decay_t<Fn_const>>>(
            n, buff_name, action, static_buff, std::forward<Fn>( fn ), std::forward<Fn_const>( is_const_fn ) );
  };

  if ( type == "duration" )
  {
    return make_buff_expr( "buff_duration",
      []( buff_t* buff ) {
        return buff->buff_duration();
      } );
  }
  else if ( type == "elapsed" )
  {
    return make_buff_expr( "buff_elapsed",
      []( buff_t* buff ) {
        return buff->elapsed( buff->sim->current_time() );
      } );
  }
  else if ( type == "remains" )
  {
    return make_const_buff_expr( "buff_remains",
      []( buff_t* buff ) {
        return buff->remains();
      },
      []( buff_t* buff ) {
        return buff->default_chance == 0;
      } );
  }
  else if ( type == "tick_time" )
  {
    return make_buff_expr( "buff_tick_time",
      []( buff_t* buff ) {
        return buff->tick_time();
      } );
  }
  else if ( type == "tick_time_remains" )
  {
    return make_const_buff_expr( "buff_tick_time_remains",
      []( buff_t* buff ) {
        return buff->tick_time_remains();
      },
      []( buff_t* buff ) {
        return buff->default_chance == 0;
      } );
  }
  else if ( type == "cooldown_remains" )
  {
    return make_buff_expr( "buff_cooldown_remains",
      []( buff_t* buff ) {
        return buff->cooldown->remains();
      } );
  }
  else if ( type == "internal_cooldown_remains" )
  {
    return make_buff_expr( "buff_internal_cooldown_remains", []( buff_t* buff ) {
      return buff->internal_cooldown ? buff->internal_cooldown->remains() : 0_ms;
    } );
  }
  else if ( type == "up" )
  {
    return make_const_buff_expr( "buff_up",
      []( buff_t* buff ) {
        return buff->check() > 0;
      },
      []( buff_t* buff ) {
        assert( buff->check() == 0 || buff->default_chance != 0);
        return buff->default_chance == 0;
      } );
  }
  else if ( type == "down" )
  {
    return make_const_buff_expr( "buff_down",
      []( buff_t* buff ) {
        return buff->check() <= 0;
      },
      []( buff_t* buff ) {
        return buff->default_chance == 0;
      } );
  }
  else if ( type == "stack" )
  {
    return make_const_buff_expr( "buff_stack",
      []( buff_t* buff ) {
        return buff->check();
      },
      []( buff_t* buff ) {
        return buff->default_chance == 0;
      } );
  }
  else if ( type == "stack_pct" )
  {
    return make_const_buff_expr( "buff_stack_pct",
      []( buff_t* buff ) {
        return 100.0 * buff->check() / buff->max_stack();
      },
      []( buff_t* buff ) {
        return buff->default_chance == 0;
      } );
  }
  else if ( type == "max_stack" )
  {
    return make_buff_expr( "buff_max_stack",
      []( buff_t* buff ) {
        return buff->max_stack();
      } );
  }
  else if ( type == "at_max_stacks" )
  {
    return make_buff_expr( "buff_at_max_stacks",
      []( buff_t* buff ) {
        return buff->at_max_stacks();
      } );
  }
  else if ( type == "value" )
  {
    return make_buff_expr( "buff_value",
      []( buff_t* buff ) {
        return buff->check_value();
      } );
  }
  else if ( type == "default_value" )
  {
    return make_buff_expr( "buff_default_value", []( buff_t* buff ) { return buff->default_value; } );
  }
  else if ( type == "stack_value" )
  {
    return make_const_buff_expr( "buff_stack_value",
      []( buff_t* buff ) {
        return buff->stack_value();
      },
      []( buff_t* buff ) {
        return buff->default_chance == 0;
      } );
  }
  else if ( type == "react" )
  {
    struct react_expr_t : public buff_expr_t
    {
      react_expr_t( util::string_view bn, action_t* a, buff_t* b ) : buff_expr_t( "buff_react", bn, a, b )
      {
        if ( b )
          b->reactable = true;
      }

      buff_t* create() const override
      {
        auto b = buff_expr_t::create();
        b->reactable = true;
        return b;
      }

      double evaluate() override
      { return buff()->stack_react(); }

      bool is_constant() override
      {
        return buff()->default_chance == 0;
      }
    };

    return std::make_unique<react_expr_t>( buff_name, action, static_buff );
  }
  else if ( type == "react_pct" )
  {
    struct react_pct_expr_t : public buff_expr_t
    {
      react_pct_expr_t( util::string_view bn, action_t* a, buff_t* b ) :
        buff_expr_t( "buff_react_pct", bn, a, b )
      {
        if ( b )
          b->reactable = true;
      }

      buff_t* create() const override
      {
        auto b = buff_expr_t::create();
        b->reactable = true;
        return b;
      }

      double evaluate() override
      { return 100.0 * buff()->stack_react() / buff()->max_stack(); }

      bool is_constant() override
      {
        return buff()->default_chance == 0;
      }
    };

    return std::make_unique<react_pct_expr_t>( buff_name, action, static_buff );
  }
  else if ( type == "cooldown_react" )
  {
    return make_buff_expr( "buff_cooldown_react",
      []( buff_t* buff ) {
        if ( buff->check() && !buff->may_react() )
          return 0_ms;
        return buff->cooldown->remains();
      } );
  }
  else if ( type == "last_trigger" )
  {
    return make_const_buff_expr( "buff_last_trigger",
      []( buff_t* buff ) {
        return buff->last_trigger_time();
      },
      []( buff_t* buff ) {
        return buff->default_chance == 0;
      } );
  }
  else if ( type == "last_expire" )
  {
    return make_const_buff_expr( "buff_last_expire",
      []( buff_t* buff ) {
        return buff->last_expire_time();
      },
      []( buff_t* buff ) {
        return buff->default_chance == 0;
      } );
  }
  else if ( type == "expiration_delay_remains" )
  {
    return make_const_buff_expr( "buff_expiration_delay_remains",
      []( buff_t* buff ) {
        return buff->expiration_delay ? buff->expiration_delay->remains() : 0_ms;
      },
      []( buff_t* buff ) {
        return buff->default_chance == 0;
      } );
  }

  throw sc_invalid_apl_argument( fmt::format( "Unsupported buff expression '{}'.", type ) );
}
}  // namespace

buff_t::buff_t( actor_pair_t q, std::string_view name )
  : buff_t( q.source->sim, q.target, q.source, name, spell_data_t::nil(), nullptr )
{}

buff_t::buff_t( actor_pair_t q, std::string_view name, const spell_data_t* spell_data, const item_t* item )
  : buff_t( q.source->sim, q.target, q.source, name, spell_data, item )
{}

buff_t::buff_t( sim_t* sim, std::string_view name )
  : buff_t( sim, nullptr, nullptr, name, spell_data_t::nil(), nullptr )
{}

buff_t::buff_t( sim_t* sim, std::string_view name, const spell_data_t* spell_data, const item_t* item )
  : buff_t( sim, nullptr, nullptr, name, spell_data, item )
{}

buff_t::buff_t( sim_t* sim, player_t* target, player_t* source, std::string_view name, const spell_data_t* spell_data,
                const item_t* item )
  : sim( sim ),
    player( target ),
    item( item ),
    name_str( name ),
    name_str_reporting(),
    s_data( spell_data ),
    s_data_reporting( spell_data_t::nil() ),
    source( source ),
    expiration(),
    delay(),
    expiration_delay(),
    cooldown(),
    internal_cooldown(),
    rppm( nullptr ),
    _max_stack( -1 ),
    _initial_stack( -1 ),
    default_value( DEFAULT_VALUE() ),
    default_value_effect_idx( 0 ),
    default_value_effect_multiplier( 1.0 ),
    schools( 0U ),
    gcd_type( gcd_haste_type::NONE ),
    activated( true ),
    reactable( false ),
    reverse(),
    constant(),
    quiet(),
    overridden(),
    can_cancel( true ),
    is_fallback(),
    requires_invalidation(),
    expire_at_max_stack(),
    consume_all_stacks( true ),
    ignore_time_modifier( false ),
    reverse_stack_reduction( 1 ),
    proc_callbacks( true ),
    proc_data( s_data ),
    can_only_proc_from_class_abilities( proc_data.can_only_proc_from_class_abilities ),
    can_proc_from_procs( proc_data.can_proc_from_procs ),
    can_proc_from_suppressed( proc_data.can_proc_from_suppressed ),
    suppress_caster_procs( proc_data.suppress_caster_procs ),
    enable_proc_from_suppressed( proc_data.enable_proc_from_suppressed ),
    trigger_data( proc_data ),
    trigger_can_only_proc_from_class_abilities( trigger_data.can_only_proc_from_class_abilities ),
    trigger_can_proc_from_procs( trigger_data.can_proc_from_procs ),
    trigger_can_proc_from_suppressed( trigger_data.can_proc_from_suppressed ),
    current_value(),
    current_stack(),
    base_buff_duration( timespan_t::min() ),
    buff_duration_multiplier( 1.0 ),
    default_chance( 1.0 ),
    manual_chance( -1.0 ),
    base_time_duration_multiplier( 1.0 ),
    dynamic_time_duration_multiplier( 1.0 ),
    constant_behavior( buff_constant_behavior::DEFAULT ),
    refresh_behavior( buff_refresh_behavior::NONE ),
    refresh_behavior_overridden( false ),
    allow_precombat( true ),
    current_tick( 0 ),
    buff_period( timespan_t::min() ),
    tick_time_behavior( buff_tick_time_behavior::UNHASTED ),
    tick_behavior( buff_tick_behavior::NONE ),
    tick_event( nullptr ),
    tick_zero( false ),
    tick_on_application( false ),
    partial_tick( false ),
    freeze_stacks( false ),
    disable_tick_effects( false ),
    last_start(),
    last_trigger(),
    last_expire(),
    iteration_uptime_sum(),
    last_benefite_update(),
    up_count(),
    down_count(),
    start_count(),
    refresh_count(),
    expire_count(),
    overflow_count(),
    overflow_total(),
    trigger_attempts(),
    trigger_successes(),
    simulation_max_stack( 0 ),
    invalidate_list(),
    benefit_pct(),
    trigger_pct(),
    avg_start(),
    avg_refresh(),
    avg_expire(),
    avg_overflow_count(),
    avg_overflow_total(),
    uptime_pct(),
    start_intervals(),
    trigger_intervals(),
    duration_lengths(),
    change_regen_rate( false ),
    disable_async_expire_events_removal( false )
{
  if ( source )  // Player Buffs
  {
    // remove matching name from fallback buff list
    range::erase_remove( player->fallback_buff_names, [ name, source ]( const auto& f ) {
      return f.first == name && f.second == source;
    } );
    player->buff_list.push_back( this );
    cooldown = source->get_cooldown( "buff_" + name_str );
  }
  else  // Sim Buffs
  {
    sim->buff_list.push_back( this );
    cooldown = sim->get_cooldown( "buff_" + name_str );
  }

  constant = ( constant_behavior == buff_constant_behavior::ALWAYS_CONSTANT );

  // Set Buff duration
  set_duration( timespan_t::min() );

  // Set Buff Cooldown
  set_cooldown( timespan_t::min() );
  set_internal_cooldown( timespan_t::min() );

  set_trigger_spell( spell_data_t::nil() );

  // If there's no overridden proc chance (%), setup any potential custom RPPM-affecting attribute
  set_rppm( RPPM_NONE, -1, -1 );

  // TODO: refactor refresh behavior parsing to consolidate calls across different methods like set_period and eliminate
  // need to manually manipulate refresh_behavior_overridden
  if ( s_data->flags( spell_attribute::SX_REFRESH_EXTENDS_DURATION ) )
  {
    set_refresh_behavior( buff_refresh_behavior::PANDEMIC );
    // Reset this after parsing the flag since the `set_refresh_behavior` call will set `refresh_behavior_overridden` to
    // true, which we don't want in this case.
    refresh_behavior_overridden = false;
  }
  // TODO: What happens if both SX_REFRESH_EXTENDS_DURATION and SX_AURA_DOES_NOT_REFRESH are set?
  else if ( s_data->flags( spell_attribute::SX_AURA_DOES_NOT_REFRESH ) )
  {
    set_refresh_behavior( buff_refresh_behavior::DISABLED );
    refresh_behavior_overridden = false;
  }

  set_period( timespan_t::min() );

  set_tick_on_application( s_data->flags( spell_attribute::SX_TICK_ON_APPLICATION ) );

  set_tick_behavior( buff_tick_behavior::NONE );

  if ( s_data->flags( spell_attribute::SX_DOT_HASTED ) )
    set_tick_time_behavior( buff_tick_time_behavior::HASTED );

  // Refresh behavior can be set during the `set_period` call above. If it wasn't, set it now.
  if ( refresh_behavior == buff_refresh_behavior::NONE )
    set_refresh_behavior( buff_refresh_behavior::NONE );

  set_stack_behavior( buff_stack_behavior::DEFAULT );

  assert( refresh_behavior != buff_refresh_behavior::CUSTOM || refresh_duration_callback );

  requires_invalidation = !invalidate_list.empty();
  init_haste_type();

  if ( player && !player->cache.active )
    requires_invalidation = false;

  // These are initialized at -1 then set to their spell data values here (along with error checking)
  set_max_stack( _max_stack );
  set_initial_stack( _initial_stack );

  if ( s_data->flags( spell_attribute::SX_IGNORE_FOR_MOD_TIME_RATE ) )
    ignore_time_modifier = true;
  set_can_cancel( !s_data->flags( spell_attribute::SX_NO_CANCEL ) );

  if ( s_data->flags( spell_attribute::SX_ASYNCHRONOUS_STACKING_AURA ) && _max_stack > 1 )
  {
    set_stack_behavior( buff_stack_behavior::ASYNCHRONOUS );
    set_activated( false );
    if ( source && source->bugs )
      set_disable_async_expire_events_removal( true );
  }

  update_trigger_calculations();
}

buff_t::~buff_t() = default;

const spell_data_t& buff_t::data_reporting() const
{
  if ( is_fallback )
    return *spell_data_t::nil();

  if (s_data_reporting == spell_data_t::nil())
    return *s_data;
  else
    return *s_data_reporting;
}

void buff_t::update_trigger_calculations()
{
  // No override of proc chance or RPPM-related attributes, setup the buff object's proc chance. The
  // spell used for the attributes is either the buff spell (by default), or the given trigger_spell
  // in buff_creator_t.
  if ( manual_chance == -1 )
  {
    default_chance = 1.0;
    if ( !rppm )
    {
      if ( trigger_data->ok() )
      {
        if ( trigger_data->real_ppm() > 0 )
        {
          rppm = player->get_rppm( "buff_" + name_str + "_rppm", trigger_data, item );
        }
        else if ( trigger_data->proc_chance() != 0 )
        {
          default_chance = trigger_data->proc_chance();
        }

        // the driver's internal cooldown becomes the triggering cooldown of the buff
        if ( trigger_data->id() != data().id() )
          set_cooldown( trigger_data->internal_cooldown() );
      }
      // Note, if the spell is "not found", then the buff is disabled.  This allows the system to
      // easily enable/disable spells based on conditional things (such as talents,
      // specialization, etc.).
      else if ( !trigger_data->found() )
      {
        default_chance = 0.0;
      }
    }
  }
  else
  {
    default_chance = manual_chance;
    rppm           = nullptr;
  }
}

buff_t* buff_t::set_chance( double chance )
{
  if ( is_fallback )
    return this;

  manual_chance = chance;
  update_trigger_calculations();
  return this;
}

buff_t* buff_t::set_duration( timespan_t duration )
{
  if ( is_fallback )
    return this;

  // Set Buff duration
  if ( duration == timespan_t::min() )
  {
    if ( data().ok() )
    {
      if ( source )
        base_buff_duration = source->get_passive_value( data(), "duration" );
      else
        base_buff_duration = data().duration();
    }
    else
    {
      base_buff_duration = timespan_t();
    }
  }
  else
  {
    base_buff_duration = duration;
  }

  if ( base_buff_duration < timespan_t::zero() )
  {
    base_buff_duration = timespan_t::zero();
  }

  return this;
}

buff_t* buff_t::modify_duration( timespan_t duration )
{
  if ( is_fallback )
    return this;

  set_duration( base_buff_duration + duration );
  return this;
}

buff_t* buff_t::set_duration_multiplier( double multiplier )
{
  if ( is_fallback )
    return this;

  assert( multiplier >= 0.0 );
  buff_duration_multiplier = multiplier;

  if ( buff_duration_multiplier < 0.0 )
  {
    buff_duration_multiplier = 0.0;
  }

  return this;
}

buff_t* buff_t::set_dynamic_time_duration_multiplier( double new_multiplier )
{
  if ( is_fallback )
    return this;

  assert( new_multiplier > 0.0 );
  if ( new_multiplier == dynamic_time_duration_multiplier )
    return this;

  auto old_multiplier = dynamic_time_duration_multiplier;
  dynamic_time_duration_multiplier = new_multiplier;

  if ( current_stack <= 0 || expiration.empty() )
  {
    return this;
  }

  auto ratio = new_multiplier / old_multiplier;

  // Slowing down the clock, expiry will be moved into the future
  if ( ratio > 1.0 )
  {
    for ( auto exp : expiration )
    {
      auto new_remains = exp->remains() * ratio;
      exp->reschedule( new_remains );

      if ( player )
        sim->print_log( "{} increases {} expiry by a factor of {}. New expiration: {}", *player, *this, ratio,
                      exp->occurs() );
    }
  }
  // Speeding up the clock, expiry moved closer
  else
  {
    for ( size_t i = 0; i < expiration.size(); i++ )
    {
      auto old_expiration = expiration[ i ];
      auto new_remains = old_expiration->remains() * ratio;
      event_t::cancel( old_expiration );

      auto exp = make_event<expiration_t>( *sim, this, new_remains );
      expiration[ i ] = exp;

      if ( player )
        sim->print_log( "{} decreases {} expiry by a factor of {}. New expiration: {}", *player, *this, ratio,
                      exp->occurs() );
    }

  }

  return this;
}

buff_t* buff_t::set_max_stack( int max_stack )
{
  if ( is_fallback )
    return this;

  // _max_stack is initialized at -1, then set_max_stack is called in the buff_t base constructor
  if ( max_stack == -1 )
  {
    if ( data().ok() )
    {
      if ( data().max_stacks() != 0 )
      {
        _max_stack = data().max_stacks();
      }
      else if ( data().initial_stacks() != 0 )
      {
        _max_stack = std::abs( data().initial_stacks() );
      }
      else
      {
        _max_stack = 1;
      }
    }
    else
    {
      _max_stack = 1;
    }
  }
  else
  {
    _max_stack = max_stack;
  }

  if ( _max_stack < 1 )
  {
    sim->error( "{} initialized with max_stack < 1 ({}). Setting max_stack to 1.\n", *this, _max_stack );
    _max_stack = 1;
  }
  else if ( _max_stack > 999 )
  {
    sim->error( "{} initialized with max_stack > 999. Setting max_stack to 999.\n", *this );
    _max_stack = 999;
  }

  stack_react_time.resize( _max_stack + 1 );
  stack_react_ready_triggers.resize( _max_stack + 1 );

  if ( as<int>( stack_uptime.size() ) < _max_stack + 1 )
  {
    stack_uptime.resize( _max_stack + 1 );
  }
  return this;
}

buff_t* buff_t::modify_max_stack( int max_stack )
{
  if ( is_fallback )
    return this;

  set_max_stack( _max_stack + max_stack );
  return this;
}

// TODO: find less blunt & hacky way to handle this
buff_t* buff_t::increase_max_stack_uptime( int max_stack_uptime )
{
  if ( is_fallback )
    return this;

  stack_uptime.resize( stack_uptime.size() + max_stack_uptime );
  return this;
}

buff_t* buff_t::set_initial_stack( int initial_stack )
{
  if ( is_fallback )
    return this;

  // _initial_stack is initialized at -1, then set_initial_stack is called in the buff_t base constructor
  if ( initial_stack == -1 )
  {
    // NOTE: buffs can have negative stacks in the data, which can indicate special handling. We do NOT guard for it
    // here, and instead will assert() out if such a buff is trigger'd/execute'd without explicitly setting a positive
    // stack in the buff construction or explicitly passing a stack amount.
    if ( data().ok() && data().initial_stacks() != 0 )
    {
      _initial_stack = data().initial_stacks();
    }
    else
    {
      _initial_stack = 1;
    }
  }
  else
  {
    _initial_stack = initial_stack;

    if ( _initial_stack < 1 )
    {
      sim->error( "{} initialized with initial_stack < 1 ({}). Setting initial_stack to 1.\n", *this, _initial_stack );
      _initial_stack = 1;
    }
  }

  if ( _initial_stack > 999 )
  {
    sim->error( "{} initialized with initial_stack > 999. Setting initial_stack to 999.\n", *this );
    _initial_stack = 999;
  }

  if ( _initial_stack > _max_stack )
  {
    sim->print_debug( "{} initalized with initial_stack ({}) > max_stack ({}). Setting max_stack to {}.\n", *this,
                      _initial_stack, _max_stack, _initial_stack );
    set_max_stack( _initial_stack );
  }

  return this;
}

buff_t* buff_t::modify_initial_stack( int initial_stack )
{
  if ( is_fallback )
    return this;

  assert( _initial_stack > 0 && "Cannot modify invalid initial stack. Use set_initial_stack() with a postive value.");
  set_initial_stack( _initial_stack + initial_stack );
  return this;
}

buff_t* buff_t::set_initial_stack_to_max_stack()
{
  if ( is_fallback )
    return this;

  set_initial_stack( max_stack() );
  return this;
}

buff_t* buff_t::set_expire_at_max_stack( bool expire )
{
  if ( is_fallback )
    return this;

  if ( expire && _max_stack <= 1 )
  {
    sim->error( "{} being set to expire with max stack <= 1. Setting expire_at_max_stack to false.", *this );
    expire_at_max_stack = false;
  }
  else
  {
    expire_at_max_stack = expire;
  }

  return this;
}

buff_t* buff_t::set_consume_all_stacks( bool consume_all )
{
  if ( is_fallback )
    return this;

  consume_all_stacks = consume_all;

  return this;
}

buff_t* buff_t::set_cooldown( timespan_t duration )
{
  if ( is_fallback )
    return this;

  if ( duration == timespan_t::min() )  // min() called in buff_t constructor
  {
    if ( data().ok() && data().cooldown() != 0_ms )
    {
      cooldown->duration = data().cooldown();
    }
  }
  else
  {
    cooldown->duration = duration;
  }

  if ( cooldown->duration < 0_ms )
  {
    cooldown->duration = 0_ms;
  }

  return this;
}

buff_t* buff_t::set_internal_cooldown( timespan_t duration )
{
  if ( is_fallback )
    return this;

  timespan_t _dur = timespan_t::min();

  if ( duration == timespan_t::min() )  // min() called in buff_t constructor
  {
    if ( data().ok() && data().internal_cooldown() != 0_ms )
    {
      _dur = data().internal_cooldown();
    }
  }
  else
  {
    _dur = duration;
  }

  if ( _dur == timespan_t::min() )  // no icd in data, don't create obj
    return this;

  if ( !internal_cooldown )
  {
    if ( source )
      internal_cooldown = std::make_unique<cooldown_t>( "buff_icd", *source );
    else
      internal_cooldown = std::make_unique<cooldown_t>( "buff_icd", *sim );
  }

  internal_cooldown->duration = _dur;

  if ( internal_cooldown->duration < 0_ms )
    internal_cooldown->duration = 0_ms;

  return this;
}

buff_t* buff_t::modify_cooldown( timespan_t duration )
{
  if ( is_fallback )
    return this;

  set_cooldown( cooldown->duration + duration );
  return this;
}

buff_t* buff_t::set_period( timespan_t period )
{
  if ( is_fallback )
    return this;

  if ( period == timespan_t::min() )
  {
    for ( size_t i = 1; i <= s_data->effect_count(); i++ )
    {
      const spelleffect_data_t& e = s_data->effectN( i );
      if ( !e.ok() || ( e.type() != E_APPLY_AURA && e.type() != E_APPLY_AREA_AURA_PET ) )
        continue;

      switch ( e.subtype() )
      {
        case A_PERIODIC_ENERGIZE:
        case A_PERIODIC_TRIGGER_SPELL_WITH_VALUE:
        case A_PERIODIC_HEALTH_FUNNEL:
        case A_PERIODIC_MANA_LEECH:
        case A_PERIODIC_DAMAGE_PERCENT:
        case A_PERIODIC_DUMMY:
        case A_PERIODIC_TRIGGER_SPELL:
        {
          if ( source )
            buff_period = source->get_passive_value( e, "period" );
          else
            buff_period = e.period();
          if ( !refresh_behavior_overridden && buff_duration() > timespan_t::zero() )
          {
            if ( data().flags( spell_attribute::SX_REFRESH_EXTENDS_DURATION ) )
              set_refresh_behavior( buff_refresh_behavior::PANDEMIC );
            else
              set_refresh_behavior( buff_refresh_behavior::TICK );
          }
          break;
        }
        default:
          break;
      }
    }
  }
  else
  {
    buff_period = period;
  }

  // Recheck tick behaviour, which is dependent on buff_period.
  set_tick_behavior( tick_behavior );

  return this;
}

buff_t* buff_t::modify_period( timespan_t duration )
{
  if ( is_fallback )
    return this;

  set_period( buff_period + duration );
  return this;
}

buff_t* buff_t::disable_ticking( bool v )
{
  if ( is_fallback )
    return this;

  disable_tick_effects = v;
  return this;
}

buff_t* buff_t::add_invalidate( cache_e c )
{
  if ( is_fallback || c == CACHE_NONE )
    return this;

  if ( range::find( invalidate_list, c ) == invalidate_list.end() )  // avoid duplication
  {
    invalidate_list.push_back( c );
    requires_invalidation = true;
    if ( !player || player->regen_caches[ c ] )
    {
      change_regen_rate = true;
    }
    init_haste_type();
  }
  return this;
}

buff_t* buff_t::set_schools( unsigned schools_ )
{
  if ( is_fallback )
    return this;

  schools = schools_;
  return this;
}

buff_t* buff_t::set_schools_from_effect( size_t effect_idx )
{
  if ( is_fallback || !s_data->ok() )
    return this;

  assert( effect_idx > 0 && effect_idx <= s_data->effect_count() );
  set_schools( s_data->effectN( effect_idx ).affected_schools() );
  return this;
}

buff_t* buff_t::add_school( school_e school )
{
  if ( is_fallback )
    return this;

  schools |= dbc::get_school_mask( school );
  return this;
}

buff_t* buff_t::set_pct_buff_type( stat_pct_buff_type type )
{
  if ( is_fallback || !player || type == STAT_PCT_BUFF_MAX )
    return this;

  auto& buffs = player->buffs.stat_pct_buffs[ type ];
  if ( range::find( buffs, this ) == buffs.end() )
    buffs.push_back( this );
  add_invalidate( cache_from_stat_pct_buff( type ) );

  return this;
}

buff_t* buff_t::set_pct_buff_type_from_effect( size_t effect_idx, bool set_default )
{
  if ( is_fallback || !data().ok() )
    return this;

  if ( set_default )
    set_default_value_from_effect( effect_idx );

  const auto& _eff = data().effectN( effect_idx );

  switch ( _eff.subtype() )
  {
    case A_MOD_ALL_CRIT_CHANCE: return set_pct_buff_type( STAT_PCT_BUFF_CRIT );
    case A_HASTE_ALL:           return set_pct_buff_type( STAT_PCT_BUFF_HASTE );
    case A_MOD_VERSATILITY_PCT: return set_pct_buff_type( STAT_PCT_BUFF_VERSATILITY );
    case A_MOD_MASTERY_PCT:     return set_pct_buff_type( STAT_PCT_BUFF_MASTERY );
    case A_MOD_TOTAL_STAT_PERCENTAGE:
    {
      auto _misc = _eff.misc_value2();

      for ( auto i = STAT_PCT_BUFF_STRENGTH; i < STAT_PCT_BUFF_MAX; ++i )
        if ( _misc & ( 0b1 << ( i - STAT_PCT_BUFF_STRENGTH ) ) )
          set_pct_buff_type( i );

      break;
    }
    default: break;
  }

  return this;
}

buff_t* buff_t::set_pct_buff_type_from_data( bool set_default )
{
  if ( is_fallback )
    return this;

  std::vector<double> validation;

  for ( const auto& _eff : data().effects() )
  {
    switch ( _eff.subtype() )
    {
      case A_MOD_ALL_CRIT_CHANCE:
      case A_HASTE_ALL:
      case A_MOD_VERSATILITY_PCT:
      case A_MOD_MASTERY_PCT:
      case A_MOD_TOTAL_STAT_PERCENTAGE:
        set_pct_buff_type_from_effect( _eff.index() + 1, set_default );
        if ( set_default )
          validation.push_back( default_value );
      default: break;
    }
  }

  if ( set_default && !validation.empty() && !range::all_of( validation, [ v = validation.front() ]( auto i ) {
         return i == v;
       } ) )
  {
    throw sc_initialization_error( fmt::format(
      "set_pct_buff_type_from_data() used on '{}' with applicable effects that have different default values.",
      *this ) );
  }

  return this;
}

buff_t* buff_t::set_movement_speed_buff( bool stacking, double percent )
{
  if ( is_fallback || !player )
    return this;

  if ( stacking )
  {
    player->buffs.movement_speed_buffs[ 0 ].emplace_back( percent, this );
  }
  else
  {
    // non-stacking buffs with a single stack need to be sorted
    if ( max_stack() <= 1 )
    {
      auto& _vec = player->buffs.movement_speed_buffs[ 1 ];
      auto it = range::upper_bound( _vec, percent, {}, &std::pair<double, buff_t*>::first );

      assert( it == _vec.end() || it->first <= percent );

      _vec.insert( it, { percent, this } );
    }
    // non-stacking buffs with multiple stacks will always get checked and don't need sorting
    else
    {
      player->buffs.movement_speed_buffs[ 2 ].emplace_back( percent, this );
    }
  }

  add_invalidate( CACHE_RUN_SPEED );

  return this;
}

buff_t* buff_t::set_movement_speed_buff_from_effect( size_t effect_idx, double percent )
{
  if ( is_fallback || !data().ok() )
    return this;

  const auto& _eff = data().effectN( effect_idx );

  if ( !percent )
    percent = _eff.percent();

  switch ( _eff.subtype() )
  {
    case A_MOD_INCREASE_SPEED: return set_movement_speed_buff( false, percent );
    case A_MOD_SPEED_ALWAYS:   return set_movement_speed_buff( true, percent );
    default:                   return this;
  }
}

buff_t* buff_t::set_movement_speed_buff_from_data( double percent )
{
  if ( is_fallback )
    return this;

  for ( const auto& _eff : data().effects() )
    if ( _eff.subtype() == A_MOD_INCREASE_SPEED || _eff.subtype() == A_MOD_SPEED_ALWAYS )
      return set_movement_speed_buff_from_effect( _eff.index() + 1, percent );

  return this;
}

buff_t* buff_t::set_default_value( double value, size_t effect_idx )
{
  if ( is_fallback )
    return this;

  // Ensure we are not errantly overwriting a value that is already set to a given effect
  assert( default_value_effect_idx == 0 || default_value_effect_idx == effect_idx );

  default_value = value;
  default_value_effect_idx = effect_idx;
  return this;
}

buff_t* buff_t::set_default_value_from_effect( size_t effect_idx, double multiplier )
{
  if ( is_fallback || !s_data->ok() )
    return this;

  assert( effect_idx > 0 && effect_idx <= s_data->effect_count() );

  // If no multiplier is specified, use the default_multiplier() lookup function
  // NOTE: If this does not work as expected, check the function for support. This still needs work!
  if ( multiplier == 0.0 )
    multiplier = s_data->effectN( effect_idx ).default_multiplier();

  set_default_value( s_data->effectN( effect_idx ).base_value() * multiplier, effect_idx );
  set_schools( s_data->effectN( effect_idx ).affected_schools() );
  default_value_effect_multiplier = multiplier;
  return this;
}

buff_t* buff_t::set_default_value_from_effect_type( effect_subtype_t a_type, property_type_t p_type, double multiplier,
                                                    effect_type_t e_type )
{
  if ( is_fallback || !s_data->ok() )
    return this;

  for ( size_t idx = 1; idx <= s_data->effect_count(); idx++ )
  {
    const spelleffect_data_t& eff = s_data->effectN( idx );

    if ( eff.subtype() != a_type || eff.type() != e_type )
      continue;

    if ( p_type != property_type_t::P_MAX && eff.property_type() != p_type )
      continue;

    if ( !multiplier )
    {
      multiplier = eff.default_multiplier();
    }

    set_default_value( eff.base_value() * multiplier, idx );
    set_schools( eff.affected_schools() );
    default_value_effect_multiplier = multiplier;
    return this;  // return out after matching the first effect
  }

  sim->error( "ERROR SETTING BUFF DEFAULT VALUE: {} (id={}) has no matching effect with subtype:{} property:{} type:{}",
              name(), s_data->id(), static_cast<int>( a_type ), static_cast<int>( p_type ),
              static_cast<int>( e_type ) );

  return this;
}

buff_t* buff_t::modify_default_value( double value )
{
  if ( is_fallback )
    return this;

  set_default_value( default_value + value, default_value_effect_idx );
  return this;
}

buff_t* buff_t::set_reverse( bool r )
{
  if ( is_fallback )
    return this;

  reverse = r;
  return this;
}

buff_t* buff_t::set_quiet( bool q )
{
  if ( is_fallback )
    return this;

  quiet = q;
  return this;
}

buff_t* buff_t::set_activated( bool a )
{
  if ( is_fallback )
    return this;

  activated = a;
  return this;
}

buff_t* buff_t::set_can_cancel( bool cc )
{
  if ( is_fallback )
    return this;

  can_cancel = cc;
  return this;
}

buff_t* buff_t::set_tick_behavior( buff_tick_behavior behavior )
{
  if ( is_fallback )
    return this;

  tick_behavior = behavior;

  // If period is set, but no buff tick behavior, set the behavior automatically to clipped ticks
  if ( behavior == buff_tick_behavior::NONE && buff_period > timespan_t::zero() )
  {
    tick_behavior = buff_tick_behavior::CLIP;
  }

  return this;
}

buff_t* buff_t::set_tick_callback( buff_tick_callback_t fn )
{
  if ( is_fallback )
    return this;

  if ( fn )
    tick_callback = std::move( fn );

  return this;
}

buff_t* buff_t::set_tick_time_callback( buff_tick_time_callback_t cb )
{
  if ( is_fallback )
    return this;

  if ( cb )
  {
    set_tick_time_behavior( buff_tick_time_behavior::CUSTOM );
    tick_time_callback = std::move( cb );
  }

  return this;
}

buff_t* buff_t::set_affects_regen( bool state )
{
  if ( is_fallback )
    return this;

  change_regen_rate = state;
  return this;
}

buff_t* buff_t::set_constant_behavior( buff_constant_behavior b )
{
  if ( is_fallback )
    return this;

  constant_behavior = b;
  if ( b == buff_constant_behavior::ALWAYS_CONSTANT )
    constant = true;
  else if ( b == buff_constant_behavior::NEVER_CONSTANT )
    constant = false;
  return this;
}

buff_t* buff_t::set_refresh_behavior( buff_refresh_behavior b )
{
  if ( is_fallback )
    return this;

  if ( b == buff_refresh_behavior::NONE )
  {
    // In wod, default behavior for ticking buffs is to pandemic-extend the duration
    if ( buff_period > timespan_t::zero() )
    {
      refresh_behavior = buff_refresh_behavior::PANDEMIC;
    }
    // Otherwise, just do the full-duration refresh
    else
    {
      refresh_behavior = buff_refresh_behavior::DURATION;
    }
  }
  else
  {
    refresh_behavior = b;
    refresh_behavior_overridden = true;
  }
  assert( refresh_behavior != buff_refresh_behavior::CUSTOM || refresh_duration_callback );
  return this;
}

buff_t* buff_t::set_refresh_duration_callback( buff_refresh_duration_callback_t cb )
{
  if ( is_fallback )
    return this;

  if ( cb )
  {
    refresh_behavior          = buff_refresh_behavior::CUSTOM;
    refresh_duration_callback = std::move( cb );
  }
  return this;
}

buff_t* buff_t::set_rppm( rppm_scale_e scale, double freq, double mod )
{
  if ( is_fallback )
    return this;

  if ( scale == RPPM_DISABLE )
  {
    rppm = nullptr;
    return this;
  }

  if ( freq > -1 )
  {
    rppm = player->get_rppm( "buff_" + name_str + "_rppm", trigger_data, item );
    rppm->set_frequency( freq );
  }

  if ( mod > -1 )
  {
    rppm = player->get_rppm( "buff_" + name_str + "_rppm", trigger_data, item );
    rppm->set_modifier( mod );
  }

  if ( scale != RPPM_NONE )
  {
    rppm = player->get_rppm( "buff_" + name_str + "_rppm", trigger_data, item );
    rppm->set_scaling( scale );
  }
  return this;
}

buff_t* buff_t::set_trigger_spell( const spell_data_t* s )
{
  if ( is_fallback )
    return this;

  // If the params specifies a trigger spell (even if it's not found), use it instead of the actual
  // spell data of the buff.
  if ( s != spell_data_t::nil() )
  {
    trigger_data.spell = s;
    trigger_data._init();
  }

  // TODO: if trigger spell has an A_PROC_TRIGGER effect, set the percent chance to the effect value
  update_trigger_calculations();
  return this;
}

buff_t* buff_t::set_stack_change_callback( const buff_stack_change_callback_t& cb )
{
  if ( is_fallback )
    return this;

  stack_change_callback.clear();
  stack_change_callback.push_back( cb );
  return this;
}

buff_t* buff_t::add_stack_change_callback( const buff_stack_change_callback_t& cb )
{
  if ( is_fallback )
    return this;

  stack_change_callback.push_back( cb );
  return this;
}

buff_t* buff_t::set_expire_callback( const buff_expire_callback_t& cb )
{
  if ( is_fallback )
    return this;

  expire_callback = cb;
  return this;
}

buff_t* buff_t::set_reverse_stack_count( int count )
{
  if ( is_fallback )
    return this;

  reverse_stack_reduction = count;
  return this;
}

buff_t* buff_t::set_stack_behavior( buff_stack_behavior b )
{
  if ( is_fallback )
    return this;

  stack_behavior = b;
  return this;
}

buff_t* buff_t::set_allow_precombat( bool b )
{
  if ( is_fallback )
    return this;

  allow_precombat = b;
  return this;
}

buff_t* buff_t::set_name_reporting( std::string_view n )
{
  if ( is_fallback )
    return this;

  name_str_reporting = n;
  return this;
}

buff_t* buff_t::set_disable_async_expire_events_removal( bool b )
{
  if ( is_fallback )
    return this;

  disable_async_expire_events_removal = b;
  return this;
}

// Applies a modifier from -99 to infinity that controls how fast the buff functions.
// Values less than -99 will be rounded to -99, which seems to match in-game behavior where
// auras with a time modifier effect of -100 actually only apply a 100x slowdown, and not a total pause.
// It's intended to modify real time duration and tickrate, without affecting the apparent duration
// as used for things like pandemic refresh behavior.
// Currently, this only modifies the duration of the buff, moving its expiration closer or
// further out. The "apparent" duration is lost (but recoverable), since remains() returns the
// real-time duration. The tickrate is un-adjusted, since it is currently based on the real-time duration.
// None of these limitations particularly matter for current usecases, but if you're looking at using this, be
// aware there may be more work required to support your usecase.
buff_t* buff_t::apply_time_rate_modifier( const spell_data_t* spell )
{
  if ( is_fallback || !spell->ok() || !s_data->ok() )
    return this;

  assert( ( spell->flags( SX_PASSIVE ) || spell->duration() < 0_ms ) && "only passive spells should be affecting buffs." );

  for ( const spelleffect_data_t& effect : spell->effects() )
  {
    if ( !effect.ok() || effect.type() != E_APPLY_AURA || ignore_time_modifier )
      continue;

    if ( effect.subtype() == A_MOD_TIME_RATE )
    {
      if ( !data().affected_by( effect ) )
        continue;
    }
    else if ( effect.subtype() == A_MOD_TIME_RATE_BY_SPELL_LABEL )
    {
      if ( !data().affected_by_label( effect ) )
        continue;
    }
    else
    {
      continue;
    }

    auto mul = 1.0 / ( 1.0 + std::max( effect.percent(), -0.99 ) ); // Limit slow down to 100x slower

    base_time_duration_multiplier = base_time_duration_multiplier * mul;

    if ( sim->debug )
    {
      sim->print_debug( "{} {} time rate modified by {} to {} from {} eff#{}", *source, *this, mul,
                        base_time_duration_multiplier, *spell, effect.index() + 1 );
    }
  }

  return this;
}

void buff_t::datacollection_begin()
{
  iteration_uptime_sum = timespan_t::zero();

  up_count = down_count = 0;
  trigger_successes = trigger_attempts = 0;
  start_count                          = 0;
  refresh_count                        = 0;
  expire_count                         = 0;
  overflow_count                       = 0;
  overflow_total                       = 0;

  for ( int i = 0; i <= simulation_max_stack; i++ )
    stack_uptime[ i ].datacollection_begin();
}

void buff_t::datacollection_end()
{
  // Debuffs need to ensure that the source is active (when single_actor_batch=1) to ensure that
  // reporting stays correct.
  if ( sim->single_actor_batch && source && source != player )
  {
    if ( !source->is_enemy() && source != sim->player_no_pet_list[ sim->current_index ] )
    {
      return;
    }
  }

  timespan_t time = player ? player->iteration_fight_length : sim->current_time();

  uptime_pct.add( time != timespan_t::zero() ? 100.0 * iteration_uptime_sum / time : 0 );

  for ( int i = 0; i <= simulation_max_stack; i++ )
    stack_uptime[ i ].datacollection_end( time );

  if ( up_count > 0 )
  {
    benefit_pct.add( 100.0 * up_count / ( up_count + down_count ) );
  }

  if ( trigger_attempts > 0 )
  {
    trigger_pct.add( 100.0 * trigger_successes / trigger_attempts );
  }

  avg_start.add( start_count );
  avg_refresh.add( refresh_count );
  avg_expire.add( expire_count );
  avg_overflow_count.add( overflow_count );
  avg_overflow_total.add( overflow_total );
}

timespan_t buff_t::refresh_duration( timespan_t new_duration ) const
{
  switch ( refresh_behavior )
  {
    case buff_refresh_behavior::DISABLED:
      return timespan_t::zero();
    case buff_refresh_behavior::DURATION:
      return new_duration;
    case buff_refresh_behavior::TICK:
    {
      assert( tick_event );
      timespan_t residual = remains() % static_cast<tick_t*>( tick_event )->tick_time;
      if ( sim->debug )
      {
        sim->print_debug( "{} {} carryover duration from ongoing tick: {}, refresh_duration={} new_duration={}",
                          *player, *this, residual, new_duration, ( new_duration + residual ) );
      }

      return new_duration + residual;
    }
    case buff_refresh_behavior::PANDEMIC:
    {
      timespan_t residual = std::min( new_duration * 0.3, remains() );
      if ( sim->debug )
      {
        sim->print_debug( "{} {} carryover from ongoing buff: {}, refresh_duration={} new_duration={}",
                          *player, *this, residual, new_duration, ( new_duration + residual ) );
      }

      return new_duration + residual;
    }
    case buff_refresh_behavior::EXTEND:
      return remains() + new_duration;
    case buff_refresh_behavior::MAX:
      return std::max( remains(), new_duration );
    case buff_refresh_behavior::CUSTOM:
      return refresh_duration_callback( this, new_duration );
    default:
    {
      assert( false );
      return new_duration;
    }
  }
}

timespan_t buff_t::tick_time() const
{
  switch ( tick_time_behavior )
  {
    case buff_tick_time_behavior::HASTED:
      assert( source );
      return buff_period * source->cache.spell_cast_speed();
    case buff_tick_time_behavior::CUSTOM:
      assert( tick_time_callback );
      return tick_time_callback( this, current_tick );
    default:
      return buff_period;
  }
}

int buff_t::stack()
{
  int cs = current_stack;
  if ( last_benefite_update != sim->current_time() )
  {
    // make sure we only record a benfit once per sim event
    last_benefite_update = sim->current_time();
    if ( cs > 0 )
      up_count++;
    else
      down_count++;
  }
  return cs;
}

int buff_t::total_stack()
{
  int s = current_stack;

  for ( const auto e : delay )
  {
    s += debug_cast<buff_delay_t*>( e )->stacks;
  }

  return std::min( s, _max_stack );
}

bool buff_t::may_react( int stack )
{
  if ( current_stack == 0 )
    return false;
  if ( stack > current_stack )
    return false;
  if ( stack < 1 )
    return false;
  if ( !reactable )
    return false;

  if ( stack > _max_stack )
    return false;

  return sim->current_time() > stack_react_time[ stack ];
}

int buff_t::stack_react()
{
  int stack = current_stack;

  for ( int i = current_stack; i >= 1; i-- )
  {
    if ( stack_react_time[ i ] <= sim->current_time() )
      break;
    stack--;
  }

  return stack;
}

timespan_t buff_t::remains() const
{
  if ( current_stack <= 0 )
  {
    return timespan_t::zero();
  }
  if ( !expiration.empty() )
  {
    return expiration.back()->occurs() - sim->current_time();
  }
  return timespan_t::min();
}

timespan_t buff_t::tick_time_remains() const
{
  if ( tick_event )
  {
    timespan_t buff_remains = remains();
    timespan_t tick_remains = tick_event->remains();

    if ( tick_remains <= buff_remains || buff_remains == timespan_t::min() )
    {
      return tick_remains;
    }
  }

  return timespan_t::max();
}

bool buff_t::remains_gt( timespan_t time ) const
{
  timespan_t time_remaining = remains();

  if ( time_remaining == timespan_t::zero() )
    return false;

  if ( time_remaining == timespan_t::min() )
    return true;

  return ( time_remaining > time );
}

bool buff_t::remains_lt( timespan_t time ) const
{
  timespan_t time_remaining = remains();

  if ( time_remaining == timespan_t::min() )
    return false;

  return ( time_remaining < time );
}

bool buff_t::has_common_school( school_e school ) const
{
  return ( schools & dbc::get_school_mask( school ) ) != 0;
}

int buff_t::_resolve_stacks( int stacks )
{
  int ret = stacks == -1 ? ( reverse ? _max_stack : _initial_stack ) : stacks;
  assert( ret > 0 && "Stacks must be positive. set_initial_stack() must be used if spell data is negative." );
  return ret;
}

bool buff_t::trigger( timespan_t duration )
{
  return trigger( -1, duration );
}

bool buff_t::trigger( int stacks, timespan_t duration )
{
  return trigger( stacks, DEFAULT_VALUE(), -1, duration );
}

bool buff_t::trigger( int stacks, double value, double chance, timespan_t duration )
{
  if ( _max_stack == 0 || chance == 0 )
    return false;

  if ( cooldown->down() )
    return false;

  if ( player && player->is_sleeping() )
    return false;

  trigger_attempts++;

  if ( rppm )
  {
    double c = chance;
    if ( chance > 0 )
    {
      c = rppm->get_frequency();
      rppm->set_frequency( chance );
    }

    bool triggered = rppm->trigger();

    if ( chance > 0 )
    {
      rppm->set_frequency( c );
    }

    if ( !triggered )
    {
      return false;
    }
  }
  else
  {
    if ( chance < 0 )
      chance = default_chance;

    if ( !rng().roll( chance ) )
      return false;
  }

  // In-game, procs that happen "close to eachother" are usually delayed into the same time slot. We roughly model this
  // by allowing procs that happen during the buff's already existing delay period to trigger at the same time as the
  // first delayed proc will happen.
  if ( !activated && player && player->in_combat && sim->default_aura_delay.mean > 0_ms )
  {
    // Since we're storing stacks as value in buff_delay_t, _resolve default values first
    if ( reverse && current_stack > 0 )
    {
      // Expected behavior of a default value (-1) call on an existing reversible buff is `decrement( 1 )`
      stacks = stacks == -1 ? 1 : stacks;
    }
    else
      stacks = _resolve_stacks( stacks );

    if ( !delay.empty() )
    {
      auto it = range::find_if( delay, [ duration ]( const event_t* e ) {
        return debug_cast<const buff_delay_t*>( e )->duration == duration;
      } );

      if ( it != delay.end() )
      {
        auto d = static_cast<buff_delay_t*>( *it );
        d->stacks += stacks;
        d->value = value;
      }
      else
      {
        delay.emplace_back( make_event<buff_delay_t>( *sim, this, stacks, value, duration ) );
      }
    }
    else
    {
      delay.emplace_back( make_event<buff_delay_t>( *sim, this, stacks, value, duration ) );
    }
  }
  else
  {
    // We can pass stacks value as-is to execute() to have it _resolve'd there
    execute( stacks, value, duration );
  }

  return true;
}

void buff_t::execute( int stacks, double value, timespan_t duration )
{
  if ( value == DEFAULT_VALUE() && default_value != DEFAULT_VALUE() )
    value = default_value;

  if ( last_trigger > timespan_t::zero() )
  {
    trigger_intervals.add( ( sim->current_time() - last_trigger ).total_seconds() );
  }
  last_trigger = sim->current_time();

  // For cases where the buff trigger hasn't been processed through buff_delay_t, or where buff_t::execute() is called
  // directly, default value remains -1, so it needs to get _resolve'd

  // If the buff has a tick event ongoing, the rules change a bit for ongoing ticking buffs, we treat executes as
  // another "normal trigger", which refreshes the buff
  if ( tick_event )
    increment( _resolve_stacks( stacks ), value, duration );
  else
  {
    if ( reverse && current_stack > 0 )
    {
      // Expected behavior of a default value (-1) call on an existing reversible buff is `decrement( 1 )`
      decrement( stacks == -1 ? 1 : stacks, value );
    }
    else
      increment( _resolve_stacks( stacks ), value, duration );
  }

  // new buff cooldown impl
  if ( cooldown->duration > timespan_t::zero() )
  {
    sim->print_debug( "{} starts {} cooldown ({}) with duration {}", source_name(),
                             *this, cooldown->name_str, cooldown->duration );

    cooldown->start();
  }

  trigger_successes++;
}

void buff_t::increment( int stacks, double value, timespan_t duration )
{
  if ( overridden )
    return;

  if ( _max_stack == 0 )
    return;

  if ( current_stack == 0 || stack_behavior == buff_stack_behavior::ASYNCHRONOUS )
  {
    // increment the refresh count since async buffs never call refresh()
    if ( current_stack > 0 )
      refresh_count++;

    start( stacks, value, duration );
  }
  else
  {
    if ( value == DEFAULT_VALUE() )
      value = current_value;

    refresh( stacks, value, duration );
  }
}

void buff_t::decrement( int stacks, double value )
{
  if ( overridden )
    return;

  if ( _max_stack == 0 || current_stack <= 0 )
    return;

  if ( stacks == 0 || current_stack <= stacks )
  {
    expire();
  }
  else
  {
    int old_stack = current_stack;

    if ( as<std::size_t>( current_stack ) < stack_uptime.size() )
      stack_uptime[ current_stack ].update( false, sim->current_time() );

    current_stack -= stacks;

    if ( value != DEFAULT_VALUE() )
      current_value = value;

    if ( as<std::size_t>( current_stack ) < stack_uptime.size() )
      stack_uptime[ current_stack ].update( true, sim->current_time() );

    sim->print_log( "{} decrements {} by {} to {} stacks", *player, *this, stacks, current_stack );

    if ( requires_invalidation )
      invalidate_cache();
    adjust_haste();

    if ( old_stack != current_stack )
    {
      if ( sim->buff_stack_uptime_timeline && !quiet )
        update_stack_uptime_array( sim->current_time(), old_stack );

      last_stack_change = sim->current_time();

      for ( const auto& cb : stack_change_callback )
        cb( this, old_stack, current_stack );
    }
  }
}

void buff_t::extend_duration( timespan_t extra_seconds )
{
  if ( !check() )
  {
    return;
  }

  if ( stack_behavior == buff_stack_behavior::ASYNCHRONOUS )
  {
    throw sc_runtime_error( fmt::format( "{} attempts to extend asynchronous {}.", *source, *this ) );
  }

  if ( expiration.empty() )
  {
    return;
  }

  assert( expiration.size() == 1 );

  extra_seconds = extra_seconds * get_time_duration_multiplier();

  if ( extra_seconds > timespan_t::zero() )
  {
    expiration.front()->reschedule( expiration.front()->remains() + extra_seconds );

    sim->print_log( "{} extends {} by {}. New expiration time: {}", *source, *this, extra_seconds,
                    expiration.front()->occurs() );
  }
  else if ( extra_seconds < timespan_t::zero() )
  {
    timespan_t reschedule_time = expiration.front()->remains() + extra_seconds;

    if ( reschedule_time <= timespan_t::zero() )
    {
      // When Strength of Soul removes the Weakened Soul debuff completely,
      // there's a delay before the server notifies the client. Modeling
      // this effect as a world lag.
      reschedule_time = rng().gauss( source->world_lag );
    }

    event_t::cancel( expiration.front() );
    expiration.erase( expiration.begin() );

    expiration.push_back( make_event<expiration_t>( *sim, this, reschedule_time ) );

    sim->print_log( "{} decreases {} by {}. New expiration: {}", *source, *this, -extra_seconds,
                    expiration.back()->occurs() );
  }
}

void buff_t::extend_async_duration( timespan_t extra_seconds )
{
  if ( !check() )
  {
    return;
  }

  if ( stack_behavior != buff_stack_behavior::ASYNCHRONOUS )
  {
    throw sc_runtime_error( fmt::format( "{} attempts to extend non-asynchronous {}.", *source, *this ) );
  }

  if ( expiration.empty() )
  {
    return;
  }

  extra_seconds = extra_seconds * get_time_duration_multiplier();

  if ( extra_seconds > timespan_t::zero() )
  {
    for ( size_t i = 0; i < expiration.size(); i++ )
    {
      // instead of rescheduling, cancel the events and create fresh ones to maintain expiration event ordering
      expiration_t* exp = debug_cast<expiration_t*>( expiration[ i ] );
      expiration[ i ] = make_event<expiration_t>( *sim, this, exp->stack, exp->remains() + extra_seconds );
      event_t::cancel( exp );
      sim->print_log( "{} extends {} by {}. New expiration time: {}", *source, *this, extra_seconds,
                     expiration[ i ]->occurs() );
    }
  }
  else if ( extra_seconds < timespan_t::zero() )
  {
    throw sc_runtime_error( fmt::format( "{} attempts to decrease asynchronous {} - this is not yet implemented.", *source, *this ) );
  }
}

// Trigger the buff with the specified duration or extend it by the same amount
// Cannot be used for negative adjustments like buff_t::extend_duration() can
void buff_t::extend_duration_or_trigger( timespan_t duration )
{
  timespan_t d = ( duration >= timespan_t::zero() ) ? duration : buff_duration();

  if ( check() )
  {
    extend_duration( d );
  }
  else
  {
    trigger( d );
  }
}

// Reschedules the time of the next tick. Use this function only as a last resort. Try using a custom tick_time_callback
// instead.
void buff_t::reschedule_tick( timespan_t delta )
{
  if ( delta == 0_s )
    return;

  if ( !tick_event )
    return;

  timespan_t new_remains = tick_event->remains() + delta;
  if ( new_remains < 0_s )
  {
    assert( false && "Attempted to reschedule a tick before the current time." );
    return;
  }

  if ( delta < 0_s )
  {
    int old_stacks   = debug_cast<tick_t*>( tick_event )->current_stacks;
    double old_value = debug_cast<tick_t*>( tick_event )->current_value;

    event_t::cancel( tick_event );

    tick_event = make_event<tick_t>( *sim, this, new_remains, old_value, old_stacks );
    debug_cast<tick_t*>( tick_event )->start_time += delta;
  }
  else
  {
    tick_event->reschedule( new_remains );
  }
}

void buff_t::start( int stacks, double value, timespan_t duration )
{
  if ( _max_stack == 0 )
    return;

  if ( value == DEFAULT_VALUE() )
    value = default_value;

#ifndef NDEBUG
  if ( stack_behavior != buff_stack_behavior::ASYNCHRONOUS && current_stack != 0 )
  {
    sim->error( "buff_t::start assertion error current_stack is not zero, {} from {}.\n", *this,
                 source_name() );
    assert( false );
  }
#endif

  timespan_t d = (( duration >= timespan_t::zero() ) ? duration : buff_duration()) * get_time_duration_multiplier();

  if ( sim->current_time() <= timespan_t::from_seconds( 0.01 ) )
  {
    if ( ( d == timespan_t::zero() || ( d > timespan_t::from_seconds( sim->expected_max_time() ) ) ) &&
         constant_behavior != buff_constant_behavior::NEVER_CONSTANT )
      constant = true;
  }

  // async buffs will always start() so only increment when actually a new buff application
  if ( stack_behavior != buff_stack_behavior::ASYNCHRONOUS || current_stack == 0 )
    start_count++;

  if ( player && change_regen_rate )
  {
    if ( player->resource_regeneration == regen_type::DYNAMIC )
      player->do_dynamic_regen( true );
  }
  else if ( change_regen_rate )
  {
    for ( auto* actor : sim->player_non_sleeping_list )
    {
       if ( actor->resource_regeneration != regen_type::DYNAMIC || actor->is_pet() )
        continue;

      for ( auto& elem : invalidate_list )
      {
        if ( actor->regen_caches[ elem ] )
        {
          actor->do_dynamic_regen( true );
          break;
        }
      }
    }
  }

  int before_stacks = check();

  bump( stacks, value );

  if ( last_start >= timespan_t::zero() )
  {
    start_intervals.add( ( sim->current_time() - last_start ).total_seconds() );
  }

  if ( before_stacks <= 0 )
  {
    last_start = sim->current_time();
  }

  if ( d > timespan_t::zero() )
  {
    expiration.push_back( make_event<expiration_t>( *sim, this, stacks, d ) );
    if ( expiration.size() > 1 )
    {
      std::stable_sort( expiration.begin(), expiration.end(), []( const event_t* a, const event_t* b ) {
        return a->remains() < b->remains();
      } );
    }
  }

  timespan_t period = tick_time();
  if ( tick_behavior != buff_tick_behavior::NONE && period > timespan_t::zero() && ( period <= d || d == 0_ms ) )
  {
    // non-async or the first async stack should not have an existing tick_event
    assert( !tick_event || ( stack_behavior == buff_stack_behavior::ASYNCHRONOUS && current_stack > 1 ) );

    // cancel tick_event for buffs that are both async & clip
    if ( tick_event && tick_behavior == buff_tick_behavior::CLIP )
    {
      event_t::cancel( tick_event );
    }

    // start new tick_event for normal, 1st stack of async, and async & clip buffs
    if ( !tick_event )
    {
      current_tick = 0;
      tick_event = make_event<tick_t>( *sim, this, period, current_value, reverse ? reverse_stack_reduction : stacks );
    }

    if ( ( tick_zero || ( tick_on_application && before_stacks == 0 ) ) && tick_callback && !disable_tick_effects )
    {
      tick_callback( this, expiration.empty() ? -1 : static_cast<int>( remains() / period ), 0_ms );
    }
  }
}

void buff_t::refresh( int stacks, double value, timespan_t duration )
{
  if ( _max_stack == 0 )
    return;

  if ( value == DEFAULT_VALUE() )
    value = current_value;

  bump( stacks, value );

  refresh_count++;

  timespan_t d;
  if ( duration > timespan_t::zero() )
    d = refresh_duration( duration );
  else if ( duration == timespan_t::zero() )
    d = duration;
  else
    d = refresh_duration( buff_duration() );

  d = d * get_time_duration_multiplier();

  if ( refresh_behavior == buff_refresh_behavior::DISABLED && duration != timespan_t::zero() )
    return;

  // Make sure we always cancel the expiration event if we get an
  // infinite duration
  if ( d <= timespan_t::zero() )
  {
    if ( !expiration.empty() )
    {
      event_t::cancel( expiration.front() );
      expiration.erase( expiration.begin() );
    }
    // Infinite ticking buff refreshes shouldnt happen, but cancel ongoing tick event just to be sure.
    // However, if stacks are frozen assume infinitely ticking event is explicitly intended and do not cancel.
    if ( !freeze_stacks )
      event_t::cancel( tick_event );
  }
  else
  {
    // Infinite duration -> duration of d
    if ( expiration.empty() )
      expiration.push_back( make_event<expiration_t>( *sim, this, d ) );
    else
    {
      timespan_t duration_remains = expiration.front()->remains();
      if ( duration_remains < d )
        expiration.front()->reschedule( d );
      else if ( duration_remains > d )
      {
        event_t::cancel( expiration.front() );
        expiration.erase( expiration.begin() );
        expiration.push_back( make_event<expiration_t>( *sim, this, d ) );
      }
    }

    if ( tick_event && tick_behavior == buff_tick_behavior::CLIP )
    {
      event_t::cancel( tick_event );
      current_tick      = 0;
      timespan_t period = tick_time();
      tick_event = make_event<tick_t>( *sim, this, period, current_value, reverse ? 1 : stacks );
    }

    if ( tick_zero && tick_callback && !disable_tick_effects )
    {
      tick_callback( this, expiration.empty() ? -1 : static_cast<int>( remains() / tick_time() ), timespan_t::zero() );
    }
  }

  if ( sim->log )
  {
    std::string buff_display_name = fmt::format( "{}_{}", name_str, current_stack );

    if ( player )
    {
      if ( !player->is_sleeping() )
      {
        sim->print_log( "{} refreshes {} (value={:.7g}, duration={}, time_duration_multiplier={:.7g})", *player,
                        buff_display_name, current_value, d, get_time_duration_multiplier() );
      }
    }
    else
    {
      sim->print_log( "Raid refreshes {} (value={:.7g}, duration={}, time_duration_multiplier={:.7g})",
                      buff_display_name, current_value, d, get_time_duration_multiplier() );
    }
  }
}

void buff_t::bump( int stacks, double value )
{
  if ( _max_stack == 0 )
    return;

  assert( default_chance != 0 && "Buff started with default chance being zero.");

  if ( value == DEFAULT_VALUE() )
    value = default_value;

  bool changes_stack_value = false; // Flag to check if we need to adjust haste and invalidate cache at the end of bump

  if ( value != current_value )
  {
    changes_stack_value = true;
  }
  current_value = value;

  int old_stack = current_stack;

  if ( max_stack() < 0 )
  {
    current_stack += stacks;
    changes_stack_value = true;
  }
  // Asynchronous buffs need to adjust their expiration even when bumped at max stacks.
  else if ( current_stack < max_stack() || stack_behavior == buff_stack_behavior::ASYNCHRONOUS )
  {
    changes_stack_value = true;
    int before_stack = current_stack;

    current_stack += stacks;
    if ( current_stack > max_stack() )
    {
      int overflow = current_stack - max_stack();

      overflow_count++;
      overflow_total += overflow;
      current_stack = max_stack();

      if ( !disable_async_expire_events_removal && stack_behavior == buff_stack_behavior::ASYNCHRONOUS )
      {
        // Can't trigger more than max stack at a time
        overflow -= std::max( 0, stacks - max_stack() );

        /* Replace the oldest buff with the new one. We do this by cancelling
        expiration events until their stack count add up to the overflow. */
        while ( overflow > 0 )
        {
          event_t* e     = expiration.front();
          int exp_stacks = debug_cast<expiration_t*>( e )->stack;
          if ( exp_stacks > overflow )
          {
            debug_cast<expiration_t*>( e )->stack -= overflow;
            break;
          }
          else
          {
            event_t::cancel( e );
            expiration.erase( expiration.begin() );
            overflow -= exp_stacks;
          }
        }
      }
    }

    if ( before_stack != current_stack )
    {
      stack_uptime[ before_stack ].update( false, sim->current_time() );
      stack_uptime[ current_stack ].update( true, sim->current_time() );
    }

    aura_gain();

    if ( reactable )
    {
      timespan_t total_reaction_time = ( player ? ( player->total_reaction_time() ) : sim->reaction_time );
      timespan_t react               = sim->current_time() + total_reaction_time;
      for ( int i = before_stack + 1; i <= current_stack; i++ )
      {
        stack_react_time[ i ] = react;
        if ( player && player->ready_type == READY_TRIGGER )
        {
          if ( !stack_react_ready_triggers[ i ] )
          {
            stack_react_ready_triggers[ i ] = make_event<react_ready_trigger_t>( *sim, this, i, total_reaction_time );
          }
          else
          {
            timespan_t next_react = sim->current_time() + total_reaction_time;
            if ( next_react > stack_react_ready_triggers[ i ]->occurs() )
            {
              stack_react_ready_triggers[ i ]->reschedule( next_react );
            }
            else if ( next_react < stack_react_ready_triggers[ i ]->occurs() )
            {
              event_t::cancel( stack_react_ready_triggers[ i ] );
              stack_react_ready_triggers[ i ] = make_event<react_ready_trigger_t>( *sim, this, i, total_reaction_time );
            }
          }
        }
      }
    }

    if ( current_stack > simulation_max_stack )
      simulation_max_stack = current_stack;
  }
  else
  {
    overflow_count++;
    overflow_total += stacks;
  }

  if ( changes_stack_value )
  {
    if ( requires_invalidation )
      invalidate_cache();
    adjust_haste();
  }

  if ( old_stack != current_stack )
  {
    if ( sim->buff_stack_uptime_timeline && !quiet )
      update_stack_uptime_array( sim->current_time(), old_stack );

    last_stack_change = sim->current_time();

    for ( const auto& cb : stack_change_callback )
      cb( this, old_stack, current_stack );
  }

  if ( expire_at_max_stack && at_max_stacks() )
    make_event( *sim, [ this ] { expire(); } );

  if ( player )
    player->trigger_ready();

  // TODO: assumption is that PROC1_NONE_HELPFUL actually applies to all aura application, whether hostile or not
  // NOTE: scheduled as event to ensure buff is fully processed
  if ( proc_callbacks && !constant && ( !suppress_caster_procs || enable_proc_from_suppressed ) && source &&
       !source->callbacks.procs[ PROC1_NONE_HELPFUL ][ PROC2_LANDED ].empty() )
  {
    make_event( *sim, [ this ] { source->trigger_callbacks( PROC1_NONE_HELPFUL, PROC2_LANDED, this ); } );
  }
}

void buff_t::override_buff( int stacks, double value )
{
  if ( _max_stack == 0 )
    return;

#ifndef NDEBUG
  if ( current_stack != 0 )
  {
    sim->error( "buff_t::override assertion error current_stack is not zero, {} from {}.\n", *this,
                 source_name() );
    assert( false );
  }
#endif

  if ( value == DEFAULT_VALUE() )
    value = default_value;

  set_duration( timespan_t::zero() );
  start( stacks, value );
  overridden = true;
}

bool buff_t::can_trigger( action_t* action ) const
{
  if ( is_fallback || !action->data().ok() || !trigger_data->ok() )
    return false;

  if ( trigger_data->proc_flags() == 0 )
    return true;

  // only direct damage triggers obey proc-related attributes
  auto pt_type = !( trigger_data->proc_flags() & PF_CAST_SUCCESSFUL ) && !action->not_a_proc &&
                     ( action->proc || action->background )
                   ? proc_trigger_type_e::TRIGGER_ACTION_PROC
                   : proc_trigger_type_e::TRIGGER_ACTION;

  return proc_data_t::check_proc_trigger( action->proc_data, trigger_data, pt_type );
}

bool buff_t::trigger( action_t* action, int stacks, double value, double chance, timespan_t duration )
{
  if ( can_trigger( action ) )
  {
    if ( sim->debug )
      sim->print_debug( "{} triggers {}.", *action, *this );

    return trigger( stacks, value, chance, duration );
  }

  return false;
}

bool buff_t::can_consume( action_t* action ) const
{
  if ( is_fallback || !action->data().ok() || !data().ok() )
    return false;

  if ( proc_data->proc_flags() == 0 )
    return true;

  // only direct damage triggers obey proc-related attributes
  auto pt_type = !( proc_data->proc_flags() & PF_CAST_SUCCESSFUL ) && !action->not_a_proc &&
                     ( action->proc || action->background )
                   ? proc_trigger_type_e::TRIGGER_ACTION_PROC
                   : proc_trigger_type_e::TRIGGER_ACTION;

  return proc_data_t::check_proc_trigger( action->proc_data, proc_data, pt_type );
}

int buff_t::consume( action_t* action, int stacks )
{
  if ( !stacks || !check() )
    return 0;

  if ( internal_cooldown && internal_cooldown->down() )
    return 0;

  if ( !can_consume( action ) )
    return 0;

  if ( sim->debug )
    sim->print_debug( "{} consumes {}.", *action, *this );

  int old_stacks = check();

  // default behavior
  if ( stacks == -1 )
  {
    if ( consume_all_stacks )
      expire();
    else
      decrement();
  }
  else
  {
    decrement( stacks );
  }

  if ( internal_cooldown )
    internal_cooldown->start();

  return old_stacks - check();
}

void buff_t::expire( timespan_t d )
{
  if ( current_stack <= 0 )
  {
    assert( tick_event == nullptr );
    return;
  }

  if ( d > timespan_t::zero() )  // Expiration Delay
  {
    if ( !expiration_delay )  // Don't reschedule already existing expiration delay
    {
      expiration_delay = make_event<expiration_delay_t>( *sim, this, d );
    }
    return;
  }
  else
  {
    event_t::cancel( expiration_delay );
  }
  last_expire = sim->current_time();

  timespan_t remaining_duration = timespan_t::zero();
  int expiration_stacks         = current_stack;
  if ( !expiration.empty() )
  {
    remaining_duration = expiration.back()->remains();

    while ( !expiration.empty() )
    {
      event_t::cancel( expiration.front() );
      expiration.erase( expiration.begin() );
    }
  }
  event_t::cancel( tick_event );
  current_tick = 0;

  assert( as<std::size_t>( current_stack ) < stack_uptime.size() );
  stack_uptime[ current_stack ].update( false, sim->current_time() );

  if ( player && change_regen_rate )
  {
    if ( player->resource_regeneration == regen_type::DYNAMIC )
      player->do_dynamic_regen( true );
  }
  else if ( change_regen_rate )
  {
    for ( auto* actor : sim->player_non_sleeping_list )
    {
       if ( actor->resource_regeneration != regen_type::DYNAMIC|| actor->is_pet() )
        continue;

      for ( auto& elem : invalidate_list )
      {
        if ( actor->regen_caches[ elem ] )
        {
          actor->do_dynamic_regen( true );
          break;
        }
      }
    }
  }

  int old_stack = current_stack;

  current_stack = 0;

  if ( last_start >= timespan_t::zero() )
  {
    timespan_t last_duration = sim->current_time() - last_start;
    iteration_uptime_sum += last_duration;
    if ( last_duration > 0_ms )
      duration_lengths.add( last_duration.total_seconds() );
  }

  update_stack_uptime_array( sim->current_time(), old_stack );
  last_stack_change = sim->current_time();

  if ( !overridden && constant_behavior != buff_constant_behavior::ALWAYS_CONSTANT &&
       player && !player->is_sleeping() )
  {
    constant = false;
  }

  if ( reactable && player && player->ready_type == READY_TRIGGER )
  {
    for ( auto& stack_react_ready_trigger : stack_react_ready_triggers )
      event_t::cancel( stack_react_ready_trigger );
  }

  if ( buff_duration() > timespan_t::zero() && remaining_duration == timespan_t::zero() )
  {
    expire_count++;
  }

  if ( expire_callback )
  {
    expire_callback( this, expiration_stacks, remaining_duration );
  }

  expire_override( expiration_stacks, remaining_duration );  // virtual expire call

  current_value = 0;

  aura_loss();

  if ( requires_invalidation )
    invalidate_cache();
  adjust_haste();

  for ( const auto& cb : stack_change_callback )
    cb( this, old_stack, current_stack );

  if ( player )
    player->trigger_ready();
}

void buff_t::cancel()
{
  expire();
  event_t::cancel( expiration_delay );
  for ( auto e : delay )
  {
    event_t::cancel( e );
  }
  delay.clear();
}

void buff_t::predict()
{
  // Guarantee that may_react() will return true if the buff is present.
  std::fill( stack_react_time.begin(), stack_react_time.begin() + current_stack + 1, timespan_t::min() );
}

void buff_t::aura_gain()
{
  if ( sim->log )
  {
    std::string buff_display_name = fmt::format("{} (stacks={})", *this, current_stack );

    if ( player )
    {
      if ( !player->is_sleeping() )
      {
        sim->print_log( "{} gains {} (value={:.7g}, time_duration_multiplier={:.7g})", *player, buff_display_name,
                        current_value, get_time_duration_multiplier() );
      }
    }
    else
    {
      sim->print_log( "Raid gains {} (value={:.7g}, time_duration_multiplier={:.7g})", buff_display_name, current_value,
                      get_time_duration_multiplier() );
    }
  }
}

void buff_t::aura_loss()
{
  if ( player )
  {
    if ( !player->is_sleeping() )
    {
      sim->print_log( "{} loses {}", *player, *this );
    }
  }
  else
  {
    sim->print_log( "Raid loses {}", name_str );
  }
}

void buff_t::reset()
{
  for ( auto e : delay )
  {
    event_t::cancel( e );
  }
  delay.clear();
  event_t::cancel( expiration_delay );
  event_t::cancel( tick_event );
  cooldown->reset( false );
  expire();
  last_start        = timespan_t::min();
  last_trigger      = timespan_t::min();
  last_expire       = timespan_t::min();
  last_stack_change = timespan_t::min();
  dynamic_time_duration_multiplier = 1.0;
  if ( internal_cooldown )
    internal_cooldown->reset_init();
}

void buff_t::merge( const buff_t& other )
{
  start_intervals.merge( other.start_intervals );
  trigger_intervals.merge( other.trigger_intervals );
  duration_lengths.merge( other.duration_lengths );

  uptime_pct.merge( other.uptime_pct );
  benefit_pct.merge( other.benefit_pct );
  trigger_pct.merge( other.trigger_pct );
  avg_start.merge( other.avg_start );
  avg_refresh.merge( other.avg_refresh );
  avg_expire.merge( other.avg_expire );
  avg_overflow_count.merge( other.avg_overflow_count );
  avg_overflow_total.merge( other.avg_overflow_total );
  if ( sim->buff_uptime_timeline && !quiet )
    uptime_array.merge( other.uptime_array );

#ifndef NDEBUG
  if ( stack_uptime.size() != other.stack_uptime.size() )
  {
    sim->error( "buff_t::merge {} from {} stack_uptime vector not of equal length.\n", *this,
                 source_name() );
    assert( false );
  }
#endif

  for ( size_t i = 0; i < stack_uptime.size(); i++ )
    stack_uptime[ i ].merge( other.stack_uptime[ i ] );
}

void buff_t::analyze()
{
  // Aura with no uptime_array data will return uptime_array.mean() == 0 and are not reported in neither the JSON nor
  // HTML outputs, so no need to adjust them.
  if ( sim->buff_uptime_timeline && uptime_array.mean() != 0 )
  {
    // If the source is null, e.g. sim-wide auras, use the sim's timeline divisor, even for single_actor_batch. This
    // situation should only arise if you disable the sim-wide aura override, sim an actor that can cast one of the
    // buffs, and the fight length extends over an hour so the buff expires.
    if ( !sim->single_actor_batch || !source )
    {
      uptime_array.adjust( *sim );
    }
    // When running with single_actor_batch and there is a source, choose the fight_length with less
    // data because enemies may have data from iterations that did not contain the other actor.
    else if ( sim->single_actor_batch && source )
    {
      if ( source->get_owner_or_self()->collected_data.fight_length.size() < player->get_owner_or_self()->collected_data.fight_length.size() )
      {
        uptime_array.adjust( source->get_owner_or_self()->collected_data.fight_length );
      }
      else
      {
        uptime_array.adjust( player->get_owner_or_self()->collected_data.fight_length );
      }
    }
    else
    {
      uptime_array.adjust( player->get_owner_or_self()->collected_data.fight_length );
    }
  }
}

buff_t* buff_t::find( util::span<buff_t* const> buffs, util::string_view name_str, player_t* source )
{
  for ( buff_t* buff : buffs )
  {
    if ( name_str == buff->name_str )
    {
      if ( !source || ( source == buff->source ) )
      {
        return buff;
      }
    }
  }

  return nullptr;
}

namespace
{
struct potion_spell_filter
{
  unsigned spell_id;
  const dbc_t& dbc;

  bool operator()( const dbc_item_data_t* item ) const
  {
    // Augment runes and other things look like potions. Only match things
    // that trigger the potion shared cooldown.
    auto item_effects = dbc.item_effects( item->id );
    return !item_effects.empty() && item_effects[ 0 ].cooldown_group == ITEM_COOLDOWN_GROUP_POTION &&
           range::contains( item_effects, spell_id, &item_effect_t::spell_id );
  }
};
}  // namespace

static buff_t* find_potion_buff( util::span<buff_t* const> buffs, player_t* source )
{
  for ( auto b : buffs )
  {
    if ( b->data().id() == 0 )
    {
      continue;
    }

    if ( source && source != b->source )
    {
      continue;
    }

    if ( auto item = &dbc::find_consumable( ITEM_SUBCLASS_POTION, b->player->is_ptr(),
                              potion_spell_filter{ b->data().id(), *b->player->dbc } ); item->id != 0 )
    {
      return b;
    }
  }

  if ( source )
  {
    return source->sim->auras.fallback;
  }

  return nullptr;
}

buff_t* buff_t::find_expressable( util::span<buff_t* const> buffs, util::string_view name, player_t* source )
{
  if ( util::str_compare_ci( "potion", name ) )
    return find_potion_buff( buffs, source );
  else
    return find( buffs, name, source );
}

buff_t* buff_t::make_fallback( player_t* player, std::string_view name, player_t* source )
{
  for ( const auto& fb : player->fallback_buff_names )
    if ( fb.first == name && fb.second == source )
      return player->sim->auras.fallback;

  player->fallback_buff_names.emplace_back( name, source );
  return player->sim->auras.fallback;
}

std::string buff_t::to_str() const
{
  std::ostringstream s;

  s << data().to_str();
  s << " max_stack=" << _max_stack;
  s << " initial_stack=" << data().initial_stacks();
  s << " cooldown=" << cooldown->duration.total_seconds();
  if ( internal_cooldown )
    s << " internal_cooldown=" << internal_cooldown->duration.total_seconds();
  s << " duration=" << buff_duration().total_seconds();
  s << " default_chance=" << default_chance;

  return s.str();
}

std::unique_ptr<expr_t> buff_t::create_expression( util::string_view buff_name, util::string_view type, action_t& action )
{
  return create_buff_expression( buff_name, type, &action, nullptr );
}

std::unique_ptr<expr_t> buff_t::create_expression( util::string_view buff_name, util::string_view type, buff_t& static_buff )
{
  return create_buff_expression( buff_name, type, nullptr, &static_buff );
}

#if defined( SC_USE_STAT_CACHE )

void buff_t::invalidate_cache()
{
  if ( player )
  {
    for ( int i = as<int>( invalidate_list.size() ) - 1; i >= 0; i-- )
    {
      player->invalidate_cache( invalidate_list[ i ] );
    }
  }
  else  // It is an aura...  Ouch.
  {
    for ( int i = as<int>( sim->player_no_pet_list.size() ) - 1; i >= 0; i-- )
    {
      player_t* p = sim->player_no_pet_list[ i ];
      for ( int j = as<int>( invalidate_list.size() ) - 1; j >= 0; j-- )
        p->invalidate_cache( invalidate_list[ j ] );
    }
  }
}

#endif

buff_t* buff_t::find( sim_t* s, util::string_view name )
{
  return find( s->buff_list, name );
}

buff_t* buff_t::find( player_t* p, util::string_view name, player_t* source )
{
  for ( const auto& fb : p->fallback_buff_names )
    if ( fb.first == name && ( !source || fb.second == source ) )
      return p->sim->auras.fallback;

  return find( p->buff_list, name, source );
}

const char* buff_t::name_reporting() const
{
  if ( name_str_reporting.empty() )
    return name_str.c_str();
  else
    return name_str_reporting.c_str();
}

util::string_view buff_t::source_name() const
{
  if ( source )
    return source->name_str;

  return "noone";
}

rng::rng_t& buff_t::rng()
{
  return sim->rng();
}

rng::rng_t& buff_t::rng() const
{
  return sim -> rng();
}

/**
 * Adjust the players dynamic effects affected by haste changes.
 */
void buff_t::adjust_haste()
{
  if ( gcd_type == gcd_haste_type::NONE )
  {
    return;
  }
  assert(player && "Haste buffs for non-player buffs are not supported.");

  player->adjust_dynamic_cooldowns();
  // player->adjust_global_cooldown( haste_type );
  player->adjust_auto_attack( gcd_type );
}

void buff_t::init_haste_type()
{
  // All haste > everything
  if ( range::find( invalidate_list, CACHE_HASTE ) != invalidate_list.end() )
  {
    gcd_type = gcd_haste_type::HASTE;
  }

  // Select one of the specific types
  if ( gcd_type == gcd_haste_type::NONE )
  {
    if ( range::find( invalidate_list, CACHE_SPELL_HASTE ) != invalidate_list.end() )
    {
      gcd_type = gcd_haste_type::SPELL_HASTE;
    }
    else if ( range::find( invalidate_list, CACHE_ATTACK_HASTE ) != invalidate_list.end() )
    {
      gcd_type = gcd_haste_type::ATTACK_HASTE;
    }
    else if ( range::find( invalidate_list, CACHE_SPELL_CAST_SPEED ) != invalidate_list.end() )
    {
      gcd_type = gcd_haste_type::SPELL_CAST_SPEED;
    }
    else if ( range::find( invalidate_list, CACHE_AUTO_ATTACK_SPEED ) != invalidate_list.end() )
    {
      gcd_type = gcd_haste_type::AUTO_ATTACK_SPEED;
    }
  }
}

void buff_t::update_stack_uptime_array( timespan_t current_time, int old_stacks )
{
  if ( !sim->buff_uptime_timeline || quiet )
    return;

  // No data collection done on first iteration of multi-iteration sim, as per sim_t::combat_end()
  if ( sim->iterations > 1 && sim->current_iteration == 0 )
    return;

  if ( constant || overridden || old_stacks <= 0 )
    return;

  timespan_t last_time = sim->buff_stack_uptime_timeline ? last_stack_change : last_start;
  int mul = sim->buff_stack_uptime_timeline ? old_stacks : 1;

  timespan_t start_time    = timespan_t::from_seconds( last_time.total_millis() / 1000 );
  timespan_t end_time      = timespan_t::from_seconds( current_time.total_millis() / 1000 );
  timespan_t begin_partial = 1_s - ( last_time % 1_s );
  timespan_t end_partial   = ( current_time % 1_s );

  if ( last_time % 1_s == timespan_t::zero() )
    begin_partial = 1_s;

  if ( start_time == end_time )
  {
    uptime_array.add( start_time, ( current_time.total_seconds() - last_time.total_seconds() ) * mul );
    return;
  }

  uptime_array.add( start_time, begin_partial.total_seconds() * mul );

  for ( timespan_t i = start_time + 1000_ms; i < end_time; i = i + 1000_ms )
    uptime_array.add( i, mul );

  uptime_array.add( end_time, end_partial.total_seconds() * mul );
}

void sc_format_to( const buff_t& buff, fmt::format_context::iterator out )
{
  if ( buff.sim->log_spell_id )
  {
    fmt::format_to( out, "Buff '{}' ({})", buff.name(), buff.data().id() );
  }
  else
  {
    fmt::format_to( out, "Buff '{}'", buff.name() );
  }
}

// ==========================================================================
// STAT_BUFF
// ==========================================================================

stat_buff_t::stat_buff_t(actor_pair_t q, util::string_view name)
  : stat_buff_t(q, name, spell_data_t::nil(), nullptr)
{

}

stat_buff_t::stat_buff_t( actor_pair_t q, util::string_view name, const spell_data_t* spell, const item_t* item )
  : buff_t( q, name, spell, item ),
    stat_gain( player->get_gain( fmt::format( "{}_buff", name ) ) ),  // append _buff for now to check usage
    manual_stats_added( false )
{
  bool has_ap = false;

  for ( size_t i = 1; i <= data().effect_count(); i++ )
  {
    stat_e s                         = STAT_NONE;
    double amount                    = 0;
    const spelleffect_data_t& effect = data().effectN( i );

    if ( item )
      amount = effect.average( item );
    else
      amount = effect.average( player, std::min( MAX_LEVEL, player->level() ) );

    if ( effect.subtype() == A_MOD_STAT )
    {
      if ( effect.misc_value1() >= 0 )
      {
        s = static_cast<stat_e>( effect.misc_value1() + 1 );
      }
      else if ( effect.misc_value1() == -1 )
      {
        s = STAT_ALL;
      }
      else if ( effect.misc_value1() == -2 )
      {
        s = player->convert_hybrid_stat( STAT_STR_AGI_INT );
      }
    }
    else if ( effect.subtype() == A_MOD_RATING )
    {
      auto k = util::translate_all_rating_mod( effect.misc_value1() );

      for ( const auto& stat : k )
      {
        stats.emplace_back( stat, amount );
      }
    }
    else if ( effect.subtype() == A_MOD_DAMAGE_DONE && ( effect.misc_value1() & 0x7E ) )
    {
      s = STAT_SPELL_POWER;
    }
    else if ( effect.subtype() == A_MOD_RESISTANCE )
    {
      s = STAT_BONUS_ARMOR;
    }
    else if ( !has_ap && ( effect.subtype() == A_MOD_ATTACK_POWER || effect.subtype() == A_MOD_RANGED_ATTACK_POWER ) )
    {
      s      = STAT_ATTACK_POWER;
      has_ap = true;
    }
    else if ( effect.subtype() == A_MOD_INCREASE_HEALTH_2 || effect.subtype() == A_MOD_INCREASE_HEALTH )
    {
      s = STAT_MAX_HEALTH;
    }
    else if ( effect.subtype() == A_MOD_BONUS_ARMOR )
    {
      s = STAT_BONUS_ARMOR;
    }

    if ( s != STAT_NONE )
    {
      stats.emplace_back( s, amount );
    }
  }
}

stat_buff_t* stat_buff_t::add_stat( stat_e s, double a, const stat_check_fn& c )
{
  if ( is_fallback )
    return this;

  if ( !manual_stats_added )
  {
    // If we are the first to add manual stats, clear the spell_data parsed ones.
    stats.clear();
  }
  manual_stats_added = true;

  auto it = range::find( stats, s, &buff_stat_t::stat );
  if ( it != stats.end() )
  {
    it->amount += a;

    if ( c )
      it->check_func = c;
  }
  else
  {
    stats.emplace_back( s, a, c );
  }

  return this;
}

stat_buff_t* stat_buff_t::set_stat( stat_e s, double a, const stat_check_fn& c )
{
  if ( is_fallback )
    return this;

  manual_stats_added = false;

  return add_stat( s, a, c );
}

stat_buff_t* stat_buff_t::add_stat_from_effect( size_t i, double a, const stat_check_fn& c )
{
  if ( is_fallback )
    return this;

  auto do_error = [ this, i ]( std::string_view msg ) -> stat_buff_t* {
    sim->error( "{} cannot add stat from effect#{}: {}", *this, i, msg );
    return this;
  };

  if ( i > data().effect_count() )
    return do_error( "index out of bounds" );

  const auto& eff = data().effectN( i );

  if ( eff.subtype() == A_MOD_STAT )
  {
    auto misc   = eff.misc_value1();
    stat_e stat = STAT_NONE;

    if ( misc >= 0 )
      stat = static_cast<stat_e>( misc + 1 );
    else if ( misc == -1 )
      stat = STAT_ALL;
    else if ( misc == -2 )
      stat = player->convert_hybrid_stat( STAT_STR_AGI_INT );

    if ( stat != STAT_NONE )
      return add_stat( stat, a, c );
  }
  else if ( eff.subtype() == A_MOD_RATING )
  {
    auto mods = util::translate_all_rating_mod( data().effectN( i ).misc_value1() );
    if ( !mods.empty() )
    {
      for ( const auto& s : mods )
        add_stat( s, a, c );

      return this;
    }
  }
  else if ( eff.subtype() == A_MOD_SUPPORT_STAT )
  {
    auto misc   = eff.misc_value1();
    stat_e stat = STAT_NONE;

    if ( misc == 1 )
      stat = player->convert_hybrid_stat( STAT_STR_AGI_INT );

    if ( stat != STAT_NONE )
      return add_stat( stat, a, c );
  }
  else if ( eff.subtype() == A_MOD_INCREASE_HEALTH || eff.subtype() == A_MOD_INCREASE_HEALTH_2 )
  {
    return add_stat( STAT_MAX_HEALTH, a, c );
  }

  return do_error( "STAT_NONE" );
}

stat_buff_t* stat_buff_t::set_stat_from_effect( size_t i, double a, const stat_check_fn& c )
{
  if ( is_fallback )
    return this;

  manual_stats_added = false;

  return add_stat_from_effect( i, a, c );
}

stat_buff_t* stat_buff_t::add_stat_from_effect_type( effect_subtype_t type, double a, const stat_check_fn& c )
{
  if ( is_fallback )
    return this;

  const auto& eff = spell_data_t::find_spelleffect( data(), E_APPLY_AURA, type );
  assert( eff.ok() && "Effect type not found in stat buff" );

  return add_stat_from_effect( eff.index() + 1, a, c );
}

stat_buff_t* stat_buff_t::set_stat_from_effect_type( effect_subtype_t type, double a, const stat_check_fn& c )
{
  if ( is_fallback )
    return this;

  manual_stats_added = false;

  return add_stat_from_effect_type( type, a, c );
}

double stat_buff_t::buff_stat_stack_amount( const buff_stat_t& buff_stat, int stacks ) const
{
  return std::max( 1.0, std::fabs( buff_stat.amount ) ) * stacks;
}

void stat_buff_t::update_player_buff_stat( buff_stat_t& buff_stat, int stacks )
{
  // Blizzard likes to use effect coefficients that give (almost) exact values at the
  // intended level. Small floating point conversion errors can add up to give the wrong
  // value. We compensate by increasing the absolute value by a tiny bit before truncating.
  double _val = buff_stat_stack_amount( buff_stat, stacks );
  _val = std::copysign( std::trunc( _val + stat_fp_epsilon ), buff_stat.amount );

  double delta = _val - buff_stat.current_value;

  if ( delta > 0 )
  {
    player->stat_gain( buff_stat.stat, delta, stat_gain, nullptr, buff_duration() > 0_ms );
  }
  else if ( delta < 0 )
  {
    player->stat_loss( buff_stat.stat, std::fabs( delta ), stat_gain, nullptr, buff_duration() > 0_ms );
  }

  buff_stat.current_value += delta;
}

void stat_buff_t::bump( int stacks, double value )
{
  buff_t::bump( stacks, value );

  for ( auto& buff_stat : stats )
  {
    if ( buff_stat.check_func && !buff_stat.check_func( *this ) )
      continue;

    update_player_buff_stat( buff_stat, current_stack );
  }
}

void stat_buff_t::decrement( int stacks, double /* value */ )
{
  if ( stacks == 0 || current_stack <= stacks )
  {
    expire();
  }
  else
  {
    int old_stack = current_stack;
    int new_stack = old_stack - stacks;

    if ( as<std::size_t>( current_stack ) < stack_uptime.size() )
      stack_uptime[ current_stack ].update( false, sim->current_time() );

    for ( auto& buff_stat : stats )
    {
      update_player_buff_stat( buff_stat, new_stack );
    }

    current_stack -= stacks;

    invalidate_cache();

    if ( as<std::size_t>( current_stack ) < stack_uptime.size() )
      stack_uptime[ current_stack ].update( true, sim->current_time() );

    sim->print_log( "{} decrements {} by {} to {} stacks", *player, *this, stacks, current_stack );

    if ( old_stack != current_stack )
    {
      if ( sim->buff_stack_uptime_timeline && !quiet )
        update_stack_uptime_array( sim->current_time(), old_stack );

      last_stack_change = sim->current_time();

      for ( const auto& cb : stack_change_callback )
        cb( this, old_stack, current_stack );
    }

    if ( player )
      player->trigger_ready();
  }
}

void stat_buff_t::expire_override( int expiration_stacks, timespan_t remaining_duration )
{
  for ( auto& buff_stat : stats )
  {
    if ( buff_stat.current_value > 0 )
    {
      player->stat_loss( buff_stat.stat, buff_stat.current_value, stat_gain, nullptr,
                         buff_duration() > timespan_t::zero() );
    }
    else if ( buff_stat.current_value < 0 )
    {
      player->stat_gain( buff_stat.stat, std::fabs( buff_stat.current_value ), stat_gain, nullptr,
                         buff_duration() > timespan_t::zero() );
    }
    buff_stat.current_value = 0;
  }

  buff_t::expire_override( expiration_stacks, remaining_duration );
}

// ==========================================================================
// COST_REDUCTION_BUFF
// ==========================================================================

cost_reduction_buff_t::cost_reduction_buff_t(actor_pair_t q, util::string_view name)
  : cost_reduction_buff_t(q, name, spell_data_t::nil(), nullptr)
{

}

cost_reduction_buff_t::cost_reduction_buff_t( actor_pair_t q, util::string_view name, const spell_data_t* spell,
                                              const item_t* item )
  : buff_t( q, name, spell, item ), amount(), school( SCHOOL_NONE )
{
  // Detect school / amount
  for ( size_t i = 1, e = data().effect_count(); i <= e; i++ )
  {
    const spelleffect_data_t& effect = data().effectN( i );
    if ( effect.type() != E_APPLY_AURA || effect.subtype() != A_MOD_POWER_COST_SCHOOL )
      continue;

    school = dbc::get_school_type( effect.misc_value1() );

    if ( item )
      amount = util::round( effect.average( item ) );
    else
      amount = effect.average( player, std::min( MAX_LEVEL, player->level() ) );

    amount = std::fabs( amount );
    break;
  }
}

void cost_reduction_buff_t::bump( int stacks, double value )
{
  if ( value > 0 )
  {
    amount = value;
  }
  buff_t::bump( stacks );
  double delta = amount * current_stack - current_value;
  if ( delta > 0 )
  {
    player->cost_reduction_gain( school, delta );
    current_value += delta;
  }
  else
    assert( delta == 0 );
}

void cost_reduction_buff_t::decrement( int stacks, double /* value */ )
{
  if ( stacks == 0 || current_stack <= stacks )
  {
    expire();
  }
  else
  {
    double delta = amount * stacks;
    player->cost_reduction_loss( school, delta );
    current_stack -= stacks;
    current_value -= delta;
  }
}

void cost_reduction_buff_t::expire_override( int expiration_stacks, timespan_t remaining_duration )
{
  player->cost_reduction_loss( school, current_value );

  buff_t::expire_override( expiration_stacks, remaining_duration );
}

cost_reduction_buff_t* cost_reduction_buff_t::set_reduction( school_e s, double a )
{
  if ( is_fallback )
    return this;

  amount = a;
  school = s;
  return this;
}

// ==========================================================================
// ABSORB_BUFF
// ==========================================================================

absorb_buff_t::absorb_buff_t(actor_pair_t q, util::string_view name)
  : absorb_buff_t(q, name, spell_data_t::nil(), nullptr)
{

}

absorb_buff_t::absorb_buff_t( actor_pair_t q, util::string_view name, const spell_data_t* spell, const item_t* item )
  : buff_t( q, name, spell, item ),
    absorb_school( SCHOOL_CHAOS ),
    absorb_source(),
    absorb_gain(),
    high_priority( false ),
    cumulative( false ),
    eligibility()
{
  assert( player && "Absorb Buffs only supported for player!" );

  set_absorb_school( absorb_school );
}

void absorb_buff_t::start( int stacks, double value, timespan_t duration )
{
  if ( max_stack() == 0 )
    return;

  buff_t::start( stacks, value, duration );

  assert( range::find( player->absorb_buff_list, this ) == player->absorb_buff_list.end() &&
          "Attempting to add absorb buff to absorb_buffs list twice" );

  player->absorb_buff_list.push_back( this );
}

void absorb_buff_t::refresh( int stacks, double value, timespan_t duration )
{
  if ( cumulative )
    value += current_value;

  buff_t::refresh( stacks, value, duration );
}

void absorb_buff_t::expire_override( int expiration_stacks, timespan_t remaining_duration )
{
  buff_t::expire_override( expiration_stacks, remaining_duration );

  if ( !player )
  {
    return;
  }

  auto it = range::find( player->absorb_buff_list, this );
  if ( it != player->absorb_buff_list.end() )
    player->absorb_buff_list.erase( it );
}

double absorb_buff_t::consume( double amount, action_state_t* state )
{
  // Limit the consumption to the current size of the buff.
  amount = std::min( amount, current_value );

  if ( absorb_source )
    absorb_source->add_result( amount, 0, result_amount_type::ABSORB, RESULT_HIT, BLOCK_RESULT_UNBLOCKED, player );

  if ( absorb_gain )
    absorb_gain->add( RESOURCE_HEALTH, amount, 0 );

  current_value -= amount;

  sim->print_debug( "{} {} absorbs {:.6f} (remaining: {:.7g})", *player, *this, amount, current_value );

  absorb_used( amount, state ? state->action->player : nullptr );

  if ( current_value <= 0 )
    expire();

  return amount;
}

absorb_buff_t* absorb_buff_t::set_absorb_gain( gain_t* g )
{
  if ( is_fallback )
    return this;

  absorb_gain = g;
  return this;
}

absorb_buff_t* absorb_buff_t::set_absorb_source( stats_t* s )
{
  if ( is_fallback )
    return this;

  if ( s )
    s->type = STATS_ABSORB;
  absorb_source = s;
  return this;
}

absorb_buff_t* absorb_buff_t::set_absorb_school( school_e s )
{
  if ( is_fallback )
    return this;

  absorb_school = s;
  if ( s == SCHOOL_CHAOS )
  {
    for ( size_t i = 1, e = data().effect_count(); i <= e; i++ )
    {
      const spelleffect_data_t& effect = data().effectN( i );
      if ( effect.type() != E_APPLY_AURA || effect.subtype() != A_SCHOOL_ABSORB )
        continue;

      absorb_school = dbc::get_school_type( effect.misc_value1() );
      if ( manual_chance == DEFAULT_VALUE() )
      {
        if ( item )
          default_value = util::round( effect.average( item ) );
        else
          default_value = effect.average( player, std::min( MAX_LEVEL, player->level() ) );
      }
      break;
    }
  }
  return this;
}

absorb_buff_t* absorb_buff_t::set_absorb_high_priority( bool hp )
{
  if ( is_fallback )
    return this;

  high_priority = hp;
  // TODO: check if player absorb_priority and instant_absorb_list could be automatically
  // populated from here somehow.
  return this;
}

absorb_buff_t* absorb_buff_t::set_absorb_eligibility( absorb_eligibility e )
{
  if ( is_fallback )
    return this;

  eligibility = std::move(e);
  // TODO: check if player absorb_priority and instant_absorb_list could be automatically
  // populated from here somehow.
  return this;
}

absorb_buff_t* absorb_buff_t::set_cumulative( bool c )
{
  if ( is_fallback )
    return this;

  cumulative = c;
  return this;
}

// ==========================================================================
// MOVEMENT_BUFF
// ==========================================================================

bool movement_buff_t::trigger( int stacks, double value, double chance, timespan_t duration )
{

  for ( const auto& cb : player->callbacks_on_movement )
  {
    if ( !check() )
      cb( true );
  }

  return buff_t::trigger( stacks, value, chance, duration );
}

void movement_buff_t::expire_override( int expiration_stacks, timespan_t remaining_duration )
{
  buff_t::expire_override( expiration_stacks, remaining_duration );
  source->finish_moving();

  for ( const auto& cb : player->callbacks_on_movement )
  {
    cb( false );
  }
}

// ==========================================================================
// DAMAGE_BUFF
// ==========================================================================

damage_buff_t::damage_buff_t( actor_pair_t q, util::string_view name )
  : damage_buff_t( q, name, spell_data_t::nil() )
{
}

damage_buff_t::damage_buff_t( actor_pair_t q, util::string_view name, const spell_data_t* spell, bool parse_data )
  : buff_t( q, name, spell, nullptr ),
  is_stacking( true )
{
  if ( parse_data )
  {
    parse_spell_data( spell );
  }
}

damage_buff_t::damage_buff_t( actor_pair_t q, util::string_view name, const spell_data_t* spell, double talent_value )
  : buff_t( q, name, spell, nullptr ),
  is_stacking( true )
{
  parse_spell_data( spell, 0.0, talent_value );
}

damage_buff_t* damage_buff_t::parse_spell_data( const spell_data_t* spell, double conduit_value, double talent_value )
{
  if ( is_fallback || !spell->ok() )
    return this;

  for ( size_t idx = 1; idx <= spell->effect_count(); idx++ )
  {
    const spelleffect_data_t& e = spell->effectN( idx );
    if ( !e.ok() || e.type() != E_APPLY_AURA )
      continue;

    double multiplier = 0.0;

    // Pass down the conduit override value only if this is the first effect
    if ( conduit_value != 0.0 && idx == 1 )
      multiplier = conduit_value;

    // If a talent value is supplied, overwrite all entries with it
    if ( talent_value != 0.0 )
      multiplier = talent_value;

    if ( e.subtype() == A_MOD_AUTO_ATTACK_PCT || e.subtype() == A_MOD_AUTO_ATTACK_FROM_CASTER )
    {
      assert( auto_attack_mod.multiplier == 1.0 && auto_attack_mod.effect_idx == 0 && "AA multiplier has already been set" );
      set_auto_attack_mod( spell, idx, multiplier );
      sim->print_debug( "{} damage buff AA multiplier initialized to {}", *this, auto_attack_mod.multiplier );
    }
    else if ( e.subtype() == A_ADD_PCT_MODIFIER )
    {
      if ( e.property_type() == P_GENERIC )
      {
        assert( direct_mod.multiplier == 1.0 && direct_mod.effect_idx == 0 && "Direct multiplier has already been set" );
        set_direct_mod( spell, idx, multiplier );
        sim->print_debug( "{} damage buff direct multiplier initialized to {}", *this, direct_mod.multiplier );
      }
      else if ( e.property_type() == P_TICK_DAMAGE )
      {
        assert( periodic_mod.multiplier == 1.0 && periodic_mod.effect_idx == 0 && "Periodic multiplier has already been set" );
        set_periodic_mod( spell, idx, multiplier );
        sim->print_debug( "{} damage buff periodic multiplier initialized to {}", *this, periodic_mod.multiplier );
      }
    }
    else if ( e.subtype() == A_ADD_FLAT_MODIFIER )
    {
      if ( e.property_type() == P_CRIT )
      {
        assert( crit_chance_mod.multiplier == 1.0 && crit_chance_mod.effect_idx == 0 && "Crit chance multiplier has already been set" );
        set_crit_chance_mod( spell, idx, multiplier );
        add_invalidate( CACHE_CRIT_CHANCE );
        sim->print_debug( "{} damage buff crit chance multiplier initialized to {}", *this, crit_chance_mod.multiplier );
      }
    }
    else if ( e.subtype() == A_MOD_CRIT_CHANCE_FROM_CASTER_SPELLS )
    {
      assert( crit_chance_mod.multiplier == 1.0 && crit_chance_mod.effect_idx == 0 && "Crit chance multiplier has already been set" );
      set_crit_chance_mod( spell, idx, multiplier );
      sim->print_debug( "{} damage debuff crit chance multiplier initialized to {}", *this, crit_chance_mod.multiplier );
    }
    else if ( e.subtype() == A_MOD_DAMAGE_FROM_CASTER_SPELLS )
    {
      assert( direct_mod.multiplier == 1.0 && direct_mod.effect_idx == 0 && "Direct multiplier has already been set" );
      assert( periodic_mod.multiplier == 1.0 && periodic_mod.effect_idx == 0 && "Periodic multiplier has already been set" );
      set_direct_mod( spell, idx, multiplier );
      set_periodic_mod( spell, idx, multiplier );
      sim->print_debug( "{} damage debuff direct multiplier initialized to {}", *this, direct_mod.multiplier );
      sim->print_debug( "{} damage debuff periodic multiplier initialized to {}", *this, periodic_mod.multiplier );
    }
    else if ( e.subtype() == A_ADD_PCT_LABEL_MODIFIER )
    {
      if ( e.property_type() == P_GENERIC )
      {
        if ( multiplier != 0.0 && direct_mod.multiplier == 1.0 && direct_mod.effect_idx == 0 )
          set_direct_mod( spell, idx, multiplier );

        if ( direct_mod.multiplier == 1.0 + ( multiplier == 0.0 ? e.percent() : multiplier ) )
        {
          direct_mod.labels.push_back( e.misc_value2() );
        }
        else if ( direct_mod.multiplier == 1.0 )
        {
          sim->print_debug( "{} no existing direct effect value of {}, setting direct value to match",
                            *this, ( multiplier == 0.0 ? e.percent() : multiplier ), direct_mod.multiplier );
          set_direct_mod( spell, idx, multiplier );
          direct_mod.labels.push_back( e.misc_value2() );
        }
        else
        {
          sim->print_debug( "{} ignoring label modifier of {} due to not matching existing direct effect value of {}",
                            *this, ( multiplier == 0.0 ? e.percent() : multiplier ), direct_mod.multiplier );
        }
      }
      else if ( e.property_type() == P_TICK_DAMAGE )
      {
        if ( multiplier != 0.0 && periodic_mod.multiplier == 1.0 && periodic_mod.effect_idx == 0 )
          set_periodic_mod( spell, idx, multiplier );

        if ( periodic_mod.multiplier == 1.0 + ( multiplier == 0.0 ? e.percent() : multiplier ) )
        {
          periodic_mod.labels.push_back( e.misc_value2() );
        }
        else if ( periodic_mod.multiplier == 1.0 )
        {
          sim->print_debug( "{} no existing periodic effect value of {}, setting periodic value to match",
                            *this, ( multiplier == 0.0 ? e.percent() : multiplier ), periodic_mod.multiplier );
          set_periodic_mod( spell, idx, multiplier );
          periodic_mod.labels.push_back( e.misc_value2() );
        }
        else
        {
          sim->print_debug( "{} ignoring label modifier of {} due to not matching existing periodic effect value of {}",
                            *this, ( multiplier == 0.0 ? e.percent() : multiplier ), periodic_mod.multiplier );
        }
      }
    }
    else if ( e.subtype() == A_ADD_FLAT_LABEL_MODIFIER && e.property_type() == P_CRIT )
    {
      if ( crit_chance_mod.multiplier == 1.0 && crit_chance_mod.effect_idx == 0 )
        set_crit_chance_mod( spell, idx, multiplier );

      assert( crit_chance_mod.multiplier == 1.0 + ( multiplier == 0.0 ? e.percent() : multiplier )
              && "Additional label modifiers do not match the existing crit chance effect value" );

      crit_chance_mod.labels.push_back( e.misc_value2() );
    }
  }

  return this;
}

damage_buff_t* damage_buff_t::apply_dynamic_buff_multiplier( buff_t* buff )
{
  if ( is_fallback )
    return this;

  auto parse_dynamic_buff_multiplier_for_mod = [ this, buff ]( damage_buff_modifier_t& mod ) {

    if ( !mod.s_data || !mod.s_data->ok() )
      return false;

    if ( range::contains( mod.dynamic_buff_multipliers, buff, []( const auto& entry ) { return entry.first; } ) )
      return false;

    for ( const spelleffect_data_t& effect : buff->data().effects() )
    {
      if ( !effect.ok() || effect.type() != E_APPLY_AURA )
        continue;

      if ( ( effect.subtype() == A_ADD_PCT_MODIFIER && mod.s_data->affected_by( effect ) ) ||
           ( effect.subtype() == A_ADD_PCT_LABEL_MODIFIER && mod.s_data->affected_by_label( effect ) ) )
      {
        if ( effect.property_type() == P_EFFECTS )
        {
          mod.dynamic_buff_multipliers.push_back( { buff, effect.percent() } );
          sim->print_debug( "{} damage buff registering dynamic buff multiplier {} of {}%", *this, *buff, effect.base_value() );
          return true;
        }
        else if ( mod.effect_idx >= 1 && mod.effect_idx <= 5 )
        {
          constexpr property_type_t effect_types[] = { P_EFFECT_1, P_EFFECT_2, P_EFFECT_3, P_EFFECT_4, P_EFFECT_5 };
          if ( effect.property_type() == effect_types[ mod.effect_idx - 1 ] )
          {
            mod.dynamic_buff_multipliers.push_back( { buff, effect.percent() } );
            sim->print_debug( "{} damage buff registering dynamic buff multiplier {} of {}%", *this, *buff, effect.base_value() );
            return true;
          }
        }
      }
    }

    return false;
  };

  parse_dynamic_buff_multiplier_for_mod( direct_mod );
  parse_dynamic_buff_multiplier_for_mod( periodic_mod );
  parse_dynamic_buff_multiplier_for_mod( auto_attack_mod );
  if ( parse_dynamic_buff_multiplier_for_mod( crit_chance_mod ) )
    buff->add_invalidate( CACHE_CRIT_CHANCE );

  return this;
}

damage_buff_t* damage_buff_t::apply_mod_affecting_effect( damage_buff_modifier_t& mod, const spelleffect_data_t& effect )
{
  if ( is_fallback || !mod.s_data || !mod.s_data->ok() )
    return this;

  if ( ( effect.subtype() == A_ADD_FLAT_MODIFIER && mod.s_data->affected_by( effect ) ) ||
       ( effect.subtype() == A_ADD_FLAT_LABEL_MODIFIER && mod.s_data->affected_by_label( effect ) ) )
  {
    if ( effect.property_type() == P_EFFECTS )
    {
      mod.multiplier += effect.percent();
      sim->print_debug( "{} damage buff multiplier modified by {}% to {}", *this, effect.base_value(), mod.multiplier );
    }
    else if( mod.effect_idx >= 1 && mod.effect_idx <= 5 )
    {
      constexpr property_type_t effect_types[] = { P_EFFECT_1, P_EFFECT_2, P_EFFECT_3, P_EFFECT_4, P_EFFECT_5 };
      if ( effect.property_type() == effect_types[ mod.effect_idx - 1 ] )
      {
        mod.multiplier += effect.percent();
        sim->print_debug( "{} damage buff multiplier modified by {}% to {}", *this, effect.base_value(), mod.multiplier );
      }
    }
  }

  // TODO -- Need to post-validate that modifiers are correctly applied to label effects as well
  // As Blizzard has started mixing whitelist and label modifiers in the same buffs, these may go out of sync
  // For now, just assume the side-by-side label modifiers are correct. May need to split out in the future

  return this;
}

damage_buff_t* damage_buff_t::set_buff_mod( damage_buff_modifier_t& mod, double multiplier )
{
  if ( is_fallback )
    return this;

  return set_buff_mod( mod, spell_data_t::nil(), 0, multiplier, 1.0 );
}

damage_buff_t* damage_buff_t::set_buff_mod( damage_buff_modifier_t& mod, const spell_data_t* s, size_t effect_idx, double multiplier, double initial_multiplier )
{
  if ( is_fallback )
    return this;

  assert( mod.s_data == nullptr && mod.effect_idx == 0 );
  mod.initial_multiplier = initial_multiplier;

  if( multiplier != 0.0 )
    mod.multiplier = 1.0 + multiplier;

  if ( !s->ok() || !s->effectN( effect_idx ).ok() || ( s->effectN( effect_idx ).type() != E_APPLY_AURA &&
                                                       s->effectN( effect_idx ).type() != E_APPLY_AREA_AURA_PARTY ) )
    return this;

  if ( multiplier == 0.0 )
    mod.multiplier = 1.0 + s->effectN( effect_idx ).percent();

  mod.s_data = s;
  mod.effect_idx = effect_idx;
  return this;
}

damage_buff_t* damage_buff_t::set_is_stacking_mod( bool value )
{
  if ( is_fallback )
    return this;

  is_stacking = value;
  return this;
}

damage_buff_t* damage_buff_t::set_direct_mod( double multiplier )
{
  if ( is_fallback )
    return this;

  return set_direct_mod( spell_data_t::nil(), 0, multiplier );
}

damage_buff_t* damage_buff_t::set_direct_mod( const spell_data_t* s, size_t effect_idx, double multiplier, double initial_multiplier )
{
  if ( is_fallback )
    return this;

  return set_buff_mod( direct_mod, s, effect_idx, multiplier, initial_multiplier );
}

damage_buff_t* damage_buff_t::set_periodic_mod( double multiplier )
{
  if ( is_fallback )
    return this;

  return set_periodic_mod( spell_data_t::nil(), 0, multiplier );
}

damage_buff_t* damage_buff_t::set_periodic_mod( const spell_data_t* s, size_t effect_idx, double multiplier, double initial_multiplier )
{
  if ( is_fallback )
    return this;

  return set_buff_mod( periodic_mod, s, effect_idx, multiplier, initial_multiplier );
}

damage_buff_t* damage_buff_t::set_auto_attack_mod( double multiplier )
{
  if ( is_fallback )
    return this;

  return set_auto_attack_mod( spell_data_t::nil(), 0, multiplier );
}

damage_buff_t* damage_buff_t::set_auto_attack_mod( const spell_data_t* s, size_t effect_idx, double multiplier, double initial_multiplier )
{
  if ( is_fallback )
    return this;

  return set_buff_mod( auto_attack_mod, s, effect_idx, multiplier, initial_multiplier );
}

damage_buff_t* damage_buff_t::set_crit_chance_mod( double multiplier )
{
  if ( is_fallback )
    return this;

  return set_crit_chance_mod( spell_data_t::nil(), 0, multiplier );
}

damage_buff_t* damage_buff_t::set_crit_chance_mod( const spell_data_t* s, size_t effect_idx, double multiplier )
{
  if ( is_fallback )
    return this;

  return set_buff_mod( crit_chance_mod, s, effect_idx, multiplier, 1.0 );
}

bool damage_buff_t::is_affecting( const spell_data_t* s )
{
  return is_affecting_direct( s ) || is_affecting_periodic( s ) || is_affecting_crit_chance( s );
}

bool damage_buff_t::is_affecting_direct( const spell_data_t* s )
{
  if ( !direct_mod.s_data || !direct_mod.s_data->ok() || direct_mod.effect_idx == 0 )
    return false;

  if ( s->affected_by( direct_mod.s_data->effectN( direct_mod.effect_idx ) ) )
    return true;

  if ( s->affected_by_label( direct_mod.s_data->effectN( direct_mod.effect_idx ) ) )
    return true;

  for ( int label : direct_mod.labels )
  {
    if ( s->affected_by_label( label ) )
      return true;
  }

  return false;
}

bool damage_buff_t::is_affecting_periodic( const spell_data_t* s )
{
  if ( !periodic_mod.s_data || !periodic_mod.s_data->ok() || periodic_mod.effect_idx == 0 )
    return false;

  if ( s->affected_by( periodic_mod.s_data->effectN( periodic_mod.effect_idx ) ) )
    return true;

  if ( s->affected_by_label( periodic_mod.s_data->effectN( periodic_mod.effect_idx ) ) )
    return true;

  for ( int label : periodic_mod.labels )
  {
    if ( s->affected_by_label( label ) )
      return true;
  }

  return false;
}

bool damage_buff_t::is_affecting_crit_chance( const spell_data_t* s )
{
  if ( !crit_chance_mod.s_data || !crit_chance_mod.s_data->ok() || crit_chance_mod.effect_idx == 0 )
    return false;

  if ( s->affected_by( crit_chance_mod.s_data->effectN( crit_chance_mod.effect_idx ) ) )
    return true;

  if ( s->affected_by_label( crit_chance_mod.s_data->effectN( crit_chance_mod.effect_idx ) ) )
    return true;

  for ( int label : crit_chance_mod.labels )
  {
    if ( s->affected_by_label( label ) )
      return true;
  }

  return false;
}

double damage_buff_t::get_mod_multiplier( const damage_buff_modifier_t& mod ) const
{
  if ( mod.dynamic_buff_multipliers.empty() )
    return mod.multiplier;

  double multiplier = mod.multiplier - 1.0;

  // Iterate over dynamic buff multipliers, check they are currently active, and apply if they are
  for ( const std::pair<buff_t*, double>& dynamic_buff_multiplier : mod.dynamic_buff_multipliers )
  {
    if ( dynamic_buff_multiplier.first->check() )
    {
      multiplier *= 1.0 + dynamic_buff_multiplier.second;
    }
  }

  return 1.0 + multiplier;
}
