#include "class_modules/apl/apl_demon_hunter.hpp"

#include "player/action_priority_list.hpp"
#include "player/player.hpp"

namespace demon_hunter_apl
{

std::string potion_devourer( const player_t* p )
{
  return ( p->true_level > 80 ) ? "potion_of_recklessness_2" : "tempered_potion_3";
}

std::string potion_havoc( const player_t* p )
{
  return ( p->true_level > 80 ) ? "potion_of_recklessness_2" : "tempered_potion_3";
}

std::string potion_vengeance( const player_t* p )
{
  return ( p->true_level > 80 ) ? "lights_potential_2" : "tempered_potion_3";
}

std::string flask_devourer( const player_t* p )
{
  return ( p->true_level > 80 ) ? "flask_of_the_magisters_2" : "flask_of_alchemical_chaos_3";
}

std::string flask_havoc( const player_t* p )
{
  return ( p->true_level > 80 ) ? "flask_of_the_shattered_sun_2" : "flask_of_alchemical_chaos_3";
}

std::string flask_vengeance( const player_t* p )
{
  return ( p->true_level > 80 ) ? "flask_of_the_magisters_2" : "flask_of_alchemical_chaos_3";
}

std::string food_devourer( const player_t* p )
{
  return ( p->true_level > 80 ) ? "blooming_feast" : "feast_of_the_divine_day";
}

std::string food_havoc( const player_t* p )
{
  return ( p->true_level > 80 ) ? "blooming_feast" : "feast_of_the_divine_day";
}

std::string food_vengeance( const player_t* p )
{
  return ( p->true_level > 80 ) ? "silvermoon_parade" : "feast_of_the_divine_day";
}

std::string rune( const player_t* p )
{
  return ( p->true_level > 80 ) ? "void_touched" : "crystallized";
}

std::string temporary_enchant_devourer( const player_t* p )
{
  return ( p->true_level > 80 ) ? "main_hand:thalassian_phoenix_oil_2/off_hand:thalassian_phoenix_oil_2" : "main_hand:algari_mana_oil_3/off_hand:algari_mana_oil_3";
}

std::string temporary_enchant_havoc( const player_t* p )
{
  return ( p->true_level > 80 ) ? "main_hand:thalassian_phoenix_oil_2/off_hand:thalassian_phoenix_oil_2" : "main_hand:ironclaw_whetstone_3/off_hand:ironclaw_whetstone_3";
}

std::string temporary_enchant_vengeance( const player_t* p )
{
  return ( p->true_level > 80 ) ? "main_hand:thalassian_phoenix_oil_2/off_hand:thalassian_phoenix_oil_2" : "main_hand:ironclaw_whetstone_3/off_hand:ironclaw_whetstone_3";
}

// clang-format off
//devourer_apl_start
void devourer( player_t* p )
{
  action_priority_list_t* default_ = p->get_action_priority_list( "default" );
  action_priority_list_t* precombat = p->get_action_priority_list( "precombat" );
  action_priority_list_t* annihilator = p->get_action_priority_list( "annihilator" );
  action_priority_list_t* annihilator_meta = p->get_action_priority_list( "annihilator_meta" );
  action_priority_list_t* annihilator_out = p->get_action_priority_list( "annihilator_out" );
  action_priority_list_t* voidscarred = p->get_action_priority_list( "voidscarred" );
  action_priority_list_t* voidscarred_meta = p->get_action_priority_list( "voidscarred_meta" );
  action_priority_list_t* voidscarred_out = p->get_action_priority_list( "voidscarred_out" );
  action_priority_list_t* voidscarred_hunt_entry = p->get_action_priority_list( "voidscarred_hunt_entry" );
  action_priority_list_t* variables = p->get_action_priority_list( "variables" );
  action_priority_list_t* cooldowns = p->get_action_priority_list( "cooldowns" );
  action_priority_list_t* reaps = p->get_action_priority_list( "reaps" );

  precombat->add_action( "snapshot_stats" );
  precombat->add_action( "variable,name=trinket_1_buffs,value=trinket.1.has_buff.intellect|trinket.1.has_buff.mastery|trinket.1.has_buff.versatility|trinket.1.has_buff.haste|trinket.1.has_buff.crit" );
  precombat->add_action( "variable,name=trinket_2_buffs,value=trinket.2.has_buff.intellect|trinket.2.has_buff.mastery|trinket.2.has_buff.versatility|trinket.2.has_buff.haste|trinket.2.has_buff.crit" );
  precombat->add_action( "variable,name=trinket_priority,op=setif,value=2,value_else=1,condition=!variable.trinket_1_buffs&variable.trinket_2_buffs|variable.trinket_2_buffs&((trinket.2.proc.any_dps.duration)*trinket.2.proc.any_dps.default_value)>((trinket.1.proc.any_dps.duration)*trinket.1.proc.any_dps.default_value)" );
  precombat->add_action( "variable,name=damage_trinket_priority,op=setif,value=2,value_else=1,condition=!variable.trinket_1_buffs&!variable.trinket_2_buffs&trinket.2.ilvl>=trinket.1.ilvl" );
  precombat->add_action( "arcane_torrent" );
  precombat->add_action( "soul_immolation" );
  precombat->add_action( "consume" );

  default_->add_action( "retarget,target_if=max:target.time_to_die,line_cd=0.25" );
  default_->add_action( "call_action_list,name=variables" );
  default_->add_action( "call_action_list,name=cooldowns" );
  default_->add_action( "call_action_list,name=reaps,if=target.time_to_die<=4&action.reap.souls_consumed>=1&!buff.soulburst.up" );
  default_->add_action( "run_action_list,name=annihilator,if=hero_tree.annihilator" );
  default_->add_action( "run_action_list,name=voidscarred,if=hero_tree.voidscarred" );

  annihilator->add_action( "run_action_list,name=annihilator_meta,if=buff.metamorphosis.up" );
  annihilator->add_action( "run_action_list,name=annihilator_out" );

  annihilator_meta->add_action( "pick_up_fragment,use_off_gcd=1,if=cooldown.reap.remains&(talent.eradicate&target.time_to_die<15|soul_fragments+buff.collapsing_star_stacking.stack>=30&buff.collapsing_star_stacking.stack<30)" );
  annihilator_meta->add_action( "devour,if=buff.soulburst.up&active_enemies=1" );
  annihilator_meta->add_action( "the_hunt,if=talent.devourers_bite" );
  annihilator_meta->add_action( "voidblade,if=talent.devourers_bite&active_enemies<=3" );
  annihilator_meta->add_action( "collapsing_star,if=fight_remains<10" );
  annihilator_meta->add_action( "void_ray,if=talent.eradicate&active_enemies>1&!buff.eradicate.up" );
  annihilator_meta->add_action( "collapsing_star,if=prev_gcd.1.void_ray" );
  annihilator_meta->add_action( "eradicate,if=buff.voidfall_spending.up" );
  annihilator_meta->add_action( "collapsing_star,if=active_enemies>1|cooldown.void_ray.remains" );
  annihilator_meta->add_action( "devour,if=buff.eradicate.up&!buff.voidfall_spending.up&buff.moment_of_craving.remains>=4&fury.deficit<=70" );
  annihilator_meta->add_action( "call_action_list,name=reaps,if=(active_enemies=1|buff.eradicate.up)&action.reap.souls_consumed>=4&!(talent.devourers_bite&active_enemies=1&fury<void_metamorphosis_base_drain_ps*2)" );
  annihilator_meta->add_action( "call_action_list,name=reaps,if=!talent.eradicate&buff.collapsing_star_stacking.stack+action.reap.souls_consumed>=30&action.reap.souls_consumed>=4" );
  annihilator_meta->add_action( "void_ray,if=active_enemies>1|talent.eradicate|fury>=100|fury<55" );
  annihilator_meta->add_action( "call_action_list,name=reaps,if=variable.voidfall_dump" );
  annihilator_meta->add_action( "call_action_list,name=reaps,if=buff.collapsing_star_stacking.stack+action.reap.souls_consumed>=30&action.reap.souls_consumed>=4&fight_remains<45" );
  annihilator_meta->add_action( "cull,if=talent.eradicate&buff.voidfall_spending.up" );
  annihilator_meta->add_action( "soul_immolation,if=active_dot.soul_immolation=0&fury<void_metamorphosis_base_drain_ps&fury<40&(cooldown.reap.remains|active_enemies=1)" );
  annihilator_meta->add_action( "devour" );

  annihilator_out->add_action( "pick_up_fragment,mode=nearest,type=all,use_off_gcd=1,line_cd=0.6,if=!buff.void_metamorphosis_stack.at_max_stacks&buff.void_metamorphosis_stack.stack>=buff.void_metamorphosis_stack.max_stack-2" );
  annihilator_out->add_action( "voidblade,if=talent.devourers_bite&active_enemies<=3&buff.void_metamorphosis_stack.at_max_stacks" );
  annihilator_out->add_action( "void_ray,if=talent.eradicate&active_enemies>1&buff.void_metamorphosis_stack.at_max_stacks&fury>=100" );
  annihilator_out->add_action( "metamorphosis" );
  annihilator_out->add_action( "consume,if=buff.soulburst.up" );
  annihilator_out->add_action( "call_action_list,name=reaps,if=(active_enemies=1|buff.eradicate.up)&action.reap.souls_consumed>=4" );
  annihilator_out->add_action( "call_action_list,name=reaps,if=!talent.eradicate&action.reap.souls_consumed>=8" );
  annihilator_out->add_action( "void_ray" );
  annihilator_out->add_action( "call_action_list,name=reaps,if=variable.voidfall_dump" );
  annihilator_out->add_action( "soul_immolation,if=active_dot.soul_immolation=0&(active_enemies>1|talent.eradicate)" );
  annihilator_out->add_action( "consume" );

  voidscarred->add_action( "run_action_list,name=voidscarred_meta,if=buff.metamorphosis.up" );
  voidscarred->add_action( "run_action_list,name=voidscarred_out" );

  voidscarred_meta->add_action( "vengeful_retreat,use_off_gcd=1,if=buff.voidstep.up" );
  voidscarred_meta->add_action( "void_ray,if=variable.no_ray_this_window&(!talent.eradicate|active_enemies=1)" );
  voidscarred_meta->add_action( "eradicate,if=cooldown.void_ray.remains<gcd.max&!buff.soulburst.up" );
  voidscarred_meta->add_action( "void_ray,if=talent.eradicate&!buff.eradicate.up&active_enemies>1" );
  voidscarred_meta->add_action( "reapers_toll,if=active_enemies>1&buff.hungering_slash.remains<gcd.max*2" );
  voidscarred_meta->add_action( "predators_wake,if=buff.collapsing_star.up" );
  voidscarred_meta->add_action( "reapers_toll,if=talent.voidrush&buff.collapsing_star.up&cooldown.voidblade.remains<gcd.max" );
  voidscarred_meta->add_action( "pierce_the_veil,if=talent.voidrush&buff.collapsing_star.up" );
  voidscarred_meta->add_action( "collapsing_star" );
  voidscarred_meta->add_action( "devour,if=buff.soulburst.up" );
  voidscarred_meta->add_action( "reapers_toll,if=active_enemies>3&fury<void_metamorphosis_base_drain_ps*cooldown.void_ray.remains" );
  voidscarred_meta->add_action( "pierce_the_veil,if=active_enemies>3&time-buff.metamorphosis.last_trigger<15&buff.eradicate.up" );
  voidscarred_meta->add_action( "soul_immolation,if=active_enemies>3&!active_dot.soul_immolation&buff.collapsing_star_stacking.stack<15" );
  voidscarred_meta->add_action( "soul_immolation,if=active_enemies=1&!active_dot.soul_immolation&fury>=void_metamorphosis_base_drain_ps*2&buff.impending_apocalypse.stack>=2" );
  voidscarred_meta->add_action( "reapers_toll,if=soul_fragments<=8|active_enemies=1&buff.impending_apocalypse.stack>=3" );
  voidscarred_meta->add_action( "pierce_the_veil,if=active_enemies<4" );
  voidscarred_meta->add_action( "predators_wake,if=!buff.hungering_slash.up" );
  voidscarred_meta->add_action( "eradicate,if=active_enemies>3&buff.collapsing_star_stacking.stack+action.reap.souls_consumed>=30" );
  voidscarred_meta->add_action( "pierce_the_veil" );
  voidscarred_meta->add_action( "call_action_list,name=reaps,if=action.reap.souls_consumed>=4+4*(active_enemies>1&buff.eradicate.up)&!buff.soulburst.up&(active_enemies>1|buff.impending_apocalypse.stack<3|buff.collapsing_star_stacking.stack+action.reap.souls_consumed>=30|cooldown.void_ray.remains<action.void_ray.execute_time)" );
  voidscarred_meta->add_action( "void_ray" );
  voidscarred_meta->add_action( "soul_immolation,if=active_dot.soul_immolation=0&fury<void_metamorphosis_base_drain_ps" );
  voidscarred_meta->add_action( "devour" );

  voidscarred_out->add_action( "pick_up_fragment,mode=nearest,type=all,use_off_gcd=1,line_cd=0.3,if=!buff.void_metamorphosis_stack.at_max_stacks&buff.void_metamorphosis_stack.stack>=buff.void_metamorphosis_stack.max_stack-3" );
  voidscarred_out->add_action( "wait,sec=0.05,if=!buff.void_metamorphosis_stack.at_max_stacks&buff.void_metamorphosis_stack.stack>=buff.void_metamorphosis_stack.max_stack-1&(active_enemies=1&soul_fragments>=1|active_enemies>1&time-action.pick_up_fragment.last_used<1.5)" );
  voidscarred_out->add_action( "vengeful_retreat,use_off_gcd=1,if=buff.voidstep.up" );
  voidscarred_out->add_action( "consume,if=buff.soulburst.up&(active_enemies=1|talent.eradicate|buff.soulburst.remains<gcd.max)" );
  voidscarred_out->add_action( "call_action_list,name=voidscarred_hunt_entry,if=talent.the_hunt&active_enemies=1&buff.void_metamorphosis_stack.at_max_stacks" );
  voidscarred_out->add_action( "voidblade,if=active_enemies>1|!talent.the_hunt|!cooldown.the_hunt.ready" );
  voidscarred_out->add_action( "metamorphosis,if=buff.eradicate.up|!talent.eradicate|active_enemies=1|fight_remains<15" );
  voidscarred_out->add_action( "void_ray,if=talent.eradicate&active_enemies>1&!buff.eradicate.up" );
  voidscarred_out->add_action( "call_action_list,name=reaps,if=fury<100&fury+4*action.reap.souls_consumed+10*talent.scythes_embrace>=100&action.reap.souls_consumed>=1&!buff.soulburst.up" );
  voidscarred_out->add_action( "hungering_slash" );
  voidscarred_out->add_action( "soul_immolation,if=active_enemies>1&active_dot.soul_immolation=0" );
  voidscarred_out->add_action( "call_action_list,name=reaps,if=action.reap.souls_consumed>=4+4*(active_enemies>1&buff.eradicate.up)&!buff.soulburst.up" );
  voidscarred_out->add_action( "void_ray" );
  voidscarred_out->add_action( "soul_immolation,if=active_enemies=1&active_dot.soul_immolation=0" );
  voidscarred_out->add_action( "the_hunt,if=talent.eradicate&active_enemies>3&cooldown.voidblade.remains" );
  voidscarred_out->add_action( "consume" );

  voidscarred_hunt_entry->add_action( "voidblade,if=cooldown.the_hunt.ready" );
  voidscarred_hunt_entry->add_action( "vengeful_retreat,if=cooldown.the_hunt.ready" );
  voidscarred_hunt_entry->add_action( "the_hunt,if=buff.vengeful_retreat_movement.up" );

  variables->add_action( "variable,name=voidfall_dump,op=set,value=!buff.eradicate.up&(buff.voidfall_spending.stack>=3&prev_gcd.1.void_ray|buff.voidfall_spending.react>=3)" );
  variables->add_action( "variable,name=no_ray_this_window,op=set,value=action.void_ray.last_used<buff.metamorphosis.last_trigger" );

  cooldowns->add_action( "invoke_external_buff,name=power_infusion,if=buff.metamorphosis.up&!buff.power_infusion.up" );
  cooldowns->add_action( "potion,if=buff.metamorphosis.up|fight_remains<=30" );
  cooldowns->add_action( "use_item,slot=trinket1,if=buff.metamorphosis.up&(variable.no_ray_this_window|hero_tree.annihilator)&(!trinket.2.has_cooldown|trinket.2.cooldown.remains|variable.trinket_priority=1)|trinket.1.proc.any_dps.duration>=fight_remains|fight_remains<=trinket.1.buff.any_dps.duration" );
  cooldowns->add_action( "use_item,slot=trinket2,if=buff.metamorphosis.up&(variable.no_ray_this_window|hero_tree.annihilator)&(!trinket.1.has_cooldown|trinket.1.cooldown.remains|variable.trinket_priority=2)|trinket.2.proc.any_dps.duration>=fight_remains|fight_remains<=trinket.2.buff.any_dps.duration" );
  cooldowns->add_action( "use_item,use_off_gcd=1,slot=trinket1,if=!variable.trinket_1_buffs&(variable.damage_trinket_priority=1|trinket.2.cooldown.remains|trinket.2.cooldown.duration=0)&gcd.remains>0.1" );
  cooldowns->add_action( "use_item,use_off_gcd=1,slot=trinket2,if=!variable.trinket_2_buffs&(variable.damage_trinket_priority=2|trinket.1.cooldown.remains|trinket.1.cooldown.duration=0)&gcd.remains>0.1" );
  cooldowns->add_action( "use_item,slot=trinket1,if=!variable.trinket_1_buffs&(variable.damage_trinket_priority=1|trinket.2.cooldown.remains|trinket.2.cooldown.duration=0)" );
  cooldowns->add_action( "use_item,slot=trinket2,if=!variable.trinket_2_buffs&(variable.damage_trinket_priority=2|trinket.1.cooldown.remains|trinket.1.cooldown.duration=0)" );

  reaps->add_action( "eradicate" );
  reaps->add_action( "cull" );
  reaps->add_action( "reap" );
}
//devourer_apl_end
// clang-format on

// clang-format off
//devourer_ptr_apl_start
//devourer_ptr_apl_end
// clang-format on

// clang-format off
//havoc_apl_start
void havoc( player_t* p )
{
  action_priority_list_t* default_ = p->get_action_priority_list( "default" );
  action_priority_list_t* precombat = p->get_action_priority_list( "precombat" );
  action_priority_list_t* items = p->get_action_priority_list( "items" );

  precombat->add_action( "snapshot_stats" );
  precombat->add_action( "variable,name=tab_target_burning_wound,op=reset,default=1" );
  precombat->add_action( "variable,name=rg_ds,default=0,op=reset" );
  precombat->add_action( "variable,name=trinket1_special,value=0" );
  precombat->add_action( "variable,name=trinket2_special,value=0" );
  precombat->add_action( "variable,name=trinket1_crit,value=!variable.trinket1_special&trinket.1.has_cooldown&trinket.1.has_use_damage&!trinket.1.is.font_of_venomous_rage" );
  precombat->add_action( "variable,name=trinket2_crit,value=!variable.trinket2_special&trinket.2.has_cooldown&trinket.2.has_use_damage&!trinket.1.is.font_of_venomous_rage" );
  precombat->add_action( "variable,name=trinket1_steroids,value=!variable.trinket1_special&trinket.1.has_cooldown&trinket.1.has_use_buff" );
  precombat->add_action( "variable,name=trinket2_steroids,value=!variable.trinket2_special&trinket.2.has_cooldown&trinket.2.has_use_buff" );
  precombat->add_action( "immolation_aura" );

  default_->add_action( "auto_attack" );
  default_->add_action( "retarget_auto_attack,line_cd=1,target_if=min:debuff.burning_wound.remains,if=talent.burning_wound&active_dot.burning_wound<(spell_targets>?3)&variable.tab_target_burning_wound", "Default auto attack to spread Burning Wound, use tab_target_burning_wound=0 to spread with Throw Glaive instead" );
  default_->add_action( "retarget_auto_attack,line_cd=1,target_if=min:!target.is_boss,if=talent.burning_wound&active_dot.burning_wound=(spell_targets>?3)&variable.tab_target_burning_wound" );
  default_->add_action( "immolation_aura,if=talent.violent_transformation&talent.a_fire_inside&cooldown.metamorphosis.remains<gcd.max*3" );
  default_->add_action( "metamorphosis,if=(!talent.chaotic_transformation|!cooldown.blade_dance.up&cooldown.eye_beam.remains>8)&!action.death_sweep.demonsurge_available&!action.annihilation.demonsurge_available" );
  default_->add_action( "the_hunt,if=(!talent.eternal_hunt|cooldown.eye_beam.remains<10&cooldown.metamorphosis.remains>15|!cooldown.eye_beam.up&cooldown.metamorphosis.up|!hero_tree.felscarred)&!buff.reavers_glaive.up", "actions+=/metamorphosis,if=!talent.chaotic_transformation|!cooldown.blade_dance.up&!cooldown.eye_beam.up" );
  default_->add_action( "vengeful_retreat,use_off_gcd=1,if=gcd.remains<0.3&cooldown.metamorphosis.remains&cooldown.eye_beam.remains<gcd.max*0.3&!buff.initiative.up|cooldown.metamorphosis.up&cooldown.eye_beam.remains&cooldown.blade_dance.remains&!buff.eternal_hunt.up" );
  default_->add_action( "call_action_list,name=items" );
  default_->add_action( "pick_up_fragment,type=all,use_off_gcd=1,if=fury<=40" );
  default_->add_action( "reavers_glaive,if=buff.rending_strike.down&buff.glaive_flurry.down" );
  default_->add_action( "annihilation,if=buff.rending_strike.up&buff.glaive_flurry.down&debuff.reavers_mark.stack<2|buff.rending_strike.up&active_enemies>=2" );
  default_->add_action( "essence_break,if=action.death_sweep.demonsurge_available|action.annihilation.demonsurge_available" );
  default_->add_action( "death_sweep,if=debuff.essence_break.up|action.death_sweep.demonsurge_available" );
  default_->add_action( "annihilation,if=debuff.essence_break.up|action.annihilation.demonsurge_available" );
  default_->add_action( "throw_glaive,if=active_enemies>1&talent.burning_wound&!talent.screaming_brutality&active_dot.burning_wound<(spell_targets>?3)&!variable.tab_target_burning_wound" );
  default_->add_action( "immolation_aura,if=talent.a_fire_inside&talent.burning_wound&(charges=2|full_recharge_time<gcd.max*2)" );
  default_->add_action( "abyssal_gaze,if=!action.death_sweep.demonsurge_available&!action.annihilation.demonsurge_available" );
  default_->add_action( "eye_beam" );
  default_->add_action( "immolation_aura,,if=action.immolation_aura.demonsurge_available&buff.demonsurge.remains<gcd.max" );
  default_->add_action( "felblade,if=buff.inertia_trigger.up" );
  default_->add_action( "essence_break,if=cooldown.eye_beam.remains>4" );
  default_->add_action( "death_sweep" );
  default_->add_action( "blade_dance" );
  default_->add_action( "immolation_aura,if=active_enemies>1&(talent.a_fire_inside|talent.burning_wound)" );
  default_->add_action( "annihilation" );
  default_->add_action( "felblade,if=hero_tree.felscarred&fury<=100" );
  default_->add_action( "chaos_strike" );
  default_->add_action( "felblade" );
  default_->add_action( "immolation_aura" );
  default_->add_action( "arcane_torrent" );

  items->add_action( "potion,use_off_gcd=1,if=cooldown.metamorphosis.up&(cooldown.eye_beam.up|!talent.chaotic_transformation)|fight_remains<=30" );
  items->add_action( "use_item,slot=trinket1,use_off_gcd=1,if=variable.trinket1_steroids&(!variable.trinket2_special|trinket.2.cooldown.remains>20)|fight_remains<15" );
  items->add_action( "use_item,slot=trinket1,use_off_gcd=1,if=variable.trinket1_crit&(buff.initiative.up|!talent.initiative)&(!variable.trinket2_special|trinket.2.cooldown.remains>20)|fight_remains<15" );
  items->add_action( "use_item,name=font_of_venomous_rage,if=buff.initiative.up&buff.initiative.remains>2&(!buff.metamorphosis.up|fight_remains<buff.metamorphosis.remains)&!debuff.essence_break.up|fight_remains<19" );
  items->add_action( "use_item,slot=trinket2,use_off_gcd=1,if=variable.trinket2_steroids&(!variable.trinket1_special|trinket.1.cooldown.remains>20)|fight_remains<15" );
  items->add_action( "use_item,slot=trinket2,use_off_gcd=1,if=variable.trinket2_crit&(buff.initiative.up|!talent.initiative)&(!variable.trinket1_special|trinket.1.cooldown.remains>20)|fight_remains<15" );
}
//havoc_apl_end
// clang-format on

// clang-format off
//havoc_ptr_apl_start
//havoc_ptr_apl_end
// clang-format on

// clang-format off
//vengeance_apl_start
void vengeance( player_t* p )
{
  action_priority_list_t* default_ = p->get_action_priority_list( "default" );
  action_priority_list_t* precombat = p->get_action_priority_list( "precombat" );
  action_priority_list_t* aldrachi_reaver = p->get_action_priority_list( "aldrachi_reaver" );
  action_priority_list_t* ar_quick_consume = p->get_action_priority_list( "ar_quick_consume" );
  action_priority_list_t* ar_fillers = p->get_action_priority_list( "ar_fillers" );
  action_priority_list_t* ar_glaive_cycle = p->get_action_priority_list( "ar_glaive_cycle" );
  action_priority_list_t* annihilator = p->get_action_priority_list( "annihilator" );
  action_priority_list_t* anni_cooldowns = p->get_action_priority_list( "anni_cooldowns" );
  action_priority_list_t* anni_voidfall_spending = p->get_action_priority_list( "anni_voidfall_spending" );
  action_priority_list_t* anni_meta_entry = p->get_action_priority_list( "anni_meta_entry" );
  action_priority_list_t* anni_pre_meta_spb = p->get_action_priority_list( "anni_pre_meta_spb" );
  action_priority_list_t* anni_generate_fury = p->get_action_priority_list( "anni_generate_fury" );
  action_priority_list_t* anni_filler_no_spend = p->get_action_priority_list( "anni_filler_no_spend" );
  action_priority_list_t* trinkets = p->get_action_priority_list( "trinkets" );

  precombat->add_action( "snapshot_stats" );
  precombat->add_action( "sigil_of_flame" );
  precombat->add_action( "sigil_of_spite,if=hero_tree.aldrachi_reaver|talent.soul_carver" );
  precombat->add_action( "immolation_aura" );

  default_->add_action( "variable,name=aoe,value=spell_targets.spirit_bomb>=3" );
  default_->add_action( "variable,name=execute,value=fight_remains<20" );
  default_->add_action( "variable,name=is_dungeon,value=fight_style.dungeonroute|fight_style.dungeonslice" );
  default_->add_action( "cycling_variable,name=dung_pull_ttd,op=reset" );
  default_->add_action( "cycling_variable,name=dung_pull_ttd,op=max,value=target.time_to_die" );
  default_->add_action( "variable,name=dung_next_pull,value=variable.is_dungeon&raid_event.adds.exists&raid_event.pull.remains<12&(raid_event.adds.has_boss|raid_event.adds.count>=3)" );
  default_->add_action( "variable,name=dung_cd_ok,value=variable.execute|!variable.is_dungeon|(variable.dung_pull_ttd>12&!variable.dung_next_pull)" );
  default_->add_action( "variable,name=dung_meta_ok,value=variable.execute|!variable.is_dungeon|(variable.dung_pull_ttd>(15-5*hero_tree.annihilator)&!variable.dung_next_pull)" );
  default_->add_action( "variable,name=trinket_1_buffs,value=trinket.1.has_use_buff|(trinket.1.has_buff.agility|trinket.1.has_buff.mastery|trinket.1.has_buff.versatility|trinket.1.has_buff.haste|trinket.1.has_buff.crit|trinket.1.has_buff.attack_power)" );
  default_->add_action( "variable,name=trinket_2_buffs,value=trinket.2.has_use_buff|(trinket.2.has_buff.agility|trinket.2.has_buff.mastery|trinket.2.has_buff.versatility|trinket.2.has_buff.haste|trinket.2.has_buff.crit|trinket.2.has_buff.attack_power)" );
  default_->add_action( "variable,name=trinket_priority,op=setif,value=2,value_else=1,condition=!variable.trinket_1_buffs&variable.trinket_2_buffs|variable.trinket_2_buffs&((trinket.2.proc.any_dps.duration)*trinket.2.proc.any_dps.default_value)>((trinket.1.proc.any_dps.duration)*trinket.1.proc.any_dps.default_value)" );
  default_->add_action( "variable,name=damage_trinket_priority,op=setif,value=2,value_else=1,condition=!variable.trinket_1_buffs&!variable.trinket_2_buffs&trinket.2.ilvl>=trinket.1.ilvl" );
  default_->add_action( "variable,name=fiery_demise_active,value=talent.fiery_demise&dot.fiery_brand.ticking" );
  default_->add_action( "variable,name=fragment_target,op=setif,value=5+apex.2,value_else=variable.fiery_demise_active*3+!variable.fiery_demise_active*(5-buff.metamorphosis.up),condition=hero_tree.aldrachi_reaver" );
  default_->add_action( "auto_attack" );
  default_->add_action( "disrupt,if=target.debuff.casting.react" );
  default_->add_action( "infernal_strike,use_off_gcd=1" );
  default_->add_action( "demon_spikes,use_off_gcd=1,if=!buff.demon_spikes.up&in_combat" );
  default_->add_action( "run_action_list,name=aldrachi_reaver,if=hero_tree.aldrachi_reaver" );
  default_->add_action( "run_action_list,name=annihilator,if=hero_tree.annihilator" );

  aldrachi_reaver->add_action( "sigil_of_flame" );
  aldrachi_reaver->add_action( "immolation_aura,if=in_combat" );
  aldrachi_reaver->add_action( "metamorphosis,use_off_gcd=1,if=buff.untethered_rage.up|(!buff.metamorphosis.up&variable.dung_meta_ok)" );
  aldrachi_reaver->add_action( "soul_cleave,if=!variable.aoe&soul_fragments.total>=variable.fragment_target&!(buff.glaive_flurry.up&buff.rending_strike.up&variable.prio_slashes)" );
  aldrachi_reaver->add_action( "variable,name=anchor_rem,value=(variable.anchor_at>0)*(20-(time-variable.anchor_at))", "Seconds left on the Reaver's Mark stacks applied by the last Fracture-second cycle" );
  aldrachi_reaver->add_action( "variable,name=prio_slashes,value=variable.aoe|variable.execute|variable.anchor_rem>11-3*(talent.soul_carver&cooldown.soul_carver.remains<6)-1.5*(talent.sigil_of_spite&cooldown.sigil_of_spite.remains<6)", "Slash-second only while the Mark has time to spare; otherwise go Fracture-second to refresh it" );
  aldrachi_reaver->add_action( "call_action_list,name=trinkets" );
  aldrachi_reaver->add_action( "reavers_glaive,if=!buff.rending_strike.up&!buff.glaive_flurry.up&(variable.execute|variable.prio_slashes|variable.anchor_rem<=4*gcd.max|buff.art_of_the_glaive.stack+soul_fragments>=(18-buff.metamorphosis.up))" );
  aldrachi_reaver->add_action( "call_action_list,name=ar_glaive_cycle,if=buff.rending_strike.up|buff.glaive_flurry.up" );
  aldrachi_reaver->add_action( "fiery_brand,if=charges>=2|!variable.fiery_demise_active|variable.execute" );
  aldrachi_reaver->add_action( "sigil_of_spite,if=variable.dung_cd_ok&!buff.reavers_glaive.up" );
  aldrachi_reaver->add_action( "call_action_list,name=ar_quick_consume,if=buff.art_of_the_glaive.stack+soul_fragments>=20|variable.aoe&soul_fragments>=6" );
  aldrachi_reaver->add_action( "fel_devastation,if=variable.dung_cd_ok&fury>85&(soul_fragments.inactive>1|variable.aoe)" );
  aldrachi_reaver->add_action( "soul_carver,if=variable.dung_cd_ok&(variable.fiery_demise_active|variable.execute)" );
  aldrachi_reaver->add_action( "call_action_list,name=ar_fillers" );

  ar_quick_consume->add_action( "spirit_bomb,if=variable.aoe" );
  ar_quick_consume->add_action( "soul_cleave,if=!variable.aoe" );

  ar_fillers->add_action( "fracture,if=buff.warblades_hunger.stack" );
  ar_fillers->add_action( "soul_cleave,if=(!variable.aoe|fury>=2*action.soul_cleave.cost|cooldown.fracture.charges>=1|cooldown.fracture.remains<=gcd.max)&!(buff.glaive_flurry.up&buff.rending_strike.up&variable.prio_slashes)" );
  ar_fillers->add_action( "fracture" );
  ar_fillers->add_action( "felblade" );
  ar_fillers->add_action( "fel_devastation" );

  ar_glaive_cycle->add_action( "potion,use_off_gcd=1" );
  ar_glaive_cycle->add_action( "invoke_external_buff,name=power_infusion" );
  ar_glaive_cycle->add_action( "variable,name=anchor_at,value=time,if=buff.rending_strike.up&!buff.glaive_flurry.up" );
  ar_glaive_cycle->add_action( "fracture,if=buff.rending_strike.up&(variable.prio_slashes|!buff.glaive_flurry.up)" );
  ar_glaive_cycle->add_action( "soul_cleave,if=buff.glaive_flurry.up&(!variable.prio_slashes|!buff.rending_strike.up)" );
  ar_glaive_cycle->add_action( "felblade" );

  annihilator->add_action( "invoke_external_buff,name=power_infusion,if=buff.voidfall_spending.stack=3|variable.execute" );
  annihilator->add_action( "call_action_list,name=anni_voidfall_spending,if=buff.voidfall_spending.up" );
  annihilator->add_action( "sigil_of_flame,if=soul_fragments<=2+talent.soul_sigils" );
  annihilator->add_action( "fracture,if=buff.voidfall_building.stack>=2&soul_fragments.total>=variable.fragment_target" );
  annihilator->add_action( "call_action_list,name=anni_generate_fury,if=buff.voidfall_building.stack>=2&cooldown.fracture.charges_fractional>=0.75" );
  annihilator->add_action( "call_action_list,name=anni_meta_entry,if=buff.untethered_rage.up|(variable.dung_meta_ok&cooldown.metamorphosis.remains<3*gcd.max)" );
  annihilator->add_action( "call_action_list,name=anni_cooldowns,if=variable.dung_cd_ok&(!talent.fiery_demise|variable.fiery_demise_active|cooldown.fiery_brand.remains>20|variable.execute)" );
  annihilator->add_action( "fracture,if=full_recharge_time<gcd.max" );
  annihilator->add_action( "immolation_aura,if=(talent.fallout&variable.aoe)|(talent.charred_flesh&variable.fiery_demise_active)" );
  annihilator->add_action( "spirit_bomb,if=soul_fragments>=variable.fragment_target" );
  annihilator->add_action( "immolation_aura" );
  annihilator->add_action( "sigil_of_flame" );
  annihilator->add_action( "fracture,if=soul_fragments.total<=4|fury<40" );
  annihilator->add_action( "soul_cleave,if=!(apex.3&!buff.untethered_rage.up&buff.seething_anger.stack>=10)&!cooldown.metamorphosis.up|(!talent.sigil_of_spite|!action.sigil_of_spite.placed)" );
  annihilator->add_action( "felblade" );
  annihilator->add_action( "throw_glaive" );

  anni_cooldowns->add_action( "spirit_bomb,if=soul_fragments>=variable.fragment_target" );
  anni_cooldowns->add_action( "sigil_of_spite,if=soul_fragments<=2+talent.soul_sigils" );
  anni_cooldowns->add_action( "call_action_list,name=anni_generate_fury,if=cooldown.fel_devastation.up&fury<50" );

  anni_voidfall_spending->add_action( "soul_cleave,if=prev_gcd.1.spirit_bomb&buff.voidfall_spending.stack=3", "Soul Cleave right after the 3-stack Spirit Bomb lands inside its window for a bonus meteor" );
  anni_voidfall_spending->add_action( "fiery_brand,if=charges>=2|!variable.fiery_demise_active" );
  anni_voidfall_spending->add_action( "fracture,if=buff.voidfall_spending.stack=buff.voidfall_spending.max_stack&cooldown.spirit_bomb.ready&soul_fragments.total>=variable.fragment_target&fury>=45&fury<75" );
  anni_voidfall_spending->add_action( "soul_cleave,if=cooldown.spirit_bomb.remains>gcd.max*4" );
  anni_voidfall_spending->add_action( "spirit_bomb,if=(soul_fragments.total>=variable.fragment_target|buff.voidfall_spending.stack=3)&(buff.voidfall_spending.stack<3|fury>=75)" );
  anni_voidfall_spending->add_action( "felblade,if=(fury<40&cooldown.spirit_bomb.remains<=gcd.max)|(fury<25&cooldown.spirit_bomb.remains>gcd.max)" );
  anni_voidfall_spending->add_action( "immolation_aura,if=(fury<40&cooldown.spirit_bomb.remains<=gcd.max)|(fury<25&cooldown.spirit_bomb.remains>gcd.max)" );
  anni_voidfall_spending->add_action( "soul_carver,if=(cooldown.spirit_bomb.remains<=gcd.max)&soul_fragments.total<variable.fragment_target&(!talent.sigil_of_spite|!action.sigil_of_spite.placed)" );
  anni_voidfall_spending->add_action( "sigil_of_spite,if=(cooldown.spirit_bomb.remains<=gcd.max)&soul_fragments.total<variable.fragment_target" );
  anni_voidfall_spending->add_action( "call_action_list,name=anni_filler_no_spend" );

  anni_meta_entry->add_action( "metamorphosis,use_off_gcd=1,if=gcd.remains=0&buff.untethered_rage.up&!buff.voidfall_spending.up&cooldown.fracture.charges>=1" );
  anni_meta_entry->add_action( "sigil_of_spite,if=!cooldown.sigil_of_spite.up" );
  anni_meta_entry->add_action( "spirit_bomb,if=soul_fragments>=variable.fragment_target&fury>=60" );
  anni_meta_entry->add_action( "potion,use_off_gcd=1,if=(variable.fiery_demise_active|variable.execute)&(!variable.is_dungeon|in_boss_encounter)" );
  anni_meta_entry->add_action( "call_action_list,name=trinkets" );
  anni_meta_entry->add_action( "invoke_external_buff,name=power_infusion" );
  anni_meta_entry->add_action( "call_action_list,name=anni_pre_meta_spb,if=cooldown.spirit_bomb.remains<3*gcd.max&soul_fragments.total<variable.fragment_target" );
  anni_meta_entry->add_action( "fiery_brand,if=charges>=2|!variable.fiery_demise_active" );
  anni_meta_entry->add_action( "sigil_of_spite,if=soul_fragments.total<variable.fragment_target" );
  anni_meta_entry->add_action( "call_action_list,name=anni_generate_fury,if=fury<75&cooldown.metamorphosis.up&cooldown.spirit_bomb.remains>gcd.max*3" );
  anni_meta_entry->add_action( "metamorphosis,use_off_gcd=1,if=variable.dung_meta_ok&gcd.remains=0&cooldown.spirit_bomb.remains>gcd.max*3&(soul_fragments.total>=variable.fragment_target|(talent.sigil_of_spite&action.sigil_of_spite.placed))" );
  anni_meta_entry->add_action( "call_action_list,name=anni_filler_no_spend" );

  anni_pre_meta_spb->add_action( "fracture" );
  anni_pre_meta_spb->add_action( "immolation_aura,if=variable.aoe" );
  anni_pre_meta_spb->add_action( "fiery_brand,if=charges>=2|!variable.fiery_demise_active" );
  anni_pre_meta_spb->add_action( "soul_carver,if=(cooldown.soul_carver.up+cooldown.sigil_of_spite.up+cooldown.fel_devastation.up)>=2" );
  anni_pre_meta_spb->add_action( "fel_devastation,if=(cooldown.soul_carver.up+cooldown.sigil_of_spite.up+cooldown.fel_devastation.up)>=2" );
  anni_pre_meta_spb->add_action( "felblade" );

  anni_generate_fury->add_action( "immolation_aura" );
  anni_generate_fury->add_action( "sigil_of_flame" );
  anni_generate_fury->add_action( "felblade" );
  anni_generate_fury->add_action( "fracture" );

  anni_filler_no_spend->add_action( "immolation_aura" );
  anni_filler_no_spend->add_action( "sigil_of_flame" );
  anni_filler_no_spend->add_action( "felblade" );
  anni_filler_no_spend->add_action( "soul_carver,if=!talent.sigil_of_spite|!action.sigil_of_spite.placed" );
  anni_filler_no_spend->add_action( "sigil_of_spite" );
  anni_filler_no_spend->add_action( "fracture" );
  anni_filler_no_spend->add_action( "throw_glaive" );

  trinkets->add_action( "use_item,slot=trinket1,if=variable.trinket_1_buffs&variable.dung_cd_ok&(!trinket.2.has_cooldown|trinket.2.cooldown.remains|variable.trinket_priority=1)" );
  trinkets->add_action( "use_item,slot=trinket2,if=variable.trinket_2_buffs&variable.dung_cd_ok&(!trinket.1.has_cooldown|trinket.1.cooldown.remains|variable.trinket_priority=2)" );
  trinkets->add_action( "use_item,use_off_gcd=1,slot=trinket1,if=!variable.trinket_1_buffs&(variable.damage_trinket_priority=1|trinket.2.cooldown.remains|trinket.2.cooldown.duration=0)&gcd.remains>0.1" );
  trinkets->add_action( "use_item,use_off_gcd=1,slot=trinket2,if=!variable.trinket_2_buffs&(variable.damage_trinket_priority=2|trinket.1.cooldown.remains|trinket.1.cooldown.duration=0)&gcd.remains>0.1" );
  trinkets->add_action( "use_item,slot=trinket1,if=variable.execute" );
  trinkets->add_action( "use_item,slot=trinket2,if=variable.execute" );
}
//vengeance_apl_end
// clang-format on

// clang-format off
//vengeance_ptr_apl_start
//vengeance_ptr_apl_end
// clang-format on

}  // namespace demon_hunter_apl
