// ==========================================================================
// Dedmonwakeen's Raid DPS/TPS Simulator.
// Send questions to natehieter@gmail.com
// ==========================================================================

#include "attack.hpp"

#include "action_state.hpp"
#include "dbc/spell_data.hpp"
#include "player/player.hpp"
#include "player/stats.hpp"
#include "sim/cooldown.hpp"
#include "sim/event.hpp"
#include "sim/sim.hpp"
#include "util/rng.hpp"

// ==========================================================================
// Attack
// ==========================================================================

attack_t::attack_t( util::string_view n, player_t* p ) : attack_t( n, p, spell_data_t::nil() ) {}

attack_t::attack_t( util::string_view n, player_t* p, const spell_data_t* s )
  : action_t( ACTION_ATTACK, n, p, s ), base_attack_expertise( 0 ), attack_table()
{
  base_crit_bonus = 1.0;
  special = true;  // Make sure to set this to false with autoattacks.

  weapon_power_mod = 1.0 / WEAPON_POWER_COEFFICIENT;
  min_gcd = p->min_gcd;

  // dodge/parry/block are true by default for attacks unless corresponding flag is set
  if ( data().ok() && !data().flags( spell_attribute::SX_NO_D_P_B ) )
  {
    may_dodge = !data().flags( spell_attribute::SX_NO_DODGE );
    may_parry = !data().flags( spell_attribute::SX_NO_PARRY );
  }
}

void attack_t::execute()
{
  action_t::execute();
}

double attack_t::execute_time_pct_multiplier() const
{
  return action_t::execute_time_pct_multiplier() * player->cache.auto_attack_speed();
}

result_amount_type attack_t::amount_type( const action_state_t*, bool periodic ) const
{
  if ( periodic || treat_as_periodic )
    return result_amount_type::DMG_OVER_TIME;
  else
    return result_amount_type::DMG_DIRECT;
}

result_amount_type attack_t::report_amount_type( const action_state_t* state ) const
{
  auto result_type = state->result_type;

  if ( result_type == result_amount_type::DMG_DIRECT )
  {
    // Direct ticks are direct damage, that are recorded as ticks
    if ( direct_tick )
    {
      result_type = result_amount_type::DMG_OVER_TIME;
    }
    else
    {
      // With direct damage, we need to check if this action is a tick action of
      // someone. If so, then the damage should be recorded as periodic.
      if ( !stats->action_list.empty() && stats->action_list.front()->tick_action == this )
      {
        result_type = result_amount_type::DMG_OVER_TIME;
      }
    }
  }

  return result_type;
}

double attack_t::miss_chance( double hit, player_t* t ) const
{
  if ( t->is_enemy() && sim->auto_attacks_always_land && !special )
  {
    return 0.0;
  }

  // cache.miss() contains the target's miss chance (3.0 base in almost all cases)
  double miss = t->cache.miss();

  // add or subtract 1.5% per level difference
  miss += ( t->level() - player->level() ) * 0.015;

  // asymmetric hit penalty for npcs attacking higher-level players
  if ( !t->is_enemy() )
    miss += std::max( t->level() - player->level() - 3, 0 ) * 0.015;

  // subtract the player's hit chance
  miss -= hit;

  return miss;
}

double attack_t::dodge_chance( double expertise, player_t* t ) const
{
  if ( t->is_enemy() && sim->auto_attacks_always_land && !special )
  {
    return 0.0;
  }

  // cache.dodge() contains the target's dodge chance (3.0 base, plus spec bonuses and rating)
  double dodge = t->cache.dodge();

  // WoD mechanics are unchanged from MoP add or subtract 1.5% per level difference
  dodge += ( t->level() - player->level() ) * 0.015;

  // subtract the player's expertise chance
  dodge -= expertise;

  return dodge;
}

double attack_t::bonus_da( const action_state_t* s ) const
{
  double da = action_t::bonus_da( s );

  if ( !special )
  {
    da += player->auto_attack_modifier;
    da += player->auto_attack_base_modifier;
  }

  return da;
}

double attack_t::action_multiplier() const
{
  double mul = action_t::action_multiplier();

  if ( !special )
  {
    mul *= player->auto_attack_multiplier;
  }

  return mul;
}

double attack_t::composite_target_multiplier( player_t* t ) const
{
  double mul = action_t::composite_target_multiplier( t );

  mul *= composite_target_damage_vulnerability( t );

  return mul;
}

double attack_t::composite_hit() const
{
  return action_t::composite_hit() + player->cache.attack_hit();
}

double attack_t::composite_crit_chance() const
{
  return action_t::composite_crit_chance() + player->cache.attack_crit_chance();
}

double attack_t::composite_crit_chance_multiplier() const
{
  return action_t::composite_crit_chance_multiplier() * player->composite_melee_crit_chance_multiplier();
}

double attack_t::composite_haste() const
{
  return action_t::composite_haste() * player->cache.attack_haste();
}

double attack_t::composite_expertise() const
{
  return base_attack_expertise + player->cache.attack_expertise();
}

double attack_t::composite_versatility( const action_state_t* state ) const
{
  return action_t::composite_versatility( state ) + player->cache.damage_versatility();
}

void attack_t::attack_table_t::build_table( double miss_chance, double dodge_chance, double parry_chance,
                                            double glance_chance, double crit_chance, sim_t* sim )
{
  sim->print_debug( "attack_t::build_table: miss={} dodge={} parry={} glance={} crit={}", miss_chance, dodge_chance,
                    parry_chance, glance_chance, crit_chance );

  assert( crit_chance >= 0 && crit_chance <= 1.0 );

  double sum = miss_chance + dodge_chance + parry_chance + crit_chance;

  // Only recalculate attack table if the stats have changed
  if ( attack_table_sum == sum )
    return;
  attack_table_sum = sum;

  double limit = 1.0;
  double total = 0;

  num_results = 0;

  if ( miss_chance > 0 && total < limit )
  {
    total += miss_chance;
    if ( total > limit )
      total = limit;

    chances[ num_results ] = total;
    results[ num_results ] = RESULT_MISS;
    num_results++;
  }
  if ( dodge_chance > 0 && total < limit )
  {
    total += dodge_chance;
    if ( total > limit )
      total = limit;

    chances[ num_results ] = total;
    results[ num_results ] = RESULT_DODGE;
    num_results++;
  }
  if ( parry_chance > 0 && total < limit )
  {
    total += parry_chance;
    if ( total > limit )
      total = limit;

    chances[ num_results ] = total;
    results[ num_results ] = RESULT_PARRY;
    num_results++;
  }
  if ( glance_chance > 0 && total < limit )
  {
    total += glance_chance;
    if ( total > limit )
      total = limit;

    chances[ num_results ] = total;
    results[ num_results ] = RESULT_GLANCE;
    num_results++;
  }
  if ( crit_chance > 0 && total < limit )
  {
    total += crit_chance;
    if ( total > limit )
      total = limit;

    chances[ num_results ] = total;
    results[ num_results ] = RESULT_CRIT;
    num_results++;
  }
  if ( total < 1.0 )
  {
    chances[ num_results ] = 1.0;
    results[ num_results ] = RESULT_HIT;
    num_results++;
  }
}

result_e attack_t::calculate_result( action_state_t* s ) const
{
  result_e result = RESULT_NONE;

  if ( !harmful || !may_hit || !s->target )
    return RESULT_NONE;

  int delta_level = s->target->level() - player->level();

  double miss = may_miss ? miss_chance( composite_hit(), s->target ) : 0;
  double dodge = may_dodge ? dodge_chance( composite_expertise(), s->target ) : 0;
  double parry =
    may_parry && player->position() == POSITION_FRONT ? parry_chance( composite_expertise(), s->target ) : 0;
  double crit = may_crit ? std::max( s->composite_crit_chance() + s->target->cache.crit_avoidance(), 0.0 ) : 0;

  // Specials are 2-roll calculations, so only pass crit chance to
  // build_table for non-special attacks

  attack_table.build_table( miss, dodge, parry, may_glance ? glance_chance( delta_level ) : 0.0,
                            !special ? std::min( 1.0, crit ) : 0.0, sim );

  if ( attack_table.num_results == 1 )
  {
    result = attack_table.results.front();
  }
  else
  {
    // 1-roll attack table with true RNG

    double random = rng().real();

    for ( int i = 0; i < attack_table.num_results; ++i )
    {
      if ( random <= attack_table.chances[ i ] )
      {
        result = attack_table.results[ i ];
        break;
      }
    }
  }

  assert( result != RESULT_NONE );

  // if we have a special, make a second roll for hit/crit
  if ( result == RESULT_HIT && special && may_crit )
  {
    if ( rng().roll( crit ) )
      result = RESULT_CRIT;
  }

  if ( sim->debug )
    sim->print_debug( "{} result for attack {} is {}.", *player, *this, result );

  return result;
}

double attack_t::recharge_multiplier( const cooldown_t& cd ) const
{
  double m = action_t::recharge_multiplier( cd );

  if ( cd.hasted )
  {
    m *= player->cache.attack_haste();
  }

  return m;
}

void attack_t::reschedule_auto_attack( double old_swing_haste )
{
  if ( player->cache.auto_attack_speed() == old_swing_haste )
  {
    return;
  }

  // Note that if attack -> swing_haste() > old_swing_haste, this could
  // probably be handled by rescheduling, but the code is slightly simpler if
  // we just cancel the event and make a new one.
  if ( execute_event && execute_event->remains() > timespan_t::zero() )
  {
    timespan_t time_to_hit = execute_event->occurs() - sim->current_time();
    timespan_t new_time_to_hit = time_to_hit * player->cache.auto_attack_speed() / old_swing_haste;

    if ( time_to_hit == new_time_to_hit )
    {
      return;
    }

    if ( sim->debug )
    {
      sim->print_debug( "Haste change, reschedule {} from {} to {} (speed {} -> {}, remains {})", *this,
                        execute_event->remains(), new_time_to_hit, old_swing_haste, player->cache.auto_attack_speed(),
                        time_to_hit );
    }

    if ( new_time_to_hit > time_to_hit )
      execute_event->reschedule( new_time_to_hit );
    else
    {
      event_t::cancel( execute_event );
      execute_event = start_action_execute_event( new_time_to_hit );
    }
  }
}

void attack_t::reset()
{
  attack_table.reset();
  action_t::reset();
}

// ==========================================================================
// Melee Attack
// ==========================================================================

melee_attack_t::melee_attack_t( util::string_view n, player_t* p ) : melee_attack_t( n, p, spell_data_t::nil() ) {}

melee_attack_t::melee_attack_t( util::string_view n, player_t* p, const spell_data_t* s ) : attack_t( n, p, s )
{
  // Prevent melee from being scheduled when player is moving
  if ( range < 0 )
    range = 5;
}

void melee_attack_t::init()
{
  attack_t::init();

  if ( !special )
    may_glance = true;
}

double melee_attack_t::parry_chance( double expertise, player_t* t ) const
{
  if ( t->is_enemy() && sim->auto_attacks_always_land && !special )
  {
    return 0.0;
  }

  // cache.parry() contains the target's parry chance (3.0 base, plus spec
  // bonuses and rating)
  double parry = t->cache.parry();

  // WoD mechanics are similar to MoP
  // add or subtract 1.5% per level difference
  parry += ( t->level() - player->level() ) * 0.015;

  // 3% additional parry for attacking a level+3 or higher NPC
  if ( t->is_enemy() && ( t->level() - player->level() ) > 2 )
    parry += 0.03;

  // subtract the player's expertise chance - no longer depends on dodge
  parry -= expertise;

  return parry;
}

double melee_attack_t::glance_chance( int delta_level ) const
{
  double glance = 0;

  // TODO-WOD: Glance chance increase per 4+ level delta?
  if ( delta_level > 3 )
  {
    glance += 0.10 + 0.10 * delta_level;
  }

  return glance;
}

proc_types melee_attack_t::proc_type() const
{
  if ( s_data->ok() )
  {
    switch ( s_data->dmg_class() )
    {
      case SPELL_TYPE_NONE:   return PROC1_NONE_HARMFUL;
      case SPELL_TYPE_MAGIC:  return PROC1_MAGIC_SPELL;
      case SPELL_TYPE_MELEE:  return special ? PROC1_MELEE_ABILITY : PROC1_MELEE;
      case SPELL_TYPE_RANGED: return special ? PROC1_RANGED_ABILITY : PROC1_RANGED;
    }
  }

  if ( special )
    return PROC1_MELEE_ABILITY;
  else
    return PROC1_MELEE;
}

// ==========================================================================
// Ranged Attack
// ==========================================================================

ranged_attack_t::ranged_attack_t( util::string_view token, player_t* p )
  : ranged_attack_t( token, p, spell_data_t::nil() )
{}

ranged_attack_t::ranged_attack_t( util::string_view token, player_t* p, const spell_data_t* s )
  : attack_t( token, p, s )
{
  // ranged attacks cannot be blocked or parried
  may_block = may_parry = false;
}

// Ranged attacks are identical to melee attacks, but cannot be parried or dodged.
// all of the inherited *_chance() methods are accurate.

double ranged_attack_t::composite_target_multiplier( player_t* t ) const
{
  double v = attack_t::composite_target_multiplier( t );

  return v;
}

void ranged_attack_t::schedule_execute( action_state_t* state )
{
  if ( sim->debug )
  {
    sim->print_log( "{} schedules execute for {} ({})", *player, *this,
                    player->resources.current[ player->primary_resource() ] );
  }

  time_to_execute = execute_time();

  execute_event = start_action_execute_event( time_to_execute, state );

  if ( trigger_gcd > timespan_t::zero() )
    player->off_gcdactions.clear();

  if ( !background )
  {
    if ( player->queueing == this )
    {
      player->queueing = nullptr;
    }

    player->executing = this;
    player->gcd_ready = sim->current_time() + gcd();
    player->gcd_type = gcd_type;
    switch ( gcd_type )
    {
      case gcd_haste_type::SPELL_HASTE:  player->gcd_current_haste_value = player->cache.spell_haste(); break;
      case gcd_haste_type::ATTACK_HASTE: player->gcd_current_haste_value = player->cache.attack_haste(); break;
      default:                           break;
    }

    if ( player->action_queued && sim->strict_gcd_queue )
    {
      player->gcd_ready -= sim->queue_gcd_reduction;
    }
  }
}

proc_types ranged_attack_t::proc_type() const
{
  if ( s_data->ok() )
  {
    switch ( s_data->dmg_class() )
    {
      case SPELL_TYPE_NONE:   return PROC1_NONE_HARMFUL;
      case SPELL_TYPE_MAGIC:  return PROC1_MAGIC_SPELL;
      case SPELL_TYPE_MELEE:  return special ? PROC1_MELEE_ABILITY : PROC1_MELEE;
      case SPELL_TYPE_RANGED: return special ? PROC1_RANGED_ABILITY : PROC1_RANGED;
    }
  }

  if ( special )
    return PROC1_RANGED_ABILITY;
  else
    return PROC1_RANGED;
}
