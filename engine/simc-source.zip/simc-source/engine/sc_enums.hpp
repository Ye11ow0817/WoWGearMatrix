// ==========================================================================
// Dedmonwakeen's Raid DPS/TPS Simulator.
// Send questions to natehieter@gmail.com
// ==========================================================================

#pragma once

#include "config.hpp"
#include <cassert>
#include <cstdint>

// Enumerations =============================================================
// annex _e to enumerations


// Type of internal execution of an action
enum class execute_type : unsigned
{
  FOREGROUND = 0u,
  OFF_GCD,
  CAST_WHILE_CASTING
};


// Source of the profile, defaults to command line / addon / etc
enum class profile_source
{
  DEFAULT, /// Anything non-blizzard-api
  BLIZZARD_API
};

// Attack power computation modes for Battle for Azeroth+
enum class attack_power_type : unsigned
{
  // Default mode, Attack power is a composite of power and mainhand weapon dps
  WEAPON_MAINHAND = 0,

  // Attack power is a composite of power and offhand weapon dps
  WEAPON_OFFHAND,

  // Attack power is a composite of power and both weapon dps
  WEAPON_BOTH,

  // Attack power is purely based on player power (main stat)
  NO_WEAPON,

  // Let SimC figure out BfA attack power mode based on information assigned to the action object.
  NONE,

  DEFAULT = WEAPON_MAINHAND,
};

// Retargeting request (event) sources. Context in ACTOR_ is the actor that triggered the event
enum class retarget_source
{
  ACTOR_ARISE,          // Any actor arises
  ACTOR_DEMISE,         // Any actor demises
  ACTOR_INVULNERABLE,   // Actor becomes invulnerable
  ACTOR_VULNERABLE,     // Actor becomes vulnerable (after becoming invulnerable)
  SELF_ARISE,           // Actor has arisen (no context provided)
  SELF_RETARGET         // Actor is choosing to retarget
};

// Misc Constants
constexpr auto MAX_ARTIFACT_RELIC = 4;

// Seemingly hard coded CurvePoint identifier for the data that returns the item level increase of a relic, based on the
// relic's own item level
constexpr auto RELIC_ILEVEL_BONUS_CURVE = 1718;

constexpr auto POTION_COOLDOWN_CATEGORY    = 4;     /// "Item - Combat Cons. (Potion)" category (for shared CD)
constexpr auto ITEM_TRINKET_BURST_CATEGORY = 1141;  /// Trinket On-Use effect default category (for shared CD)
constexpr auto MAX_GEM_SLOTS               = 4;     /// Global maximum number of gem slots in any specific item

constexpr auto MAX_AZERITE_LEVEL =
    300;  // Maximum Azerite level (for Heart of Azeroth) at the start of Battle for Azeroth

constexpr auto MAX_AZERITE_ESSENCE_RANK = 4u;  // Maximum Azerite Essence power rank for patch BfA 8.2.0

// Shadowlands: Curves used to apply diminishing returns to Combat Ratings
constexpr auto DIMINISHING_RETURN_SECONDARY_CR_CURVE  = 21024u;
constexpr auto DIMINISHING_RETURN_TERTIARY_CR_CURVE   = 21025u;
constexpr auto DIMINISHING_RETURN_VERS_MITIG_CR_CURVE = 21035u;

// Midnight curve from ItemSquishEra.db2
constexpr auto SQUISH_CURVE_MIDNIGHT = 92181u;

// Maximum damage reduction from armor / block
constexpr auto MAX_ARMOR_DAMAGE_REDUCTION = 0.85;

// Enable/Disable azerite effects
enum class azerite_control
{
  ENABLED,          // All azerite-related effects enabled (default)
  DISABLED_ITEMS,   // Azerite effects from items are disabled
  DISABLED_ALL      // All azerite-related effects disabled
};

enum class regen_type
{
  /*
   Old resource regeneration model.

   Actors regen every 'periodicity' seconds through a single global event.
   Default.
   */
   STATIC,

  /*
   Dynamic resource regeneration model.

   Resources are regenerated at dynamic intervals when an actor is about to
   execute an action, and when the state of the actor changes in a way that
   affects resource regeneration.

   See comment on player_t::regen_caches how to define what state changes
   affect resource regneration.
   */
  DYNAMIC,

  // Resource regeneration is disabled for the actor
  DISABLED
};

enum class buff_constant_behavior
{
  DEFAULT,
  ALWAYS_CONSTANT,
  NEVER_CONSTANT
};

enum class buff_tick_behavior
{
  NONE,

  // tick timer is reset on refresh of the dot/buff (next tick is rescheduled)
  CLIP,

  // tick timer stays intact on refresh of the dot/buff (next tick won't be rescheduled)
  REFRESH
};

enum class buff_tick_time_behavior
{
  UNHASTED,
  HASTED,
  CUSTOM
};

/*
 Buff refresh mechanism during trigger.

 Defaults to _PANDEMIC for ticking buffs, DURATION for normal buffs.
 */
enum class buff_refresh_behavior
{
  // Constructor default, determines "autodetection" in buff_t::buff_t
  NONE = -1,

  // Disable refresh by triggering
  DISABLED,

  // Refresh to given duration
  DURATION,

  // Refresh to given duration plus remaining duration
  EXTEND,

  // Refresh to given duration plus min(0.3 * new_duration, remaining_duration)
  PANDEMIC,

  // Refresh to given duration plus ongoing tick time
  TICK,

  // Refresh to given duration or remaining duration, whichever is greater
  MAX,

  // Refresh to duration returned by the custom callback
  CUSTOM,
};

enum class buff_stack_behavior
{
  DEFAULT,

  // Asynchronous buffs use separate duration for each stack application. This means that each stack expires on its own.
  ASYNCHRONOUS,
};

enum class movement_direction_type : int
{
  NONE,
  OMNI,
  TOWARDS,
  AWAY,
  RANDOM, // Reserved for raid event. Chooses random direction from {OMNI, TOWARDS, AWAY}
  MAX,
};

enum race_e
{
  RACE_NONE = 0,
  // Creature Types
  RACE_BEAST,
  RACE_DRAGONKIN,
  RACE_DEMON,
  RACE_ELEMENTAL,
  RACE_GIANT,
  RACE_UNDEAD,          // also player race, decouple if necessary
  RACE_HUMANOID,
  RACE_CRITTER,         // trivial
  RACE_MECHANICAL,
  RACE_NOT_SPECIFIED,
  RACE_TOTEM,
  RACE_NON_COMBAT_PET,  // trivial
  RACE_GAS_CLOUD,       // trivial
  RACE_WILD_PET,        // trivial
  RACE_ABERRATION,
  // Player Races
  RACE_NIGHT_ELF,
  RACE_HUMAN,
  RACE_GNOME,
  RACE_DWARF,
  RACE_DRAENEI,
  RACE_WORGEN,
  RACE_ORC,
  RACE_TROLL,
  RACE_BLOOD_ELF,
  RACE_TAUREN,
  RACE_GOBLIN,
  RACE_PANDAREN,
  RACE_PANDAREN_ALLIANCE,
  RACE_PANDAREN_HORDE,
  RACE_VOID_ELF,
  RACE_LIGHTFORGED_DRAENEI,
  RACE_HIGHMOUNTAIN_TAUREN,
  RACE_NIGHTBORNE,
  RACE_DARK_IRON_DWARF,
  RACE_MAGHAR_ORC,
  RACE_ZANDALARI_TROLL,
  RACE_KUL_TIRAN,
  RACE_VULPERA,
  RACE_MECHAGNOME,
  RACE_DRACTHYR_ALLIANCE,
  RACE_DRACTHYR_HORDE,
  RACE_EARTHEN_ALLIANCE,
  RACE_EARTHEN_HORDE,
  RACE_HARANIR_ALLIANCE,
  RACE_HARANIR_HORDE,
  RACE_UNKNOWN,
  RACE_MAX
};

inline bool is_pandaren( race_e r )
{
  return RACE_PANDAREN <= r && r <= RACE_PANDAREN_HORDE;
}

enum player_e
{
  PLAYER_SPECIAL_SCALE10 = -10,
  PLAYER_SPECIAL_SCALE9  = -9,
  PLAYER_SPECIAL_SCALE8  = -8,
  PLAYER_SPECIAL_SCALE7  = -7,
  PLAYER_SPECIAL_SCALE6  = -6,
  PLAYER_SPECIAL_SCALE5  = -5,
  PLAYER_SPECIAL_SCALE4  = -4,
  PLAYER_SPECIAL_SCALE3  = -3,
  PLAYER_SPECIAL_SCALE2  = -2,
  PLAYER_SPECIAL_SCALE   = -1,
  PLAYER_NONE            = 0,
  DEATH_KNIGHT,
  DEMON_HUNTER,
  DRUID,
  EVOKER,
  HUNTER,
  MAGE,
  MONK,
  PALADIN,
  PRIEST,
  ROGUE,
  SHAMAN,
  WARLOCK,
  WARRIOR,
  PLAYER_SIMPLIFIED,
  PLAYER_PET,
  PLAYER_GUARDIAN,
  HEALING_ENEMY,
  ENEMY,
  ENEMY_ADD,
  ENEMY_ADD_BOSS,
  TANK_DUMMY,
  PLAYER_MAX
};

enum hero_tree_e
{
  HERO_NONE                      = 0,
  HERO_VOIDWEAVER                = 18,
  HERO_ARCHON                    = 19,
  HERO_ORACLE                    = 20,
  HERO_DRUID_OF_THE_CLAW         = 21,
  HERO_WILDSTALKER               = 22,
  HERO_KEEPER_OF_THE_GROVE       = 23,
  HERO_ELUNES_CHOSEN             = 24,
  HERO_SANLAYN                   = 31,
  HERO_RIDER_OF_THE_APOCALYPSE   = 32,
  HERO_DEATHBRINGER              = 33,
  HERO_FELSCARRED                = 34,
  HERO_ALDRACHI_REAVER           = 35,
  HERO_SCALECOMMANDER            = 36,
  HERO_FLAMESHAPER               = 37,
  HERO_CHRONOWARDEN              = 38,
  HERO_SUNFURY                   = 39,
  HERO_SPELLSLINGER              = 40,
  HERO_FROSTFIRE                 = 41,
  HERO_SENTINEL                  = 42,
  HERO_PACK_LEADER               = 43,
  HERO_DARK_RANGER               = 44,
  HERO_TEMPLAR                   = 48,
  HERO_LIGHTSMITH                = 49,
  HERO_HERALD_OF_THE_SUN         = 50,
  HERO_TRICKSTER                 = 51,
  HERO_FATEBOUND                 = 52,
  HERO_DEATHSTALKER              = 53,
  HERO_TOTEMIC                   = 54,
  HERO_STORMBRINGER              = 55,
  HERO_FARSEER                   = 56,
  HERO_SOUL_HARVESTER            = 57,
  HERO_HELLCALLER                = 58,
  HERO_DIABOLIST                 = 59,
  HERO_SLAYER                    = 60,
  HERO_MOUNTAIN_THANE            = 61,
  HERO_COLOSSUS                  = 62,
  HERO_CONDUIT_OF_THE_CELESTIALS = 64,
  HERO_SHADOPAN                  = 65,
  HERO_MASTER_OF_HARMONY         = 66,
  HERO_ANNIHILATOR               = 124,
  HERO_VOID_SCARRED              = 126,
  HERO_MAX
};

enum pet_e
{
  PET_NONE = 0,

  // Ferocity
  PET_CARRION_BIRD,
  PET_CAT,
  PET_CORE_HOUND,
  PET_DEVILSAUR,
  PET_DOG,
  PET_FOX,
  PET_HYENA,
  PET_MOTH,
  PET_RAPTOR,
  PET_SPIRIT_BEAST,
  PET_TALLSTRIDER,
  PET_WASP,
  PET_WOLF,

  PET_FEROCITY_TYPE,

  // Tenacity
  PET_BEAR,
  PET_BEETLE,
  PET_BOAR,
  PET_CRAB,
  PET_CROCOLISK,
  PET_GORILLA,
  PET_RHINO,
  PET_SCORPID,
  PET_SHALE_SPIDER,
  PET_TURTLE,
  PET_WARP_STALKER,
  PET_WORM,
  PET_DUCK,
  //PET_RIVERBEAST,

  PET_TENACITY_TYPE,

  // Cunning
  PET_BAT,
  PET_BIRD_OF_PREY,
  PET_CHIMAERA,
  PET_DRAGONHAWK,
  PET_MONKEY,
  PET_NETHER_RAY,
  PET_RAVAGER,
  PET_SERPENT,
  PET_SILITHID,
  PET_SPIDER,
  PET_SPOREBAT,
  PET_WIND_SERPENT,

  PET_CUNNING_TYPE,

  PET_HUNTER,

  PET_FELGUARD,
  PET_FELHUNTER,
  PET_IMP,
  PET_VOIDWALKER,
  PET_SAYAAD,
  PET_INFERNAL,
  PET_DOOMGUARD,
  PET_WILD_IMP,
  PET_DREADSTALKER,
  PET_VILEFIEND,
  PET_DEMONIC_TYRANT,
  PET_SERVICE_IMP,
  PET_SERVICE_FELHUNTER,
  PET_SERVICE_FELGUARD,
  PET_WARLOCK_RANDOM,
  PET_PIT_LORD,
  PET_DOOMFIEND,
  PET_DARKGLARE,
  PET_OBSERVER,
  PET_THAL_KIEL,
  PET_LADY_SACROLASH,
  PET_GRAND_WARLOCK_ALYTHESS,
  PET_ANTORAN_INQUISITOR,
  PET_ANTORAN_JAILER,
  PET_WARLOCK,

  PET_GHOUL,
  PET_BLOODWORMS,
  PET_DANCING_RUNE_WEAPON,
  PET_LESSER_GHOUL,
  PET_ARMY_GHOUL,
  PET_MAGUS_OF_THE_DEAD,
  PET_LORD_OF_THE_DEAD,
  PET_RISEN_SKULKER,
  PET_ABOMINATION,
  PET_GARGOYOLE,
  PET_BLOOD_BEAST,
  PET_MOGRAINE,
  PET_WHITEMANE,
  PET_TROLLBANE,
  PET_NAZGRIM,
  PET_DEATH_KNIGHT,

  PET_TREANTS,
  PET_DRUID,

  PET_WATER_ELEMENTAL,
  PET_MAGE,

  PET_SPIRIT_WOLF,
  PET_FIRE_ELEMENTAL,
  PET_EARTH_ELEMENTAL,
  PET_SHAMAN,

  PET_XUEN,
  PET_NIUZAO,
  PET_CHIJI,
  PET_YULON,
  PET_MONK_STATUE,
  PET_MONK,

  PET_ENEMY,

  PET_MAX
};

enum class result_amount_type
{
  NONE = -1,
  DMG_DIRECT       = 0,
  DMG_OVER_TIME    = 1,
  HEAL_DIRECT,
  HEAL_OVER_TIME,
  ABSORB
};

enum stats_e
{
  STATS_DMG,
  STATS_HEAL,
  STATS_ABSORB,
  STATS_NEUTRAL
};

enum dot_behavior_e
{
  DOT_CLIP,             // DoT is restarted from scratch with Duration
  DOT_EXTEND,           // DoT is extended indefinitely by Duration
  DOT_REFRESH_DURATION, // Duration + Current Tick
  DOT_REFRESH_PANDEMIC, // Duration + Current Duration up to 1.3x
  DOT_ROLLING,          // Duration + Current Tick, except for during last partial tick
  DOT_NONE              // Does not refresh
};

enum dot_copy_e
{
  DOT_COPY_START,            // Start a new DoT with the same remaining duration
  DOT_COPY_CLONE,            // Clone everything from source DoT (tick time, stacks, remaining duration, etc) and refresh if active
  DOT_COPY_CLONE_NO_REFRESH, // Clone everything from source DoT (tick time, stacks, remaining duration, etc) 
};

enum dynamic_tick_action_e
{
  TICK_ACTION_NONE = 0,  // no state snapshot on parent dot tick
  TICK_ACTION_UPDATE,    // update state on parent dot tick
  TICK_ACTION_SNAPSHOT   // snapshot state on parent dot tick
};

enum attribute_e
{
  ATTRIBUTE_NONE = 0,
  ATTR_STRENGTH,
  ATTR_AGILITY,
  ATTR_STAMINA,
  ATTR_INTELLECT,
  ATTR_SPIRIT,
  // WoD Hybrid attributes
  ATTR_AGI_INT,
  ATTR_STR_AGI,
  ATTR_STR_INT,
  ATTR_STR_AGI_INT,
  ATTRIBUTE_MAX,

  /**
   * "All stats" enchant attribute cap to prevent
   * double/triple/quadrupledipping
   */
  ATTRIBUTE_STAT_ALL_MAX = ATTR_AGI_INT
};

enum resource_e
{
  RESOURCE_NONE = 0,
  RESOURCE_HEALTH,
  RESOURCE_MANA,
  RESOURCE_RAGE,
  RESOURCE_FOCUS,
  RESOURCE_ENERGY,
  RESOURCE_RUNIC_POWER,
  RESOURCE_SOUL_SHARD,
  RESOURCE_ASTRAL_POWER,
  RESOURCE_HOLY_POWER,
  RESOURCE_MAELSTROM,
  RESOURCE_CHI,
  RESOURCE_INSANITY,
  RESOURCE_FURY,
  RESOURCE_RUNE,
  RESOURCE_COMBO_POINT,
  RESOURCE_ESSENCE,
  RESOURCE_MAX
};

enum result_e
{
  RESULT_UNKNOWN = -1,
  RESULT_NONE    = 0,
  RESULT_MISS,
  RESULT_DODGE,
  RESULT_PARRY,
  RESULT_GLANCE,
  RESULT_CRIT,
  RESULT_HIT,
  RESULT_MAX
};

enum block_result_e
{
  BLOCK_RESULT_UNKNOWN   = -1,
  BLOCK_RESULT_UNBLOCKED = 0,
  BLOCK_RESULT_BLOCKED,
  BLOCK_RESULT_CRIT_BLOCKED,
  BLOCK_RESULT_MAX
};

enum full_result_e
{
  FULLTYPE_UNKNOWN = -1,
  FULLTYPE_NONE    = 0,
  FULLTYPE_MISS,
  FULLTYPE_DODGE,
  FULLTYPE_PARRY,
  FULLTYPE_GLANCE_CRITBLOCK,
  FULLTYPE_GLANCE_BLOCK,
  FULLTYPE_GLANCE,
  FULLTYPE_CRIT_CRITBLOCK,
  FULLTYPE_CRIT_BLOCK,
  FULLTYPE_CRIT,
  FULLTYPE_HIT_CRITBLOCK,
  FULLTYPE_HIT_BLOCK,
  FULLTYPE_HIT,
  FULLTYPE_MAX
};

const unsigned RESULT_HIT_MASK =
    ( 1 << RESULT_GLANCE ) | ( 1 << RESULT_CRIT ) | ( 1 << RESULT_HIT );

const unsigned RESULT_CRIT_MASK = ( 1 << RESULT_CRIT );

const unsigned RESULT_MISS_MASK = ( 1 << RESULT_MISS );

const unsigned RESULT_DODGE_MASK = ( 1 << RESULT_DODGE );

const unsigned RESULT_PARRY_MASK = ( 1 << RESULT_PARRY );

const unsigned RESULT_NONE_MASK = ( 1 << RESULT_NONE );

const unsigned RESULT_ALL_MASK = -1;

enum special_effect_e
{
  SPECIAL_EFFECT_NONE = -1,
  SPECIAL_EFFECT_EQUIP,
  SPECIAL_EFFECT_USE,
  SPECIAL_EFFECT_PASSIVE,
  SPECIAL_EFFECT_FALLBACK // Internal use only for fallback special effects
};

enum special_effect_source_e
{
  SPECIAL_EFFECT_SOURCE_NONE = -1,
  SPECIAL_EFFECT_SOURCE_ITEM,
  SPECIAL_EFFECT_SOURCE_ENCHANT,
  SPECIAL_EFFECT_SOURCE_ADDON,
  SPECIAL_EFFECT_SOURCE_GEM,
  SPECIAL_EFFECT_SOURCE_SOCKET_BONUS,
  SPECIAL_EFFECT_SOURCE_RACE,
  SPECIAL_EFFECT_SOURCE_AZERITE,
  SPECIAL_EFFECT_SOURCE_AZERITE_ESSENCE,
  SPECIAL_EFFECT_SOURCE_FALLBACK,
  SPECIAL_EFFECT_SOURCE_TEMPORARY_ENCHANT
};

enum special_effect_buff_e
{
  SPECIAL_EFFECT_BUFF_NONE = -1,
  SPECIAL_EFFECT_BUFF_CUSTOM,
  SPECIAL_EFFECT_BUFF_STAT,
  SPECIAL_EFFECT_BUFF_ABSORB,
  SPECIAL_EFFECT_BUFF_DISABLED
};

enum special_effect_action_e
{
  SPECIAL_EFFECT_ACTION_NONE = -1,
  SPECIAL_EFFECT_ACTION_CUSTOM,
  SPECIAL_EFFECT_ACTION_SPELL,
  SPECIAL_EFFECT_ACTION_HEAL,
  SPECIAL_EFFECT_ACTION_ATTACK,
  SPECIAL_EFFECT_ACTION_RESOURCE,
  SPECIAL_EFFECT_ACTION_DISABLED
};

enum action_e
{
  /// On use actions
  ACTION_USE = 0,

  /// Hostile spells
  ACTION_SPELL,

  /// Hostile attacks
  ACTION_ATTACK,

  /// Heals
  ACTION_HEAL,

  /// Absorbs
  ACTION_ABSORB,

  /// Sequences
  ACTION_SEQUENCE,

  /// Miscellaneous actions
  ACTION_OTHER,

  // Call other action lists
  ACTION_CALL,

  // Perform operations on a variable
  ACTION_VARIABLE,

  ACTION_MAX
};

enum school_e
{
  SCHOOL_NONE = 0,
  SCHOOL_ARCANE,
  SCHOOL_FIRE,
  SCHOOL_FROST,
  SCHOOL_HOLY,
  SCHOOL_NATURE,
  SCHOOL_SHADOW,
  SCHOOL_PHYSICAL,
  SCHOOL_MAX_PRIMARY,
  SCHOOL_FROSTFIRE,
  SCHOOL_HOLYSTRIKE,
  SCHOOL_FLAMESTRIKE,
  SCHOOL_HOLYFIRE,
  SCHOOL_STORMSTRIKE,
  SCHOOL_HOLYSTORM,
  SCHOOL_FIRESTORM,
  SCHOOL_FROSTSTRIKE,
  SCHOOL_HOLYFROST,
  SCHOOL_FROSTSTORM,
  SCHOOL_SHADOWSTRIKE,
  SCHOOL_SHADOWLIGHT,
  SCHOOL_SHADOWFLAME,
  SCHOOL_SHADOWSTORM,
  SCHOOL_SHADOWFROST,
  SCHOOL_SPELLSTRIKE,
  SCHOOL_DIVINE,
  SCHOOL_SPELLFIRE,
  SCHOOL_ASTRAL,
  SCHOOL_SPELLFROST,
  SCHOOL_SPELLSHADOW,
  SCHOOL_ELEMENTAL,
  SCHOOL_COSMIC,
  SCHOOL_CHROMATIC,
  SCHOOL_CHROMASTRIKE,
  SCHOOL_MAGIC,
  SCHOOL_CHAOS,
  SCHOOL_DRAIN,
  SCHOOL_MAX
};

enum school_mask_e
{
  SCHOOL_MASK_PHYSICAL = 0x01,
  SCHOOL_MASK_HOLY     = 0x02,
  SCHOOL_MASK_FIRE     = 0x04,
  SCHOOL_MASK_NATURE   = 0x08,
  SCHOOL_MASK_FROST    = 0x10,
  SCHOOL_MASK_SHADOW   = 0x20,
  SCHOOL_MASK_ARCANE   = 0x40,
};

const int64_t SCHOOL_ATTACK_MASK = ( ( int64_t( 1 ) << SCHOOL_PHYSICAL ) |
                                     ( int64_t( 1 ) << SCHOOL_HOLYSTRIKE ) |
                                     ( int64_t( 1 ) << SCHOOL_FLAMESTRIKE ) |
                                     ( int64_t( 1 ) << SCHOOL_STORMSTRIKE ) |
                                     ( int64_t( 1 ) << SCHOOL_FROSTSTRIKE ) |
                                     ( int64_t( 1 ) << SCHOOL_SHADOWSTRIKE ) |
                                     ( int64_t( 1 ) << SCHOOL_SPELLSTRIKE ) |
                                     ( int64_t( 1 ) << SCHOOL_COSMIC ) );
// SCHOOL_CHAOS should probably be added here too.

const int64_t SCHOOL_SPELL_MASK( ( int64_t( 1 ) << SCHOOL_ARCANE ) | ( int64_t( 1 ) << SCHOOL_CHAOS ) |
                                 ( int64_t( 1 ) << SCHOOL_FIRE ) | ( int64_t( 1 ) << SCHOOL_FROST ) |
                                 ( int64_t( 1 ) << SCHOOL_FROSTFIRE ) | ( int64_t( 1 ) << SCHOOL_HOLY ) |
                                 ( int64_t( 1 ) << SCHOOL_NATURE ) | ( int64_t( 1 ) << SCHOOL_SHADOW ) |
                                 ( int64_t( 1 ) << SCHOOL_HOLYSTRIKE ) | ( int64_t( 1 ) << SCHOOL_FLAMESTRIKE ) |
                                 ( int64_t( 1 ) << SCHOOL_HOLYFIRE ) | ( int64_t( 1 ) << SCHOOL_STORMSTRIKE ) |
                                 ( int64_t( 1 ) << SCHOOL_HOLYSTORM ) | ( int64_t( 1 ) << SCHOOL_FIRESTORM ) |
                                 ( int64_t( 1 ) << SCHOOL_FROSTSTRIKE ) | ( int64_t( 1 ) << SCHOOL_HOLYFROST ) |
                                 ( int64_t( 1 ) << SCHOOL_FROSTSTORM ) | ( int64_t( 1 ) << SCHOOL_SHADOWSTRIKE ) |
                                 ( int64_t( 1 ) << SCHOOL_SHADOWLIGHT ) | ( int64_t( 1 ) << SCHOOL_SHADOWFLAME ) |
                                 ( int64_t( 1 ) << SCHOOL_SHADOWSTORM ) | ( int64_t( 1 ) << SCHOOL_SHADOWFROST ) |
                                 ( int64_t( 1 ) << SCHOOL_SPELLSTRIKE ) | ( int64_t( 1 ) << SCHOOL_DIVINE ) |
                                 ( int64_t( 1 ) << SCHOOL_SPELLFIRE ) | ( int64_t( 1 ) << SCHOOL_ASTRAL ) |
                                 ( int64_t( 1 ) << SCHOOL_SPELLFROST ) | ( int64_t( 1 ) << SCHOOL_SPELLSHADOW ) |
                                 ( int64_t( 1 ) << SCHOOL_ELEMENTAL ) | ( int64_t( 1 ) << SCHOOL_COSMIC ) |
                                 ( int64_t( 1 ) << SCHOOL_CHROMATIC ) | ( int64_t( 1 ) << SCHOOL_CHROMASTRIKE ) |
                                 ( int64_t( 1 ) << SCHOOL_MAGIC ) );

const int64_t SCHOOL_MAGIC_MASK( ( int64_t( 1 ) << SCHOOL_ARCANE ) |
                                 ( int64_t( 1 ) << SCHOOL_FIRE ) |
                                 ( int64_t( 1 ) << SCHOOL_FROST ) |
                                 ( int64_t( 1 ) << SCHOOL_FROSTFIRE ) |
                                 ( int64_t( 1 ) << SCHOOL_HOLY ) |
                                 ( int64_t( 1 ) << SCHOOL_NATURE ) |
                                 ( int64_t( 1 ) << SCHOOL_SHADOW ) );

const int64_t SCHOOL_ALL_MASK( -1 );

enum weapon_e
{
  WEAPON_NONE = 0,
  WEAPON_DAGGER,
  WEAPON_SMALL,
  WEAPON_BEAST,
  WEAPON_SWORD,
  WEAPON_MACE,
  WEAPON_AXE,
  WEAPON_FIST,
  WEAPON_WARGLAIVE,
  WEAPON_1H,
  WEAPON_BEAST_2H,
  WEAPON_SWORD_2H,
  WEAPON_MACE_2H,
  WEAPON_AXE_2H,
  WEAPON_STAFF,
  WEAPON_POLEARM,
  WEAPON_2H,
  WEAPON_BOW,
  WEAPON_CROSSBOW,
  WEAPON_GUN,
  WEAPON_WAND,
  WEAPON_THROWN,
  WEAPON_BEAST_RANGED,
  WEAPON_RANGED,
  WEAPON_MAX
};

enum slot_e  // these enum values match armory settings
{
  SLOT_INVALID   = -1,
  SLOT_HEAD      = 0,
  SLOT_NECK      = 1,
  SLOT_SHOULDERS = 2,
  SLOT_SHIRT     = 3,
  SLOT_CHEST     = 4,
  SLOT_WAIST     = 5,
  SLOT_LEGS      = 6,
  SLOT_FEET      = 7,
  SLOT_WRISTS    = 8,
  SLOT_HANDS     = 9,
  SLOT_FINGER_1  = 10,
  SLOT_FINGER_2  = 11,
  SLOT_TRINKET_1 = 12,
  SLOT_TRINKET_2 = 13,
  SLOT_BACK      = 14,
  SLOT_MAIN_HAND = 15,
  SLOT_OFF_HAND  = 16,
  SLOT_RANGED    = 17,
  SLOT_TABARD    = 18,
  SLOT_MAX       = 19,
  SLOT_MIN       = 0
};

// 1, 2, 3, 4
const unsigned N_SEASON = 5;
const unsigned MIN_SEASON = 1;

// Set bonus .. bonus. They map to a vector internally, so each enum value is just the vector
// element index.
enum set_bonus_e
{
  B_NONE = -1,
  B1     = 0,
  B2     = 1,
  B3     = 2,
  B4     = 3,
  B5     = 4,
  B6     = 5,
  B7     = 6,
  B8     = 7,
  B_MAX  = 8
};

/**
 * @brief Type safe tier enum.
 *
 * MUST correspond to the ordering in
 * dbc_extract/dbc/generator.py SetBonusListGenerator::set_bonus_map
 */
enum set_bonus_type_e
{
  SET_BONUS_NONE = -1,

  // Actual tier support in SIMC
  SL3,
  DF1,
  DF_PSF,
  DF_HSG,
  DF_AV,
  DF_WC,
  DF_RT,
  DF2,
  DF3,
  DF4,
  TWW_ECB,
  TWW_FSR,
  TWW_KCI,
  TWW1,
  TWW_WDusk,
  TWW_WDawn,
  TWW2,
  TWW3,
  MID_ST,
  MID_AT,
  TWW_SOTV,
  MID_MRM,
  MID_RWR,
  MID_TD,
  MID_VB,
  MID_UWP,
  MID1,
  MID2,
  MID_BOZ,
  SET_BONUS_MAX
};

enum stat_e
{
  STAT_NONE = 0,
  STAT_STRENGTH,
  STAT_AGILITY,
  STAT_STAMINA,
  STAT_INTELLECT,
  STAT_SPIRIT,
  STAT_AGI_INT,
  STAT_STR_AGI,
  STAT_STR_INT,
  STAT_STR_AGI_INT,
  STAT_HEALTH,
  STAT_MANA,
  STAT_RAGE,
  STAT_ENERGY,
  STAT_FOCUS,
  STAT_RUNIC,
  STAT_MAX_HEALTH,
  STAT_MAX_MANA,
  STAT_MAX_RAGE,
  STAT_MAX_ENERGY,
  STAT_MAX_FOCUS,
  STAT_MAX_RUNIC,
  STAT_SPELL_POWER,
  STAT_ATTACK_POWER,
  STAT_EXPERTISE_RATING,
  STAT_EXPERTISE_RATING2,
  STAT_HIT_RATING,
  STAT_HIT_RATING2,
  STAT_CRIT_RATING,
  STAT_HASTE_RATING,
  STAT_MASTERY_RATING,
  STAT_VERSATILITY_RATING,
  STAT_LEECH_RATING,
  STAT_SPEED_RATING,
  STAT_AVOIDANCE_RATING,
  STAT_CORRUPTION,
  STAT_CORRUPTION_RESISTANCE,
  STAT_ARMOR,
  STAT_BONUS_ARMOR,
  STAT_RESILIENCE_RATING,
  STAT_DODGE_RATING,
  STAT_PARRY_RATING,
  STAT_BLOCK_RATING, // Block CHANCE rating. Block damage reduction is in player_t::composite_block_value()
  STAT_PVP_POWER,
  STAT_WEAPON_DPS,
  STAT_WEAPON_OFFHAND_DPS,
  STAT_ALL,
  STAT_MAX,

  STAT_ANY_DPS, // Only for use with buff_has_stat() queries
};
#define check( x )                                                             \
  static_assert( static_cast<int>( STAT_##x ) == static_cast<int>( ATTR_##x ), \
                 "stat_e and attribute_e must be kept in sync" )
check( STRENGTH );
check( AGILITY );
check( STAMINA );
check( INTELLECT );
check( SPIRIT );
check( AGI_INT );
check( STR_AGI );
check( STR_INT );
check( STR_AGI_INT );
#undef check

enum rating_e
{
  RATING_DODGE = 0,
  RATING_PARRY,
  RATING_BLOCK,
  RATING_MELEE_HIT,
  RATING_RANGED_HIT,
  RATING_SPELL_HIT,
  RATING_MELEE_CRIT,
  RATING_RANGED_CRIT,
  RATING_SPELL_CRIT,
  RATING_PVP_RESILIENCE,
  RATING_LEECH,
  RATING_MELEE_HASTE,
  RATING_RANGED_HASTE,
  RATING_SPELL_HASTE,
  RATING_EXPERTISE,
  RATING_MASTERY,
  RATING_PVP_POWER,
  RATING_DAMAGE_VERSATILITY,
  RATING_HEAL_VERSATILITY,
  RATING_MITIGATION_VERSATILITY,
  RATING_SPEED,
  RATING_AVOIDANCE,
  RATING_CORRUPTION,
  RATING_CORRUPTION_RESISTANCE,
  RATING_MAX
};

inline stat_e stat_from_attr( attribute_e a )
{
  // Assumes that ATTR_X == STAT_X
  return static_cast<stat_e>( a );
}

enum scale_metric_e
{
  SCALE_METRIC_NONE = 0,
  SCALE_METRIC_DPS,
  SCALE_METRIC_DPSP,
  SCALE_METRIC_DPSE,
  SCALE_METRIC_HPS,
  SCALE_METRIC_HPSE,
  SCALE_METRIC_APS,
  SCALE_METRIC_HAPS,
  SCALE_METRIC_DTPS,
  SCALE_METRIC_DMG_TAKEN,
  SCALE_METRIC_HTPS,
  SCALE_METRIC_DEATHS,
  SCALE_METRIC_TIME,
  SCALE_METRIC_RAID_DPS,
  SCALE_METRIC_DHAPS,
  SCALE_METRIC_MAX
};

enum cache_e
{
  CACHE_NONE = 0,
  CACHE_STRENGTH,
  CACHE_AGILITY,
  CACHE_STAMINA,
  CACHE_INTELLECT,
  CACHE_SPIRIT,
  CACHE_AGI_INT,
  CACHE_STR_AGI,
  CACHE_STR_INT,
  CACHE_STR_AGI_INT,
  CACHE_SPELL_POWER,
  CACHE_ATTACK_POWER,
  CACHE_WEAPON_DPS,
  CACHE_EXP,
  CACHE_ATTACK_EXP,
  CACHE_HIT,
  CACHE_ATTACK_HIT,
  CACHE_SPELL_HIT,
  CACHE_CRIT_CHANCE,
  CACHE_ATTACK_CRIT_CHANCE,
  CACHE_SPELL_CRIT_CHANCE,
  CACHE_RPPM_CRIT,
  CACHE_HASTE,
  CACHE_ATTACK_HASTE,
  CACHE_SPELL_HASTE,
  CACHE_RPPM_HASTE,
  CACHE_AUTO_ATTACK_SPEED,
  CACHE_SPELL_CAST_SPEED,
  CACHE_VERSATILITY,
  CACHE_DAMAGE_VERSATILITY,
  CACHE_HEAL_VERSATILITY,
  CACHE_MITIGATION_VERSATILITY,
  CACHE_MASTERY,
  CACHE_DODGE,
  CACHE_PARRY,
  CACHE_BLOCK,
  CACHE_ARMOR,
  CACHE_BONUS_ARMOR,
  CACHE_CRIT_AVOIDANCE,
  CACHE_MISS,
  CACHE_LEECH,
  CACHE_RUN_SPEED,
  CACHE_AVOIDANCE,
  CACHE_CORRUPTION,
  CACHE_CORRUPTION_RESISTANCE,
  CACHE_PLAYER_DAMAGE_MULTIPLIER,
  CACHE_PLAYER_HEAL_MULTIPLIER,
  CACHE_PET_DAMAGE_MULTIPLIER,
  CACHE_GUARDIAN_DAMAGE_MULTIPLIER,
  CACHE_MAX
};

enum stat_pct_buff_type
{
  STAT_PCT_BUFF_CRIT,
  STAT_PCT_BUFF_HASTE,
  STAT_PCT_BUFF_VERSATILITY,
  STAT_PCT_BUFF_MASTERY,
  STAT_PCT_BUFF_STRENGTH,
  STAT_PCT_BUFF_AGILITY,
  STAT_PCT_BUFF_STAMINA,
  STAT_PCT_BUFF_INTELLECT,
  STAT_PCT_BUFF_SPIRIT,
  STAT_PCT_BUFF_MAX
};

#define check( x )                                                   \
  static_assert(                                                     \
      static_cast<int>( CACHE_##x ) == static_cast<int>( ATTR_##x ), \
      "cache_e and attribute_e must be kept in sync" )
check( STRENGTH );
check( AGILITY );
check( STAMINA );
check( INTELLECT );
check( SPIRIT );
check( AGI_INT );
check( STR_AGI );
check( STR_INT );
check( STR_AGI_INT );
#undef check

inline cache_e cache_from_stat( stat_e st )
{
  switch ( st )
    {
      case STAT_STRENGTH:
      case STAT_AGILITY:
      case STAT_STAMINA:
      case STAT_INTELLECT:
      case STAT_SPIRIT:
      case STAT_AGI_INT:
      case STAT_STR_AGI:
      case STAT_STR_INT:
      case STAT_STR_AGI_INT:
        return static_cast<cache_e>( st );
      case STAT_SPELL_POWER:
        return CACHE_SPELL_POWER;
      case STAT_ATTACK_POWER:
        return CACHE_ATTACK_POWER;
      case STAT_WEAPON_DPS:
      case STAT_WEAPON_OFFHAND_DPS:
        return CACHE_WEAPON_DPS;
      case STAT_EXPERTISE_RATING:
      case STAT_EXPERTISE_RATING2:
        return CACHE_EXP;
      case STAT_HIT_RATING:
      case STAT_HIT_RATING2:
        return CACHE_HIT;
      case STAT_CRIT_RATING:
        return CACHE_CRIT_CHANCE;
      case STAT_HASTE_RATING:
        return CACHE_HASTE;
      case STAT_MASTERY_RATING:
        return CACHE_MASTERY;
      case STAT_DODGE_RATING:
        return CACHE_DODGE;
      case STAT_PARRY_RATING:
        return CACHE_PARRY;
      case STAT_BLOCK_RATING:
        return CACHE_BLOCK;
      case STAT_ARMOR:
        return CACHE_ARMOR;
      case STAT_BONUS_ARMOR:
        return CACHE_BONUS_ARMOR;
      case STAT_VERSATILITY_RATING:
        return CACHE_VERSATILITY;
      case STAT_LEECH_RATING:
        return CACHE_LEECH;
      case STAT_SPEED_RATING:
        return CACHE_RUN_SPEED;
      case STAT_AVOIDANCE_RATING:
        return CACHE_AVOIDANCE;
      default:
        break;
    }
  return CACHE_NONE;
}

inline cache_e cache_from_stat_pct_buff( stat_pct_buff_type spb )
{
  switch ( spb )
  {
    case STAT_PCT_BUFF_CRIT: return CACHE_CRIT_CHANCE;
    case STAT_PCT_BUFF_HASTE: return CACHE_HASTE;
    case STAT_PCT_BUFF_VERSATILITY: return CACHE_VERSATILITY;
    case STAT_PCT_BUFF_MASTERY: return CACHE_MASTERY;
    case STAT_PCT_BUFF_STRENGTH: return CACHE_STRENGTH;
    case STAT_PCT_BUFF_AGILITY: return CACHE_AGILITY;
    case STAT_PCT_BUFF_STAMINA: return CACHE_STAMINA;
    case STAT_PCT_BUFF_INTELLECT: return CACHE_INTELLECT;
    case STAT_PCT_BUFF_SPIRIT: return CACHE_SPIRIT;
    case STAT_PCT_BUFF_MAX: break;
  }
  assert( false ); return CACHE_NONE;
}

// Gear Rating Conversions ==================================================

inline cache_e cache_from_rating( rating_e r )
{
  switch ( r )
  {
    case RATING_SPELL_HASTE: return CACHE_SPELL_HASTE;
    case RATING_SPELL_HIT: return CACHE_SPELL_HIT;
    case RATING_SPELL_CRIT: return CACHE_SPELL_CRIT_CHANCE;
    case RATING_MELEE_HASTE: return CACHE_ATTACK_HASTE;
    case RATING_MELEE_HIT: return CACHE_ATTACK_HIT;
    case RATING_MELEE_CRIT: return CACHE_ATTACK_CRIT_CHANCE;
    case RATING_RANGED_HASTE: return CACHE_ATTACK_HASTE;
    case RATING_RANGED_HIT: return CACHE_ATTACK_HIT;
    case RATING_RANGED_CRIT: return CACHE_ATTACK_CRIT_CHANCE;
    case RATING_EXPERTISE: return CACHE_EXP;
    case RATING_DODGE: return CACHE_DODGE;
    case RATING_PARRY: return CACHE_PARRY;
    case RATING_BLOCK: return CACHE_BLOCK;
    case RATING_MASTERY: return CACHE_MASTERY;
    case RATING_PVP_POWER: return CACHE_NONE;
    case RATING_PVP_RESILIENCE: return CACHE_NONE;
    case RATING_DAMAGE_VERSATILITY: return CACHE_DAMAGE_VERSATILITY;
    case RATING_HEAL_VERSATILITY: return CACHE_HEAL_VERSATILITY;
    case RATING_MITIGATION_VERSATILITY: return CACHE_MITIGATION_VERSATILITY;
    case RATING_LEECH: return CACHE_LEECH;
    case RATING_SPEED: return CACHE_RUN_SPEED;
    case RATING_AVOIDANCE: return CACHE_AVOIDANCE;
    case RATING_CORRUPTION: return CACHE_CORRUPTION;
    case RATING_CORRUPTION_RESISTANCE: return CACHE_CORRUPTION_RESISTANCE;
    default: break;
  }
  assert( false ); return CACHE_NONE;
}

enum position_e
{
  POSITION_NONE = 0,
  POSITION_FRONT,
  POSITION_BACK,
  POSITION_RANGED_FRONT,
  POSITION_RANGED_BACK,
  POSITION_MAX
};

enum profession_e
{
  PROFESSION_NONE = 0,
  PROF_ALCHEMY,
  PROF_MINING,
  PROF_HERBALISM,
  PROF_LEATHERWORKING,
  PROF_ENGINEERING,
  PROF_BLACKSMITHING,
  PROF_INSCRIPTION,
  PROF_SKINNING,
  PROF_TAILORING,
  PROF_JEWELCRAFTING,
  PROF_ENCHANTING,
  PROFESSION_MAX
};

enum role_e
{
  ROLE_NONE = 0,
  ROLE_ATTACK,
  ROLE_SPELL,
  ROLE_HYBRID,
  ROLE_DPS,
  ROLE_TANK,
  ROLE_HEAL,
  ROLE_MAX
};

enum save_e : unsigned
{
  // Specifies the type of profile data to be saved
  SAVE_GEAR    = 0x1,
  SAVE_TALENTS = 0x2,
  SAVE_ACTIONS = 0x4,
  SAVE_PLAYER  = 0x8,
  SAVE_ALL     = SAVE_GEAR | SAVE_TALENTS | SAVE_ACTIONS | SAVE_PLAYER,
};

enum power_e
{
  POWER_HEALTH         = -2,
  POWER_MANA           = 0,
  POWER_RAGE           = 1,
  POWER_FOCUS          = 2,
  POWER_ENERGY         = 3,
  POWER_COMBO_POINT    = 4,
  POWER_RUNE           = 5,
  POWER_RUNIC_POWER    = 6,
  POWER_SOUL_SHARDS    = 7,
  POWER_ASTRAL_POWER   = 8,
  POWER_HOLY_POWER     = 9,
  // Alternate         = 10,
  POWER_MAELSTROM      = 11,
  POWER_CHI            = 12,
  POWER_INSANITY       = 13,
  // Unused            = 14,
  // Unused            = 15,
  POWER_ARCANE_CHARGES = 16,
  POWER_FURY           = 17,
  POWER_PAIN           = 18,
  POWER_ESSENCE        = 19,
  // Helpers
  POWER_MAX,
  POWER_NONE          = 0xFFFFFFFF  // None.
};

// New stuff
enum snapshot_state_e
{
  STATE_HASTE          = 0x00000001,
  STATE_CRIT           = 0x00000002,
  STATE_AP             = 0x00000004,
  STATE_SP             = 0x00000008,

  STATE_MUL_SPELL_DA   = 0x00000010,  // Add Percent Modifier (108): Spell Direct Amount (0) list-based multiplier
  STATE_MUL_SPELL_TA   = 0x00000020,  // Add Percent Modifier (108): Spell Periodic Amount (22) list-based multiplier
  STATE_VERSATILITY    = 0x00000040,
  STATE_MUL_PERSISTENT = 0x00000080,  // Persistent modifier for the few abilities that snapshot

  STATE_TGT_CRIT       = 0x00000100,
  STATE_TGT_MUL_DA     = 0x00000200,
  STATE_TGT_MUL_TA     = 0x00000400,

  STATE_MUL_PLAYER_DAM = 0x00000800,  // Modify Damage Done% (79) school-based player-wide multiplier

  // User-defined state flags
  STATE_USER_1         = 0x00001000,
  STATE_USER_2         = 0x00002000,
  STATE_USER_3         = 0x00004000,
  STATE_USER_4         = 0x00008000,

  STATE_TGT_MITG_DA    = 0x00010000,
  STATE_TGT_MITG_TA    = 0x00020000,
  STATE_TGT_ARMOR      = 0x00040000,

  /// Multiplier from the owner to pet damage
  STATE_MUL_PET        = 0x00100000,
  STATE_TGT_MUL_PET    = 0x00200000,

  STATE_ROLLING_TA     = 0x00400000,
  STATE_MUL_VERSUS     = 0x00800000,  // Modify Damage Done% vs Race (168) and Modify Damage Done Against Target With Aura (303)

  // User-defined target-specific state flags
  STATE_TGT_USER_1     = 0x10000000,
  STATE_TGT_USER_2     = 0x20000000,
  STATE_TGT_USER_3     = 0x40000000,
  STATE_TGT_USER_4     = 0x80000000,

  /**
   * No multiplier helper, use in action_t::init() (after parent init) by issuing snapshot_flags &= STATE_NO_MULTIPLIER
   * (and/or update_flags &= STATE_NO_MULTIPLIER if a dot). This disables all multipliers, including versatility, and
   * any/all persistent multipliers the action would use. */
  STATE_NO_MULTIPLIER  = ~( STATE_MUL_SPELL_DA | STATE_MUL_SPELL_TA | STATE_MUL_PLAYER_DAM | STATE_VERSATILITY |
                            STATE_MUL_PERSISTENT | STATE_TGT_MUL_DA | STATE_TGT_MUL_TA | STATE_TGT_ARMOR |
                            STATE_MUL_PET | STATE_TGT_MUL_PET | STATE_MUL_VERSUS ),

  /// Target-specific state variables, excluding the pet damage multiplier
  STATE_TARGET_NO_PET  = ( STATE_TGT_CRIT | STATE_TGT_MUL_DA | STATE_TGT_MUL_TA | STATE_TGT_ARMOR | STATE_TGT_MITG_DA |
                           STATE_TGT_MITG_TA | STATE_TGT_USER_1 | STATE_TGT_USER_2 | STATE_TGT_USER_3 | STATE_TGT_USER_4 |
                           STATE_MUL_VERSUS ),

  /// Target-specific state variables
  STATE_TARGET         = STATE_TARGET_NO_PET | STATE_TGT_MUL_PET
};

enum ready_e
{
  READY_POLL    = 0,
  READY_TRIGGER = 1
};

// proc rng type
enum rng_type_e
{
  RNG_NONE = 0,
  RNG_SIMPLE,
  RNG_RPPM,
  RNG_SHUFFLE,
  RNG_ACCUMULATE,
  RNG_THRESHOLD,
  RNG_CUSTOM
};

/// Real PPM scale stats
enum rppm_scale_e : uint8_t
{
  RPPM_NONE              = 0x00,
  RPPM_HASTE             = 0x01,
  RPPM_CRIT              = 0x02,
  RPPM_AUTO_ATTACK_SPEED = 0x04,
  RPPM_DISABLE           = UINT8_MAX
};

enum class action_energize
{
  NONE = 0,
  ON_CAST,
  ON_HIT,
  PER_HIT,
  PER_TICK
};

// Global cooldown speed-up type
enum class gcd_haste_type
{
  NONE,
  // any (all) haste types
  HASTE,
  SPELL_HASTE,
  ATTACK_HASTE,       // TODO: This should probably be Range/Melee
  SPELL_CAST_SPEED,   // Includes spell haste as well as cast speed effects
  AUTO_ATTACK_SPEED,  // Includes attack haste as well as auto attack speed effects
};

enum fight_style_e
{
  FIGHT_STYLE_NONE = 0,
  FIGHT_STYLE_PATCHWERK,
  FIGHT_STYLE_CASTING_PATCHWERK,
  FIGHT_STYLE_HECTIC_ADD_CLEAVE,
  FIGHT_STYLE_DUNGEON_SLICE,
  FIGHT_STYLE_DUNGEON_ROUTE,
  // Maybe deprecated?
  FIGHT_STYLE_CLEAVE_ADD,
  FIGHT_STYLE_LIGHT_MOVEMENT,
  FIGHT_STYLE_HEAVY_MOVEMENT,
  // Deprecated
  FIGHT_STYLE_BEASTLORD,
  FIGHT_STYLE_HELTER_SKELTER,
  FIGHT_STYLE_ULTRAXION,
  FIGHT_STYLE_MAX
};

// Dragonflight player talent tree indices
enum class talent_tree : unsigned
{
  INVALID = 0,
  CLASS,
  SPECIALIZATION,
  HERO,
  SELECTION,
  MAX,  // Everything below are not player traits
  EXPANSION  // expansion/patch specific miscellaneous traits
};

enum trait_definition_op : int
{
  TRAIT_OP_NONE = -1,
  TRAIT_OP_SET,
  TRAIT_OP_MUL
};

enum trait_node_type_e
{
  NODE_NORMAL = 0,
  NODE_TIERED = 1,
  NODE_CHOICE = 2,
  NODE_SELECTION = 3
};

// sim_t::error() severity level
enum error_level_e : unsigned short
{
  SEVERE,
  MODERATE,
  TRIVIAL,
  UNIMPLEMENTED,
  UNVERIFIED_IMPLEMENTATION,
  UNVERIFIED_VALUE,
  IMPLEMENTATION_NOTES,
};

enum proc_trigger_type_e : unsigned short
{
  TRIGGER_ACTION,
  TRIGGER_ACTION_PROC,
  TRIGGER_ACTION_TAKEN,
  TRIGGER_ACTION_PROC_TAKEN,
  TRIGGER_AURA_APPLIED,
  TRIGGER_HEARTBEAT,
};

enum init_actor_e
{
  INIT_ACTOR_INIT             = 100,
  INIT_ACTOR_PROPERTIES       = 200,
  INIT_ACTOR_TALENTS          = 300,
  INIT_ACTOR_ITEMS            = 400,
  INIT_ACTOR_SPELLS           = 500,
  INIT_ACTOR_CREATE_EFFECTS   = 600,
  INIT_ACTOR_BASE_STATS       = 700,
  INIT_ACTOR_CREATE_BUFFS     = 800,
  INIT_ACTOR_CREATE_ACTIONS   = 900,
  INIT_ACTOR_PETS             = 1000,
  INIT_ACTOR_INIT_EFFECTS     = 1100,
  INIT_ACTOR_INIT_ACTIONS     = 1200,
  INIT_ACTOR_INITIAL_STATS    = 1300,
  INIT_ACTOR_MISC             = 1400,
  INIT_ACTOR_ASSESSORS        = 1600,
};
