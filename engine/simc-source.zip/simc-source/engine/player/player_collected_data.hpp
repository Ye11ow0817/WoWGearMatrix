// ==========================================================================
// Dedmonwakeen's Raid DPS/TPS Simulator.
// Send questions to natehieter@gmail.com
// ==========================================================================

#pragma once

#include "config.hpp"

#include "sc_enums.hpp"
#include "util/concurrency.hpp"
#include "util/sample_data.hpp"
#include "util/timeline.hpp"

#include <array>

struct action_t;
struct buff_t;
struct cooldown_t;
struct player_t;

/* Contains any data collected during / at the end of combat
 * Mostly statistical data collection, represented as sample data containers
 */
struct player_collected_data_t
{
  extended_sample_data_t fight_length;
  extended_sample_data_t waiting_time, pooling_time, executed_foreground_actions;

  // DMG
  extended_sample_data_t dmg;
  extended_sample_data_t compound_dmg;
  extended_sample_data_t prioritydps;
  extended_sample_data_t dps;
  extended_sample_data_t dpse;
  extended_sample_data_t dtps;
  extended_sample_data_t dmg_taken;
  sc_timeline_t timeline_dmg;
  sc_timeline_t timeline_dmg_taken;
  // Heal
  extended_sample_data_t heal;
  extended_sample_data_t compound_heal;
  extended_sample_data_t hps;
  extended_sample_data_t hpse;
  extended_sample_data_t htps;
  extended_sample_data_t heal_taken;
  sc_timeline_t timeline_healing_taken;
  // Absorb
  extended_sample_data_t absorb;
  extended_sample_data_t compound_absorb;
  extended_sample_data_t aps;
  extended_sample_data_t atps;
  extended_sample_data_t absorb_taken;
  // Tank
  extended_sample_data_t deaths;

  // Metric used to end simulations early
  extended_sample_data_t target_metric;
  mutex_t target_metric_mutex;

  std::vector<simple_sample_data_t> resource_lost, resource_gained, resource_overflowed;
  struct resource_timeline_t
  {
    resource_e type;
    sc_timeline_t timeline;

    resource_timeline_t( resource_e t = RESOURCE_NONE ) : type( t ) {}
  };
  // Druid requires 4 resource timelines health/mana/energy/rage
  std::vector<resource_timeline_t> resource_timelines;
  // For some actors (typically enemies), health and health percentage timelines might not match. Track health
  // percentage separately.
  sc_timeline_t health_pct;

  std::vector<simple_sample_data_t> combat_start_resource;
  std::vector<simple_sample_data_with_min_max_t> combat_end_resource;

  struct stat_timeline_t
  {
    stat_e type;
    sc_timeline_t timeline;

    stat_timeline_t( stat_e t = STAT_NONE ) : type( t ) {}
  };

  std::vector<stat_timeline_t> stat_timelines;

  // hooked up in resource timeline collection event
  struct health_changes_timeline_t
  {
    double previous_loss_level, previous_gain_level;
    sc_timeline_t timeline;             // keeps only data per iteration
    sc_timeline_t timeline_normalized;  // same as above, but normalized to current player health
    sc_timeline_t merged_timeline;
    bool collect;  // whether we collect all this or not.

    health_changes_timeline_t() : previous_loss_level( 0.0 ), previous_gain_level( 0.0 ), collect( false ) {}

    void set_bin_size( double bin );
    double get_bin_size() const;
  };

  health_changes_timeline_t health_changes;      // records all health changes

  // Total number of iterations for the actor. Needed for single_actor_batch if target_error is used.
  int total_iterations;

  struct action_sequence_data_t : noncopyable
  {
    template <typename T>
    struct record_t
    {
      T* object;
      int value;
      timespan_t time_value;

      record_t( T* o, int v, timespan_t tv ) : object( o ), value( v ), time_value( tv ) {}
    };

    const action_t* action;
    const player_t* target;
    std::string action_reporting;  // reporting override
    std::string target_reporting;  // reporting override
    const timespan_t time;
    timespan_t wait_time;
    bool queue_failed;
    std::vector<record_t<buff_t>> buff_list;
    std::vector<record_t<cooldown_t>> cooldown_list;
    std::vector<std::pair<player_t*, std::vector<record_t<buff_t>>>> target_list;
    std::array<double, RESOURCE_MAX> resource_snapshot;
    std::array<double, RESOURCE_MAX> resource_max_snapshot;

    action_sequence_data_t( const action_t* a, const player_t* t, timespan_t ts, timespan_t wait, const player_t* p );

    action_sequence_data_t( timespan_t ts, timespan_t wait, const player_t* p )
      : action_sequence_data_t( nullptr, nullptr, ts, wait, p )
    {}

    action_sequence_data_t( const action_t* a, const player_t* t, timespan_t ts, const player_t* p )
      : action_sequence_data_t( a, t, ts, 0_ms, p )
    {}
  };

  std::vector<action_sequence_data_t> action_sequence;
  std::vector<action_sequence_data_t> action_sequence_precombat;

  // Buffed snapshot_stats (for reporting)
  struct buffed_stats_t
  {
    std::array<double, ATTRIBUTE_MAX> attribute;
    std::array<double, RESOURCE_MAX> resource;

    double spell_power, spell_hit, spell_crit_chance, manareg_per_second;
    double attack_power, attack_hit, mh_attack_expertise, oh_attack_expertise, attack_crit_chance;
    double armor, miss, crit, dodge, parry, block, bonus_armor;
    double spell_haste, spell_cast_speed, attack_haste, auto_attack_speed;
    double mastery_value;
    double damage_versatility, heal_versatility, mitigation_versatility;
    double leech, run_speed, avoidance;
    double spell_crit_rating, melee_crit_rating;
    double spell_haste_rating, melee_haste_rating;
    double mastery_rating;
    double versatility_rating;
    double avoidance_rating, leech_rating, speed_rating;
    double corruption, corruption_resistance;
  } buffed_stats_snapshot;

  player_collected_data_t( const player_t* player );

  void reserve_memory( const player_t& );
  void merge( const player_t& );
  void analyze( const player_t& );
  void collect_data( const player_t& );
  double calculate_max_spike_damage( const health_changes_timeline_t& tl, int window );

  static bool tank_container_type( const player_t* for_actor, int target_statistics_level );
  static bool generic_container_type( const player_t* for_actor, int target_statistics_level );
};
