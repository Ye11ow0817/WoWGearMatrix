// ==========================================================================
// Dedmonwakeen's DPS-DPM Simulator.
// Send questions to natehieter@gmail.com
// ==========================================================================

#include "config.hpp"

#include "action/parse_effects.hpp"
#include "class_modules/apl/apl_evoker.hpp"
#include "dbc/trait_data.hpp"
#include "player/pet_spawner.hpp"
#include "sim/option.hpp"

#include "simulationcraft.hpp"

namespace
{
// ==========================================================================
// Evoker
// ==========================================================================

// Static helper functions
template <typename V>
static const spell_data_t* resolve_spell_data( V data )
{
  if constexpr ( std::is_invocable_v<decltype( &spell_data_t::ok ), V> )
    return data;
  else if constexpr ( std::is_invocable_v<decltype( &buff_t::data ), V> )
    return &data->data();
  else if constexpr ( std::is_invocable_v<decltype( &action_t::data ), V> )
    return &data->data();
  else
    static_assert( static_false<V>, "Could not resolve find_effect argument to spell data." );
}

// finds a spell effect
// 1) first argument can be either player_talent_t, spell_data_t*, buff_t*, action_t*
// 2) if the second argument is player_talent_t, spell_data_t*, buff_t*, or action_t* then only effects that affect it
// are returned 3) if the third (or second if the above does not apply) argument is effect subtype, then the type is
// assumed to be E_APPLY_AURA further arguments can be given to filter for full type + subtype + property
template <typename T, typename U, typename... Ts>
static const spelleffect_data_t& find_effect( T val, U type, Ts&&... args )
{
  const spell_data_t* data = resolve_spell_data<T>( val );

  if constexpr ( std::is_same_v<U, effect_subtype_t> )
    return spell_data_t::find_spelleffect( *data, E_APPLY_AURA, type, std::forward<Ts>( args )... );
  else if constexpr ( std::is_same_v<U, effect_type_t> )
    return spell_data_t::find_spelleffect( *data, type, std::forward<Ts>( args )... );
  else
  {
    const spell_data_t* affected = resolve_spell_data<U>( type );

    if constexpr ( sizeof...( Ts ) == 0 )
      return spell_data_t::find_spelleffect( *data, *affected, E_APPLY_AURA );
    else if constexpr ( std::is_same_v<std::tuple_element_t<0, std::tuple<Ts...>>, effect_subtype_t> )
      return spell_data_t::find_spelleffect( *data, *affected, E_APPLY_AURA, std::forward<Ts>( args )... );
    else if constexpr ( std::is_same_v<std::tuple_element_t<0, std::tuple<Ts...>>, effect_type_t> )
      return spell_data_t::find_spelleffect( *data, *affected, std::forward<Ts>( args )... );
    else
      return spell_data_t::find_spelleffect( *data, *affected, E_APPLY_AURA );
  }
}

// Forward declarations
struct evoker_t;
struct simplified_player_t;

namespace pets
{
struct evoker_pet_t;
struct dracthyr_commando_t;
struct duplicate_t;
}  // namespace pets

enum empower_e
{
  EMPOWER_NONE = 0,
  EMPOWER_1    = 1,
  EMPOWER_2,
  EMPOWER_3,
  EMPOWER_4,
  EMPOWER_MAX
};

enum spell_color_e
{
  SPELL_COLOR_NONE = 0,
  SPELL_BLACK,
  SPELL_BLUE,
  SPELL_BRONZE,
  SPELL_GREEN,
  SPELL_RED
};

enum mote_buffs_e : unsigned
{
  INFERNOS_BLESSING = 0,
  SHIFTING_SANDS,
  SYMBIOTIC_BLOOM,
  PRESCIENCE,
  MAX
};

enum proc_spell_type_e : unsigned
{
  NONE          = 0x0,
  DRAGONRAGE    = 0x1,  // 3 pyre proc'd via dragonrage
  SCINTILLATION = 0x2,  // level 1 eternity surge proc'd from disintegrate tick via scintillation
  VOLATILITY    = 0x4   // chained pyre proc'd via volatility
};

struct evoker_td_t : public actor_target_data_t
{
  struct dots_t
  {
    dot_t* fire_breath;
    dot_t* disintegrate;
    dot_t* living_flame;
    dot_t* enkindle;
    dot_t* melt_armor;
  } dots;

  struct debuffs_t
  {
    buff_t* in_firestorm;
    buff_t* temporal_wound;
    buff_t* melt_armor;
    buff_t* bombardments;
  } debuffs;

  struct buffs_t
  {
    buff_t* blistering_scales;
    buff_t* prescience;
    buff_t* infernos_blessing;
    buff_t* ebon_might;
    buff_t* shifting_sands;
    buff_t* symbiotic_bloom;

    // Legendary
    buff_t* unbound_surge;
  } buffs;

  struct chrono_tracker_t
  {
    std::array<double, 5> damage_buckets = { 0, 0, 0, 0, 0 };
    time_t last_accessed_second          = 0;
  } chrono_tracker;

  evoker_td_t( player_t* target, evoker_t* source );
};

// utility to create target_effect_t compatible functions from evoker_td_t member references
template <typename T>
static std::function<int( actor_target_data_t* )> d_fn( T d, bool stack = true )
{
  if constexpr ( std::is_invocable_v<T, evoker_td_t::debuffs_t> )
  {
    if ( stack )
      return [ d ]( actor_target_data_t* t ) {
        return std::invoke( d, static_cast<evoker_td_t*>( t )->debuffs )->check();
      };
    else
      return [ d ]( actor_target_data_t* t ) {
        return std::invoke( d, static_cast<evoker_td_t*>( t )->debuffs )->check() > 0;
      };
  }
  else if constexpr ( std::is_invocable_v<T, evoker_td_t::dots_t> )
  {
    if ( stack )
      return [ d ]( actor_target_data_t* t ) {
        return std::invoke( d, static_cast<evoker_td_t*>( t )->dots )->current_stack();
      };
    else
      return [ d ]( actor_target_data_t* t ) {
        return std::invoke( d, static_cast<evoker_td_t*>( t )->dots )->is_ticking();
      };
  }
  else
  {
    static_assert( static_false<T>, "Not a valid member of evoker_td_t" );
    return nullptr;
  }
}

template <typename T>
static std::function<double( actor_target_data_t* )> d_value_fn( T d, [[maybe_unused]] bool stack = true )
{
  if constexpr ( std::is_invocable_v<T, evoker_td_t::debuffs_t> )
  {
    return [ d ]( actor_target_data_t* t ) {
      return std::invoke( d, static_cast<evoker_td_t*>( t )->debuffs )->check_stack_value();
    };
  }
  else
  {
    static_assert( static_false<T>, "Not a valid debuff member of evoker_td_t" );
    return nullptr;
  }
}

template <typename Data, typename Base = action_state_t>
struct evoker_action_state_t : public Base, public Data
{
  static_assert( std::is_base_of_v<action_state_t, Base> );
  static_assert( std::is_default_constructible_v<Data> );  // required for initialize
  static_assert( std::is_copy_assignable_v<Data> );        // required for copy_state

  using Base::Base;

  void initialize() override
  {
    Base::initialize();
    *static_cast<Data*>( this ) = Data{};
  }

  std::ostringstream& debug_str( std::ostringstream& s ) override
  {
    Base::debug_str( s );
    if constexpr ( fmt::is_formattable<Data>::value )
      fmt::print( s, " {}", *static_cast<const Data*>( this ) );
    return s;
  }

  void copy_state( const action_state_t* o ) override
  {
    Base::copy_state( o );
    *static_cast<Data*>( this ) = *static_cast<const Data*>( static_cast<const evoker_action_state_t*>( o ) );
  }
};

struct simple_timed_buff_t : public buff_t
{
  event_t* current_event;

  simple_timed_buff_t( player_t* p, std::string_view name ) : buff_t( p, name ), current_event( nullptr )
  {
  }

  void register_next_trigger( timespan_t time )
  {
    if ( current_event )
      return;

    current_event = make_event( sim, time, [ this ] {
      current_event = nullptr;
      trigger();
    } );
  }

  void reset() override
  {
    buff_t::reset();
    event_t::cancel( current_event );
  }

  bool trigger( int stacks = -1, double value = DEFAULT_VALUE(), double chance = -1.0,
                timespan_t duration = timespan_t::min() ) override
  {
    bool trigger_buff = false;

    for ( auto* p : sim->target_non_sleeping_list )
    {
      if ( !p->is_sleeping() && !( p->debuffs.invulnerable && p->debuffs.invulnerable->check() ) )
      {
        trigger_buff = true;
        break;
      }
    }

    if ( !trigger_buff )
    {
      timespan_t next = timespan_t::max();

      if ( sim->fight_style == FIGHT_STYLE_DUNGEON_ROUTE || sim->fight_style == FIGHT_STYLE_DUNGEON_SLICE )
      {
        for ( auto& event : sim->raid_events )
        {
          if ( event->type == "adds" || event->type == "pull" )
          {
            next = event->until_next() < next ? event->until_next() : next;
          }
        }
      }

      next = next < timespan_t::max() ? next : 1_s;
      next += rng().gauss<100, 25>();

      register_next_trigger( next );

      return false;
    }

    trigger_buff = buff_t::trigger( stacks, value, chance, duration );

    if ( trigger_buff )
    {
      if ( cooldown && cooldown->remains() > 0_s )
      {
        register_next_trigger( cooldown->remains() + rng().gauss<100, 25>() );
      }
    }

    return trigger_buff;
  }
};

enum class bob_buff_type_e
{
  BUFF_NONE           = -1,
  BUFF_PERCENT_DAMAGE = 0,
  BUFF_HASTE,
  BUFF_CRIT,
  BUFF_VERS,
  BUFF_MAST,
  BUFF_PCT_PRIMARY,
  BUFF_FLAT_PRIMARY,
  BUFF_MAX
};

struct simplified_player_t : public player_t
{
  action_t* ability;
  action_t* snapshot_stats;
  std::vector<buff_t*> damage_buffs;

  bool has_hasted_gcds;
  double haste_modifier;
  double execute_threshold;
  double execute_amount;

  struct bob_settings_t
  {
    struct bob_buff_t
    {
      std::string_view name;
      double value;
      timespan_t duration;
      timespan_t cooldown;
      timespan_t delay_from_start;
      bob_buff_type_e type;
    };

    role_e role;

    double sp_coeff;
    bool hasted_gcds;
    timespan_t gcd_time;

    double base_aoe_multiplier;
    int aoe;
    int reduced_aoe_targets;
    int full_amount_targets;

    double haste_modifier;

    double flat_damage_per_hit;

    double scaling_factor;

    double execute_mod;

    double execute_threshold;

    std::vector<bob_buff_t> buffs;
  };

  // Options
  struct options_t
  {
    int item_level      = 323;
    std::string variant = "default";
    double skill         = 1.0;
  } option;

  std::map<std::string, bob_settings_t> bob_settings = {
      { "default", 
        { ROLE_SPELL, 29.4, true, 1.5_s, 0.45, -1, 8, 1, 0.0, 20000.0, 0.0011, 0.1, 0.2,
          {
            { "dps_pot", 695.0, 30_s, 300_s, 3_s, bob_buff_type_e::BUFF_FLAT_PRIMARY }
          } 
        } 
      },
      { "tank", 
        { ROLE_TANK, 20.9, true, 1.5_s, 0.45, -1, 8, 1, 0.0, 20000.0, 0.0011, 0, 0,
          {
            { "dps_pot", 695.0, 30_s, 300_s, 3_s, bob_buff_type_e::BUFF_FLAT_PRIMARY }
          } 
        } 
      },
      { "healer", 
        { ROLE_HEAL, 5.4, true, 1.5_s, 0.25, -1, 5, 1, 0.0, 20000.0, 0.0011, 0, 0,
          {
            { "dps_pot", 695.0, 30_s, 300_s, 3_s, bob_buff_type_e::BUFF_FLAT_PRIMARY }
          } 
        } 
      },
      { "shadow_archon", 
        { ROLE_SPELL, 19.1, true, 1.5_s, 0.6, -1, 12, 1, -0.1, 20000.0, 0.0011, 0.1, 0.35,
          { 
            { "trinket", 0.2, 15_s, 120_s, 0_s, bob_buff_type_e::BUFF_MAST },
            { "pi", 0.2, 15_s, 120_s, 3_s, bob_buff_type_e::BUFF_HASTE },
            { "vf", 0.3, 26_s, 120_s, 3_s, bob_buff_type_e::BUFF_PERCENT_DAMAGE },
            { "one_mins_cds", 0.3, 25_s, 60_s, 3_s, bob_buff_type_e::BUFF_PERCENT_DAMAGE },
            { "one_mins_cds_part2", 0.1, 25_s, 60_s, 8_s, bob_buff_type_e::BUFF_PERCENT_DAMAGE },
            { "one_mins_cds_lingering", 0.1, 35_s, 60_s, 3_s, bob_buff_type_e::BUFF_PERCENT_DAMAGE },
            { "dps_pot", 695.0, 30_s, 300_s, 3_s, bob_buff_type_e::BUFF_FLAT_PRIMARY }
          } 
        }
      },
      { "shadow",
        { ROLE_SPELL, 21.0, true, 1.5_s, 0.6, -1, 12, 1, -0.1,  20000.0, 0.0011, 0.1, 0.35,
          { 
            { "trinket", 0.2, 15_s, 120_s, 0_s, bob_buff_type_e::BUFF_MAST },
            { "pi", 0.2, 15_s, 120_s, 3_s, bob_buff_type_e::BUFF_HASTE },
            { "vf", 0.3, 20_s, 120_s, 3_s, bob_buff_type_e::BUFF_PERCENT_DAMAGE },
            { "30s_cds", 0.4, 12_s, 30.75_s, 2_s, bob_buff_type_e::BUFF_PERCENT_DAMAGE },
            { "dps_pot", 695.0, 30_s, 300_s, 2_s, bob_buff_type_e::BUFF_FLAT_PRIMARY }
          } 
        }
      },
      { "bm",
        { ROLE_SPELL, 16.4, true, 1.5_s, 0.45, -1, 8, 1, -0.1, 14000.0, 0.0011, 0, 0,
          { 
            { "trinket",            0.2, 15_s, 120_s, 0_s, bob_buff_type_e::BUFF_MAST },
            { "beastial_wrath",     0.8, 16_s,  30_s, 1_s, bob_buff_type_e::BUFF_PERCENT_DAMAGE },
            { "beastial_wrath2",    0.8,  8_s,  30_s, 1_s, bob_buff_type_e::BUFF_PERCENT_DAMAGE },
            { "dps_pot",          695.0, 30_s, 300_s, 1_s, bob_buff_type_e::BUFF_FLAT_PRIMARY } ,
            { "racial",           168.7, 15_s, 120_s, 1_s, bob_buff_type_e::BUFF_FLAT_PRIMARY } 
          } 
        }
      },
      { "assa",
        { ROLE_SPELL, 13.5, false, 1_s, 0.5, -1, 8, 1, 0.8, 11100.0, 0.0011, 0.25, 0.35,
          { 
            { "two_mins_cds", 0.9, 20_s, 120_s, 3_s, bob_buff_type_e::BUFF_PERCENT_DAMAGE },
            { "one_mins_cds", 0.65, 14_s, 60_s, 4_s, bob_buff_type_e::BUFF_PERCENT_DAMAGE },
            { "dps_pot", 695.0, 30_s, 360_s, 4_s, bob_buff_type_e::BUFF_FLAT_PRIMARY } 
          } 
        }
      },
      { "unh",
        { ROLE_SPELL, 19.6, true, 1.5_s, 0.5, -1, 8, 1, 0, 18000.0, 0.0011, 0.1, 0.35,
          { 
            { "90s_cds", 0.8, 20_s, 90_s, 6_s, bob_buff_type_e::BUFF_PERCENT_DAMAGE },
            { "45s_cds", 0.55, 20_s, 45_s, 7_s, bob_buff_type_e::BUFF_PERCENT_DAMAGE },
            { "45s_cds_2", 0.2, 30_s, 45_s, 7_s, bob_buff_type_e::BUFF_PERCENT_DAMAGE },
            { "dps_pot", 695.0, 30_s, 360_s, 7_s, bob_buff_type_e::BUFF_FLAT_PRIMARY } 
          }
        } 
      },
      { "demo",
        { ROLE_SPELL, 19.0, true, 1.5_s, 0.5, -1, 8, 1, -0.2, 9000.0, 0.0011, 0.1, 0.35,
          { 
            { "60s_cds_p1", 0.2,  30_s,  60_s,  3_s, bob_buff_type_e::BUFF_PERCENT_DAMAGE },
            { "60s_cds_p2", 0.2,  30_s,  60_s,  7_s, bob_buff_type_e::BUFF_PERCENT_DAMAGE },
            { "60s_cds_p3", 0.1,  30_s,  60_s, 11_s, bob_buff_type_e::BUFF_PERCENT_DAMAGE },
            { "60s_cds_p4", 0.1,  20_s,  60_s,  3_s, bob_buff_type_e::BUFF_PERCENT_DAMAGE },
            { "60s_cds_p5", 0.3,  15_s,  60_s,  3_s, bob_buff_type_e::BUFF_PERCENT_DAMAGE },
            { "20s_cds",    0.2,  12_s,  20_s,  2_s, bob_buff_type_e::BUFF_PERCENT_DAMAGE },
            { "120s_cds",   0.2,  15_s, 120_s,  2_s, bob_buff_type_e::BUFF_PERCENT_DAMAGE },
            { "120s_cds_2", 0.2,  15_s, 120_s,  2_s, bob_buff_type_e::BUFF_HASTE },
            { "dps_pot",  695.0,  30_s, 300_s,  7_s, bob_buff_type_e::BUFF_FLAT_PRIMARY } 
          }
        } 
      },
      { "arcane",
        { ROLE_SPELL, 16.4, true, 1.5_s, 0.45, -1,  8, 1, 0.0, 20000.0, 0.0011, 0.15, 0.35,
          { 
            { "90s_cds", 1.2, 15_s, 90_s, 3_s, bob_buff_type_e::BUFF_PERCENT_DAMAGE },
            { "45s_cds", 0.8, 12_s, 45_s, 3_s, bob_buff_type_e::BUFF_PERCENT_DAMAGE },
            { "dps_pot", 695.0, 30_s, 320_s, 2_s, bob_buff_type_e::BUFF_FLAT_PRIMARY } 
          }
        }
      },
      { "dk_frost",
        { ROLE_SPELL, 16.2, true, 1.5_s, 0.45, -1, 8, 1, 0, 6900.0, 0.0011, 0.05, 0.35,
          { { "nerf_lust",                 -0.2,     8_s,  600_s,  0_s, bob_buff_type_e::BUFF_HASTE },
            { "90s_trinket",                0.15,   20_s,   90_s,  1_s, bob_buff_type_e::BUFF_HASTE },
            { "funny_dragon",               0.10,    3_s,   90_s,  1_s, bob_buff_type_e::BUFF_PERCENT_DAMAGE },
            { "funny_dragon_haste",         0.12,   12_s,   90_s,  1_s, bob_buff_type_e::BUFF_HASTE },
            { "breath_of_sindragosa",       0.2,    30_s,   90_s,  1_s, bob_buff_type_e::BUFF_PERCENT_DAMAGE },
            { "pillar_cd_dump",             0.3,    20_s,   45_s,  1_s, bob_buff_type_e::BUFF_PERCENT_DAMAGE },
            { "pillar_of_frost",            0.3,    18_s,   45_s,  1_s, bob_buff_type_e::BUFF_PERCENT_DAMAGE },
            { "pillar_of_frost_lingering",  0.1,    20_s,   45_s, 19_s, bob_buff_type_e::BUFF_PERCENT_DAMAGE },
            { "reapers_mark_1",             0.2,    16_s,   45_s,  0_s, bob_buff_type_e::BUFF_PERCENT_DAMAGE },
            { "reapers_mark_2",             0.1,    12_s,   45_s,  0_s, bob_buff_type_e::BUFF_PERCENT_DAMAGE },
            { "reapers_mark_3",             0.2,     8_s,   45_s,  0_s, bob_buff_type_e::BUFF_PERCENT_DAMAGE },
            { "reapers_mark_4",             0.5,     4_s,   45_s,  0_s, bob_buff_type_e::BUFF_PERCENT_DAMAGE },
            { "dps_pot",                  695.0,    30_s,  300_s,  3_s, bob_buff_type_e::BUFF_FLAT_PRIMARY }
          }
        }
      }
  };

  std::map<std::string, bob_settings_t> bob_settings_121 = {
      { "default", 
        { ROLE_SPELL, 29.4 * 1.21, true, 1.5_s, 0.45, -1, 8, 1, 0.0, 20000.0, 0.0011, 0.1, 0.2,
          {
            { "dps_pot", 695.0, 30_s, 300_s, 3_s, bob_buff_type_e::BUFF_FLAT_PRIMARY }
          } 
        } 
      },
      { "tank", 
        { ROLE_TANK, 20.9 * 0.9, true, 1.5_s, 0.45, -1, 8, 1, 0.0, 20000.0, 0.0011, 0, 0,
          {
            { "dps_pot", 695.0, 30_s, 300_s, 3_s, bob_buff_type_e::BUFF_FLAT_PRIMARY }
          } 
        } 
      },
      { "bdk", 
        { ROLE_TANK, 10.1 * 1.1, true, 1.5_s, 0.45, -1, 8, 1, 0.0, 20000.0, 0.0011, 0, 0,
          {
            { "dps_pot",                  695.0, 30_s, 300_s, 3_s, bob_buff_type_e::BUFF_FLAT_PRIMARY },
            { "90s_trinket",              480.0,    20_s,   90_s,  0_s, bob_buff_type_e::BUFF_FLAT_PRIMARY },
            { "berserking",                 0.1,    12_s,  180_s,  0_s, bob_buff_type_e::BUFF_HASTE },
            { "raise_dead",                 0.2,    15_s,   90_s,  0_s, bob_buff_type_e::BUFF_PERCENT_DAMAGE },
            { "90s_something",              0.15,   10_s,   90_s,  0_s, bob_buff_type_e::BUFF_PERCENT_DAMAGE },
            { "reapers_mark_1",             0.4,    16_s,   45_s,  0_s, bob_buff_type_e::BUFF_PERCENT_DAMAGE },
            { "reapers_mark_2",             0.3,    12_s,   45_s,  0_s, bob_buff_type_e::BUFF_PERCENT_DAMAGE },
            { "reapers_mark_3",             0.2,     8_s,   45_s,  0_s, bob_buff_type_e::BUFF_PERCENT_DAMAGE },
            { "reapers_mark_4",             0.5,     4_s,   45_s,  0_s, bob_buff_type_e::BUFF_PERCENT_DAMAGE },
          } 
        } 
      },
      { "healer", 
        { ROLE_HEAL, 5.4 * 1.21, true, 1.5_s, 0.25, -1, 5, 1, 0.0, 20000.0, 0.0011, 0, 0,
          {
            { "dps_pot", 695.0, 30_s, 300_s, 3_s, bob_buff_type_e::BUFF_FLAT_PRIMARY }
          } 
        } 
      },
      { "shadow_archon", 
        { ROLE_SPELL, 19.1 * 1.32, true, 1.5_s, 0.45, -1, 12, 1, -0.1, 20000.0, 0.0011, 0.1, 0.35,
          { 
            { "trinket",                0.2, 15_s, 120_s, 0_s, bob_buff_type_e::BUFF_MAST },
            { "pi",                     0.2, 15_s, 120_s, 3_s, bob_buff_type_e::BUFF_HASTE },
            { "vf",                     0.3, 26_s, 120_s, 3_s, bob_buff_type_e::BUFF_PERCENT_DAMAGE },
            { "one_mins_cds",           0.3, 25_s, 60_s, 3_s, bob_buff_type_e::BUFF_PERCENT_DAMAGE },
            { "one_mins_cds_part2",     0.1, 25_s, 60_s, 8_s, bob_buff_type_e::BUFF_PERCENT_DAMAGE },
            { "one_mins_cds_lingering", 0.1, 35_s, 60_s, 3_s, bob_buff_type_e::BUFF_PERCENT_DAMAGE },
            { "dps_pot",              695.0, 30_s, 300_s, 3_s, bob_buff_type_e::BUFF_FLAT_PRIMARY }
          } 
        }
      },
      { "shadow",
        { ROLE_SPELL, 21.0 * 1.32, true, 1.5_s, 0.45, -1, 12, 1, -0.1,  20000.0, 0.0011, 0.1, 0.35,
          { 
            { "trinket",   0.2, 15_s, 120_s, 0_s, bob_buff_type_e::BUFF_MAST },
            { "pi",        0.2, 15_s, 120_s, 3_s, bob_buff_type_e::BUFF_HASTE },
            { "vf",        0.3, 20_s, 120_s, 3_s, bob_buff_type_e::BUFF_PERCENT_DAMAGE },
            { "30s_cds",   0.4, 12_s,  30_s, 2_s, bob_buff_type_e::BUFF_PERCENT_DAMAGE },
            { "dps_pot", 695.0, 30_s, 300_s, 2_s, bob_buff_type_e::BUFF_FLAT_PRIMARY }
          } 
        }
      },
      { "bm",
        { ROLE_SPELL, 16.4 * 1.245 * 0.96, true, 1.5_s, 0.45, -1, 8, 1, -0.1, 14000.0, 0.0011, 0, 0,
          { 
            { "trinket",            0.2, 15_s, 120_s, 0_s, bob_buff_type_e::BUFF_MAST },
            { "beastial_wrath",     0.8, 16_s,  30_s, 1_s, bob_buff_type_e::BUFF_PERCENT_DAMAGE },
            { "beastial_wrath2",    0.8,  8_s,  30_s, 1_s, bob_buff_type_e::BUFF_PERCENT_DAMAGE },
            { "dps_pot",          695.0, 30_s, 300_s, 1_s, bob_buff_type_e::BUFF_FLAT_PRIMARY } ,
            { "racial",           168.7, 15_s, 120_s, 1_s, bob_buff_type_e::BUFF_FLAT_PRIMARY } 
          } 
        }
      },
      { "assa",
        { ROLE_SPELL, 13.5 * 1.21, false, 1_s, 0.5, -1, 8, 1, 0.8, 11100.0, 0.0011, 0.25, 0.35,
          { 
            { "two_mins_cds", 0.9,  20_s, 120_s, 3_s, bob_buff_type_e::BUFF_PERCENT_DAMAGE },
            { "one_mins_cds", 0.65, 14_s,  60_s, 4_s, bob_buff_type_e::BUFF_PERCENT_DAMAGE },
            { "dps_pot",    695.0,  30_s, 360_s, 4_s, bob_buff_type_e::BUFF_FLAT_PRIMARY } 
          } 
        }
      },
      { "unh",
        { ROLE_SPELL, 19.6 * 0.945, true, 1.5_s, 0.5, -1, 8, 1, 0, 18000.0, 0.0011, 0.1, 0.35,
          { 
            { "90s_cds",  0.8,  20_s,  90_s, 6_s, bob_buff_type_e::BUFF_PERCENT_DAMAGE },
            { "45s_cds",  0.55, 20_s,  45_s, 7_s, bob_buff_type_e::BUFF_PERCENT_DAMAGE },
            { "45s_cds_2", 0.2, 30_s,  45_s, 7_s, bob_buff_type_e::BUFF_PERCENT_DAMAGE },
            { "dps_pot", 695.0, 30_s, 360_s, 7_s, bob_buff_type_e::BUFF_FLAT_PRIMARY } 
          }
        } 
      },
      { "demo",
        { ROLE_SPELL, 19.0, true, 1.5_s, 0.5, -1, 8, 1, -0.2, 9000.0, 0.0011, 0.1, 0.35,
          { 
            { "60s_cds_p1", 0.2,  30_s,  60_s,  3_s, bob_buff_type_e::BUFF_PERCENT_DAMAGE },
            { "60s_cds_p2", 0.2,  30_s,  60_s,  7_s, bob_buff_type_e::BUFF_PERCENT_DAMAGE },
            { "60s_cds_p3", 0.1,  30_s,  60_s, 11_s, bob_buff_type_e::BUFF_PERCENT_DAMAGE },
            { "60s_cds_p4", 0.1,  20_s,  60_s,  3_s, bob_buff_type_e::BUFF_PERCENT_DAMAGE },
            { "60s_cds_p5", 0.3,  15_s,  60_s,  3_s, bob_buff_type_e::BUFF_PERCENT_DAMAGE },
            { "20s_cds",    0.2,  12_s,  20_s,  2_s, bob_buff_type_e::BUFF_PERCENT_DAMAGE },
            { "120s_cds",   0.2,  15_s, 120_s,  2_s, bob_buff_type_e::BUFF_PERCENT_DAMAGE },
            { "120s_cds_2", 0.2,  15_s, 120_s,  2_s, bob_buff_type_e::BUFF_HASTE },
            { "dps_pot",  695.0,  30_s, 300_s,  7_s, bob_buff_type_e::BUFF_FLAT_PRIMARY } 
          }
        } 
      },
      { "arcane",
        { ROLE_SPELL, 16.4 * 1.21, true, 1.5_s, 0.45, -1,  8, 1, 0.0, 20000.0, 0.0011, 0.15, 0.35,
          { 
            { "90s_cds",   1.2, 15_s, 90_s, 3_s, bob_buff_type_e::BUFF_PERCENT_DAMAGE },
            { "45s_cds",   0.8, 12_s, 45_s, 3_s, bob_buff_type_e::BUFF_PERCENT_DAMAGE },
            { "dps_pot", 695.0, 30_s, 320_s, 2_s, bob_buff_type_e::BUFF_FLAT_PRIMARY } 
          }
        }
      },
      { "dk_frost",
        { ROLE_SPELL, 16.2 * 1.4 * 1.022, true, 1.5_s, 0.55, -1, 8, 1, 0, 6900.0, 0.0011, 0.05, 0.35,
          { { "nerf_lust",                 -0.2,     8_s,  600_s,  0_s, bob_buff_type_e::BUFF_HASTE },
            { "90s_trinket",              480.0,    20_s,   90_s,  1_s, bob_buff_type_e::BUFF_FLAT_PRIMARY },
            { "funny_dragon",               0.10,    3_s,   90_s,  1_s, bob_buff_type_e::BUFF_PERCENT_DAMAGE },
            { "funny_dragon_haste",         0.12,   12_s,   90_s,  1_s, bob_buff_type_e::BUFF_HASTE },
            { "breath_of_sindragosa",       0.1,    30_s,   90_s,  1_s, bob_buff_type_e::BUFF_PERCENT_DAMAGE },
            { "pillar_of_frost",            0.181,  18_s,   45_s,  1_s, bob_buff_type_e::BUFF_PERCENT_DAMAGE },
            { "pillar_of_frost_lingering",  0.1,    38_s,   45_s,  1_s, bob_buff_type_e::BUFF_PERCENT_DAMAGE },
            { "rider_cds_1",                0.1,    20_s,   90_s,  1_s, bob_buff_type_e::BUFF_PERCENT_DAMAGE },
            { "rider_cds_2",                0.15,   30_s,   90_s,  1_s, bob_buff_type_e::BUFF_PERCENT_DAMAGE },
            { "rider_cds_3",                0.2,    45_s,   90_s,  1_s, bob_buff_type_e::BUFF_PERCENT_DAMAGE },
            { "dps_pot",                  695.0,    30_s,  300_s,  3_s, bob_buff_type_e::BUFF_FLAT_PRIMARY }
          }
        }
      },
      { "dk_frost_db",
        { ROLE_SPELL, 16.2 * 1.076 * 1.025, true, 1.5_s, 0.55, -1, 8, 1, 0, 6900.0, 0.0011, 0.05, 0.35,
          { { "nerf_lust",                 -0.2,     8_s,  600_s,  0_s, bob_buff_type_e::BUFF_HASTE },
            { "90s_trinket",              480.0,   20_s,   90_s,  1_s, bob_buff_type_e::BUFF_FLAT_PRIMARY },
            { "funny_dragon",               0.10,    3_s,   90_s,  1_s, bob_buff_type_e::BUFF_PERCENT_DAMAGE },
            { "funny_dragon_haste",         0.12,   12_s,   90_s,  1_s, bob_buff_type_e::BUFF_HASTE },
            { "breath_of_sindragosa",       0.2,    30_s,   90_s,  1_s, bob_buff_type_e::BUFF_PERCENT_DAMAGE },
            { "pillar_cd_dump",             0.3,    20_s,   45_s,  1_s, bob_buff_type_e::BUFF_PERCENT_DAMAGE },
            { "pillar_of_frost",            0.181,  18_s,   45_s,  1_s, bob_buff_type_e::BUFF_PERCENT_DAMAGE },
            { "pillar_of_frost_lingering",  0.1,    38_s,   45_s,  1_s, bob_buff_type_e::BUFF_PERCENT_DAMAGE },
            { "reapers_mark_1",             0.2,    16_s,   45_s,  0_s, bob_buff_type_e::BUFF_PERCENT_DAMAGE },
            { "reapers_mark_2",             0.1,    12_s,   45_s,  0_s, bob_buff_type_e::BUFF_PERCENT_DAMAGE },
            { "reapers_mark_3",             0.2,     8_s,   45_s,  0_s, bob_buff_type_e::BUFF_PERCENT_DAMAGE },
            { "reapers_mark_4",             0.5,     4_s,   45_s,  0_s, bob_buff_type_e::BUFF_PERCENT_DAMAGE },
            { "dps_pot",                  695.0,    30_s,  300_s,  3_s, bob_buff_type_e::BUFF_FLAT_PRIMARY }
          }
        }
      }
  };

  simplified_player_t( sim_t* sim, std::string_view name, race_e r = RACE_HUMAN )
    : player_t( sim, PLAYER_SIMPLIFIED, name, r ),
      damage_buffs(),
      has_hasted_gcds( true ),
      haste_modifier( 0.0 ),
      execute_threshold( 0.0 ),
      execute_amount( 0.0 )
  {
    resource_regeneration = regen_type::DISABLED;

    // Using a background repeating action as a replacement for a foreground action. Change Ready Type to trigger so we
    // can wake up the pet when it needs to re-execute this action.
    ready_type = READY_TRIGGER;

    _spec = SPEC_PET;
  }

  buff_t* make_damage_buff( std::string_view name, double value, timespan_t duration, timespan_t cooldown,
                            timespan_t delay_from_start, bob_buff_type_e buff_type )
  {
    buff_t* b = make_buff<simple_timed_buff_t>( this, name );

    b->set_default_value( value )->set_cooldown( cooldown )->set_duration( duration );

    switch ( buff_type )
    {
      case bob_buff_type_e::BUFF_PERCENT_DAMAGE:
        b->add_invalidate( CACHE_PLAYER_DAMAGE_MULTIPLIER );
        damage_buffs.push_back( b );
        break;
      case bob_buff_type_e::BUFF_HASTE:
        b->set_pct_buff_type( STAT_PCT_BUFF_HASTE );
        break;
      case bob_buff_type_e::BUFF_CRIT:
        b->set_pct_buff_type( STAT_PCT_BUFF_CRIT );
        break;
      case bob_buff_type_e::BUFF_VERS:
        b->set_pct_buff_type( STAT_PCT_BUFF_VERSATILITY );
        break;
      case bob_buff_type_e::BUFF_MAST:
        b->default_value *= 100.0;
        b->set_pct_buff_type( STAT_PCT_BUFF_MASTERY );
        break;
      case bob_buff_type_e::BUFF_PCT_PRIMARY:
        b->add_stack_change_callback( [ this ]( buff_t* b, int, int _new ) {
          if ( _new )
          {
            stat_gain( STAT_INTELLECT, initial.stats.get_stat( STAT_INTELLECT ) * b->default_value );
          }
          else
          {
            stat_loss( STAT_INTELLECT, initial.stats.get_stat( STAT_INTELLECT ) * b->default_value );
          }
        } );
        break;
      case bob_buff_type_e::BUFF_FLAT_PRIMARY:
        b->add_stack_change_callback( [ this ]( buff_t* b, int, int _new ) {
          if ( _new )
          {
            stat_gain( STAT_INTELLECT, b->default_value );
          }
          else
          {
            stat_loss( STAT_INTELLECT, b->default_value );
          }
        } );
        break;
      default:
        break;
    }

    register_combat_begin( [ this, b, delay_from_start ]( player_t* ) {
      make_event( sim, delay_from_start, [ b ]() { b->trigger(); } );
    } );

    return b;
  }

  buff_t* make_damage_buff( bob_settings_t::bob_buff_t b )
  {
    return make_damage_buff( b.name, b.value, b.duration, b.cooldown, b.delay_from_start, b.type );
  }

  void make_damage_buffs( bob_settings_t s )
  {
    for ( auto& b : s.buffs )
    {
      make_damage_buff( b );
    }
  }

  bob_settings_t& get_variant_settings()
  {
    auto& settings = sim->dbc->wowv() >= wowv_t( 12, 1, 0 ) ? bob_settings_121 : bob_settings;

    auto it = settings.find( option.variant );
    if ( it != settings.end() )
    {
      return it->second;
    }

    return settings.at( "default" );
  }

  const bob_settings_t& get_variant_settings() const
  {
    auto& settings = sim->dbc->wowv() >= wowv_t( 12, 1, 0 ) ? bob_settings_121 : bob_settings;

    auto it = settings.find( option.variant );
    if ( it != settings.end() )
    {
      return it->second;
    }

    return settings.at( "default" );
  }

  void init() override
  {
    player_t::init();

    role              = get_variant_settings().role;
    has_hasted_gcds   = get_variant_settings().hasted_gcds;
    haste_modifier    = get_variant_settings().haste_modifier;
    execute_threshold = get_variant_settings().execute_threshold;
    execute_amount    = get_variant_settings().execute_mod;
  }

  role_e primary_role() const override
  {
    return get_variant_settings().role;
  }

  void init_defence()
  {
    player_t::init_defense();

    collected_data.health_changes.collect = false;
  }

  struct simple_ability_t : public spell_t
  {
    struct simple_proc_t : public spell_t
    {
      simple_proc_t( simplified_player_t* p, bob_settings_t settings ) : spell_t( "simple_proc", p )
      {
        background = true;

        allow_class_ability_procs = false;
        may_crit                  = true;

        set_action_stats( settings, p );
      }

      void init() override
      {
        spell_t::init();
        snapshot_flags &= ~STATE_MUL_PLAYER_DAM;
      }

      void set_action_stats( bob_settings_t settings, simplified_player_t* p )
      {
        school = SCHOOL_MAGIC;

        double scaling_factor = pow( 1.15, ( p->option.item_level - 489 ) / 15.0 );
        base_dd_min = base_dd_max = settings.flat_damage_per_hit * scaling_factor;
      }
    };

    simplified_player_t* p()
    {
      return debug_cast<simplified_player_t*>( player );
    }

    simplified_player_t* p() const
    {
      return debug_cast<simplified_player_t*>( player );
    }

    action_t* damage_proc;
    double haste_modifier;

    simple_ability_t( simplified_player_t* p, bob_settings_t settings )
      : spell_t( "simple_spell", p ), damage_proc( nullptr ), haste_modifier( 0.0 )
    {
      background = repeating = true;

      allow_class_ability_procs = not_a_proc = true;
      may_crit                               = true;

      set_action_stats( settings, p );
    }

    double composite_target_multiplier( player_t* t ) const override
    {
      double m = spell_t::composite_target_multiplier( t );

      if ( t->resources.pct( RESOURCE_HEALTH ) <= p()->execute_threshold )
        m *= 1.0 + p()->execute_amount;

      return m;
    }

    double composite_da_multiplier( const action_state_t* s ) const override
    {
      double m = spell_t::composite_da_multiplier( s );

      m *= 1.0 + p()->cache.mastery_value();

      m *= 1.0 - haste_modifier + haste_modifier / p()->cache.spell_cast_speed();

      return m;
    }

    void set_action_stats( bob_settings_t settings, simplified_player_t* p )
    {
      double scaling_factor = pow( 1.0 + settings.scaling_factor, ( p->option.item_level - 489 ) );

      spell_power_mod.direct = settings.sp_coeff * scaling_factor * p->option.skill;
      gcd_type               = settings.hasted_gcds ? gcd_haste_type::SPELL_HASTE : gcd_haste_type::NONE;
      base_execute_time      = settings.gcd_time;

      school = SCHOOL_MAGIC;

      aoe                 = settings.aoe;
      reduced_aoe_targets = settings.reduced_aoe_targets;
      full_amount_targets = settings.full_amount_targets;
      base_aoe_multiplier = settings.base_aoe_multiplier;

      if ( settings.flat_damage_per_hit > 0.0 )
      {
        damage_proc = new simple_proc_t( p, settings );
        add_child( damage_proc );
      }

      haste_modifier = settings.haste_modifier;
    }

    double execute_time_pct_multiplier() const override
    {
      if ( gcd_type == gcd_haste_type::SPELL_HASTE )
        return spell_t::execute_time_pct_multiplier();

      return 1.0;
    }

    timespan_t execute_time() const override
    {
      return std::max( min_gcd, spell_t::execute_time() );
    }

    bool usable_moving() const override
    {
      return true;
    }

    void schedule_execute( action_state_t* state ) override
    {
      spell_t::schedule_execute( state );
      // This uses a background repeating event with a ready type of READY_TRIGGER. Without constantly re-updating
      // the started waiting trigger_ready would never function.
      player->started_waiting = sim->current_time();
    }

    void execute() override
    {
      pre_execute_state = get_state( pre_execute_state );
      snapshot_state( pre_execute_state, amount_type( pre_execute_state ) );

      spell_t::execute();
    }

    void impact( action_state_t* s ) override
    {
      spell_t::impact( s );

      if ( s->chain_target == 0 && damage_proc )
      {
        damage_proc->execute_on_target( s->target );
      }
    }
  };

  void init_finished() override
  {
    player_t::init_finished();

    register_combat_begin( snapshot_stats );

    matching_gear = true;
  }

  void create_buffs() override
  {
    player_t::create_buffs();
    make_damage_buffs( get_variant_settings() );
  }

  double composite_player_multiplier( school_e school ) const override
  {
    double m = player_t::composite_player_multiplier( school );

    for ( auto* b : damage_buffs )
    {
      if ( b->check() )
      {
        m *= 1.0 + b->check_stack_value();
      }
    }

    return m;
  }

  double composite_mastery_value() const override
  {
    return cache.mastery() * 0.0125;
  }

  void init_base_stats() override
  {
    // Become a Priest temporarily to steal its base stat initialisation.
    type                           = PRIEST;
    base.spell_power_per_intellect = 1;
    player_t::init_base_stats();
    type = PLAYER_SIMPLIFIED;
  }

  void init_items() override
  {
    int item_level = option.item_level;

    std::map<slot_e, std::string> default_items;

    if ( sim->dbc->wowv() >= wowv_t( 12, 1, 0 ) )
    {
      const int crafted_item_ilvl = item_level - 3;
      const int elevated_item_ilvl = item_level == 334 ? 344 : item_level;
      default_items               = {
          { SLOT_HEAD, fmt::format( ",id=195476,gem_id=240983,ilevel={},enchant=175crit", elevated_item_ilvl ) },
          { SLOT_NECK, fmt::format( ",id=207163,gem_id=240900,ilevel={},enchant=103mastery", elevated_item_ilvl ) },
          { SLOT_SHOULDERS, fmt::format( ",id=193637,ilevel={},enchant=-56haste", item_level ) },
          { SLOT_BACK, fmt::format( ",id=195482,ilevel={},enchant=-56vers", elevated_item_ilvl ) },
          { SLOT_CHEST, fmt::format( ",id=193801,ilevel={},enchant_id=7987", elevated_item_ilvl ) },
          { SLOT_WRISTS, fmt::format( ",id=193812,gem_id=240900,ilevel={},enchant=35int", crafted_item_ilvl ) },
          { SLOT_HANDS, fmt::format( ",id=193818,ilevel={}", item_level ) },
          { SLOT_WAIST, fmt::format( ",id=207144,gem_id=240900,ilevel={},enchant=35int", crafted_item_ilvl ) },
          { SLOT_LEGS, fmt::format( ",id=193759,ilevel={},enchant_id=7935", item_level ) },
          { SLOT_FEET, fmt::format( ",id=207139,ilevel={}", elevated_item_ilvl ) },
          { SLOT_FINGER_1, fmt::format( ",id=207159,gem_id=240900,ilevel={},enchant_id=7997", item_level ) },
          { SLOT_FINGER_2, fmt::format( ",id=237570,gem_id=240900,ilevel={},enchant_id=7997", item_level ) },
          { SLOT_TRINKET_1, fmt::format( ",id=153816,ilevel={}", item_level ) },
          { SLOT_TRINKET_2, fmt::format( ",id=153819,ilevel={}", item_level ) },
          { SLOT_MAIN_HAND, fmt::format( ",id=202565,ilevel={},enchant=39int", elevated_item_ilvl ) },
      };
    }
    else
    {
      const int crafted_item_ilvl = item_level - 4;
      bool void_event             = ( sim->dbc->wowv() >= wowv_t( 12, 0, 5 ) && sim->dbc->wowv() < wowv_t( 12, 1, 0 ) );
      const int void_event_ilvl   = void_event ? item_level + 9 : item_level;
      default_items               = {
          { SLOT_HEAD, fmt::format( ",id=195476,gem_id=240983,ilevel={}", item_level ) },
          { SLOT_NECK, fmt::format( ",id=207163,gem_id=240900,ilevel={}", item_level ) },
          { SLOT_SHOULDERS, fmt::format( ",id=193637,ilevel={}", item_level ) },
          { SLOT_BACK, fmt::format( ",id=195482,ilevel={}", item_level ) },
          { SLOT_CHEST, fmt::format( ",id=193801,ilevel={},enchant_id=7987", item_level ) },
          { SLOT_WRISTS, fmt::format( ",id=193812,gem_id=240900,ilevel={},enchant=23int", crafted_item_ilvl ) },
          { SLOT_HANDS, fmt::format( ",id=193818,ilevel={}", item_level ) },
          { SLOT_WAIST, fmt::format( ",id=207144,gem_id=240900,ilevel={},enchant=23int", crafted_item_ilvl ) },
          { SLOT_LEGS, fmt::format( ",id=193759,ilevel={},enchant_id=7935", item_level ) },
          { SLOT_FEET, fmt::format( ",id=207139,ilevel={}", item_level ) },
          { SLOT_FINGER_1, fmt::format( ",id=207159,gem_id=240900,ilevel={},enchant_id=7997", item_level ) },
          { SLOT_FINGER_2, fmt::format( ",id=237570,gem_id=240900,ilevel={},enchant_id=7997", item_level ) },
          { SLOT_TRINKET_1, fmt::format( ",id=153816,ilevel={}", void_event_ilvl ) },
          { SLOT_TRINKET_2, fmt::format( ",id=153819,ilevel={}", void_event_ilvl ) },
          { SLOT_MAIN_HAND, fmt::format( ",id=202565,ilevel={},enchant=39int", void_event_ilvl ) },
      };
    }

    for ( const auto& [ slot, item_str ] : default_items )
    {
      if ( items[ slot ].options_str.empty() )
      {
        items[ slot ].options_str = item_str;
        sim->print_debug( "{} setting gearslot {} string to {}", *this, util::slot_type_string( slot ), item_str );
      }
      else
      {
        sim->print_debug( "{} already has gearslot {} string {}", *this, util::slot_type_string( slot ),
                          items[ slot ].options_str );
      }
    }

    player_t::init_items();

    matching_gear = true;
  }

  // Not actually used, emulated.
  std::string default_potion() const override
  {
    return "lights_potential_2";
  }

  std::string default_flask() const override
  {
    return "flask_of_the_blood_knights_2";
  }

  std::string default_food() const override
  {
    return "blooming_feast";
  }

  std::string default_rune() const override
  {
    return "void_touched";
  }

  std::string default_temporary_enchant() const override
  {
    return "main_hand:thalassian_phoenix_oil_2";
  }

  void create_actions() override
  {
    // player_t::create_actions();
    consumable::create_consumeable_actions( this );

    ability        = new simple_ability_t( this, get_variant_settings() );
    snapshot_stats = new snapshot_stats_t( this, "" );
  }

  void acquire_target( retarget_source event, player_t* context ) override
  {
    if ( ability->execute_event && ability->target->is_sleeping() )
    {
      event_t::cancel( ability->execute_event );
      started_waiting = sim->current_time();
    }

    // TODO: This skips certain very custom targets (such as Soul Effigy), is it a problem (since those
    // usually are handled in action target cache regeneration)?
    if ( sim->debug )
    {
      sim->out_debug.printf( "%s retargeting event=%s context=%s current_target=%s", name(),
                             util::retarget_event_string( event ), context ? context->name() : "NONE",
                             target ? target->name() : "NONE" );
    }

    player_t* candidate_target    = nullptr;
    player_t* first_invuln_target = nullptr;

    // TODO: Fancier system
    for ( auto enemy : sim->target_non_sleeping_list )
    {
      if ( enemy->debuffs.invulnerable != nullptr && enemy->debuffs.invulnerable->check() )
      {
        if ( first_invuln_target == nullptr )
        {
          first_invuln_target = enemy;
        }
        continue;
      }

      if ( !enemy->is_enemy() || enemy->is_sleeping() )
        continue;

      if ( !candidate_target || enemy->max_health() > candidate_target->max_health() )
        candidate_target = enemy;

      if ( sim->fixed_time )
        break;
    }

    // Invulnerable targets are currently not in the target_non_sleeping_list, so fall back to
    // checking if the first target has the invulnerability buff up, and use that as the fallback
    auto first_target = sim->target_list.data().front();
    if ( !first_invuln_target && first_target->debuffs.invulnerable->check() )
    {
      first_invuln_target = first_target;
    }

    // Only perform target acquisition if the actor's current target would change (to the candidate
    // target).
    if ( candidate_target )
    {
      if ( sim->debug )
      {
        sim->out_debug.printf( "%s acquiring (potentially new) target, current=%s candidate=%s", name(),
                               target ? target->name() : "NONE", candidate_target ? candidate_target->name() : "NONE" );
      }

      target = candidate_target;
      range::for_each( action_list, [ event, context, candidate_target ]( action_t* action ) {
        action->acquire_target( event, context, candidate_target );
      } );
    }
    // If we really cannot find any sensible target, fall back to the first invulnerable target
    else if ( !candidate_target && first_invuln_target )
    {
      if ( sim->debug )
      {
        sim->out_debug.printf( "%s acquiring (potentially new) target, current=%s candidate=%s [invulnerable fallback]",
                               name(), target ? target->name() : "NONE",
                               first_invuln_target ? first_invuln_target->name() : "NONE" );
      }

      target = first_invuln_target;
      range::for_each( action_list, [ event, context, first_invuln_target ]( action_t* action ) {
        action->acquire_target( event, context, first_invuln_target );
      } );
    }

    if ( candidate_target || first_invuln_target )
    {
      // Finally, re-acquire targeting for all dynamic targeting actions. This needs to be done
      // separately, as their targeting is not strictly bound to player_t::target (i.e., "the players
      // target")
      range::for_each(
          dynamic_target_action_list, [ event, context, candidate_target, first_invuln_target ]( action_t* action ) {
            action->acquire_target( event, context, candidate_target ? candidate_target : first_invuln_target );
          } );
    }

    if ( !ability->execute_event )
      trigger_ready();
  }

  void invalidate_cache( cache_e cache ) override
  {
    player_t::invalidate_cache( cache );

    switch ( cache )
    {
      case CACHE_MASTERY:
        player_t::invalidate_cache( CACHE_PLAYER_DAMAGE_MULTIPLIER );
        break;
      case CACHE_HASTE:
        player_t::invalidate_cache( CACHE_PLAYER_DAMAGE_MULTIPLIER );
        break;
      default:
        break;
    }
  }

  double matching_gear_multiplier( attribute_e attr ) const override
  {
    return attr == ATTR_INTELLECT ? 1.05 : 1.0;
  }

  stat_e convert_hybrid_stat( stat_e stat ) const override
  {
    switch ( stat )
    {
      case STAT_STR_AGI_INT:
      case STAT_AGI_INT:
      case STAT_STR_INT:
        return STAT_INTELLECT;
      case STAT_STR_AGI:
      case STAT_SPIRIT:
      case STAT_BONUS_ARMOR:
        return STAT_NONE;
      default:
        return stat;
    }
  }

  void reschedule_actor()
  {
    if ( executing || ability->execute_event || is_sleeping() || buffs.stunned->check() )
      return;

    ability->schedule_execute();
  }

  void create_options() override
  {
    player_t::create_options();

    add_option( opt_string( "variant", option.variant ) );
    add_option( opt_int( "item_level", option.item_level, 0, 4096 ) );
    add_option( opt_float( "skill", option.skill, 0, 100 ) );
  }

  void arise() override
  {
    player_t::arise();

    reschedule_actor();
  }

  void schedule_ready( timespan_t, bool ) override
  {
    reschedule_actor();
  }

  resource_e primary_resource() const override
  {
    return RESOURCE_MANA;
  }
};

struct evoker_t : public player_t
{
  // !!!===========================================================================!!!
  // !!! Runtime variables NOTE: these MUST be properly reset in evoker_t::reset() !!!
  // !!!===========================================================================!!!
  vector_with_callback<player_t*> allies_with_my_ebon;
  vector_with_callback<player_t*> allies_with_my_prescience;
  vector_with_callback<player_t*> allies_with_my_shifting_sands;
  mutable std::vector<buff_t*> active_infernos_blessings;
  mutable std::vector<buff_t*> allied_ebons_on_me;
  std::map<player_t*, buff_t*> allied_major_cds;
  player_t* last_scales_target;
  bool was_empowering;
  // !!!===========================================================================!!!

  timespan_t precombat_travel = 0_s;

  const special_effect_t* naszuro;

  std::vector<evoker_t*> allied_augmentations;
  std::vector<std::function<void()>> allied_ebon_callbacks;
  std::vector<std::function<void()>> allied_prescience_callbacks;

  struct heartbeat_t
  {
    std::vector<std::function<void()>> callbacks;
    timespan_t initial_time;
  } heartbeat;
  bool close_as_clutchmates;

  // Options
  struct options_t
  {
    // Should every Disintegrate in Dragonrage be clipped after the 3rd tick
    bool use_clipping = true;
    // Should chained Disintegrates( those with 5 ticks ) be chained after the 3rd tick in Dragonrage
    bool use_early_chaining = true;
    double scarlet_overheal = 0.5;
    double heal_eb_chance   = 0.9;
    // How much time should prepulling with Deep Breath delay opener
    timespan_t prepull_deep_breath_delay                       = timespan_t::from_seconds( 0.3 );
    timespan_t prepull_deep_breath_delay_stddev                = timespan_t::from_seconds( 0.05 );
    bool naszuro_accurate_behaviour                            = true;
    bool naszuro_bounce_destroy_solo                           = true;
    double naszuro_bounce_chance                               = 0.85;
    std::string force_clutchmates                              = "";
    bool make_simplified_if_alone                              = true;
    bool remove_precombat_ancient_flame                        = true;
    int simplified_actor_ilevel                                = -1;
    double ally_skill                                          = 0.9;
    bool simulate_bombardments                                 = true;
    timespan_t simulate_bombardments_time_between_procs_mean   = 0.2_s;
    timespan_t simulate_bombardments_time_between_procs_stddev = 0.10_s;
    timespan_t allied_virtual_cd_time                          = 118_s;
    double simulate_bombardments_fixed_crit                    = 0.21;
    int fire_breath_default_rank                               = 0;
    int eternity_surge_default_rank                            = 0;
    int upheaval_default_rank                                  = 0;
    bool allow_precombat_buffs_for_debug                       = false;
    int estimated_raid_dps_allies                              = 13;
    bool nerf_em_for_external_sims                             = false;
    bool patchwerk_in_dungeon                                  = false;
    bool force_raid                                            = false;
    std::string shifting_sands_target_if_str                   = "";
    bool sands_shuffle_list                                    = true;
  } option;

  // Action pointers
  struct actions_t
  {
    action_t* obsidian_shards;  // 2t30
    action_t* volatility;
    action_t* volatility_dragonrage;
    action_t* enkindle;
    action_t* essence_bomb;  // FS TWW3 4pc
    action_t* twin_flame;    // FS
  } action;

  // Buffs
  struct buffs_t
  {
    // Baseline Abilities
    propagate_const<buff_t*> essence_burst;
    propagate_const<buff_t*> essence_burst_titanic_wrath_disintegrate;
    propagate_const<buff_t*> hover;
    propagate_const<buff_t*> leaping_flames;
    propagate_const<buff_t*> tailwind;

    // Class Traits
    propagate_const<buff_t*> ancient_flame;
    propagate_const<buff_t*> obsidian_scales;
    propagate_const<buff_t*> scarlet_adaptation;
    propagate_const<buff_t*> tip_the_scales;

    // Devastation
    propagate_const<buff_t*> blazing_shards;  // 4t30
    propagate_const<buff_t*> burnout;
    propagate_const<buff_t*> charged_blast;
    propagate_const<buff_t*> dragonrage;
    propagate_const<buff_t*> fury_of_the_aspects;
    propagate_const<buff_t*> imminent_destruction;
    propagate_const<buff_t*> iridescence_blue;
    propagate_const<buff_t*> iridescence_blue_disintegrate;
    propagate_const<buff_t*> iridescence_red;
    propagate_const<buff_t*> limitless_potential;
    propagate_const<buff_t*> power_swell;
    propagate_const<buff_t*> feed_the_flames_stacking;
    propagate_const<buff_t*> feed_the_flames_pyre;
    propagate_const<buff_t*> emerald_trance_stacking;
    propagate_const<buff_t*> emerald_trance;
    propagate_const<buff_t*> jackpot;
    propagate_const<buff_t*> azure_sweep;
    propagate_const<buff_t*> strafing_run;
    propagate_const<buff_t*> rising_fury;
    propagate_const<buff_t*> risen_fury;
    propagate_const<buff_t*> unbound_flame;

    // Preservation

    // Augmentation
    propagate_const<buff_t*> reactive_hide;
    propagate_const<buff_t*> time_skip;
    propagate_const<buff_t*> ebon_might_self_buff;
    propagate_const<buff_t*> momentum_shift;
    propagate_const<buff_t*> t31_2pc_proc;
    propagate_const<buff_t*> t31_2pc_stacks;
    propagate_const<buff_t*> trembling_earth;
    propagate_const<buff_t*> volcanic_upsurge;  // TWW1 2PC
    propagate_const<buff_t*> tww1_4pc_aug;
    propagate_const<buff_t*> duplicate;
    propagate_const<buff_t*> magnified_fate; // MID2 4pc

    // Chronowarden
    propagate_const<buff_t*> primacy;
    propagate_const<buff_t*> temporal_burst;
    propagate_const<buff_t*> time_convergence_intellect;
    propagate_const<buff_t*> doubletime;
    // Flameshaper
    propagate_const<buff_t*> inner_flame;
    // Scalecommander
    propagate_const<buff_t*> mass_disintegrate_stacks;
    propagate_const<buff_t*> mass_disintegrate_ticks;
    propagate_const<buff_t*> mass_eruption_stacks;
    propagate_const<buff_t*> unrelenting_siege;
  } buff;

  // Specialization Spell Data
  struct specializations_t
  {
    // Baseline
    const spell_data_t* evoker;        // evoker class aura
    const spell_data_t* devastation;   // devastation class aura
    const spell_data_t* preservation;  // preservation class aura
    const spell_data_t* augmentation;  // augmentation_12_0_0 class aura
    const spell_data_t* mastery;       // Mastery Spell Data

    const spell_data_t* tempered_scales;

    const spell_data_t* fire_breath_damage;

    const spell_data_t* living_flame_damage;
    const spell_data_t* living_flame_heal;
    const spell_data_t* energizing_flame;

    const spell_data_t* emerald_blossom;
    const spell_data_t* emerald_blossom_heal;
    const spell_data_t* emerald_blossom_spec;

    // Augmentation
    const spell_data_t* close_as_clutchmates;
    std::unique_ptr<modified_spell_data_t> ebon_might;

    // Devastation

    // Preservation
  } spec;

  // Talents
  struct talents_t
  {
    // Class Traits
    player_talent_t landslide;  // row 1
    player_talent_t obsidian_scales;
    player_talent_t expunge;
    player_talent_t natural_convergence;  // row 2
    player_talent_t permeating_chill;
    player_talent_t verdant_embrace;
    player_talent_t forger_of_mountains;  // row 3
    player_talent_t innate_magic;
    player_talent_t obsidian_bulwark;
    player_talent_t enkindled;
    player_talent_t scarlet_adaptation;
    player_talent_t quell;  // row 4
    player_talent_t recall;
    player_talent_t heavy_wingbeats;
    player_talent_t clobbering_sweep;
    player_talent_t tailwind;
    player_talent_t cauterizing_flame;
    player_talent_t roar_of_exhilaration;  // row 5
    player_talent_t instinctive_arcana;
    player_talent_t tip_the_scales;
    player_talent_t attuned_to_the_dream;
    player_talent_t sleep_walk;
    player_talent_t draconic_legacy;  // row 6
    player_talent_t inherent_resistance;
    player_talent_t extended_flight;
    player_talent_t bountiful_bloom;
    player_talent_t blast_furnace;  // row 7
    player_talent_t panacea;
    const spell_data_t* panacea_spell;
    player_talent_t exuberance;
    player_talent_t source_of_magic;
    player_talent_t ancient_flame;
    player_talent_t unravel;            // row 8
    const spell_data_t* unravel_spell;  // 1264379
    player_talent_t protracted_talons;
    player_talent_t oppressing_roar;
    player_talent_t rescue;
    player_talent_t lush_growth;
    player_talent_t renewing_blaze;
    player_talent_t leaping_flames;  // row 9
    player_talent_t overawe;
    player_talent_t aerial_mastery;
    player_talent_t twin_guardian;
    player_talent_t foci_of_life;
    player_talent_t fire_within;
    player_talent_t terror_of_the_skies;  // row 10
    player_talent_t time_spiral;
    player_talent_t spatial_paradox;
    player_talent_t zephyr;

    // Devastation Traits
    player_talent_t pyre;                // row 1
    player_talent_t ruby_essence_burst;  // row 2
    player_talent_t azure_essence_burst;
    player_talent_t lay_waste;  // Row 3
    player_talent_t imposing_presence;
    player_talent_t inner_radiance;
    player_talent_t eternity_surge;
    player_talent_t volatility;  // row 4
    player_talent_t power_nexus;
    player_talent_t dragonrage;
    player_talent_t azure_sweep;
    const spell_data_t* azure_sweep_buff;   // 1265871
    const spell_data_t* azure_sweep_spell;  // 1265872
    player_talent_t arcane_intensity;
    player_talent_t ruby_embers;  // row 5
    player_talent_t animosity;
    player_talent_t essence_attunement;
    player_talent_t engulfing_blaze;  // row 6
    player_talent_t heat_wave;
    player_talent_t honed_aggression;
    player_talent_t eternitys_span;
    player_talent_t eye_of_infinity;
    player_talent_t event_horizon;
    player_talent_t catalyze;  // row 7
    player_talent_t tyranny;
    player_talent_t charged_blast;
    player_talent_t shattering_stars;
    const spell_data_t* shattering_star_spell;         // 1265804
    player_talent_t feed_the_flames;                   // row 8
    const spell_data_t* feed_the_flames_tracker_buff;  // 405874
    const spell_data_t* feed_the_flames_proc_trigger;  // 411288
    const spell_data_t* feed_the_flames_firestorm;     // 368847
    player_talent_t burnout;
    player_talent_t onyx_legacy;
    player_talent_t spellweavers_dominance;
    player_talent_t star_salvo;
    player_talent_t imminent_destruction;  // row 9
    player_talent_t font_of_magic;
    player_talent_t titanic_wrath;
    player_talent_t azure_celerity;
    player_talent_t power_swell;
    player_talent_t strafing_run;           // row 10
    const spell_data_t* strafing_run_buff;  // 1266165
    player_talent_t scorching_embers;
    player_talent_t causality;
    player_talent_t scintillation;
    player_talent_t iridescence;
    player_talent_t rising_fury_1;
    const spell_data_t* rising_fury_buff;  // 1271783
    player_talent_t rising_fury_2;
    player_talent_t rising_fury_3;
    const spell_data_t* risen_fury_buff;  // 1271799
    const spell_data_t* unbound_flame_buff;  // 1292323
    const spell_data_t* unbound_flame_spell;  // 1292321

    // Preservation Traits

    // Augmentation Traits
    player_talent_t ebon_might;
    const spell_data_t* ebon_might_self_buff;
    const spell_data_t* sands_of_time;
    player_talent_t eruption;
    player_talent_t essence_burst;
    // Imposing Presence / Inner Radiance - Non DPS
    player_talent_t ricocheting_pyroclast;
    // Essence Attunement - Devastation also has
    player_talent_t pupil_of_alexstrasza;
    player_talent_t echoing_strike;
    player_talent_t upheaval;
    player_talent_t breath_of_eons;
    const spell_data_t* breath_of_eons_damage;
    const spell_data_t* temporal_wound;
    // Defy Fate - Non DPS
    // Timelessness - Non DPS
    player_talent_t ignition_rush;
    player_talent_t volcanism;
    // Perilous Fate / Chrono Ward - Non DPS
    // Stretch Time - Non DPS
    // Geomancy - Non DPS
    // Bestow Weyrnstone - Non DPS
    player_talent_t blistering_scales;
    const spell_data_t* blistering_scales_damage;
    // Draconic Attunements - Non DPS
    player_talent_t arcane_reach;
    player_talent_t unyielding_domain;
    player_talent_t tectonic_locus;
    player_talent_t regenerative_chitin;
    player_talent_t molten_blood;
    // Power Nexus - Devastation also has
    // Aspects' Favor - Non DPS
    player_talent_t plot_the_future;
    player_talent_t dream_of_spring;
    player_talent_t symbiotic_bloom;
    player_talent_t reactive_hide;
    const spell_data_t* reactive_hide_buff;
    player_talent_t hoarded_power;
    player_talent_t prescience;
    const spell_data_t* prescience_buff;
    // Prolong Life - Non DPS. Scarlet Exists. Todo: Implement Healing
    player_talent_t momentum_shift;
    player_talent_t infernos_blessing;
    const spell_data_t* infernos_blessing_damage;
    const spell_data_t* infernos_blessing_buff;
    player_talent_t time_skip;
    player_talent_t accretion;
    player_talent_t anachronism;
    player_talent_t motes_of_possibility;
    player_talent_t clairvoyant;
    // Font of Magic - Devastation ha
    player_talent_t tomorrow_today;
    player_talent_t interwoven_threads;
    player_talent_t overlord;
    player_talent_t fate_mirror;
    const spell_data_t* fate_mirror_damage;
    player_talent_t rumbling_earth;
    player_talent_t molten_embers;
    player_talent_t mighty_inferno;
    player_talent_t duplicate1;
    const spell_data_t* duplicate_eruption_spell;     // 1259172
    const spell_data_t* duplicate_fire_breath_charge_spell;  // 1283718
    const spell_data_t* duplicate_fire_breath_release_spell;  // 431164
    const spell_data_t* duplicate_upheaval_spell;     // 396288
    player_talent_t duplicate2;
    player_talent_t duplicate3;
    const spell_data_t* duplicate3_buff;  // 1259171

    struct chronowarden_t
    {
      player_talent_t chrono_flame;
      const spell_data_t* chrono_flames_spell;  // 431443
      const spell_data_t* chrono_flame_damage;  // 431583
      player_talent_t warp;
      player_talent_t temporal_burst;
      const spell_data_t* temporal_burst_buff;  // 431698
      player_talent_t reverberations;
      const spell_data_t* reverberations_upheaval;  // 431620
      player_talent_t temporality;
      const spell_data_t* temporality_buff;  // 431872
      player_talent_t motes_of_acceleration;
      player_talent_t primacy;
      const spell_data_t* primacy_buff;  // 431654
      player_talent_t double_time;
      player_talent_t time_convergence;
      const spell_data_t* time_convergence_intellect_buff;  // 431991
      const spell_data_t* time_convergence_stamina_buff;    // 431993
      player_talent_t master_of_destiny;
      player_talent_t golden_opportunity;
      player_talent_t instability_matrix;
      player_talent_t afterimage;
      player_talent_t chronoboon;
      player_talent_t overclock;
      player_talent_t energy_cycles;
      player_talent_t chronal_dynamo;
      const spell_data_t* doubletime_buff;  // 460688
    } chronowarden;

    struct flameshaper_t
    {
      player_talent_t legacy_of_the_lifebinder;
      player_talent_t trailblazer;
      player_talent_t shape_of_flame;
      player_talent_t enkindle;
      const spell_data_t* enkindle_damage;  // 444017
      player_talent_t conduit_of_flame;
      player_talent_t burning_adrenaline;
      player_talent_t fan_the_flames;
      player_talent_t expanded_lungs;
      player_talent_t fulminous_roar;
      player_talent_t titanic_precision;
      player_talent_t lifecinders;
      player_talent_t draconic_instincts;
      player_talent_t consume_flame;
      const spell_data_t* consume_flame_damage;   // 444089
      const spell_data_t* inner_flame_buff_base;  // TWw3_2pc 1236776
      const spell_data_t* inner_flame_buff;       // TWw3_2pc 1236776
      const spell_data_t* essence_bomb_spell;     // TWw3_4pc 1236792
      player_talent_t ashes_in_motion;
      player_talent_t deep_exhalation;
      player_talent_t essence_well;
      player_talent_t twin_flame;
      const spell_data_t* twin_flame_damage_spell;  // 1265980
      const spell_data_t* twin_flame_heal_spell;    // 1265991
      player_talent_t fire_torrent;
    } flameshaper;

    struct scalecommander_t
    {
      player_talent_t mass_disintegrate;
      const spell_data_t* mass_disintegrate_buff;  // 436336
      player_talent_t mass_eruption;
      const spell_data_t* mass_eruption_damage;  // 438653
      const spell_data_t* mass_eruption_buff;    // 438588
      player_talent_t might_of_the_black_dragonflight;
      player_talent_t bombardments;
      const spell_data_t* bombardments_debuff;  // 434473
      const spell_data_t* bombardments_driver;  // 443788
      const spell_data_t* bombardments_damage;  // 434481
      player_talent_t onslaught;
      player_talent_t melt_armor;
      const spell_data_t* melt_armor_debuff;  // 441172
      player_talent_t wingleader;
      player_talent_t unrelenting_siege;
      const spell_data_t* unrelenting_siege_buff;  // 441248
      player_talent_t hardened_scales;
      player_talent_t menacing_presence;
      player_talent_t extended_battle;
      player_talent_t diverted_power;
      player_talent_t nimble_flyer;
      player_talent_t slipstream;
      player_talent_t maneuverability;                     // Melt Armor debuff is the damage done
      const spell_data_t* maneuverability_breath_of_eons;  // 442204
      const spell_data_t* maneuverability_deep_breath;     // 433874
      const spell_data_t* commando_deep_breath_buff;       // TWW3_2pc 1236943
      player_talent_t command_squadron;
      const spell_data_t* command_squadron_pyre_spell;  // 1236970
      player_talent_t concentrated_power;
      player_talent_t refined_essence;

    } scalecommander;

  } talent;

  // Benefits
  struct benefits_t
  {
    propagate_const<benefit_t*> supercharged_shards;
  } benefit;

  // Cooldowns
  struct cooldowns_t
  {
    propagate_const<cooldown_t*> eternity_surge;
    propagate_const<cooldown_t*> fire_breath;
    propagate_const<cooldown_t*> firestorm;
    propagate_const<cooldown_t*> upheaval;
    propagate_const<cooldown_t*> breath_of_eons;
    propagate_const<cooldown_t*> tip_the_scales;
    propagate_const<cooldown_t*> deep_breath;
    propagate_const<cooldown_t*> hover;
  } cooldown;

  // Gains
  struct gains_t
  {
    propagate_const<gain_t*> roar_of_exhilaration;
    propagate_const<gain_t*> energizing_flame;
  } gain;

  // Procs
  struct procs_t
  {
    propagate_const<proc_t*> ruby_essence_burst;
    propagate_const<proc_t*> azure_essence_burst;
    propagate_const<proc_t*> titanic_precision_ruby_essence_burst;
    propagate_const<proc_t*> titanic_precision_azure_essence_burst;
    propagate_const<proc_t*> emerald_trance;
    propagate_const<proc_t*> anachronism_essence_burst;
    propagate_const<proc_t*> echoing_strike;
    propagate_const<proc_t*> overwritten_leaping_flames;
    propagate_const<proc_t*> diverted_power;
    propagate_const<proc_t*> destroyers_scarred_wards;
    propagate_const<proc_t*> tww2_4pc;
    propagate_const<proc_t*> hoarded_power;
    propagate_const<proc_t*> essence_well;
  } proc;

  // RPPMs
  struct rppms_t
  {
  } rppm;

  // Uptimes
  struct uptimes_t
  {
  } uptime;

  struct pets_t
  {
    spawner::pet_spawner_t<pets::dracthyr_commando_t, evoker_t> commando_pet;
    spawner::pet_spawner_t<pets::duplicate_t, evoker_t> duplicate_pet;

    pets_t( evoker_t* e ) : commando_pet( "dracthyr_commando", e ), duplicate_pet( "duplicate", e )
    {
      duplicate_pet.set_default_duration( e->find_spell( 1259171 )->duration() );
    }
  } pets;

  // Background Actions
  struct background_actions_t
  {
    propagate_const<action_t*> ebon_might;
    propagate_const<action_t*> tip_the_scales;
    propagate_const<action_t*> consume_flame;
  } background_actions;

  proc_data_t background_proc_data;

  evoker_t( sim_t* sim, std::string_view name, race_e r = RACE_DRACTHYR_HORDE );

  // Character Definitions
  void validate_sim_options() override;
  unsigned int specialization_aura_id();
  void init_action_list() override;
  void init_blizzard_action_list() override;
  parsed_assisted_combat_rule_t parse_assisted_combat_rule( const assisted_combat_rule_data_t& rule,
                                                            const assisted_combat_step_data_t& step ) const override;
  void parse_assisted_combat_step( const assisted_combat_step_data_t& step,
                                   action_priority_list_t* assisted_combat ) override;
  std::vector<std::string> action_names_from_spell_id( unsigned int spell_id ) const override;
  std::string aura_expr_from_spell_id( unsigned int spell_id, bool on_self ) const override;
  void init_finished() override;
  void init_base_stats() override;
  void init_background_actions() override;
  // void init_resources( bool ) override;
  void init_benefits() override;
  resource_e primary_resource() const override
  {
    return RESOURCE_ESSENCE;
  }
  role_e primary_role() const override;
  void init_gains() override;
  void init_procs() override;
  // void init_rng() override;
  // void init_uptimes() override;
  void init_items() override;
  void init_spells() override;
  void init_special_effects() override;
  void init_assessors() override;
  // void init_finished() override;
  void create_actions() override;
  void create_buffs() override;
  void create_options() override;
  void create_permanent_actors() override;
  void create_pets() override;
  // void arise() override;
  void moving() override;
  void schedule_ready( timespan_t, bool ) override;
  void combat_begin() override;
  // void combat_end() override;
  void analyze( sim_t& ) override;
  void reset() override;
  void copy_from( player_t* ) override;
  void merge( player_t& ) override;
  std::string default_potion() const override;
  std::string default_flask() const override;
  std::string default_food() const override;
  std::string default_rune() const override;
  std::string default_temporary_enchant() const override;

  target_specific_t<evoker_td_t> target_data;
  const evoker_td_t* find_target_data( const player_t* target ) const override;
  evoker_td_t* get_target_data( player_t* target ) const override;

  action_t* create_action( std::string_view name, std::string_view options_str ) override;
  std::unique_ptr<expr_t> create_expression( std::string_view expr_str ) override;

  // Stat & Multiplier overrides
  double matching_gear_multiplier( attribute_e ) const override;
  double composite_player_pet_damage_multiplier( const action_state_t* s, bool guardian ) const override;
  double composite_base_armor_multiplier() const override;
  double composite_armor() const override;
  double composite_base_armor() const;
  double composite_attribute_multiplier( attribute_e ) const override;
  double composite_player_multiplier( school_e ) const override;
  double composite_player_target_crit_chance( player_t* target ) const override;
  double composite_spell_haste() const override;
  double composite_melee_haste() const override;
  double composite_mitigation_multiplier( const action_state_t*, school_e, bool direct ) const override;
  stat_e convert_hybrid_stat( stat_e ) const override;
  double non_stacking_movement_modifier() const override;
  double stacking_movement_modifier() const override;
  double resource_regen_per_second( resource_e ) const override;

  void bounce_naszuro( player_t*, timespan_t );

  // Augmentation Helpers
  void spawn_mote_of_possibility( player_t* = nullptr, mote_buffs_e = mote_buffs_e::MAX,
                                  timespan_t = timespan_t::zero() );
  void extend_ebon( timespan_t );
  void apply_bombardments( player_t* );

  // Utility functions
  const spelleffect_data_t* find_spelleffect( const spell_data_t* spell, effect_subtype_t subtype = A_MAX,
                                              int misc_value               = P_GENERIC,
                                              const spell_data_t* affected = spell_data_t::nil(),
                                              effect_type_t type           = E_APPLY_AURA );
  const spell_data_t* find_spell_override( const spell_data_t* base, const spell_data_t* passive );

  std::vector<action_t*> secondary_action_list;

  template <typename T, typename... Ts>
  T* get_secondary_action( std::string_view n, Ts&&... args )
  {
    auto it = range::find( secondary_action_list, n, &action_t::name_str );
    if ( it != secondary_action_list.cend() )
      return dynamic_cast<T*>( *it );

    auto a        = new T( this, std::forward<Ts>( args )... );
    a->background = true;
    secondary_action_list.push_back( a );
    return a;
  }
};

namespace pets
{
// ==========================================================================
// Base Evoker Pet Action
// ==========================================================================

template <typename T_PET, typename Base>
struct pet_action_t : public parse_action_effects_t<Base>
{
  using action_base_t = parse_action_effects_t<Base>;
  using base_t        = pet_action_t<T_PET, Base>;

  pet_action_t( T_PET* p, std::string_view name, const spell_data_t* spell = spell_data_t::nil() )
    : action_base_t( name, p, spell )
  {
    this->special = this->may_crit = true;
    if ( this->data().ok() )
    {
      apply_pet_action_effects();
      if ( this->type == action_e::ACTION_SPELL || this->type == action_e::ACTION_ATTACK )
      {
        apply_pet_target_effects();
      }
    }
  }

  void apply_pet_action_effects();
  void apply_pet_target_effects();

  template <typename... Ts>
  void parse_effects( Ts&&... args )
  {
    action_base_t::parse_effects( std::forward<Ts>( args )... );
  }
  template <typename... Ts>
  void parse_target_effects( Ts&&... args )
  {
    action_base_t::parse_target_effects( std::forward<Ts>( args )... );
  }

  T_PET* pet() const
  {
    return debug_cast<T_PET*>( this->player );
  }

  evoker_t* evoker() const
  {
    return debug_cast<evoker_t*>( pet()->owner );
  }

  void init() override
  {
    action_base_t::init();

    // Merge stats for pets sharing the same name
    if ( !this->player->sim->report_pets_separately )
    {
      auto it =
          range::find_if( evoker()->pet_list, [ & ]( pet_t* pet ) { return this->player->name_str == pet->name_str; } );

      if ( it != evoker()->pet_list.end() && this->player != *it )
      {
        this->stats = ( *it )->get_stats( this->name(), this );
      }
    }
  }

  bool ready() override
  {
    if ( this->player->is_moving() )
      return false;

    return action_base_t::ready();
  }
};
template <typename T_PET>
struct pet_spell_t : public pet_action_t<T_PET, spell_t>
{
  using ab = pet_action_t<T_PET, spell_t>;
  pet_spell_t( T_PET* p, std::string_view name, const spell_data_t* spell = spell_data_t::nil() )
    : ab( p, name, spell )
  {
    /* this->tick_may_crit = true;
     this->hasted_ticks  = false;*/
  }

  T_PET* p()
  {
    return debug_cast<T_PET*>( ab::player );
  }

  evoker_t* o()
  {
    return debug_cast<evoker_t*>( ab::player->owner );
  }
};

// Empowered spell base templates
struct empower_data_t
{
  empower_e empower;

  friend void sc_format_to( const empower_data_t& data, fmt::format_context::iterator out )
  {
    fmt::format_to( out, "empower_level={}", static_cast<int>( data.empower ) );
  }
};

template <class T_PET>
struct empowered_pet_spell_t : public pet_spell_t<T_PET>
{
protected:
  using state_t = evoker_action_state_t<empower_data_t>;
  using BASE = pet_spell_t<T_PET>;

public:
  empower_e max_empower;

  empowered_pet_spell_t( T_PET* p, std::string_view name, const spell_data_t* spell )
    : pet_spell_t<T_PET>( p, name, spell ),
      max_empower( empower_e::EMPOWER_3 )
  {
  }

  action_state_t* new_state() override
  {
    return new state_t( this, BASE::target );
  }

  state_t* cast_state( action_state_t* s )
  {
    return static_cast<state_t*>( s );
  }

  const state_t* cast_state( const action_state_t* s ) const
  {
    return static_cast<const state_t*>( s );
  }
};

template <class T_PET>
struct empowered_pet_release_t : public empowered_pet_spell_t<T_PET>
{
  using ab = empowered_pet_spell_t<T_PET>;

  empowered_pet_release_t( T_PET* p, std::string_view name, const spell_data_t* spell )
    : ab( p, name, spell )
  {
    ab::dual = true;

    // TODO: Continue to check it uses this spell to trigger GCD, as of 28/10/2022 it does. It can still be bypassed via
    // spell queue. Potentally add a better way to model this?
    const spell_data_t* gcd_spell = p->evoker()->find_spell( 359115 );
    if ( gcd_spell )
      ab::trigger_gcd = gcd_spell->gcd();
    ab::gcd_type = gcd_haste_type::NONE;
  }

  empower_e empower_level( const action_state_t* s ) const
  {
    return ab::cast_state( s )->empower;
  }

  int empower_value( const action_state_t* s ) const
  {
    return static_cast<int>( ab::cast_state( s )->empower );
  }

  void execute() override
  {
    ab::p()->was_empowering = false;

    ab::execute();
  }
};

template <class T_PET>
struct empowered_pet_charge_t : public empowered_pet_spell_t<T_PET>
{
  using ab = empowered_pet_spell_t<T_PET>;

  action_t* release_spell;
  stats_t* dummy_stat;  // used to hack channel tick time into execute time
  stats_t* orig_stat;
  int empower_to;
  timespan_t base_empower_duration;
  timespan_t lag;

  void setup_empower_stats( empower_e empower_level )
  {
    empower_to = empower_level;
    if ( static_cast<empower_e>( empower_to ) == EMPOWER_MAX )
    {
      base_empower_duration = max_hold_time();
    }
    else
    {
      empower_to            = std::min( static_cast<int>( ab::max_empower ), empower_to );
      base_empower_duration = base_time_to_empower( static_cast<empower_e>( empower_to ) );
    }

    // apply parsed modifiers
    ab::dot_duration      = ab::player->get_passive_value( ab::data(), "duration" );
    ab::dot_duration.base = base_empower_duration;
    ab::base_tick_time    = ab::dot_duration;
  }

  void setup_empower_stats( int empower_level )
  {
    assert( empower_level > 0 );
    assert( empower_level <= 5 );
    setup_empower_stats( static_cast<empower_e>( empower_level ) );
  }

  empowered_pet_charge_t( T_PET* p, std::string_view name, const spell_data_t* spell )
    : ab( p, name, spell ),
      release_spell( nullptr ),
      dummy_stat( p->get_stats( "dummy_stat" ) ),
      orig_stat( ab::stats ),
      empower_to( EMPOWER_MAX ),
      base_empower_duration( 0_ms ),
      lag( 0_ms )
  {
    ab::channeled = true;

    setup_empower_stats( empower_to );

    ab::gcd_type = gcd_haste_type::NONE;
    if ( ab::trigger_gcd > timespan_t::zero() )
      ab::min_gcd = ab::trigger_gcd;
  }

  template <typename T>
  void create_release_spell( std::string_view n )
  {
    static_assert( std::is_base_of_v<empowered_pet_release_t<T_PET>, T>,
                   "Empowered release spell must be dervied from empowered_pet_release_spell_t." );

    release_spell = ab::p()->template get_secondary_action<T_PET, T>( n );

    ab::add_child( release_spell );

    release_spell->stats      = ab::stats;
    release_spell->background = false;
  }

  timespan_t base_time_to_empower( empower_e emp ) const
  {
    // TODO: confirm these values and determine if they're set values or adjust based on a formula
    // Currently all empowered spells are 2.5s base and 3.25s with empower 4
    switch ( emp )
    {
      case empower_e::EMPOWER_1:
        return 1000_ms;
      case empower_e::EMPOWER_2:
        return 1750_ms;
      case empower_e::EMPOWER_3:
        return 2500_ms;
      case empower_e::EMPOWER_4:
        return 3250_ms;
      default:
        break;
    }

    return 0_ms;
  }

  timespan_t max_hold_time() const
  {
    // TODO: confirm if this is affected by duration mods/haste
    return base_time_to_empower( ab::max_empower ) + 2_s;
  }

  timespan_t tick_time( const action_state_t* s ) const override
  {
    return composite_dot_duration( s );
  }

  timespan_t composite_dot_duration( const action_state_t* s ) const override
  {
    auto dur = ab::composite_dot_duration( s );

    // hack so we always have a non-zero duration in order to trigger last_tick()
    if ( dur == 0_ms )
      return 1_ms;

    return dur + lag;
  }

  timespan_t composite_time_to_empower( const action_state_t* s, empower_e emp ) const
  {
    auto base = base_time_to_empower( emp );
    auto mult = composite_dot_duration( s ) / base_empower_duration;

    return base * mult;
  }

  empower_e empower_level( const dot_t* d ) const
  {
    auto emp = empower_e::EMPOWER_NONE;

    if ( !d->is_ticking() )
      return emp;

    auto s       = d->state;
    auto elapsed = tick_time( s ) - d->time_to_next_full_tick();

    if ( elapsed >= composite_time_to_empower( s, empower_e::EMPOWER_4 ) )
      emp = empower_e::EMPOWER_4;
    else if ( elapsed >= composite_time_to_empower( s, empower_e::EMPOWER_3 ) )
      emp = empower_e::EMPOWER_3;
    else if ( elapsed >= composite_time_to_empower( s, empower_e::EMPOWER_2 ) )
      emp = empower_e::EMPOWER_2;
    else if ( elapsed >= composite_time_to_empower( s, empower_e::EMPOWER_1 ) )
      emp = empower_e::EMPOWER_1;

    return std::min( ab::max_empower, emp );
  }

  void init() override
  {
    ab::init();
    assert( release_spell && "Empowered charge spell must have a release spell." );
  }

  void execute() override
  {
    // pre-determine lag here per every execute
    lag = ab::rng().gauss( ab::sim->channel_lag );

    ab::execute();
  }

  void tick( dot_t* d ) override
  {
    // For proper DPET analysis, we need to treat charge spells as non-channel, since channelled spells sum up tick
    // times to get the execute time, but this does not work for fire breath which also has a dot component. Instead we
    // hijack the stat obj during action_t:tick() causing the channel's tick to be recorded onto a throwaway stat obj.
    // We then record the corresponding tick time as execute time onto the original real stat obj. See further notes in
    // evoker_t::analyze()
    ab::stats = dummy_stat;
    ab::tick( d );
    ab::stats = orig_stat;

    ab::stats->iteration_total_execute_time += d->time_to_tick();
  }

  virtual player_t* get_release_target( dot_t* )
  {
    return ab::target;
  }

  void last_tick( dot_t* d ) override
  {
    ab::last_tick( d );

    // being stunned ends the empower without triggering the release spell
    if ( ab::p()->buffs.stunned->check() )
    {
      ab::p()->was_empowering = false;
      return;
    }

    auto release_target = get_release_target( d );

    if ( empower_level( d ) == empower_e::EMPOWER_NONE || !release_target )
    {
      ab::p()->was_empowering = false;
      return;
    }

    auto emp_state        = release_spell->get_state();
    emp_state->target     = release_target;
    release_spell->target = release_target;
    release_spell->snapshot_state( emp_state, release_spell->amount_type( emp_state ) );

    ab::cast_state( emp_state )->empower = empower_level( d );

    release_spell->schedule_execute( emp_state );

    // hack to prevent dot_t::last_tick() from schedule_ready()'ing the player
    d->current_action = release_spell;
    // hack to prevent channel lag being added when player is schedule_ready()'d after the release spell execution
    ab::p()->last_foreground_action = release_spell;
    // Start GCD - All Empowerw have a GCD of 0.5s after completion.
    ab::start_gcd();
  }
};

struct evoker_pet_t : public pet_t
{
  bool use_auto_attack, precombat_spawn;
  timespan_t precombat_spawn_adjust;
  bool was_empowering;

  std::vector<action_t*> secondary_action_list;

  template <typename T_PET, typename T, typename... Ts>
  T* get_secondary_action( std::string_view n, Ts&&... args )
  {
    auto it = range::find( secondary_action_list, n, &action_t::name_str );
    if ( it != secondary_action_list.cend() )
      return dynamic_cast<T*>( *it );

    auto a        = new T( dynamic_cast<T_PET*>( this ), n, std::forward<Ts>( args )... );
    a->background = true;
    secondary_action_list.push_back( a );
    return a;
  }

  evoker_pet_t( evoker_t* player, std::string_view name, bool guardian = true, bool auto_attack = true,
                bool dynamic = true )
    : pet_t( player->sim, player, name, guardian, dynamic ),
      use_auto_attack( auto_attack ),
      precombat_spawn( false ),
      precombat_spawn_adjust( 0_s ),
      was_empowering( false ),
      secondary_action_list()
  {
    if ( auto_attack )
    {
      main_hand_weapon.type = WEAPON_BEAST;
    }
  }

  void init_finished() override
  {
    pet_t::init_finished();
  }

  // pets dont care about armor, return 0 for speed
  double composite_bonus_armor() const override
  {
    return 0;
  }

  // pets dont care about incoming damage, return 0 for speed
  double composite_mitigation_versatility() const override
  {
    return 0;
  }

  evoker_t* evoker() const
  {
    return debug_cast<evoker_t*>( owner );
  }

  virtual attack_t* create_main_hand_auto_attack()
  {
    return nullptr;
  }

  virtual attack_t* create_off_hand_auto_attack()
  {
    return nullptr;
  }

  // const evoker_td_t* find_target_data( const player_t* target ) const override
  //{
  //   return evoker()->find_target_data( target );
  // }

  // evoker_td_t* get_target_data( player_t* target ) const override
  //{
  //   return evoker()->get_target_data( target );
  // }

  void arise() override
  {
    pet_t::arise();
  }

  void demise() override
  {
    pet_t::demise();
  }

  void reset() override
  {
    pet_t::reset();
    was_empowering = false;
  }

  void moving() override
  {
    // If we are mid-empower and forced to move, we don't want player_t::interrupt() to schedule_ready as the release
    // action will handle that for us. We set the bool here and override player_t::schedule_ready to return if bool is
    // set.
    if ( channeling && dynamic_cast<empowered_pet_charge_t<evoker_pet_t>*>( channeling ) )
      was_empowering = true;

    player_t::moving();
  }

  void analyze( sim_t& sim ) override
  {
    // For proper DPET analysis, we need to treat empowered spell stat objs as non-channelled so the dot ticks from fire
    // breath do not get summed up into total execute time. All empowered spells have a release spell that is pushed
    // onto secondary_action_list, which we can use to find stat objs for empowered actions without having to go through
    // the entire action_list. See empower_charge_spell_t::tick() for more notes.
    for ( auto a : secondary_action_list )
    {
      if ( auto emp = dynamic_cast<empowered_pet_charge_t<evoker_pet_t>*>( a->stats->action_list[ 0 ] ) )
        range::for_each( emp->stats->action_list, []( action_t* a ) { a->channeled = false; } );
    }

    player_t::analyze( sim );
  }

  void schedule_ready( timespan_t delta_time, bool waiting ) override
  {
    if ( was_empowering )
      return;

    player_t::schedule_ready( delta_time, waiting );
  }

  void trigger_pet_movement( double dist )
  {
    if ( dist == 0 )
      return;

    this->trigger_movement( dist, movement_direction_type::TOWARDS );
    auto dur = this->time_to_move();
    make_event( *sim, dur, [ &, dur ] { update_movement( dur ); } );
  }

  double composite_player_multiplier( school_e s ) const override
  {
    double m = pet_t::composite_player_multiplier( s );

    return m;
  }

  // Standard Evoker pet actions
  struct auto_attack_t final : public melee_attack_t
  {
    auto_attack_t( evoker_pet_t* p ) : melee_attack_t( "auto_attack", p )
    {
      assert( p->main_hand_weapon.type != WEAPON_NONE );
      p->main_hand_attack                    = p->create_main_hand_auto_attack();
      p->main_hand_attack->weapon            = &( p->main_hand_weapon );
      p->main_hand_attack->base_execute_time = p->main_hand_weapon.swing_time;

      if ( p->off_hand_weapon.type != WEAPON_NONE )
      {
        p->off_hand_attack                    = p->create_off_hand_auto_attack();
        p->off_hand_attack->weapon            = &( p->off_hand_weapon );
        p->off_hand_attack->base_execute_time = p->off_hand_weapon.swing_time;
        p->off_hand_attack->id                = 1;
      }

      ignore_false_positive = true;
      trigger_gcd           = 0_ms;
      school                = SCHOOL_PHYSICAL;
    }

    void execute() override
    {
      player->main_hand_attack->schedule_execute();
      if ( player->off_hand_attack )
      {
        player->off_hand_attack->schedule_execute();
      }
    }

    bool ready() override
    {
      if ( player->is_moving() )
        return false;
      return ( player->main_hand_attack->execute_event == nullptr );
    }
  };

  action_t* create_action( std::string_view name, std::string_view options_str ) override
  {
    if ( name == "auto_attack" )
      return new auto_attack_t( this );

    return pet_t::create_action( name, options_str );
  }

  void create_buffs() override
  {
    pet_t::create_buffs();
  }

  void init_action_list() override
  {
    action_priority_list_t* def = get_action_priority_list( "default" );
    if ( use_auto_attack )
      def->add_action( "auto_attack" );

    pet_t::init_action_list();
  }
};
}  // namespace pets

namespace buffs
{
// Template for base evoker buffs
template <class Base>
struct evoker_buff_t : public Base
{
private:
  using bb = Base;  // buff base, buff_t/stat_buff_t/etc.

protected:
  using base_t = evoker_buff_t<buff_t>;  // shorthand

public:
  evoker_buff_t( evoker_t* player, std::string_view name, const spell_data_t* spell = spell_data_t::nil(),
                 const item_t* item = nullptr )
    : bb( player, name, spell, item )
  {
  }

  evoker_buff_t( evoker_td_t& td, std::string_view name, const spell_data_t* spell = spell_data_t::nil(),
                 const item_t* item = nullptr )
    : bb( td, name, spell, item )
  {
  }

  timespan_t buff_duration() const override
  {
    if ( p()->specialization() != EVOKER_AUGMENTATION || !bb::data().affected_by( p()->spec.mastery->effectN( 2 ) ) )
      return bb::buff_duration();

    auto m = 1.0 + p()->cache.mastery() * p()->spec.mastery->effectN( 2 ).mastery_value();

    return m * bb::buff_duration();
  }

  evoker_t* p()
  {
    return static_cast<evoker_t*>( bb::source );
  }

  const evoker_t* p() const
  {
    return static_cast<evoker_t*>( bb::source );
  }
};

struct time_skip_t : public buff_t
{
  std::vector<action_t*> affected_actions;

  time_skip_t( evoker_t* p ) : buff_t( p, "time_skip", p->talent.time_skip )
  {
    set_cooldown( 0_ms );
    set_default_value_from_effect( 1 );
    set_stack_change_callback( [ this ]( buff_t* /* b */, int /* old */, int new_ ) { update_cooldowns( new_ ); } );
  }

  void update_cooldowns( int new_ )
  {
    double recharge_rate_multiplier = 1.0 / ( default_value );
    for ( auto a : affected_actions )
    {
      if ( new_ > 0 )
      {
        a->dynamic_recharge_rate_multiplier *= recharge_rate_multiplier;
      }
      else
      {
        a->dynamic_recharge_rate_multiplier /= recharge_rate_multiplier;
      }
      if ( a->cooldown->action == a )
        a->cooldown->adjust_recharge_multiplier();
      if ( a->internal_cooldown->action == a )
        a->internal_cooldown->adjust_recharge_multiplier();
    }
  }
};
}  // namespace buffs

// Base Classes =============================================================

struct stats_data_t
{
  stats_t* stats;
};

struct augment_t : public spell_base_t
{
private:
  using ab = spell_base_t;

public:
  augment_t( std::string_view name, player_t* player, const spell_data_t* spell = spell_data_t::nil() )
    : ab( ACTION_OTHER, name, player, spell )
  {
    harmful = false;
    if ( !target || target->is_enemy() )
      target = player;
  }

  void activate() override
  {
    sim->player_no_pet_list.register_callback( [ this ]( player_t* ) { target_cache.is_valid = false; } );
  }

  int num_targets() const override
  {
    return as<int>( range::count_if( sim->player_no_pet_list, []( player_t* t ) {
      if ( t->is_sleeping() )
        return false;
      return true;
    } ) );
  }

  size_t available_targets( std::vector<player_t*>& target_list ) const override
  {
    target_list.clear();
    target_list.push_back( target );

    for ( const auto& t : sim->player_no_pet_list )
    {
      if ( t->is_sleeping() )
        continue;

      if ( t != target )
        target_list.push_back( t );
    }

    return target_list.size();
  }

  std::unique_ptr<expr_t> create_expression( util::string_view name ) override
  {
    if ( name_str == "active_allies" )
    {
      return make_fn_expr( "active_allies", [ this ] { return num_targets(); } );
    }

    return spell_base_t::create_expression( name );
  }

  player_t* get_expression_target() override
  {
    return target;
  }
};

struct external_action_data
{
  evoker_t* evoker;
};

// Template for base external evoker action code.
template <class Base>
struct evoker_external_action_t : public Base
{
private:
  using ab = Base;  // action base, spell_t/heal_t/etc.

protected:
  using state_t = evoker_action_state_t<external_action_data>;

public:
  evoker_t* evoker;

  evoker_external_action_t( std::string_view name, player_t* player, const spell_data_t* spell = spell_data_t::nil() )
    : ab( name, player, spell ), evoker( nullptr )
  {
  }

  action_state_t* new_state() override
  {
    return new state_t( this, ab::target );
  }

  state_t* cast_state( action_state_t* s )
  {
    return static_cast<state_t*>( s );
  }

  const state_t* cast_state( const action_state_t* s ) const
  {
    return static_cast<const state_t*>( s );
  }

  // We overload these methods with versions that take the action state as an argument.
  // Base methods are brought up to scope to squash warnings, but set private for now.
  // Set public if base methods needs to be accessed from a derived object in the future.
private:
  using ab::composite_crit_chance;
  using ab::composite_crit_chance_multiplier;
  using ab::composite_haste;

public:
  virtual double composite_crit_chance( const action_state_t* s ) const
  {
    return action_t::composite_crit_chance() + p( s )->cache.spell_crit_chance();
  }

  virtual double composite_haste( const action_state_t* s ) const
  {
    return action_t::composite_haste() * p( s )->cache.spell_cast_speed();
  }

  virtual double composite_crit_chance_multiplier( const action_state_t* s ) const
  {
    return action_t::composite_crit_chance_multiplier() * p( s )->composite_spell_crit_chance_multiplier();
  }

  double composite_versatility( const action_state_t* s ) const override
  {
    return action_t::composite_versatility( s ) + p( s )->cache.damage_versatility();
  }

  double composite_attack_power( const action_state_t* s ) const
  {
    return p( s )->composite_total_attack_power_by_type( ab::get_attack_power_type() );
  }

  double composite_spell_power( const action_state_t* s ) const
  {
    double spell_power = 0;
    double tmp;

    auto _player = p( s );

    for ( auto base_school : ab::base_schools )
    {
      tmp = _player->composite_total_spell_power( base_school );
      if ( tmp > spell_power )
        spell_power = tmp;
    }

    return spell_power;
  }

  void snapshot_internal( action_state_t* state, unsigned flags, result_amount_type rt ) override
  {
    assert( state );

    cast_state( state )->evoker = evoker;

    assert( p( state ) );

    ab::snapshot_internal( state, flags, rt );

    if ( flags & STATE_CRIT )
      state->crit_chance = composite_crit_chance( state ) * composite_crit_chance_multiplier( state );

    if ( flags & STATE_HASTE )
      state->haste = composite_haste( state );

    if ( flags & STATE_AP )
      state->attack_power = composite_attack_power( state );

    if ( flags & STATE_SP )
      state->spell_power = composite_spell_power( state );

    if ( flags & STATE_VERSATILITY )
      state->versatility = composite_versatility( state );
  }

  void snapshot_state( action_state_t* s, result_amount_type rt ) override
  {
    ab::snapshot_state( s, rt );
    cast_state( s )->evoker = evoker;
  }

  evoker_t* p( action_state_t* s )
  {
    return cast_state( s )->evoker;
  }

  const evoker_t* p( const action_state_t* s ) const
  {
    return cast_state( s )->evoker;
  }

  evoker_td_t* td( action_state_t* s, player_t* t ) const
  {
    return p( s )->get_target_data( t );
  }

  const evoker_td_t* find_td( action_state_t* s, const player_t* t ) const
  {
    return p( s )->find_target_data( t );
  }
};

// Template for base external evoker action code.
template <class Base>
struct evoker_external_scaling_action_t : public Base
{
private:
  using ab = Base;  // action base, spell_t/heal_t/etc.

protected:
  using state_t = evoker_action_state_t<external_action_data>;

public:
  evoker_t* evoker;

  evoker_external_scaling_action_t( std::string_view name, player_t* player,
                                    const spell_data_t* spell = spell_data_t::nil() )
    : ab( name, player, spell ), evoker( nullptr )
  {
  }

  action_state_t* new_state() override
  {
    return new state_t( this, ab::target );
  }

  state_t* cast_state( action_state_t* s )
  {
    return static_cast<state_t*>( s );
  }

  const state_t* cast_state( const action_state_t* s ) const
  {
    return static_cast<const state_t*>( s );
  }

  void snapshot_internal( action_state_t* state, unsigned flags, result_amount_type rt ) override
  {
    assert( state );

    cast_state( state )->evoker = evoker;

    assert( p( state ) );

    ab::snapshot_internal( state, flags, rt );
  }

  void snapshot_state( action_state_t* s, result_amount_type rt ) override
  {
    ab::snapshot_state( s, rt );
    cast_state( s )->evoker = evoker;
  }

  evoker_t* p( action_state_t* s )
  {
    return cast_state( s )->evoker;
  }

  const evoker_t* p( const action_state_t* s ) const
  {
    return cast_state( s )->evoker;
  }

  evoker_td_t* td( action_state_t* s, player_t* t ) const
  {
    return p( s )->get_target_data( t );
  }

  const evoker_td_t* find_td( action_state_t* s, const player_t* t ) const
  {
    return p( s )->find_target_data( t );
  }
};

// Template for base evoker action code.
template <class Base>
struct evoker_action_t : public parse_action_effects_t<Base>
{
private:
  using ab = parse_action_effects_t<Base>;

public:
  spell_color_e spell_color;
  unsigned proc_spell_type;
  bool move_during_hover;

  evoker_action_t( std::string_view name, evoker_t* player, const spell_data_t* spell = spell_data_t::nil() )
    : ab( name, player, spell ),
      spell_color( SPELL_COLOR_NONE ),
      proc_spell_type( proc_spell_type_e::NONE ),
      move_during_hover( false )
  {
    // TODO: find out if there is a better data source for the spell color
    if ( ab::data().ok() )
    {
      const auto& desc = player->dbc->spell_text( ab::data().id() ).rank();
      if ( desc )
      {
        if ( util::str_compare_ci( desc, "Black" ) )
          spell_color = SPELL_BLACK;
        else if ( util::str_compare_ci( desc, "Blue" ) )
          spell_color = SPELL_BLUE;
        else if ( util::str_compare_ci( desc, "Bronze" ) )
          spell_color = SPELL_BRONZE;
        else if ( util::str_compare_ci( desc, "Green" ) )
          spell_color = SPELL_GREEN;
        else if ( util::str_compare_ci( desc, "Red" ) )
          spell_color = SPELL_RED;
      }

      ab::can_have_one_button_penalty = true;

      move_during_hover =
          player->find_spelleffect( player->find_class_spell( "Hover" ), A_CAST_WHILE_MOVING_WHITELIST, 0, &ab::data() )
              ->ok();

      apply_buff_effects();
      apply_debuffs_effects();
    }
  }

  evoker_t* p()
  {
    return static_cast<evoker_t*>( ab::player );
  }

  const evoker_t* p() const
  {
    return static_cast<evoker_t*>( ab::player );
  }

  void execute() override
  {
    ab::execute();

    // Precombat Hacks Beware
    if ( ab::is_precombat && p()->precombat_travel > 0_s && ab::gcd() > timespan_t::zero() )
    {
      // Start GCD
      ab::start_gcd();
      // Set this as the last Executing Action
      ab::player->last_foreground_action = this;
      // Work out what is longer, execute time or GCD, then subtract off travel time of precast missile spells.
      auto gcd_ready = std::max( 0_s, std::max( ab::player->gcd_ready, ab::execute_time() ) - p()->precombat_travel );
      // Set GCD ready to this, which is when the sim will wake for first action
      ab::player->gcd_ready = gcd_ready;
      // Add time spent to stats, because it cost this much time
      ab::stats->iteration_total_execute_time += gcd_ready;
    }
  }

  evoker_td_t* td( player_t* t ) const
  {
    return p()->get_target_data( t );
  }

  const evoker_td_t* find_td( const player_t* t ) const
  {
    return p()->find_target_data( t );
  }

  bool usable_moving() const override
  {
    return move_during_hover && p()->buff.hover->check();
  }

  // Syntax: parse_effects( data[, spells|condition|ignore_mask|flags|spells][,...] )
  //   (buff_t*) or
  //   (const spell_data_t*)   data: Buff or spell to be checked for to see if effect applies. If buff is used, effect
  //                                 will require the buff to be active. If spell is used, effect will always apply
  //                                 unless an optional condition function is provided.
  //
  // The following optional arguments can be used in any order:
  //   (const spell_data_t*) spells: List of spells with redirect effects that modify the effects on the buff
  //   (bool F())         condition: Function that takes no arguments and returns true if the effect should apply
  //   (unsigned)       ignore_mask: Bitmask to skip effect# n corresponding to the n'th bit
  //   (parse_flag_e)         flags: Various flags to control how the value is calculated when the action executes
  //                    USE_DEFAULT: Use the buff's default value instead of spell effect data value
  //                    USE_CURRENT: Use the buff's current value instead of spell effect data value
  //                  IGNORE_STACKS: Ignore stacks of the buff and don't multiply the value
  //
  // Example 1: Parse buff1, ignore effects #1 #3 #5, modify by talent1, modify by tier1:
  //   parse_effects( buff1, 0b10101U, talent1, tier1 );
  //
  // Example 2: Parse buff2, don't multiply by stacks, use the default value set on the buff instead of effect value:
  //   parse_effects( buff2, false, USE_DEFAULT );
  //
  // Example 3: Parse spell1, modify by talent1, only apply if my_player_t::check1() returns true:
  //   parse_effects( spell1, talent1, &my_player_t::check1 );
  //
  // Example 4: Parse buff3, only apply if my_player_t::check2() and my_player_t::check3() returns true:
  //   parse_effects( buff3, [ this ] { return p()->check2() && p()->check3(); } );
  void apply_buff_effects()
  {
    auto af_mask = effect_mask_t( true ).disable( 2 );
    parse_effects( p()->buff.ancient_flame, af_mask );
    parse_effects( p()->buff.burnout );
    parse_effects( p()->buff.essence_burst );
    parse_effects( p()->buff.tip_the_scales );

    if ( p()->talent.imminent_destruction.enabled() )
    {
      parse_effects( p()->buff.imminent_destruction, IGNORE_STACKS );
    }

    parse_effects( p()->buff.emerald_trance_stacking );
    parse_effects( p()->buff.emerald_trance );

    if ( p()->specialization() == EVOKER_AUGMENTATION )
    {
      parse_effects( p()->buff.ebon_might_self_buff );
    }

    if ( p()->talent.chronowarden.temporal_burst.enabled() )
    {
      auto chrono_mask = effect_mask_t( true );
      if ( !p()->sets->has_set_bonus( HERO_CHRONOWARDEN, TWW3, B4 ) )
        chrono_mask.disable( 15 );

      parse_effects( p()->buff.temporal_burst, chrono_mask );
    }

    if ( p()->talent.scalecommander.unrelenting_siege.enabled() )
    {
      parse_effects( p()->buff.unrelenting_siege );
    }

    if ( p()->sets->has_set_bonus( EVOKER_AUGMENTATION, TWW1, B2 ) )
    {
      parse_effects( p()->buff.volcanic_upsurge, IGNORE_STACKS );
    }

    if ( p()->sets->has_set_bonus( HERO_FLAMESHAPER, TWW3, B2 ) )
    {
      parse_effects( p()->buff.inner_flame, IGNORE_STACKS );
    }

    if ( p()->talent.azure_sweep.enabled() )
    {
      parse_effects( p()->buff.azure_sweep, CONSUME_BUFF );
    }

    if ( p()->talent.rising_fury_2.enabled() )
    {
      parse_effects( p()->buff.rising_fury, effect_mask_t( false ).enable( 2, 3 ),
                     p()->talent.rising_fury_2->effectN( 1 ).percent(),
                     [ this ] { return p()->buff.rising_fury->at_max_stacks(); } );

      if ( p()->talent.rising_fury_3.enabled() )
      {
        parse_effects( p()->buff.risen_fury, effect_mask_t( false ).enable( 2, 3 ),
                       p()->talent.rising_fury_2->effectN( 1 ).percent(),
                       [ this ] { return p()->buff.risen_fury->at_max_stacks(); } );
      }
    }

    if ( p()->talent.duplicate3.enabled() )
    {
      parse_effects( p()->buff.duplicate, IGNORE_STACKS );
    }
  }

  // Syntax: parse_target_effects( func, debuff[, spells|ignore_mask][,...] )
  //   (int F(TD*))            func: Function taking the target_data as argument and returning an integer mutiplier
  //   (const spell_data_t*) debuff: Spell data of the debuff
  //
  // The following optional arguments can be used in any order:
  //   (const spell_data_t*) spells: List of spells with redirect effects that modify the effects on the debuff
  //   (unsigned)       ignore_mask: Bitmask to skip effect# n corresponding to the n'th bit
  void apply_debuffs_effects()
  {
    if ( p()->talent.scorching_embers.enabled() || p()->talent.molten_embers.enabled() )
    {
      parse_target_effects( d_fn( &evoker_td_t::dots_t::fire_breath ), p()->spec.fire_breath_damage );
    }

    if ( p()->talent.scalecommander.melt_armor.enabled() )
    {
      parse_target_effects( d_fn( &evoker_td_t::debuffs_t::melt_armor ), p()->talent.scalecommander.melt_armor_debuff );
    }
  }

  template <typename... Ts>
  void parse_effects( Ts&&... args )
  {
    ab::parse_effects( std::forward<Ts>( args )... );
  }
  template <typename... Ts>
  void parse_target_effects( Ts&&... args )
  {
    ab::parse_target_effects( std::forward<Ts>( args )... );
  }

  template <typename... Ts>
  void parse_cd_effects( std::vector<cooldown_t*>& v, buff_t* buff, Ts&&... mods )
  {
    size_t old = ab::recharge_rate_effects.size();

    parse_effects( buff, std::forward<Ts>( mods )... );

    if ( ab::recharge_rate_effects.size() > old )
    {
      v.push_back( ab::cooldown );
      v.push_back( ab::internal_cooldown );
    }
  }

  double cost_flat_modifier() const override
  {
    if ( ab::data().powers().size() > 1 && ab::current_resource() != ab::data().powers()[ 0 ].resource() )
      return Base::cost_flat_modifier();

    return ab::cost_flat_modifier();
  }

  double cost_pct_multiplier() const override
  {
    if ( ab::data().powers().size() > 1 && ab::current_resource() != ab::data().powers()[ 0 ].resource() )
      return Base::cost_pct_multiplier();

    return ab::cost_pct_multiplier();
  }

  double composite_target_multiplier( player_t* t ) const override
  {
    auto mul = ab::composite_target_multiplier( t );

    return mul;
  }

  void init() override
  {
    ab::init();

    if ( p()->specialization() == EVOKER_AUGMENTATION && p()->talent.time_skip.ok() )
    {
      auto time_skip = static_cast<buffs::time_skip_t*>( p()->buff.time_skip.get() );
      if ( p()->find_spelleffect( &time_skip->data(), A_MAX, 0, &ab::data() )->ok() )
      {
        if ( range::find( time_skip->affected_actions, this ) == time_skip->affected_actions.end() )
        {
          time_skip->affected_actions.push_back( this );
        }
      }
    }
  }

  double tick_damage_over_time( timespan_t duration, const dot_t* dot ) const
  {
    if ( !dot->is_ticking() )
    {
      return 0.0;
    }
    action_state_t* state = dot->current_action->get_state( dot->state );
    dot->current_action->calculate_tick_amount( state, 1.0 );
    double tick_base_damage  = state->result_raw;
    timespan_t dot_tick_time = dot->current_action->tick_time( state );
    // We don't care how much is remaining on the target, this will always deal
    // Xs worth of DoT ticks even if the amount is currently less
    double ticks_left   = duration / dot_tick_time;
    double total_damage = ticks_left * tick_base_damage;
    // Factor out Target TA multiplier since we will add that back with consume flame
    total_damage /= state->target_ta_multiplier;
    action_state_t::release( state );
    return total_damage;
  }

  void handle_consume_flame( dot_t* dot, timespan_t duration, double multiplier )
  {
    if ( !p()->talent.flameshaper.consume_flame.ok() || !p()->background_actions.consume_flame )
      return;

    if ( dot && dot->is_ticking() )
    {
      auto dot_damage = tick_damage_over_time( duration, dot ) * multiplier;
      if ( dot_damage > 0 )
      {
        p()->background_actions.consume_flame->execute_on_target( dot->state->target, dot_damage );
        ab::sim->print_debug( "Consume Flame consumed {} seconds, dealing {}", duration, dot_damage );
        dot->adjust_duration( -duration );
      }
    }
  }
};

// Essence base template
template <class BASE>
struct essence_base_t : public BASE
{
  double hoarded_pct;
  double titanic_mul;
  double obsidian_shards_mul;
  double enkindle_mul;
  timespan_t master_of_destiny_duration;
  timespan_t time_convergence_extension;
  timespan_t extended_battle_duration;

  essence_base_t( std::string_view n, evoker_t* p, const spell_data_t* s, std::string_view o = {} )
    : BASE( n, p, s, o ),
      hoarded_pct( p->talent.hoarded_power->effectN( 1 ).percent() ),
      titanic_mul( p->talent.titanic_wrath->effectN( 1 ).percent() ),
      obsidian_shards_mul( p->sets->set( EVOKER_DEVASTATION, DF2, B2 )->effectN( 1 ).percent() ),
      enkindle_mul( p->talent.flameshaper.enkindle->effectN( 1 ).percent() ),
      master_of_destiny_duration(
          timespan_t::from_seconds( p->talent.chronowarden.master_of_destiny->effectN( 1 ).base_value() ) ),
      time_convergence_extension(
          timespan_t::from_seconds( p->talent.chronowarden.time_convergence->effectN( 2 ).base_value() ) ),
      extended_battle_duration(
          timespan_t::from_seconds( p->talent.scalecommander.extended_battle->effectN( 1 ).base_value() ) )
  {
  }

  void consume_resource() override
  {
    BASE::consume_resource();

    if ( !BASE::base_cost() || BASE::proc || BASE::current_resource() != RESOURCE_ESSENCE )
      return;

    if ( BASE::p()->buff.essence_burst->up() )
    {
      if ( BASE::p()->sets->has_set_bonus( HERO_FLAMESHAPER, TWW3, B4 ) && BASE::execute_state )
      {
        for ( int i = 0; i < BASE::p()->buff.inner_flame->check(); i++ )
          BASE::p()->action.essence_bomb->execute_on_target( BASE::execute_state->target );
      }
      if ( BASE::p()->talent.flameshaper.twin_flame.ok() && BASE::execute_state )
      {
        BASE::p()->action.twin_flame->execute_on_target( BASE::execute_state->target );
      }
      if ( BASE::p()->talent.momentum_shift.ok() )
      {
        BASE::p()->buff.momentum_shift->trigger();
      }
      BASE::p()->buff.essence_burst->decrement();
      if ( BASE::rng().roll( hoarded_pct ) )
      {
        BASE::p()->buff.essence_burst->trigger();
        BASE::p()->proc.hoarded_power->occur();
      }
    }
    else
    {
      if ( BASE::p()->buff.imminent_destruction->up() )
      {
        BASE::p()->buff.imminent_destruction->decrement();
      }
    }
  }

  void execute() override
  {
    BASE::execute();

    if ( !BASE::background && BASE::p()->talent.chronowarden.time_convergence.ok() )
    {
      if ( BASE::p()->buff.time_convergence_intellect->check() )
      {
        BASE::p()->buff.time_convergence_intellect->extend_duration( time_convergence_extension );
      }
    }

    if ( !BASE::background && BASE::p()->talent.scalecommander.extended_battle.ok() &&
         BASE::base_costs[ RESOURCE_ESSENCE ] > 0 )
    {
      for ( auto p_ : BASE::sim->target_non_sleeping_list )
      {
        auto td = BASE::p()->get_target_data( p_ );
        if ( td->debuffs.bombardments->check() )
        {
          td->debuffs.bombardments->extend_duration( extended_battle_duration );
        }
      }
    }
  }
};

struct evoker_augment_t : public evoker_action_t<augment_t>
{
private:
  using ab = evoker_action_t<augment_t>;

public:
  evoker_augment_t( std::string_view name, evoker_t* player, const spell_data_t* spell = spell_data_t::nil(),
                    std::string_view options_str = {}, bool auto_parse_options = true )
    : ab( name, player, spell )
  {
    if ( auto_parse_options )
      parse_options( options_str );
  }
};

// Empowered spell base templates
struct empower_data_t
{
  empower_e empower;

  friend void sc_format_to( const empower_data_t& data, fmt::format_context::iterator out )
  {
    fmt::format_to( out, "empower_level={}", static_cast<int>( data.empower ) );
  }
};

template <class BASE>
struct empowered_base_t : public BASE
{
protected:
  using state_t = evoker_action_state_t<empower_data_t>;

public:
  empower_e max_empower;

  empowered_base_t( std::string_view name, evoker_t* p, const spell_data_t* spell, std::string_view options_str = {} )
    : BASE( name, p, spell, options_str ),
      max_empower( p->talent.font_of_magic.ok() ? empower_e::EMPOWER_4 : empower_e::EMPOWER_3 )
  {
    BASE::can_have_one_button_penalty = false;
  }

  action_state_t* new_state() override
  {
    return new state_t( this, BASE::target );
  }

  state_t* cast_state( action_state_t* s )
  {
    return static_cast<state_t*>( s );
  }

  const state_t* cast_state( const action_state_t* s ) const
  {
    return static_cast<const state_t*>( s );
  }
};

template <class BASE>
struct empowered_release_t : public empowered_base_t<BASE>
{
  struct shifting_sands_t : public evoker_augment_t
  {
    shifting_sands_t( evoker_t* p ) : evoker_augment_t( "shifting_sands", p, p->find_spell( 413984 ) )
    {
      background   = true;
      dot_duration = base_tick_time = 0_ms;

      if ( aoe == 0 )
        aoe = 1;
    }

    void init() override
    {
      option.target_if_str = p()->option.shifting_sands_target_if_str;

      evoker_augment_t::init();
    }

    void execute() override
    {
      target_cache.is_valid = false;
      select_target();

      evoker_augment_t::execute();
    }

    void impact( action_state_t* s ) override
    {
      evoker_augment_t::impact( s );

      auto buff_size = p()->cache.mastery_value();

      p()->get_target_data( s->target )->buffs.shifting_sands->trigger( 1, buff_size );
    }

    size_t available_targets( std::vector<player_t*>& target_list ) const override
    {
      target_list.clear();

      target_list.push_back( target );

      for ( const auto& t : sim->player_no_pet_list )
      {
        if ( t->is_sleeping() )
          continue;

        if ( t == target )
          continue;

        target_list.push_back( t );
      }

      if ( as<int>( target_list.size() ) <= n_targets() )
        return target_list.size();

      auto shifting_point = std::partition( target_list.begin(), target_list.end(), [ & ]( player_t* t ) {
        return std::none_of( p()->allied_augmentations.begin(), p()->allied_augmentations.end(),
                             [ t ]( evoker_t* e ) { return e->get_target_data( t )->buffs.shifting_sands->up(); } ) &&
               !p()->get_target_data( t )->buffs.shifting_sands->up();
      } );

      if ( shifting_point > target_list.begin() )
      {
        if ( p()->option.sands_shuffle_list )
          rng().shuffle( target_list.begin(), shifting_point );

        std::partition( target_list.begin(), shifting_point, [ & ]( player_t* t ) {
          return t->primary_role() != ROLE_HYBRID && t->primary_role() != ROLE_HEAL && t->primary_role() != ROLE_TANK &&
                 t != player;
        } );
      }

      if ( shifting_point < target_list.end() )
      {
        if ( p()->option.sands_shuffle_list )
          rng().shuffle( shifting_point, target_list.end() );

        std::partition( shifting_point, target_list.end(), [ & ]( player_t* t ) {
          return t->primary_role() != ROLE_HYBRID && t->primary_role() != ROLE_HEAL && t->primary_role() != ROLE_TANK &&
                 t != player;
        } );
      }

      return target_list.size();
    }

    bool target_ready( player_t* candidate_target ) override
    {
      auto ally_shifting = ( std::any_of(
          p()->allied_augmentations.begin(), p()->allied_augmentations.end(), [ candidate_target ]( evoker_t* e ) {
            return e->get_target_data( candidate_target )->buffs.shifting_sands->check();
          } ) );

      if ( ally_shifting || p()->get_target_data( candidate_target )->buffs.shifting_sands->check() )
      {
        return false;
      }

      return evoker_augment_t::target_ready( candidate_target );
    }

    // No point caching using basic cache, cache would be ruined by every cast.
    // TODO: If noticable lag caused by this target list implement custom cache.
    std::vector<player_t*>& target_list() const override
    {
      available_targets( target_cache.list );

      return target_cache.list;
    }
  };

  using ab = empowered_base_t<BASE>;

  timespan_t extend_tier29_4pc;
  timespan_t extend_ebon;
  action_t* sands;

  empowered_release_t( std::string_view name, evoker_t* p, const spell_data_t* spell )
    : ab( name, p, spell ),
      extend_ebon( p->talent.ebon_might.ok() ? p->talent.sands_of_time->effectN( 2 ).time_value() : 0_s ),
      sands( p->specialization() == EVOKER_AUGMENTATION ? p->get_secondary_action<shifting_sands_t>( "shifting_sands" )
                                                        : nullptr )
  {
    ab::dual = true;

    // TODO: Continue to check it uses this spell to trigger GCD, as of 28/10/2022 it does. It can still be bypassed via
    // spell queue. Potentally add a better way to model this?
    const spell_data_t* gcd_spell = p->find_spell( 359115 );
    if ( gcd_spell )
      ab::trigger_gcd = gcd_spell->gcd();
    ab::gcd_type = gcd_haste_type::NONE;

    extend_tier29_4pc =
        timespan_t::from_seconds( p->sets->set( EVOKER_DEVASTATION, DF1, B4 )->effectN( 1 ).base_value() );
  }

  empower_e empower_level( const action_state_t* s ) const
  {
    return ab::cast_state( s )->empower;
  }

  int empower_value( const action_state_t* s ) const
  {
    return static_cast<int>( ab::cast_state( s )->empower );
  }

  void execute() override
  {
    ab::p()->was_empowering = false;

    ab::execute();

    ab::p()->extend_ebon( extend_ebon );

    if ( sands )
      sands->execute();
  }
};

template <class BASE>
struct empowered_charge_t : public empowered_base_t<BASE>
{
  using ab = empowered_base_t<BASE>;

  action_t* release_spell;
  stats_t* dummy_stat;  // used to hack channel tick time into execute time
  stats_t* orig_stat;
  int empower_to;
  timespan_t base_empower_duration;
  timespan_t lag;
  timespan_t instability_matrix_max_cdr;

  void setup_empower_stats( int empower_level )
  {
    assert( empower_level > 0 );
    assert( empower_level <= 5 );
    setup_empower_stats( static_cast<empower_e>( empower_level ) );
  }

  void setup_empower_stats( empower_e empower_level )
  {
    empower_to = empower_level;
    if ( static_cast<empower_e>( empower_to ) == EMPOWER_MAX )
    {
      base_empower_duration = max_hold_time();
    }
    else
    {
      empower_to            = std::min( static_cast<int>( ab::max_empower ), empower_to );
      base_empower_duration = base_time_to_empower( static_cast<empower_e>( empower_to ) );
    }

    // apply parsed modifiers
    ab::dot_duration      = ab::player->get_passive_value( ab::data(), "duration" );
    ab::dot_duration.base = base_empower_duration;
    ab::base_tick_time    = ab::dot_duration;
  }

  empowered_charge_t( std::string_view name, evoker_t* p, const spell_data_t* spell, std::string_view options_str )
    : ab( name, p, p->find_spell_override( spell, p->talent.font_of_magic ) ),
      release_spell( nullptr ),
      dummy_stat( p->get_stats( "dummy_stat" ) ),
      orig_stat( ab::stats ),
      empower_to( EMPOWER_MAX ),
      base_empower_duration( 0_ms ),
      lag( 0_ms ),
      instability_matrix_max_cdr(
          timespan_t::from_seconds( p->talent.chronowarden.instability_matrix->effectN( 1 ).base_value() ) )
  {
    ab::channeled = true;

    // TODO: convert to full empower expression support
    ab::add_option( opt_int( "empower_to", empower_to, EMPOWER_1, EMPOWER_MAX ) );

    ab::parse_options( options_str );

    setup_empower_stats( empower_to );

    ab::gcd_type = gcd_haste_type::NONE;
    if ( ab::trigger_gcd > timespan_t::zero() )
      ab::min_gcd = ab::trigger_gcd;
  }

  template <typename T>
  void create_release_spell( std::string_view n )
  {
    static_assert( std::is_base_of_v<empowered_release_t<BASE>, T>,
                   "Empowered release spell must be dervied from empowered_release_spell_t." );

    release_spell = ab::p()->template get_secondary_action<T>( n );

    ab::add_child( release_spell );

    release_spell->stats      = ab::stats;
    release_spell->background = false;
  }

  timespan_t base_time_to_empower( empower_e emp ) const
  {
    // TODO: confirm these values and determine if they're set values or adjust based on a formula
    // Currently all empowered spells are 2.5s base and 3.25s with empower 4
    switch ( emp )
    {
      case empower_e::EMPOWER_1:
        return 1000_ms;
      case empower_e::EMPOWER_2:
        return 1750_ms;
      case empower_e::EMPOWER_3:
        return 2500_ms;
      case empower_e::EMPOWER_4:
        return 3250_ms;
      default:
        break;
    }

    return 0_ms;
  }

  timespan_t max_hold_time() const
  {
    // TODO: confirm if this is affected by duration mods/haste
    return base_time_to_empower( ab::max_empower ) + 2_s;
  }

  timespan_t tick_time( const action_state_t* s ) const override
  {
    return composite_dot_duration( s );
  }

  timespan_t composite_dot_duration( const action_state_t* s ) const override
  {
    auto dur = ab::composite_dot_duration( s );

    // hack so we always have a non-zero duration in order to trigger last_tick()
    if ( dur == 0_ms )
      return 1_ms;

    return dur + lag;
  }

  timespan_t composite_time_to_empower( const action_state_t* s, empower_e emp ) const
  {
    auto base = base_time_to_empower( emp );
    auto mult = composite_dot_duration( s ) / base_empower_duration;

    return base * mult;
  }

  empower_e empower_level( const dot_t* d ) const
  {
    auto emp = empower_e::EMPOWER_NONE;

    if ( !d->is_ticking() )
      return emp;

    auto s       = d->state;
    auto elapsed = tick_time( s ) - d->time_to_next_full_tick();

    if ( elapsed >= composite_time_to_empower( s, empower_e::EMPOWER_4 ) )
      emp = empower_e::EMPOWER_4;
    else if ( elapsed >= composite_time_to_empower( s, empower_e::EMPOWER_3 ) )
      emp = empower_e::EMPOWER_3;
    else if ( elapsed >= composite_time_to_empower( s, empower_e::EMPOWER_2 ) )
      emp = empower_e::EMPOWER_2;
    else if ( elapsed >= composite_time_to_empower( s, empower_e::EMPOWER_1 ) )
      emp = empower_e::EMPOWER_1;

    return std::min( ab::max_empower, emp );
  }

  void init() override
  {
    ab::init();
    assert( release_spell && "Empowered charge spell must have a release spell." );
  }

  void execute() override
  {
    // pre-determine lag here per every execute
    lag = ab::rng().gauss( ab::sim->channel_lag );

    ab::execute();
  }

  void tick( dot_t* d ) override
  {
    // For proper DPET analysis, we need to treat charge spells as non-channel, since channelled spells sum up tick
    // times to get the execute time, but this does not work for fire breath which also has a dot component. Instead we
    // hijack the stat obj during action_t:tick() causing the channel's tick to be recorded onto a throwaway stat obj.
    // We then record the corresponding tick time as execute time onto the original real stat obj. See further notes in
    // evoker_t::analyze().
    ab::stats = dummy_stat;
    ab::tick( d );
    ab::stats = orig_stat;

    ab::stats->iteration_total_execute_time += d->time_to_tick();
  }

  virtual player_t* get_release_target( dot_t* )
  {
    return ab::target;
  }

  void last_tick( dot_t* d ) override
  {
    ab::last_tick( d );

    // being stunned ends the empower without triggering the release spell
    if ( ab::p()->buffs.stunned->check() )
    {
      ab::p()->was_empowering = false;
      return;
    }

    auto release_target = get_release_target( d );

    if ( empower_level( d ) == empower_e::EMPOWER_NONE || !release_target )
    {
      ab::p()->was_empowering = false;
      return;
    }

    if ( ab::p()->naszuro )
    {
      if ( ab::p()->get_target_data( ab::p() )->buffs.unbound_surge->check() &&
           ab::p()->option.naszuro_accurate_behaviour )
      {
        ab::p()->bounce_naszuro( ab::p() );
      }
      else
      {
        ab::p()->get_target_data( ab::p() )->buffs.unbound_surge->trigger();
      }
    }

    auto emp_state        = release_spell->get_state();
    emp_state->target     = release_target;
    release_spell->target = release_target;
    release_spell->snapshot_state( emp_state, release_spell->amount_type( emp_state ) );

    if ( ab::p()->buff.tip_the_scales->up() )
    {
      ab::p()->buff.tip_the_scales->expire();
      ab::cast_state( emp_state )->empower = ab::max_empower;
    }
    else
      ab::cast_state( emp_state )->empower = empower_level( d );

    release_spell->schedule_execute( emp_state );

    // hack to prevent dot_t::last_tick() from schedule_ready()'ing the player
    d->current_action = release_spell;
    // hack to prevent channel lag being added when player is schedule_ready()'d after the release spell execution
    ab::p()->last_foreground_action = release_spell;
    // Start GCD - All Empowerw have a GCD of 0.5s after completion.
    ab::start_gcd();

    if ( ab::p()->talent.chronowarden.instability_matrix.enabled() )
    {
      ab::cooldown->adjust( -ab::rng().range( 0_s, instability_matrix_max_cdr ) );
    }
  }
};

namespace pets
{
struct dracthyr_commando_t : evoker_pet_t
{
  action_t* commando_pyre;
  action_t* commando_disintegrate;
  buff_t* flying_buff;

  dracthyr_commando_t( evoker_t* player ) : evoker_pet_t( player, "dracthyr_commando", true, false, true )
  {
    owner_coeff.sp_from_sp = 1.0;
  }

  struct pyre_t : public pet_spell_t<dracthyr_commando_t>
  {
    pyre_t( dracthyr_commando_t* p )
      : pet_spell_t( p, "pyre", p->evoker()->talent.scalecommander.command_squadron_pyre_spell )
    {
      background = true;
      aoe        = -1;
    }
  };

  void arise() override
  {
    evoker_pet_t::arise();
    start_flying();
  }

  void create_buffs() override
  {
    evoker_pet_t::create_buffs();

    flying_buff = make_buff( this, "deep_breath", evoker()->talent.scalecommander.commando_deep_breath_buff )
                      ->set_tick_callback( [ this ]( buff_t* b, int, timespan_t ) {
                        if ( b->current_tick <= 3 )
                          commando_pyre->execute();
                      } )
                      ->set_tick_on_application( true )
                      ->set_cooldown( 0_s );
  }

  void start_flying()
  {
    flying_buff->trigger();
  }

  void finish_flying()
  {
    demise();
  }

  void create_actions() override
  {
    evoker_pet_t::create_actions();
    commando_pyre = new pyre_t( this );
  }

  void schedule_ready( timespan_t /* delta_time */, bool /* waiting */ ) override
  {
    // Goons do not do anything on their own.
    return;
  }
};

struct duplicate_t : evoker_pet_t
{
  action_t* eruption;
  action_t* fire_breath;
  action_t* upheaval;
  action_t* custom_execution_pointer;
  event_t* custom_readying_event;

  duplicate_t( evoker_t* player )
    : evoker_pet_t( player, "duplicate", true, false, true ),
      custom_execution_pointer( nullptr ),
      custom_readying_event( nullptr )
  {
    owner_coeff.sp_from_sp = 1.0;
    ready_type             = READY_TRIGGER;
  }

  struct duplicate_ready_event_t : public event_t
  {
    duplicate_t* _player;
    duplicate_ready_event_t( duplicate_t& p, timespan_t delta_time ) : event_t( p, delta_time ), _player( &p )
    {
      if ( sim().debug )
        sim().out_debug.printf( "New Player-Duplicate-Ready Event: %s", p.name() );
    }
    const char* name() const override
    {
      return "Player-Duplicate-Ready";
    }

    duplicate_t* p()
    {
      return player();
    }

    const duplicate_t* p() const
    {
      return player();
    }

    duplicate_t* player()
    {
      return _player;
    }
    const duplicate_t* player() const
    {
      return _player;
    }

    void execute() override
    {
      p()->custom_readying_event = nullptr;
      p()->current_execute_type  = execute_type::FOREGROUND;
      p()->executing             = nullptr;
      p()->channeling            = nullptr;
      p()->gcd_ready             = timespan_t::min();

      // There are certain chains of events where an off-gcd ability can be queued such that the queue
      // time for the action exceeds Player-Ready event (essentially end of GCD). In this case, the
      // simple solution is to just cancel the queue execute and let the actor select an action from
      // the action list as normal.
      if ( p()->queueing )
      {
        event_t::cancel( p()->queueing->queue_event );
        p()->queueing = nullptr;
      }

      p()->schedule_ready( p()->available(), true );
    }
  };

  struct eruption_t : public pet_spell_t<duplicate_t>
  {
    eruption_t( duplicate_t* p ) : pet_spell_t( p, "eruption", p->evoker()->talent.duplicate_eruption_spell )
    {
      aoe              = -1;
      split_aoe_damage = true;

      // GCD is unhasted and lasts for the entire cast duration. Last Tested Feb 01 26
      gcd_type = gcd_haste_type::NONE;
      trigger_gcd = base_execute_time;
    }

    double composite_da_multiplier( const action_state_t* s ) const override
    {
      double da = base_t::composite_da_multiplier( s );

      if ( evoker()->talent.ricocheting_pyroclast.ok() )
      {
        da *= 1.0 + std::min( static_cast<double>( s->n_targets ),
                            evoker()->talent.ricocheting_pyroclast->effectN( 2 ).base_value() ) *
                      evoker()->talent.ricocheting_pyroclast->effectN( 1 ).percent();
      }
      return da;
    }

    void execute() override
    {
      pet_spell_t::execute();
      p()->schedule_ready( timespan_t::zero(), false );
    }
  };

  struct fire_breath_t : public empowered_pet_charge_t<duplicate_t>
  {
    struct fire_breath_damage_t : public empowered_pet_release_t<duplicate_t>
    {
      timespan_t dot_dur_per_emp;
      action_t* chrono_flames;
      int max_afterimage_targets;

      fire_breath_damage_t( duplicate_t* p, std::string_view name )
        : empowered_pet_release_t( p, name, p->evoker()->spec.fire_breath_damage ),
          dot_dur_per_emp( 6_s )
      {
        aoe                 = -1;  // TODO: actually a cone so we need to model it if possible
        reduced_aoe_targets = 5.0;

        //dot_duration = 20_s;  // base * 10? or hardcoded to 20s?
        //dot_duration += timespan_t::from_seconds( p->talent.blast_furnace->effectN( 1 ).base_value() );
        dot_duration = 24_s;  // May not scale with blast furnace.
      }

      timespan_t reduction_from_empower( const action_state_t* s ) const
      {
        return std::max( 0, empower_value( s ) - 1 ) * dot_dur_per_emp;
      }

      timespan_t composite_dot_duration( const action_state_t* s ) const override
      {
        return base_t::composite_dot_duration( s ) - reduction_from_empower( s );
      }

      double bonus_da( const action_state_t* s ) const override
      {
        auto da          = base_t::bonus_da( s );
        auto ticks       = reduction_from_empower( s ) / tick_time( s );
        auto tick_damage = s->composite_spell_power() * spell_tick_power_coefficient( s );

        return da + ticks * tick_damage;
      }

      double calculate_tick_amount( action_state_t* s, double m ) const override
      {
        auto n = std::clamp( as<double>( s->n_targets ), reduced_aoe_targets, 20.0 );

        m *= std::sqrt( reduced_aoe_targets / n );

        return base_t::calculate_tick_amount( s, m );
      }

      void execute() override
      {
        empowered_pet_release_t::execute();
        p()->schedule_ready( timespan_t::zero(), false );
      }
    };

    fire_breath_t( duplicate_t* p )
      : empowered_pet_charge_t( p, "fire_breath", p->evoker()->talent.duplicate_fire_breath_charge_spell )
    {
      create_release_spell<fire_breath_damage_t>( "fire_breath_damage" );

      setup_empower_stats( empower_e::EMPOWER_1 );
    }

    player_t* get_release_target( dot_t* d ) override
    {
      auto t = d->state->target;

      if ( t->is_sleeping() )
      {
        t = nullptr;

        for ( auto enemy : player->sim->target_non_sleeping_list )
        {
          if ( enemy->is_sleeping() || ( enemy->debuffs.invulnerable && enemy->debuffs.invulnerable->check() ) )
            continue;

          t = enemy;
          break;
        }
      }

      return t;
    }
  };

  struct upheaval_t : public empowered_pet_charge_t<duplicate_t>
  {
    struct upheaval_damage_t : public empowered_pet_release_t<duplicate_t>
    {
      upheaval_damage_t( duplicate_t* p, std::string_view name )
        : empowered_pet_release_t( p, name, p->evoker()->talent.duplicate_upheaval_spell )
      {
        aoe = -1;
      }

      void execute() override
      {
        empowered_pet_release_t::execute();
        p()->schedule_ready( timespan_t::zero(), false );
      }
    };

    upheaval_t( duplicate_t* p ) : empowered_pet_charge_t( p, "upheaval", p->evoker()->find_spell( 396286 ) )
    {
      create_release_spell<upheaval_damage_t>( "upheaval_damage" );

      setup_empower_stats( empower_e::EMPOWER_3 );
    }
  };

  void arise() override
  {
    evoker_pet_t::arise();

    // Rough Guess
    upheaval->cooldown->start( upheaval, rng().gauss( 9_s, 3_s ) );
    fire_breath->cooldown->start( fire_breath, rng().gauss( 9_s, 3_s ) );

    reschedule_actor();

    if ( evoker()->talent.duplicate3.enabled() )
      evoker()->buff.duplicate->trigger();
  }

  void demise() override
  {
    evoker_pet_t::demise();

    if ( evoker()->talent.duplicate3.enabled() )
      evoker()->buff.duplicate->decrement();
  }

  void create_buffs() override
  {
    evoker_pet_t::create_buffs();
  }

  void reset() override
  {
    evoker_pet_t::reset();
    custom_execution_pointer = nullptr;
    custom_readying_event    = nullptr;
  }

  void create_actions() override
  {
    evoker_pet_t::create_actions();
    eruption    = new eruption_t( this );
    upheaval    = new upheaval_t( this );
    fire_breath = new fire_breath_t( this );
  }

  // Unnecessary as the GCD is unhasted, but just in case I need it later.
  void adjust_global_cooldown( gcd_haste_type ht ) override
  {
    // Don't adjust if the current gcd isnt hasted
    if ( ht == gcd_haste_type::NONE )
    {
      return;
    }

    // Don't adjust if the changed haste type isnt current GCD haste scaling type
    if ( ht != gcd_haste_type::HASTE && ht != gcd_type )
    {
      return;
    }

    // Don't adjust elapsed GCDs
    if ( ( custom_readying_event && custom_readying_event->occurs() <= sim->current_time() ) ||
         ( gcd_ready <= sim->current_time() ) )
    {
      return;
    }

    double new_haste = 0;
    switch ( ht )
    {
      case gcd_haste_type::SPELL_HASTE:
        new_haste = cache.spell_haste();
        break;
      case gcd_haste_type::ATTACK_HASTE:
        new_haste = cache.attack_haste();
        break;
      case gcd_haste_type::SPELL_CAST_SPEED:
        new_haste = cache.spell_cast_speed();
        break;
      case gcd_haste_type::AUTO_ATTACK_SPEED:
        new_haste = cache.auto_attack_speed();
        break;
      // SPEED_ANY and HASTE_ANY are nonsensical, actions have to have a correct GCD haste type so
      // they can be adjusted on state changes.
      default:
        assert( 0 && "player_t::adjust_global_cooldown called without proper haste type" );
        break;
    }

    // Haste did not change, don't do anything
    if ( new_haste == gcd_current_haste_value )
    {
      return;
    }

    double delta           = new_haste / gcd_current_haste_value;
    timespan_t remains = custom_readying_event ? custom_readying_event->remains() : ( gcd_ready - sim->current_time() );
    timespan_t new_remains = remains * delta;

    // Don't bother processing too small (less than a millisecond) granularity changes
    if ( remains == new_remains )
    {
      return;
    }

    if ( sim->debug )
    {
      sim->out_debug.printf(
          "%s adjusting GCD due to haste change: old_ready=%.3f new_ready=%.3f old_haste=%f new_haste=%f delta=%f",
          name(), ( sim->current_time() + remains ).total_seconds(),
          ( sim->current_time() + new_remains ).total_seconds(), gcd_current_haste_value, new_haste, delta );
    }

    // We need to adjust the event (GCD is already elapsing)
    if ( custom_readying_event )
    {
      // GCD speeding up, recreate the event
      if ( delta < 1 )
      {
        event_t::cancel( custom_readying_event );
        custom_readying_event = make_event<duplicate_ready_event_t>(*sim, *this, new_remains );
      }
      // GCD slowing down, just reschedule into future
      else
      {
        custom_readying_event->reschedule( new_remains );
      }
    }

    gcd_ready               = sim->current_time() + new_remains;
    gcd_current_haste_value = new_haste;
  }

  void schedule_ready( timespan_t /* delta_time */, bool /* waiting */ ) override
  {
    if ( custom_readying_event )
      return;

    if ( gcd_ready != timespan_t::min() && gcd_ready - sim->current_time() > 0_s )
    {
      custom_readying_event = make_event<duplicate_ready_event_t>( *sim, *this, gcd_ready - sim->current_time() );
      return;
    }

    reschedule_actor();
  }

  void acquire_target( retarget_source event, player_t* context ) override
  {
    if ( custom_execution_pointer && custom_execution_pointer->execute_event &&
         custom_execution_pointer->target->is_sleeping() )
    {
      event_t::cancel( custom_execution_pointer->execute_event );
      started_waiting = sim->current_time();
    }

    // TODO: This skips certain very custom targets (such as Soul Effigy), is it a problem (since those
    // usually are handled in action target cache regeneration)?
    if ( sim->debug )
    {
      sim->out_debug.printf( "%s retargeting event=%s context=%s current_target=%s", name(),
                             util::retarget_event_string( event ), context ? context->name() : "NONE",
                             target ? target->name() : "NONE" );
    }

    player_t* candidate_target    = nullptr;
    player_t* first_invuln_target = nullptr;

    // TODO: Fancier system
    for ( auto enemy : sim->target_non_sleeping_list )
    {
      if ( enemy->debuffs.invulnerable != nullptr && enemy->debuffs.invulnerable->check() )
      {
        if ( first_invuln_target == nullptr )
        {
          first_invuln_target = enemy;
        }
        continue;
      }

      if ( !enemy->is_enemy() || enemy->is_sleeping() )
        continue;

      if ( !candidate_target || enemy->max_health() > candidate_target->max_health() )
        candidate_target = enemy;

      if ( sim->fixed_time )
        break;
    }

    // Invulnerable targets are currently not in the target_non_sleeping_list, so fall back to
    // checking if the first target has the invulnerability buff up, and use that as the fallback
    auto first_target = sim->target_list.data().front();
    if ( !first_invuln_target && first_target->debuffs.invulnerable->check() )
    {
      first_invuln_target = first_target;
    }

    // Only perform target acquisition if the actor's current target would change (to the candidate
    // target).
    if ( candidate_target )
    {
      if ( sim->debug )
      {
        sim->out_debug.printf( "%s acquiring (potentially new) target, current=%s candidate=%s", name(),
                               target ? target->name() : "NONE", candidate_target ? candidate_target->name() : "NONE" );
      }

      target = candidate_target;
      range::for_each( action_list, [ event, context, candidate_target ]( action_t* action ) {
        action->acquire_target( event, context, candidate_target );
      } );
    }
    // If we really cannot find any sensible target, fall back to the first invulnerable target
    else if ( !candidate_target && first_invuln_target )
    {
      if ( sim->debug )
      {
        sim->out_debug.printf( "%s acquiring (potentially new) target, current=%s candidate=%s [invulnerable fallback]",
                               name(), target ? target->name() : "NONE",
                               first_invuln_target ? first_invuln_target->name() : "NONE" );
      }

      target = first_invuln_target;
      range::for_each( action_list, [ event, context, first_invuln_target ]( action_t* action ) {
        action->acquire_target( event, context, first_invuln_target );
      } );
    }

    if ( candidate_target || first_invuln_target )
    {
      // Finally, re-acquire targeting for all dynamic targeting actions. This needs to be done
      // separately, as their targeting is not strictly bound to player_t::target (i.e., "the players
      // target")
      range::for_each(
          dynamic_target_action_list, [ event, context, candidate_target, first_invuln_target ]( action_t* action ) {
            action->acquire_target( event, context, candidate_target ? candidate_target : first_invuln_target );
          } );
    }

    if ( !custom_execution_pointer || !custom_execution_pointer->execute_event )
      trigger_ready();
  }

  action_t* execute_action() override
  {
   if ( fire_breath->cooldown->up() )
      return fire_breath;

    if ( upheaval->cooldown->up() )
      return upheaval;

    return eruption;
  }

  void reschedule_actor()
  {
    if ( executing || ( custom_execution_pointer && custom_execution_pointer->execute_event ) || is_sleeping() ||
         buffs.stunned->check() )
      return;

    // Select Action
    custom_execution_pointer = execute_action();
    custom_execution_pointer->schedule_execute();
  }
};
};  // namespace pets

namespace heals
{
struct evoker_heal_t : public evoker_action_t<heal_t>
{
private:
  using ab = evoker_action_t<heal_t>;

public:
  double scarlet_adaptation_sp_cap;

  evoker_heal_t( std::string_view name, evoker_t* player, const spell_data_t* spell = spell_data_t::nil(),
                 std::string_view options_str = {} )
    : ab( name, player, spell ), scarlet_adaptation_sp_cap( player->spec.living_flame_damage->effectN( 1 ).sp_coeff() )
  {
    parse_options( options_str );
  }

  void assess_damage( result_amount_type rt, action_state_t* s ) override
  {
    ab::assess_damage( rt, s );

    if ( p()->talent.scarlet_adaptation.ok() )
    {
      if ( !p()->buff.scarlet_adaptation->check() )
        p()->buff.scarlet_adaptation->trigger();

      auto& stored = p()->buff.scarlet_adaptation->current_value;
      // TODO: raw_amount for used for testing
      // stored += s->result_amount * p()->talent.scarlet_adaptation->effectN( 1 ).percent();
      stored +=
          s->result_raw * p()->talent.scarlet_adaptation->effectN( 1 ).percent() * ( 1 - p()->option.scarlet_overheal );
      // TODO: confirm if this always matches living flame SP coeff
      stored = std::min( stored, p()->composite_total_spell_power( SCHOOL_MAX ) * scarlet_adaptation_sp_cap );
    }
  }

  double composite_target_multiplier( player_t* t ) const override
  {
    double tm = ab::composite_target_multiplier( t );

    if ( p()->specialization() == EVOKER_PRESERVATION && t->health_percentage() < p()->health_percentage() )
      tm *= 1.0 + p()->cache.mastery_value();

    return tm;
  }
};

using essence_heal_t = essence_base_t<evoker_heal_t>;

// Empowered Heals ==========================================================
using empowered_charge_heal_t  = empowered_charge_t<evoker_heal_t>;
using empowered_release_heal_t = empowered_release_t<evoker_heal_t>;

// Heals ====================================================================

struct panacea_t : public evoker_heal_t
{
  panacea_t( evoker_t* p, std::string_view name ) : evoker_heal_t( name, p, p->talent.panacea_spell )
  {
    harmful = false;
    dual    = true;
    target  = p;
  }
};

struct emerald_blossom_t : public essence_heal_t
{
  struct emerald_blossom_heal_t : public evoker_heal_t
  {
    emerald_blossom_heal_t( evoker_t* p, bool do_aoe = true )
      : evoker_heal_t( do_aoe ? "emerald_blossom_heal" : "emerald_blossom_virtual_heal", p,
                       p->spec.emerald_blossom_heal )
    {
      harmful = false;
      dual    = true;
      if ( do_aoe )
        aoe = as<int>( data().effectN( 2 ).base_value() );
    }
  };

  action_t *heal, *panacea, *virtual_heal;

  timespan_t extend_ebon;
  double motes_chance;

  emerald_blossom_t( evoker_t* p, std::string_view options_str )
    : essence_heal_t( "emerald_blossom", p, p->spec.emerald_blossom, options_str ),
      motes_chance( p->talent.motes_of_possibility->proc_chance() )
  {
    harmful      = false;
    heal         = p->get_secondary_action<emerald_blossom_heal_t>( "emerald_blossom_heal" );
    virtual_heal = p->get_secondary_action<emerald_blossom_heal_t>( "emerald_blossom_virtual_heal", false );
    panacea      = p->get_secondary_action<panacea_t>( "panacea_eb", "panacea_eb" );

    min_travel_time = data().duration().total_seconds();

    extend_ebon = timespan_t::from_seconds( p->talent.dream_of_spring->effectN( 2 ).base_value() );

    add_child( heal );
    add_child( panacea );
  }

  void impact( action_state_t* s ) override
  {
    essence_heal_t::impact( s );

    heal->execute_on_target( s->target );

    auto tl_size = as<int>( heal->target_list().size() );
    if ( heal->aoe > tl_size )
    {
      tl_size = heal->aoe - tl_size;
      for ( int i = 0; i < tl_size; i++ )
      {
        virtual_heal->execute_on_target( s->target );
      }
    }
  }

  void consume_resource() override
  {
    essence_heal_t::consume_resource();

    resource_e prev_cr = current_resource();

    if ( prev_cr == RESOURCE_MANA )
      return;

    resource_e cr = resource_current = RESOURCE_MANA;

    if ( base_cost() == 0 || proc )
      return;

    last_resource_cost = cost();

    player->resource_loss( cr, last_resource_cost, nullptr, this );

    sim->print_log( "{} consumes {} {} for {} ({})", *player, last_resource_cost, cr, *this,
                    player->resources.current[ cr ] );

    stats->consume_resource( cr, last_resource_cost );

    resource_current = prev_cr;
  }

  bool ready() override
  {
    if ( !essence_heal_t::ready() )
      return false;

    if ( resource_current == RESOURCE_MANA )
      return true;

    auto prev_resource = resource_current;
    resource_current   = RESOURCE_MANA;

    if ( !player->resource_available( RESOURCE_MANA, cost() ) )
    {
      if ( starved_proc )
        starved_proc->occur();

      resource_current = prev_resource;
      return false;
    }

    resource_current = prev_resource;
    return true;
  }

  void execute() override
  {
    essence_heal_t::execute();

    if ( extend_ebon > timespan_t::zero() )
      p()->extend_ebon( extend_ebon );

    if ( p()->talent.ancient_flame.ok() )
      p()->buff.ancient_flame->trigger();

    if ( p()->talent.panacea.ok() )
      panacea->execute_on_target( p() );

    if ( p()->talent.dream_of_spring.ok() && p()->talent.motes_of_possibility.ok() && rng().roll( motes_chance ) )
    {
      p()->spawn_mote_of_possibility();
    }
  }
};

struct verdant_embrace_t : public evoker_heal_t
{
  struct verdant_embrace_heal_t : public evoker_heal_t
  {
    action_t* panacea;

    verdant_embrace_heal_t( evoker_t* p )
      : evoker_heal_t( "verdant_embrace_heal", p, p->find_spell( 361195 ) ), panacea( nullptr )
    {
      harmful = false;
      dual    = true;

      panacea = p->get_secondary_action<panacea_t>( "panacea_ve", "panacea_ve" );
      add_child( panacea );
    }

    void impact( action_state_t* s ) override
    {
      evoker_heal_t::impact( s );
      if ( panacea )
        panacea->execute_on_target( s->target );
    }
  };

  verdant_embrace_t( evoker_t* p, std::string_view options_str )
    : evoker_heal_t( "verdant_embrace", p, p->talent.verdant_embrace, options_str )
  {
    harmful       = false;
    impact_action = p->get_secondary_action<verdant_embrace_heal_t>( "verdant_embrace_heal" );

    add_child( impact_action );
  }

  void execute() override
  {
    evoker_heal_t::execute();

    if ( p()->talent.ancient_flame.ok() )
      p()->buff.ancient_flame->trigger();
  }
};

}  // namespace heals

namespace spells
{
struct evoker_spell_t : public evoker_action_t<spell_t>
{
private:
  using ab = evoker_action_t<spell_t>;

public:
  bool affected_by_giantkiller = true;
  evoker_spell_t( std::string_view name, evoker_t* player, const spell_data_t* spell = spell_data_t::nil(),
                  std::string_view options_str = {} )
    : ab( name, player, spell )
  {
    parse_options( options_str );
  }

  void execute() override
  {
    ab::execute();

    if ( ( !ab::background || ( ab::not_a_proc && ab::id != 359077 ) ) && !ab::dual )
    {
      // These happen after any secondary spells are executed, so we schedule as events
      if ( spell_color == SPELL_BLUE )
        make_event( *sim, [ this ]() { p()->buff.iridescence_blue->decrement(); } );
      else if ( spell_color == SPELL_RED )
        make_event( *sim, [ this ]() { p()->buff.iridescence_red->decrement(); } );
    }
  }

  virtual void trigger_charged_blast( action_state_t* s )
  {
    if ( spell_color == SPELL_BLUE && has_amount_result() && result_is_hit( s->result ) )
      p()->buff.charged_blast->trigger();
  }

  void impact( action_state_t* s ) override
  {
    ab::impact( s );

    trigger_charged_blast( s );
  }

  void tick( dot_t* d ) override
  {
    ab::tick( d );

    trigger_charged_blast( d->state );
  }

  virtual bool use_full_mastery() const
  {
    return p()->talent.tyranny.ok() && p()->buff.dragonrage->check();
  }

  double composite_target_multiplier( player_t* t ) const override
  {
    double tm = ab::composite_target_multiplier( t );

    // Preliminary testing shows this is linear with target hp %.
    // TODO: confirm this applies only to all evoker offensive spells
    if ( p()->specialization() == EVOKER_DEVASTATION && affected_by_giantkiller )
    {
      if ( use_full_mastery() )
        tm *= 1.0 + p()->cache.mastery_value();
      else
        tm *= 1.0 + p()->cache.mastery_value() * std::max( 0.3, t->health_percentage() / 100 );
    }

    return tm;
  }
};

using essence_spell_t = essence_base_t<evoker_spell_t>;

// Empowered Spells =========================================================
struct empowered_release_spell_t : public empowered_release_t<evoker_spell_t>
{
  using base_t = empowered_release_spell_t;

  timespan_t animosity_extend;
  double animosity_stack_mul;

  empowered_release_spell_t( std::string_view n, evoker_t* p, const spell_data_t* s ) : empowered_release_t( n, p, s )
  {
    animosity_extend    = p->talent.animosity->effectN( 1 ).time_value();
    animosity_stack_mul = 1 - p->talent.animosity->effectN( 2 ).percent();
  }

  double composite_persistent_multiplier( const action_state_t* s ) const override
  {
    auto m = empowered_release_t::composite_persistent_multiplier( s );

    if ( !background && p()->sets->has_set_bonus( EVOKER_DEVASTATION, TWW2, B4 ) )
    {
      m *= 1.0 + p()->buff.jackpot->check_stack_value();
    }

    return m;
  }

  void execute() override
  {
    empowered_release_t::execute();

    if ( background )
      return;
        
    if ( p()->sets->has_set_bonus( EVOKER_DEVASTATION, TWW2, B4 ) )
    {
      p()->buff.jackpot->expire();
    }

    p()->buff.limitless_potential->trigger();

    if ( p()->talent.animosity.ok() && p()->buff.dragonrage->check() )
    {
      p()->buff.dragonrage->extend_duration( animosity_extend * p()->buff.dragonrage->check_value() );
      p()->buff.dragonrage->current_value *= animosity_stack_mul;
    }

    p()->buff.power_swell->trigger();

    if ( spell_color == SPELL_BLUE )
      p()->buff.iridescence_blue->trigger();
    else if ( spell_color == SPELL_RED )
      p()->buff.iridescence_red->trigger();

    if ( rng().roll( p()->sets->set( EVOKER_DEVASTATION, DF1, B4 )->effectN( 2 ).percent() ) )
    {
      if ( p()->buffs.bloodlust->check() )
        p()->buffs.bloodlust->extend_duration( extend_tier29_4pc );
      else if ( p()->buff.fury_of_the_aspects->check() )
        p()->buff.fury_of_the_aspects->extend_duration( extend_tier29_4pc );
      else
        p()->buff.fury_of_the_aspects->trigger( extend_tier29_4pc );
    }

    p()->buff.blazing_shards->trigger();

    if ( p()->talent.scalecommander.mass_disintegrate.ok() )
      p()->buff.mass_disintegrate_stacks->trigger();

    if ( p()->talent.scalecommander.mass_eruption.ok() )
      p()->buff.mass_eruption_stacks->trigger();
  }
};

struct empowered_charge_spell_t : public empowered_charge_t<evoker_spell_t>
{
  using base_t = empowered_charge_spell_t;

  empowered_charge_spell_t( std::string_view n, evoker_t* p, const spell_data_t* s, std::string_view o )
    : empowered_charge_t( n, p, s, o )
  {
  }

  player_t* get_release_target( dot_t* d ) override
  {
    auto t = d->state->target;

    if ( t->is_sleeping() )
      t = nullptr;

    return t;
  }
};

struct ebon_might_t : public evoker_augment_t
{
public:
  timespan_t ebon_time = timespan_t::min();
  double double_time_mult;

  ebon_might_t( evoker_t* p, std::string_view options_str )
    : ebon_might_t( p, "ebon_might", options_str, timespan_t::min() )
  {
  }

  ebon_might_t( evoker_t* p, timespan_t ebon, std::string_view name ) : ebon_might_t( p, name, {}, ebon )
  {
  }

  ebon_might_t( evoker_t* p, std::string_view name, std::string_view options_str, timespan_t ebon )
    : evoker_augment_t( name, p, p->talent.ebon_might, options_str ),
      ebon_time( ebon ),
      double_time_mult( p->talent.chronowarden.double_time->effectN( 2 ).percent() )
  {
    aoe          = -1;
    dot_duration = base_tick_time = 0_ms;

    may_crit = true;

    cooldown->base_duration = 0_s;

    if ( !p->spec.ebon_might )
    {
      p->spec.ebon_might = std::make_unique<modified_spell_data_t>( data() );
      p->spec.ebon_might->parse_effects( p->sets->set( EVOKER_AUGMENTATION, DF2, B4 ) )
          ->parse_effects( p->spec.close_as_clutchmates,
                           [ p = p ]( const action_t*, const action_state_t* ) { return p->close_as_clutchmates; } );
    }
  }

  double ebon_value() const
  {
    if ( sim->dbc->wowv() < wowv_t( 12, 1, 0 ) )
      return p()->spec.ebon_might->effectN( 1 ).percent() * ( 1.0 + p()->buff.ebon_might_self_buff->check_value() ) +
             p()->buff.tww1_4pc_aug->check_stack_value();

    return p()->spec.ebon_might->effectN( 1 ).percent() * ( 1.0 + p()->buff.doubletime->check_value() ) +
           p()->buff.tww1_4pc_aug->check_stack_value();
  }

  double ebon_int()
  {
    sim->print_debug( "{} ebon might current int: {}, base percent: {}, crit_mod: {}, aug_4pc_value: {}, active_buffs: {}",
                      player->name_str, p()->cache.intellect(), p()->spec.ebon_might->effectN( 1 ).percent(),
                      p()->buff.ebon_might_self_buff->check_value(), p()->buff.tww1_4pc_aug->check_stack_value(), p()->allies_with_my_ebon.size() );

    if ( p()->allied_ebons_on_me.empty() )
      return p()->cache.intellect() * ebon_value();

    double ignore_int = 0;

    for ( auto b : p()->allied_ebons_on_me )
    {
      ignore_int += debug_cast<stat_buff_t*>( b )->stats[ 0 ].amount;
    }

    ignore_int *= p()->composite_attribute_multiplier( ATTR_INTELLECT );

    return ( p()->cache.intellect() - ignore_int ) * ebon_value();
  }

  double ebon_int_post_dr()
  {
    auto amount = ebon_int();

    if ( p()->option.nerf_em_for_external_sims )
    {
      amount *= p()->spec.ebon_might->effectN( 3 ).base_value() / p()->option.estimated_raid_dps_allies;
    }
    else if ( p()->allies_with_my_ebon.size() > p()->spec.ebon_might->effectN( 3 ).base_value() )
    {
      amount *= p()->spec.ebon_might->effectN( 3 ).base_value() / p()->allies_with_my_ebon.size();
    }

    if ( p()->talent.duplicate2.enabled() && p()->buff.duplicate->check() )
    {
      amount *= 1.0 + p()->buff.duplicate->check_value();
    }

    return amount;
  }

  void extend_ebon( timespan_t extend )
  {
    if ( extend <= 0_s )
      return;

    if ( rng().roll( p()->cache.spell_crit_chance() ) )
      extend *= 1.0 + p()->talent.sands_of_time->effectN( 4 ).percent();

    if ( p()->buff.ebon_might_self_buff->check() )
    {
      p()->buff.ebon_might_self_buff->extend_duration( extend );
    }

    for ( auto ally : p()->allies_with_my_ebon )
    {
      auto ebon = p()->get_target_data( ally )->buffs.ebon_might;

      ebon->extend_duration( extend );
    }

    if ( p()->talent.duplicate2.enabled() && p()->pets.duplicate_pet.n_active_pets() > 0 )
    {
      auto pet_extend = extend * p()->talent.duplicate2->effectN( 1 ).percent();
      for ( auto& pet : p()->pets.duplicate_pet.active_pets() )
      {
        pet->adjust_duration( pet_extend );
      }
    }

    if ( p()->talent.mighty_inferno.enabled() )
    {
      for ( auto& b : p()->active_infernos_blessings )
      {
        b->extend_duration( extend );
      }
    }
  }

  void update_stat( stat_buff_t* ebon, double _ebon_int )
  {
    if ( ebon->check() && ebon->stats[ 0 ].amount != _ebon_int )
    {
      sim->print_debug( "{} updating em values on player {}. New amount: {}, was: {}", *p(), *ebon->player, _ebon_int,
                        ebon->stats[ 0 ].amount );
      ebon->stats[ 0 ].amount = _ebon_int;
      adjust_int( ebon );
    }
  }

  void update_stats()
  {
    auto _ebon_int = ebon_int_post_dr();

    for ( auto ally : p()->allies_with_my_ebon )
    {
      auto ebon = debug_cast<stat_buff_t*>( p()->get_target_data( ally )->buffs.ebon_might );
      update_stat( ebon, _ebon_int );
    }
  }

  void adjust_int( stat_buff_t* b )
  {
    for ( auto& buff_stat : b->stats )
    {
      if ( buff_stat.check_func && !buff_stat.check_func( *b ) )
        continue;

      b->update_player_buff_stat( buff_stat, b->current_stack );
    }
  }

  void ebon_on_target( player_t* t, bool crit )
  {
    if ( t->is_enemy() )
    {
      sim->error( "{} Attempted to cast Ebon Might on {}, an enemy.", *p(), *t );
      return;
    }

    buff_t* buff;

    if ( t == p() )
      buff = p()->buff.ebon_might_self_buff;
    else
    {
      buff = p()->get_target_data( t )->buffs.ebon_might;
    }

    bool new_cast = !buff->check();
    if ( ebon_time <= timespan_t::zero() || new_cast )
    {
      if ( t == p() && p()->sets->has_set_bonus( EVOKER_AUGMENTATION, TWW1, B4 ) )
      {
        p()->buff.tww1_4pc_aug->expire();
        make_event( sim, p()->buff.tww1_4pc_aug->tick_time(), [ this ] {
          if ( p()->buff.ebon_might_self_buff->check() )
            p()->buff.tww1_4pc_aug->trigger();
        } );
      }

      auto time = ebon_time >= timespan_t::zero() ? ebon_time : buff->buff_duration();
      buff->trigger( time );
      if ( p()->talent.chronowarden.double_time.enabled() && crit && t == p() )
      {
        if ( sim->dbc->wowv() < wowv_t( 12, 1, 0 ) )
        {
          buff->current_value = double_time_mult;
        }
        else
        {
          p()->buff.doubletime->trigger();
        }
      }
    }
    else
    {
      auto time = ebon_time;
      if ( crit )
        time *= 1.0 + p()->talent.sands_of_time->effectN( 4 ).percent();
      buff->extend_duration( time );
    }
  }

  void execute() override
  {
    sim->print_debug( "{} before cast {} allies with prescience: {} allies with ebon: {} n_targets: {}", *p(), *this,
                      p()->allies_with_my_prescience.size(), p()->allies_with_my_ebon.size(), n_targets() );

    // Debug for Ebon Might - Need to check if there's a bug
    if ( sim->debug )
    {
      std::string _str = "";

      for ( auto& _p : sim->player_no_pet_list )
      {
        if ( _p->is_sleeping() )
        {
          _str += "S ";
          continue;
        }
        auto td = p()->get_target_data( _p );

        if ( td->buffs.ebon_might->up() )
        {
          if ( td->buffs.prescience->up() )
          {
            _str += "B ";
          }
          else
          {
            _str += "E ";
          }
        }
        else if ( td->buffs.prescience->up() )
        {
          _str += "P ";
        }
        else
        {
          _str += "X ";
        }
      }

      sim->print_debug( "{} {}", *p(), _str );

      for ( auto& _e : p()->allied_augmentations )
      {
        _str = "";

        for ( auto& _p : sim->player_no_pet_list )
        {
          if ( _p->is_sleeping() )
          {
            _str += "S ";
            continue;
          }
          auto td = _e->get_target_data( _p );

          if ( td->buffs.ebon_might->up() )
          {
            if ( td->buffs.prescience->up() )
            {
              _str += "B ";
            }
            else
            {
              _str += "E ";
            }
          }
          else if ( td->buffs.prescience->up() )
          {
            _str += "P ";
          }
          else
          {
            _str += "X ";
          }
        }
        sim->print_debug( "{} {}", *_e, _str );
      }
    }

    evoker_augment_t::execute();

    update_stats();

    sim->print_debug( "{} casts {} allies with prescience: {} allies with ebon: {} n_targets: {}", *p(), *this,
                      p()->allies_with_my_prescience.size(), p()->allies_with_my_ebon.size(), n_targets() );
  }

  void impact( action_state_t* s ) override
  {
    evoker_augment_t::impact( s );

    /*if ( s->chain_target == 0 )
    {
      for ( auto t : p()->allies_with_my_ebon )
      {
        ebon_on_target( t, s->result == RESULT_CRIT );
      }
    }*/

    ebon_on_target( s->target, s->result == RESULT_CRIT );
  }

  void activate() override
  {
    evoker_augment_t::activate();
    p()->allies_with_my_ebon.register_callback( [ this ]( player_t* ) { target_cache.is_valid = false; } );
    p()->allies_with_my_prescience.register_callback( [ this ]( player_t* ) { target_cache.is_valid = false; } );

    for ( auto e : p()->allied_augmentations )
    {
      e->allied_ebon_callbacks.push_back( [ this ]() { target_cache.is_valid = false; } );
    }
  }

  size_t available_targets( std::vector<player_t*>& target_list ) const override
  {
    target_list.clear();
    // Player must always be the first target.
    target_list.push_back( player );

    for ( auto& t : p()->sim->player_non_sleeping_list )
    {
      if ( t == player || ( t->primary_role() == ROLE_TANK || t->primary_role() == ROLE_HEAL ) || t->is_pet() )
        continue;

      target_list.push_back( t );
    }

    return target_list.size();
  }
};

struct chrono_flame_damage_t : public evoker_spell_t
{
  double chrono_mult;
  double chrono_cap;
  double TWW3_set_cap;
  chrono_flame_damage_t( evoker_t* p, std::string_view suffix = "" )
    : evoker_spell_t( fmt::format( "chrono_flame{}", suffix ), p, p->talent.chronowarden.chrono_flame_damage ),
      chrono_mult( p->talent.chronowarden.chrono_flame->effectN( p->specialization() == EVOKER_AUGMENTATION ? 3 : 1 )
                       .percent() ),
      chrono_cap( ( p->talent.chronowarden.overclock->effectN( 1 ).percent() + 1 ) *
                  2.5 ),   // TODO: Parse from variable,
      TWW3_set_cap( 4.5 )  // TODO: Parse from variable,
  {
    may_crit = false;
    // sets->set( HERO_CHRONOWARDEN, TWW3, B2 )
  }

  double get_damage( const action_state_t* s ) const
  {
    auto td = p()->find_target_data( s->target );

    if ( !td )
      return 0;

    double mult = ( p()->sets->has_set_bonus( HERO_CHRONOWARDEN, TWW3, B4 ) && p()->buff.temporal_burst->check() )
                      ? chrono_mult + p()->sets->set( HERO_CHRONOWARDEN, TWW3, B4 )->effectN( 1 ).percent()
                      : chrono_mult;

    double pool =
        std::accumulate( td->chrono_tracker.damage_buckets.begin(), td->chrono_tracker.damage_buckets.end(), 0.0 ) *
        mult;

    return pool;
  }

  double current_chrono_cap( action_state_t* s )
  {
    if ( p()->sets->has_set_bonus( HERO_CHRONOWARDEN, TWW3, B4 ) && p()->buff.temporal_burst->check() )
      return composite_versatility( s ) * composite_total_spell_power() * TWW3_set_cap;
    return composite_versatility( s ) * composite_total_spell_power() * chrono_cap;
  }

  void impact( action_state_t* s )
  {
    s->result_total = s->result_raw = s->result_amount = std::min( get_damage( s ), current_chrono_cap( s ) );

    evoker_spell_t::impact( s );
  }
};

template <class Base>
struct living_flame_base_t : public Base
{
  using base_t = living_flame_base_t<Base>;

  timespan_t prepull_timespent;
  bool st_only;

  living_flame_base_t( std::string_view n, evoker_t* p, const spell_data_t* s, bool st = false )
    : Base( n, p, s ), prepull_timespent( timespan_t::zero() ), st_only( st )
  {
    base_t::background = base_t::dual = true;

    if ( !p->talent.ruby_embers.ok() )
      base_t::dot_duration = 0_ms;
  }

  int n_targets() const override
  {
    if ( st_only )
      return 1;

    if ( auto n = base_t::p()->buff.leaping_flames->check() )
      return 1 + n;
    else
      return Base::n_targets();
  }

  timespan_t travel_time() const override
  {
    if ( prepull_timespent == timespan_t::zero() )
      return Base::travel_time();

    // for each additional spell in precombat apl, reduce the travel time by the cast time
    base_t::player->invalidate_cache( CACHE_SPELL_HASTE );
    return std::max( 1_ms, Base::travel_time() - prepull_timespent * base_t::composite_haste() );
  }

  std::vector<player_t*>& target_list() const override
  {
    auto& tl = Base::target_list();

    if ( base_t::is_aoe() && as<int>( tl.size() ) > base_t::n_targets() )
    {
      // always hit the target, so if it exists make sure it's first
      auto start_it = tl.begin() + ( tl[ 0 ] == base_t::target ? 1 : 0 );

      // randomize remaining targets
      base_t::rng().shuffle( start_it, tl.end() );
    }

    return tl;
  }
};

struct living_flame_damage_t : public living_flame_base_t<evoker_spell_t>
{
  chrono_flame_damage_t* chrono_flame;
  living_flame_damage_t( evoker_t* p, std::string_view name = "living_flame", bool afterimage = false )
    : base_t( std::string( name ) + "_damage", p, p->spec.living_flame_damage, afterimage ), chrono_flame( nullptr )
  {
    if ( p->talent.chronowarden.chrono_flame.enabled() )
    {
      chrono_flame = p->get_secondary_action<chrono_flame_damage_t>( "chrono_flame", "_" + std::string( name ) );
      if ( name != "living_flame" )
      {
        add_child( chrono_flame );
      }
    }
  }

  double bonus_da( const action_state_t* s ) const override
  {
    auto da = base_t::bonus_da( s );

    da += p()->buff.scarlet_adaptation->check_value();

    return da;
  }

  double composite_da_multiplier( const action_state_t* s ) const override
  {
    auto da = base_t::composite_da_multiplier( s );

    da *= 1.0 + p()->buff.iridescence_red->check_value();

    // Afterimage
    if ( !st_only )
      da *= 1.0 + p()->talent.chronowarden.chronal_dynamo->effectN( 2 ).percent();

    return da;
  }

  void execute() override
  {
    base_t::execute();

    if ( st_only && rng().roll( p()->talent.ruby_essence_burst->effectN( 1 ).percent() ) )
    {
      p()->buff.essence_burst->trigger();
      p()->proc.ruby_essence_burst->occur();
    }
  }

  void impact( action_state_t* state ) override
  {
    base_t::impact( state );

    if ( chrono_flame )
    {
      chrono_flame->execute_on_target( state->target );
    }

    if ( p()->talent.flameshaper.titanic_precision.ok() && state->result == RESULT_CRIT &&
         rng().roll( p()->talent.ruby_essence_burst->effectN( 1 ).percent() ) )
    {
      p()->buff.essence_burst->trigger();
      p()->proc.titanic_precision_ruby_essence_burst->occur();
    }
  }
};

struct living_flame_heal_t : public living_flame_base_t<heals::evoker_heal_t>
{
  living_flame_heal_t( evoker_t* p ) : base_t( "living_flame_heal", p, p->spec.living_flame_heal )
  {
  }

  void impact( action_state_t* state ) override
  {
    base_t::impact( state );

    if ( p()->talent.flameshaper.titanic_precision.ok() && state->result == RESULT_CRIT &&
         rng().roll( p()->talent.ruby_essence_burst->effectN( 1 ).percent() ) )
    {
      p()->buff.essence_burst->trigger();
      p()->proc.titanic_precision_ruby_essence_burst->occur();
    }
  }
};

struct fire_breath_t : public empowered_charge_spell_t
{
  struct fire_breath_damage_t : public empowered_release_spell_t
  {
    timespan_t dot_dur_per_emp;
    action_t* chrono_flames;
    int max_afterimage_targets;

    fire_breath_damage_t( evoker_t* p )
      : base_t( "fire_breath_damage", p, p->spec.fire_breath_damage ),
        dot_dur_per_emp( 6_s ),
        chrono_flames( nullptr ),
        max_afterimage_targets( as<int>( p->talent.chronowarden.afterimage->effectN( 1 ).base_value() ) )
    {
      aoe                 = -1;  // TODO: actually a cone so we need to model it if possible
      reduced_aoe_targets = 5.0;

      dot_duration = 20_s;  // base * 10? or hardcoded to 20s?
      dot_duration += timespan_t::from_seconds( p->talent.blast_furnace->effectN( 1 ).base_value() );
      dot_duration += timespan_t::from_seconds( p->talent.flameshaper.deep_exhalation->effectN( 1 ).base_value() );

      if ( p->talent.chronowarden.afterimage.enabled() )
      {
        chrono_flames =
            p->get_secondary_action<living_flame_damage_t>( "afterimage_fire_breath", "afterimage_fire_breath", true );
      }
    }

    timespan_t reduction_from_empower( const action_state_t* s ) const
    {
      return std::max( 0, empower_value( s ) - 1 ) * dot_dur_per_emp;
    }

    timespan_t composite_dot_duration( const action_state_t* s ) const override
    {
      return base_t::composite_dot_duration( s ) - reduction_from_empower( s );
    }

    double bonus_da( const action_state_t* s ) const override
    {
      auto da          = base_t::bonus_da( s );
      auto ticks       = reduction_from_empower( s ) / tick_time( s );
      auto tick_damage = s->composite_spell_power() * spell_tick_power_coefficient( s );

      return da + ticks * tick_damage;
    }

    double composite_persistent_multiplier( const action_state_t* s ) const override
    {
      auto m = base_t::composite_persistent_multiplier( s );

      m *= 1.0 + p()->buff.iridescence_red->check_value();

      return m;
    }

    void execute() override
    {
      base_t::execute();

      if ( p()->talent.leaping_flames.ok() )
      {
        if ( p()->buff.leaping_flames->check() )
        {
          p()->proc.overwritten_leaping_flames->occur();
          p()->buff.leaping_flames->expire();
        }

        p()->buff.leaping_flames->trigger( empower_value( execute_state ) );
      }

      if ( p()->talent.infernos_blessing.ok() )
      {
        if ( p()->buff.ebon_might_self_buff->check() )
        {
          p()->get_target_data( p() )->buffs.infernos_blessing->trigger();

          player_t* other_player = nullptr;

          if ( p()->allies_with_my_ebon.size() > 0 )
            other_player = rng().range( p()->allies_with_my_ebon );

          if ( other_player )
          {
            p()->get_target_data( other_player )->buffs.infernos_blessing->trigger();
          }
        }
      }

      if ( p()->talent.flameshaper.essence_well.enabled() )
      {
        if ( p()->buff.dragonrage->check() ||
             rng().roll( p()->talent.flameshaper.essence_well->effectN( 1 ).percent() ) )
        {
          p()->buff.essence_burst->trigger();
          p()->proc.essence_well->occur();
        }
      }
    }

    double tick_time_pct_multiplier( const action_state_t* state ) const override
    {
      auto mul = base_t::tick_time_pct_multiplier( state );

      if ( p()->talent.catalyze.ok() && p()->get_target_data( state->target )->dots.disintegrate->is_ticking() &&
           p()->get_target_data( state->target )->dots.disintegrate->ticks_left_fractional() > 0 )
      {
        mul /= ( 1.0 + p()->talent.catalyze->effectN( 1 ).percent() );
      }

      return mul;
    }

    double calculate_tick_amount( action_state_t* s, double m ) const override
    {
      auto n = std::clamp( as<double>( s->n_targets ), reduced_aoe_targets, 20.0 );

      m *= std::sqrt( reduced_aoe_targets / n );

      return base_t::calculate_tick_amount( s, m );
    }

    void tick( dot_t* d ) override
    {
      empowered_release_spell_t::tick( d );

      // TODO: confirm this doesn't have a target # based DR, or exhibit previously bugged behavior where icd is
      // triggered on check, not success
      p()->buff.burnout->trigger();
    }

    void impact( action_state_t* s ) override
    {
      empowered_release_spell_t::impact( s );

      int max_afterimage = p()->sets->has_set_bonus( HERO_CHRONOWARDEN, TWW3, B4 ) && p()->buff.temporal_burst->check()
                               ? max_afterimage_targets + 1
                               : max_afterimage_targets;

      if ( chrono_flames && s->chain_target < max_afterimage )
      {
        chrono_flames->execute_on_target( s->target );
      }
    }
  };

  fire_breath_t( evoker_t* p, std::string_view options_str )
    : base_t( "fire_breath", p, p->find_class_spell( "Fire Breath" ), options_str )
  {
    create_release_spell<fire_breath_damage_t>( "fire_breath_damage" );

    if ( p->talent.chronowarden.afterimage.enabled() )
    {
      add_child(
          p->get_secondary_action<living_flame_damage_t>( "afterimage_fire_breath", "afterimage_fire_breath", true ) );
    }

    if ( empower_to == EMPOWER_MAX && p->option.fire_breath_default_rank > 0 )
    {
      setup_empower_stats( p->option.fire_breath_default_rank );
    }
  }

  player_t* get_release_target( dot_t* d ) override
  {
    auto t = d->state->target;

    if ( t->is_sleeping() )
    {
      t = nullptr;

      for ( auto enemy : p()->sim->target_non_sleeping_list )
      {
        if ( enemy->is_sleeping() || ( enemy->debuffs.invulnerable && enemy->debuffs.invulnerable->check() ) )
          continue;

        t = enemy;
        break;
      }
    }

    return t;
  }

  std::unique_ptr<expr_t> create_expression( std::string_view expression_str ) override
  {
    auto splits = util::string_split<util::string_view>( expression_str, "." );

    if ( splits.size() >= 2 )
    {
      if ( util::str_compare_ci( splits[ 0 ], "release" ) )
      {
        if ( util::str_compare_ci( splits[ 1 ], "dot_duration" ) )
        {
          class dot_duration_expr_t : public expr_t
          {
          public:
            fire_breath_damage_t& action;
            fire_breath_t& release;
            evoker_action_state_t<empower_data_t>* state;

            dot_duration_expr_t( std::string_view name, fire_breath_damage_t& a, fire_breath_t& release,
                                 empower_e empower_level )
              : expr_t( name ), action( a ), release( release ), state( a.cast_state( a.get_state() ) )
            {
              state->n_targets    = 1;
              state->chain_target = 0;
              state->empower      = empower_level;
              state->result       = RESULT_HIT;
            }

            double evaluate() override
            {
              state->target = release.target;
              action.snapshot_state( state, result_amount_type::DMG_OVER_TIME );
              return coerce( action.composite_dot_duration( state ) );
            }

            ~dot_duration_expr_t() override
            {
              delete state;
            }
          };

          return std::make_unique<dot_duration_expr_t>( expression_str,
                                                        dynamic_cast<fire_breath_damage_t&>( *release_spell ), *this,
                                                        static_cast<empower_e>( empower_to ) );
        }
      }
    }

    return base_t::create_expression( expression_str );
  }
};

struct shattering_star_t : public evoker_spell_t
{
  shattering_star_t( evoker_t* p, std::string_view name ) : evoker_spell_t( name, p, p->talent.shattering_star_spell )
  {
  }
};

struct eternity_surge_t : public empowered_charge_spell_t
{
  struct eternity_surge_damage_t : public empowered_release_spell_t
  {
    action_t* shattering_star;
    eternity_surge_damage_t( evoker_t* p, std::string_view name )
      : base_t( name, p, p->find_spell( 359077 ) ), shattering_star( nullptr )
    {
      if ( p->talent.shattering_stars.enabled() )
      {
        shattering_star = p->get_secondary_action<shattering_star_t>( fmt::format( "{}_star", name ),
                                                                      fmt::format( "{}_star", name ) );
        add_child( shattering_star );
      }
    }

    eternity_surge_damage_t( evoker_t* p ) : eternity_surge_damage_t( p, "eternity_surge_damage" )
    {
    }

    int n_targets() const override
    {
      return n_targets( pre_execute_state );
    }

    int n_targets( action_state_t* s ) const
    {
      int n = s ? empower_value( s ) : max_empower;

      if ( p()->talent.eternitys_span.enabled() )
        n *= 2;

      return n == 1 ? 0 : n;
    }

    double composite_da_multiplier( const action_state_t* s ) const override
    {
      auto m = base_t::composite_da_multiplier( s );

      if ( p()->talent.eye_of_infinity.enabled() && s->chain_target == 0 )
      {
        m *= 1.0 + p()->talent.eye_of_infinity->effectN( 1 ).percent();
      }

      return m;
    }

    void impact( action_state_t* s ) override
    {
      base_t::impact( s );

      if ( shattering_star && ( s->chain_target == 0 || p()->talent.star_salvo.enabled() ) )
      {
        shattering_star->set_target( s->target );
        action_state_t* damage_state = shattering_star->get_state();
        damage_state->target         = s->target;
        shattering_star->snapshot_state( damage_state, result_amount_type::DMG_DIRECT );

        auto empower_level =
            p()->sets->has_set_bonus( EVOKER_DEVASTATION, MID2, B2 ) ? max_empower : cast_state( s )->empower;

        damage_state->da_multiplier *= 1.0 + ( empower_level - 1 ) * p()->talent.shattering_stars->effectN( 1 ).percent();

        if ( proc_spell_type == proc_spell_type_e::SCINTILLATION )
        {
          damage_state->da_multiplier *= p()->talent.scintillation->effectN( 1 ).percent();
        }

        shattering_star->schedule_execute( damage_state );
      }
    }
  };

  eternity_surge_t( evoker_t* p, std::string_view options_str )
    : base_t( "eternity_surge", p, p->talent.eternity_surge, options_str )
  {
    create_release_spell<eternity_surge_damage_t>( "eternity_surge_damage" );
    add_child( release_spell );

    if ( empower_to == EMPOWER_MAX && p->option.eternity_surge_default_rank > 0 )
    {
      setup_empower_stats( p->option.eternity_surge_default_rank );
    }
  }

  void execute() override
  {
    base_t::execute();

    if ( p()->talent.azure_sweep.enabled() )
    {
      p()->buff.azure_sweep->trigger();
    }
  }
};

// Spells ===================================================================
struct azure_strike_base_t : public evoker_spell_t
{
  azure_strike_base_t( std::string_view name, evoker_t* p, const spell_data_t* spell, std::string_view options_str )
    : evoker_spell_t( name, p, spell, options_str )
  {
  }

  void execute() override
  {
    evoker_spell_t::execute();
    double eb_chance =
        p()->talent.azure_essence_burst->effectN( 1 ).percent() * ( 1.0 + p()->buff.inner_flame->check_stack_value() );

    // TODO:  Work out how this is rolled.
    if ( p()->talent.flameshaper.titanic_precision.ok() && rng().roll( composite_target_crit_chance( target ) ) &&
         rng().roll( rng().roll( eb_chance ) ) )
    {
      p()->buff.essence_burst->trigger();
      p()->proc.titanic_precision_azure_essence_burst->occur();
    }

    if ( p()->talent.azure_essence_burst.ok() && ( p()->buff.dragonrage->up() || rng().roll( eb_chance ) ) )
    {
      p()->buff.essence_burst->trigger();
      p()->proc.azure_essence_burst->occur();
    }
  }

  double composite_da_multiplier( const action_state_t* s ) const override
  {
    auto da = evoker_spell_t::composite_da_multiplier( s );

    da *= 1.0 + p()->buff.iridescence_blue->check_value();

    return da;
  }

  void impact( action_state_t* s ) override
  {
    evoker_spell_t::impact( s );

    if ( p()->talent.echoing_strike.ok() && s->chain_target == 0 &&
         rng().roll( p()->talent.echoing_strike->effectN( 1 ).percent() * s->n_targets ) )
    {
      execute_on_target( s->target );
      p()->proc.echoing_strike->occur();
    }
  }
};

struct azure_strike_t : public azure_strike_base_t
{
  azure_strike_t( evoker_t* p, std::string_view options_str )
    : azure_strike_base_t( "azure_strike", p, p->find_class_spell( "Azure Strike" ), options_str )
  {
    aoe = as<int>( data().effectN( 1 ).base_value() );
  }

  bool action_ready() override
  {
    if ( p()->buff.azure_sweep->check() )
      return false;

    return azure_strike_base_t::action_ready();
  }
};

struct azure_sweep_t : public azure_strike_base_t
{
  timespan_t mid1_es_cdr;
  azure_sweep_t( evoker_t* p, std::string_view options_str )
    : azure_strike_base_t( "azure_sweep", p, p->talent.azure_sweep_spell, options_str ),
      mid1_es_cdr( -p->sets->set( EVOKER_DEVASTATION, MID1, B4 )->effectN( 2 ).time_value() )
  {
    aoe = -1;
  }

  bool action_ready() override
  {
    if ( !p()->buff.azure_sweep->check() )
      return false;

    return azure_strike_base_t::action_ready();
  }

  double composite_da_multiplier( const action_state_t* s ) const override
  {
    auto da = azure_strike_base_t::composite_da_multiplier( s );

    if ( s->chain_target == 0 && p()->sets->has_set_bonus( EVOKER_DEVASTATION, MID1, B2 ) )
    {
      da *= 1.0 + p()->sets->set( EVOKER_DEVASTATION, MID1, B2 )->effectN( 2 ).percent();
    }

    return da;
  }

  void execute() override
  {
    azure_strike_base_t::execute();

    if ( p()->sets->has_set_bonus( EVOKER_DEVASTATION, MID1, B4 ) )
    {
      p()->cooldown.eternity_surge->adjust( mid1_es_cdr );
    }
  }
};

struct melt_armor_dot_t : public evoker_spell_t
{
  melt_armor_dot_t( evoker_t* p ) : evoker_spell_t( "melt_armor_dot", p, p->talent.scalecommander.melt_armor_debuff )
  {
    dual = background = true;
    aoe               = -1;
    dot_behavior      = DOT_EXTEND;
  }

  bool use_full_mastery() const override
  {
    return p()->talent.tyranny.ok();
  }

  void impact( action_state_t* s ) override
  {
    evoker_spell_t::impact( s );
  }

  void execute() override
  {
    evoker_spell_t::execute();
  }
};

struct eruption_t : public essence_spell_t
{
  struct eruption_4pc_t : public evoker_spell_t
  {
    timespan_t extend_ebon;

    eruption_4pc_t( evoker_t* p, std::string_view n )
      : evoker_spell_t( n, p, p->find_spell( 424428 ) ),
        extend_ebon( p->sets->set( EVOKER_AUGMENTATION, DF3, B4 )->effectN( 1 ).time_value() * 100 )
    {
      aoe              = -1;
      split_aoe_damage = true;
    }

    double composite_da_multiplier( const action_state_t* s ) const override
    {
      double da = evoker_spell_t::composite_da_multiplier( s );

      if ( p()->talent.ricocheting_pyroclast.ok() )
      {
        da *= 1.0 + std::min( static_cast<double>( s->n_targets ),
                            p()->talent.ricocheting_pyroclast->effectN( 2 ).base_value() ) *
                      p()->talent.ricocheting_pyroclast->effectN( 1 ).percent();
      }

      return da;
    }

    void execute() override
    {
      evoker_spell_t::execute();

      p()->extend_ebon( extend_ebon );
    }
  };

  struct eruption_mass_eruption_t : public evoker_spell_t
  {
    timespan_t upheaval_cdr;

    eruption_mass_eruption_t( evoker_t* p, std::string_view n )
      : evoker_spell_t( n, p, p->talent.scalecommander.mass_eruption_damage ),

        upheaval_cdr( p->talent.accretion->effectN( 1 ).trigger()->effectN( 1 ).time_value() )
    {
      aoe              = -1;
      split_aoe_damage = true;
    }

    double composite_da_multiplier( const action_state_t* s ) const override
    {
      double da = evoker_spell_t::composite_da_multiplier( s );

      if ( p()->talent.ricocheting_pyroclast.ok() )
      {
        da *= 1.0 + std::min( static_cast<double>( s->n_targets ),
                            p()->talent.ricocheting_pyroclast->effectN( 2 ).base_value() ) *
                      p()->talent.ricocheting_pyroclast->effectN( 1 ).percent();
      }

      return da;
    }

    void execute() override
    {
      evoker_spell_t::execute();

      if ( p()->talent.accretion.ok() )
      {
        p()->cooldown.upheaval->adjust( upheaval_cdr );
      }
    }
  };

  timespan_t extend_ebon;
  timespan_t upheaval_cdr;
  action_t* t31_4pc_eruption;
  action_t* mass_eruption;
  double mass_eruption_mult;
  int mass_eruption_max_targets;
  double motes_chance;
  bool is_overlord;
  double tww2_4pc_mult;

  eruption_t( evoker_t* p, std::string_view name ) : eruption_t( p, name, {} )
  {
  }

  eruption_t( evoker_t* p, std::string_view name, std::string_view options_str )
    : essence_spell_t( name, p, p->talent.eruption, options_str ),
      extend_ebon( p->talent.sands_of_time->effectN( 1 ).time_value() ),
      upheaval_cdr( p->talent.accretion->effectN( 1 ).trigger()->effectN( 1 ).time_value() ),
      t31_4pc_eruption( nullptr ),
      mass_eruption( nullptr ),
      mass_eruption_mult( p->talent.scalecommander.mass_eruption->effectN( 2 ).percent() ),
      mass_eruption_max_targets( 1 +
                                 as<int>( p->talent.scalecommander.mass_eruption_buff->effectN( 1 ).base_value() ) ),
      motes_chance( p->talent.motes_of_possibility->proc_chance() ),
      is_overlord( false ),
      tww2_4pc_mult( p->sets->has_set_bonus( EVOKER_AUGMENTATION, TWW2, B4 )
                         ? p->sets->set( EVOKER_AUGMENTATION, TWW2, B4 )->effectN( 2 ).percent()
                         : 0.0 )
  {
    aoe              = -1;
    split_aoe_damage = true;

    if ( p->sets->has_set_bonus( EVOKER_AUGMENTATION, DF3, B4 ) )
    {
      t31_4pc_eruption = p->get_secondary_action<eruption_4pc_t>( name_str + "_4pc", name_str + "_4pc" );
      add_child( t31_4pc_eruption );
    }

    if ( p->talent.scalecommander.mass_eruption.enabled() )
    {
      mass_eruption = p->get_secondary_action<eruption_mass_eruption_t>( "mass_" + name_str, "mass_" + name_str );
      add_child( mass_eruption );
    }
  }

  int mass_eruption_targets() const
  {
    std::vector<player_t*>& tl = target_list();
    const int tl_size          = as<int>( tl.size() );

    return std::min( mass_eruption_max_targets, tl_size );
  }

  double composite_da_multiplier( const action_state_t* s ) const override
  {
    double da = essence_spell_t::composite_da_multiplier( s );

    if ( p()->talent.ricocheting_pyroclast.ok() )
    {
      da *= 1 + std::min( static_cast<double>( s->n_targets ),
                          p()->talent.ricocheting_pyroclast->effectN( 2 ).base_value() ) *
                    p()->talent.ricocheting_pyroclast->effectN( 1 ).percent();
    }

    if ( p()->buff.mass_eruption_stacks->check() && !is_overlord &&
         mass_eruption_targets() < mass_eruption_max_targets )
    {
      da *= 1.0 + ( mass_eruption_max_targets - mass_eruption_targets() ) * mass_eruption_mult;
    }

    if ( p()->buff.essence_burst->check() && p()->sets->has_set_bonus( EVOKER_AUGMENTATION, TWW2, B4 ) )
      da *= 1.0 + tww2_4pc_mult;

    return da;
  }

  void impact( action_state_t* s ) override
  {
    essence_spell_t::impact( s );

    if ( p()->talent.scalecommander.bombardments.enabled() && p()->buff.mass_eruption_stacks->check() && !is_overlord &&
         s->chain_target == 0 )
    {
      p()->apply_bombardments( s->target );
    }
  }

  void execute() override
  {
    essence_spell_t::execute();

    p()->extend_ebon( extend_ebon );

    if ( p()->buff.trembling_earth->check() && t31_4pc_eruption )
    {
      for ( int i = 0; i < p()->buff.trembling_earth->check(); i++ )
      {
        t31_4pc_eruption->execute_on_target( p()->target );
      }
      p()->buff.trembling_earth->expire();
    }

    if ( p()->talent.accretion.ok() )
    {
      p()->cooldown.upheaval->adjust( upheaval_cdr );
    }

    if ( p()->talent.motes_of_possibility.ok() && rng().roll( motes_chance ) )
    {
      p()->spawn_mote_of_possibility();
    }

    if ( !is_overlord )
    {
      if ( p()->talent.scalecommander.mass_eruption.enabled() && p()->buff.mass_eruption_stacks->check() &&
           execute_state )
      {
        int eruptions = 1;
        for ( auto potential_target : target_list() )
        {
          if ( potential_target == execute_state->target )
            continue;

          mass_eruption->execute_on_target( potential_target );

          if ( ++eruptions >= mass_eruption_max_targets )
            break;
        }

        if ( sim->dbc->wowv() >= wowv_t( 12, 1, 0 ) )
        {
          timespan_t cdr = p()->talent.scalecommander.wingleader->effectN( 2 ).time_value() * mass_eruption_targets();
          p()->cooldown.breath_of_eons->adjust( -cdr );
        }
      }

      p()->buff.volcanic_upsurge->decrement();
      p()->buff.mass_eruption_stacks->decrement();
    }
  }
};

struct upheaval_t : public empowered_charge_spell_t
{
  using periodic_base_t = residual_action::residual_periodic_action_t<evoker_spell_t>;
  struct reverberations_t : public periodic_base_t
  {
    reverberations_t( evoker_t* p, std::string_view n )
      : residual_action_t( n, p, p->talent.chronowarden.reverberations_upheaval )
    {
    }

    // Return Spell_t's multiplier as evoker's contains our mastery amp.
    double composite_target_multiplier( player_t* t ) const override
    {
      return spell_t::composite_target_multiplier( t );
    }

    void trigger_dot( action_state_t* s ) override
    {
      periodic_base_t::trigger_dot( s );

      p()->buff.primacy->trigger();
    }
  };

  struct upheaval_damage_t : public empowered_release_spell_t
  {
    reverberations_t* reverberations;
    double reverb_mul;
    int repeats;
    upheaval_damage_t* rumbling_earth;
    action_t* chrono_flames;
    int max_afterimage_targets;
    bool is_rumbling_earth;
    bool is_tierset;

    upheaval_damage_t( evoker_t* p, std::string_view name, bool is_rumbling_earth, bool is_tierset )
      : base_t( name, p, p->find_spell( 396288 ) ),
        reverberations( nullptr ),
        reverb_mul( p->talent.chronowarden.reverberations->effectN( 2 ).percent() ),
        repeats( as<int>( p->talent.rumbling_earth->effectN( 2 ).base_value() ) ),
        rumbling_earth( nullptr ),
        chrono_flames( nullptr ),
        max_afterimage_targets( as<int>( p->talent.chronowarden.afterimage->effectN( 1 ).base_value() ) ),
        is_rumbling_earth( is_rumbling_earth ),
        is_tierset( is_tierset )
    {
      aoe = -1;

      if ( p->talent.chronowarden.reverberations.enabled() )
      {
        auto reverb_name = fmt::format( "{}_dot", name );
        reverberations   = p->get_secondary_action<reverberations_t>( reverb_name, reverb_name );
      }

      if ( is_rumbling_earth )
      {
        sands = nullptr;
        base_dd_multiplier *= p->talent.rumbling_earth->effectN( 1 ).percent();
        extend_ebon = 0_s;

        if ( reverberations )
        {
          add_child( reverberations );
        }
      }
      else if ( p->talent.rumbling_earth.enabled() )
      {
        rumbling_earth = p->get_secondary_action<upheaval_damage_t>(
            fmt::format( "{}_rumbling_earth", name ), fmt::format( "{}_rumbling_earth", name ), true, is_tierset );
      }

      if ( p->talent.chronowarden.afterimage.enabled() && !is_rumbling_earth )
      {
        chrono_flames = p->get_secondary_action<living_flame_damage_t>( fmt::format( "afterimage_{}", name ),
                                                                        fmt::format( "afterimage_{}", name ), true );
      }

      if ( is_tierset )
      {
        base_dd_multiplier *= p->sets->set( EVOKER_AUGMENTATION, TWW2, B2 )->effectN( 1 ).percent();
        sands       = nullptr;
        extend_ebon = 0_s;
      }

      if ( is_tierset && !is_rumbling_earth )
      {
        if ( rumbling_earth )
        {
          add_child( rumbling_earth );
        }
        if ( chrono_flames )
        {
          add_child( chrono_flames );
        }
        if ( reverberations )
        {
          add_child( reverberations );
        }
      }
    }

    upheaval_damage_t( evoker_t* p ) : upheaval_damage_t( p, "upheaval_damage", false, false )
    {
    }

    double composite_da_multiplier( const action_state_t* s ) const override
    {
      double da = empowered_release_spell_t::composite_da_multiplier( s );

      if ( p()->talent.tectonic_locus.ok() && s->chain_target == 0 )
      {
        da *= 1.0 + p()->talent.tectonic_locus->effectN( 1 ).percent();
      }

      return da;
    }

    void impact( action_state_t* s ) override
    {
      empowered_release_spell_t::impact( s );

      if ( reverberations )
      {
        residual_action::trigger( reverberations, s->target, s->result_amount * reverb_mul );
      }

      if ( chrono_flames && s->chain_target < max_afterimage_targets )
      {
        chrono_flames->execute_on_target( s->target );
      }
    }

    void execute() override
    {
      if ( rumbling_earth )
      {
        empower_e empower_level  = cast_state( pre_execute_state )->empower;
        player_t* current_target = pre_execute_state->target;

        for ( int i = 0; i < repeats; i++ )
        {
          // First repeat is 200ms, 2nd repeat was 400ms delay from the first. Maybe triangular?
          make_event( sim, 200_ms * ( i + 1 ) * ( i + 2 ) / 2, [ this, current_target, empower_level ] {
            auto emp_state         = rumbling_earth->get_state();
            emp_state->target      = current_target;
            rumbling_earth->target = current_target;
            rumbling_earth->snapshot_state( emp_state, rumbling_earth->amount_type( emp_state ) );
            rumbling_earth->cast_state( emp_state )->empower = empower_level;

            rumbling_earth->schedule_execute( emp_state );
          } );
        }
      }

      empowered_release_spell_t::execute();

      if ( !is_rumbling_earth )
      {
        if ( p()->sets->has_set_bonus( EVOKER_AUGMENTATION, MID2, B4 ) )
          p()->buff.magnified_fate->trigger();

        if ( p()->sets->has_set_bonus( EVOKER_AUGMENTATION, TWW1, B2 ) )
          p()->buff.volcanic_upsurge->trigger();

        if ( p()->sets->has_set_bonus( EVOKER_AUGMENTATION, TWW2, B4 ) &&
             rng().roll( p()->sets->set( EVOKER_AUGMENTATION, TWW2, B4 )->effectN( 1 ).percent() ) )
        {
          p()->buff.essence_burst->trigger();
          p()->proc.tww2_4pc->occur();
        }
      }
    }
  };

  upheaval_t( evoker_t* p, std::string_view options_str ) : base_t( "upheaval", p, p->talent.upheaval, options_str )
  {
    create_release_spell<upheaval_damage_t>( "upheaval_damage" );

    if ( p->talent.chronowarden.reverberations.enabled() )
    {
      add_child( p->get_secondary_action<reverberations_t>( "upheaval_damage_dot", "upheaval_damage_dot" ) );
    }

    if ( p->talent.rumbling_earth.enabled() )
    {
      add_child( p->get_secondary_action<upheaval_damage_t>( "upheaval_damage_rumbling_earth",
                                                             "upheaval_damage_rumbling_earth", true, false ) );
    }

    if ( p->talent.chronowarden.afterimage.enabled() )
    {
      add_child( p->get_secondary_action<living_flame_damage_t>( "afterimage_upheaval_damage",
                                                                 "afterimage_upheaval_damage", true ) );
    }

    if ( empower_to == EMPOWER_MAX && p->option.upheaval_default_rank > 0 )
    {
      setup_empower_stats( p->option.upheaval_default_rank );
    }
  }
};

struct deep_breath_t : public evoker_spell_t
{
  struct deep_breath_dot_t : public evoker_spell_t
  {
    deep_breath_dot_t( evoker_t* p ) : evoker_spell_t( "deep_breath_dot", p, p->find_spell( 353759 ) )
    {
      aoe  = 0;
      dual = true;
    }

    bool use_full_mastery() const override
    {
      return p()->talent.tyranny.ok();
    }

    void impact( action_state_t* s ) override
    {
      evoker_spell_t::impact( s );

      if ( p()->talent.scalecommander.melt_armor.ok() )
      {
        auto td = p()->get_target_data( s->target );
        td->debuffs.melt_armor->trigger();
      }
    }
  };

  struct deep_breath_main_t : public evoker_spell_t
  {
    action_t* damage;
    action_t* ebon;
    action_t* melt_armor_dot;
    timespan_t plot_duration;
    eruption_t* eruption;
    upheaval_t::upheaval_damage_t* upheaval_set;
    deep_breath_main_t( evoker_t* p, std::string_view options_str )
      : evoker_spell_t(
            "deep_breath_trigger", p,
            p->talent.breath_of_eons.ok() ? spell_data_t::not_found() : p->find_class_spell( "Deep Breath" ),
            options_str ),
        damage( nullptr ),
        ebon( nullptr ),
        melt_armor_dot( nullptr ),
        eruption( nullptr ),
        upheaval_set( nullptr )
    {
      aoe = -1;

      travel_delay = 0.9;   // guesstimate, TODO: confirm
      travel_speed = 19.5;  // guesstimate, TODO: confirm

      if ( data().ok() )
      {
        damage        = p->get_secondary_action<deep_breath_dot_t>( "deep_breath_dot" );
        damage->stats = stats;

        if ( p->talent.overlord.ok() )
        {
          eruption               = p->get_secondary_action<eruption_t>( "eruption_overlord", "eruption_overlord" );
          eruption->is_overlord  = true;
          eruption->motes_chance = p->talent.overlord->effectN( 2 ).percent();
          add_child( eruption );
        }

        if ( p->talent.scalecommander.maneuverability.ok() )
        {
          melt_armor_dot = p->get_secondary_action<melt_armor_dot_t>( "melt_armor_dot" );
          add_child( melt_armor_dot );
        }

        if ( p->specialization() == EVOKER_AUGMENTATION && p->talent.ebon_might.ok() )
          ebon = p->get_secondary_action<ebon_might_t>(
              "ebon_might_deep_breath", p->talent.sands_of_time->effectN( 3 ).time_value(), "ebon_might_deep_breath" );
      }

      if ( p->sets->has_set_bonus( EVOKER_AUGMENTATION, TWW2, B2 ) )
      {
        upheaval_set = p->get_secondary_action<spells::upheaval_t::upheaval_damage_t>(
            "upheaval_tww2_2pc_db", "upheaval_tww2_2pc_db", false, true );

        add_child( upheaval_set );
      }

      plot_duration = timespan_t::from_seconds( p->talent.plot_the_future->effectN( 1 ).base_value() );
    }

    void impact( action_state_t* s ) override
    {
      evoker_spell_t::impact( s );

      damage->execute_on_target( s->target );

      if ( eruption && s->chain_target < p()->talent.overlord->effectN( 1 ).base_value() )
      {
        make_event( sim, 200_ms, [ this, s ] { eruption->execute_on_target( s->target ); } );
      }

      if ( melt_armor_dot && s->chain_target == 0 )
        melt_armor_dot->execute_on_target( s->target );
    }

    void execute() override
    {
      if ( p()->talent.scalecommander.command_squadron.enabled() )
      {
        p()->pets.commando_pet.spawn( 4_s, 2 );
      }

      if ( p()->talent.duplicate1.enabled() )
      {
        p()->pets.duplicate_pet.spawn();
      }

      if ( p()->buff.ebon_might_self_buff->check() )
      {
        p()->extend_ebon( p()->talent.sands_of_time->effectN( 3 ).time_value() );
      }
      else if ( ebon )
      {
        ebon->execute();
      }

      evoker_spell_t::execute();


      if ( upheaval_set )
      {
        auto emp_state       = upheaval_set->get_state();
        emp_state->target    = target;
        upheaval_set->target = target;
        upheaval_set->snapshot_state( emp_state, upheaval_set->amount_type( emp_state ) );
        upheaval_set->cast_state( emp_state )->empower = EMPOWER_4;
        upheaval_set->schedule_execute( emp_state );
      }

      if ( p()->talent.chronowarden.time_convergence.enabled() )
      {
        p()->buff.time_convergence_intellect->trigger();
      }

      if ( p()->talent.plot_the_future.ok() )
      {
        make_event( sim, player->gcd_ready - sim->current_time() - 1_ms, [ this ] {
          if ( p()->buffs.bloodlust->check() )
            p()->buffs.bloodlust->extend_duration( plot_duration );
          else if ( p()->buff.fury_of_the_aspects->check() )
            p()->buff.fury_of_the_aspects->extend_duration( plot_duration );
          else
          {
            p()->buff.fury_of_the_aspects->trigger( plot_duration );
            // Plots bloodlust re-triggers the buff for some reason.
            if ( p()->talent.chronowarden.time_convergence.enabled() )
            {
              p()->buff.time_convergence_intellect->trigger();
            }
          }
        } );
      }

      if ( p()->talent.scalecommander.slipstream.ok() )
      {
        p()->cooldown.hover->reset( false, -1 );
      }
    }
  };

  action_t* main_spell;
  deep_breath_t( evoker_t* p, std::string_view options_str )
    : evoker_spell_t( "deep_breath", p,
                      p->talent.breath_of_eons.ok() ? spell_data_t::not_found()
                      : p->talent.scalecommander.maneuverability.ok()
                          ? p->talent.scalecommander.maneuverability_deep_breath
                          : p->find_class_spell( "Deep Breath" ),
                      options_str )
  {
    if ( data().ok() )
    {
      main_spell = p->get_secondary_action<deep_breath_main_t>( "deep_breath_trigger", options_str );
      add_child( main_spell );

      channeled      = true;
      dot_duration   = data().duration();
      base_tick_time = 0.2_s;

      trigger_gcd = p->talent.scalecommander.maneuverability.ok() ? 1.5_s : 2_s;
      gcd_type    = p->talent.scalecommander.maneuverability.ok() ? gcd_haste_type::SPELL_HASTE : gcd_haste_type::NONE;
    }
  }

  void update_ready( timespan_t cd_duration ) override
  {
    if ( p()->buff.strafing_run->up() )
    {
      p()->buff.strafing_run->decrement();
    }
    else
    {
      evoker_spell_t::update_ready( cd_duration );
    }
  }

  void reset() override
  {
    // Reset max charges to initial value, since it can get out of sync when previous iteration ends with charge-giving
    // buffs up. Do this before calling reset as that will also reset the cooldown.
    cooldown->charges = data().charges();
    evoker_spell_t::reset();
  }

  void last_tick( dot_t* d ) override
  {
    evoker_spell_t::last_tick( d );

    if ( p()->talent.imminent_destruction.ok() )
    {
      p()->buff.imminent_destruction->trigger();
    }

    if ( p()->talent.scalecommander.command_squadron.enabled() )
    {
      for ( auto& pet : p()->pets.commando_pet.active_pets() )
      {
        pet->finish_flying();
      }
    }
  }

  void execute() override
  {
    auto is_strafing_run = p()->buff.strafing_run->up();

    evoker_spell_t::execute();
    main_spell->execute();

    if ( !( p()->talent.scalecommander.maneuverability.ok() &&
            p()->talent.scalecommander.command_squadron.enabled() ) &&
         p()->talent.imminent_destruction.ok() )
    {
      p()->buff.imminent_destruction->trigger();
    }

    if ( p()->talent.strafing_run.enabled() && !is_strafing_run )
    {
      p()->buff.strafing_run->trigger();
    }

    if ( is_precombat )
    {
      start_gcd();
      player->last_foreground_action = this;
      auto delay                     = std::max(
          0_s, rng().gauss( p()->option.prepull_deep_breath_delay, p()->option.prepull_deep_breath_delay_stddev ) );
      player->gcd_ready = delay;
      stats->iteration_total_execute_time += delay;
    }
  }
};

struct disintegrate_t : public essence_spell_t
{
  eternity_surge_t::eternity_surge_damage_t* eternity_surge;
  int num_ticks;
  double mass_disint_mult;

  std::vector<dot_t*> current_dots;

  double consume_flame_mul;
  timespan_t consume_flame_duration;
  int mass_disint_targets;
  disintegrate_t( evoker_t* p, std::string_view options_str )
    : essence_spell_t( "disintegrate", p,
                       p->talent.eruption.ok() ? spell_data_t::not_found() : p->find_class_spell( "Disintegrate" ),
                       options_str ),
      num_ticks( 0 ),
      mass_disint_mult( p->talent.scalecommander.mass_disintegrate->effectN( 2 ).percent() ),
      current_dots(),
      consume_flame_mul( p->talent.flameshaper.consume_flame->effectN( 4 ).percent() ),
      consume_flame_duration( p->talent.flameshaper.consume_flame->effectN( 2 ).time_value() ),
      mass_disint_targets( as<int>( p->talent.scalecommander.mass_disintegrate->effectN( 1 ).base_value() ) )
  {
    channeled = tick_zero = true;

    if ( data().ok() )
      num_ticks =
          as<int>( dot_duration.base / base_tick_time.base + 1 + p->talent.azure_celerity->effectN( 3 ).base_value() );
    else
      num_ticks = as<int>( 1 + p->talent.azure_celerity->effectN( 3 ).base_value() );

    if ( p->bugs )
    {
      dot_duration = base_tick_time * ( num_ticks - 1 );
    }

    auto surge = p->get_secondary_action<eternity_surge_t::eternity_surge_damage_t>( "scintillation", "scintillation" );
    surge->not_a_proc         = true;
    surge->s_data_reporting   = p->talent.scintillation;
    surge->name_str_reporting = "scintillation";
    surge->proc_spell_type    = proc_spell_type_e::SCINTILLATION;
    eternity_surge            = surge;

    // Not in Spell Data, However it would appear to proc class ability related effects. Primarily made to Fix Irideus
    // Fragment Bug - TODO: Review for other class based procs.
    allow_class_ability_procs = true;

    // 25/11/2022 - Override the lag handling for Disintegrate so that it doesn't use channeled ready behavior
    //              In-game tests have shown it is possible to cast after faster than the 250ms channel_lag using a
    //              nochannel macro
    ability_lag = p->world_lag;

    if ( p->talent.feed_the_flames.ok() )
    {
      add_parse_entry( target_multiplier_effects )
          .set_func( d_fn( &evoker_td_t::debuffs_t::in_firestorm, false ) )
          .set_value( p->talent.feed_the_flames->effectN( 1 ).percent() )
          .set_eff( &p->talent.feed_the_flames->effectN( 1 ) );
    }

    add_child( eternity_surge );
  }

  void cancel_buff_helpers()
  {
    p()->buff.mass_disintegrate_ticks->expire();
    p()->buff.essence_burst_titanic_wrath_disintegrate->expire();
    p()->buff.iridescence_red->expire();
  }

  int max_targets() const
  {
    // TODO: Check if the additional target actually increases ST when its missing.
    return ( p()->buff.mass_disintegrate_stacks->check() > 0 ) * mass_disint_targets;
  }

  int targets() const
  {
    std::vector<player_t*>& tl = target_list();
    const int tl_size          = as<int>( tl.size() );

    return std::min( max_targets(), tl_size );
  }

  void cancel() override
  {
    for ( auto dot : current_dots )
    {
      dot->cancel();
    }
    
    cancel_buff_helpers();
    current_dots.clear();

    essence_spell_t::cancel();
  }

  void interrupt_action() override
  {
    essence_spell_t::interrupt_action();

    for ( auto dot : current_dots )
    {
      dot->cancel();
    }
    
    cancel_buff_helpers();
  }

  void reset() override
  {
    essence_spell_t::reset();
    current_dots.clear();
  }

  void execute() override
  {
    current_dots.clear();

    for ( auto enemy : target_list() )
    {
      if ( get_dot( enemy )->is_ticking() )
      {
        current_dots.push_back( get_dot( enemy ) );
      }
    }

    action_state_t* state = get_state( pre_execute_state );

    snapshot_state( state, result_amount_type::NONE );
    state->target = target;

    timespan_t buff_duration = composite_dot_duration( state ) + 1_s;

    action_state_t::release( state );

    int targets_ = targets();
    targets_     = targets_ ? targets_ : 1;

    int virtual_buff_stacks = num_ticks * targets_;

    // trigger the buffs first so tick-zero can get buffed
    if ( p()->buff.essence_burst->check() )
      p()->buff.essence_burst_titanic_wrath_disintegrate->trigger( virtual_buff_stacks, buff_duration );

    if ( p()->buff.iridescence_blue->check() )
      p()->buff.iridescence_blue_disintegrate->trigger( virtual_buff_stacks, buff_duration );

    if ( p()->buff.mass_disintegrate_stacks->check() )
    {
      int max_targets_ = max_targets();
      max_targets_     = max_targets_ ? max_targets_ : 1;

      auto buff_size = ( max_targets_ - targets_ ) * mass_disint_mult;
      buff_size      = buff_size > 0 ? buff_size : 0;
      p()->buff.mass_disintegrate_ticks->trigger( num_ticks, buff_size, -1, buff_duration );

      if ( sim->dbc->wowv() >= wowv_t( 12, 1, 0 ) )
      {
        timespan_t cdr = p()->talent.scalecommander.wingleader->effectN( 1 ).time_value() * targets_;
        p()->cooldown.deep_breath->adjust( -cdr );
      }
    }

    essence_spell_t::execute();
  }

  int n_targets() const override
  {
    return targets();
  }

  void impact( action_state_t* s ) override
  {
    essence_spell_t::impact( s );

    if ( p()->talent.scalecommander.bombardments.ok() && p()->buff.mass_disintegrate_stacks->check() &&
         s->chain_target == 0 )
    {
      p()->apply_bombardments( s->target );
    }

    if ( s->chain_target == 0 )
      p()->buff.mass_disintegrate_stacks->decrement();
  }

  double composite_ta_multiplier( const action_state_t* s ) const override
  {
    auto ta = essence_spell_t::composite_ta_multiplier( s );

    if ( p()->buff.essence_burst_titanic_wrath_disintegrate->check() )
      ta *= 1.0 + titanic_mul;

    ta *= 1.0 + p()->buff.iridescence_blue_disintegrate->check_value();

    ta *= 1.0 + p()->buff.mass_disintegrate_ticks->check_value();

    return ta;
  }

  void trigger_dot( action_state_t* s ) override
  {
    dot_t* d                = get_dot( s->target );
    timespan_t tick_remains = d->time_to_next_full_tick();
    timespan_t tt           = tick_time( s );
    int ticks               = 0;

    if ( !d->is_ticking() )
    {
      current_dots.push_back( d );
    }

    essence_spell_t::trigger_dot( s );

    // Disint channel duration is a bit fuzzy, it will go above or below the
    // standard duration to make sure it has the correct number of ticks.
    ticks += as<int>( std::round( ( d->remains() - tick_remains ) / tt ) );
    timespan_t new_remains = ticks * tt + tick_remains;

    d->adjust_duration( new_remains - d->remains() );
  }

  void last_tick( dot_t* d ) override
  {
    range::erase_remove( current_dots, d );

    if ( current_dots.size() == 0 )
    {
      p()->buff.mass_disintegrate_ticks->expire();
      essence_spell_t::last_tick( d );
    }
    else
    {
      target = current_dots[ 0 ]->target;
    }
  }

  void tick( dot_t* d ) override
  {
    essence_spell_t::tick( d );

    p()->trigger_aura_applied_callbacks( proc_data, p() );

    bool is_main_tick = current_dots[ 0 ] == d && ( p()->buff.mass_disintegrate_ticks->check() > 1 || current_dots.size() == 1 );

    if ( is_main_tick )
    {
      p()->buff.mass_disintegrate_ticks->decrement();
    }
    else
    {
      stats->iteration_total_tick_time -= d->time_to_tick();
    }

    p()->buff.essence_burst_titanic_wrath_disintegrate->decrement();
    p()->buff.iridescence_blue_disintegrate->decrement();

    if ( p()->talent.scintillation.ok() && rng().roll( p()->talent.scintillation->effectN( 2 ).percent() ) )
    {
      auto emp_state    = eternity_surge->get_state();
      emp_state->target = d->state->target;
      eternity_surge->snapshot_state( emp_state, eternity_surge->amount_type( emp_state ) );
      emp_state->persistent_multiplier *= p()->talent.scintillation->effectN( 1 ).percent();
      eternity_surge->cast_state( emp_state )->empower = EMPOWER_1;

      eternity_surge->schedule_execute( emp_state );
    }

    if ( p()->action.obsidian_shards )
    {
      residual_action::trigger( p()->action.obsidian_shards, d->state->target,
                                d->state->result_amount * obsidian_shards_mul );
    }

    if ( p()->action.enkindle )
    {
      residual_action::trigger( p()->action.enkindle, d->state->target,
                                d->state->result_amount * enkindle_mul *
                                    ( 1.0 + p()->buff.inner_flame->stack() *
                                              p()->talent.flameshaper.inner_flame_buff->effectN( 2 ).percent() ) );
    }

    if ( p()->talent.causality.ok() && is_main_tick )
    {
      auto cdr = p()->talent.causality->effectN( 1 ).time_value();
      p()->cooldown.eternity_surge->adjust( cdr );
      p()->cooldown.fire_breath->adjust( cdr );
    }

    if ( p()->talent.flameshaper.consume_flame.enabled() )
    {
      auto dot = p()->get_target_data( d->state->target )->dots.fire_breath;
      handle_consume_flame( dot, consume_flame_duration, consume_flame_mul );
    }
  }
};

struct expunge_t : public evoker_spell_t
{
  expunge_t( evoker_t* p, std::string_view options_str )
    : evoker_spell_t( "expunge", p, p->talent.expunge, options_str )
  {
  }
};

struct firestorm_t : public evoker_spell_t
{
  struct firestorm_tick_t : public evoker_spell_t
  {
    firestorm_tick_t( evoker_t* p ) : evoker_spell_t( "firestorm_tick", p, p->find_spell( 369374 ) )
    {
      dual = ground_aoe = background = true;
      aoe                            = -1;
    }
  };

  action_t* damage;
  timespan_t tick_period;
  timespan_t duration;

  firestorm_t( evoker_t* p ) : evoker_spell_t( "firestorm", p, p->find_spell( 368847 ) ), tick_period(), duration()
  {
    damage        = p->get_secondary_action<firestorm_tick_t>( "firestorm_tick" );
    damage->stats = stats;
    damage->proc  = true;
    proc          = true;

    tick_period = find_effect( p->find_spell( 456657 ), A_PERIODIC_DAMAGE ).period();
    duration    = data().effectN( 1 ).trigger()->duration();
  }

  void execute() override
  {
    evoker_spell_t::execute();

    if ( duration > 0_s && tick_period > 0_s )
    {
      auto total_ticks = as<int>( std::floor( duration / tick_period ) + 1 );

      make_event<ground_aoe_event_t>(
          *sim, p(),
          ground_aoe_params_t()
              .target( execute_state->target )
              .pulse_time( tick_period )
              .hasted( ground_aoe_params_t::hasted_with::SPELL_HASTE )
              .n_pulses( total_ticks )
              .action( damage )
              .state_callback( [ this ]( ground_aoe_params_t::state_type s, ground_aoe_event_t* e ) {
                if ( s == ground_aoe_params_t::state_type::EVENT_STARTED )
                {
                  for ( player_t* t : e->params->action()->target_list() )
                  {
                    auto td = p()->get_target_data( t );
                    td->debuffs.in_firestorm->increment();
                  }
                }
                else if ( s == ground_aoe_params_t::state_type::EVENT_STOPPED )
                {
                  for ( player_t* t : e->params->action()->target_list() )
                  {
                    auto td = p()->get_target_data( t );
                    td->debuffs.in_firestorm->decrement();
                  }
                }
              } ),
          true );
    }
  }
};

struct fury_of_the_aspects_t : public evoker_spell_t
{
  fury_of_the_aspects_t( evoker_t* p, std::string_view options_str )
    : evoker_spell_t( "fury_of_the_aspects", p, p->find_class_spell( "Fury of the Aspects" ), options_str )
  {
  }

  void execute() override
  {
    evoker_spell_t::execute();

    if ( p()->talent.chronowarden.time_convergence.enabled() )
    {
      p()->buff.time_convergence_intellect->trigger();
    }
  }
};

struct hover_t : public evoker_spell_t
{
  hover_t( evoker_t* p, std::string_view options_str )
    : evoker_spell_t( "hover", p, p->find_class_spell( "Hover" ), options_str )
  {
    harmful              = false;
    usable_while_casting = true;
  }

  bool ready() override
  {
    if ( p()->last_foreground_action && p()->in_gcd() )
    {
      switch ( p()->last_foreground_action->id )
      {
        // DB SC
        case 433874:
          // DB
        case 357210:
          // Eons SC
        case 442204:
          // Eons
        case 403631:
          return false;
        default:
          break;
      }

      if ( dynamic_cast<empowered_release_spell_t*>( p()->last_foreground_action ) )
        return false;
    }

    return evoker_spell_t::ready();
  }

  void execute() override
  {
    evoker_spell_t::execute();

    p()->buff.hover->trigger();
  }
};

struct landslide_t : public evoker_spell_t
{
  landslide_t( evoker_t* p, std::string_view options_str )
    : evoker_spell_t( "landslide", p, p->talent.landslide, options_str )
  {
    // TODO: root NYI
  }
};

struct living_flame_t : public evoker_spell_t
{
  action_t* damage;
  action_t* heal;
  double gcd_mul;
  bool cast_heal;
  timespan_t prepull_timespent;
  double mana_return;
  int extra_hits_tww3_s4;

  living_flame_t( evoker_t* p, std::string_view options_str )
    : evoker_spell_t( "living_flame", p, p->find_class_spell( "Living Flame" ) ),
      gcd_mul( p->find_spelleffect( &p->buff.ancient_flame->data(), A_ADD_PCT_MODIFIER, P_GCD, &data() )->percent() ),
      cast_heal( false ),
      prepull_timespent( timespan_t::zero() ),
      mana_return( p->spec.energizing_flame->effectN( 1 ).percent() ),
      extra_hits_tww3_s4( p->sets->has_set_bonus( HERO_CHRONOWARDEN, TWW3, B4 )
                              ? as<int>( p->sets->set( HERO_CHRONOWARDEN, TWW3, B4 )->effectN( 3 ).base_value() )
                              : 0 )
  {
    damage        = p->get_secondary_action<living_flame_damage_t>( "living_flame_damage" );
    damage->stats = stats;

    if ( p->talent.chronowarden.chrono_flame.enabled() )
    {
      add_child( p->get_secondary_action<chrono_flame_damage_t>( "chrono_flame_living_flame" ) );
    }

    // TODO: implement option to cast heal instead
    heal = p->get_secondary_action<living_flame_heal_t>( "living_flame_heal" );

    add_option( opt_bool( "heal", cast_heal ) );
    parse_options( options_str );
  }

  bool has_amount_result() const override
  {
    return damage->has_amount_result();
  }

  timespan_t travel_time() const override
  {
    if ( is_precombat )
      return 1_ms;

    return evoker_spell_t::travel_time();
  }

  timespan_t gcd() const override
  {
    auto g = evoker_spell_t::gcd();

    if ( p()->buff.ancient_flame->check() && !p()->buff.burnout->check() )
      g *= 1.0 + gcd_mul;

    return std::max( min_gcd, g );
  }

  void execute() override
  {
    evoker_spell_t::execute();

    // Single child, update children to parent action on each precombat execute

    if ( is_precombat )
    {
      debug_cast<living_flame_damage_t*>( damage )->prepull_timespent = prepull_timespent;
      debug_cast<living_flame_heal_t*>( heal )->prepull_timespent     = prepull_timespent;
    }

    if ( !cast_heal )
    {
      p()->resource_gain( RESOURCE_MANA, cost() * mana_return, p()->gain.energizing_flame, this );
    }

    damage->execute_on_target( target );

    int total_damage_hits = damage->num_targets_hit;
    int total_heal_hits   = 0;

    if ( !p()->buff.burnout->up() )
      p()->buff.ancient_flame->expire();
    p()->buff.scarlet_adaptation->expire();

    if ( p()->buff.leaping_flames->up() && damage->num_targets_hit <= p()->buff.leaping_flames->check() )
    {
      if ( damage->num_targets_hit > 1 )
        p()->buff.leaping_flames->decrement( damage->num_targets_hit - 1 );

      while ( p()->buff.leaping_flames->check() )
      {
        // Leaping flames are hitting extra targets, the primary target is already a leaping flame used.
        p()->buff.leaping_flames->decrement( 1 );
        heal->execute_on_target( p() );
        if ( heal->num_targets_hit > 1 )
          p()->buff.leaping_flames->decrement( heal->num_targets_hit - 1 );
        for ( int i = 0; i < heal->num_targets_hit; i++ )
          if ( rng().roll( p()->option.heal_eb_chance ) )
            total_heal_hits++;
      }
    }

    // Make sure the buff is definitely gone.
    p()->buff.leaping_flames->expire();

    if ( p()->talent.pupil_of_alexstrasza.ok() )
    {
      // TODO: Auto handle dummy cleave values and damage effectiveness
      if ( !damage->target_cache.is_valid )
      {
        damage->available_targets( damage->target_cache.list );
        damage->target_cache.is_valid = true;
      }

      if ( damage->target_cache.list.size() > 1 )
      {
        damage->execute_on_target( damage->target_list()[ 1 ] );
        total_damage_hits++;
      }
    }

    if ( p()->sets->has_set_bonus( HERO_CHRONOWARDEN, TWW3, B4 ) && p()->buff.temporal_burst->check() )
    {
      if ( !damage->target_cache.is_valid )
      {
        damage->available_targets( damage->target_cache.list );
        damage->target_cache.is_valid = true;
      }

      int set_damage_hits = 0;

      if ( damage->target_cache.list.size() > 1 )
      {
        for ( int i = 1; i < extra_hits_tww3_s4 + 1 && i < as<int>( damage->target_cache.list.size() ); i++ )
        {
          damage->execute_on_target( damage->target_list()[ i ] );
          set_damage_hits++;
        }

        total_damage_hits += set_damage_hits;
      }
      if ( set_damage_hits < extra_hits_tww3_s4 )
      {
        for ( int i = 0; i < extra_hits_tww3_s4 - set_damage_hits; i++ )
        {
          heal->execute_on_target( p() );
          if ( rng().roll( p()->option.heal_eb_chance ) )
            total_heal_hits++;
        }
      }
    }

    if ( p()->talent.ruby_essence_burst.ok() )
    {
      double eb_chance =
          p()->talent.ruby_essence_burst->effectN( 1 ).percent() * ( 1.0 + p()->buff.inner_flame->check_stack_value() );

      for ( int i = 0; i < total_damage_hits; i++ )
      {
        if ( p()->buff.dragonrage->up() || rng().roll( eb_chance ) )
        {
          p()->buff.essence_burst->trigger();
          p()->proc.ruby_essence_burst->occur();
        }
      }

      for ( int i = 0; i < total_heal_hits; i++ )
      {
        if ( p()->buff.dragonrage->up() || rng().roll( eb_chance ) )
        {
          p()->buff.essence_burst->trigger();
          p()->proc.ruby_essence_burst->occur();
        }
      }
    }

    if ( p()->buff.burnout->up() )
      p()->buff.burnout->decrement();

    // Reset them after execute
    if ( is_precombat )
    {
      debug_cast<living_flame_damage_t*>( damage )->prepull_timespent = timespan_t::zero();
      debug_cast<living_flame_heal_t*>( heal )->prepull_timespent     = timespan_t::zero();
    }
  }
};

struct obsidian_scales_t : public evoker_spell_t
{
  obsidian_scales_t( evoker_t* p, std::string_view options_str )
    : evoker_spell_t( "obsidian_scales", p, p->talent.obsidian_scales, options_str )
  {
  }
};

struct obsidian_shards_t : public residual_action::residual_periodic_action_t<evoker_spell_t>
{
  double blazing_shards_mul;

  obsidian_shards_t( evoker_t* p )
    : residual_action_t( "obsidian_shards", p, p->find_spell( 409776 ) ),
      blazing_shards_mul( p->sets->set( EVOKER_DEVASTATION, DF2, B4 )->effectN( 3 ).percent() )
  {
  }

  double composite_ta_multiplier( const action_state_t* s ) const override
  {
    auto ta = residual_action_t::composite_ta_multiplier( s );

    if ( p()->buff.dragonrage->check() || p()->buff.blazing_shards->check() )
      ta *= 1.0 + blazing_shards_mul;

    return ta;
  }

  // Return Spell_t's multiplier as evoker's contains our mastery amp.
  double composite_target_multiplier( player_t* t ) const override
  {
    return spell_t::composite_target_multiplier( t );
  }

  void tick( dot_t* d ) override
  {
    residual_action_t::tick( d );

    p()->benefit.supercharged_shards->update( p()->buff.dragonrage->check() || p()->buff.blazing_shards->check() );
  }
};

struct oppressing_roar_t : public evoker_spell_t
{
  oppressing_roar_t( evoker_t* p, std::string_view options_str )
    : evoker_spell_t( "oppressing_roar", p, p->talent.oppressing_roar, options_str )
  {
  }

  void execute() override
  {
    evoker_spell_t::execute();

    if ( p()->talent.chronowarden.time_convergence.enabled() )
    {
      p()->buff.time_convergence_intellect->trigger();
    }
  }
};

struct quell_t : public evoker_spell_t
{
  quell_t( evoker_t* p, std::string_view options_str ) : evoker_spell_t( "quell", p, p->talent.quell, options_str )
  {
    may_miss = may_glance = may_block = may_dodge = may_parry = may_crit = harmful = false;
    ignore_false_positive = use_off_gcd = is_interrupt = true;
  }

  bool target_ready( player_t* t ) override
  {
    if ( !t->debuffs.casting->check() )
      return false;

    return evoker_spell_t::target_ready( t );
  }

  void execute() override
  {
    evoker_spell_t::execute();

    // always assume succes since action cannot be used unless target is casting
    if ( p()->talent.roar_of_exhilaration.ok() )
    {
      p()->resource_gain(
          RESOURCE_ESSENCE,
          p()->talent.roar_of_exhilaration->effectN( 1 ).trigger()->effectN( 1 ).resource( RESOURCE_ESSENCE ),
          p()->gain.roar_of_exhilaration );
    }
  }
};

struct time_spiral_t : public evoker_spell_t
{
  time_spiral_t( evoker_t* p, std::string_view options_str )
    : evoker_spell_t( "time_spiral", p, p->talent.time_spiral, options_str )
  {
  }

  void execute() override
  {
    evoker_spell_t::execute();

    if ( p()->talent.chronowarden.time_convergence.enabled() )
    {
      p()->buff.time_convergence_intellect->trigger();
    }
  }
};

struct tip_the_scales_t : public evoker_spell_t
{
  tip_the_scales_t( evoker_t* p, std::string_view options_str )
    : evoker_spell_t( "tip_the_scales", p, p->talent.tip_the_scales, options_str )
  {
  }

  bool ready() override
  {
    if ( p()->buff.tip_the_scales->check() )
      return false;

    return evoker_spell_t::ready();
  }

  void execute() override
  {
    evoker_spell_t::execute();

    cooldown->reset( false, 1 );

    p()->buff.tip_the_scales->trigger();

    if ( p()->talent.chronowarden.temporal_burst.ok() )
    {
      p()->buff.temporal_burst->trigger();
    }

    if ( p()->talent.chronowarden.time_convergence.enabled() )
    {
      p()->buff.time_convergence_intellect->trigger();
    }
  }
};

struct pyre_data_t
{
  double charged_blast;
  double essence_burst;
  double iridescence;

  friend void sc_format_to( const pyre_data_t& data, fmt::format_context::iterator out )
  {
    fmt::format_to( out, "charged_blast={}, essence_burst={}, iridescence={}", data.charged_blast, data.essence_burst,
                    data.iridescence );
  }
};

struct pyre_t : public essence_spell_t
{
  using state_t = evoker_action_state_t<pyre_data_t>;

  struct pyre_damage_t : public essence_spell_t
  {
    double consume_flame_mul;
    timespan_t consume_flame_duration;
    pyre_damage_t( evoker_t* p, std::string_view name_str )
      : essence_spell_t( name_str, p, p->find_spell( 357212 ) ),
        consume_flame_mul( p->talent.flameshaper.consume_flame->effectN( 7 ).percent() ),
        consume_flame_duration( p->talent.flameshaper.consume_flame->effectN( 3 ).time_value() )
    {
      dual = true;
      aoe  = -1;
    }

    action_state_t* new_state() override
    {
      return new state_t( this, target );
    }

    double composite_da_multiplier( const action_state_t* s ) const override
    {
      auto da = essence_spell_t::composite_da_multiplier( s );
      auto s_ = static_cast<const state_t*>( s );

      da *= 1.0 + s_->charged_blast;
      da *= 1.0 + s_->essence_burst;
      da *= 1.0 + s_->iridescence;

      return da;
    }

    void impact( action_state_t* s ) override
    {
      essence_spell_t::impact( s );

      if ( p()->talent.causality.ok() && s->chain_target == 0 )
      {
        auto cdr = std::min( 5u, s->n_targets ) * p()->talent.causality->effectN( 2 ).time_value();
        p()->cooldown.eternity_surge->adjust( cdr );
        p()->cooldown.fire_breath->adjust( cdr );
      }

      if ( p()->action.obsidian_shards )
        residual_action::trigger( p()->action.obsidian_shards, s->target, s->result_amount * obsidian_shards_mul );

      if ( p()->action.enkindle )
      {
        residual_action::trigger( p()->action.enkindle, s->target, s->result_amount * enkindle_mul );
      }

      if ( p()->talent.flameshaper.consume_flame.enabled() )
      {
        auto dot = p()->get_target_data( s->target )->dots.fire_breath;
        handle_consume_flame( dot, consume_flame_duration, consume_flame_mul );
      }
    }
  };

  action_t* volatility;
  action_t* damage;
  action_t* firestorm;

  pyre_t( evoker_t* p, std::string_view options_str ) : pyre_t( p, "pyre", p->talent.pyre, options_str )
  {
  }

  pyre_t( evoker_t* p, std::string_view n, const spell_data_t* s, std::string_view o = {} )
    : essence_spell_t( n, p, s, o ), volatility( nullptr )
  {
    damage        = p->get_secondary_action<pyre_damage_t>( name_str + "_damage", name_str + "_damage" );
    damage->stats = stats;
    damage->proc  = true;

    firestorm = p->get_secondary_action<firestorm_t>( "firestorm" );
  }

  action_state_t* new_state() override
  {
    return new state_t( this, target );
  }

  void init() override
  {
    essence_spell_t::init();

    if ( p()->talent.volatility.ok() )
    {
      if ( proc_spell_type & proc_spell_type_e::DRAGONRAGE )
        volatility = p()->action.volatility_dragonrage;
      else
        volatility = p()->action.volatility;

      if ( ( proc_spell_type & proc_spell_type_e::VOLATILITY ) == 0 )
        add_child( volatility );
    }

    if ( ( proc_spell_type & ( proc_spell_type_e::VOLATILITY | proc_spell_type_e::DRAGONRAGE ) ) == 0 )
      add_child( firestorm );
  }

  size_t available_targets( std::vector<player_t*>& target_list ) const override
  {
    target_list.clear();

    for ( auto& t : sim->target_non_sleeping_list )
    {
      if ( t == target && ( proc_spell_type & proc_spell_type_e::VOLATILITY ) != 0 )
        continue;

      target_list.push_back( t );
    }

    return target_list.size();
  }

  bool has_amount_result() const override
  {
    return damage->has_amount_result();
  }

  void execute() override
  {
    essence_spell_t::execute();
    p()->buff.charged_blast->expire();

    if ( p()->talent.feed_the_flames.enabled() && ( proc_spell_type & proc_spell_type_e::VOLATILITY ) == 0 )
    {
      p()->buff.feed_the_flames_stacking->trigger();
    }
  }

  void snapshot_state( action_state_t* s, result_amount_type rt ) override
  {
    essence_spell_t::snapshot_state( s, rt );

    auto s_ = static_cast<state_t*>( s );

    if ( ( proc_spell_type & proc_spell_type_e::VOLATILITY ) != 0 )
      return;

    s_->charged_blast = p()->buff.charged_blast->check_stack_value();
    s_->essence_burst = p()->buff.essence_burst->check() ? titanic_mul : 0.0;
    s_->iridescence   = p()->buff.iridescence_red->check_value();
  }

  void impact( action_state_t* s ) override
  {
    essence_spell_t::impact( s );

    if ( p()->buff.feed_the_flames_pyre->up() )
    {
      firestorm->execute_on_target( s->target );
      p()->buff.feed_the_flames_pyre->expire();
    }

    // The captured da mul is passed along to the damage action state.
    auto state = damage->get_state();
    state->copy_state( s );
    damage->snapshot_state( state, damage->amount_type( state ) );
    damage->schedule_execute( state );

    // TODO: How many times can volatility chain?
    if ( volatility && rng().roll( p()->talent.volatility->effectN( 1 ).percent() ) )
    {
      if ( volatility->target != s->target )
      {
        volatility->target                = s->target;
        volatility->target_cache.is_valid = false;
      }

      const auto& tl = volatility->target_list();
      if ( tl.size() > 0 )
        volatility->execute_on_target( tl[ rng().range( tl.size() ) ] );
    }
  }
};

struct dragonrage_t : public evoker_spell_t
{
  struct dragonrage_damage_t : public pyre_t
  {
    dragonrage_damage_t( evoker_t* p ) : pyre_t( p, "dragonrage_pyre", p->talent.dragonrage->effectN( 2 ).trigger() )
    {
      name_str_reporting = "pyre";
      s_data_reporting   = p->talent.pyre;

      // spell has 30yd range but the effect to launch pyre only has 25yd
      range = data().effectN( 1 ).radius();
      aoe   = as<int>( data().effectN( 1 ).base_value() );

      proc_spell_type = proc_spell_type_e::DRAGONRAGE;
      proc            = true;
    }

    std::vector<player_t*>& target_list() const override
    {
      auto& tl = pyre_t::target_list();

      if ( as<int>( tl.size() ) > n_targets() )
        rng().shuffle( tl.begin(), tl.end() );

      return tl;
    }
  };

  action_t* damage;
  unsigned max_targets;

  dragonrage_t( evoker_t* p, std::string_view options_str )
    : evoker_spell_t( "dragonrage", p, p->talent.dragonrage, options_str ),
      max_targets( as<unsigned>( data().effectN( 2 ).trigger()->effectN( 1 ).base_value() ) )
  {
    if ( !data().ok() )
      return;

    damage = p->get_secondary_action<dragonrage_damage_t>( "dragonrage_pyre" );
    add_child( damage );

    school = damage->school;
  }

  void execute() override
  {
    evoker_spell_t::execute();

    p()->buff.dragonrage->trigger();

    if ( p()->sets->has_set_bonus( EVOKER_DEVASTATION, DF3, B2 ) )
    {
      p()->buff.emerald_trance_stacking->trigger();
    }

    damage->execute_on_target( target );
  }
};

struct unbound_flame_t : public evoker_spell_t
{
  struct unbound_flame_damage_t : public evoker_spell_t
  {
    unbound_flame_damage_t( evoker_t* p )
      : evoker_spell_t( "unbound_flame_damage", p, p->talent.unbound_flame_spell->effectN( 1 ).trigger() )
    {
      dual                = true;
      aoe                 = -1;
      reduced_aoe_targets = 5;
      base_crit           = 1;
    }

    bool use_full_mastery() const override
    {
      return p()->talent.tyranny.ok();
    }
  };

  unbound_flame_t( evoker_t* p, std::string_view options_str )
    : evoker_spell_t( "unbound_flame", p, p->talent.unbound_flame_spell, options_str )
  {
    impact_action = p->get_secondary_action<unbound_flame_damage_t>( "unbound_flame_damage" );
    add_child( impact_action );
  }

  bool ready() override
  {
    if ( !p()->buff.unbound_flame->check() )
      return false;

    return evoker_spell_t::ready();
  }

  void execute() override
  {
    evoker_spell_t::execute();

    p()->buff.essence_burst->trigger();
    p()->buff.unbound_flame->decrement();
  }
};

struct fate_mirror_damage_t : public evoker_external_action_t<spell_t>
{
protected:
  using base = evoker_external_action_t<spell_t>;

public:
  fate_mirror_damage_t( player_t* p ) : base( "fate_mirror_damage", p, p->find_spell( 404908 ) )
  {
    may_dodge = may_parry = may_block = may_crit = false;
    background                                   = true;
  }

  double composite_da_multiplier( const action_state_t* s ) const override
  {
    return cast_state( s )->evoker->talent.fate_mirror->effectN( 1 ).percent() +
           cast_state( s )->evoker->buff.magnified_fate->check_value();
  }

  void init() override
  {
    spell_t::init();
    snapshot_flags &= STATE_NO_MULTIPLIER & ~STATE_TARGET;
    snapshot_flags |= STATE_MUL_SPELL_DA;
  }
};

struct fate_mirror_heal_t : public evoker_external_action_t<heal_t>
{
protected:
  using base = evoker_external_action_t<heal_t>;

public:
  fate_mirror_heal_t( player_t* p ) : base( "fate_mirror_heal", p, p->find_spell( 413786 ) )
  {
    may_dodge = may_parry = may_block = may_crit = false;
    background                                   = true;
  }

  double composite_da_multiplier( const action_state_t* s ) const override
  {
    return cast_state( s )->evoker->talent.fate_mirror->effectN( 1 ).percent();
  }

  void init() override
  {
    base::init();
    snapshot_flags &= STATE_NO_MULTIPLIER & ~STATE_TARGET;
    snapshot_flags |= STATE_MUL_SPELL_DA;
  }
};

struct infernos_blessing_t : public evoker_external_action_t<spell_t>
{
protected:
  using base = evoker_external_action_t<spell_t>;

public:
  infernos_blessing_t( player_t* p ) : base( "infernos_blessing", p, p->find_spell( 410265 ) )
  {
    may_dodge = may_parry = may_block = false;
    background                        = true;
    spell_power_mod.direct            = 2.69;  // Hardcoded for some reason, 29/12/2025
  }

  double composite_da_multiplier( const action_state_t* s ) const override
  {
    double da = base::composite_da_multiplier( s );

    da *= 1.0 + p( s )->talent.mighty_inferno->effectN( 1 ).percent();

    return da;
  }
};

struct breath_of_eons_damage_t : public evoker_external_action_t<spell_t>
{
protected:
  using base = evoker_external_action_t<spell_t>;

public:
  breath_of_eons_damage_t( player_t* p ) : base( "breath_of_eons_damage", p, p->find_spell( 409632 ) )
  {
    may_dodge = may_parry = may_block = false;
    background                        = true;
    base_crit += 1.0;
    base_crit_bonus = 0.0;
  }

  double composite_da_multiplier( const action_state_t* s ) const override
  {
    double m = p( s )->talent.temporal_wound->effectN( 1 ).percent();

    if ( p( s )->close_as_clutchmates )
      m *= 1.0 + p( s )->spec.close_as_clutchmates->effectN( 1 ).percent();

    int player_count = as<int>( p( s )->allies_with_my_ebon.size() );

    // Depower Breath of Eons in Raid Encounters
    if ( ( p( s ) == s->action->player && player_count > p( s )->spec.ebon_might->effectN( 3 ).base_value() &&
             p( s )->option.estimated_raid_dps_allies > player_count ) ||
         p( s )->option.force_raid )
    {
      player_count = p( s )->option.estimated_raid_dps_allies;
    }
    
    if ( player_count > p( s )->spec.ebon_might->effectN( 3 ).base_value() )
    {
      m *= p( s )->spec.ebon_might->effectN( 3 ).base_value() / player_count;
    }


    return m;
  }

  double composite_player_critical_multiplier( const action_state_t* ) const override
  {
    return 1.0;
  }

  void init() override
  {
    spell_t::init();
    snapshot_flags &= STATE_NO_MULTIPLIER;
    snapshot_flags |= STATE_MUL_SPELL_DA | STATE_CRIT;
  }
};

struct prescience_t : public evoker_augment_t
{
protected:
  double anachronism_chance;
  double double_time_mult;
  bool use_auto;

public:
  prescience_t( evoker_t* p, std::string_view options_str )
    : evoker_augment_t( "prescience", p, p->talent.prescience, options_str, false ),
      anachronism_chance(),
      double_time_mult(),
      use_auto( false )
  {
    anachronism_chance = p->talent.anachronism->effectN( 1 ).percent();
    double_time_mult   = p->talent.chronowarden.double_time->effectN( 2 ).percent();

    may_crit = p->talent.chronowarden.double_time.enabled();

    add_option( opt_bool( "use_auto", use_auto ) );
    parse_options( options_str );
  }

  void activate() override
  {
    evoker_augment_t::activate();

    for ( auto e : p()->allied_augmentations )
    {
      e->allied_prescience_callbacks.push_back( [ this, e ]() {
        sim->print_debug( "{} had target cache for prescience invalidated by {}", *p(), *e );
        target_cache.is_valid = false;
      } );
    }
  }

  void init_finished() override
  {
    evoker_augment_t::init_finished();

    if ( action_list && action_list->name_str == "assisted_combat" )
    {
      use_auto = true;
      sim->print_debug( "{} setting use_auto to true for action {} because it is in the assisted_combat action_list.",
                        *player, *this );
    }
  }

  void impact( action_state_t* s ) override
  {
    evoker_augment_t::impact( s );

    auto allied_aug_buffs =
        ( std::count_if( p()->allied_augmentations.begin(), p()->allied_augmentations.end(),
                         [ s ]( evoker_t* e ) { return e->get_target_data( s->target )->buffs.prescience->up(); } ) );

    sim->print_debug( "{} - {} has {} prescience buffs at impact.", *p(), *target, allied_aug_buffs );

    double prescience_value = p()->get_target_data( s->target )->buffs.prescience->default_value;

    if ( s->result == RESULT_CRIT )
    {
      prescience_value *= 1.0 + double_time_mult;
    }

    p()->get_target_data( s->target )->buffs.prescience->trigger( 1, prescience_value );

    if ( is_precombat )
    {
      cooldown->reset( 1 );
      for ( auto ally : p()->allies_with_my_prescience )
      {
        p()->get_target_data( ally )->buffs.prescience->extend_duration(
            ally == s->target ? -gcd() : -cooldown->cooldown_duration( cooldown ) );
      }
    }

    if ( p()->sets->has_set_bonus( EVOKER_AUGMENTATION, DF3, B2 ) )
    {
      p()->buff.t31_2pc_proc->expire();
      p()->buff.t31_2pc_stacks->trigger();
    }

    if ( p()->sets->has_set_bonus( EVOKER_AUGMENTATION, DF3, B4 ) )
    {
      p()->buff.trembling_earth->trigger( as<int>( p()->allies_with_my_prescience.size() ) );
    }
  }

  size_t available_targets( std::vector<player_t*>& target_list ) const override
  {
    target_list.clear();
    // Player must always be the first target.
    for ( const auto& t : sim->player_no_pet_list )
    {
      if ( t->is_sleeping() )
        continue;

      auto allied_aug_buffs =
          ( std::count_if( p()->allied_augmentations.begin(), p()->allied_augmentations.end(),
                           [ t ]( evoker_t* e ) { return e->get_target_data( t )->buffs.prescience->up(); } ) );

      if ( allied_aug_buffs >= 2 )
        continue;

      target_list.push_back( t );
    }

    return target_list.size();
  }

  bool ready() override
  {
    // Do not ever do this out of precombat, the order of entries in allies with my prescience is not preserved. During
    // precombat we can guarantee the first entry is the first buff because we do not allow the sim to cast prescience
    // if it would expire a prescience before the next cast, factoring in a gcds since you need time to make use of your
    // spell.
    if ( is_precombat && cooldown->up() )
      return p()->allies_with_my_prescience.empty() ||
             p()->get_target_data( p()->allies_with_my_prescience[ 0 ] )->buffs.prescience->remains() >
                 cooldown->cooldown_duration( cooldown ) + gcd() + 100_ms;

    return evoker_augment_t::ready();
  }
  bool target_ready( player_t* candidate_target ) override
  {
    auto allied_aug_buffs = ( std::count_if( p()->allied_augmentations.begin(), p()->allied_augmentations.end(),
                                             [ candidate_target ]( evoker_t* e ) {
                                               return e->get_target_data( candidate_target )->buffs.prescience->up();
                                             } ) );

    if ( allied_aug_buffs >= 2 )
    {
      return false;
    }

    return evoker_augment_t::target_ready( candidate_target );
  }

  void queue_execute( execute_type et ) override
  {
    auto allied_aug_buffs =
        ( std::count_if( p()->allied_augmentations.begin(), p()->allied_augmentations.end(),
                         [ this ]( evoker_t* e ) { return e->get_target_data( target )->buffs.prescience->up(); } ) );

    if ( allied_aug_buffs >= 2 )
    {
      if ( !select_target() )
      {
        sim->print_debug( "{} had action {} schedule on a invalid target. No valid targets remain.", *p(), name() );
      }
      else
      {
        sim->print_debug( "{} had action {} schedule on a invalid target. Retargeting action.", *p(), name() );
      }
    }

    evoker_augment_t::queue_execute( et );
  }

  bool select_target() override
  {
    if ( use_auto )
    {
      auto& tl = target_list();

      // first split into [has buff] vs [no buff]
      auto it = range::partition( tl, [ this ]( player_t* t ) {
        return !p()->get_target_data( t )->buffs.prescience->check();
      } );

      auto is_dps = []( player_t* p ) {
        return p->primary_role() != ROLE_HYBRID && p->primary_role() != ROLE_HEAL && p->primary_role() != ROLE_TANK &&
               p->specialization() != EVOKER_AUGMENTATION;
      };

      std::partition( tl.begin(), it, [ & ]( player_t* t ) { return is_dps( t ); } );
      std::partition( it, tl.end(), [ & ]( player_t* t ) { return is_dps( t ); } );

      target = tl.front();

      auto potential_target =
          std::find_if( tl.begin(), tl.end(), [ this ]( player_t* tar ) { return target_ready( tar ); } );

      if ( potential_target != tl.end() )
      {
        target = *potential_target;
        return true;
      }

      return false;
    }
    else
    {
      return action_t::select_target();
    }
  }

  void execute() override
  {
    auto allied_aug_buffs =
        ( std::count_if( p()->allied_augmentations.begin(), p()->allied_augmentations.end(),
                         [ this ]( evoker_t* e ) { return e->get_target_data( target )->buffs.prescience->up(); } ) );

    if ( allied_aug_buffs >= 2 )
    {
      target_cache.is_valid = false;

      if ( !select_target() )
      {
        sim->print_debug(
            "{} had action {} execute on a invalid target. No valid targets remain. Cancel execution of the action.",
            *p(), name() );

        return;
      }
      else
      {
        sim->print_debug( "{} had action {} execute on a invalid target. Retargeting action.", *p(), name() );

        // Update the sequence datas last executed spell to the new target
        if ( sim->collect_action_sequence && ( ( sim->iterations <= 1 && sim->current_iteration == 0 ) ||
                                               ( sim->iterations > 1 && player->nth_iteration() == 1 ) ) )
        {
          // Find the last action sequence entry that matches the current action
          auto& seq = player->collected_data.action_sequence;
          auto it   = std::find_if(
              seq.rbegin(), seq.rend(),
              [ this ]( const player_collected_data_t::action_sequence_data_t& s ) { return s.action == this; } );
          if ( it != seq.rend() )
            ( *it ).target = target;
        }
      }
    }

    allied_aug_buffs =
        ( std::count_if( p()->allied_augmentations.begin(), p()->allied_augmentations.end(),
                         [ this ]( evoker_t* e ) { return e->get_target_data( target )->buffs.prescience->up(); } ) );

    sim->print_debug( "{} - {} has {} prescience buffs at execute.", *p(), *target, allied_aug_buffs );

    evoker_augment_t::execute();

    if ( p()->talent.anachronism.ok() && rng().roll( anachronism_chance ) )
    {
      p()->buff.essence_burst->trigger();
      p()->proc.anachronism_essence_burst->occur();
    }
  }
};

struct blistering_scales_damage_t : public evoker_external_action_t<spell_t>
{
private:
  using base = evoker_external_action_t<spell_t>;

public:
  blistering_scales_damage_t( player_t* p ) : base( "blistering_scales_damage", p, p->find_spell( 360828 ) )
  {
    may_dodge = may_parry = may_block = false;
    background                        = true;
    aoe                               = -1;
    spell_power_mod.direct            = 0.3;  // Hardcoded for some reason, 19/05/2023
  }

  double composite_da_multiplier( const action_state_t* s ) const override
  {
    double da = base::composite_da_multiplier( s );

    da *= 1.0 + p( s )->buff.reactive_hide->check_stack_value();
    da *= 1.0 + p( s )->talent.regenerative_chitin->effectN( 2 ).percent();
    return da;
  }

  void execute() override
  {
    base::execute();

    if ( execute_state && p( execute_state )->talent.reactive_hide.ok() )
      p( execute_state )->buff.reactive_hide->trigger();
  }
};

struct breath_of_eons_t : public evoker_spell_t
{
  struct breath_of_eons_main_t : public evoker_spell_t
  {
    action_t* ebon;
    eruption_t* eruption;
    action_t* melt_armor_dot;
    cooldown_t* virtual_cooldown;
    upheaval_t::upheaval_damage_t* upheaval_set;
    breath_of_eons_main_t( evoker_t* p, std::string_view options_str )
      : evoker_spell_t( "breath_of_eons_trigger", p, p->talent.breath_of_eons, options_str ),
        ebon( nullptr ),
        eruption( nullptr ),
        melt_armor_dot( nullptr ),
        upheaval_set( nullptr )
    {
      //travel_delay = 0.9;   // guesstimate, TODO: confirm
      //travel_speed = 19.5;  // guesstimate, TODO: confirm

      travel_delay = 0;
      travel_speed = 0;

      trigger_gcd = p->talent.scalecommander.maneuverability.ok() ? 1.5_s : 2_s;
      gcd_type    = p->talent.scalecommander.maneuverability.ok() ? gcd_haste_type::SPELL_HASTE : gcd_haste_type::NONE;

      virtual_cooldown           = p->get_cooldown( "allied_virtual_cd_time", this );
      virtual_cooldown->duration = p->option.allied_virtual_cd_time;

      aoe = -1;

      if ( data().ok() )
      {
        if ( p->specialization() == EVOKER_AUGMENTATION )
          ebon = p->get_secondary_action<ebon_might_t>(
              "ebon_might_eons", p->talent.sands_of_time->effectN( 3 ).time_value(), "ebon_might_eons" );

        if ( p->talent.overlord.ok() )
        {
          eruption               = p->get_secondary_action<eruption_t>( "eruption_overlord", "eruption_overlord" );
          eruption->proc         = true;
          eruption->is_overlord  = true;
          eruption->motes_chance = p->talent.overlord->effectN( 2 ).percent();
          add_child( eruption );
        }

        if ( p->talent.scalecommander.maneuverability.ok() )
        {
          melt_armor_dot = p->get_secondary_action<melt_armor_dot_t>( "melt_armor_dot" );
          add_child( melt_armor_dot );
        }

        if ( p->sets->has_set_bonus( EVOKER_AUGMENTATION, TWW2, B2 ) )
        {
          upheaval_set = p->get_secondary_action<spells::upheaval_t::upheaval_damage_t>(
              "upheaval_tww2_2pc_eons", "upheaval_tww2_2pc_eons", false, true );

          add_child( upheaval_set );
        }
      }
    }

    void impact( action_state_t* s ) override
    {
      evoker_spell_t::impact( s );

      p()->get_target_data( s->target )->debuffs.temporal_wound->trigger();

      if ( eruption && s->chain_target < p()->talent.overlord->effectN( 1 ).base_value() )
      {
        // Hacky code to implement the overlord extending duplicate behaviour
        auto targets  = std::min( s->n_targets, as<unsigned int>( p()->talent.overlord->effectN( 1 ).base_value() ) );
        auto fraction = ( s->chain_target + 1.0 ) / targets;
        auto delay    = ( p()->gcd_ready - p()->sim->current_time() ) * fraction + 200_ms;

        make_event( sim, delay, [ this, s ] { eruption->execute_on_target( s->target ); } );
      }

      if ( p()->talent.scalecommander.melt_armor.ok() )
      {
        auto td = p()->get_target_data( s->target );
        td->debuffs.melt_armor->trigger();
      }

      if ( melt_armor_dot && s->chain_target == 0 )
      {
        melt_armor_dot->execute_on_target( s->target );
      }
    }

    void execute() override
    {
      if ( p()->talent.scalecommander.command_squadron.enabled() )
      {
        p()->pets.commando_pet.spawn( 4_s, 2 );
      }

      if ( p()->buff.ebon_might_self_buff->check() )
      {
        p()->extend_ebon( p()->talent.sands_of_time->effectN( 3 ).time_value() );
      }
      else if ( ebon )
      {
        ebon->execute();
      }

      evoker_spell_t::execute();

      if ( upheaval_set )
      {
        auto emp_state       = upheaval_set->get_state();
        emp_state->target    = target;
        upheaval_set->target = target;
        upheaval_set->snapshot_state( emp_state, upheaval_set->amount_type( emp_state ) );
        upheaval_set->cast_state( emp_state )->empower = EMPOWER_4;
        upheaval_set->schedule_execute( emp_state );
      }

      if ( p()->talent.chronowarden.time_convergence.enabled() )
      {
        p()->buff.time_convergence_intellect->trigger();
      }

      if ( virtual_cooldown )
      {
        virtual_cooldown->start();
      }

      if ( p()->talent.scalecommander.slipstream.ok() )
      {
        p()->cooldown.hover->reset( false, -1 );
      }
    }
  };

  action_t* main_spell;
  breath_of_eons_t( evoker_t* p, std::string_view options_str )
    : evoker_spell_t( "breath_of_eons", p,
                      p->talent.breath_of_eons.ok() ? p->talent.scalecommander.maneuverability.ok()
                                                          ? p->talent.scalecommander.maneuverability_breath_of_eons
                                                          : p->talent.breath_of_eons
                                                    : spell_data_t::not_found(),
                      options_str )
  {
    if ( data().ok() )
    {
      main_spell = p->get_secondary_action<breath_of_eons_main_t>( "breath_of_eons_trigger", options_str );
      add_child( main_spell );

      if ( p->talent.scalecommander.maneuverability.ok() && p->talent.scalecommander.command_squadron.enabled() )
      {
        channeled      = true;
        dot_duration   = data().duration();
        base_tick_time = data().effectN( 2 ).period();
      }

      trigger_gcd = p->talent.scalecommander.maneuverability.ok() ? 1.5_s : 2_s;
      gcd_type    = p->talent.scalecommander.maneuverability.ok() ? gcd_haste_type::SPELL_HASTE : gcd_haste_type::NONE;
    }
  }

  void eons_finished_effects()
  {
    if ( p()->talent.imminent_destruction.ok() )
    {
      p()->buff.imminent_destruction->trigger();
    }

    if ( p()->talent.scalecommander.command_squadron.enabled() )
    {
      for ( auto& pet : p()->pets.commando_pet.active_pets() )
      {
        pet->finish_flying();
      }
    }

    if ( p()->talent.duplicate1.enabled() )
    {
      p()->pets.duplicate_pet.spawn();
    }

    if ( p()->talent.plot_the_future.ok() )
    {
      auto plot_duration = timespan_t::from_seconds( p()->talent.plot_the_future->effectN( 1 ).base_value() );
      if ( p()->buffs.bloodlust->check() )
        p()->buffs.bloodlust->extend_duration( plot_duration );
      else if ( p()->buff.fury_of_the_aspects->check() )
        p()->buff.fury_of_the_aspects->extend_duration( plot_duration );
      else
      {
        p()->buff.fury_of_the_aspects->trigger( plot_duration );
        // Plots bloodlust re-triggers the buff for some reason.
        if ( p()->talent.chronowarden.time_convergence.enabled() )
        {
          p()->buff.time_convergence_intellect->trigger();
        }
      }
    }
  }

  void last_tick( dot_t* d ) override
  {
    evoker_spell_t::last_tick( d );

    eons_finished_effects();
  }

  void execute() override
  {
    evoker_spell_t::execute();
    main_spell->execute();

    if ( !channeled )
    {
      make_event( p()->sim, p()->gcd_ready - 1_ms - sim->current_time(), [ this ] { eons_finished_effects(); } );
    }

    if ( is_precombat )
    {
      start_gcd();
      player->last_foreground_action = this;
      auto delay                     = std::max(
          0_s, rng().gauss( p()->option.prepull_deep_breath_delay, p()->option.prepull_deep_breath_delay_stddev ) );
      player->gcd_ready = delay;
      stats->iteration_total_execute_time += delay;
    }
  }
};

struct time_skip_t : public evoker_spell_t
{
  time_skip_t( evoker_t* p, std::string_view options_str )
    : evoker_spell_t( "time_skip", p,
                      p->talent.interwoven_threads.ok() ? spell_data_t::not_found() : p->talent.time_skip, options_str )
  {
    target            = player;
    channeled         = true;
    hasted_ticks      = false;
    base_execute_time = 0_s;
    harmful           = false;
    dot_duration = base_tick_time = data().duration();

    // Adjust base tick time to allow for reasonably timed interrupt statements.
    base_tick_time = 250_ms;
  }

  void execute() override
  {
    evoker_spell_t::execute();
    p()->buff.time_skip->trigger();

    if ( p()->talent.chronowarden.time_convergence.enabled() )
    {
      p()->buff.time_convergence_intellect->trigger();
    }
  }

  void last_tick( dot_t* d ) override
  {
    evoker_spell_t::last_tick( d );
    p()->buff.time_skip->expire();
  }
};

// Flameshaper
struct consume_flame_t : evoker_spell_t
{
  consume_flame_t( evoker_t* p ) : evoker_spell_t( "consume_flame", p, p->talent.flameshaper.consume_flame_damage )
  {
  }

  void init() override
  {
    spell_t::init();
    snapshot_flags &= ~STATE_VERSATILITY;
    snapshot_flags |= STATE_TGT_MUL_DA;
    update_flags = snapshot_flags;
  }
};

struct enkindle_t : public residual_action::residual_periodic_action_t<evoker_spell_t>
{
  enkindle_t( evoker_t* p ) : residual_action_t( "enkindle", p, p->talent.flameshaper.enkindle_damage )
  {
  }

  // Return Spell_t's multiplier as evoker's contains our mastery amp.
  double composite_target_multiplier( player_t* t ) const override
  {
    return spell_t::composite_target_multiplier( t );
  }
};

struct essence_bomb_t : public evoker_spell_t
{
  essence_bomb_t( evoker_t* p ) : evoker_spell_t( "essence_bomb", p, p->talent.flameshaper.essence_bomb_spell )
  {
    background = true;

    aoe                 = -1;
    reduced_aoe_targets = 5;
  }
};

struct twin_flame_t : public evoker_spell_t
{
  twin_flame_t( evoker_t* p ) : evoker_spell_t( "twin_flame", p, p->talent.flameshaper.twin_flame_damage_spell )
  {
    background = true;

    aoe = p->talent.flameshaper.fire_torrent.enabled()
              ? 1 + as<int>( p->talent.flameshaper.fire_torrent->effectN( 1 ).base_value() )
              : 0;
  }
};

struct bombardments_damage_t : public evoker_external_action_t<spell_t>
{
protected:
  using base = evoker_external_action_t<spell_t>;
  double diverted_power_chance;
  target_specific_t<cooldown_t> cooldown_objects;

public:
  bool force_external;
  bombardments_damage_t( player_t* p )
    : base( "bombardments", p, p->find_spell( 434481 ) ),
      diverted_power_chance( 0.1 ),  // Reasonable guess. TODO: Get more accurate
      cooldown_objects{ false },
      force_external( false )
  {
    may_dodge = may_parry = may_block = false;
    background                        = true;
    aoe                               = -1;
    split_aoe_damage                  = true;

  }

  void init() override
  {
    base::init();
  }

  cooldown_t* get_cd_for_player( evoker_t* e )
  {
    if ( cooldown_objects[ e ] )
      return cooldown_objects[ e ];

    if ( e->talent.breath_of_eons.ok() )
    {
      cooldown_t* cd        = e->find_cooldown( "breath_of_eons" );
      cooldown_objects[ e ] = cd;
      return cd;
    }

    cooldown_t* cd        = e->find_cooldown( "deep_breath" );
    cooldown_objects[ e ] = cd;

    return cd;
  }

  bool use_full_mastery() const
  {
    return evoker && evoker->talent.tyranny.ok() && evoker->buff.dragonrage->check();
  }

  double composite_target_multiplier( player_t* t ) const override
  {
    double tm = base::composite_target_multiplier( t );

    if ( evoker )
    {
      auto td = evoker->get_target_data( t );

      if ( !evoker->bugs || ( player == evoker && !force_external ) )
      {
        if ( td && evoker->talent.molten_embers.enabled() && td->dots.fire_breath->is_ticking() )
        {
          tm *= 1.0 + evoker->spec.fire_breath_damage->effectN( 5 ).percent();
        }
      }

      if ( td && td->debuffs.melt_armor->check() )
      {
        tm *= 1.0 + td->debuffs.melt_armor->check_value();
      }

      if ( evoker->buff.ebon_might_self_buff->check() )
      {
        tm *= 1.0 + evoker->buff.ebon_might_self_buff->data().effectN( 1 ).percent();
      }

      // No mastery yet
      /* if ( evoker->specialization() == EVOKER_DEVASTATION )
      {
        if ( use_full_mastery() )
          tm *= 1.0 + evoker->cache.mastery_value();
        else
          tm *= 1.0 + evoker->cache.mastery_value() * std::max( 0.3, t->health_percentage() / 100 );
      }*/
    }

    return tm;
  }

  void impact( action_state_t* s ) override
  {
    base::impact( s );

    if ( sim->dbc->wowv() < wowv_t( 12, 1, 0 ) && p( s )->talent.scalecommander.wingleader.ok() &&
         s->chain_target == 0 )
    {
      cooldown_t* cd = get_cd_for_player( p( s ) );
      size_t idx     = p( s )->specialization() == EVOKER_AUGMENTATION ? 3 : 1;
      timespan_t cdr = -std::min( p( s )->talent.scalecommander.wingleader->effectN( idx ).time_value() * s->n_targets,
                                  p( s )->talent.scalecommander.wingleader->effectN( idx + 1 ).time_value() );
      cd->adjust( cdr );
    }
  }

  void execute() override
  {
    base::execute();

    if ( evoker && evoker->talent.scalecommander.diverted_power.ok() && rng().roll( diverted_power_chance ) )
    {
      evoker->buff.essence_burst->trigger();
      evoker->proc.diverted_power->occur();
    }
  }
};
}  // end namespace spells

// Namespace buffs post spells
namespace buffs
{

struct fate_mirror_cb_t : public dbc_proc_callback_t
{
  evoker_t* source;
  spells::fate_mirror_damage_t* fate_mirror_damage;
  spells::fate_mirror_heal_t* fate_mirror_heal;

  fate_mirror_cb_t( player_t* p, const special_effect_t& e, evoker_t* source )
    : dbc_proc_callback_t( p, e ), source( source )
  {
    allow_pet_procs = true;
    deactivate();
    initialize();

    fate_mirror_damage = debug_cast<spells::fate_mirror_damage_t*>( p->find_action( "fate_mirror_damage" ) );
    fate_mirror_heal   = debug_cast<spells::fate_mirror_heal_t*>( p->find_action( "fate_mirror_heal" ) );
  }

  evoker_t* p()
  {
    return source;
  }

  void execute( const spell_data_t*, player_t* t, action_state_t* s ) override
  {
    if ( t->is_sleeping() || !s )
      return;

    double da = s->result_amount;
    if ( da > 0 )
    {
      if ( t->is_enemy() )
      {
        fate_mirror_damage->evoker = source;
        fate_mirror_damage->execute_on_target( t, da );
      }
      else
      {
        // Tested 03/08/2023 Self Damage triggers the *healing effect*
        fate_mirror_heal->evoker = source;
        fate_mirror_heal->execute_on_target( t, da );
      }
    }
  }
};

struct infernos_blessing_cb_t : public dbc_proc_callback_t
{
  evoker_t* source;
  spells::infernos_blessing_t* infernos_blessing;

  infernos_blessing_cb_t( player_t* p, const special_effect_t& e, evoker_t* source )
    : dbc_proc_callback_t( p, e ), source( source )
  {
    allow_pet_procs = true;
    deactivate();
    initialize();

    infernos_blessing = debug_cast<spells::infernos_blessing_t*>( p->find_action( "infernos_blessing" ) );
  }

  void execute( const spell_data_t*, player_t* t, action_state_t* ) override
  {
    if ( t->is_sleeping() || !infernos_blessing )
      return;

    infernos_blessing->evoker = source;
    infernos_blessing->execute_on_target( t );
  }
};

struct blistering_scales_buff_t : public evoker_buff_t<buff_t>
{
private:
  using bb = evoker_buff_t<buff_t>;

  dbc_proc_callback_t* cb;
  stat_buff_t* armour;

  struct blistering_scales_cb_t : public dbc_proc_callback_t
  {
    evoker_t* source;
    spells::blistering_scales_damage_t* blistering_scales;
    stats_t* stats;

    blistering_scales_cb_t( player_t* p, const special_effect_t& e, evoker_t* source )
      : dbc_proc_callback_t( p, e ), source( source )
    {
      allow_pet_procs = true;
      deactivate();
      initialize();

      blistering_scales =
          debug_cast<spells::blistering_scales_damage_t*>( p->find_action( "blistering_scales_damage" ) );
    }

    evoker_t* p()
    {
      return source;
    }

    void execute( const spell_data_t*, player_t* t, action_state_t* s ) override
    {
      if ( t->is_sleeping() )
        return;

      if ( !p()->talent.blistering_scales.enabled() )
        p()->get_target_data( t )->buffs.blistering_scales->decrement();

      p()->sim->print_debug( "{}'s blistering scales detonates for action {} from {} targeting {}", *p(), *s->action,
                             *s->action->player, *t );

      blistering_scales->evoker = source;
      blistering_scales->execute_on_target( s->action->player );
    }
  };

  struct blistering_scales_armour_buff_t : evoker_buff_t<stat_buff_t>
  {
    blistering_scales_armour_buff_t( evoker_td_t& td, util::string_view name, const spell_data_t* s )
      : evoker_buff_t<stat_buff_t>( td, std::string( name ) + "_armour", s )
    {
      add_stat( STAT_BONUS_ARMOR, p()->composite_base_armor() * p()->talent.blistering_scales->effectN( 2 ).percent() );
      set_duration( 0_s );
      set_cooldown( 0_s );
      set_constant_behavior( buff_constant_behavior::NEVER_CONSTANT );

      if ( p()->talent.regenerative_chitin->ok() )
      {
        set_max_stack( 1 );
        set_initial_stack( 1 );
      }
    }
  };

public:
  blistering_scales_buff_t( evoker_td_t& td, util::string_view name, const spell_data_t* s ) : bb( td, name, s )
  {
    auto blistering_scales_effect          = new special_effect_t( td.target );
    blistering_scales_effect->name_str     = "blistering_scales_" + p()->name_str;
    blistering_scales_effect->type         = SPECIAL_EFFECT_EQUIP;
    blistering_scales_effect->spell_id     = p()->talent.blistering_scales->id();
    blistering_scales_effect->proc_flags2_ = PF2_ALL_HIT;
    blistering_scales_effect->cooldown_    = 2_s;  // Tested 27 / 05 / 2023
    td.target->special_effects.push_back( blistering_scales_effect );

    cb = new blistering_scales_cb_t( td.target, *blistering_scales_effect, p() );

    armour = new blistering_scales_armour_buff_t( td, name, s );

    set_cooldown( 0_s );
    set_constant_behavior( buff_constant_behavior::NEVER_CONSTANT );
    set_stack_change_callback( [ this ]( buff_t*, int, int new_ ) {
      if ( new_ )
      {
        cb->activate();
        armour->trigger();
      }
      else if ( !new_ )
      {
        cb->deactivate();
        armour->expire();
      }
    } );

    if ( p()->talent.regenerative_chitin->ok() )
    {
      set_max_stack( 1 );
      set_initial_stack( max_stack() );
    }
  }

  void update_stat( stat_buff_t* b, double amount )
  {
    if ( b->check() && b->stats[ 0 ].amount != amount )
    {
      b->stats[ 0 ].amount = amount;
      adjust_stats( b );
    }
  }

  double calc_armour()
  {
    return p()->composite_base_armor() * p()->talent.blistering_scales->effectN( 2 ).percent();
  }

  void adjust_stats( stat_buff_t* b )
  {
    for ( auto& buff_stat : b->stats )
    {
      if ( buff_stat.check_func && !buff_stat.check_func( *b ) )
        continue;

      b->update_player_buff_stat( buff_stat, b->current_stack );
    }
  }

  void update_armour_buff()
  {
    update_stat( armour, calc_armour() );
  }
};

struct prescience_buff_t : public evoker_buff_t<buff_t>
{
protected:
  using bb = evoker_buff_t<buff_t>;

public:
  prescience_buff_t( evoker_td_t& td )
    : bb( td, "prescience", static_cast<evoker_t*>( td.source )->talent.prescience_buff )
  {
    set_default_value( p()->talent.prescience->effectN( 1 ).percent() );
    set_pct_buff_type( STAT_PCT_BUFF_CRIT );
    set_chance( 1.0 );
    set_duration( p()->talent.prescience_buff->duration() *
                  ( 1.0 + p()->talent.chronowarden.golden_opportunity->effectN( 2 ).percent() ) );
  };

  timespan_t buff_duration() const override
  {
    timespan_t bd = bb::buff_duration();

    if ( p()->buff.t31_2pc_proc->check() )
    {
      bd *= 1.0 + p()->buff.t31_2pc_proc->check_value();
    }

    return bd;
  }
};

struct temporal_wound_buff_t : public evoker_buff_t<buff_t>
{
  target_specific_t<spells::breath_of_eons_damage_t> eon_actions;
  std::map<size_t, double> eon_stored;
  dbc_proc_callback_t* cb;

  struct temporal_wound_cb_t : public dbc_proc_callback_t
  {
    evoker_t* source;
    std::unique_ptr<dbc_proc_callback_t::trigger_fn_t> trig;

    temporal_wound_cb_t( player_t* p, const special_effect_t& e, evoker_t* source )
      : dbc_proc_callback_t( p, e ), source( source )
    {
      allow_pet_procs = true;
      deactivate();
      initialize();

      trigger_type = trigger_fn_type::CONDITION;

      const trigger_fn_t lambda = [ this ]( const dbc_proc_callback_t*, const proc_data_t&, player_t*,
                                            action_state_t* s, proc_trigger_type_e ) {
        if ( s->result_amount <= 0 )
          return false;

        if ( this->p() == s->action->player )
          return static_cast<bool>( this->p()->buff.ebon_might_self_buff->check() );

        return static_cast<bool>(
            this->p()->get_target_data( s->action->player->get_owner_or_self() )->buffs.ebon_might->check() );
      };

      trig = std::make_unique<dbc_proc_callback_t::trigger_fn_t>( lambda );

      trigger_fn = trig.get();
    }

    evoker_t* p()
    {
      return source;
    }

    void execute( const spell_data_t*, player_t* t, action_state_t* s ) override
    {
      if ( t->is_sleeping() )
        return;

      double da = s->result_amount;
      p()->sim->print_debug( "{} triggers {}s temporal wound on {} with {} dealing {}",
                             *s->action->player->get_owner_or_self(), *p(), *t, *s->action, da );
      if ( da > 0 )
      {
        buffs::temporal_wound_buff_t* buff =
            debug_cast<buffs::temporal_wound_buff_t*>( p()->get_target_data( t )->debuffs.temporal_wound );

        if ( buff && buff->up() )
        {
          buff->eon_stored[ buff->player_id( s->action->player->get_owner_or_self() ) ] += da;
          p()->sim->print_debug(
              "{} triggers {}s temporal wound on {} with {} dealing {} increasing stored damage to {} from {}",
              *s->action->player->get_owner_or_self(), *p(), *t, *s->action, da,
              buff->eon_stored[ buff->player_id( s->action->player->get_owner_or_self() ) ],
              buff->eon_stored[ buff->player_id( s->action->player->get_owner_or_self() ) ] - da );
        }
      }
    }
  };

  temporal_wound_buff_t( evoker_td_t& td, util::string_view name, const spell_data_t* s )
    : evoker_buff_t<buff_t>( td, name, s ), eon_actions{ false }
  {
    disable_ticking( true );

    auto temporal_wound_effect      = new special_effect_t( p() );
    temporal_wound_effect->name_str = "temporal_wound_" + p()->name_str;
    temporal_wound_effect->type     = SPECIAL_EFFECT_EQUIP;
    temporal_wound_effect->spell_id = p()->talent.temporal_wound->id();
    player->special_effects.push_back( temporal_wound_effect );

    cb = new temporal_wound_cb_t( player, *temporal_wound_effect, p() );
  }

  size_t player_id( player_t* p )
  {
    return p->actor_index;
  }

  // TODO: Stop using PID and just use the pointers.
  player_t* player_from_id( size_t i )
  {
    return sim->actor_list[ i ];
  }

  bool trigger( int stacks, double value, double chance, timespan_t duration ) override
  {
    if ( !evoker_buff_t::trigger( stacks, value, chance, duration ) )
      return false;

    if ( cb )
      cb->activate();

    return true;
  }

  spells::breath_of_eons_damage_t* get_eon_action( const player_t* target )
  {
    if ( eon_actions[ target ] != nullptr )
      return eon_actions[ target ];

    eon_actions[ target ] =
        debug_cast<spells::breath_of_eons_damage_t*>( target->find_action( "breath_of_eons_damage" ) );

    return eon_actions[ target ];
  }

  void reset() override
  {
    evoker_buff_t<buff_t>::reset();

    cb->deactivate();
  }

  void expire_override( int expiration_stacks, timespan_t remaining_duration ) override
  {
    buff_t::expire_override( expiration_stacks, remaining_duration );

    if ( cb )
      cb->deactivate();

    for ( auto& [ pid, damage ] : eon_stored )
    {
      auto pp            = player_from_id( pid );
      auto eon_damage    = get_eon_action( pp );
      eon_damage->evoker = p();
      sim->print_debug( "{} eon helper expiry, player {}s, size {}, damage execution inc, executing on {}", *source,
                        *pp, damage, *player );
      eon_damage->execute_on_target( player, damage );
    }
    eon_stored.clear();
  }
};

struct bombardments_buff_t : public evoker_buff_t<buff_t>
{
  struct bombardments_cb_t : public dbc_proc_callback_t
  {
    evoker_t* source;
    target_specific_t<spells::bombardments_damage_t> bombardments_actions;

    bombardments_cb_t( player_t* p, const special_effect_t& e, evoker_t* source )
      : dbc_proc_callback_t( p, e ), source( source ), bombardments_actions{ false }
    {
      // allow_pet_procs = true;
      deactivate();
      initialize();
    }

    evoker_t* p()
    {
      return source;
    }

    spells::bombardments_damage_t* get_bombardments_action( const player_t* target )
    {
      if ( bombardments_actions[ target ] != nullptr )
        return bombardments_actions[ target ];

      bombardments_actions[ target ] =
          debug_cast<spells::bombardments_damage_t*>( target->find_action( "bombardments" ) );

      return bombardments_actions[ target ];
    }

    void execute( const spell_data_t*, player_t* t, action_state_t* s ) override
    {
      if ( t->is_sleeping() )
        return;

      double da = s->result_amount;

      if ( da > 0 )
      {
        player_t* triggering_player = s->action->player->get_owner_or_self();
        auto damage_action          = get_bombardments_action( triggering_player );
        damage_action->evoker       = p();
        damage_action->execute_on_target( t );
      }
    }
  };
  using e_buff_t = evoker_buff_t<buff_t>;

  bombardments_cb_t* cb;
  bool use_bombardments_cb = false;
  rng::truncated_gauss_t gauss;
  double bombardments_external_chance;
  bombardments_buff_t( evoker_td_t& td, util::string_view name, const spell_data_t* s,
                       const spell_data_t* driver_spell )
    : e_buff_t( td, name, s ),
      gauss( p()->option.simulate_bombardments_time_between_procs_mean,
             p()->option.simulate_bombardments_time_between_procs_stddev,
             std::max( p()->option.simulate_bombardments_time_between_procs_stddev / 2, 0.033_s ) ),
      bombardments_external_chance( p()->specialization() == EVOKER_DEVASTATION ? 0.875 : 0.925 )
  {
    if ( !p()->option.simulate_bombardments )
      disable_ticking( true );

    set_refresh_behavior( buff_refresh_behavior::EXTEND );
    set_tick_behavior( buff_tick_behavior::REFRESH );

    set_cooldown( 0_s );
    set_chance( 1 );

    auto bombardments_effect                      = new special_effect_t( td.target );
    bombardments_effect->name_str                 = "bombardments_" + td.source->name_str;
    bombardments_effect->target_specific_cooldown = true;
    bombardments_effect->type                     = SPECIAL_EFFECT_EQUIP;
    bombardments_effect->spell_id                 = driver_spell->id();
    td.target->special_effects.push_back( bombardments_effect );

    cb = new bombardments_cb_t( td.target, *bombardments_effect, p() );

    use_bombardments_cb = !p()->option.simulate_bombardments;
    if ( p()->option.simulate_bombardments )
    {
      cb->deactivate();

      set_tick_time_callback( [ this ]( const buff_t*, unsigned ) { return rng().gauss( gauss ); } );
      set_tick_callback( [ this ]( buff_t*, int, timespan_t ) { fake_execute(); } );
    }
  }

  void fake_execute()
  {
    auto cd = cb->get_cooldown( player );
    assert( cd && "Bombardments CD Must Exist" );
    if ( cd->up() )
    {
      auto damage_action            = cb->get_bombardments_action( p() );
      damage_action->evoker         = p();
      damage_action->force_external = p()->bugs ? rng().roll( bombardments_external_chance ) : false;
      damage_action->execute_on_target( player );
      damage_action->force_external = false;
      cd->start();
    }
  }

  bool trigger( int stacks, double value, double chance, timespan_t duration ) override
  {
    if ( !e_buff_t::trigger( stacks, value, chance, duration ) )
      return false;

    if ( cb && use_bombardments_cb )
      cb->activate();

    return true;
  }

  void reset() override
  {
    e_buff_t::reset();

    cb->deactivate();
  }

  void expire_override( int expiration_stacks, timespan_t remaining_duration ) override
  {
    e_buff_t::expire_override( expiration_stacks, remaining_duration );

    if ( cb )
      cb->deactivate();
  }
};

}  // namespace buffs

// Namespace spells again
namespace spells
{

struct blistering_scales_t : public evoker_augment_t
{
  blistering_scales_t( evoker_t* p, std::string_view options_str )
    : evoker_augment_t( "blistering_scales", p, p->talent.blistering_scales, options_str )
  {
  }

  void impact( action_state_t* s ) override
  {
    evoker_augment_t::impact( s );

    if ( p()->last_scales_target )
      p()->get_target_data( p()->last_scales_target )->buffs.blistering_scales->expire();

    p()->last_scales_target = s->target;

    p()->get_target_data( s->target )->buffs.blistering_scales->trigger();

    debug_cast<buffs::blistering_scales_buff_t*>( p()->get_target_data( s->target )->buffs.blistering_scales )
        ->update_armour_buff();
  }
};

}  // namespace spells

// ==========================================================================
// Evoker Character Definitions
// ==========================================================================

evoker_td_t::evoker_td_t( player_t* target, evoker_t* evoker )
  : actor_target_data_t( target, evoker ), dots(), debuffs(), buffs()
{
  dots.fire_breath  = target->get_dot( "fire_breath_damage", evoker );
  dots.disintegrate = target->get_dot( "disintegrate", evoker );
  dots.enkindle     = target->get_dot( "enkindle", evoker );
  dots.living_flame = target->get_dot( "living_flame_damage", evoker );
  dots.melt_armor   = target->get_dot( "melt_armor_dot", evoker );

  debuffs.in_firestorm = make_buff_fallback( evoker->talent.feed_the_flames.ok(), *this, "in_firestorm" )
                             ->set_max_stack( 20 )
                             ->set_duration( 0_ms );

  debuffs.melt_armor = make_buff_fallback( evoker->talent.scalecommander.melt_armor.ok(), *this, "melt_armor",
                                           evoker->talent.scalecommander.melt_armor_debuff )
                           ->set_default_value_from_effect( 2, 0.01 )
                           ->set_refresh_behavior( buff_refresh_behavior::EXTEND );

  debuffs.bombardments = make_buff_fallback<buffs::bombardments_buff_t>(
      evoker->talent.scalecommander.bombardments, *this, "bombardments",
      evoker->talent.scalecommander.bombardments_debuff, evoker->talent.scalecommander.bombardments_driver );

  bool make_unbound_surge = evoker->naszuro && !target->is_enemy() && !target->is_pet();
  buffs.unbound_surge = make_buff_fallback<stat_buff_t>( make_unbound_surge, *this, "unbound_surge_" + evoker->name_str,
                                                         evoker->find_spell( 403275 ),
                                                         evoker->naszuro ? evoker->naszuro->item : nullptr );
  if ( make_unbound_surge )
  {
    buffs.unbound_surge->disable_ticking( true );

    switch ( evoker->specialization() )
    {
      case EVOKER_DEVASTATION:
        buffs.unbound_surge->set_duration(
            timespan_t::from_seconds( evoker->naszuro->driver()->effectN( 2 ).base_value() ) );
        break;
      case EVOKER_PRESERVATION:
        buffs.unbound_surge->set_duration(
            timespan_t::from_seconds( evoker->naszuro->driver()->effectN( 3 ).base_value() ) );
        break;
      case EVOKER_AUGMENTATION:
        buffs.unbound_surge->set_duration(
            timespan_t::from_seconds( evoker->naszuro->driver()->effectN( 4 ).base_value() ) );
        break;
      default:
        break;
    }

    if ( evoker->option.naszuro_bounce_chance > 0 && evoker->option.naszuro_accurate_behaviour )
    {
      buffs.unbound_surge->set_period( 3_s );
      if ( auto* _target = dynamic_cast<evoker_t*>( target ) )
      {
        buffs.unbound_surge->set_tick_callback(
            [ _target, evoker ]( buff_t* b, int /*current_tick*/, timespan_t /*tick_time*/ ) {
              {
                if ( b->remains() > 0_s && !_target->buff.dragonrage->check() &&
                     _target->rng().roll( evoker->option.naszuro_bounce_chance ) )
                  make_event( _target->sim, [ _target, evoker, b ] {
                    timespan_t remains = b->remains();
                    b->expire();
                    evoker->bounce_naszuro( _target, remains );
                  } );
              }
            } );
      }
      else
      {
        buffs.unbound_surge->set_tick_callback(
            [ target, evoker ]( buff_t* b, int /*current_tick*/, timespan_t /*tick_time*/ ) {
              {
                if ( b->remains() > 0_s && target->rng().roll( evoker->option.naszuro_bounce_chance ) )
                  make_event( target->sim, [ target, evoker, b ] {
                    timespan_t remains = b->remains();
                    b->expire();
                    evoker->bounce_naszuro( target, remains );
                  } );
              }
            } );
      }
    }
  }

  using e_buff_t = buffs::evoker_buff_t<buff_t>;
  using namespace buffs;

  bool is_aug  = evoker->specialization() == EVOKER_AUGMENTATION;
  bool is_ally = is_aug && !target->is_enemy() && !target->is_pet();

  bool make_temporal_wound = is_aug && evoker->talent.breath_of_eons.ok() && target->is_enemy();
  debuffs.temporal_wound   = make_buff_fallback<temporal_wound_buff_t>( make_temporal_wound, *this, "temporal_wound",
                                                                        evoker->talent.temporal_wound );

  buffs.shifting_sands = make_buff_fallback<e_buff_t>( is_ally, *this, "shifting_sands", evoker->find_spell( 413984 ) )
                             ->set_stack_change_callback( [ evoker, target ]( buff_t*, int, int _new ) {
                               if ( _new )
                               {
                                 evoker->allies_with_my_shifting_sands.push_back( target );
                               }
                               else
                               {
                                 evoker->allies_with_my_shifting_sands.find_and_erase_unordered( target );
                               }
                             } );

  buffs.symbiotic_bloom =
      make_buff_fallback<e_buff_t>( is_ally, *this, "symbiotic_bloom", evoker->find_spell( 410686 ) )
          ->set_default_value_from_effect( 1, 0.01 );

  if ( is_ally )
  {
    buffs.shifting_sands->set_default_value( 0.0 )
        ->set_pct_buff_type( STAT_PCT_BUFF_VERSATILITY )
        ->set_tick_callback( [ evoker ]( buff_t* b, int, timespan_t ) {
          if ( b->current_value != evoker->cache.mastery_value() )
          {
            b->current_value = evoker->cache.mastery_value();
            b->invalidate_cache();
          }
        } )
        ->set_freeze_stacks( true );
  }

  buffs.ebon_might =
      make_buff_fallback<evoker_buff_t<stat_buff_t>>( is_ally, *this, "ebon_might", evoker->find_spell( 395152 ) );
  if ( is_ally )
  {
    debug_cast<stat_buff_t*>( buffs.ebon_might )->set_stat_from_effect( 2, 0 );

    buffs.ebon_might->set_cooldown( 0_ms )
        ->disable_ticking( true )
        ->set_refresh_behavior( buff_refresh_behavior::PANDEMIC )
        ->add_invalidate( CACHE_STR_AGI_INT )
        ->set_stack_change_callback( [ target, evoker ]( buff_t* b, int, int new_ ) {
          if ( new_ )
          {
            evoker->allies_with_my_ebon.push_back( target );
            if ( auto e = dynamic_cast<evoker_t*>( target ) )
            {
              e->allied_ebons_on_me.push_back( b );
            }
          }
          else
          {
            evoker->allies_with_my_ebon.find_and_erase_unordered( target );
            if ( auto e = dynamic_cast<evoker_t*>( target ) )
            {
              range::erase_remove( e->allied_ebons_on_me, b );
            }
          }
          for ( auto& c : evoker->allied_ebon_callbacks )
          {
            c();
          }
        } );
  }

  buffs.prescience = make_buff_fallback<prescience_buff_t>( is_ally, *this, "prescience" );

  // TODO: Move into the buff itself
  if ( is_ally && evoker->talent.fate_mirror.ok() )
  {
    auto fate_mirror_effect          = new special_effect_t( target );
    fate_mirror_effect->name_str     = "fate_mirror_" + evoker->name_str;
    fate_mirror_effect->type         = SPECIAL_EFFECT_EQUIP;
    fate_mirror_effect->spell_id     = evoker->talent.prescience_buff->id();
    fate_mirror_effect->proc_flags2_ = PF2_ALL_HIT | PF2_PERIODIC_DAMAGE | PF2_PERIODIC_HEAL;
    if ( evoker->talent.prescience_buff->effect_count() > 2 )
    {
      fate_mirror_effect->proc_chance_ = evoker->talent.prescience_buff->effectN( 3 ).percent();
    }
    target->special_effects.push_back( fate_mirror_effect );

    auto fate_mirror_cb = new fate_mirror_cb_t( target, *fate_mirror_effect, evoker );

    buffs.prescience->set_stack_change_callback( [ fate_mirror_cb, target, evoker ]( buff_t*, int, int new_ ) {
      if ( new_ )
      {
        fate_mirror_cb->activate();
        evoker->allies_with_my_prescience.push_back( target );
      }
      else
      {
        fate_mirror_cb->deactivate();
        evoker->allies_with_my_prescience.find_and_erase_unordered( target );
      }
      for ( auto& c : evoker->allied_prescience_callbacks )
      {
        c();
      }
    } );
  }
  else
  {
    buffs.prescience->set_stack_change_callback( [ target, evoker ]( buff_t*, int /*old_stack*/, int new_stack ) {
      if ( new_stack )
      {
        evoker->allies_with_my_prescience.push_back( target );
      }
      else
      {
        evoker->allies_with_my_prescience.find_and_erase_unordered( target );
      }
      for ( auto& c : evoker->allied_prescience_callbacks )
      {
        c();
      }
    } );
  }

  bool make_blistering_scales = is_ally && evoker->talent.blistering_scales.ok();
  buffs.blistering_scales     = make_buff_fallback<blistering_scales_buff_t>(
      make_blistering_scales, *this, "blistering_scales", evoker->talent.blistering_scales );

  bool make_infernos_blessing = is_ally && evoker->talent.infernos_blessing.ok();
  buffs.infernos_blessing     = make_buff_fallback<e_buff_t>( make_infernos_blessing, *this, "infernos_blessing",
                                                              evoker->talent.infernos_blessing_buff );
  if ( make_infernos_blessing )
  {
    auto infernos_blessing_effect      = new special_effect_t( target );
    infernos_blessing_effect->name_str = "infernos_blessing_" + target->name_str;
    infernos_blessing_effect->type     = SPECIAL_EFFECT_EQUIP;
    infernos_blessing_effect->spell_id = evoker->talent.infernos_blessing_buff->id();
    target->special_effects.push_back( infernos_blessing_effect );

    auto infernos_blessing_cb = new infernos_blessing_cb_t( target, *infernos_blessing_effect, evoker );

    buffs.infernos_blessing->set_stack_change_callback( [ evoker ]( buff_t* b, int, int new_ ) {
      if ( new_ )
      {
        evoker->active_infernos_blessings.push_back( b );
      }
      else
      {
        range::erase_remove( evoker->active_infernos_blessings, b );
      }
    } );

    infernos_blessing_cb->activate_with_buff( buffs.infernos_blessing );
  }
}

evoker_t::evoker_t( sim_t* sim, std::string_view name, race_e r )
  : player_t( sim, EVOKER, name, r ),
    allies_with_my_ebon(),
    allies_with_my_prescience(),
    allies_with_my_shifting_sands(),
    active_infernos_blessings(),
    allied_ebons_on_me(),
    allied_major_cds(),
    last_scales_target( nullptr ),
    was_empowering( false ),
    naszuro(),
    allied_augmentations(),
    allied_ebon_callbacks(),
    allied_prescience_callbacks(),
    heartbeat(),
    close_as_clutchmates( false ),
    option(),
    action(),
    buff(),
    spec(),
    talent(),
    benefit(),
    cooldown(),
    gain(),
    proc(),
    rppm(),
    uptime(),
    pets( this )
{
  cooldown.eternity_surge = get_cooldown( "eternity_surge" );
  cooldown.fire_breath    = get_cooldown( "fire_breath" );
  cooldown.firestorm      = get_cooldown( "firestorm" );
  cooldown.upheaval       = get_cooldown( "upheaval" );
  cooldown.breath_of_eons = get_cooldown( "breath_of_eons" );
  cooldown.tip_the_scales = get_cooldown( "tip_the_scales" );
  cooldown.hover          = get_cooldown( "hover" );
  cooldown.deep_breath    = get_cooldown( "deep_breath" );

  resource_regeneration             = regen_type::DYNAMIC;
  regen_caches[ CACHE_HASTE ]       = true;
  regen_caches[ CACHE_SPELL_HASTE ] = true;
}

// Kharnalex, The First Light ======================================================

void karnalex_the_first_light( special_effect_t& effect )
{
  using generic_proc_t = unique_gear::generic_proc_t;
  struct light_of_creation_t : public generic_proc_t
  {
    light_of_creation_t( const special_effect_t& e ) : generic_proc_t( e, "light_of_creation", e.driver() )
    {
      channeled = true;
    }

    bool usable_moving() const override
    {
      return false;
    }

    void execute() override
    {
      generic_proc_t::execute();
      event_t::cancel( player->readying );
      player->reset_auto_attacks( composite_dot_duration( execute_state ) );
    }

    evoker_t* p()
    {
      return static_cast<evoker_t*>( generic_proc_t::player );
    }

    evoker_t* p() const
    {
      return static_cast<evoker_t*>( generic_proc_t::player );
    }

    void tick( dot_t* d ) override
    {
      generic_proc_t::tick( d );

      // TODO: Do a better job of this. It's close enough for now but it still is awful, and the item doesn't have the
      // time properly added.
      stats->iteration_total_execute_time += d->time_to_tick();
    }

    void last_tick( dot_t* d ) override
    {
      bool was_channeling = player->channeling == this;
      generic_proc_t::last_tick( d );

      if ( was_channeling && !player->readying )
      {
        player->schedule_ready( rng().gauss( sim->channel_lag ) );
      }
    }

    double composite_target_multiplier( player_t* t ) const override
    {
      double tm = generic_proc_t::composite_target_multiplier( t );

      if ( p()->specialization() == EVOKER_DEVASTATION )
      {
        if ( !p()->buff.dragonrage->check() || !p()->talent.tyranny.ok() )
          tm *= 1.0 + p()->cache.mastery_value() * t->health_percentage() / 100;
        else
          tm *= 1.0 + p()->cache.mastery_value();
      }

      return tm;
    }
  };

  effect.execute_action = unique_gear::create_proc_action<light_of_creation_t>( "light_of_creation", effect );

  action_t* action = effect.player->find_action( "use_item_" + effect.item->name_str );
  if ( action )
    action->base_execute_time = effect.execute_action->base_execute_time;
}

// Evoker Legendary Weapon Nasz'uro, the Unbound Legacy
void insight_of_naszuro( special_effect_t& effect )
{
  if ( auto e = dynamic_cast<evoker_t*>( effect.player ) )
  {
    e->naszuro = &effect;
  }
}

void evoker_t::validate_sim_options()
{
  if ( specialization() == EVOKER_AUGMENTATION )
  {
    if ( sim->single_actor_batch )
    {
      sim->error( "Single actor batch is not supported for Augmentation, disabling." );
      sim->single_actor_batch = false;
    }
  }
}

unsigned int evoker_t::specialization_aura_id()
{
  switch ( specialization() )
  {
    case EVOKER_DEVASTATION:
      return spec.devastation->id();
      break;
    case EVOKER_PRESERVATION:
      return spec.preservation->id();
      break;
    case EVOKER_AUGMENTATION:
      return spec.augmentation->id();
      break;
    default:
      return 356816;
      break;
  }
}

void evoker_t::init_action_list()
{
  // 2022-08-07: Healing is not supported
  if ( !sim->allow_experimental_specializations && primary_role() == ROLE_HEAL )
  {
    if ( !quiet )
      sim->error( "Role heal for evoker '{}' is currently not supported.", name() );

    quiet = true;
    return;
  }

  if ( !action_list_str.empty() )
  {
    player_t::init_action_list();
    return;
  }
  clear_action_priority_lists();

  switch ( specialization() )
  {
    case EVOKER_DEVASTATION:
      evoker_apl::devastation( this );
      break;
    case EVOKER_PRESERVATION:
      evoker_apl::preservation( this );
      break;
    case EVOKER_AUGMENTATION:
      if ( sim->dbc->wowv() >= wowv_t( 12, 1, 0 ) )
        evoker_apl::augmentation_12_1_0( this );
      else
        evoker_apl::augmentation_12_0_5( this );
      break;
    default:
      evoker_apl::no_spec( this );
      break;
  }

  use_default_action_list = true;

  player_t::init_action_list();
}

void evoker_t::init_blizzard_action_list()
{
  [[maybe_unused]] action_priority_list_t* default_ = get_action_priority_list( "default" );
  player_t::init_blizzard_action_list();

  //// default overrides
  // switch ( specialization() )
  //{
  //   case PRIEST_DISCIPLINE:
  //     break;
  //   case PRIEST_HOLY:
  //     break;
  //   case PRIEST_SHADOW:
  //     break;
  //   default:
  //     break;
  // }

  // precombat overrides
  action_priority_list_t* pre_c = get_action_priority_list( "precombat" );

  switch ( specialization() )
  {
    case EVOKER_PRESERVATION:
      break;
    case EVOKER_AUGMENTATION:
      pre_c->add_action( "blistering_scales,if=talent.blistering_scales" );
      SC_FALLTHROUGH;
    case EVOKER_DEVASTATION:
      pre_c->add_action( "living_flame" );
      break;
    default:
      break;
  }

  // cooldown overrides
  action_priority_list_t* cooldowns = get_action_priority_list( "cooldowns" );
  // reset this from player.cpp
  cooldowns->action_list.clear();

  cooldowns->add_action( "potion" );

  switch ( specialization() )
  {
    case EVOKER_PRESERVATION:
      break;
    case EVOKER_DEVASTATION:
      cooldowns->add_action(
          "deep_breath,if=talent.imminent_destruction|talent.melt_armor|talent.maneuverability|active_enemies>1" );
      cooldowns->add_action( "dragonrage" );
      cooldowns->add_action( "tip_the_scales" );
      cooldowns->add_action( "use_items,if=buff.dragonrage.up|!talent.dragonrage|cooldown.dragonrage.remains>20" );
      break;
    case EVOKER_AUGMENTATION:
      cooldowns->add_action( "prescience,use_auto=1,if=cooldown.breath_of_eons.up&talent.breath_of_eons" );
      cooldowns->add_action( "ebon_might,if=cooldown.breath_of_eons.up&talent.breath_of_eons" );
      cooldowns->add_action( "breath_of_eons" );
      cooldowns->add_action( "deep_breath" );
      cooldowns->add_action( "tip_the_scales" );
      cooldowns->add_action( "time_skip" );
      cooldowns->add_action( "use_items" );
      break;
    default:
      break;
  }
}

parsed_assisted_combat_rule_t evoker_t::parse_assisted_combat_rule( const assisted_combat_rule_data_t& rule,
                                                                    const assisted_combat_step_data_t& step ) const
{
  // Blistering scales checks if it is up
  if ( rule.condition_type == AC_AURA_MISSING_PLAYER && rule.condition_value_1 == 1245013 )
  {
    return { "!evoker.scales_up" };
  }
  // Blistering scales checks if it is up
  if ( rule.condition_type == AC_AURA_ON_PLAYER && rule.condition_value_1 == 1245013 )
  {
    return { "evoker.scales_up" };
  }
  if ( rule.condition_type == AC_AURA_ON_PLAYER && rule.condition_value_1 == 436336 )
  {
    return { "buff.mass_disintegrate_stacks.up" };
  }
  if ( rule.condition_type == AC_AURA_ON_TARGET && rule.condition_value_1 == 361500 )
  {
    return { "dot.living_flame_damage.ticking" };
  }
  if ( rule.condition_type == AC_AURA_MISSING_TARGET && rule.condition_value_1 == 361500 )
  {
    return { "!dot.living_flame_damage.ticking" };
  }
  if ( rule.condition_type == AC_AURA_ON_TARGET && rule.condition_value_1 == 357209 )
  {
    return { "dot.fire_breath_damage.ticking" };
  }
  if ( rule.condition_type == AC_AURA_MISSING_TARGET && rule.condition_value_1 == 357209 )
  {
    return { "!dot.fire_breath_damage.ticking" };
  }
  // recall buff check for deep breath
  if ( rule.condition_type == AC_AURA_MISSING_PLAYER &&
       ( rule.condition_value_1 == 371807 || rule.condition_value_1 == 403760 ) )
  {
    return { "", true };
  }

  // if ( rule.condition_type == AC_AURA_ON_PLAYER && rule.condition_value_1 == 410089 )
  //{
  //   return { "" };
  // }
  //
  // if ( rule.condition_type == AC_AURA_MISSING_PLAYER && rule.condition_value_1 == 410089 )
  //{
  //   return { "" };
  // }

  return player_t::parse_assisted_combat_rule( rule, step );
}

void evoker_t::parse_assisted_combat_step( const assisted_combat_step_data_t& step,
                                           action_priority_list_t* assisted_combat )
{
  std::string expr                    = "";
  std::string base_expr               = "";
  std::string comment                 = "";
  bool show_diff                      = false;
  bool cooldown_allow_casting_success = false;
  bool use_auto                       = false;

  for ( const auto& rule : assisted_combat_rule_data_t::data( step.id, is_ptr() ) )
  {
    if ( rule.condition_type == AC_COOLDOWN_ALLOW_CASTING_SUCCESS )
      cooldown_allow_casting_success = true;

    parsed_assisted_combat_rule_t derived_combat_rule = parse_assisted_combat_rule( rule, step );
    parsed_assisted_combat_rule_t base_combat_rule    = player_t::parse_assisted_combat_rule( rule, step );

    if ( !derived_combat_rule.expr.empty() )
      expr += expr.empty() ? derived_combat_rule.expr : "&" + derived_combat_rule.expr;
    if ( !derived_combat_rule.comment.empty() )
      comment += comment.empty() ? derived_combat_rule.comment : ", " + derived_combat_rule.comment;
    if ( !base_combat_rule.expr.empty() )
      base_expr += base_expr.empty() ? base_combat_rule.expr : "&" + base_combat_rule.expr;

    show_diff |= derived_combat_rule.show_diff;
  }

  if ( base_expr != expr && show_diff )
    comment += ( comment.empty() ? "" : " " ) + fmt::format( "(Overridden from '{}')", base_expr );

  for ( const auto& name : action_names_from_spell_id( step.spell_id ) )
  {
    if ( name.empty() )
      continue;

    if ( name == "prescience" )
    {
      use_auto = true;
    }

    std::string action_str = name;

    if ( !expr.empty() )
      action_str += ",if=" + expr;

    if ( cooldown_allow_casting_success )
      action_str += ",cooldown_allow_casting_success=1";

    if ( use_auto )
      action_str += ",use_auto=1";

    assisted_combat->add_action( action_str, comment );
  }
}

std::vector<std::string> evoker_t::action_names_from_spell_id( unsigned int spell_id ) const
{
  if ( spell_id == 364342 )  // Blessing of the Bronze
  {
    return {};
  }

  if ( spell_id == 356995 && talent.eruption.enabled() )  // Eruption Replacement
  {
    return { "eruption" };
  }

  return player_t::action_names_from_spell_id( spell_id );
}

std::string evoker_t::aura_expr_from_spell_id( unsigned int spell_id, bool on_self ) const
{
  std::string aura_expr = player_t::aura_expr_from_spell_id( spell_id, on_self );

  return aura_expr;
}

void evoker_t::create_permanent_actors()
{
    
  if ( specialization() == EVOKER_AUGMENTATION && sim->player_no_pet_list.size() == 1 &&
       option.make_simplified_if_alone && !sim->single_actor_batch )
  {
    const module_t* module = module_t::get( PLAYER_SIMPLIFIED );

    std::vector<std::pair<std::string_view, std::string_view>> bobs;

    if ( sim->fight_style == FIGHT_STYLE_DUNGEON_ROUTE || sim->fight_style == FIGHT_STYLE_DUNGEON_SLICE || option.patchwerk_in_dungeon )
    {
      option.force_clutchmates = "yes";
      close_as_clutchmates     = true;
      
      if ( sim->dbc->wowv() >= wowv_t( 12, 1, 0 ) )
      {
        bobs = { { "Bob FDK", "dk_frost" }, { "Bob Shadow", "shadow_archon" }, { "Bob BDK", "bdk" }, { "Bob Healer", "healer" } };
      }
      else
      {
        bobs = { { "Bob Demo", "demo" }, { "Bob UDK", "unh" }, { "Bob Tank", "tank" }, { "Bob Healer", "healer" } };
      }
    }
    else
    {
      option.force_clutchmates = "no";
      close_as_clutchmates     = false;
      // Spawn in a vastly reduced Raid Cohort and estimate Breath of Eons instead.
      // This will slightly over-estimate the power of Ebon Might but makes the sims significantly faster.
      if ( sim->dbc->wowv() >= wowv_t( 12, 1, 0 ) )
      {
          
        bobs = {
            { "Bob Shadow1",  "shadow_archon" },
            { "Bob Shadow2",  "shadow_archon" },
            { "Bob FDK",      "dk_frost" },
            { "Bob BM",       "bm" },
            { "Bob Flat1",    "default" },
            { "Bob Demo",     "demo" },  // Local sandbag spec to estimate the more varied damage profiles of a real raid.
            { "Bob Healer1",  "healer" },
            { "Bob BDK",      "bdk" },
        };
      }
      else
      {
        bobs = {
            { "Bob UHDK1", "unh" },
            { "Bob Demo", "demo" },
            { "Bob BM", "bm" },
            { "Bob Flat1", "default" },
            { "Bob Flat2", "default" },
            { "Bob ShadowVW", "shadow" },  // Local sandbag spec to estimate the more varied damage profiles of a real raid.
            { "Bob Healer1", "healer" },
            { "Bob Tank1", "tank" },
        };
      }
    }

    for ( auto& pair : bobs )
    {
      simplified_player_t* p = dynamic_cast<simplified_player_t*>( module->create_player( sim, pair.first ) );

      p->true_level     = level();
      p->option.variant = pair.second;

      if ( option.ally_skill >= 0 )
      {
        p->option.skill = option.ally_skill;
      }

      if ( option.simplified_actor_ilevel >= 0 )
      {
        p->option.item_level = option.simplified_actor_ilevel;
      }
      else
      {
        if ( p->level() < 90 )
        {
          p->option.item_level = 170;
        }
      }
    }
  }
}

void evoker_t::create_pets()
{
  player_t::create_pets();

  pets.commando_pet.set_max_pets( 4 );

  if ( sets->has_set_bonus( HERO_SCALECOMMANDER, TWW3, B2 ) )
  {
    timespan_t duration =
        timespan_t::from_seconds( sets->set( HERO_SCALECOMMANDER, TWW3, B2 )->effectN( 1 ).base_value() );

    if ( sets->has_set_bonus( HERO_SCALECOMMANDER, TWW3, B4 ) )
    {
      auto added_duration = sets->set( HERO_SCALECOMMANDER, TWW3, B4 )->effectN( 2 ).time_value();
      duration += added_duration;
    }

    pets.commando_pet.set_default_duration( duration );
  }
}

void evoker_t::init_finished()
{
  auto CT = []( player_t* p, std::string_view n ) { return p->find_talent_spell( talent_tree::CLASS, n ); };
  auto ST = []( player_t* p, std::string_view n ) { return p->find_talent_spell( talent_tree::SPECIALIZATION, n ); };

  int dps = 0;

  for ( auto p : sim->player_no_pet_list )
  {
    if ( p == this )
      continue;

    if ( p->primary_role() != ROLE_HYBRID && p->primary_role() != ROLE_HEAL && p->primary_role() != ROLE_TANK )
      dps += 1;

    // DEATH_KNIGHT, DEMON_HUNTER, DRUID, EVOKER, HUNTER, MAGE, MONK, PALADIN, PRIEST, ROGUE, SHAMAN, WARLOCK, WARRIOR,
    if ( p->type == DEATH_KNIGHT )
    {
      if ( p->specialization() == DEATH_KNIGHT_FROST )
      {
        if ( ST( p, "Breath of Sindragosa" ).ok() )
        {
          allied_major_cds[ p ] = buff_t::find( p, "breath_of_sindragosa" );
        }
        else if ( ST( p, "Pillar of Frost" ).ok() )
        {
          allied_major_cds[ p ] = buff_t::find( p, "pillar_of_frost" );
        }
        else if ( ST( p, "Empower Rune Weapon" ).ok() || CT( p, "Empower Rune Weapon" ).ok() )
        {
          allied_major_cds[ p ] = buff_t::find( p, "empower_rune_weapon" );
        }
      }
      else if ( p->specialization() == DEATH_KNIGHT_UNHOLY )
      {
        if ( ST( p, "Commander of the Dead" ).ok() )
        {
          allied_major_cds[ p ] = buff_t::find( p, "commander_of_the_dead" );
        }
        else if ( ST( p, "Unholy Assault" ).ok() )
        {
          allied_major_cds[ p ] = buff_t::find( p, "unholy_assault" );
        }
        else if ( ST( p, "Defile" ).ok() && ( sim->has_raid_event( "adds" ) || sim->has_raid_event( "pull" ) ) )
        {
          allied_major_cds[ p ] = buff_t::find( p, "defile" );
        }
        else if ( ST( p, "Dark Transformation" ).ok() )
        {
          allied_major_cds[ p ] = buff_t::find( p, "dark_transformation" );
        }
      }
    }
    else if ( p->type == DEMON_HUNTER )
    {
      allied_major_cds[ p ] = buff_t::find( p, "metamorphosis" );
    }
    else if ( p->type == EVOKER )
    {
      if ( p->specialization() == EVOKER_AUGMENTATION )
      {
        allied_augmentations.push_back( static_cast<evoker_t*>( p ) );
      }
      else if ( p->specialization() == EVOKER_DEVASTATION )
      {
        auto evoker = static_cast<evoker_t*>( p );
        if ( evoker->talent.dragonrage.ok() )
        {
          allied_major_cds[ p ] = evoker->buff.dragonrage;
        }
      }
    }
    else if ( p->type == PRIEST )
    {
      if ( p->specialization() == PRIEST_SHADOW )
      {
        if ( ST( p, "Void Eruption" ).ok() )
        {
          allied_major_cds[ p ] = buff_t::find( p, "voidform" );
        }
        else if ( CT( p, "Power Infusion" ).ok() )
        {
          allied_major_cds[ p ] = buff_t::find( p, "power_infusion" );
        }
      }
    }
    else if ( p->type == MAGE )
    {
      if ( p->specialization() == MAGE_FIRE )
      {
        allied_major_cds[ p ] = buff_t::find( p, "combustion" );
      }
      else if ( p->specialization() == MAGE_FROST )
      {
        if ( ST( p, "Icy Veins" ).ok() )
          allied_major_cds[ p ] = buff_t::find( p, "icy_veins" );
      }
      else if ( p->specialization() == MAGE_ARCANE )
      {
        if ( ST( p, "Arcane Surge" ).ok() )
          allied_major_cds[ p ] = buff_t::find( p, "arcane_surge" );
      }
    }
    else if ( p->type == DRUID )
    {
      if ( p->specialization() == DRUID_BALANCE )
      {
        if ( ST( p, "Incarnation: Chosen of Elune" ) )
        {
          allied_major_cds[ p ] = buff_t::find( p, "incarnation_chosen_of_elune" );
        }
        else
        {
          if ( ST( p, "Celestial Alignment" ) )
            allied_major_cds[ p ] = buff_t::find( p, "celestial_alignment" );
        }
      }
      else if ( p->specialization() == DRUID_FERAL )
      {
        if ( ST( p, "Incarnation: Avatar of Ashamane" ) )
        {
          allied_major_cds[ p ] = buff_t::find( p, "incarnation_avatar_of_ashamane" );
        }
        else if ( ST( p, "Berserk" ) )
        {
          allied_major_cds[ p ] = buff_t::find( p, "berserk" );
        }
        else
        {
          allied_major_cds[ p ] = buff_t::find( p, "tigers_fury" );
        }
      }
    }
    else if ( p->type == SHAMAN )
    {
      if ( ST( p, "Ascendance" ) && p->specialization() != SHAMAN_RESTORATION )
      {
        allied_major_cds[ p ] = buff_t::find( p, "ascendance" );
      }
    }
    else if ( p->type == HUNTER )
    {
      if ( p->specialization() == HUNTER_MARKSMANSHIP )
      {
        if ( ST( p, "Trueshot" ).ok() )
          allied_major_cds[ p ] = buff_t::find( p, "trueshot" );
      }
      else if ( p->specialization() == HUNTER_SURVIVAL )
      {
        if ( ST( p, "Coordinated Assault" ).ok() )
          allied_major_cds[ p ] = buff_t::find( p, "coordinated_assault" );
      }
    }
    else if ( p->type == PALADIN )
    {
      if ( CT( p, "Avenging Wrath" ).ok() )
      {
        // TODO: Handle sentinel and other special ones
        allied_major_cds[ p ] = buff_t::find( p, "avenging_wrath" );
      }
    }
    else if ( p->type == MONK )
    {
      if ( ST( p, "Zenith" ).ok() )
      {
        allied_major_cds[ p ] = buff_t::find( p, "zenith" );
      }
    }
    else if ( p->type == ROGUE )
    {
      if ( p->specialization() == ROGUE_OUTLAW )
      {
        allied_major_cds[ p ] = buff_t::find( p, "adrenaline_rush" );
      }
      else
      {
        if ( CT( p, "Shadow Dance" ).ok() || ST( p, "Shadow Dance" ).ok() )
        {
          allied_major_cds[ p ] = buff_t::find( p, "shadow_dance" );
        }
      }
    }
  }

  if ( ( dps < 4 && !util::str_compare_ci( option.force_clutchmates, "no" ) ) ||
       util::str_compare_ci( option.force_clutchmates, "yes" ) )
  {
    close_as_clutchmates = true;
    sim->print_debug( "{} Activating Close As Clutchmates", *this );
  }

  player_t::init_finished();

  /*PRECOMBAT SHENANIGANS
  we do this here so all precombat actions have gone throught init() and init_finished() so if-expr are properly
  parsed and we can adjust travel times accordingly based on subsequent precombat actions that will sucessfully
  cast*/

  for ( auto pre = precombat_action_list.begin(); pre != precombat_action_list.end(); pre++ )
  {
    if ( auto lf = dynamic_cast<spells::living_flame_t*>( *pre ) )
    {
      int actions           = 0;
      timespan_t time_spent = 0_ms;

      std::for_each( pre + 1, precombat_action_list.end(), [ &actions, &time_spent ]( action_t* a ) {
        if ( a->gcd() > 0_ms && ( !a->if_expr || a->if_expr->success() ) && a->action_ready() )
        {
          actions++;
          time_spent += std::max( a->base_execute_time.value(), a->trigger_gcd );
        }
      } );

      // Only allow precast Living Flame if there's only one GCD action following it - It doesn't have a very long
      // travel time.
      if ( actions == 1 )
      {
        lf->harmful = false;
        // Child contains the travel time
        precombat_travel      = lf->damage->travel_time();
        lf->prepull_timespent = time_spent;
        break;
      }
    }
  }

  if ( heartbeat.callbacks.size() > 0 )
  {
    heartbeat.initial_time = timespan_t::from_millis( rng().range( 0, 5250 ) );
    register_combat_begin( [ this ]( player_t* ) {
      make_event( sim, heartbeat.initial_time, [ this ] {
        for ( auto& cb : heartbeat.callbacks )
        {
          cb();
        }
        make_repeating_event( sim, 5.25_s, [ this ]() {
          for ( auto& cb : heartbeat.callbacks )
          {
            cb();
          }
        } );
      } );
    } );
  }

  // I hate gaze.
  // This might be shifting sands but it seems to get slightly too many from sands.
  // This is about right, though.
  // Seemingly bugged in keys.
  if ( specialization() == EVOKER_AUGMENTATION &&
       ( ( !option.patchwerk_in_dungeon || sim->fight_style != FIGHT_STYLE_PATCHWERK ) &&
         sim->fight_style != FIGHT_STYLE_DUNGEON_ROUTE && sim->fight_style != FIGHT_STYLE_DUNGEON_SLICE ) )
  {
    register_combat_begin( [ this ]( player_t* ) {
      make_event( sim, timespan_t::from_millis( rng().range( 0, 1350 ) ), [ this ] {
        trigger_aura_applied_callbacks( background_proc_data, this );
        make_repeating_event( sim, 1.35_s,
                              [ this ]() { trigger_aura_applied_callbacks( background_proc_data, this ); } );
      } );
    } );
  }

  if ( talent.scalecommander.onslaught.enabled() )
  {
    register_on_combat_state_callback( [ this ]( player_t*, bool in_combat ) {
      if ( in_combat )
      {
        buff.burnout->increment();
      }
    } );
  }

  if ( talent.scalecommander.unrelenting_siege.enabled() )
  {
    register_on_combat_state_callback( [ this ]( player_t*, bool in_combat ) {
      if ( in_combat )
      {
        if ( !buff.unrelenting_siege->check() )
        {
          buff.unrelenting_siege->trigger();
        }
      }
      else
      {
        buff.unrelenting_siege->expire();
      }
    } );
  }
}

role_e evoker_t::primary_role() const
{
  switch ( player_t::primary_role() )
  {
    case ROLE_HEAL:
      return ROLE_HEAL;
    case ROLE_DPS:
    case ROLE_SPELL:
      return ROLE_SPELL;
    case ROLE_ATTACK:
      return ROLE_SPELL;
    default:
      if ( specialization() == EVOKER_PRESERVATION )
      {
        return ROLE_HEAL;
      }
      break;
  }

  return ROLE_SPELL;
}

void evoker_t::init_benefits()
{
  player_t::init_benefits();

  benefit.supercharged_shards = get_benefit( "Supercharged Shards" );
}

void evoker_t::init_gains()
{
  player_t::init_gains();

  gain.roar_of_exhilaration = get_gain( "Roar of Exhilaration" );
  gain.energizing_flame     = get_gain( "Energizing Flame" );
}

void evoker_t::init_procs()
{
  player_t::init_procs();

  proc.ruby_essence_burst                    = get_proc( "Ruby Essence Burst" );
  proc.azure_essence_burst                   = get_proc( "Azure Essence Burst" );
  proc.titanic_precision_ruby_essence_burst  = get_proc( "Titanic Precision Ruby Essence Burst" );
  proc.titanic_precision_azure_essence_burst = get_proc( "Titanic Precision Azure Essence Burst" );
  proc.emerald_trance                        = get_proc( "Emerald Trance" );
  proc.anachronism_essence_burst             = get_proc( "Anachronism" );
  proc.echoing_strike                        = get_proc( "Echoing Strike" );
  proc.overwritten_leaping_flames            = get_proc( "Overwritten Leaping Flames" );
  proc.diverted_power                        = get_proc( "Diverted Power" );
  proc.destroyers_scarred_wards              = get_proc( "Evoker Devastation 11.0 Class Set 4pc" );
  proc.tww2_4pc                              = get_proc( "Essence Bursts from TWW Season 2 4pc" );
  proc.hoarded_power                         = get_proc( "Hoarded Power" );
  proc.essence_well                          = get_proc( "Essence Well" );
}

void evoker_t::init_base_stats()
{
  if ( base.distance < 1 )
    base.distance = 25;

  // We need to check travel time during init_finished... So we have to initialise current.distance ourselves. Note to
  // self: Never play with prepull actions ever again.
  current.distance = base.distance;

  base.spell_power_per_intellect = 1.0;

  player_t::init_base_stats();
}

void evoker_t::init_background_actions()
{
  player_t::init_background_actions();

  if ( talent.ebon_might.ok() )
  {
    background_actions.ebon_might =
        get_secondary_action<spells::ebon_might_t>( "ebon_might_helper", timespan_t::min(), "ebon_might_helper" );
  }

  if ( talent.tip_the_scales.ok() )
  {
    background_actions.tip_the_scales = get_secondary_action<spells::tip_the_scales_t>( "tip_the_scales", "" );
  }

  if ( talent.flameshaper.consume_flame.ok() )
  {
    background_actions.consume_flame = get_secondary_action<spells::consume_flame_t>( "consume_flame" );
  }
}

void evoker_t::init_items()
{
  player_t::init_items();

  set_bonus_type_e tier_to_enable;
  switch ( specialization() )
  {
    case EVOKER_PRESERVATION:
      tier_to_enable = DF1;
      break;
    case EVOKER_AUGMENTATION:
      tier_to_enable = DF3;
      break;
    case EVOKER_DEVASTATION:
      tier_to_enable = DF2;
      break;
    default:
      return;
  }

  if ( sets->has_set_bonus( specialization(), DF4, B2 ) )
  {
    sets->enable_set_bonus( specialization(), tier_to_enable, B2 );
  }

  if ( sets->has_set_bonus( specialization(), DF4, B4 ) )
  {
    sets->enable_set_bonus( specialization(), tier_to_enable, B4 );
  }
}

void evoker_t::init_spells()
{
  player_t::init_spells();

  background_proc_data = find_spell( 364342 ); // Blessing of the Bronze

  // Evoker Specialization Spells
  spec.evoker               = find_spell( 353167 );  // TODO: confirm this is the class aura
  spec.devastation          = find_specialization_spell( "Devastation Evoker" );
  spec.preservation         = find_specialization_spell( "Preservation Evoker" );
  spec.augmentation         = find_specialization_spell( "Augmentation Evoker" );
  spec.mastery              = find_mastery_spell( specialization() );
  spec.fire_breath_damage   = find_spell( 357209 );
  spec.living_flame_damage  = find_spell( 361500 );
  spec.living_flame_heal    = find_spell( 361509 );
  spec.energizing_flame     = find_spell( 400006 );
  spec.tempered_scales      = find_spell( 396571 );
  spec.emerald_blossom      = find_spell( 355913 );
  spec.emerald_blossom_heal = find_spell( 355916 );
  spec.emerald_blossom_spec = find_specialization_spell( 365261, specialization() );
  spec.close_as_clutchmates = find_specialization_spell( 396043, specialization() );

  // Evoker Talents
  auto CT = [ this ]( std::string_view n ) { return find_talent_spell( talent_tree::CLASS, n ); };
  auto ST = [ this ]( std::string_view n ) { return find_talent_spell( talent_tree::SPECIALIZATION, n ); };
  auto HT = [ this ]( std::string_view n ) { return find_talent_spell( talent_tree::HERO, n ); };

  // Class Traits
  talent.landslide            = CT( "Landslide" );  // Row 1
  talent.obsidian_scales      = CT( "Obsidian Scales" );
  talent.expunge              = CT( "Expunge" );
  talent.natural_convergence  = CT( "Natural Convergence" );  // Row 2
  talent.verdant_embrace      = CT( "Verdant Embrace" );
  talent.forger_of_mountains  = CT( "Forger of Mountains" );  // Row 3
  talent.innate_magic         = CT( "Innate Magic" );
  talent.obsidian_bulwark     = CT( "Obsidian Bulwark" );
  talent.enkindled            = CT( "Enkindled" );
  talent.scarlet_adaptation   = CT( "Scarlet Adaptation" );
  talent.quell                = CT( "Quell" );  // Row 4
  talent.tailwind             = CT( "Tailwind" );
  talent.roar_of_exhilaration = CT( "Roar of Exhilaration" );  // Row 5
  talent.instinctive_arcana   = CT( "Instinctive Arcana" );
  talent.tip_the_scales       = CT( "Tip the Scales" );
  talent.attuned_to_the_dream = CT( "Attuned to the Dream" );  // healing received NYI
  talent.draconic_legacy      = CT( "Draconic Legacy" );       // Row 6
  talent.inherent_resistance  = CT( "Inherent Resistance" );
  talent.extended_flight      = CT( "Extended Flight" );
  talent.bountiful_bloom      = CT( "Bountiful Bloom" );
  talent.blast_furnace        = CT( "Blast Furnace" );  // Row 7
  talent.panacea              = CT( "Panacea" );
  talent.panacea_spell        = find_spell( 387763 );
  talent.exuberance           = CT( "Exuberance" );
  talent.ancient_flame        = CT( "Ancient Flame" );
  talent.unravel              = CT( "Unravel" );
  talent.unravel_spell        = find_spell( 1264379 );
  talent.protracted_talons    = CT( "Protracted Talons" );  // Row 8
  talent.lush_growth          = CT( "Lush Growth" );
  talent.oppressing_roar      = CT( "Oppressing Roar" );
  talent.leaping_flames       = CT( "Leaping Flames" );  // Row 9
  talent.aerial_mastery       = CT( "Aerial Mastery" );
  talent.overawe              = CT( "Overawe" );
  talent.time_spiral          = CT( "Time Spiral" );  // Row 10
  // Devastation Traits
  talent.pyre                         = ST( "Pyre" );                // Row 1
  talent.ruby_essence_burst           = ST( "Ruby Essence Burst" );  // Row 2
  talent.azure_essence_burst          = ST( "Azure Essence Burst" );
  talent.imposing_presence            = ST( "Imposing Presence" );
  talent.eternity_surge               = ST( "Eternity Surge" );
  talent.volatility                   = ST( "Volatility" );  // Row 4
  talent.power_nexus                  = ST( "Power Nexus" );
  talent.dragonrage                   = ST( "Dragonrage" );
  talent.lay_waste                    = ST( "Lay Waste" );
  talent.azure_sweep                  = ST( "Azure Sweep" );
  talent.azure_sweep_buff             = find_spell( 1265871 );
  talent.azure_sweep_spell            = find_spell( 1265872 );
  talent.arcane_intensity             = ST( "Arcane Intensity" );
  talent.ruby_embers                  = ST( "Ruby Embers" );  // Row 5
  talent.engulfing_blaze              = ST( "Engulfing Blaze" );
  talent.animosity                    = ST( "Animosity" );
  talent.essence_attunement           = ST( "Essence Attunement" );
  talent.heat_wave                    = ST( "Heat Wave" );
  talent.honed_aggression             = ST( "Honed Aggression" );
  talent.eternitys_span               = ST( "Eternity's Span" );
  talent.eye_of_infinity              = ST( "Eye of Infinity" );
  talent.event_horizon                = ST( "Event Horizon" );
  talent.causality                    = ST( "Causality" );
  talent.catalyze                     = ST( "Catalyze" );  // Row 7
  talent.tyranny                      = ST( "Tyranny" );
  talent.charged_blast                = ST( "Charged Blast" );
  talent.shattering_stars             = ST( "Shattering Stars" );
  talent.shattering_star_spell        = find_spell( 1265804 );
  talent.star_salvo                   = ST( "Star Salvo" );
  talent.burnout                      = ST( "Burnout" );
  talent.onyx_legacy                  = ST( "Onyx Legacy" );
  talent.spellweavers_dominance       = ST( "Spellweaver's Dominance" );
  talent.feed_the_flames              = ST( "Feed the Flames" );  // Row 9
  talent.feed_the_flames_tracker_buff = find_spell( 405874 );
  talent.feed_the_flames_proc_trigger = find_spell( 411288 );
  talent.feed_the_flames_firestorm    = find_spell( 368847 );
  talent.font_of_magic                = ST( "Font of Magic" );
  talent.titanic_wrath                = ST( "Titanic Wrath" );
  talent.azure_celerity               = ST( "Azure Celerity" );
  talent.power_swell                  = ST( "Power Swell" );
  talent.imminent_destruction         = ST( "Imminent Destruction" );  // Row 10
  talent.scorching_embers             = ST( "Scorching Embers" );
  talent.scintillation                = ST( "Scintillation" );
  talent.iridescence                  = ST( "Iridescence" );
  talent.strafing_run                 = ST( "Strafing Run" );
  talent.strafing_run_buff            = find_spell( 1266165 );
  talent.rising_fury_1                = find_talent_spell( talent_tree::SPECIALIZATION, 1271687 );
  talent.rising_fury_buff             = find_spell( 1271783 );
  talent.rising_fury_2                = find_talent_spell( talent_tree::SPECIALIZATION, 1271796 );
  talent.rising_fury_3                = find_talent_spell( talent_tree::SPECIALIZATION, 1271788 );
  talent.risen_fury_buff              = find_spell( 1271799 );
  talent.unbound_flame_buff           = find_spell( 1292323 );
  talent.unbound_flame_spell          = find_spell( 1292321 );
  // Preservation Traits

  // Augmentation Traits
  talent.ebon_might           = ST( "Ebon Might" );
  talent.ebon_might_self_buff = find_spell( 395296 );
  talent.sands_of_time        = find_spell( 395153 );
  talent.eruption             = ST( "Eruption" );
  talent.essence_burst        = ST( "Essence Burst" );
  // Imposing Presence / Inner Radiance - Non DPS
  talent.ricocheting_pyroclast = ST( "Ricocheting Pyroclast" );
  // Essence Attunement - Devastation also has
  talent.pupil_of_alexstrasza  = ST( "Pupil of Alexstrasza" );
  talent.echoing_strike        = ST( "Echoing Strike" );
  talent.upheaval              = ST( "upheaval" );
  talent.breath_of_eons        = ST( "Breath of Eons" );
  talent.breath_of_eons_damage = find_spell( 409632 );
  talent.temporal_wound        = find_spell( 409560 );
  // Defy Fate - Non DPS
  // Timelessness - Non DPS
  // Seismic Slam - Non DPS
  talent.volcanism = ST( "Volcanism" );
  // Perilous Fate / Chrono Ward - Non DPS
  // Stretch Time - Non DPS
  // Geomancy - Non DPS
  // Bestow Weyrnstone - Non DPS
  talent.blistering_scales        = ST( "Blistering Scales" );
  talent.blistering_scales_damage = find_spell( 360828 );
  // Draconic Attunements - Non DPS
  // Spatial Paradox Non DPS - Movement DPS Gain?
  talent.arcane_reach        = ST( "Arcane Reach" );
  talent.unyielding_domain   = ST( "Unyielding Domain" );
  talent.tectonic_locus      = ST( "Tectonic Locus" );
  talent.regenerative_chitin = ST( "Regenerative Chitin" );
  talent.molten_blood        = ST( "Molten Blood" );
  // Power Nexus - Devastation also has
  // Aspects' Favor - Non DPS
  talent.plot_the_future    = ST( "Plot the Future" );
  talent.dream_of_spring    = ST( "Dream of Spring" );
  talent.symbiotic_bloom    = ST( "Symbiotic Bloom" );
  talent.reactive_hide      = ST( "Reactive Hide" );
  talent.reactive_hide_buff = find_spell( 410256 );
  // Hoarded Power - Devas Has
  talent.ignition_rush   = ST( "Ignition Rush" );
  talent.prescience      = ST( "Prescience" );
  talent.prescience_buff = find_spell( 410089 );
  // Prolong Life - Non DPS. Scarlet Exists. Todo: Implement Healing
  talent.momentum_shift           = ST( "Momentum Shift" );
  talent.infernos_blessing        = ST( "Inferno's Blessing" );
  talent.infernos_blessing_damage = find_spell( 410265 );
  talent.infernos_blessing_buff   = find_spell( 410263 );
  talent.time_skip                = ST( "Time Skip" );
  talent.accretion                = ST( "Accretion" );
  talent.anachronism              = ST( "Anachronism" );
  talent.motes_of_possibility     = ST( "Motes of Possibility" );
  // Font of Magic - Devastation ha
  talent.tomorrow_today     = ST( "Tomorrow, Today" );
  talent.interwoven_threads = ST( "Interwoven Threads" );
  talent.overlord           = ST( "Overlord" );
  talent.fate_mirror        = ST( "Fate Mirror" );
  talent.fate_mirror_damage = find_spell( 404908 );
  talent.rumbling_earth     = ST( "Rumbling Earth" );
  talent.molten_embers      = ST( "Molten Embers" );
  talent.mighty_inferno     = ST( "Mighty Inferno" );
  talent.clairvoyant        = ST( "Clairvoyant" );

  // Apex
  talent.duplicate1                  = find_talent_spell( talent_tree::SPECIALIZATION, 1259173 );
  talent.duplicate_eruption_spell    = find_spell( 1259172 );
  talent.duplicate_fire_breath_charge_spell = find_spell( 1283718 );
  talent.duplicate_fire_breath_release_spell = find_spell( 431164 );
  talent.duplicate_upheaval_spell    = find_spell( 396288 );
  talent.duplicate2                  = find_talent_spell( talent_tree::SPECIALIZATION, 1259174 );
  talent.duplicate3                  = find_talent_spell( talent_tree::SPECIALIZATION, 1259175 );
  talent.duplicate3_buff             = find_spell( 1259171 );

  // Set up Essence Bursts for Preservation and Augmentation
  if ( talent.essence_burst.ok() )
  {
    const trait_data_t* trait;
    uint32_t class_idx, spec_idx;

    dbc->spec_idx( EVOKER_DEVASTATION, class_idx, spec_idx );

    trait = trait_data_t::find( talent_tree::SPECIALIZATION, "Ruby Essence Burst", class_idx, EVOKER_DEVASTATION,
                                dbc->ptr );

    if ( trait )
    {
      talent.ruby_essence_burst = player_talent_t( this, trait, trait->max_ranks );
    }

    if ( specialization() == EVOKER_AUGMENTATION )
    {
      trait = trait_data_t::find( talent_tree::SPECIALIZATION, "Azure Essence Burst", class_idx, EVOKER_DEVASTATION,
                                  dbc->ptr );

      if ( trait )
      {
        talent.azure_essence_burst = player_talent_t( this, trait, trait->max_ranks );
      }
    }
  }

  // chronowarden
  talent.chronowarden.chrono_flame                    = HT( "Chrono Flame" );
  talent.chronowarden.chrono_flames_spell             = find_spell( 431443 );
  talent.chronowarden.chrono_flame_damage             = find_spell( 431583 );
  talent.chronowarden.warp                            = HT( "Warp" );
  talent.chronowarden.temporal_burst                  = HT( "Temporal Burst" );
  talent.chronowarden.temporal_burst_buff             = find_spell( 431698 );
  talent.chronowarden.reverberations                  = HT( "Reverberations" );
  talent.chronowarden.reverberations_upheaval         = find_spell( 431620 );
  talent.chronowarden.temporality                     = HT( "Temporality" );
  talent.chronowarden.temporality_buff                = find_spell( 431872 );
  talent.chronowarden.motes_of_acceleration           = HT( "Motes of Acceleration" );
  talent.chronowarden.primacy                         = HT( "Primacy" );
  talent.chronowarden.primacy_buff                    = find_spell( 431654 );
  talent.chronowarden.double_time                     = HT( "Double-time" );
  talent.chronowarden.time_convergence                = HT( "Time Convergence" );
  talent.chronowarden.time_convergence_intellect_buff = find_spell( 431991 );
  talent.chronowarden.master_of_destiny               = HT( "Master of Destiny" );
  talent.chronowarden.instability_matrix              = HT( "Instability Matrix" );
  talent.chronowarden.golden_opportunity              = HT( "Golden Opportunity" );
  talent.chronowarden.afterimage                      = HT( "Afterimage" );
  talent.chronowarden.chronoboon                      = HT( "Chronoboon" );
  talent.chronowarden.energy_cycles                   = HT( "Energy Cycles" );
  talent.chronowarden.overclock                       = HT( "Overclock" );
  talent.chronowarden.chronal_dynamo                  = HT( "Chronal Dynamo" );
  talent.chronowarden.doubletime_buff                 = find_spell( 460688 );

  // flameshaper
  talent.flameshaper.trailblazer              = HT( "Trailblazer" );
  talent.flameshaper.shape_of_flame           = HT( "Shape of flame" );
  talent.flameshaper.enkindle                 = HT( "Enkindle" );
  talent.flameshaper.enkindle_damage          = find_spell( 444017 );
  talent.flameshaper.conduit_of_flame         = HT( "Conduit of Flame" );
  talent.flameshaper.burning_adrenaline       = HT( "Burning Adrenaline" );
  talent.flameshaper.fulminous_roar           = HT( "Fulminous Roar" );
  talent.flameshaper.fan_the_flames           = HT( "Fan the Flames" );
  talent.flameshaper.expanded_lungs           = HT( "Expanded Lungs" );
  talent.flameshaper.titanic_precision        = HT( "Titanic Precision" );
  talent.flameshaper.lifecinders              = HT( "Lifecinders" );
  talent.flameshaper.draconic_instincts       = HT( "Draconic Instincts" );
  talent.flameshaper.consume_flame            = HT( "Consume Flame" );
  talent.flameshaper.consume_flame_damage     = find_spell( 444089 );
  talent.flameshaper.legacy_of_the_lifebinder = HT( "Legacy of the Lifebinder" );
  talent.flameshaper.ashes_in_motion          = HT( "Ashes in Motion" );
  talent.flameshaper.deep_exhalation          = HT( "Deep Exhalation" );
  talent.flameshaper.essence_well             = HT( "Essence Well" );
  talent.flameshaper.twin_flame               = HT( "Twin Flame" );
  talent.flameshaper.twin_flame_damage_spell  = find_spell( 1265980 );
  talent.flameshaper.twin_flame_heal_spell    = find_spell( 1265991 );
  talent.flameshaper.fire_torrent             = HT( "Fire Torrent" );

  talent.flameshaper.inner_flame_buff_base = find_spell( 1236776 );
  talent.flameshaper.inner_flame_buff      = find_spell( 1236776 );
  talent.flameshaper.essence_bomb_spell    = find_spell( 1236792 );

  // Scalecommander
  talent.scalecommander.mass_disintegrate               = HT( "Mass Disintegrate" );
  talent.scalecommander.mass_disintegrate_buff          = find_spell( 436336 );
  talent.scalecommander.mass_eruption =
      specialization() == EVOKER_AUGMENTATION ? HT( "Mass Eruption" ) : player_talent_t();
  talent.scalecommander.mass_eruption_damage            = find_spell( 438653 );
  talent.scalecommander.mass_eruption_buff              = find_spell( 438588 );
  talent.scalecommander.mass_disintegrate_buff          = find_spell( 436336 );
  talent.scalecommander.might_of_the_black_dragonflight = HT( "Might of the Black Dragonflight" );
  talent.scalecommander.bombardments                    = HT( "Bombardments" );
  talent.scalecommander.bombardments_debuff             = find_spell( 434473 );
  talent.scalecommander.bombardments_driver             = find_spell( 443788 );
  talent.scalecommander.bombardments_damage             = find_spell( 434481 );
  talent.scalecommander.onslaught                       = HT( "Onslaught" );
  talent.scalecommander.melt_armor                      = HT( "Melt Armor" );
  talent.scalecommander.melt_armor_debuff               = find_spell( 441172 );
  talent.scalecommander.wingleader                      = HT( "Wingleader" );
  talent.scalecommander.unrelenting_siege               = HT( "Unrelenting Siege" );
  talent.scalecommander.unrelenting_siege_buff          = find_spell( 441248 );
  talent.scalecommander.hardened_scales                 = HT( "Hardened Scales" );
  talent.scalecommander.menacing_presence               = HT( "Menacing Presence" );
  talent.scalecommander.extended_battle                 = HT( "Extended Battle" );
  talent.scalecommander.diverted_power                  = HT( "Diverted Power" );
  talent.scalecommander.nimble_flyer                    = HT( "Nimble Flyer" );
  talent.scalecommander.slipstream                      = HT( "Slipstream" );
  talent.scalecommander.maneuverability                 = HT( "Maneuverability" );
  talent.scalecommander.maneuverability_breath_of_eons  = find_spell( 442204 );
  talent.scalecommander.maneuverability_deep_breath     = find_spell( 433874 );
  talent.scalecommander.command_squadron                = HT( "Command Squadron" );
  talent.scalecommander.command_squadron_pyre_spell     = find_spell( 1236970 );
  talent.scalecommander.concentrated_power              = HT( "Concentrated Power" );
  talent.scalecommander.refined_essence                 = HT( "Refined Essence" );

  talent.scalecommander.commando_deep_breath_buff = find_spell( 1236943 );

  register_passive_effect_mask( spec.close_as_clutchmates, effect_mask_t( true ).disable( 1, 2 ) );

  register_passive_affect_list( talent.natural_convergence, affect_list_t( 3 ).remove_spell( 1259172 ) );

  register_passive_affect_list( talent.spellweavers_dominance, affect_list_t( 1 ).add_spell( 444089, 445495 ) );

  // Register passives
  parse_all_class_passives();
  parse_all_passive_talents();
  parse_all_passive_sets();
  parse_raid_buffs();
}

void evoker_t::init_special_effects()
{
  if ( unique_gear::find_special_effect( this, 443393 ) && talent.pupil_of_alexstrasza.enabled() &&
       talent.essence_burst.enabled() )
  {
    callbacks.register_callback_execute_function(
        443393, [ this ]( const dbc_proc_callback_t* cb, const spell_data_t*, player_t* t, action_state_t* s ) {
          // Only trigger this on Single Target (Pretending its a 2nd target)
          if ( sim->target_non_sleeping_list.size() == 1 &&
               rng().roll( talent.ruby_essence_burst->effectN( 1 ).percent() ) )
          {
            buff.essence_burst->trigger();
          }

          cb->proc_action->set_target( cb->get_target( t, s ) );
          auto proc_state    = cb->proc_action->get_state();
          proc_state->target = cb->proc_action->target;
          cb->proc_action->snapshot_state( proc_state, cb->proc_action->amount_type( proc_state ) );
          cb->proc_action->schedule_execute( proc_state );
        } );
  }

  player_t::init_special_effects();
}

void evoker_t::init_assessors()
{
  player_t::init_assessors();

  if ( talent.chronowarden.chrono_flame.enabled() )
  {
    assessor_out_damage.add( assessor::TARGET_DAMAGE + 1, [ this ]( result_amount_type, action_state_t* state ) {
      auto td       = get_target_data( state->target );
      auto& tracker = td->chrono_tracker;

      time_t accessed_second = sim->current_time().total_millis() / 1000;
      size_t current_bucket  = as<size_t>( accessed_second ) % 5;

      if ( accessed_second > tracker.last_accessed_second )
      {
        size_t old_bucket = as<size_t>( tracker.last_accessed_second % 5 );

        while ( old_bucket != current_bucket )
        {
          old_bucket                           = ( old_bucket + 1 ) % 5;
          tracker.damage_buckets[ old_bucket ] = 0;
        }

        tracker.last_accessed_second = accessed_second;
      }

      tracker.damage_buckets[ current_bucket ] += state->result_amount;

      return assessor::CONTINUE;
    } );
  }
}

void evoker_t::create_actions()
{
  using namespace spells;
  using namespace heals;

  if ( sets->has_set_bonus( EVOKER_DEVASTATION, DF2, B2 ) )
    action.obsidian_shards = get_secondary_action<obsidian_shards_t>( "obsidian_shards" );

  if ( talent.flameshaper.enkindle.ok() )
    action.enkindle = get_secondary_action<enkindle_t>( "enkindle" );

  if ( talent.volatility.ok() )
  {
    auto vol                = get_secondary_action<pyre_t>( "pyre_volatility", "pyre_volatility", talent.pyre );
    vol->s_data_reporting   = talent.volatility;
    vol->name_str_reporting = "volatility";
    vol->proc_spell_type    = proc_spell_type_e::VOLATILITY;
    vol->proc               = true;
    action.volatility       = vol;

    if ( talent.dragonrage.ok() )
    {
      auto vol_dr =
          get_secondary_action<pyre_t>( "dragonrage_pyre_volatility", "dragonrage_pyre_volatility", talent.pyre );
      vol_dr->s_data_reporting     = talent.volatility;
      vol_dr->name_str_reporting   = "volatility";
      vol_dr->proc_spell_type      = proc_spell_type_e::VOLATILITY | proc_spell_type_e::DRAGONRAGE;
      vol_dr->proc                 = true;
      action.volatility_dragonrage = vol_dr;
    }
  }

  if ( sets->has_set_bonus( HERO_FLAMESHAPER, TWW3, B4 ) )
  {
    action.essence_bomb = get_secondary_action<essence_bomb_t>( "essence_bomb" );
  }

  if ( talent.flameshaper.twin_flame.enabled() )
  {
    action.twin_flame = get_secondary_action<twin_flame_t>( "twin_flame" );
  }

  player_t::create_actions();
}

void evoker_t::create_buffs()
{
  player_t::create_buffs();

  using namespace buffs;
  using e_buff_t = evoker_buff_t<buff_t>;

  auto MB  = []( auto&&... args ) { return make_buff<e_buff_t>( std::forward<decltype( args )>( args )... ); };
  auto MBF = []( auto&&... args ) { return make_buff_fallback<e_buff_t>( std::forward<decltype( args )>( args )... ); };

  // Baseline Abilities

  switch ( specialization() )
  {
    case EVOKER_PRESERVATION:
      buff.essence_burst = MB( this, "essence_burst", find_spell( 369299 ) );
      break;
    case EVOKER_AUGMENTATION:
      buff.essence_burst = MB( this, "essence_burst", find_spell( 392268 ) );
      break;
    case EVOKER_DEVASTATION:
    default:
      buff.essence_burst = MB( this, "essence_burst", find_spell( 359618 ) );
      break;
  }

  buff.essence_burst_titanic_wrath_disintegrate =
      MBF( talent.titanic_wrath.ok(), this, "essence_burst_titanic_wrath_disintegrate", find_spell( 397870 ) )
          ->set_quiet( true );

  buff.hover = MB( this, "hover", find_class_spell( "Hover" ) )
                   ->set_cooldown( 0_ms )
                   ->set_default_value_from_effect_type( A_MOD_INCREASE_SPEED )
                   ->set_refresh_behavior( buff_refresh_behavior::EXTEND );

  buff.tailwind = MBF( talent.tailwind.ok(), this, "tailwind",
                       find_spelleffect( talent.tailwind, A_PROC_TRIGGER_SPELL )->trigger() )
                      ->set_default_value_from_effect( 1 );

  // Class Traits
  buff.ancient_flame = MBF( talent.ancient_flame.ok(), this, "ancient_flame", find_spell( 375583 ) )
                           ->set_constant_behavior( buff_constant_behavior::NEVER_CONSTANT );

  buff.leaping_flames = MBF( talent.leaping_flames.ok(), this, "leaping_flames", find_spell( 370901 ) );

  buff.obsidian_scales = MBF( talent.obsidian_scales.ok(), this, "obsidian_scales", talent.obsidian_scales )
                             ->set_cooldown( 0_ms )
                             ->set_default_value_from_effect_type( A_MOD_DAMAGE_PERCENT_TAKEN );

  buff.scarlet_adaptation = MBF( talent.scarlet_adaptation.ok(), this, "scarlet_adaptation", find_spell( 372470 ) )
                                ->set_constant_behavior( buff_constant_behavior::NEVER_CONSTANT );

  buff.tip_the_scales = MBF( talent.tip_the_scales.ok(), this, "tip_the_scales", talent.tip_the_scales )
                            ->set_cooldown( 0_ms )
                            ->set_expire_callback( [ this ]( buff_t*, int, timespan_t ) {
                              cooldown.tip_the_scales->start( background_actions.tip_the_scales );
                            } );

  // Devastation
  buff.blazing_shards =
      MBF( sets->has_set_bonus( EVOKER_DEVASTATION, DF2, B4 ), this, "blazing_shards", find_spell( 409848 ) );

  buff.burnout = MBF( talent.burnout.ok(), this, "burnout", find_spell( 375802 ) )
                     ->set_cooldown( talent.burnout->internal_cooldown() )
                     ->set_chance( talent.burnout->effectN( 1 ).percent() );

  buff.charged_blast =
      MBF( talent.charged_blast.ok(), this, "charged_blast", talent.charged_blast->effectN( 1 ).trigger() )
          ->set_default_value_from_effect( 1 );

  buff.dragonrage = MBF( talent.dragonrage.ok(), this, "dragonrage", talent.dragonrage )
                        ->set_cooldown( 0_ms )
                        ->set_stack_change_callback( [ this ]( buff_t*, int old, int ) {
                          if ( old )
                          {
                            buff.emerald_trance_stacking->expire();
                          }
                        } )
                        ->set_default_value( 1 );

  buff.rising_fury = MBF( talent.rising_fury_1.ok(), this, "rising_fury", talent.rising_fury_buff )
                         ->set_duration( 0_s )
                         ->set_constant_behavior( buff_constant_behavior::NEVER_CONSTANT )
                         ->set_pct_buff_type( STAT_PCT_BUFF_HASTE )
                         ->set_default_value_from_effect( 1 );

  if ( sim->dbc->wowv() < wowv_t( 12, 1, 0 ) )
  {
    buff.rising_fury->add_stack_change_callback( [ this ]( buff_t*, int old, int n ) {
      if ( old && !n && talent.rising_fury_3.ok() )
      {
        buff.risen_fury->trigger( old, old * buff.risen_fury->buff_duration() );
      }
    } );
  }

  buff.risen_fury = MBF( talent.rising_fury_3.ok(), this, "risen_fury", talent.risen_fury_buff )
                        ->set_freeze_stacks( false )
                        ->set_tick_callback( [ this ]( buff_t*, int, timespan_t ) { buff.essence_burst->trigger(); } )
                        ->set_pct_buff_type( STAT_PCT_BUFF_HASTE )
                        ->set_default_value_from_effect( 1 );

  
  buff.unbound_flame = MBF( sim->dbc->wowv() >= wowv_t( 12, 1, 0 ) && talent.rising_fury_3.ok(), this, "unbound_flame",
                            talent.unbound_flame_buff )
                           ->set_reverse( true );

  if ( talent.rising_fury_1.enabled() )
  {
    if ( sim->dbc->wowv() < wowv_t( 12, 1, 0 ) )
    {
      buff.dragonrage->add_stack_change_callback( [ this ]( buff_t*, int old, int n ) {
        if ( n && !old )
        {
          buff.rising_fury->trigger();
        }
        else
        {
          buff.rising_fury->expire();
        }
      } );
    }
    else
    {
      buff.dragonrage->add_stack_change_callback( [ this ]( buff_t*, int old, int n ) {
        if ( n && !old )
        {
          buff.rising_fury->set_freeze_stacks( false );
          buff.rising_fury->trigger();
        }
        else
        {
          if ( talent.rising_fury_3.enabled() )
          {
            buff.unbound_flame->trigger();
            buff.rising_fury->expire( buff.rising_fury->stack() * talent.rising_fury_3->effectN( 1 ).time_value() );
            buff.rising_fury->set_freeze_stacks( true );
          }
          else
          {
            buff.rising_fury->expire();
          }
        }
      } );
    }
  }

  buff.fury_of_the_aspects = MB( this, "fury_of_the_aspects", find_class_spell( "Fury of the Aspects" ) )
                                 ->set_default_value_from_effect( 1 )
                                 ->set_cooldown( 0_s )
                                 ->add_invalidate( CACHE_HASTE );

  buff.imminent_destruction = MBF( talent.imminent_destruction.ok(), this, "imminent_destruction",
                                   find_spell( specialization() == EVOKER_AUGMENTATION ? 459574 : 411055 ) )
                                  ->set_consume_all_stacks( false );

  if ( talent.imminent_destruction.ok() )
    buff.imminent_destruction->set_initial_stack( as<int>( talent.imminent_destruction->effectN( 1 ).base_value() ) );

  buff.iridescence_blue = MBF( talent.iridescence.ok(), this, "iridescence_blue", find_spell( 386399 ) )
                              ->set_default_value_from_effect( 1 )
                              ->set_initial_stack_to_max_stack();

  buff.iridescence_blue_disintegrate =
      MBF( talent.iridescence.ok(), this, "iridescence_blue_disintegrate", find_spell( 399370 ) )
          ->set_quiet( true )
          ->set_default_value( buff.iridescence_blue->default_value )
          ->set_proc_callbacks( false );

  buff.iridescence_red = MBF( talent.iridescence.ok(), this, "iridescence_red", find_spell( 386353 ) )
                           ->set_default_value_from_effect( 1 )
                           ->set_initial_stack_to_max_stack();

  buff.limitless_potential =
      MBF( sets->has_set_bonus( EVOKER_DEVASTATION, DF1, B2 ), this, "limitless_potential", find_spell( 394402 ) )
          ->set_default_value_from_effect_type( A_MOD_ALL_CRIT_CHANCE )
          ->set_pct_buff_type( STAT_PCT_BUFF_CRIT );

  buff.power_swell = MBF( talent.power_swell.ok(), this, "power_swell", find_spell( 376850 ) )
                         ->set_affects_regen( true )
                         ->set_default_value_from_effect_type( A_MOD_POWER_REGEN_PERCENT );

  buff.reactive_hide = MBF( talent.reactive_hide.ok(), this, "reactive_hide", talent.reactive_hide_buff )
                           ->set_default_value_from_effect( 1, 0.01 );

  buff.time_skip = make_buff_fallback<time_skip_t>( talent.time_skip.ok(), this, "time_skip" );

  buff.feed_the_flames_stacking =
      MBF( talent.feed_the_flames.ok(), this, "feed_the_flames", talent.feed_the_flames_tracker_buff );
  buff.feed_the_flames_pyre =
      MBF( talent.feed_the_flames.ok(), this, "feed_the_flames_pyre", talent.feed_the_flames_proc_trigger );

  if ( talent.feed_the_flames.ok() )
  {
    buff.feed_the_flames_stacking
        ->set_max_stack( as<int>( -talent.feed_the_flames_proc_trigger->effectN( 2 ).base_value() ) )
        ->set_expire_at_max_stack( true )
        ->set_stack_change_callback( [ this ]( buff_t* b, int old, int ) {
          if ( old == b->max_stack() )
          {
            make_event( *sim, [ this ]() { buff.feed_the_flames_pyre->trigger(); } );
          }
        } );
  }

  buff.emerald_trance_stacking =
      MBF( sets->has_set_bonus( EVOKER_DEVASTATION, DF3, B2 ), this, "emerald_trance_stacking", find_spell( 424155 ) )
          ->set_duration( 0_s )
          ->set_constant_behavior( buff_constant_behavior::NEVER_CONSTANT );

  if ( sets->has_set_bonus( EVOKER_DEVASTATION, DF3, B4 ) )
  {
    buff.emerald_trance_stacking->set_stack_change_callback( [ this ]( buff_t*, int old, int _new ) {
      if ( _new < old )
      {
        buff.emerald_trance->trigger( old, old * buff.emerald_trance->buff_duration() );
      }
    } );
  }

  buff.emerald_trance =
      MBF( sets->has_set_bonus( EVOKER_DEVASTATION, DF3, B4 ), this, "emerald_trance", find_spell( 424402 ) )
          ->set_tick_callback( [ this ]( buff_t*, int, timespan_t ) {
            buff.essence_burst->trigger();
            proc.emerald_trance->occur();
          } )
          ->set_freeze_stacks( true );

  buff.jackpot = MBF( sets->has_set_bonus( EVOKER_DEVASTATION, TWW2, B4 ), this, "jackpot", find_spell( 1217769 ) )
                     ->set_default_value_from_effect( 1, 0.01 );

  // Preservation

  // Augmentation
  buff.ebon_might_self_buff =
      MBF( talent.ebon_might.ok(), this, "ebon_might_self", talent.ebon_might_self_buff )
          ->set_refresh_behavior( buff_refresh_behavior::PANDEMIC )
          ->set_tick_callback( [ this ]( buff_t*, int, timespan_t ) {
            static_cast<spells::ebon_might_t*>( background_actions.ebon_might.get() )->update_stats();
          } )
          ->set_stack_change_callback( [ this ]( buff_t*, int _old, int ) {
            if ( _old )
            {
              buff.tww1_4pc_aug->expire();
            }
          } )
          ->set_default_value( 0 )
          ->set_freeze_stacks( true );

  buff.t31_2pc_proc = MBF( sets->has_set_bonus( EVOKER_AUGMENTATION, DF3, B2 ), this, "t31_2pc_proc",
                           sets->set( EVOKER_AUGMENTATION, DF3, B2 ) )
                          ->set_can_cancel( false )
                          ->set_constant_behavior( buff_constant_behavior::NEVER_CONSTANT )
                          ->set_default_value_from_effect( 1, 0.01 )
                          ->set_duration( 0_s );

  buff.t31_2pc_stacks = MBF( sets->has_set_bonus( EVOKER_AUGMENTATION, DF3, B2 ), this, "t31_2pc_stacks" )
                            ->set_can_cancel( false )
                            ->set_constant_behavior( buff_constant_behavior::NEVER_CONSTANT )
                            ->set_duration( 0_s )
                            ->set_max_stack( 3 )
                            ->set_expire_at_max_stack( true )
                            ->set_stack_change_callback( [ this ]( buff_t* b, int _old, int ) {
                              if ( _old == b->max_stack() )
                              {
                                buff.t31_2pc_proc->trigger();
                              }
                            } );

  buff.trembling_earth =
      MBF( sets->has_set_bonus( EVOKER_AUGMENTATION, DF3, B4 ), this, "trembling_earth", find_spell( 424368 ) )
          ->set_stack_behavior( buff_stack_behavior::ASYNCHRONOUS )
          ->set_cooldown( 0_s );

  buff.volcanic_upsurge = MBF( sets->has_set_bonus( EVOKER_AUGMENTATION, TWW1, B2 ), this, "volcanic_upsurge",
                               sets->set( EVOKER_AUGMENTATION, TWW1, B2 )->effectN( 2 ).trigger() );

  buff.tww1_4pc_aug = MBF( sets->has_set_bonus( EVOKER_AUGMENTATION, TWW1, B4 ), this, "evoker_augmentation_tww1_4pc",
                           sets->set( EVOKER_AUGMENTATION, TWW1, B4 )->effectN( 1 ).trigger() )
                          ->set_duration( 0_ms )
                          ->set_constant_behavior( buff_constant_behavior::NEVER_CONSTANT );

  if ( sets->has_set_bonus( EVOKER_AUGMENTATION, TWW1, B4 ) )
  {
    buff.tww1_4pc_aug->set_max_stack(
        as<int>( sets->set( EVOKER_AUGMENTATION, TWW1, B4 )->effectN( 2 ).base_value() /
                 sets->set( EVOKER_AUGMENTATION, TWW1, B4 )->effectN( 1 ).base_value() ) );
    buff.tww1_4pc_aug->set_default_value( sets->set( EVOKER_AUGMENTATION, TWW1, B4 )->effectN( 1 ).percent() / 1000 );
  }

  buff.magnified_fate =
      MBF( sets->has_set_bonus( EVOKER_AUGMENTATION, MID2, B4 ), this, "magnified_fate", find_spell( 1297728 ) )
          ->set_default_value_from_effect( 1, 0.01 );

  buff.duplicate = MBF( talent.duplicate3.ok(), this, "duplicate", talent.duplicate3_buff )
                       ->set_max_stack( 99 )
                       ->set_duration( 0_s )
                       ->set_constant_behavior( buff_constant_behavior::NEVER_CONSTANT )
                       ->set_default_value_from_effect( 2, 0.01 );

  buff.momentum_shift = MBF( talent.momentum_shift.ok(), this, "momentum_shift", find_spell( 408005 ) )
                            ->set_default_value_from_effect( 1 )
                            ->set_pct_buff_type( STAT_PCT_BUFF_INTELLECT );

  // Chronowarden
  buff.primacy = MBF( talent.chronowarden.primacy.ok(), this, "primacy", talent.chronowarden.primacy_buff )
                     ->set_default_value_from_effect( 1 )
                     ->set_pct_buff_type( STAT_PCT_BUFF_HASTE );

  buff.temporal_burst =
      MBF( talent.chronowarden.temporal_burst.ok(), this, "temporal_burst", talent.chronowarden.temporal_burst_buff )
          ->set_cooldown( 0_ms )
          ->set_pct_buff_type( STAT_PCT_BUFF_HASTE )
          ->set_default_value_from_effect( 2 )
          ->set_reverse( true );

  if ( talent.chronowarden.energy_cycles.ok() )
  {
    buff.temporal_burst->set_tick_callback( [ this ]( buff_t* b, int, timespan_t ) {
      if ( ( b->current_tick % as<int>( talent.chronowarden.energy_cycles->effectN( 1 ).base_value() ) ) == 0 )
      {
        buff.essence_burst->trigger();
      }
    } );
  }

  buff.doubletime = MBF( talent.chronowarden.double_time.ok(), this, "doubletime", talent.chronowarden.doubletime_buff )
                        ->set_refresh_behavior( buff_refresh_behavior::EXTEND )
                        ->set_default_value( talent.chronowarden.double_time->effectN( 2 ).percent() );

  buff.time_convergence_intellect = MBF( talent.chronowarden.time_convergence.ok(), this, "time_convergence_intellect",
                                         talent.chronowarden.time_convergence_intellect_buff )
                                        ->set_default_value_from_effect( 1 )
                                        ->set_pct_buff_type( STAT_PCT_BUFF_INTELLECT );
  // Flameshaper
  buff.inner_flame = MBF( sets->has_set_bonus( HERO_FLAMESHAPER, TWW3, B2 ), this, "inner_flame",
                          talent.flameshaper.inner_flame_buff_base )
                         ->set_default_value( talent.flameshaper.inner_flame_buff->effectN( 2 ).percent() )
                         ->set_stack_behavior( buff_stack_behavior::ASYNCHRONOUS );

  // Scalecommander
  buff.mass_disintegrate_stacks = MBF( talent.scalecommander.mass_disintegrate.ok(), this, "mass_disintegrate_stacks",
                                       talent.scalecommander.mass_disintegrate_buff );
  buff.mass_disintegrate_ticks  = MBF( talent.scalecommander.mass_disintegrate.ok(), this, "mass_disintegrate_ticks",
                                       talent.scalecommander.mass_disintegrate_buff )
                                     ->set_max_stack( 8 )
                                     ->set_proc_callbacks( false );

  buff.mass_eruption_stacks = MBF( talent.scalecommander.mass_eruption.ok(), this, "mass_eruption_stacks",
                                   talent.scalecommander.mass_eruption_buff );
  buff.unrelenting_siege    = MBF( talent.scalecommander.unrelenting_siege.ok(), this, "unrelenting_siege",
                                   talent.scalecommander.unrelenting_siege_buff )
                               ->set_constant_behavior( buff_constant_behavior::NEVER_CONSTANT )
                               ->set_freeze_stacks( true )
                               ->set_tick_callback( []( buff_t* b, int, timespan_t ) {
                                 if ( !b->at_max_stacks() )
                                   b->bump( 1, b->current_value );
                               } );

  buff.azure_sweep =
      MBF( talent.azure_sweep.ok(), this, "azure_sweep", talent.azure_sweep_buff )->set_consume_all_stacks( false );

  if ( sets->has_set_bonus( EVOKER_DEVASTATION, MID1, B4 ) )
  {
    buff.azure_sweep->set_initial_stack(
        1 + as<int>( sets->set( EVOKER_DEVASTATION, MID1, B4 )->effectN( 1 ).base_value() ) );
  }

  buff.strafing_run = MBF( talent.strafing_run.ok(), this, "strafing_run", talent.strafing_run_buff )
                          ->add_stack_change_callback( [ this ]( buff_t*, int old, int cur ) {
                            cooldown.deep_breath->adjust_max_charges( cur - old );
                          } );
}

void evoker_t::create_options()
{
  player_t::create_options();

  add_option( opt_bool( "evoker.use_clipping", option.use_clipping ) );
  add_option( opt_bool( "evoker.use_early_chaining", option.use_early_chaining ) );
  add_option( opt_float( "evoker.scarlet_overheal", option.scarlet_overheal, 0.0, 1.0 ) );
  add_option( opt_float( "evoker.heal_eb_chance", option.heal_eb_chance, 0.0, 1.0 ) );
  add_option( opt_timespan( "evoker.prepull_deep_breath_delay", option.prepull_deep_breath_delay, 0_s, 3_s ) );
  add_option(
      opt_timespan( "evoker.prepull_deep_breath_delay_stddev", option.prepull_deep_breath_delay_stddev, 0_s, 1.5_s ) );
  add_option( opt_float( "evoker.naszuro_bounce_chance", option.naszuro_bounce_chance, 0.0, 1.0 ) );
  add_option( opt_bool( "evoker.naszuro_accurate_behaviour", option.naszuro_accurate_behaviour ) );
  add_option( opt_bool( "evoker.naszuro_bounce_destroy_solo", option.naszuro_bounce_destroy_solo ) );
  add_option( opt_string( "evoker.force_clutchmates", option.force_clutchmates ) );
  add_option( opt_bool( "evoker.make_simplified_if_alone", option.make_simplified_if_alone ) );
  add_option( opt_bool( "evoker.remove_precombat_ancient_flame", option.remove_precombat_ancient_flame ) );
  add_option( opt_int( "evoker.simplified_actor_ilevel", option.simplified_actor_ilevel, 0, 4096 ) );
  add_option( opt_float( "evoker.ally_skill", option.ally_skill, 0, 10 ) );
  add_option( opt_bool( "evoker.simulate_bombardments", option.simulate_bombardments ) );
  add_option( opt_timespan( "evoker.simulate_bombardments_time_between_procs_mean",
                            option.simulate_bombardments_time_between_procs_mean, 0_s, 9999_s ) );
  add_option( opt_timespan( "evoker.simulate_bombardments_time_between_procs_stddev",
                            option.simulate_bombardments_time_between_procs_stddev, 0_s, 9999_s ) );
  add_option( opt_timespan( "evoker.allied_virtual_cd_time", option.allied_virtual_cd_time, 0_s, 9999_s ) );
  add_option(
      opt_float( "evoker.simulate_bombardments_fixed_crit", option.simulate_bombardments_fixed_crit, 0.05, 1.0 ) );

  add_option( opt_int( "evoker.fire_breath_default_rank", option.fire_breath_default_rank, 0, 5 ) );
  add_option( opt_int( "evoker.eternity_surge_default_rank", option.eternity_surge_default_rank, 0, 5 ) );
  add_option( opt_int( "evoker.upheaval_default_rank", option.upheaval_default_rank, 0, 5 ) );
  add_option( opt_bool( "evoker.allow_precombat_buffs_for_debug", option.allow_precombat_buffs_for_debug ) );
  add_option( opt_int( "evoker.estimated_raid_dps_allies", option.estimated_raid_dps_allies ) );
  add_option( opt_bool( "evoker.patchwerk_in_dungeon", option.patchwerk_in_dungeon ) );
  add_option( opt_bool( "evoker.nerf_em_for_external_sims", option.nerf_em_for_external_sims ) );
  add_option( opt_bool( "evoker.force_raid", option.force_raid ) );
  add_option( opt_string( "evoker.shifting_sands_target_if_str", option.shifting_sands_target_if_str ) );
  add_option( opt_bool( "evoker.sands_shuffle_list", option.sands_shuffle_list ) );
}

void evoker_t::analyze( sim_t& sim )
{
  // For proper DPET analysis, we need to treat empowered spell stat objs as non-channelled so the dot ticks from fire
  // breath do not get summed up into total execute time. All empowered spells have a release spell that is pushed onto
  // secondary_action_list, which we can use to find stat objs for empowered actions without having to go through the
  // entire action_list. See empower_charge_spell_t::tick() for more notes.
  for ( auto a : secondary_action_list )
  {
    if ( auto emp = dynamic_cast<spells::empowered_charge_spell_t*>( a->stats->action_list[ 0 ] ) )
      range::for_each( emp->stats->action_list, []( action_t* a ) { a->channeled = false; } );
  }

  player_t::analyze( sim );
}

void evoker_t::moving()
{
  // If we are mid-empower and forced to move, we don't want player_t::interrupt() to schedule_ready as the release
  // action will handle that for us. We set the bool here and override player_t::schedule_ready to return if bool is
  // set.
  if ( channeling && dynamic_cast<spells::empowered_charge_spell_t*>( channeling ) )
    was_empowering = true;

  player_t::moving();
}

void evoker_t::schedule_ready( timespan_t delta_time, bool waiting )
{
  if ( was_empowering )
    return;

  player_t::schedule_ready( delta_time, waiting );
}

void evoker_t::combat_begin()
{
  player_t::combat_begin();

  if ( !option.allow_precombat_buffs_for_debug )
  {
    if ( talent.prescience.enabled() )
    {
      while ( !allies_with_my_prescience.empty() )
      {
        find_target_data( *allies_with_my_prescience.begin() )->buffs.prescience->cancel();
      }
    }

    if ( talent.ebon_might.enabled() )
    {
      while ( !allies_with_my_ebon.empty() )
      {
        find_target_data( *allies_with_my_ebon.begin() )->buffs.prescience->cancel();
      }
      buff.ebon_might_self_buff->cancel();
    }
  }

  if ( talent.ancient_flame.enabled() && option.remove_precombat_ancient_flame )
  {
    buff.ancient_flame->cancel();
  }
}

void evoker_t::reset()
{
  player_t::reset();

  // clear runtime variables
  allies_with_my_ebon.clear_without_callbacks();
  allies_with_my_prescience.clear_without_callbacks();
  allies_with_my_shifting_sands.clear_without_callbacks();
  allied_ebons_on_me.clear();
  active_infernos_blessings.clear();
  last_scales_target = nullptr;
  was_empowering     = false;

  // Reset Chrono Flame Buckets
  if ( talent.chronowarden.chrono_flame.enabled() )
  {
    for ( evoker_td_t* td : target_data.get_entries() )
    {
      if ( !td )
        continue;

      td->chrono_tracker.last_accessed_second = 0;

      for ( auto& bucket : td->chrono_tracker.damage_buckets )
      {
        bucket = 0;
      }
    }
  }
}

void evoker_t::copy_from( player_t* source )
{
  player_t::copy_from( source );

  option = debug_cast<evoker_t*>( source )->option;
}

void evoker_t::merge( player_t& other )
{
  player_t::merge( other );
}

std::string evoker_t::default_potion() const
{
  return evoker_apl::potion( this );
}

std::string evoker_t::default_flask() const
{
  return evoker_apl::flask( this );
}

std::string evoker_t::default_food() const
{
  return evoker_apl::food( this );
}

std::string evoker_t::default_rune() const
{
  return evoker_apl::rune( this );
}

std::string evoker_t::default_temporary_enchant() const
{
  return evoker_apl::temporary_enchant( this );
}

const evoker_td_t* evoker_t::find_target_data( const player_t* target ) const
{
  return target_data[ target ];
}

evoker_td_t* evoker_t::get_target_data( player_t* target ) const
{
  evoker_td_t*& td = target_data[ target ];
  if ( !td )
    td = new evoker_td_t( target, const_cast<evoker_t*>( this ) );
  return td;
}

action_t* evoker_t::create_action( std::string_view name, std::string_view options_str )
{
  using namespace spells;

  if ( name == "azure_strike" )
    return new azure_strike_t( this, options_str );
  if ( name == "azure_sweep" )
    return new azure_sweep_t( this, options_str );
  if ( name == "deep_breath" )
    return new deep_breath_t( this, options_str );
  if ( name == "disintegrate" )
    return new disintegrate_t( this, options_str );
  if ( name == "dragonrage" )
    return new dragonrage_t( this, options_str );
  if ( name == "eternity_surge" )
    return new eternity_surge_t( this, options_str );
  if ( name == "expunge" )
    return new expunge_t( this, options_str );
  if ( name == "fire_breath" )
    return new fire_breath_t( this, options_str );
  if ( name == "hover" )
    return new hover_t( this, options_str );
  if ( name == "landslide" )
    return new landslide_t( this, options_str );
  if ( name == "living_flame" )
    return new living_flame_t( this, options_str );
  if ( name == "obsidian_scales" )
    return new obsidian_scales_t( this, options_str );
  if ( name == "pyre" )
    return new pyre_t( this, options_str );
  if ( name == "quell" )
    return new quell_t( this, options_str );
  if ( name == "tip_the_scales" )
    return new tip_the_scales_t( this, options_str );
  if ( name == "verdant_embrace" )
    return new heals::verdant_embrace_t( this, options_str );
  if ( name == "emerald_blossom" )
    return new heals::emerald_blossom_t( this, options_str );
  if ( name == "ebon_might" )
    return new ebon_might_t( this, options_str );
  if ( name == "eruption" )
    return new eruption_t( this, "eruption", options_str );
  if ( name == "upheaval" )
    return new upheaval_t( this, options_str );
  if ( name == "prescience" )
    return new prescience_t( this, options_str );
  if ( name == "breath_of_eons" )
    return new breath_of_eons_t( this, options_str );
  if ( name == "blistering_scales" )
    return new blistering_scales_t( this, options_str );
  if ( name == "time_skip" )
    return new time_skip_t( this, options_str );
  if ( name == "time_spiral" )
    return new time_spiral_t( this, options_str );
  if ( name == "oppressing_roar" )
    return new oppressing_roar_t( this, options_str );
  if ( name == "fury_of_the_aspects" )
    return new fury_of_the_aspects_t( this, options_str );
  if ( sim->dbc->wowv() >= wowv_t( 12, 1, 0 ) && name == "unbound_flame" )
    return new unbound_flame_t( this, options_str );

  return player_t::create_action( name, options_str );
}

std::unique_ptr<expr_t> evoker_t::create_expression( std::string_view expr_str )
{
  auto splits = util::string_split<std::string_view>( expr_str, "." );

  if ( util::str_compare_ci( expr_str, "essense" ) || util::str_compare_ci( expr_str, "essences" ) )
    return make_ref_expr( expr_str, resources.current[ RESOURCE_ESSENCE ] );

  if ( splits.size() >= 2 )
  {
    if ( util::str_compare_ci( splits[ 0 ], "evoker" ) )
    {
      if ( util::str_compare_ci( splits[ 1 ], "active_infernos_blessings" ) )
      {
        return make_fn_expr( "active_infernos_blessings", [ this ] { return active_infernos_blessings.size(); } );
      }
      if ( util::str_compare_ci( splits[ 1 ], "allied_cds_up" ) )
      {
        return make_fn_expr( "allied_cds_up", [ this ] {
          auto* vec = &allies_with_my_ebon;
          if ( allies_with_my_ebon.size() == 0 )
          {
            if ( allies_with_my_prescience.size() > 0 )
            {
              vec = &allies_with_my_prescience;
            }
            else
            {
              return 0;
            }
          }

          int out = 0;

          for ( auto p : *vec )
          {
            if ( ( allied_major_cds.count( p ) && allied_major_cds[ p ] && allied_major_cds[ p ]->check() ) ||
                 p->type == PLAYER_SIMPLIFIED )
            {
              out++;
            }
          }

          return out;
        } );
      }
      if ( util::str_compare_ci( splits[ 1 ], "prescience_buffs" ) )
        return make_fn_expr( "prescience_buffs", [ this ] { return allies_with_my_prescience.size(); } );
      if ( util::str_compare_ci( splits[ 1 ], "ebon_buffs" ) )
        return make_fn_expr( "ebon_buffs", [ this ] { return allies_with_my_ebon.size(); } );
      if ( util::str_compare_ci( splits[ 1 ], "shifting_buffs" ) )
        return make_fn_expr( "shifting_buffs", [ this ] { return allies_with_my_shifting_sands.size(); } );
      if ( util::str_compare_ci( splits[ 1 ], "scales_up" ) )
        return make_fn_expr( "scales_up", [ this ] {
          return last_scales_target != nullptr &&
                 get_target_data( last_scales_target )->buffs.blistering_scales->check();
        } );
      if ( util::str_compare_ci( splits[ 1 ], "use_clipping" ) )
        return expr_t::create_constant( "use_clipping", option.use_clipping );
      if ( util::str_compare_ci( splits[ 1 ], "use_early_chaining" ) )
        return expr_t::create_constant( "use_early_chaining", option.use_early_chaining );
      throw sc_invalid_apl_argument( fmt::format( "Unsupported evoker expression '{}'.", splits[ 1 ] ) );
    }
  }

  return player_t::create_expression( expr_str );
}

// Stat & Multiplier overrides ==============================================
double evoker_t::matching_gear_multiplier( attribute_e attr ) const
{
  return player_t::matching_gear_multiplier( attr );
}

double evoker_t::composite_base_armor_multiplier() const
{
  double a = player_t::composite_base_armor_multiplier();

  return a;
}

double evoker_t::composite_armor() const
{
  double a = player_t::composite_armor();

  return a;
}

double evoker_t::composite_base_armor() const
{
  double a = current.stats.armor;

  a *= composite_base_armor_multiplier();
  a *= composite_armor_multiplier();

  return a;
}

double evoker_t::composite_attribute_multiplier( attribute_e attr ) const
{
  double am = player_t::composite_attribute_multiplier( attr );

  return am;
}

double evoker_t::composite_player_multiplier( school_e s ) const
{
  double m = player_t::composite_player_multiplier( s );

  return m;
}

double evoker_t::composite_player_target_crit_chance( player_t* target ) const
{
  double m = player_t::composite_player_target_crit_chance( target );

  if ( talent.flameshaper.conduit_of_flame.ok() )
  {
    if ( target->health_percentage() > talent.flameshaper.conduit_of_flame->effectN( 2 ).base_value() )
    {
      m += talent.flameshaper.conduit_of_flame->effectN( 1 ).percent();
    }
  }

  return m;
}

double evoker_t::composite_spell_haste() const
{
  double h = player_t::composite_spell_haste();

  if ( buff.fury_of_the_aspects )
    h *= 1.0 / ( 1.0 + buff.fury_of_the_aspects->check_value() );

  return h;
}

double evoker_t::composite_melee_haste() const
{
  double h = player_t::composite_melee_haste();

  if ( buff.fury_of_the_aspects )
    h *= 1.0 / ( 1.0 + buff.fury_of_the_aspects->check_value() );

  return h;
}

double evoker_t::composite_mitigation_multiplier( const action_state_t* s, school_e school, bool direct ) const
{
  double m = player_t::composite_mitigation_multiplier( s, school, direct );

  if ( buff.obsidian_scales->check() )
    m *= 1.0 + buff.obsidian_scales->check_value();

  if ( talent.inherent_resistance.ok() )
  {
    const auto& eff = talent.inherent_resistance->effectN( 1 );
    if ( eff.has_common_school( school ) )
      m *= 1.0 + eff.percent();
  }

  return m;
}

stat_e evoker_t::convert_hybrid_stat( stat_e stat ) const
{
  switch ( stat )
  {
    case STAT_STR_AGI_INT:
    case STAT_AGI_INT:
    case STAT_STR_INT:
      return STAT_INTELLECT;
    case STAT_STR_AGI:
    case STAT_SPIRIT:
    case STAT_BONUS_ARMOR:
      return STAT_NONE;
    default:
      return stat;
  }
}

void evoker_t::bounce_naszuro( player_t* s, timespan_t remains = timespan_t::min() )
{
  if ( !naszuro )
    return;

  if ( remains <= 0_s && remains != timespan_t::min() )
    return;

  if ( sim->single_actor_batch )
  {
    if ( option.naszuro_bounce_destroy_solo )
      return;

    get_target_data( s )->buffs.unbound_surge->trigger( remains );
    return;
  }

  player_t* p = s;

  std::vector<player_t*> non_sleeping_players_unbound_surge    = {};
  std::vector<player_t*> non_sleeping_players_no_unbound_surge = {};

  for ( auto p : sim->player_no_pet_list )
  {
    if ( !p->is_sleeping() )
    {
      if ( get_target_data( p )->buffs.unbound_surge->check() )
      {
        non_sleeping_players_unbound_surge.push_back( p );
      }
      else
      {
        non_sleeping_players_no_unbound_surge.push_back( p );
      }
    }
  }

  // TODO: Improve target selection (CD Based)
  if ( non_sleeping_players_no_unbound_surge.size() > 0 )
  {
    p = non_sleeping_players_no_unbound_surge[ rng().range( non_sleeping_players_no_unbound_surge.size() ) ];
  }
  else if ( non_sleeping_players_unbound_surge.size() > 0 )
  {
    p = non_sleeping_players_unbound_surge[ rng().range( non_sleeping_players_unbound_surge.size() ) ];
  }

  if ( option.naszuro_bounce_destroy_solo &&
       ( non_sleeping_players_no_unbound_surge.size() + non_sleeping_players_unbound_surge.size() ) == 1 )
    return;

  get_target_data( p )->buffs.unbound_surge->trigger( remains );
}

void evoker_t::spawn_mote_of_possibility( player_t* prospective_player, mote_buffs_e mote_buff, timespan_t /* delay */ )
{
  player_t* target = prospective_player;

  if ( target && target->is_sleeping() )
    target = nullptr;

  if ( mote_buff == mote_buffs_e::MAX )
  {
    mote_buff = mote_buffs_e(
        rng().range<unsigned>( talent.clairvoyant.enabled() ? mote_buffs_e::MAX : mote_buffs_e::PRESCIENCE ) );
  }

  if ( !target )
  {
    target                        = this;
    std::vector<player_t*> helper = sim->player_non_sleeping_list.data();
    helper.erase( std::remove_if( helper.begin(), helper.end(), []( player_t* t ) { return t->is_pet(); } ),
                  helper.end() );

    switch ( mote_buff )
    {
      case mote_buffs_e::INFERNOS_BLESSING:
      case mote_buffs_e::PRESCIENCE:
      case mote_buffs_e::SYMBIOTIC_BLOOM:
      case mote_buffs_e::SHIFTING_SANDS:
      default:
        target = rng().range( helper );

        bool in_dungeon = ( sim->fight_style == FIGHT_STYLE_DUNGEON_ROUTE ||
                            sim->fight_style == FIGHT_STYLE_DUNGEON_SLICE || option.patchwerk_in_dungeon );
        // Roll again if it picks a tank, a healer, or you. These are not likely outcomes if played well.
        if ( ( target == this || target->primary_role() == ROLE_TANK || target->primary_role() == ROLE_HEAL ) &&
             !in_dungeon )
          target = rng().range( helper );
        break;
    }
  }

  assert( target && "Target should be non-null" );

  if ( mote_buff == mote_buffs_e::INFERNOS_BLESSING )
  {
    get_target_data( target )->buffs.infernos_blessing->trigger();
  }
  else if ( mote_buff == mote_buffs_e::PRESCIENCE )
  {
    double prescience_value = get_target_data( target )->buffs.prescience->default_value;

    if ( talent.chronowarden.double_time.enabled() && rng().roll( cache.spell_crit_chance() ) )
    {
      prescience_value *= 1.0 + talent.chronowarden.double_time->effectN( 2 ).percent();
    }

    get_target_data( target )->buffs.prescience->trigger( 1, prescience_value );
  }
  else if ( mote_buff == mote_buffs_e::SHIFTING_SANDS )
  {
    auto td        = get_target_data( target );
    auto buff_size = cache.mastery_value();
    td->buffs.shifting_sands->trigger( 1, buff_size );
  }
  else if ( mote_buff == mote_buffs_e::SYMBIOTIC_BLOOM )
  {
    auto& buff = get_target_data( target )->buffs.symbiotic_bloom;
    // Always triggers with at least 6%
    buff->trigger( 1, buff->default_value + 0.06 );
  }
}

void evoker_t::extend_ebon( timespan_t extend )
{
  if ( background_actions.ebon_might )
  {
    static_cast<spells::ebon_might_t*>( background_actions.ebon_might.get() )->extend_ebon( extend );
  }
}

// Basic Parse Effects implementation for pets.
template <class T_PET, class Base>
void pets::pet_action_t<T_PET, Base>::apply_pet_action_effects()
{
  parse_effects( evoker()->buff.ebon_might_self_buff );

  if ( evoker()->talent.scalecommander.unrelenting_siege.enabled() )
  {
    parse_effects( evoker()->buff.unrelenting_siege );
  }

  auto burst_mask    = effect_mask_t( true ).enable( 2, 3 );
  parse_effects( evoker()->buff.essence_burst, burst_mask );

  if ( evoker()->talent.duplicate3.enabled() )
  {
    parse_effects( evoker()->buff.duplicate, IGNORE_STACKS );
  }
}

template <class T_PET, class Base>
void pets::pet_action_t<T_PET, Base>::apply_pet_target_effects()
{
  using namespace pets;
}

void evoker_t::apply_bombardments( player_t* target )
{
  auto td = get_target_data( target );
  td->debuffs.bombardments->trigger();

  auto bombardments_buff = debug_cast<buffs::bombardments_buff_t*>( td->debuffs.bombardments );

  auto callback = bombardments_buff->cb;

  if ( callback )
  {
    auto cd = callback->get_cooldown( this );
    assert( cd && "Bombardments CD Must Exist" );
    cd->reset( false );
    sim->print_debug( "{} resets cooldown of bombardments on target {} as bombardments is applied.", this->name_str,
                      target->name_str );
  }
}

double evoker_t::composite_player_pet_damage_multiplier( const action_state_t* s, bool guardian ) const
{
  double m = player_t::composite_player_pet_damage_multiplier( s, guardian );

  return m;
}

double evoker_t::non_stacking_movement_modifier() const
{
  double ms = player_t::non_stacking_movement_modifier();

  if ( buff.hover->check() )
    ms = std::max( ms, buff.hover->check_value() + buff.tailwind->check_value() );

  return ms;
}

double evoker_t::stacking_movement_modifier() const
{
  auto ms = player_t::stacking_movement_modifier();

  // hardcode 75% from spell desc; not found in spell data
  if ( talent.exuberance.ok() && health_percentage() > 75 )
    ms += talent.exuberance->effectN( 1 ).percent();

  return ms;
}

double evoker_t::resource_regen_per_second( resource_e resource ) const
{
  auto rrps = player_t::resource_regen_per_second( resource );

  if ( resource == RESOURCE_ESSENCE )
    rrps *= 1.0 + buff.power_swell->check_value();

  return rrps;
}

// Utility functions ========================================================

// Utility function to search spell data for matching effect.
// NOTE: This will return the FIRST effect that matches parameters.
const spelleffect_data_t* evoker_t::find_spelleffect( const spell_data_t* spell, effect_subtype_t subtype,
                                                      int misc_value, const spell_data_t* affected, effect_type_t type )
{
  for ( size_t i = 1; i <= spell->effect_count(); i++ )
  {
    const auto& eff = spell->effectN( i );

    if ( affected->ok() && !affected->affected_by_all( eff ) )
      continue;

    if ( eff.type() == type && ( eff.subtype() == subtype || subtype == A_MAX ) &&
         ( eff.misc_value1() == misc_value || misc_value == 0 ) )
    {
      return &eff;
    }
  }

  return &spelleffect_data_t::nil();
}

// Return the appropriate spell when `base` is overriden to another spell by `passive`
const spell_data_t* evoker_t::find_spell_override( const spell_data_t* base, const spell_data_t* passive )
{
  if ( !passive->ok() || !base->ok() )
    return base;

  auto id = as<unsigned>( find_spelleffect( passive, A_OVERRIDE_ACTION_SPELL, base->id() )->base_value() );
  if ( !id )
    return base;

  return find_spell( id );
}

/* Report Extension Class
 * Here you can define class specific report extensions/overrides
 */
class evoker_report_t : public player_report_extension_t
{
public:
  evoker_report_t( evoker_t& player ) : p( player )
  {
  }

  void html_customsection( report::sc_html_stream& /*os*/ ) override
  {
  }

private:
  [[maybe_unused]] evoker_t& p;
};

class player_simplified_report_t : public player_report_extension_t
{
public:
  player_simplified_report_t( simplified_player_t& player ) : p( player )
  {
  }

  void html_customsection( report::sc_html_stream& /*os*/ ) override
  {
  }

private:
  [[maybe_unused]] simplified_player_t& p;
};

// EVOKER MODULE INTERFACE ==================================================
struct evoker_module_t : public module_t
{
  evoker_module_t() : module_t( EVOKER )
  {
  }

  player_t* create_player( sim_t* sim, std::string_view name, race_e r = RACE_NONE ) const override
  {
    auto p              = new evoker_t( sim, name, r );
    p->report_extension = std::make_unique<evoker_report_t>( *p );
    return p;
  }

  bool valid() const override
  {
    return true;
  }

  void static_init() const override
  {
    unique_gear::register_special_effect( 394927, karnalex_the_first_light );
    unique_gear::register_special_effect( 405061, insight_of_naszuro );
  }

  void register_hotfixes() const override
  {
  }

  void register_actor_initializers( sim_t* sim ) const override
  {
    sim->register_actor_initializer( INIT_ACTOR_CREATE_ACTIONS + offset(), [ sim ]( player_t* p ) {
      if ( !p->is_player() )
        return;

      // Only create if an evoker is in the sim
      if ( !range::count_if( sim->player_no_pet_list, []( player_t* p ) { return p->type == EVOKER; } ) )
        return;

      new spells::infernos_blessing_t( p );
      new spells::blistering_scales_damage_t( p );
      new spells::fate_mirror_damage_t( p );
      new spells::fate_mirror_heal_t( p );
      new spells::breath_of_eons_damage_t( p );
      new spells::bombardments_damage_t( p );
    }, "create_actions_evoker" );
  }
};

// EVOKER MODULE INTERFACE ==================================================
struct player_simplified_module_t : public module_t
{
  player_simplified_module_t() : module_t( PLAYER_SIMPLIFIED )
  {
  }

  player_t* create_player( sim_t* sim, std::string_view name, race_e r = RACE_NONE ) const override
  {
    auto p              = new simplified_player_t( sim, name, r );
    p->report_extension = std::make_unique<player_simplified_report_t>( *p );
    return p;
  }

  bool valid() const override
  {
    return true;
  }

  void register_hotfixes() const override
  {
  }

  void register_actor_initializers( sim_t* ) const override
  {
  }
};
}  // namespace

const module_t* module_t::evoker()
{
  static evoker_module_t m;
  return &m;
}

const module_t* module_t::player_simplified()
{
  static player_simplified_module_t m;
  return &m;
}
