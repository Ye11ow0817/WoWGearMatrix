// ==========================================================================
// Dedmonwakeen's Raid DPS/TPS Simulator.
// Send questions to natehieter@gmail.com
// ==========================================================================

#include "sim.hpp"

#include "buff/buff.hpp"
#include "class_modules/class_module.hpp"
#include "dbc/dbc.hpp"
#include "dbc/spell_query/spell_data_expr.hpp"
#include "interfaces/bcp_api.hpp"
#include "interfaces/sc_http.hpp"
#include "player/pet.hpp"
#include "player/player.hpp"
#include "player/spawner_base.hpp"
#include "player/unique_gear.hpp"
#include "report/json/report_configuration.hpp"
#include "report/reports.hpp"
#include "report/highchart.hpp"
#include "profileset.hpp"
#include "sim/event.hpp"
#include "sim/iteration_data_entry.hpp"
#include "sim/plot.hpp"
#include "sim/raid_event.hpp"
#include "sim/reforge_plot.hpp"
#include "sim/cooldown.hpp"
#include "sim/expressions.hpp"
#include "sim/option.hpp"
#include "sim/profileset.hpp"
#include "sim/scale_factor_control.hpp"
#include "sim/sim_control.hpp"
#include "sim/work_queue.hpp"
#include "util/string_view.hpp"
#include "util/xml.hpp"

#include <algorithm>
#include <iostream>
#include <random>
#include <sstream>
#ifdef SC_WINDOWS
#include <direct.h>
#endif

namespace { // UNNAMED NAMESPACE ============================================

// Comparator for iteration data entry sorting (see analyze_iteration_data)
bool iteration_data_cmp( const iteration_data_entry_t& a,
                         const iteration_data_entry_t& b )
{
  if ( a.metric > b.metric )
  {
    return true;
  }
  else if ( a.metric == b.metric )
  {
    if ( a.seed != b.seed )
    {
      return a.seed > b.seed;
    }
    else
    {
      return &a > &b;
    }
  }

  return false;
}

bool iteration_data_cmp_r( const iteration_data_entry_t& a,
                          const iteration_data_entry_t& b )
{
  if ( a.metric > b.metric )
  {
    return false;
  }
  else if ( a.metric == b.metric )
  {
    if ( a.seed != b.seed )
    {
      return a.seed > b.seed;
    }
    else
    {
      return &a > &b;
    }
  }

  return true;
}

struct seed_predicate_t
{
  uint64_t seed;

  seed_predicate_t( uint64_t seed_ ) : seed( seed_ )
  { }

  bool operator()( const iteration_data_entry_t& e ) const
  { return e.seed == seed; }
};

// parse_debug_seed =========================================================

bool parse_debug_seed( sim_t* sim, util::string_view, util::string_view value )
{
  auto split = util::string_split( value, ":/," );

  for ( const auto& seed_str : split )
  {

    uint64_t seed = std::stoull( seed_str );
    sim -> debug_seed.push_back( seed );
  }

  range::sort( sim -> debug_seed );

  if ( sim->debug_seed.empty() )
  {
    throw sc_invalid_sim_argument( "Could not parse any debug seeds." );
  }

  return true;
}

/**
 * Parse json= option.
 *
 * General structure is: json=destination[,<option>=<value>]
 *
 * destination: path to which the report is written.
 *
 * Valid options:
 * - version [string]: Requested report version, which follow semver. This option can be a specific report version, or a semver interval like ">=2.0.0".
 * - full_states [bool]: Collects and reports full action and other states, greatly increasing the report size.
 * - pretty_print [bool]: Pretty-print (whitespaces and indentation) the report.
 * - decimal_places [int]: limit floating point decimal places. Valid if > 0
 */
bool parse_json_reports( sim_t* sim, util::string_view /* option_name */, util::string_view value )
{
  auto splits = util::string_split<util::string_view>( value, ",", false );

  if ( splits.empty() || splits[ 0 ].empty() )
  {
    throw sc_invalid_sim_argument( "Missing JSON report output file name." );
  }

  auto destination = splits[0];
  std::string report_version;
  bool fullStates = false;
  bool pretty_print = false;
  int decimal_places = 0;
  if ( splits.size() > 1 )
  {
    for ( std::size_t i = 1; i < splits.size(); ++i )
    {
      const auto& split = splits[ i ];

      auto splitOptions = util::string_split<util::string_view>( split, "=" );
      if ( splitOptions.size() != 2 )
      {
        continue;
      }
      if ( splitOptions[ 0 ] == "version" )
      {
        report_version = std::string( splitOptions[ 1 ] );
      }
      if ( splitOptions[ 0 ] == "full_states" )
      {
        try
        {
          fullStates = util::to_int( splitOptions[ 1 ] );
          if ( fullStates )
          {
            // We need to set the global json full states so extra data gets produced if one report requests it.
            sim->json_full_states = true;
          }
        }
        catch ( const std::exception& )
        {
          std::throw_with_nested( std::runtime_error( "Canot parse JSON report option 'full_states'" ) );
        }
      }
      if ( splitOptions[ 0 ] == "pretty_print" )
      {
        try
        {
          pretty_print = util::to_int( splitOptions[ 1 ] );
        }
        catch ( const std::exception& )
        {
          std::throw_with_nested( std::runtime_error( "Canot parse JSON report option 'pretty_print'" ) );
        }
      }
      if ( splitOptions[ 0 ] == "decimal_places" )
      {
        // limit floating point decimal places. Valid if > 0
        try
        {
          decimal_places = util::to_int( splitOptions[ 1 ] );
        }
        catch ( const std::exception& )
        {
          std::throw_with_nested( std::runtime_error( "Canot parse JSON report option 'decimal places'" ) );
        }
      }
    }
  }

  auto entry = report::json::create_report_entry( *sim, std::move(report_version), std::string(destination) );
  entry.full_states = fullStates;
  entry.decimal_places = decimal_places;
  entry.pretty_print = pretty_print;

  sim->json_reports.push_back( std::move( entry ) );

  return true;
}

bool replace_json2( sim_t* sim, util::string_view /*option_name*/, util::string_view value )
{
  // Redirect existing json2=value option to json=value,version=2
  return parse_json_reports(sim, "json", fmt::format("{},version=2", value));
}

// parse_ptr ================================================================

bool parse_ptr( sim_t*             sim,
                       util::string_view name,
                       util::string_view value )
{
  if ( name != "ptr" ) return false;

  if ( SC_USE_PTR )
    sim -> dbc->ptr = util::to_int( value ) != 0;
  else
    sim -> error( "SimulationCraft has not been built with PTR data.  The 'ptr=' option is ignored.\n" );

  return true;
}

// parse_active =============================================================

bool parse_active( sim_t*             sim,
                          util::string_view name,
                          util::string_view value )
{
  if ( name != "active" ) return false;

  if ( value == "owner" )
  {
    if ( sim -> active_player -> is_pet() )
    {
      sim -> active_player = sim -> active_player -> cast_pet() -> owner;
    }
    else
    {
      throw std::invalid_argument( "Active Player is not a pet, cannot refer to 'owner'." );
    }
  }
  else if ( value == "none" || value == "0" )
  {
    sim -> active_player = nullptr;
  }
  else
  {
    if ( sim -> active_player )
    {
      sim -> active_player = sim -> active_player -> find_pet( value );
    }
    if ( ! sim -> active_player )
    {
      sim -> active_player = sim -> find_player( value );
    }
    if ( !sim->active_player )
    {
      throw std::invalid_argument( fmt::format( "Player '{}' not found, cannot make active.", value ) );
    }
  }

  return true;
}

// parse_optimal_raid =======================================================

bool parse_optimal_raid( sim_t*             sim,
                                util::string_view name,
                                util::string_view value )
{
  if ( name != "optimal_raid" ) return false;

  sim -> use_optimal_buffs_and_debuffs( util::to_int( value ) );

  return true;
}

// parse_player =============================================================

bool parse_player( sim_t*             sim,
                          util::string_view name,
                          util::string_view value )
{
  if ( name == "pet" || name == "guardian" )
  {
    std::string::size_type cut_pt = value.find( ',' );
    auto pet_type = value.substr( 0, cut_pt );

    std::string pet_name;
    if ( cut_pt != value.npos )
      pet_name = std::string( value.substr( cut_pt + 1 ) );
    else
      pet_name = std::string( value );

    if ( !sim->active_player )
    {
      throw std::invalid_argument( fmt::format( "Pet '{}' needs a player preceding it.", value ) );
    }

    sim -> active_player = sim -> active_player -> create_pet( pet_name, pet_type );
  }
  else if ( name == "copy" )
  {
    std::string::size_type cut_pt = value.find( ',' );
    auto player_name = value.substr( 0, cut_pt );

    player_t* source;
    if ( cut_pt == value.npos )
    {
      source = sim->active_player;
      if ( !source )
      {
        throw std::invalid_argument( "No active player as source for profile copy, format is 'copy=target[,source]'." );
      }
    }
    else
    {
      auto source_name = value.substr( cut_pt + 1 );
      source = sim->find_player( source_name );
      if ( !source )
      {
        throw std::invalid_argument( fmt::format(
          "Player '{}' not found as source for profile copy, format is 'copy=target[,source]'.", source_name ) );
      }
    }

    assert(source);

    sim -> active_player = module_t::get( source -> type ) -> create_player( sim, player_name );

    if ( sim -> active_player != nullptr )
      sim -> active_player -> copy_from ( source );
  }
  else
  {
    sim -> active_player = nullptr;

    auto player_type = util::parse_player_type( name );
    if ( player_type == PLAYER_NONE )
    {
      throw std::invalid_argument( fmt::format( "Class module '{}' not found.", name ) );
    }
    const module_t* module = module_t::get( player_type );

    if ( !module || !module->valid() )
    {
      throw std::invalid_argument( fmt::format( "Class module '{}' is currently not available.", name ) );
    }
    else
    {
      sim->active_player = module->create_player( sim, value );

      if ( !sim->active_player )
      {
        throw std::invalid_argument( fmt::format( "Unable to create player '{}' with class '{}'.", value, name ) );
      }
    }
  }

  // Create options for player
  if ( sim -> active_player )
    sim -> active_player -> create_options();

  return sim -> active_player != nullptr;
}

// parse_proxy ==============================================================

bool parse_proxy( sim_t*, std::string_view, std::string_view value )
{
  auto splits = util::string_split<std::string_view>( value, "," );

  if ( splits.size() != 3 )
  {
    throw std::invalid_argument( "Proxy format is 'proxy=type,host,port'." );
  }

  if ( splits[ 0 ] != "http" )
  {
    throw std::invalid_argument( fmt::format( "Invalid proxy type '{}'.", splits[ 0 ] ) );
  }

  unsigned port = util::to_unsigned( splits[ 2 ] );
  if ( port <= 0 || port >= 65536 )
  {
    throw std::invalid_argument( fmt::format( "Invalid proxy port '{}', outside range", port ) );
  }

  http::set_proxy( splits[ 0 ], splits[ 1 ], port );
  return true;
}

// parse_cache ==============================================================

bool parse_cache( sim_t*             /* sim */,
                         util::string_view name,
                         util::string_view value )
{
  if ( name == "cache_players" )
  {
    if ( value == "1" ) cache::players( cache::ANY );
    else if ( value == "0" ) cache::players( cache::CURRENT );
    else if ( util::str_compare_ci( value, "only" ) ) cache::players( cache::ONLY );
    else return false;

    return true;
  }

  else if ( name == "cache_items" )
  {
    if ( value == "1" ) cache::items( cache::ANY );
    else if ( value == "0" ) cache::items( cache::CURRENT );
    else if ( util::str_compare_ci( value, "only" ) ) cache::items( cache::ONLY );
    else return false;

    return true;
  }

  else
    return false;
}

// parse_armory =============================================================

class names_and_options_t
{
private:
  static bool is_valid_region( const std::string& s )
  {
    static constexpr std::array<util::string_view, 5> REGIONS { { "us", "eu", "kr", "tw", "cn" } };
    return s.size() == 2 && range::find( REGIONS, s ) != REGIONS.end();
  }

public:
  std::vector<std::string> names;
  std::string region;
  std::string server;
  cache::behavior_e cache;

  names_and_options_t( sim_t* sim, util::string_view context,
                       std::vector<std::unique_ptr<option_t>> client_options, util::string_view input )
  {
    int use_cache = 0;

    std::vector<std::unique_ptr<option_t>> options;
    options = std::move(client_options);
    //options.insert( options.begin(), client_options.begin(), client_options.end() );
    options.push_back( opt_string( "region", region ) );
    options.push_back( opt_string( "server", server ) );
    options.push_back( opt_bool( "cache", use_cache ) );

    names = util::string_split( input, "," );

    std::vector<std::string> names2 = names;
    size_t count = 0;
    for ( const auto& name : names )
    {
      if ( name.find( '=' ) != std::string::npos )
      {
        opts::parse( sim, context, options, name );
      }
      else
      {
        names2[ count++ ] = name;
      }
    }

    names2.resize( count );
    names = names2;

    if ( region.empty() )
    {
      if ( names.size() > 2 )
      {
        region = names[ 0 ];
        // Lowercase regions, always
        std::transform( region.begin(), region.end(), region.begin(), tolower );
        server = names[ 1 ];
        names.erase( names.begin(), names.begin() + 2 );
      }
      else
      {
        region = sim -> default_region_str;
      }
    }
    if ( !is_valid_region( region ) )
    {
      throw std::invalid_argument(
        fmt::format( "Invalid region '{}', available regions: us, eu, kr, tw, cn", region ) );
    }

    if ( server.empty() )
    {
      if ( names.size() > 1 )
      {
        server = names[ 0 ];
        names.erase( names.begin(), names.begin() + 1 );
      }
      else
      {
        server = sim -> default_server_str;
      }
    }

    cache = use_cache ? cache::ANY : cache::players();
  }
};

bool clear_http_cache(sim_t* sim,
  util::string_view name,
  util::string_view value)
{
  assert(name == "http_clear_cache"); (void)name;
  if (value != "0" && !sim->parent)
  {
    http::clear_cache();
  }
  return true;
}

bool parse_armory( sim_t* sim, std::string_view name, std::string_view value )
{
  std::string spec = "active";

  std::vector<std::unique_ptr<option_t>> options;
  options.push_back( opt_string( "spec", spec ) );

  names_and_options_t stuff( sim, name, std::move( options ), value );

  for ( size_t i = 0; i < stuff.names.size(); ++i )
  {
    // Format: name[|spec]
    std::string& player_name = stuff.names[ i ];
    std::string description = spec;

    std::string::size_type pos = player_name.find( '|' );
    if ( pos != player_name.npos )
    {
      description.assign( player_name, pos + 1, player_name.npos );
      player_name.erase( pos );
    }

    player_t* p;

    try
    {
      if ( name == "local_json" )
        p = bcp_api::from_local_json( sim, player_name, std::string( value ), description );
      else
        p = bcp_api::download_player( sim, stuff.region, stuff.server, player_name, description, stuff.cache );

      if ( !p )
        throw std::runtime_error( "Could not download player." );
    }
    catch ( const std::exception& )
    {
      std::throw_with_nested( sc_network_error( fmt::format( "Armory lookup for player '{}'", player_name ) ) );
    }

    sim->active_player = p;
  }

  // Create options for player
  if ( sim->active_player )
    sim->active_player->create_options();

  return sim->active_player != nullptr;
}

bool parse_guild( sim_t* sim, std::string_view name, std::string_view value )
{
  // Save Raid Summary file when guilds are downloaded
  sim->save_raid_summary = 1;

  std::string type_str;
  std::string ranks_str;
  int max_rank = 0;

  std::vector<std::unique_ptr<option_t>> options;
  options.push_back( opt_string( "class", type_str ) );
  options.push_back( opt_int( "max_rank", max_rank ) );
  options.push_back( opt_string( "ranks", ranks_str ) );

  names_and_options_t stuff( sim, name, std::move( options ), value );

  std::vector<int> ranks_list;
  if ( !ranks_str.empty() )
  {
    auto ranks = util::string_split<util::string_view>( ranks_str, "/" );

    for ( const auto& rank : ranks )
      ranks_list.push_back( util::to_int( rank ) );
  }

  player_e pt = PLAYER_NONE;
  if ( !type_str.empty() )
    pt = util::parse_player_type( type_str );

  for ( size_t i = 0; i < stuff.names.size(); ++i )
  {
    std::string& guild_name = stuff.names[ i ];

    try
    {
      if ( !bcp_api::download_guild( sim, stuff.region, stuff.server, guild_name, ranks_list, pt, max_rank,
                                     stuff.cache ) )
      {
        return false;
      }
    }
    catch ( const std::exception& )
    {
      std::throw_with_nested( sc_network_error( fmt::format( "Armory lookup for guild '{}'", guild_name ) ) );
    }
  }

  return true;
}

// parse_fight_style ========================================================

bool parse_fight_style( sim_t*             sim,
                        util::string_view /*name*/,
                        util::string_view value )
{
  sim->fight_style = util::parse_fight_style( value );

  if ( sim->fight_style == FIGHT_STYLE_NONE )
  {
    throw std::invalid_argument( fmt::format( "Invalid fight style '{}'.", value ) );
  }

  // Disable optimal raid setting for Dungeon-style sim types
  if ( sim->fight_style == FIGHT_STYLE_DUNGEON_SLICE || sim->fight_style == FIGHT_STYLE_DUNGEON_ROUTE )
  {
    sim->optimal_raid = 0;
    sim->use_optimal_buffs_and_debuffs( 0 );
  }

  return true;
}

// parse_override_spell_data ================================================

bool parse_override_spell_data( sim_t*             sim,
                                util::string_view /* name */,
                                util::string_view value )
{
  sim->dbc_override->parse( *(sim->dbc), value );
  return true;
}

// parse_override_target_health =============================================

bool parse_override_target_health( sim_t*             sim,
                                   util::string_view /* name */,
                                   util::string_view value )
{
  auto healths = util::string_split<util::string_view>( value, "/" );

  for ( const auto& health : healths )
  {
    std::stringstream s;
    s << std::string( health );
    uint64_t health_number;
    s >> health_number;
    if ( health_number > 0 )
    {
      sim -> overrides.target_health.push_back( health_number );
    }
  }

  return true;
}


// parse_spell_query ========================================================

bool parse_spell_query( sim_t*             sim,
                               util::string_view /* name */,
                               util::string_view value )
{
  auto sq_str = value;
  size_t lvl_offset = util::string_view::npos;

  if ( ( lvl_offset = value.rfind( "@" ) ) != util::string_view::npos )
  {
    auto lvl_offset_str = value.substr( lvl_offset + 1 );
    int sq_lvl = util::to_int( lvl_offset_str );
    if ( sq_lvl < 1 )
      return false;

    if ( sq_lvl > MAX_ILEVEL )
    {
      throw std::invalid_argument(
        fmt::format( "Maximum item level supported in Simulationcraft is {}.", MAX_ILEVEL ) );
    }

    sim->spell_query_level = as<unsigned>( sq_lvl );

    sq_str = sq_str.substr( 0, lvl_offset );
  }

  sim->spell_query = spell_data_expr_t::parse( sim, sq_str );

  if ( sim->spell_query == nullptr )
  {
    throw std::invalid_argument( "Could not build spell query" );
  }
  return sim->spell_query != nullptr;
}

// parse_item_sources =======================================================

// Specifies both the default search order for the various data sources
// and the complete set of valid data source names.
const char* const default_item_db_sources[] =
{
  "local", "bcpapi", "wowhead", "ptrhead", "ptr2head"
#if SC_BETA
  , SC_BETA_STR "head"
#endif
};

bool parse_item_sources( sim_t*             sim,
                                util::string_view /* name */,
                                util::string_view value )
{
  sim -> item_db_sources.clear();

  auto sources = util::string_split<util::string_view>( value, ":/|" );

  for ( const auto& source : sources )
  {
    for ( const auto& default_item_db_source : default_item_db_sources )
    {
      if ( util::str_compare_ci( source, default_item_db_source ) )
      {
        sim -> item_db_sources.emplace_back(default_item_db_source );
        break;
      }
    }
  }

  if ( sim->item_db_sources.empty() )
  {
    throw std::invalid_argument(
      fmt::format( "Invalid global data source, valid sources are: {}.", fmt::join( default_item_db_sources, ", " ) ) );
  }

  return true;
}

bool parse_process_priority( sim_t*             sim,
                                   util::string_view /* name */,
                                   util::string_view value )
{
  computer_process::priority_e pr = computer_process::BELOW_NORMAL;

  if ( util::str_compare_ci( value, "normal" ) )
  {
    pr = computer_process::NORMAL;
  }
  else if ( util::str_compare_ci( value, "above_normal" ) )
  {
    pr = computer_process::ABOVE_NORMAL;
  }
  else if ( util::str_compare_ci( value, "below_normal" ) )
  {
    pr = computer_process::BELOW_NORMAL;
  }
  else if ( util::str_compare_ci( value, "high" ) )
  {
    pr = computer_process::HIGH;
  }
  else if ( util::str_compare_ci( value, "low" ) )
  {
    pr = computer_process::LOW;
  }
  else
  {
    sim -> error( "Could not set thread priority to {}. Defaulting to below_normal priority.", value );
  }

  sim -> process_priority = pr;

  return true;
}

bool parse_target_error_role( sim_t * sim,
                              util::string_view /* name */,
                              util::string_view value )
{
  sim -> target_error_role = util::parse_role_type( value );

  if ( sim->target_error_role == ROLE_NONE )
  {
    throw std::invalid_argument( "Invalid target error role." );
  }

  return true;
}

bool parse_maximize_reporting( sim_t*             sim,
                                   util::string_view /*name*/,
                                   util::string_view v )
{
  if ( v != "0" && v != "1" )
  {
    throw std::invalid_argument( "Acceptable values are '1' or '0'." );
  }
  bool r = util::to_int( v ) != 0;
  if ( r )
  {
    sim -> maximize_reporting = true;
    sim -> statistics_level = 100;
    sim -> report_raid_summary = true;
    sim -> report_rng = true;
    sim -> report_details = true;
    sim -> report_targets = true;
    sim -> report_pets_separately = true;
    sim -> report_precision = 4;
    sim -> buff_uptime_timeline = true;
    sim -> buff_stack_uptime_timeline = true;
  }

  return true;
}

bool parse_report_merged_stats( sim_t* sim, std::string_view, std::string_view value )
{
  static constexpr std::string_view valid_stats[] = { "dps", "dpspct", "count", "critpct" };

  auto splits = util::string_split<std::string_view>( value, ",:/|" );
  for ( auto str : splits )
  {
    if ( !range::contains( valid_stats, str ) )
    {
      throw std::invalid_argument(
        fmt::format( "Invalid report_merged_stats '{}', valid stats are: {}.", str, fmt::join( valid_stats, "," ) ) );
    }
  }

  sim->report_merged_stats = util::string_join( splits, "," );

  return true;
}

/**
 * Parse threads option, and if equal or lower than 0, adjust
 * the number of threads to the number of cpu cores minus the absolute value given as a thread option.
 * So eg. threads=-2 on a 8 core machine will result in 6 threads.
 */
void adjust_threads( int& threads )
{
  // This is to resolve https://github.com/simulationcraft/simc/issues/2304
  int max_threads = sc_thread_t::cpu_thread_count();
  if ( threads <= 0 && max_threads > 0 ) //max_threads will return 0 if it has no clue how many threads it can use.
  {
    threads *= -1;
    if ( threads <= max_threads )
      threads = max_threads - threads;
  }
}

// Proxy cast ===============================================================

struct proxy_cast_check_t : public event_t
{
  int uses;
  const int& _override;
  timespan_t start_time;
  timespan_t cooldown;
  timespan_t duration;

  proxy_cast_check_t( sim_t& s, int u, timespan_t st, timespan_t i, timespan_t cd, timespan_t d, const int& o ) :
    event_t( s, i ),
    uses( u ), _override( o ), start_time( st ), cooldown( cd ), duration( d )
  {
  }
  const char* name() const override
  { return "proxy_cast_check"; }
  virtual bool proxy_check() = 0;
  virtual void proxy_execute() = 0;
  virtual proxy_cast_check_t* proxy_schedule( timespan_t interval ) = 0;

  void execute() override
  {
    timespan_t interval = timespan_t::from_seconds( 0.25 );

    if ( uses == _override && start_time > timespan_t::zero() )
      interval = cooldown - ( sim().current_time() - start_time );

    if ( proxy_check() )
    {
      // Cooldown over, reset uses
      if ( uses == _override && start_time > timespan_t::zero() && ( sim().current_time() - start_time ) >= cooldown )
      {
        start_time = timespan_t::zero();
        uses = 0;
      }

      if ( uses < _override )
      {
        proxy_execute();

        uses++;

        if ( start_time == timespan_t::zero() )
          start_time = sim().current_time();

        interval = duration + timespan_t::from_seconds( 1 );

        if ( sim().debug )
          sim().out_debug.printf( "Proxy-Execute uses=%d total=%d start_time=%.3f next_check=%.3f",
                      uses, _override, start_time.total_seconds(),
                      ( sim().current_time() + interval ).total_seconds() );
      }
    }

    proxy_schedule( interval );
  }
};

struct sim_end_event_t : event_t
{
  sim_end_event_t( sim_t& s, timespan_t end_time ) :
    event_t( s, end_time )
  {
  }
  const char* name() const override
  { return "sim_end_expected_time"; }
  void execute() override
  {
    sim().cancel_iteration();
  }
};

/* Forcefully cancel the iteration if it has unexpectedly taken too long
 * to end normally.
 */
struct sim_safeguard_end_event_t : public sim_end_event_t
{
  timespan_t et;

  sim_safeguard_end_event_t( sim_t& s, timespan_t end_time ) :
    sim_end_event_t( s, end_time ), et( end_time )
  { }

  const char* name() const override
  { return "sim_end_twice_expected_time"; }

  void execute() override
  {
    sim().errorf( "Simulation has been forcefully cancelled at %.3f (%.3f) because twice the "
                  "expected combat length has been exceeded.",
                  sim().current_time().total_seconds(),
                  et.total_seconds() );

    sim_end_event_t::execute();
  }
};

struct resource_timeline_collect_event_t : public event_t
{
  resource_timeline_collect_event_t( sim_t& s ) :
    event_t( s, timespan_t::from_seconds( 1 ) )
  {
  }
  const char* name() const override
  { return "resource_timeline_collect_event_t"; }
  void execute() override
  {
    if ( sim().iterations == 1 || sim().current_iteration > 0 )
    {
      if ( ! sim().single_actor_batch )
      {
        // Assumptions: Enemies do not have primary resource regeneration
        for ( auto* p : sim().player_non_sleeping_list )
        {
           if ( p -> primary_resource() == RESOURCE_NONE ) continue;

          p -> collect_resource_timeline_information();
        }
      }
      else
      {
        auto p = sim().player_no_pet_list[ sim().current_index ];
        if (p && p -> primary_resource() != RESOURCE_NONE)
        {
          p -> collect_resource_timeline_information();
          for ( auto pet : p -> pet_list )
          {
            if ( pet -> primary_resource() != RESOURCE_NONE )
            {
              pet -> collect_resource_timeline_information();
            }
          }
        }
      }

      // However, enemies do have health
      for ( auto* p : sim().target_non_sleeping_list )
      {
         p -> collect_resource_timeline_information();
      }
    }

    make_event<resource_timeline_collect_event_t>( sim(), sim() );
  }
};

struct regen_event_t : public event_t
{
  regen_event_t( sim_t& s ) :
    event_t( s, s.regen_periodicity )
  {
    if ( sim().debug )
    {
      sim().out_debug.printf( "New Regen Event" );
    }
  }

  const char* name() const override
  { return "Regen Event"; }

  void execute() override
  {
    if ( ! sim().single_actor_batch )
    {
      // targets do not get any resource regen for performance reasons
      for ( auto* p : sim().player_non_sleeping_list )
      {
         if ( p -> primary_resource() == RESOURCE_NONE ) continue;
        if ( p ->resource_regeneration !=  regen_type::STATIC ) continue;

        p -> regen( sim().regen_periodicity );
      }
    }
    else
    {
      auto p = sim().player_no_pet_list[ sim().current_index ];
      if ( p && p -> primary_resource() != RESOURCE_NONE && p ->resource_regeneration ==  regen_type::STATIC )
      {
        p -> regen( sim().regen_periodicity );
        for ( auto pet : p -> pet_list )
        {
          if ( ! pet -> is_sleeping() && p -> primary_resource() != RESOURCE_NONE &&
            p ->resource_regeneration ==  regen_type::STATIC )
          {
            pet -> regen( sim().regen_periodicity );
          }
        }
      }
    }

    make_event<regen_event_t>( sim(), sim() );
  }
};

/// List of files from which to look for Blizzard API key
std::vector<std::string> get_api_key_locations()
{
  std::vector<std::string> key_locations;
  key_locations.emplace_back("./apikey.txt" );

  // unix home
  if ( char* home_path = getenv( "HOME" ) )
  {
    std::string home_apikey(home_path);
    home_apikey += "/.simc_apikey";
    key_locations.push_back( home_apikey );
  }

  // windows home
  if ( char* home_drive = getenv( "HOMEDRIVE" ) )
  {
    if ( char* home_path = getenv( "HOMEPATH" ) )
    {
      std::string home_apikey(home_drive);
      home_apikey += home_path;
      home_apikey += "/apikey.txt";
      key_locations.push_back( home_apikey );
    }
  }

  return key_locations;
}


/**
 * @brief Try to get user-supplied api key
 *
 * We will include a simc default api key for people who do not wish to register their own.
 * This will be done at the time of compilation, as we do not want to post our key on git for everyone to see.
 * However, the default setting will always check to see if the user has put their own 32-character key in.
 * If this is true, then the apikey that they enter will overwrite the default.
 * in predetermined locations to see if they have saved the key to a file named 'api_key.txt'. The gui has a entry field setup
 * That will update the apikey variable whenever the user enters a key there.
 */
std::string get_api_key()
{
  if constexpr ( SC_NO_NETWORKING_ON )
  {
    return {};
  }
  auto key_locations = get_api_key_locations();

  for ( const auto& filename : key_locations )
  {
    std::ifstream myfile( filename );
    if ( ! myfile.is_open() )
    {
      continue;
    }

    std::string line;
    std::getline( myfile,line );
    if ( bcp_api::validate_api_key( line ) )
    {
      return line;
    }
    else
    {
      fmt::print( stderr, "Blizzard API credentials from file '{}' were not properly entered. (Size != 65)\n",
                  filename );
    }
  }

#if defined( SC_DEFAULT_APIKEY )
  return std::string(SC_DEFAULT_APIKEY);
#endif /* SC_DEFAULT_APIKEY */
  return {};
}

/// Setup a periodic check for Bloodlust
struct bloodlust_check_t : public event_t
{
  bloodlust_check_t( sim_t& sim, timespan_t time_until_next_check = timespan_t::from_seconds( 1.0 ) )
    : event_t( sim, time_until_next_check )
  {}

  const char* name() const override
  {
    return "Bloodlust Check";
  }

  void execute() override
  {
    sim_t& sim = this->sim();
    player_t* t = sim.target;
    if ( ( sim.bloodlust_percent > 0 && t->health_percentage() < sim.bloodlust_percent ) ||
         ( sim.bloodlust_time < timespan_t::zero() && t->time_to_percent( 0.0 ) < -sim.bloodlust_time ) ||
         ( sim.bloodlust_time >= timespan_t::zero() && sim.current_time() >= sim.bloodlust_time ) )
    {
      if ( !sim.single_actor_batch )
      {
        // use indices since it's possible to spawn new actors when bloodlust is triggered
        for ( size_t i = 0; i < sim.player_non_sleeping_list.size(); i++ )
        {
          auto* p = sim.player_non_sleeping_list[ i ];
          if ( p->is_pet() || p->buffs.exhaustion->check() )
            continue;

          p->buffs.bloodlust->trigger();
          p->buffs.exhaustion->trigger();
        }
      }
      else
      {
        auto p = sim.player_no_pet_list[ sim.current_index ];
        if ( p )
        {
          p->buffs.bloodlust->trigger();
          p->buffs.exhaustion->trigger();
        }
      }
    }
    else
    {
      make_event<bloodlust_check_t>( sim, sim );
    }
  }
};

struct heartbeat_event_t : public event_t
{
  heartbeat_event_t( sim_t& s, timespan_t t ) : event_t( s, t ) {}

  const char* name() const override
  {
    return "heartbeat_event";
  }

  void execute() override
  {
    if ( !sim().heartbeat_event_callback_function.empty() )
    {
      sim().heartbeat_event_callback();
    }

    // TODO: possible that there is actually no variance in the period other than log timestamp artifacts
    make_event<heartbeat_event_t>( sim(), sim(), timespan_t::from_millis( rng().gauss( 5250, 25 ) ) );
  }
};

// compare_dps ==============================================================

struct compare_dps
{
  bool operator()( player_t* l, player_t* r ) const
  {
    double lv = l->collected_data.dps.mean();
    double rv = r->collected_data.dps.mean();
    if ( lv == rv )
    {
      return l->actor_index < r->actor_index;
    }

    return lv > rv;
  }
};

// compare_priority_dps ==============================================================

struct compare_priority_dps
{
  bool operator()( player_t* l, player_t* r ) const
  {
    double lv = l->collected_data.prioritydps.mean();
    double rv = r->collected_data.prioritydps.mean();
    if ( lv == rv )
    {
      return l->actor_index < r->actor_index;
    }

    return lv > rv;
  }
};

// compare_apm ==============================================================

struct compare_apm
{
  bool operator()( player_t* l, player_t* r ) const
  {
    double lv = l->collected_data.fight_length.mean()
      ? 60.0 * l->collected_data.executed_foreground_actions.mean() / l->collected_data.fight_length.mean()
      : 0.0;

    double rv = r->collected_data.fight_length.mean()
      ? 60.0 * r->collected_data.executed_foreground_actions.mean() / r->collected_data.fight_length.mean()
      : 0.0;

    if ( lv == rv )
    {
      return l->actor_index < r->actor_index;
    }

    return lv > rv;
  }
};

// compare_hps ==============================================================

struct compare_hps
{
  bool operator()( player_t* l, player_t* r ) const
  {
    double lv = l->collected_data.hps.mean();
    double rv = r->collected_data.hps.mean();
    if ( lv == rv )
    {
      return l->actor_index < r->actor_index;
    }

    return lv > rv;
  }
};

// compare_hps_plus_aps ====================================================

struct compare_hps_plus_aps
{
  bool operator()( player_t* l, player_t* r ) const
  {
    double lv = l->collected_data.hps.mean() + l->collected_data.aps.mean();
    double rv = r->collected_data.hps.mean() + r->collected_data.aps.mean();
    if ( lv == rv )
    {
      return l->actor_index < r->actor_index;
    }

    return lv > rv;
  }
};

// compare_dtps ==============================================================

struct compare_dtps
{
  bool operator()( player_t* l, player_t* r ) const
  {
    double lv = l->collected_data.dtps.mean();
    double rv = r->collected_data.dtps.mean();
    if ( lv == rv )
    {
      return l->actor_index < r->actor_index;
    }

    return lv > rv;
  }
};

// compare_name =============================================================

struct compare_name
{
  bool operator()( player_t* l, player_t* r ) const
  {
    if ( l -> type != r -> type )
    {
      return l -> type < r -> type;
    }
    if ( l -> specialization() != r -> specialization() )
    {
      return l -> specialization() < r -> specialization();
    }
    return l -> name_str < r -> name_str;
  }
};

} // UNNAMED NAMESPACE ===================================================

// Standard progress method, normal mode sims use the single (first) index, single actor batch
// sims progress with the main thread's current index.
sim_progress_t work_queue_t::progress( int idx )
{
  G l(m);
  size_t current_index = idx;
  if ( idx < 0 )
  {
    current_index = index;
  }

  if ( current_index >= _total_work.size() )
  {
    return sim_progress_t{ _work.back(), _projected_work.back() };
  }

  return sim_progress_t{ _work[ current_index ], _projected_work[ current_index ] };
}

// ==========================================================================
// Simulator
// ==========================================================================

// sim_t::sim_t =============================================================

sim_t::sim_t()
  : event_mgr( this ),
    out_log( *this, &std::cout, sim_ostream_t::no_close() ),
    out_debug( *this, &std::cout, sim_ostream_t::no_close() ),
    debug( false ),
    strict_parsing( false ),
    canceled( false ),
    cleanup_threads( false ),
    initialized( false ),
    fixed_time( true ),
    save_profiles( false ),
    save_profile_with_actions( true ),
    save_full_profile( true ),
    default_actions( false ),
    max_time( 0_ms ),
    expected_iteration_time( 0_ms ),
    vary_combat_length( 0.0 ),
    current_iteration( -1 ),
    iterations( 0 ),
    target_error( 0 ),
    target_error_role( ROLE_DPS ),
    current_error( 0 ),
    current_mean( 0 ),
    analyze_error_interval( 100 ),
    analyze_number( 0 ),
    control( nullptr ),
    parent( nullptr ),
    target( nullptr ),
    heal_target( nullptr ),
    target_list(),
    target_non_sleeping_list(),
    player_list(),
    player_no_pet_list(),
    player_non_sleeping_list(),
    active_player( nullptr ),
    current_index( 0 ),
    num_players( 0 ),
    num_enemies( 0 ),
    num_tanks( 0 ),
    enemy_targets( 0 ),
    healing( 0 ),
    global_spawn_index( 0 ),
    max_player_level( -1 ),
    queue_lag( 5_ms, 0_ms ),
    gcd_lag( 150_ms, 0_ms ),
    channel_lag( 250_ms, 0_ms ),
    queue_gcd_reduction( 100_ms ),
    default_cooldown_tolerance( 250_ms ),
    strict_gcd_queue( false ),
    confidence( 0.95 ),
    confidence_estimator( 0.0 ),
    world_lag( 100_ms, timespan_t::min() ),
    travel_variance( 0 ),
    default_skill( 1.0 ),
    reaction_time( 500_ms ),
    regen_periodicity( 250_ms ),
    ignite_sampling_delta( 200_ms ),
    optimize_expressions( 2 ),
    optimize_expressions_rounds( 1 ),
    current_slot( -1 ),
    optimal_raid( 0 ),
    log( 0 ),
    debug_each( 0 ),
    normalized_stat( STAT_NONE ),
    default_region_str( "us" ),
    save_prefix_str( "save_" ),
    save_talent_str( false ),
    stat_cache( 1 ),
    max_aoe_enemies( 20 ),
    requires_regen_event( false ),
    single_actor_batch( false ),
    allow_experimental_specializations( false ),
    enable_all_talents( false ),
    enable_all_sets( false ),
    enable_all_item_effects( false ),
    progressbar_type( 0 ),
    armory_retries( 3 ),
    enemy_death_pct( 0 ),
    rel_target_level( -1 ),
    target_level( -1 ),
    target_adds( 0 ),
    desired_targets( 1 ),
    desired_tank_targets( 1 ),
    dbc( new dbc_t() ),
    dbc_override( std::make_unique<dbc_override_t>() ),
    timewalk( -1 ),
    scale_to_itemlevel( -1 ),
    dungeon_route_smart_targeting( true ),
    dungeon_route_simple_dps_members( 0 ),
    dungeon_route_pct_hp( 0 ),
    dungeon_route_key_level( 0 ),
    challenge_mode( false ),
    scale_itemlevel_down_only( false ),
    disable_set_bonuses( false ),
    enable_taunts( false ),
    use_item_verification( true ),
    pvp_rules(),
    pvp_mode( false ),
    auto_attacks_always_land( false ),
    log_spell_id( true ),
    active_enemies( 0 ),
    active_allies( 0 ),
    _rng(),
    seed( 0 ),
    deterministic( 0 ),
    strict_work_queue( 0 ),
    average_range( true ),
    average_gauss( false ),
    fight_style(),
    add_waves( 0 ),
    overrides( overrides_t() ),
    default_aura_delay( 30_ms, 5_ms ),
    azerite_status( azerite_control::DISABLED_ALL ),
    progress_bar( *this ),
    scaling( new scale_factor_control_t( this ) ),
    plot( new plot_t( this ) ),
    reforge_plot( new reforge_plot_t( this ) ),
    elapsed_cpu(),
    elapsed_time(),
    work_done( 0 ),
    iteration_dmg( 0 ),
    priority_iteration_dmg( 0 ),
    iteration_heal( 0 ),
    iteration_absorb( 0 ),
    total_dmg(),
    raid_hps(),
    total_heal(),
    total_absorb(),
    raid_aps(),
    raid_dps( "Raid Damage Per Second", false ),
    simulation_length( "Simulation Length", false ),
    merge_time(),
    init_time(),
    analyze_time(),
    report_iteration_data( 0.025 ),
    min_report_iteration_data( -1 ),
    report_strict_iteration_data( false ),
    report_progress( 1 ),
    bloodlust_percent( 0 ),
    bloodlust_time( 0_ms ),
    // Report
    display_build( 1 ),
    report_precision( 2 ),
    report_pets_separately( 0 ),
    report_targets( 1 ),
    report_details( 1 ),
    report_merged_stats( "dps,dpspct" ),
    full_damage_sources_chart( false ),
    report_all_variables( false ),
    collect_action_sequence( true ),
    report_rng( 0 ),
    hosted_html( 0 ),
    offline( 0 ),
    save_raid_summary( 0 ),
    save_gear_comments( 0 ),
    statistics_level( 1 ),
    separate_stats_by_actions( 0 ),
    report_raid_summary( 0 ),
    buff_uptime_timeline( 1 ),
    buff_stack_uptime_timeline( 1 ),
    json_full_states( 0 ),
    decorated_tooltips( -1 ),
    allow_potions( true ),
    allow_food( true ),
    allow_flasks( true ),
    allow_augmentations( true ),
    solo_raid( false ),
    maximize_reporting( false ),
    apikey( get_api_key() ),
    distance_targeting_enabled( false ),
    ignore_invulnerable_targets( false ),
    enable_dps_healing( false ),
    count_overheal_as_heal( false ),
    dhaps_healing_weight( 1.0 ),
    scaling_normalized( 1.0 ),
    merge_enemy_priority_dmg( false ),
    profileset_controller_factory(
        { { "set_bonus_enabled", profileset_controller::create_fn_pair<set_bonus_enabled_t>() } } ),
    profileset_controller(),
    profileset_controller_data(),
    // Multi-Threading
    threads( 0 ),
    thread_index( 0 ),
    process_priority( computer_process::BELOW_NORMAL ),
    work_queue( new work_queue_t() ),
    spell_query(),
    spell_query_level( MAX_LEVEL ),
    spell_query_wrap( 0 ),
    pause_mutex( nullptr ),
    paused( false ),
    chart_show_relative_difference( false ),
    chart_show_relative_difference_percent( true ),
    relative_difference_from_max( false ),
    relative_difference_base(),
    chart_boxplot_percentile( .25 ),
    display_hotfixes( false ),
    disable_hotfixes( false ),
    display_bonus_ids( false ),
    profileset_main_actor_index( 0 ),
    profileset_report_player_index( 0 ),
    profileset_multiactor_base_name( "Baseline" ),
    profileset_metric( { SCALE_METRIC_DPS } ),
    profileset_output_data(),
    profileset_enabled( false ),
    profileset_work_threads( 0 ),
    profileset_init_threads( 1 ),
    profilesets( std::make_unique<profileset::profilesets_t>() ),
    profileset_name()
{
  item_db_sources.assign( std::begin( default_item_db_sources ), std::end( default_item_db_sources ) );

  max_time = 300_s;
  vary_combat_length = 0.2;
  use_optimal_buffs_and_debuffs( 1 );

  create_options();

  profileset::create_options( this );
}

sim_t::sim_t( sim_t* p, int index, std::string_view profileset_name )
  : sim_t()
{
  assert( p );

  this->profileset_name = profileset_name;

  parent = p;
  thread_index = index;

  // Inherit setup
  setup( parent -> control );

  // Inherit 'scaling' settings from parent because these are set outside of the config file
  assert( parent -> scaling );
  scaling -> scale_stat  = parent -> scaling -> scale_stat;
  scaling -> scale_value = parent -> scaling -> scale_value;

  // Inherit reporting directives from parent
  report_progress = parent -> report_progress;

  // Inherit 'plot' settings from parent because are set outside of the config file
  enchant = parent -> enchant;

  // While we inherit the parent seed, it may get overwritten in sim_t::init
  seed = parent -> seed;

  parent -> add_relative( this );
}

sim_t::sim_t( sim_t* p, int index, sim_control_t* control, std::string_view profileset_name )
  : sim_t()
{
  assert( p && control );

  this->profileset_name = profileset_name;

  parent = p;
  thread_index = index;

  // Use specialized control for setup
  setup( control );

  // Inherit 'scaling' settings from parent because these are set outside of the config file
  assert( parent -> scaling );
  scaling -> scale_stat  = parent -> scaling -> scale_stat;
  scaling -> scale_value = parent -> scaling -> scale_value;

  // Inherit reporting directives from parent
  report_progress = parent -> report_progress;

  // Inherit 'plot' settings from parent because are set outside of the config file
  enchant = parent -> enchant;

  // While we inherit the parent seed, it may get overwritten in sim_t::init
  seed = parent -> seed;

  parent -> add_relative( this );
}

// sim_t::~sim_t ============================================================

sim_t::~sim_t()
{
  assert( ( requires_cleanup() && relatives.empty() ) || ! requires_cleanup() );
  if( parent )
    parent -> remove_relative( this );
}

// sim_t::iteration_time_adjust =============================================

double sim_t::iteration_time_adjust()
{
  if ( iterations <= 1 )
    return 1.0;

  if ( current_iteration == 0 )
    return 1.0;

  // Approximate uniform distribution for fight lengths through randomization when target error is
  // used. Will generate more fair fight length distribution when reasonable (<0.5) target_error
  // values are chosen, and removes issues with pathological cases where high values are used (high
  // enough for analyze_error_interval to bound the number of iterations done, instead of the
  // target_error).
  if ( target_error != 0 )
  {
    return rng().range( 1.0 - vary_combat_length, 1.0 + vary_combat_length );
  }
  else
  {
    auto progress = work_queue -> progress();
    return 1.0 + vary_combat_length * ( ( current_iteration % 2 ) ? 1 : -1 ) * progress.pct();
  }
}

// sim_t::expected_max_time =================================================

double sim_t::expected_max_time() const
{
  return max_time.total_seconds() * ( 1.0 + vary_combat_length );
}

// sim_t::add_relative ======================================================

void sim_t::add_relative( sim_t* cousin )
{
  if( parent )
  {
    parent -> add_relative( cousin );
  }
  else
  {
    AUTO_LOCK( relatives_mutex );
    relatives.push_back( cousin );
  }
}

// sim_t::remove_relative ===================================================

void sim_t::remove_relative( sim_t* cousin )
{
  if( parent )
  {
    parent -> remove_relative( cousin );
  }
  else
  {
    AUTO_LOCK( relatives_mutex );
    auto it = range::find( relatives, cousin );
    assert( it != relatives.end() && "Could not find relative to remove" );
    *it = relatives.back();
    relatives.pop_back();
  }
}

/// Cancel simulation.
void sim_t::cancel()
{
  if ( canceled )
    return;

  // check if there're exceptions in queue to display more detailed message
  if ( exception_queue.empty() && ( !parent || parent->exception_queue.empty() ) )
  {
    if ( current_iteration >= 0 )
      error( "Simulation has been canceled after {} iterations! (thread={})", current_iteration + 1, thread_index );
    else
      error( "Simulation has been canceled during player setup! (thread={})", thread_index );
  }

  work_queue->flush();

  canceled = true;

  for ( auto& relative : relatives )
    relative->cancel();

  if ( !parent )
    profilesets->cancel();
}

// sim_t::interrupt =========================================================

void sim_t::interrupt()
{
  work_queue -> flush();

  for (auto & child : children)
  {
    child -> interrupt();
  }
}

// sim_t::is_canceled =======================================================

bool sim_t::is_canceled() const
{
  return canceled;
}

// sim_t::cancel_iteration ==================================================

void sim_t::cancel_iteration()
{
  print_debug( "Iteration canceled." );

  event_mgr.cancel();
}

// sim_t::combat ============================================================

void sim_t::combat()
{
  print_debug( "Starting Simulator" );

  // The sequencing of event manager seed and flush is very tricky.
  // DO NOT MESS WITH THIS UNLESS YOU ARE EXTREMELY CONFIDENT.
  // combat_begin will seed the event manager with "player_ready" events
  // combat_end   will flush any events remaining due to early termination
  // In the future, flushing may occur in event manager execute().

  combat_begin();
  event_mgr.execute();
  combat_end();
}

/// Reset simulation.
void sim_t::reset()
{
  print_debug( "Resetting Simulator" );

  if ( deterministic )
    seed = rng().reseed();

  event_mgr.reset();

  expected_iteration_time = max_time * iteration_time_adjust();

  for ( auto& buff : buff_list )
    buff->reset();

  for ( auto& t : target_list )
  {
    t->reset();
    range::for_each( t->pet_list, []( pet_t* pet ) { pet->reset(); } );
  }

  if ( single_actor_batch )
  {
    player_no_pet_list[ current_index ]->reset();
    // make sure to reset pets after owner, or otherwards they may access uninitialized things from the owner
    for ( auto pet : player_no_pet_list[ current_index ]->pet_list )
    {
      pet->reset();
    }
  }
  else
  {
    for ( auto& player : player_no_pet_list )
    {
      player->reset();
      // Make sure to reset pets after owner, or otherwards they may access uninitialized things from the owner
      for ( auto& pet : player->pet_list )
      {
        pet->reset();
      }
    }
  }

  raid_event_t::reset( this );
}

/// Start combat.
void sim_t::combat_begin()
{
  if ( debug_each )
  {
    // On Debug Each, we collect debug information for each iteration, but clear it before each one
    std::shared_ptr<io::ofstream> o(new io::ofstream());
    o -> open( output_file_str );
    if ( o -> is_open() )
    {
      out_debug = o;
      out_log = o;

      fmt::print( "------ Iteration #{} ------", current_iteration + 1 );
      std::fflush( stdout );
    }
    else
    {
      throw sc_report_output_error( fmt::format( "Unable to open output file '{}'.", output_file_str ) );
    }
  }

  print_debug( "Combat Begin" );

  reset();

  // Debug seed needs to be done _after_ sim reset, because deterministic=1 will reseed in
  // sim_t::reset()
  if ( !debug_seed.empty() )
  {
    enable_debug_seed();
  }

  iteration_dmg = priority_iteration_dmg = iteration_heal = 0;

  // Always call begin() to ensure various counters are initialized.
  datacollection_begin();

  // Initialise all actors before (pre)combat.
  for ( auto& t : target_list )
    t->precombat_init();

  for ( auto& t : target_list )
    t->combat_begin();

  if ( overrides.arcane_intellect )
    auras.arcane_intellect->override_buff();

  if ( overrides.battle_shout )
    auras.battle_shout->override_buff();

  if ( overrides.mark_of_the_wild )
    auras.mark_of_the_wild->override_buff();

  if ( overrides.power_word_fortitude )
    auras.power_word_fortitude->override_buff();

  if ( overrides.skyfury )
    auras.skyfury->override_buff();

  for ( player_e i = PLAYER_NONE; i < PLAYER_MAX; ++i )
  {
    const module_t* m = module_t::get( i );
    if ( m ) m -> combat_begin( this );
  }

  if ( single_actor_batch )
  {
    player_no_pet_list[ current_index ] -> precombat_init();
    player_no_pet_list[ current_index ] -> combat_begin();
    for ( auto pet: player_no_pet_list[ current_index ] -> pet_list )
    {
      // Pets do not need to be initialised individually first
      pet -> precombat_init();
      pet -> combat_begin();
    }
  }
  else
  {
    // Initialize all actors before (pre)combat.
    // Needs to be a index-based loop, as the player list may be extended during iteration.
    for ( size_t i = 0; i < player_list.size(); ++i ) // NOLINT(modernize-loop-convert)
    {
      player_t* p = player_list[ i ];
      p -> precombat_init();
    }

    for ( size_t i = 0; i < player_list.size(); ++i )  // NOLINT(modernize-loop-convert)
    {
      player_t* p = player_list[ i ];
      p -> combat_begin();
    }
  }

  if ( requires_regen_event )
    make_event<regen_event_t>( *this, *this );

  if ( overrides.bloodlust )
  {
    make_event<bloodlust_check_t>( *this, *this, timespan_t::from_seconds( 0.0 ) );
  }

  // Keep droute from creating an end event, it will end itself after the last pull ends
  if ( ( fixed_time || target -> resources.base[ RESOURCE_HEALTH ] == 0 ) && fight_style != FIGHT_STYLE_DUNGEON_ROUTE )
  {
    make_event<sim_end_event_t>( *this, *this, expected_iteration_time );
    target -> death_pct = enemy_death_pct;
  }
  else
  {
    target -> death_pct = enemy_death_pct;
  }
  make_event<sim_safeguard_end_event_t>( *this, *this, expected_iteration_time + expected_iteration_time );

  // Create the 5.25s average heartbeat event used for pet stat updates, and other aura update events.
  if ( !heartbeat_event_callback_function.empty() )
    make_event<heartbeat_event_t>( *this, *this, timespan_t::from_millis( rng().range( 1, 5249 ) ) );

  raid_event_t::combat_begin( this );
}

// sim_t::combat_end ========================================================

void sim_t::combat_end()
{
  print_debug( "Combat End" );

  for ( auto* t : target_list )
  {
     if ( t -> is_add() ) continue;
    t -> combat_end();
  }

  for ( player_e i = PLAYER_NONE; i < PLAYER_MAX; ++i )
  {
    const module_t* m = module_t::get( i );
    if ( m ) m -> combat_end( this );
  }

  raid_event_t::combat_end( this );

  if ( single_actor_batch )
  {
    player_no_pet_list[ current_index ] -> combat_end();
  }
  else
  {
    for ( auto* p : player_no_pet_list )
    {
       p -> combat_end();
    }
  }

  for ( size_t i = 0; i < buff_list.size(); ++i )
  {
    buff_t* b = buff_list[ i ];
    b -> expire();
  }

  if ( iterations == 1 || current_iteration >= 1 )
    datacollection_end();

  //assert( active_enemies == 0 );
  //assert( active_allies == 0 );

  print_debug( "Flush Events" );

  event_mgr.flush();

  analyze_error();

  if ( !debug_seed.empty() )
  {
    disable_debug_seed();
  }
}

// sim_t::datacollection_begin ==============================================

void sim_t::datacollection_begin()
{
  print_debug( "Sim Data Collection Begin" );

  iteration_dmg = priority_iteration_dmg = iteration_heal = iteration_absorb = 0.0;

  for ( auto* t : target_list )
  {
     if ( t -> is_add() ) continue;
    t -> datacollection_begin();
  }

  for ( size_t i = 0; i < buff_list.size(); ++i )
    buff_list[ i ] -> datacollection_begin();

  if ( single_actor_batch )
  {
    player_no_pet_list[ current_index ] -> datacollection_begin();
  }
  else
  {
    for ( auto* p : player_no_pet_list )
    {
       p -> datacollection_begin();
    }
  }
  make_event<resource_timeline_collect_event_t>( *this, *this );
}

// sim_t::datacollection_end ================================================

void sim_t::datacollection_end()
{
  print_debug( "Sim Data Collection End" );

  simulation_length.add( current_time().total_seconds() );

  for ( auto* t : target_list )
  {
     if ( t -> is_add() ) continue;
    t -> datacollection_end();
  }

  if ( single_actor_batch )
  {
    player_no_pet_list[ current_index ] -> datacollection_end();
  }
  else
  {
    for ( auto* p : player_no_pet_list )
    {
       p -> datacollection_end();
    }
  }

  for ( size_t i = 0; i < buff_list.size(); ++i )
  {
    buff_t* b = buff_list[ i ];
    b -> datacollection_end();
  }

  total_dmg.add( iteration_dmg );
  raid_dps.add( current_time() != timespan_t::zero() ? iteration_dmg / current_time().total_seconds() : 0 );
  total_heal.add( iteration_heal );
  raid_hps.add( current_time() != timespan_t::zero() ? iteration_heal / current_time().total_seconds() : 0 );
  total_absorb.add( iteration_absorb );
  raid_aps.add( current_time() != timespan_t::zero() ? iteration_absorb / current_time().total_seconds() : 0 );

  if ( deterministic && report_iteration_data > 0 && ( iterations == 1 || current_iteration > 0 ) &&
       current_time() > timespan_t::zero() )
  {
    // TODO: Metric should be selectable
    iteration_data_entry_t entry( iteration_dmg / current_time().total_seconds(), current_time().total_seconds(), seed,
                                  current_iteration, thread_index, single_actor_batch ? as<int>( current_index ) : -1 );

    for ( auto* t : target_list )
    {
       // Once we start hitting adds (instead of real enemies), break out as those don't have real
      // hitpoints.
      if ( t -> is_add() )
      {
        break;
      }

      entry.add_health( static_cast< uint64_t >( t -> resources.initial[ RESOURCE_HEALTH ] ) );
    }

    if ( std::find_if( iteration_data.begin(), iteration_data.end(),
                       seed_predicate_t( seed ) ) != iteration_data.end() )
    {
      errorf( "[Thread-%d] Duplicate seed %llu found on iteration %u, skipping ...",
          thread_index, seed, current_iteration );
    }
    else
    {
      iteration_data.push_back( entry );
    }
  }
}

// sim_t::analyze_error =====================================================

void sim_t::analyze_error()
{
  if ( thread_index != 0 ) return;
  if ( target_error <= 0 ) return;
  if ( current_iteration < 1 ) return;

  work_queue -> lock();

  // First iterations of each thread are considered statistically insignificant and not
  // collected
  int n_iterations = work_queue -> progress().current_iterations - threads;
  if ( strict_work_queue )
  {
    range::for_each( children, [ &n_iterations ]( sim_t* c ) {
      n_iterations += c -> work_queue -> progress().current_iterations;
    } );
  }

  if ( n_iterations < analyze_error_interval * ( analyze_number + 1 ) )
  {
    work_queue -> unlock();
    return;
  }

  analyze_number++;

  double mean_total=0;
  int mean_count=0;

  current_error = 0;

  bool is_multiactor_metric = false;

  if ( single_actor_batch )
  {
    auto p = player_no_pet_list[ current_index ];
    auto& cd = p -> collected_data;
    AUTO_LOCK( cd.target_metric_mutex );
    if ( cd.target_metric.size() != 0 )
    {
      cd.target_metric.analyze_basics();
      cd.target_metric.analyze_variance();
      current_mean = cd.target_metric.mean();
      if ( current_mean != 0 )
      {
        current_error = sim_t::distribution_mean_error( *this, cd.target_metric ) / current_mean;
      }
    }
  }
  else
  {
    is_multiactor_metric =
        player_no_pet_list.size() > 1 && std::find_if( profileset_metric.begin(), profileset_metric.end(),
                                                       util::scale_metric_is_raid ) != profileset_metric.end();

    for ( size_t i = 0; i < actor_list.size(); i++ )
    {
      player_t* p = actor_list[i];
      player_collected_data_t& cd = p -> collected_data;
      AUTO_LOCK( cd.target_metric_mutex );
      if ( cd.target_metric.size() != 0 )
      {
        cd.target_metric.analyze_basics();
        cd.target_metric.analyze_variance();
        double mean = cd.target_metric.mean();
        if ( mean != 0 )
        {
          if ( is_multiactor_metric )
           {
             double error = sim_t::distribution_mean_error( *this, cd.target_metric );
             current_error += error;
          }
          else
          {
             double error = sim_t::distribution_mean_error( *this, cd.target_metric ) / mean;
             if ( error > current_error )
              current_error = error;
          }
          mean_total += mean;
          mean_count++;
        }
      }
    }
  }

  if ( mean_count > 0 )
  {
    if ( is_multiactor_metric )
    {
      current_error = current_error / current_mean;
      // We're going to lie and call the sum the mean for multiactor metrics.
      current_mean  = mean_total;
    }
    else
    {
      current_mean = mean_total / mean_count;
    }
  }

  current_error *= 100;

  if ( current_error > 0 )
  {
    if ( current_error < target_error )
    {
      interrupt();
    }
    else
    {
      auto projected_iterations = static_cast<int>( n_iterations * ( ( current_error * current_error ) /
          ( target_error *  target_error ) ) );
      if ( ! strict_work_queue )
      {
        work_queue -> project( projected_iterations );
      }
      else
      {
        // Divide work evenly between threads
        projected_iterations /= threads;
        work_queue -> project( projected_iterations );
        range::for_each( children, [ projected_iterations ]( sim_t* c ) {
          c -> work_queue -> project( projected_iterations );
        } );
      }
    }
  }

  work_queue -> unlock();
}

/**
 * @brief check for active player
 *
 * This function just checks that the sim has at least 1 active player, and sets
 * fixed_time automatically if the only role present is a ROLE_HEAL.  Called in sim_t::init_actors()
 */
void sim_t::check_actors()
{
  bool too_quiet = true; // Check for at least 1 active player
  bool zero_dds = true; // Check for at least 1 player != HEAL

  for ( const auto& p : actor_list )
  {
    if ( p -> is_pet() || p -> is_enemy() )
      continue;
    if ( p -> type == HEALING_ENEMY )
      continue;
    if ( ! p -> quiet )
    {
      too_quiet = false;
    }
    if ( p -> primary_role() != ROLE_HEAL && ! p -> is_pet() )
    {
      zero_dds = false;
    }
  }

  if ( too_quiet && !debug )
  {
    throw sc_initialization_error( "No active players in sim!" );
  }

  // Set Fixed_Time when there are no DD's present
  if ( zero_dds && ! debug )
  {
    fixed_time = true;
  }
}

/**
 * @brief configure fight style
 *
 * Parses fight style information into specific simulator defines. Performed as a separate
 * initialization step (early) in the simulator init process to avoid positional dependencies
 * between options (first and foremost, the max_time option).
 *
 * Note that there are side-effects of this, namely that where fight styles define other options
 * (e.g., Ultraxion), those can no longer be overwritten on the command line.
 */
void sim_t::init_fight_style()
{
  bool deprecated = false;

  switch ( fight_style )
  {
    case FIGHT_STYLE_PATCHWERK:
      raid_events_str.clear();
      break;

    case FIGHT_STYLE_CASTING_PATCHWERK:
      raid_events_str += "/casting,cooldown=500,duration=500";
      break;

    case FIGHT_STYLE_HECTIC_ADD_CLEAVE:
    {
      // Phase 1 - Adds and move into position to fight adds
      auto first_and_duration = std::max( static_cast<unsigned>( max_time.total_seconds() * 0.05 ), 1U );
      auto cooldown = std::max( static_cast<unsigned>( max_time.total_seconds() * 0.075 ), 1U );
      auto last = static_cast<unsigned>( max_time.total_seconds() * 0.75 );

      raid_events_str += fmt::format( "/adds,count=5,first={},cooldown={},duration={},last={}",
                                      first_and_duration, cooldown, first_and_duration, last );

      raid_events_str += fmt::format( "/movement,distance=25,first={},cooldown={},last={}",
                                      first_and_duration, cooldown, last );

      // Phase2 - Move out of stuff
      auto first2 = static_cast<unsigned>( max_time.total_seconds() * 0.03 );
      auto cooldown2 = std::max( static_cast<unsigned>( max_time.total_seconds() * 0.04 ), 1U );

      raid_events_str += fmt::format( "/movement,players_only=1,distance=8,first={},cooldown={}",
                                      first2, cooldown2 );
    }
    break;

    case FIGHT_STYLE_DUNGEON_SLICE:
      desired_targets = 1;
      max_time = timespan_t::from_seconds( 360.0 );

      ignore_invulnerable_targets = true;

      raid_events_str +=
        "/adds,name=Boss,count=1,cooldown=500,duration=135,type=add_boss,duration_stddev=1"
        "/adds,name=SmallAdd,count=5,count_range=1,first=140,cooldown=45,duration=18,duration_stddev=2"
        "/adds,name=BigAdd,count=2,count_range=1,first=160,cooldown=50,duration=30,duration_stddev=2";
      break;

    case FIGHT_STYLE_DUNGEON_ROUTE:
      // To be used in conjunction with "pull" raid events for a simulated dungeon run.
      desired_targets = 1;
      fixed_time = false;
      // Bloodlust is handled by an option on each pull raid event.
      overrides.bloodlust = 0;
      // Only use for this should be setting the safeguard event (max_time * 2). As long as Blizzard remains sane and tunes around a typical dungeon
      // taking about 30 minutes to complete, a safeguard of 1.5 hours should be a safe point to assume something has gone wrong in the sim, either the 
      // input needs to be checked or something got stuck.
      max_time = 45_min;
      break;

    case FIGHT_STYLE_CLEAVE_ADD:
    {
      auto first_and_duration = static_cast<unsigned>( max_time.total_seconds() * 0.05 );
      auto cooldown = static_cast<unsigned>( max_time.total_seconds() * 0.075 );
      auto last = static_cast<unsigned>( max_time.total_seconds() * 0.90 );

      raid_events_str += fmt::format( "/adds,count=1,first={},cooldown={},duration={},last={}",
                                      first_and_duration, cooldown, first_and_duration, last );
    }
    break;

    case FIGHT_STYLE_LIGHT_MOVEMENT:
      raid_events_str += "/movement,players_only=1,cooldown=40,cooldown_stddev=10,distance=15,move_distance_min=10,move_distance_max=20,first=15";
      break;

    case FIGHT_STYLE_HEAVY_MOVEMENT:
      raid_events_str += "/movement,players_only=1,cooldown=20,cooldown_stddev=15,distance=25,move_distance_min=20,move_distance_max=30,first=15";
      raid_events_str += "/movement,players_only=1,cooldown=45,cooldown_stddev=15,distance=45,move_distance_min=40,move_distance_max=50,first=30";
      break;

    case FIGHT_STYLE_BEASTLORD:
    {
      deprecated = true;
      raid_events_str += "/adds,name=Pack_Beast,count=6,"
        "first=15,duration=10,cooldown=30,angle_start=0,angle_end=360,distance=3";
      raid_events_str += "/adds,name=Heavy_Spear,count=2,"
        "first=15,duration=15,cooldown=20,spawn_x=-15,spawn_y=0,distance=15";
      raid_events_str += "/movement,first=13,distance=5,cooldown=20,players_only=1,player_chance=0.1";

      auto beast_duration = static_cast<int>( max_time.total_seconds() * 0.15 );
      auto beast_cooldown = static_cast<int>( max_time.total_seconds() * 0.25 );
      // Ensure min cooldown (cd - 6*stddev) is larger than duration
      auto beast_cooldown_stddev = std::max(
        static_cast<int>( ( beast_duration - beast_cooldown ) / 6.0 ) - 1, 0 );
      auto beast_last = static_cast<unsigned>( max_time.total_seconds() * 0.65 );

      raid_events_str += fmt::format( "/adds,name=Beast,count=1,first=10,duration_stddev=5,"
                                      "duration={},cooldown={},cooldown_stddev={},last={}",
                                      beast_duration, beast_cooldown, beast_cooldown_stddev,
                                      beast_last );
    }
    break;

    case FIGHT_STYLE_HELTER_SKELTER:
      deprecated = true;
      raid_events_str += "/casting,cooldown=30,duration=3,first=15";
      raid_events_str += "/movement,cooldown=30,distance=20";
      raid_events_str += "/stun,cooldown=60,duration=2";
      raid_events_str += "/invulnerable,cooldown=120,duration=3";
      break;

    case FIGHT_STYLE_ULTRAXION:
      deprecated = true;
      max_time = timespan_t::from_seconds( 366.0 );
      fixed_time = true;
      vary_combat_length = 0.0;
      raid_events_str += "/flying,first=0,duration=500,cooldown=500";
      raid_events_str += "/position_switch,first=0,duration=500,cooldown=500";
      raid_events_str += "/stun,duration=1.0,first=45.0,cooldown=45.0";
      raid_events_str += "/stun,duration=1.0,first=57.0,cooldown=57.0";
      raid_events_str += "/damage,first=6.0,cooldown=6.0,last=59.5,amount=44000,type=shadow";
      raid_events_str += "/damage,first=60.0,cooldown=5.0,last=119.5,amount=44855,type=shadow";
      raid_events_str += "/damage,first=120.0,cooldown=4.0,last=179.5,amount=44855,type=shadow";
      raid_events_str += "/damage,first=180.0,cooldown=3.0,last=239.5,amount=44855,type=shadow";
      raid_events_str += "/damage,first=240.0,cooldown=2.0,last=299.5,amount=44855,type=shadow";
      raid_events_str += "/damage,first=300.0,cooldown=1.0,amount=44855,type=shadow";
      break;

    default:
      fight_style = FIGHT_STYLE_PATCHWERK;
      break;
  }

  if ( deprecated )
  {
    error( "Fight style {} is currently unsupported, use with caution!", fight_style );
  }
}

/**
 * @brief configure parties
 *
 * This function... builds parties? I guess it assigns each player in player_list to
 * a party based on party_encoding. Called in sim_t::init_actors()
 */
void sim_t::init_parties()
{
  if ( debug )
    print_debug( "Building Parties." );

  int party_index = 0;
  for ( const auto& party_str : party_encoding )
  {
    if (util::str_compare_ci(party_str, "reset"))
    {
      party_index = 0;
      for ( auto& player : player_list )
      {
        player -> party = 0;
      }
    }
    else if (util::str_compare_ci(party_str, "all"))
    {
      for ( auto& player : player_list )
      {
        player -> party = 1;
      }
    }
    else
    {
      party_index++;

      auto player_names = util::string_split<util::string_view>( party_str, ",;/" );

      for ( const auto& player_name : player_names )
      {
        player_t* p = find_player( player_name );
        if ( !p )
        {
          throw sc_invalid_sim_argument( fmt::format( "Player '{}' not found for party creation.", player_name ) );
        }
        p -> party = party_index;
        for ( auto& pet : p -> pet_list )
        {
          pet -> party = party_index;
        }
      }
    }
  }
}

/// Initialize actors
void sim_t::init_actors()
{
  // sort initializers by priority
  std::stable_sort( actor_initializer.begin(), actor_initializer.end(), []( const auto& a, const auto& b ) {
    auto a_prio = std::get<int>( a );
    auto b_prio = std::get<int>( b );
    assert( a_prio != b_prio || std::get<std::string>( a ) != std::get<std::string>( b ) );
    return a_prio == b_prio ? std::get<std::string>( a ) < std::get<std::string>( b ) : a_prio < b_prio;
  } );

  print_debug( "Initializing actors." );

  for ( size_t i = 0; i < player_no_pet_list.size(); ++i )
  {
    player_no_pet_list[ i ]->create_permanent_actors();
  }

  for ( size_t i = 0; i < target_list.size(); ++i )
  {
    target_list[ i ]->create_permanent_actors();
  }

  for ( size_t i = 0; i < target_list.size(); ++i )
  {
    init_actor( target_list[ i ] );
  }

  print_debug( "Initializing Players." );

  if ( decorated_tooltips == -1 )
    decorated_tooltips = 1;

  auto name_number = 1;
  for ( size_t j = 0; j < player_no_pet_list.size(); ++j )
  {
    for ( size_t i = 0; i < player_no_pet_list.size(); ++i )
    {
      if ( i == j )
        continue;
      if ( player_no_pet_list[j] -> name_str == player_no_pet_list[i] -> name_str )
      {
        errorf( "%s has duplicate name, renaming to %s%s. Please use unique names for all players in simulation.",
                player_no_pet_list[j] -> name_str.c_str(),
                player_no_pet_list[j] -> name_str.c_str(),
                std::to_string( name_number ).c_str() );

        player_no_pet_list[j] -> name_str += std::to_string( name_number );
        name_number++;
      }
    }
  }

  for ( size_t i = 0; i < player_no_pet_list.size(); ++i )
  {
    init_actor( player_no_pet_list[ i ] );
  }

  // create actor entries for pets
  init_actor_pets();

  // check that we have at least one active player
  check_actors();

  // organize parties if necessary
  init_parties();
}

// sim_t::init_actor ========================================================

void sim_t::init_actor( player_t* p )
{
  try
  {
    // Initialize class/enemy modules
    for ( player_e i = PLAYER_NONE; i < PLAYER_MAX; ++i )
      if ( auto m = module_t::get( i ) )
       m->init( p );

    // Clear APL for default actions
    if ( default_actions && !p->is_pet() )
    {
      p->clear_action_priority_lists();
      p->action_list_str.clear();
    }

    // Use index loop to allow initializers to add more initializers
    for ( size_t i = 0; i < actor_initializer.size(); ++i )
    {
      std::get<1>( actor_initializer[ i ] )( p );
    }
  }
  catch ( const std::exception& )
  {
    std::throw_with_nested( std::runtime_error( fmt::format( "{}", *p ) ) );
  }
}

// sim_t::init_actor_pets ===================================================

void sim_t::init_actor_pets()
{
  if ( debug )
    out_debug.printf( "Creating and initializing pets." );

  for ( size_t i = 0, end = target_list.size(); i < end; ++i )
  {
    player_t* p = target_list[ i ];

    for (auto & elem : p -> pet_list)
    {
      init_actor( elem );
    }
  }

  for ( size_t i = 0, end = player_no_pet_list.size(); i < end; ++i )
  {
    player_t* p = player_no_pet_list[ i ];

    for (auto & elem : p -> pet_list)
    {
      init_actor( elem );
    }
  }
}

// sim_t::init ==============================================================

void sim_t::init()
{
  const auto start_time = chrono::wall_clock::now();

  if ( initialized )
    return;

  event_mgr.init();

  unique_gear::register_target_data_initializers( this );
  register_actor_initializers();

  // Seed RNG
  if ( seed == 0 )
  {
    if( deterministic )
    {
      seed = 31459;
    }
    else
    {
      std::random_device rd;
      seed  = uint64_t(rd()) | (uint64_t(rd()) << 32);
    }
  }
  _rng.seed( seed + thread_index );

  if (   queue_lag.stddev == 0_ms )   queue_lag.stddev =   queue_lag.mean * 0.25;
  if (     gcd_lag.stddev == 0_ms )     gcd_lag.stddev =     gcd_lag.mean * 0.25;
  if ( channel_lag.stddev == 0_ms ) channel_lag.stddev = channel_lag.mean * 0.25;
  if (   world_lag.stddev  < 0_ms )   world_lag.stddev =   world_lag.mean * 0.1;

  confidence_estimator = rng::stdnormal_inv( 1.0 - ( 1.0 - confidence ) / 2.0 );

  if ( challenge_mode && scale_to_itemlevel < 0 )
  {
    scale_to_itemlevel = 630;
    scale_itemlevel_down_only = true;
  }
  else if ( timewalk > 0 )
  {
    if ( scale_to_itemlevel == -1 )
    {
      switch ( timewalk )
      {
        case 45: scale_to_itemlevel = 50; break;
        case 40: scale_to_itemlevel = 45; break;
        case 35: scale_to_itemlevel = 40; break;
        case 30: scale_to_itemlevel = 35; break;
      }
    }
    scale_itemlevel_down_only = true;
  }

  if ( pvp_mode )
    pvp_rules = dbc::find_spell( this, 134735 );

  // set scaling metric
  if ( !scaling->scale_over.empty() )
  {
    scaling->scaling_metric = util::parse_scale_metric( scaling->scale_over );
    if ( scaling->scaling_metric == SCALE_METRIC_NONE )
    {
      throw sc_invalid_sim_argument( fmt::format( "Unknown scaling metric '{}'", scaling->scale_over ) );
    }
  }

  struct fallback_buff_t : public buff_t
  {
    fallback_buff_t( sim_t* sim ) : buff_t( sim, "fallback" )
    {
      is_fallback = true;
      manual_chance = 0.0;
      default_chance = 0.0;
    }
    bool trigger( int, double, double, timespan_t ) override { return false; }
    void execute( int, double, timespan_t ) override { return; }
    void increment( int, double, timespan_t ) override { return; }
    void decrement( int, double ) override { return; }
    void start( int, double, timespan_t ) override { return; }
    void refresh( int, double, timespan_t ) override { return; }
    void bump( int, double ) override { return; }
    void reset() override { return; }
    void invalidate_cache() override { return; }
    double check_value() const override { return 0; }
  };

  auras.fallback = make_buff<fallback_buff_t>( this );

  auras.arcane_intellect = make_buff( this, "arcane_intellect", dbc::find_spell( this, 1459 ) )
                               ->set_default_value_from_effect( 1 )
                               ->add_invalidate( CACHE_INTELLECT );

  auras.battle_shout = make_buff( this, "battle_shout", dbc::find_spell( this, 6673 ) )
                           ->set_default_value_from_effect( 1 )
                           ->add_invalidate( CACHE_ATTACK_POWER );

  auras.mark_of_the_wild = make_buff( this, "mark_of_the_wild", dbc::find_spell( this, 1126 ) )
                               ->set_default_value_from_effect_type( A_MOD_VERSATILITY_PCT );

  auras.power_word_fortitude = make_buff( this, "power_word_fortitude", dbc::find_spell( this, 21562 ) )
                                   ->set_default_value_from_effect( 1 )
                                   ->add_invalidate( CACHE_STAMINA );

  auras.skyfury = make_buff( this, "skyfury", dbc::find_spell( this, 462854 ) )
                      ->set_default_value_from_effect( 1 )
                      ->add_invalidate( CACHE_MASTERY );

  // Fight style initialization must be performed before target creation and raid event initialization, since fight
  // styles may define/override these things.
  init_fight_style();

  // Find Already defined target, otherwise create a new one.
  print_debug( "Creating Enemies." );

  if ( fight_style == FIGHT_STYLE_DUNGEON_SLICE || fight_style == FIGHT_STYLE_DUNGEON_ROUTE )
  {
    if ( main_target_str.empty() && target_list.empty() )
    {
      target = module_t::enemy()->create_player( this, "Dungeon" );
      target->initial.sleeping = target->base.sleeping = target->current.sleeping = true;
    }
    else
    {
      if ( !target_list.empty() )
      {
        target = target_list.data().front();
        if ( fight_style == FIGHT_STYLE_DUNGEON_ROUTE )
          target->quiet = true;
      }

      range::for_each( target_list, []( player_t* t ) {
        t->initial.sleeping = t->base.sleeping = t->current.sleeping = true;
      } );
    }
  }
  else if ( !target_list.empty() )
  {
    target = target_list.data().front();
  }
  else if ( !main_target_str.empty() )
  {
    player_t* p = find_player( main_target_str );
    if ( p )
      target = p;
  }
  else
  {
    // Default enemy used if no explicity enemy declarations are found.
    // Only the first enemy uses the tank_dummy_enemy module, to prevent approximately
    // linear scaling of damage intake from using the `desired_targets` sim opt
    target = module_t::tank_dummy_enemy()->create_player( this, "Fluffy_Pillow" );
  }

  // create additional non-tank enemies here
  int count_additional_enemy = 1;
  while ( as<int>( target_list.size() ) < desired_targets )
  {
    active_player = nullptr;
    active_player =
      module_t::enemy()->create_player( this, "Dummy_Enemy_" + util::to_string( count_additional_enemy ) );
    count_additional_enemy++;
    if ( !active_player )
    {
      throw sc_initialization_error( fmt::format( "Unable to create dps enemy {}.", target_list.size() ) );
    }
  }

  // create additional tank enemies here
  int desired_target_count = as<int>( target_list.size() ) + desired_tank_targets - 1;
  count_additional_enemy = 1;
  while ( as<int>( target_list.size() ) < desired_target_count )
  {
    active_player = nullptr;
    active_player = module_t::tank_dummy_enemy()->create_player(
      this, "Tank_Dummy_Enemy_" + util::to_string( count_additional_enemy ) );
    count_additional_enemy++;
    if ( !active_player )
    {
      throw sc_initialization_error( fmt::format( "Unable to create tank enemy {}.", target_list.size() ) );
    }
  }

  if ( max_player_level < 0 )
  {
    for ( const auto* p : player_no_pet_list )
    {
       if ( max_player_level < p -> level() )
        max_player_level = p -> level();
    }
  }

  {
    // Determine whether we have healers.
    unsigned int healers = 0;
    unsigned int dps     = 0;
    unsigned int tanks   = 0;
    for ( const auto* p : player_no_pet_list )
    {
      if ( p->primary_role() == ROLE_HEAL )
        ++healers;
      else if ( p->primary_role() == ROLE_TANK )
        ++tanks;
      else if ( p->primary_role() != ROLE_HYBRID )
        ++dps;
    }

    bool dungeon_based_sim = ( fight_style == FIGHT_STYLE_DUNGEON_SLICE || fight_style == FIGHT_STYLE_DUNGEON_ROUTE );
    unsigned int players_for_content = dungeon_based_sim ? 5 : 20;

    int healing_targets_to_create = healing > 0          ? healing
                                    : single_actor_batch ? players_for_content - 1
                                                         : players_for_content - ( healers + dps + tanks );

    if ( healers > 0 || healing > 0 )
    {
      while ( healing_targets_to_create > 0 )
      {
        heal_target = module_t::heal_enemy()->create_player(
            this, "Healing_Target_" + util::to_string( healing_targets_to_create ), RACE_NONE );
        healing_targets_to_create--;
      }
    }
  }

  raid_event_t::init( this );

  // Initialize actors
  init_actors();

  if ( report_precision < 0 ) report_precision = 2;

  raid_dps.reserve( std::min( iterations, 10000 ) );
  simulation_length.reserve( std::min( iterations, 10000 ) );

  for ( const auto& player : player_list )
  {
    if ( player ->resource_regeneration ==  regen_type::STATIC )
    {
      requires_regen_event = true;
      break;
    }
  }

  // We are committed to simulating something. Tell actors that the sim init is now complete if they
  // need to do something.
  if ( !canceled )
  {
    bool verify_use_items_state = true;

    for ( auto& actor : actor_list )
    {
      try
      {
        actor->init_finished();
      }
      catch ( const std::exception& )
      {
        std::throw_with_nested( std::runtime_error( fmt::format( "Actor '{}'", actor->name() ) ) );
      }
      // Some verification stuff to avoid user mistakes

      // .. nag if the user has not added an use_item line for each on-use item
      if ( !actor->verify_use_items() )
      {
        verify_use_items_state = false;
      }
    }

    if ( !verify_use_items_state )
    {
      error(
        "Disable this warning by adding 'use_item' actions into the action priority list for the actor(s), or set "
        "'use_item_verification=0' in your SimulationCraft input." );
    }
  }

  // If save= option is used, don't bother initializing profilesets or plots as the main thread is going to
  // exit in any case
  if ( active_player && active_player->report_information.save_str.empty() )
  {
    profilesets->initialize( this );
    plot->initialize();
  }

  init_mutex.lock();

  if ( !parent && !profileset_controller_options.empty() && !profileset_map.empty() )
  {
    for ( const auto& [ key, values ] : profileset_controller_options )
    {
      if ( profileset_controller_t::controller_exists( this, key ) )
        for ( const auto& value : values )
          profileset_controller_data.emplace_back( key, value );
      else
        throw sc_invalid_sim_argument( fmt::format( "Unknown profileset controller option with name '{}'.", key ) );
    }
  }
  if ( parent && profileset_enabled )
    for ( auto& profileset_controller_datum : parent->profileset_controller_data )
      profileset_controller_datum.construct_controller( this );

  initialized = true;
  init_mutex.unlock();

  init_time = chrono::elapsed(start_time);

  if ( canceled && !rethrow_exception_queue() )
  {
    throw std::runtime_error( fmt::format( "Canceled ({})", thread_index ) );
  }
}

// sim_t::register_actor_initializers() =====================================

void sim_t::register_actor_initializers()
{
  // add default initializers
  print_debug( "Registering actor initializers." );

  register_actor_initializer( INIT_ACTOR_INIT, &player_t::init, "init" );
  register_actor_initializer( INIT_ACTOR_INIT + 10, []( player_t* p ) { p->initialized = true; } );

  // Initialize player properties
  register_actor_initializer( INIT_ACTOR_PROPERTIES + 5, &player_t::init_race, "race" );
  register_actor_initializer( INIT_ACTOR_PROPERTIES + 10, &player_t::init_position, "position" );
  register_actor_initializer( INIT_ACTOR_PROPERTIES + 15, &player_t::init_target, "target" );
  register_actor_initializer( INIT_ACTOR_PROPERTIES + 20, &player_t::init_professions, "professions" );

  // Initialize talents before items, as some item options like temporary enchant can utilize expressions
  register_actor_initializer( INIT_ACTOR_TALENTS, &player_t::init_talents, "talents" );

  // Initialize each actor's items, construct gear information & stats
  register_actor_initializer( INIT_ACTOR_ITEMS, &player_t::init_items, "items" );
  register_actor_initializer( INIT_ACTOR_ITEMS + 10, &player_t::init_azerite, "azerite" );

  // Main spell looksup. Populate class/spec/hero talents & spells.
  register_actor_initializer( INIT_ACTOR_SPELLS, &player_t::init_spells, "spells" );
  // Apply spec spell overrides to the DBC, must be done before spell lookups
  register_actor_initializer( INIT_ACTOR_SPELLS - 10, &player_t::replace_spells, "replace_spells" );

  // First-phase creation of special effects from various sources. Needed to be able to create actions (APLs, really)
  // based on the presence of special effects on items. Certain effects, such as effects that modify base stats, may be
  // flagged to have their custom initialization run on creation.
  register_actor_initializer( INIT_ACTOR_CREATE_EFFECTS, &player_t::create_special_effects, "create_effects" );

  // Initialize stats from DBC. Base stats can be modified until init_initial_stats()
  register_actor_initializer( INIT_ACTOR_BASE_STATS, &player_t::init_base_stats, "base_stats" );

  // Buffs are created before actions, as typically action constructors tends to be more customized than buff
  // constructors. This allow actions to reference buff validity during instantiation, but the vice versa is not
  // possible.
  register_actor_initializer( INIT_ACTOR_CREATE_BUFFS, &player_t::create_buffs, "create_buffs" );

  // Validate the actor and create all the action objects and set up action lists properly. If actor is not valid, set
  // quiet and skip action creation.
  register_actor_initializer( INIT_ACTOR_CREATE_ACTIONS, []( player_t* p ) {
    if ( p->validate_actor() )
      p->create_actions();
#ifdef NDEBUG
    else
      p->quiet = true;
#endif
  }, "create_actions" );
  // Background actions must be created before actions as some actions can reference them in their constructors
  register_actor_initializer( INIT_ACTOR_CREATE_ACTIONS - 10, &player_t::init_background_actions );

  // Create all actor pets before special effects get initialized. This ensures that we can use stuff like the presence
  // of an action (created with create_actions()) to determine if a pet needs to be created or not. Similarly, talent,
  // spec, and item based qualifiers would work.
  register_actor_initializer( INIT_ACTOR_PETS, &player_t::create_pets, "pets" );
  // Create persistent actors from dynamic spawners
  register_actor_initializer( INIT_ACTOR_PETS + 10, []( player_t* p ) { spawner::create_persistent_actors( *p ); } );

  // Second-phase initialize all special effects and register them to actors
  register_actor_initializer( INIT_ACTOR_INIT_EFFECTS, &player_t::init_special_effects, "init_effects" );

  // Finally, initialize all action objects
  register_actor_initializer( INIT_ACTOR_INIT_ACTIONS, &player_t::init_actions, "init_actions" );

  // Once all transient properties are initialized (e.g., base stats, spells, special effects, items), initialize the
  // initial stats of the actor. Do not modify base stats after this call.
  register_actor_initializer( INIT_ACTOR_INITIAL_STATS, &player_t::init_initial_stats, "initial_stats" );
  // And once initial stats are initialized, derive the passive defensive properties of the actor
  register_actor_initializer( INIT_ACTOR_INITIAL_STATS + 10, &player_t::init_defense, "defense" );

  register_actor_initializer( INIT_ACTOR_MISC + 5, &player_t::init_scaling, "scaling" );
  register_actor_initializer( INIT_ACTOR_MISC + 10, &player_t::init_gains, "gains" );
  register_actor_initializer( INIT_ACTOR_MISC + 15, &player_t::init_procs, "procs" );
  register_actor_initializer( INIT_ACTOR_MISC + 20, &player_t::init_uptimes, "uptimes" );
  register_actor_initializer( INIT_ACTOR_MISC + 25, &player_t::init_benefits, "benefits" );
  register_actor_initializer( INIT_ACTOR_MISC + 30, &player_t::init_rng, "rng" );
  register_actor_initializer( INIT_ACTOR_MISC + 35, &player_t::init_stat_data, "stat_data" );
  register_actor_initializer( INIT_ACTOR_MISC + 40, &player_t::init_distance_targeting, "distance_targeting" );
  register_actor_initializer( INIT_ACTOR_MISC + 45, &player_t::init_absorb_priority, "absorb_priority" );

  register_actor_initializer( INIT_ACTOR_ASSESSORS, &player_t::init_assessors, "assessors" );

  // Register initializers from class modules
  for ( player_e i = PLAYER_NONE; i < PLAYER_MAX; ++i )
    if ( auto m = module_t::get( i ) )
      m->register_actor_initializers( this );

  // Register initializers from xpac gear
  unique_gear::register_actor_initializers( *this );
}

// sim_t::analyze ===========================================================

void sim_t::analyze()
{
  const auto start_time = chrono::wall_clock::now();

  simulation_length.analyze();
  if ( simulation_length.mean() == 0 ) return;

  raid_dps.analyze();

  for ( size_t i = 0; i < buff_list.size(); ++i )
    buff_list[ i ]->analyze();

  if ( scaling->scale_stat == STAT_NONE && scaling->calculate_scale_factors == 0 && plot->dps_plot_stats.empty() &&
       reforge_plot->reforge_plot_stat_str.empty() && profileset_map.empty() && !profileset_enabled )
  {
    fmt::print( "Analyzing actor data ...\n" );
    std::fflush( stdout );
  }

  assert( iterations > 0 );

  // Run core analyze for all actor collected data before proceeding to full analysis. This is to prevent errors from
  // when actors access information from each other, e.g. buffs.
  for ( size_t i = 0; i < actor_list.size(); i++ )
  {
    actor_list[ i ] -> pre_analyze_hook();
    actor_list[ i ] -> collected_data.analyze( *actor_list[ i ] );
  }

  for ( size_t i = 0; i < actor_list.size(); i++ )
    actor_list[ i ] -> analyze( *this );

  raid_event_t::analyze( this );

  range::sort( players_by_dps,  compare_dps() );
  range::sort( players_by_priority_dps, compare_priority_dps() );
  range::sort( players_by_hps,  compare_hps() );
  range::sort( players_by_hps_plus_aps, compare_hps_plus_aps() );
  range::sort( players_by_dtps, compare_dtps() );
  range::sort( players_by_name, compare_name() );
  range::sort( players_by_apm, compare_apm() );
  range::sort( targets_by_name, compare_name() );

  analyze_iteration_data();

  analyze_time = chrono::elapsed(start_time);
}

/**
 * Build a N-highest/lowest iteration table for deterministic so they can be
 * replayed
 */
void sim_t::analyze_iteration_data()
{
  // Only enabled for deterministic simulations for now
  if ( !deterministic || ( report_iteration_data == 0 && !report_strict_iteration_data ) )
  {
    return;
  }

  if ( report_strict_iteration_data )
  {
    if ( single_actor_batch )
    {
      range::sort( iteration_data, []( const auto& a, const auto& b ) {
        return a.actor_index == b.actor_index
                 ? a.thread_index == b.thread_index ? a.iteration < b.iteration : a.thread_index < b.thread_index
                 : a.actor_index < b.actor_index;
      } );
    }
    else
    {
      range::sort( iteration_data, []( const auto& a, const auto& b ) {
        return a.thread_index == b.thread_index ? a.iteration < b.iteration : a.thread_index < b.thread_index;
      } );
    }

    return;
  }

  range::sort( iteration_data, iteration_data_cmp_r );

  size_t min_entries = ( min_report_iteration_data == -1 ) ? 5 : static_cast<size_t>( min_report_iteration_data );
  double n_pct = report_iteration_data / ( report_iteration_data > 1 ? 100.0 : 1.0 );
  size_t n_entries = std::max( min_entries, static_cast<size_t>( std::ceil( iteration_data.size() * n_pct ) ) );

  // If low + high entries is more than we have data for, we will just print
  // all data out
  if ( n_entries * 2 > iteration_data.size() )
  {
    return;
  }

  std::copy( iteration_data.begin(), iteration_data.begin() + n_entries, std::back_inserter( low_iteration_data ) );
  range::sort( low_iteration_data, iteration_data_cmp_r );
  std::copy( iteration_data.end() - n_entries, iteration_data.end(), std::back_inserter( high_iteration_data ) );
  range::sort( high_iteration_data, iteration_data_cmp );
}

// sim_t::iterate ===========================================================

bool sim_t::iterate()
{
  try
  {
    init();
  }
  catch ( const std::exception& )
  {
    if ( !parent )
      std::throw_with_nested( sc_initialization_error( "Initialization error" ) );

    return false;
  }

  progress_bar.init();

  profileset_controller_t::evaluate( this, POST_INIT );

  try
  {
    activate_actors();

    bool more_work = true;
    do
    {
      ++current_iteration;
      ++work_done;

      combat();

      if ( progress_bar.update( false, as<int>( current_index ) ) )
      {
        progress_bar.output( false );
      }

      profileset_controller_t::evaluate( this, POST_ITER );

      do_pause();
      auto old_active = current_index;
      if ( !canceled )
      {
        current_index = work_queue->pop();
        more_work = work_queue->more_work();

        if ( more_work && current_index != old_active )
        {
          if ( !parent || scaling->scale_stat != STAT_NONE ||
               ( parent && parent->reforge_plot->current_stat_combo > -1 ) )
          {
            progress_bar.update( true, static_cast<int>( old_active ) );
            progress_bar.output( true );
            progress_bar.restart();
          }

          activate_actors();
        }
      }
    } while ( more_work && !canceled );
  }
  catch ( const std::exception& )
  {
    std::throw_with_nested( sc_runtime_error( fmt::format( "Iteration ({})", current_iteration ) ) );
  }

  if ( !canceled && progress_bar.update( true, as<int>( current_index ) ) )
  {
    progress_bar.output( true );
  }

  // Deactivate the final actor after simulation is done in single_actor_batch
  if ( single_actor_batch )
  {
    player_no_pet_list[ player_no_pet_list.size() - 1 ]->deactivate();
  }
  else
  {
    progress_bar.restart();
  }

  reset();

  iterations = current_iteration + 1;

  return iterations > 0;
}

/**
 * @brief pause simulator
 *
 * Sit in an external pause mutex (lock) of the first simulator thread until
 * it's our turn to lock/unlock it. In theory can have racing issues, but in
 * practice all iterations do enough work for it not to matter.
 *
 * Lock/unlock is done per iteration, so processing cost should be minimal.
 */
void sim_t::do_pause()
{
  if ( parent )
  {
    parent -> do_pause();
  }
  else
  {
    if ( pause_mutex && paused )
    {
      pause_mutex -> lock();
      pause_mutex -> unlock();
    }
  }
}

void sim_t::set_error( error_level_e level, std::string error )
{
  util::replace_all( error, "\n", "" );

  auto [ it, success ] = error_list[ level ].insert( std::move( error ) );
  if ( !success )
    return;

  fmt::print( stderr, "{}: {}\n", util::error_level_string( level ), *it );
  std::fflush( stderr );
}

/// merge sims
void sim_t::merge( sim_t& other_sim )
{
  auto_lock_t auto_lock( merge_mutex );
  const auto start_time = chrono::wall_clock::now();

  if ( scaling->scale_stat == STAT_NONE && scaling->calculate_scale_factors == 0 && plot->dps_plot_stats.empty() &&
       reforge_plot->reforge_plot_stat_str.empty() && profileset_map.empty() && !profileset_enabled )
  {
    fmt::print( "Merging data from thread-{} ...\n", other_sim.thread_index );
    std::fflush( stdout );
  }

  iterations += other_sim.iterations;
  work_per_thread[ other_sim.thread_index ] = other_sim.work_done;

  simulation_length.merge( other_sim.simulation_length );
  total_dmg.merge( other_sim.total_dmg );
  raid_dps.merge( other_sim.raid_dps );
  total_heal.merge( other_sim.total_heal );
  raid_hps.merge( other_sim.raid_hps );
  total_absorb.merge( other_sim.total_absorb );
  raid_aps.merge( other_sim.raid_aps );
  event_mgr.merge( other_sim.event_mgr );

  for ( auto & buff : buff_list )
  {
    if ( buff_t* otherbuff = buff_t::find( &other_sim, buff -> name_str ) )
    {
      buff -> merge( *otherbuff );
    }
  }

  for ( auto & player : actor_list )
  {
    // If the player is spawned by a separate wrapper class, it will handle the merging process
    if ( player -> spawner != nullptr )
    {
      continue;
    }

    player_t* other_p = other_sim.find_player( player -> index );
    assert( other_p );
    player -> merge( *other_p );
  }

  raid_event_t::merge( this, &other_sim );

  // After normal player merging, merge all dynamically spawned players. This is done after the
  // normal player merging because the dynamic spawner merging process may need to create new actors
  // into the parent (e.g., thread 0) sim to accommodate child sims managing to create more actors
  // than the parent
  spawner::merge( *this, other_sim );

  range::append( iteration_data, other_sim.iteration_data );
  merge_time += chrono::elapsed(start_time);
}

/// merge all sims together
void sim_t::merge()
{
  work_per_thread[ thread_index ] = work_done;

  if ( children.empty() )
    return;

  merge_mutex.unlock();

  for ( auto& child : children )
  {
    if ( child )
    {
      child -> join();
      sim_t* copy = child;
      child = nullptr;
      if ( requires_cleanup() )
      {
        delete copy;
      }
    }
  }

  children.clear();
}

// sim_t::run (for threads) ===================================================

void sim_t::run()
{
  try
  {
    if ( iterate() )
      parent->merge( *this );
  }
  catch ( const std::exception& )
  {
    try
    {
      std::throw_with_nested( std::runtime_error( fmt::format( "Thread ({})", thread_index ) ) );
    }
    catch ( const std::exception& )
    {
      cancel();
      AUTO_LOCK( parent->exception_mutex );
      parent->exception_queue.push_back( std::current_exception() );
    }
  }
}

// sim_t::partition =========================================================

void sim_t::partition()
{
  iterations = work_queue -> size();

  if ( threads <= 1 )
    return;
  if ( iterations < threads )
    return;

  thread::set_main_thread_priority();

  merge_mutex.lock(); // parent sim is locked until parent merge() is called

  int remainder = iterations % threads;
  iterations /= threads;

  // Normally we use a shared work-queue to ensure proper load balancing among threads.
  // However, when we desire deterministic runs (for debugging) we need to force the
  // sims to each use a specific number of iterations as opposed to using shared pool of work.

  if ( deterministic || strict_work_queue )
  {
    work_queue -> init( iterations );
  }

  int num_children = threads - 1;

  sim_control_t* child_control = nullptr;
  // Filter out profileset-related options from the child sim control, since they are not going to
  // use them anyhow. This significantly speeds up child creation in situations where the input
  // profile is a very large set of profileset sims.
  if ( !profileset_map.empty() )
  {
    child_control = profileset::filter_control( control );
  }
  else
  {
    child_control = control;
  }

  for ( int i = 0; i < num_children; i++ )
  {
    auto  child = new sim_t( this, i + 1, child_control, child_control->combat.name );

    assert( child );
    children.push_back( child );

    child -> iterations = iterations;
    if ( remainder )
    {
      child -> iterations += 1;
      remainder--;
    }

    if( deterministic || strict_work_queue )
    {
      child -> work_queue -> init( child -> iterations );
    }
    else // share the work queue
    {
      child -> work_queue = work_queue;
    }
    child -> report_progress = 0;
  }

  computer_process::set_priority( process_priority ); // Set main thread priority

  for ( auto & child : children )
    child -> launch();

  // Safe to do for now, since control is only referenced by sim_t::setup, which is called in the
  // sim_t constructor.
  if ( !profileset_map.empty() )
  {
    delete child_control;
  }
}

// sim_t::execute ===========================================================

bool sim_t::execute()
{
  struct finally_t
  {
    std::function<void()> fn;

    finally_t( std::function<void()> fn ) : fn( std::move( fn ) )
    {
    }

    ~finally_t()
    {
      fn();
    }
  };

  const auto start_cpu_time  = chrono::cpu_clock::now();
  const auto start_wall_time = chrono::wall_clock::now();

  bool success = false;
  {
    // Always merge, even in cases of unsuccessful simulation, parent sim merge_mutex is unlocked in merge()
    auto merge_final_action = finally_t( [ & ]() {
      merge();
      // Rethrow accumulated exceptions from threads
      if ( !children.empty() && rethrow_exception_queue() )
        success = false;
    } );

    // Split out to threads, parent sim merge_mutex is locked in partition until merge()
    partition();
    success = iterate();
  }

  if ( success )
    analyze();

  elapsed_cpu  = chrono::elapsed( start_cpu_time );
  elapsed_time = chrono::elapsed( start_wall_time );

  return success;
}

/// find player in sim by name
player_t* sim_t::find_player( util::string_view name ) const
{
  auto it = range::find( actor_list, name, &player_t::name );
  if ( it != actor_list.end())
    return *it;
  return nullptr;
}

/// find player in sim by actor index
player_t* sim_t::find_player( int index ) const
{
  auto it = range::find( actor_list, index, &player_t::index );
  if ( it != actor_list.end())
    return *it;
  return nullptr;
}

// sim_t::get_cooldown ======================================================

cooldown_t* sim_t::get_cooldown( util::string_view name )
{
  auto it = range::find( cooldown_list, name, &cooldown_t::name_str );
  if ( it != cooldown_list.end() )
    return *it;

  cooldown_t* c = new cooldown_t( name, *this );

  cooldown_list.push_back( c );

  return c;
}

// sim_t::use_optimal_buffs_and_debuffs =====================================

void sim_t::use_optimal_buffs_and_debuffs( int value )
{
  optimal_raid = value;

  overrides.arcane_intellect        = optimal_raid;
  overrides.battle_shout            = optimal_raid;
  overrides.blessing_of_the_bronze  = optimal_raid;
  overrides.mark_of_the_wild        = optimal_raid;
  overrides.power_word_fortitude    = optimal_raid;
  overrides.skyfury                 = optimal_raid;

  overrides.chaos_brand             = optimal_raid;
  overrides.mystic_touch            = optimal_raid;
  overrides.hunters_mark            = optimal_raid;
  overrides.mortal_wounds           = optimal_raid;
  overrides.bleeding                = optimal_raid;

  overrides.bloodlust               = optimal_raid;
}

// sim_t::time_to_think =====================================================

bool sim_t::time_to_think( timespan_t proc_time )
{
  if ( proc_time == timespan_t::zero() ) return false;
  if ( proc_time < timespan_t::zero() ) return true;
  return current_time() - proc_time > reaction_time;
}

// sim_t::create_expression =================================================

std::unique_ptr<expr_t> sim_t::create_expression( util::string_view name_str )
{
  if ( name_str == "desired_targets" )
    return expr_t::create_constant( name_str, desired_targets );

  if ( name_str == "desired_tank_targets" )
    return expr_t::create_constant( name_str, desired_tank_targets );

  if ( name_str == "initial_targets" )
    return expr_t::create_constant( name_str, target_list.size() );

  if ( name_str == "time" )
    return make_ref_expr( name_str, event_mgr.current_time );

  if ( util::str_compare_ci( name_str, "expected_combat_length" ) )
    return make_ref_expr( name_str, expected_iteration_time );

  if ( util::str_compare_ci( name_str, "fight_remains" ) )
    return make_fn_expr( name_str, [ this ] {
      return expected_iteration_time - event_mgr.current_time;
    } );

  if ( util::str_compare_ci( name_str, "interpolated_fight_remains" ) )
    return make_fn_expr( name_str, [ this ] {
      return max_time * ( 1.0 - event_mgr.current_time / expected_iteration_time );
    } );

  if ( name_str == "channel_lag" )
    return expr_t::create_constant( name_str, channel_lag.mean );

  if ( name_str == "channel_lag_stddev" )
    return expr_t::create_constant( name_str, channel_lag.stddev );

  if ( util::str_compare_ci( name_str, "enemies" ) )
    return expr_t::create_constant( name_str, enemy_targets );

  if ( util::str_compare_ci( name_str, "active_enemies" ) )
  {
    if ( target_list.size() == 1U && !has_raid_event( "adds" ) && !has_raid_event( "pull" ) )
    {
      return expr_t::create_constant( name_str, 1.0 );
    }
    else
    {
      return make_ref_expr( name_str, active_enemies );
    }
  }

  if ( util::str_compare_ci( name_str, "active_allies" ) )
    return make_ref_expr( name_str, active_allies );

  if ( util::str_compare_ci( name_str, "active_allied_augmentations" ) )
  {
    if ( player_list.size() == 1U )
    {
      return expr_t::create_constant( name_str, 0 );
    }
    else
    {
      return make_fn_expr( name_str, [ this ] {
        int augs = 0;
        for ( auto& player : player_non_sleeping_list )
        {
          if ( player->specialization() == EVOKER_AUGMENTATION )
            augs++;
        }
        return augs;
      } );
    }
  }

  // Get the number of actors in the simulation that do not have execute abilities
  if ( name_str == "nonexecute_actors_pct" )
  {
    struct nonexecute_actors_pct_expr : public expr_t
    {
      double nonexecute_actors_pct;  // Cached value, created on expression
                                     // creation

      nonexecute_actors_pct_expr( const sim_t* sim ) : expr_t( "nonexecute_actors_pct" )
      {
        double execute    = 0.0;
        double nonexecute = 0.0;

        for ( const player_t* p : sim->player_list )
        {
          if ( p->role != ROLE_NONE )
          {
            switch ( p->specialization() )
            {
              case PRIEST_SHADOW:
              case WARRIOR_ARMS:
              case WARRIOR_FURY:
                execute += 1.0;
                break;
              default:
                nonexecute += 1.0;
            }
          }
        }

        auto divisor = ( nonexecute + execute );
        nonexecute_actors_pct = divisor != 0 ? nonexecute / divisor : 0.0;
      }

      double evaluate() override
      {
        return nonexecute_actors_pct;
      }
    };
    return std::make_unique<nonexecute_actors_pct_expr>( this );
  }

  auto splits = util::string_split<util::string_view>( name_str, "." );

  if ( splits.size() == 2 && util::str_compare_ci( splits[ 0 ], "fight_style" ) )
  {
    return expr_t::create_constant(
        name_str, util::str_compare_ci( util::fight_style_string( fight_style ), splits[ 1 ] ) );
  }

  if ( splits.size() == 3 )
  {
    if ( splits[ 0 ] == "aura" )
    {
      buff_t* buff = buff_t::find( this, splits[ 1 ] );
      if ( !buff )
        return nullptr;

      return buff_t::create_expression( splits[ 1 ], splits[ 2 ], *buff );
    }
  }

  if ( splits.size() >= 3 && splits[ 0 ] == "actors" )
  {
    player_t* actor = sim_t::find_player( splits[ 1 ] );
    if ( !target )
      return nullptr;

    auto rest = std::string( splits[ 2 ] );
    for ( size_t i = 3; i < splits.size(); ++i )
      rest += fmt::format( ".{}", splits[ i ] );

    return actor->create_expression( rest );
  }

  if ( splits.size() == 1 && splits[ 0 ] == "target" )
  {
    return make_ref_expr( name_str, target->actor_index );
  }

  // conditionals that handle upcoming raid events

  if ( splits.size() >= 3 && util::str_compare_ci( splits[ 0 ], "raid_event" ) )
  {
    auto type_or_name = splits[ 1 ];
    auto filter = splits[ 2 ];

    // Call once to see if we have a valid raid expression.
    bool is_constant = false;
    raid_event_t::evaluate_raid_event_expression( this, type_or_name, filter, true, &is_constant );

    if ( is_constant )
    {
      return expr_t::create_constant(
          name_str, raid_event_t::evaluate_raid_event_expression( this, type_or_name, filter, false, &is_constant ) );
    }

    struct raid_event_expr_t : public expr_t
    {
      sim_t* s;
      std::string type;
      std::string filter;

      raid_event_expr_t( sim_t* s, util::string_view type, util::string_view filter )
        : expr_t( fmt::format( "raid_event_{}_{}", type, filter ) ), s( s ), type( type ), filter( filter )
      {}

      double evaluate() override
      {
        return raid_event_t::evaluate_raid_event_expression( s, type, filter, false, nullptr );
      }
    };

    return std::make_unique<raid_event_expr_t>( this, type_or_name, filter );
  }

  // If nothing else works, check to see if the string matches an actor in the sim.
  // If so, return their actor index
  if ( splits.size() == 1 )
    for ( size_t i = 0; i < actor_list.size(); i++ )
      if ( name_str == actor_list[ i ]->name_str )
        return make_ref_expr( name_str, actor_list[ i ]->actor_index );

  return nullptr;
}

// sim_t::print_options =====================================================

void sim_t::print_options()
{
  auto& raw_log = out_log.raw();
  raw_log.print( "\nWorld of Warcraft Raid Simulator Options:\n" );

  raw_log.print( "\nSimulation Engine:\n" );
  for ( const auto& option : options )
  {
    if ( option->name() != "apikey" )  // Don't print out sensitive information.
      raw_log.print( "{}", *option );
  }

  for ( const auto* p : player_list )
  {
    raw_log.print( "\nPlayer: {} ({})\n", p->name(), util::player_type_string( p->type ) );
    for ( const auto& option : p->options )
      raw_log.print( "{}", *option );
  }

  raw_log.print( "\n" );
}

void sim_t::add_option( std::unique_ptr<option_t> opt )
{
  options.insert( options.begin(), std::move(opt) );
}

// sim_t::create_options ====================================================

void sim_t::create_options()
{
  // General
  add_option( opt_int( "iterations", iterations ) );
  add_option( opt_bool( "cleanup_threads", cleanup_threads ) );
  add_option( opt_float( "target_error", target_error ) );
  add_option( opt_func( "target_error_role", parse_target_error_role ) );
  add_option( opt_int( "analyze_error_interval", analyze_error_interval ) );
  add_option( opt_func( "process_priority", parse_process_priority ) );
  add_option( opt_timespan( "max_time", max_time, timespan_t::zero(), timespan_t::max() ) );
  add_option( opt_bool( "fixed_time", fixed_time ) );
  add_option( opt_float( "vary_combat_length", vary_combat_length, 0.0, 1.0 ) );
  add_option( opt_func( "ptr", parse_ptr ) );
  add_option( opt_int( "threads", threads ) );
  add_option( opt_float( "confidence", confidence, 0.0, 1.0 ) );
  add_option( opt_func( "spell_query", parse_spell_query ) );
  add_option( opt_string( "spell_query_xml_output_file", spell_query_xml_output_file_str ) );
  add_option( opt_func( "item_db_source", parse_item_sources ) );
  add_option( opt_func( "proxy", parse_proxy ) );
  add_option( opt_int( "stat_cache", stat_cache ) );
  add_option( opt_int( "max_aoe_enemies", max_aoe_enemies ) );
  add_option( opt_int( "optimize_expressions", optimize_expressions, 0, std::numeric_limits<int>::max() ) );
  add_option( opt_int( "optimize_expressions_rounds", optimize_expressions_rounds, 0, 100 ) );
  add_option( opt_bool( "single_actor_batch", single_actor_batch ) );
  add_option( opt_bool( "progressbar_type", progressbar_type ) );
  add_option( opt_bool( "allow_experimental_specializations", allow_experimental_specializations ) );
  add_option( opt_bool( "enable_all_talents", enable_all_talents ) );
  add_option( opt_bool( "enable_all_sets", enable_all_sets ) );
  add_option( opt_bool( "enable_all_item_effects", enable_all_item_effects ) );

  // Raid buff overrides
  add_option( opt_func( "optimal_raid", parse_optimal_raid ) );
  add_option( opt_func( "fight_style", parse_fight_style ) );
  add_option( opt_int( "override.arcane_intellect", overrides.arcane_intellect ) );
  add_option( opt_int( "override.battle_shout", overrides.battle_shout ) );
  add_option( opt_int( "override.blessing_of_the_bronze", overrides.blessing_of_the_bronze ) );
  add_option( opt_int( "override.mark_of_the_wild", overrides.mark_of_the_wild ) );
  add_option( opt_int( "override.power_word_fortitude", overrides.power_word_fortitude ) );
  add_option( opt_int( "override.skyfury", overrides.skyfury ) );
  add_option( opt_int( "override.chaos_brand", overrides.chaos_brand ) );
  add_option( opt_int( "override.mystic_touch", overrides.mystic_touch ) );
  add_option( opt_int( "override.hunters_mark", overrides.hunters_mark ) );
  add_option( opt_int( "override.mortal_wounds", overrides.mortal_wounds ) );
  add_option( opt_int( "override.bleeding", overrides.bleeding ) );
  add_option( opt_func( "override.spell_data", parse_override_spell_data ) );
  add_option( opt_func( "override.target_health", parse_override_target_health ) );
  // Lag
  add_option( opt_timespan( "channel_lag", channel_lag.mean ) );
  add_option( opt_timespan( "channel_lag_stddev", channel_lag.stddev ) );
  add_option( opt_timespan( "gcd_lag", gcd_lag.mean ) );
  add_option( opt_timespan( "gcd_lag_stddev", gcd_lag.stddev ) );
  add_option( opt_timespan( "queue_lag", queue_lag.mean ) );
  add_option( opt_timespan( "queue_lag_stddev", queue_lag.stddev ) );
  add_option( opt_timespan( "queue_gcd_reduction", queue_gcd_reduction ) );
  add_option( opt_bool( "strict_gcd_queue", strict_gcd_queue ) );
  add_option( opt_timespan( "default_cooldown_tolerance", default_cooldown_tolerance ) );
  add_option( opt_timespan( "default_world_lag", world_lag.mean ) );
  add_option( opt_timespan( "default_world_lag_stddev", world_lag.stddev ) );
  add_option( opt_timespan( "default_aura_delay", default_aura_delay.mean ) );
  add_option( opt_timespan( "default_aura_delay_stddev", default_aura_delay.stddev ) );
  add_option( opt_float( "default_skill", default_skill ) );
  add_option( opt_timespan( "reaction_time", reaction_time ) );
  add_option( opt_float( "travel_variance", travel_variance ) );
  add_option( opt_timespan( "ignite_sampling_delta", ignite_sampling_delta ) );
  // Output
  add_option( opt_bool( "save_profiles", save_profiles ) );
  add_option( opt_bool( "save_profile_with_actions", save_profile_with_actions ) );
  add_option( opt_bool( "save_full_profile", save_full_profile ) );
  add_option( opt_bool( "default_actions", default_actions ) );
  add_option( opt_bool( "debug", debug ) );

  add_option( opt_bool( "strict_parsing", strict_parsing ) );
  add_option( opt_bool( "debug_each", debug_each ) );
  add_option( opt_func( "debug_seed", parse_debug_seed ) );
  add_option( opt_func( "json", parse_json_reports ) );
  add_option( opt_func( "json2", replace_json2 ) );
  add_option( opt_string( "html", html_file_str ) );
  add_option( opt_bool( "hosted_html", hosted_html ) );
  add_option( opt_bool( "offline", offline ) );
  add_option( opt_int( "healing", healing ) );
  add_option( opt_bool( "log", log ) );
  add_option( opt_string( "output", output_file_str ) );
  add_option( opt_bool( "save_raid_summary", save_raid_summary ) );
  add_option( opt_bool( "save_gear_comments", save_gear_comments ) );
  add_option( opt_bool( "buff_uptime_timeline", buff_uptime_timeline ) );
  add_option( opt_bool( "buff_stack_uptime_timeline", buff_stack_uptime_timeline ) );
  // Bloodlust
  add_option( opt_int( "bloodlust_percent", bloodlust_percent ) );
  add_option( opt_timespan( "bloodlust_time", bloodlust_time ) );
  // Overrides
  add_option( opt_bool( "override.allow_potions", allow_potions ) );
  add_option( opt_bool( "override.allow_food", allow_food ) );
  add_option( opt_bool( "override.allow_flasks", allow_flasks ) );
  add_option( opt_bool( "override.allow_augmentations", allow_augmentations ) );
  add_option( opt_bool( "override.bloodlust", overrides.bloodlust ) );
  // Regen
  add_option( opt_timespan( "regen_periodicity", regen_periodicity ) );
  // RNG
  add_option( opt_bool( "deterministic", deterministic ) );
  add_option( opt_bool( "strict_work_queue", strict_work_queue ) );
  add_option( opt_float( "report_iteration_data", report_iteration_data ) );
  add_option( opt_int( "min_report_iteration_data", min_report_iteration_data ) );
  add_option( opt_bool( "report_strict_iteration_data", report_strict_iteration_data ) );
  add_option( opt_bool( "average_range", average_range ) );
  add_option( opt_bool( "average_gauss", average_gauss ) );
  // Misc
  add_option( opt_list( "party", party_encoding ) );
  add_option( opt_func( "active", parse_active ) );
  add_option( opt_uint64( "seed", seed ) );
  add_option( opt_float( "wheel_granularity", event_mgr.wheel_granularity ) );
  add_option( opt_int( "wheel_seconds", event_mgr.wheel_seconds ) );
  add_option( opt_int( "wheel_shift", event_mgr.wheel_shift ) );
  add_option( opt_string( "reference_player", reference_player_str ) );
  add_option( opt_string( "raid_events", raid_events_str ) );
  add_option( opt_append( "raid_events+", raid_events_str ) );
  add_option( opt_string( "main_target", main_target_str ) );
  add_option( opt_float( "enemy_death_pct", enemy_death_pct ) );
  add_option( opt_int( "target_level", target_level ) );
  add_option( opt_int( "target_level+", rel_target_level ) );
  add_option( opt_string( "target_race", target_race ) );
  add_option( opt_bool( "challenge_mode", challenge_mode ) );
  add_option( opt_int( "timewalk", timewalk, -1, MAX_SCALING_LEVEL ) );
  add_option( opt_int( "scale_to_itemlevel", scale_to_itemlevel ) );
  add_option( opt_bool( "scale_itemlevel_down_only", scale_itemlevel_down_only ) );
  add_option( opt_bool( "disable_set_bonuses", disable_set_bonuses ) );
  add_option( opt_string( "disable_2_set", disable_2_set ) );
  add_option( opt_string( "disable_4_set", disable_4_set ) );
  add_option( opt_string( "enable_2_set", enable_2_set ) );
  add_option( opt_string( "enable_4_set", enable_4_set ) );
  add_option( opt_bool( "pvp", pvp_mode ) );
  add_option( opt_bool( "auto_attacks_always_land", auto_attacks_always_land ) );
  add_option( opt_bool( "log_spell_id", log_spell_id ) );
  add_option( opt_int( "desired_targets", desired_targets ) );
  add_option( opt_int( "desired_tank_targets", desired_tank_targets ) );
  add_option( opt_bool( "enable_taunts", enable_taunts ) );
  add_option( opt_bool( "use_item_verification", use_item_verification ) );
  add_option( opt_int( "keystone_level", dungeon_route_key_level ) );
  add_option( opt_int( "keystone_pct_hp", dungeon_route_pct_hp, 0, 100 ) );
  add_option( opt_bool( "dungeon_route_smart_targeting", dungeon_route_smart_targeting ) );
  add_option( opt_int( "dungeon_route_simple_dps_members", dungeon_route_simple_dps_members, 0, 3 ) );

  // Character Creation
  add_option( opt_func( "deathknight", parse_player ) );
  add_option( opt_func( "demonhunter", parse_player ) );
  add_option( opt_func( "druid", parse_player ) );
  add_option( opt_func( "evoker", parse_player ) );
  add_option( opt_func( "hunter", parse_player ) );
  add_option( opt_func( "mage", parse_player ) );
  add_option( opt_func( "monk", parse_player ) );
  add_option( opt_func( "priest", parse_player ) );
  add_option( opt_func( "paladin", parse_player ) );
  add_option( opt_func( "rogue", parse_player ) );
  add_option( opt_func( "shaman", parse_player ) );
  add_option( opt_func( "warlock", parse_player ) );
  add_option( opt_func( "warrior", parse_player ) );
  add_option( opt_func( "player_simplified", parse_player ) );
  add_option( opt_func( "enemy", parse_player ) );
  add_option( opt_func( "tank_dummy", parse_player ) );
  add_option( opt_func( "pet", parse_player ) );
  add_option( opt_func( "guardian", parse_player ) );
  add_option( opt_func( "copy", parse_player ) );
  add_option( opt_func( "armory", parse_armory ) );
  add_option( opt_func( "guild", parse_guild ) );
  add_option( opt_func( "local_json", parse_armory ) );
  add_option( opt_func( "http_clear_cache", clear_http_cache ) );
  add_option( opt_func( "cache_items", parse_cache ) );
  add_option( opt_func( "cache_players", parse_cache ) );
  add_option( opt_string( "default_region", default_region_str ) );
  add_option( opt_string( "default_server", default_server_str ) );
  add_option( opt_string( "save_prefix", save_prefix_str ) );
  add_option( opt_string( "save_suffix", save_suffix_str ) );
  add_option( opt_bool( "save_talent_str", save_talent_str ) );
  add_option( opt_int( "armory_retries", armory_retries ) );
  add_option( opt_map( "override.item_slot.", item_slot_overrides ) );

  // Stat Enchants
  add_option( opt_float( "default_enchant_strength", enchant.attribute[ATTR_STRENGTH] ) );
  add_option( opt_float( "default_enchant_agility", enchant.attribute[ATTR_AGILITY] ) );
  add_option( opt_float( "default_enchant_stamina", enchant.attribute[ATTR_STAMINA] ) );
  add_option( opt_float( "default_enchant_intellect", enchant.attribute[ATTR_INTELLECT] ) );
  add_option( opt_float( "default_enchant_spirit", enchant.attribute[ATTR_SPIRIT] ) );
  add_option( opt_float( "default_enchant_spell_power", enchant.spell_power ) );
  add_option( opt_float( "default_enchant_attack_power", enchant.attack_power ) );
  add_option( opt_float( "default_enchant_haste_rating", enchant.haste_rating ) );
  add_option( opt_float( "default_enchant_mastery_rating", enchant.mastery_rating ) );
  add_option( opt_float( "default_enchant_crit_rating", enchant.crit_rating ) );
  add_option( opt_float( "default_enchant_versatility_rating", enchant.versatility_rating ) );
  add_option( opt_float( "default_enchant_health", enchant.resource[RESOURCE_HEALTH] ) );
  add_option( opt_float( "default_enchant_mana", enchant.resource[RESOURCE_MANA] ) );
  add_option( opt_float( "default_enchant_rage", enchant.resource[RESOURCE_RAGE] ) );
  add_option( opt_float( "default_enchant_energy", enchant.resource[RESOURCE_ENERGY] ) );
  add_option( opt_float( "default_enchant_focus", enchant.resource[RESOURCE_FOCUS] ) );
  add_option( opt_float( "default_enchant_runic", enchant.resource[RESOURCE_RUNIC_POWER] ) );
  // Report
  add_option( opt_int( "display_build", display_build ) );
  add_option( opt_int( "report_precision", report_precision ) );
  add_option( opt_bool( "report_pets_separately", report_pets_separately ) );
  add_option( opt_bool( "report_targets", report_targets ) );
  add_option( opt_bool( "report_details", report_details ) );
  add_option( opt_func( "report_merged_stats", parse_report_merged_stats) );
  add_option( opt_bool( "full_damage_sources_chart", full_damage_sources_chart ) );
  add_option( opt_bool( "report_all_variables", report_all_variables ) );
  add_option( opt_bool( "collect_action_sequence", collect_action_sequence ) );
  add_option( opt_bool( "report_rng", report_rng ) );
  add_option( opt_int( "statistics_level", statistics_level ) );
  add_option( opt_bool( "separate_stats_by_actions", separate_stats_by_actions ) );
  add_option( opt_bool( "report_raid_summary", report_raid_summary ) ); // Force reporting of raid summary
  add_option( opt_string( "reforge_plot_output_file", reforge_plot_output_file_str ) );
  add_option( opt_bool( "monitor_cpu", event_mgr.monitor_cpu ) );
  add_option( opt_func( "maximize_reporting", parse_maximize_reporting ) );
  add_option( opt_string( "apikey", apikey ) );
  add_option( opt_string( "apitoken", user_apitoken ) );
  add_option( opt_bool( "distance_targeting_enabled", distance_targeting_enabled ) );
  add_option( opt_bool( "ignore_invulnerable_targets", ignore_invulnerable_targets ) );
  add_option( opt_bool( "enable_dps_healing", enable_dps_healing ) );
  add_option( opt_bool( "count_overheal_as_heal", count_overheal_as_heal ) );
  add_option( opt_float( "dhaps_healing_weight", dhaps_healing_weight ) );
  add_option( opt_float( "scaling_normalized", scaling_normalized ) );
  add_option( opt_bool( "merge_enemy_priority_dmg", merge_enemy_priority_dmg ) );
  add_option( opt_int( "decorated_tooltips", decorated_tooltips ) );
  add_option( opt_uint( "spell_query_wrap", spell_query_wrap, 50, UINT_MAX ) );
  // Sim Controller Options
  add_option( opt_map_list( "profileset_controller.", profileset_controller_options ) );
  // Charts
  add_option( opt_bool( "chart_show_relative_difference", chart_show_relative_difference ) );
  add_option( opt_bool( "chart_show_relative_difference_percent", chart_show_relative_difference_percent ) );
  add_option( opt_string( "relative_difference_base", relative_difference_base ) );
  add_option( opt_bool( "relative_difference_from_max", relative_difference_from_max ) );
  add_option( opt_float( "chart_boxplot_percentile", chart_boxplot_percentile ) );
  // Hotfix
  add_option( opt_bool( "show_hotfixes", display_hotfixes ) );
  // Bonus ids
  add_option( opt_bool( "show_bonus_ids", display_bonus_ids ) );

  // Expansion-specific options

  // Legion
  add_option( opt_int( "legion.infernal_cinders_users", legion_opts.infernal_cinders_users, 1, 20 ) );
  add_option( opt_int( "legion.engine_of_eradication_orbs", legion_opts.engine_of_eradication_orbs, 0, 4 ) );
  add_option( opt_int( "legion.void_stalkers_contract_targets", legion_opts.void_stalkers_contract_targets ) );
  add_option( opt_float( "legion.specter_of_betrayal_overlap", legion_opts.specter_of_betrayal_overlap, 0, 1 ) );
  add_option( opt_func( "legion.cradle_of_anguish_resets", []( sim_t* sim, util::string_view, util::string_view value ) {
    auto split = util::string_split<util::string_view>( value, ":/," );
    range::for_each( split, [ sim ]( util::string_view str ) {
      auto v = util::to_double( str );
      if ( v <= 0.0 )
      {
        return;
      }

      auto it = range::find( sim -> legion_opts.cradle_of_anguish_resets, v );
      if ( it != sim -> legion_opts.cradle_of_anguish_resets.end() )
      {
        return;
      }

      sim -> legion_opts.cradle_of_anguish_resets.push_back( v );
    } );
    return true;
  } ) );

  // Battle for Azeroth
  add_option( opt_func( "disable_azerite", []( sim_t* sim, util::string_view, util::string_view value ) {
    if ( value == "1" )
    {
      sim -> azerite_status = azerite_control::DISABLED_ALL;
    }
    else if ( util::str_compare_ci( value, "items" ) )
    {
      sim -> azerite_status = azerite_control::DISABLED_ITEMS;
    }
    else if ( util::str_compare_ci( value, "all" ) )
    {
      sim -> azerite_status = azerite_control::DISABLED_ALL;
    }
    else if ( util::str_compare_ci( value, "0" ) || util::str_compare_ci( value, "false" ) )
    {
     sim -> azerite_status = azerite_control::ENABLED;
    }
    else
    {
      sim -> error( "Unknown disable_azerite value '{}', valid values are 'items' or 'all'",
          value );
      return false;
    }
    return true;
  } ) );

  add_option( opt_uint( "bfa.jes_howler_allies", bfa_opts.jes_howler_allies, 0, 4 ) );
  add_option( opt_float( "bfa.secrets_of_the_deep_chance",
        bfa_opts.secrets_of_the_deep_chance, 0, 1 ) );
  add_option( opt_float( "bfa.secrets_of_the_deep_collect_chance",
        bfa_opts.secrets_of_the_deep_collect_chance, 0, 1 ) );
  add_option( opt_int( "bfa.initial_archive_of_the_titans_stacks",
        bfa_opts.initial_archive_of_the_titans_stacks, 0, 20 ) );
  add_option( opt_int( "bfa.reorigination_array_stacks",
        bfa_opts.reorigination_array_stacks, 0, 10 ) );
  add_option( opt_bool( "bfa.reorigination_array_ignore_scale_factors",
        bfa_opts.reorigination_array_ignore_scale_factors ) );
  add_option( opt_float( "bfa.seductive_power_pickup_chance",
        bfa_opts.seductive_power_pickup_chance, 0.0, 1.0 ) );
  add_option( opt_int( "bfa.initial_seductive_power_stacks",
        bfa_opts.initial_seductive_power_stacks, 0, 5 ) );
  add_option( opt_bool( "bfa.randomize_oscillation",
        bfa_opts.randomize_oscillation ) );
  add_option( opt_bool( "bfa.auto_oscillating_overload",
        bfa_opts.auto_oscillating_overload ) );
  add_option( opt_bool( "bfa.zuldazar",
        bfa_opts.zuldazar ) );
  add_option( opt_timespan( "bfa.covenant_period",
        bfa_opts.covenant_period, 1_ms, timespan_t::max() ) );
  add_option( opt_float( "bfa.covenant_chance",
        bfa_opts.covenant_chance, 0.0, 1.0 ) );
  add_option( opt_float( "bfa.incandescent_sliver_chance",
        bfa_opts.incandescent_sliver_chance, 0.0, 1.0 ) );
  add_option( opt_timespan( "bfa.fight_or_flight_period",
        bfa_opts.fight_or_flight_period, 1_ms, timespan_t::max() ) );
  add_option( opt_float( "bfa.fight_or_flight_chance",
        bfa_opts.fight_or_flight_chance, 0.0, 1.0 ) );
  add_option( opt_float( "bfa.harbingers_inscrutable_will_silence_chance",
        bfa_opts.harbingers_inscrutable_will_silence_chance, 0.0, 1.0 ) );
  add_option( opt_float( "bfa.harbingers_inscrutable_will_move_chance",
        bfa_opts.harbingers_inscrutable_will_move_chance, 0.0, 1.0 ) );
  add_option( opt_float( "bfa.aberrant_tidesage_damage_chance",
        bfa_opts.aberrant_tidesage_damage_chance, 0.0, 1.0 ) );
  add_option( opt_float( "bfa.fathuuls_floodguards_damage_chance",
        bfa_opts.fathuuls_floodguards_damage_chance, 0.0, 1.0 ) );
  add_option( opt_float( "bfa.grips_of_forsaken_sanity_damage_chance",
        bfa_opts.grips_of_forsaken_sanity_damage_chance, 0.0, 1.0 ) );
  add_option( opt_float( "bfa.stormglide_steps_take_damage_chance",
        bfa_opts.stormglide_steps_take_damage_chance, 0.0, 1.0 ) );
  add_option( opt_timespan( "bfa.lurkers_insidious_gift_duration",
        bfa_opts.lurkers_insidious_gift_duration, 0_ms, timespan_t::max() ) );
  add_option( opt_timespan( "bfa.abyssal_speakers_gauntlets_shield_duration",
        bfa_opts.abyssal_speakers_gauntlets_shield_duration, 0_ms, timespan_t::max() ) );
  add_option( opt_timespan( "bfa.trident_of_deep_ocean_duration",
        bfa_opts.trident_of_deep_ocean_duration, 0_ms, timespan_t::max() ) );
  add_option( opt_float( "bfa.legplates_of_unbound_anguish_chance",
        bfa_opts.legplates_of_unbound_anguish_chance, 0.0, 1.0 ) );
  add_option( opt_int( "bfa.loyal_to_the_end_allies",
        bfa_opts.loyal_to_the_end_allies, 0, 4 ) );
  add_option( opt_timespan( "bfa.loyal_to_the_end_ally_death_timer",
        bfa_opts.loyal_to_the_end_ally_death_timer, 1_s, timespan_t::max() ) );
  add_option( opt_float( "bfa.loyal_to_the_end_ally_death_chance",
        bfa_opts.loyal_to_the_end_ally_death_chance, 0.0, 1.0 ) );
  add_option( opt_int( "bfa.worldvein_allies",
        bfa_opts.worldvein_allies, 0, 10 ) );
  add_option( opt_float( "bfa.ripple_in_space_proc_chance",
        bfa_opts.ripple_in_space_proc_chance, 0.0, 1.0 ) );
  add_option( opt_float( "bfa.blood_of_the_enemy_in_range",
        bfa_opts.blood_of_the_enemy_in_range, 0.0, 1.0 ) );
  add_option( opt_timespan( "bfa.undulating_tides_lockout_timer",
        bfa_opts.undulating_tides_lockout_timer, 1_s, timespan_t::max() ) );
  add_option( opt_float( "bfa.undulating_tides_lockout_chance",
        bfa_opts.undulating_tides_lockout_chance, 0.0, 1.0 ) );
  add_option( opt_float( "bfa.leviathans_lure_base_rppm",
        bfa_opts.leviathans_lure_base_rppm, 0.0, 2.0 ) );
  add_option( opt_float( "bfa.aquipotent_nautilus_catch_chance",
        bfa_opts.aquipotent_nautilus_catch_chance, 0.0, 1.0 ) );
  add_option( opt_float( "bfa.zaquls_portal_key_move_chance",
        bfa_opts.zaquls_portal_key_move_chance, 0.0, 1.0 ) );
  add_option( opt_timespan( "bfa.anuazshara_unleash_time",
        bfa_opts.anuazshara_unleash_time, 1_s, timespan_t::max() ) );
  add_option( opt_bool( "bfa.nazjatar",
        bfa_opts.nazjatar ) );
  add_option( opt_bool( "bfa.shiver_venom",
        bfa_opts.shiver_venom ) );
  add_option( opt_float( "bfa.storm_of_the_eternal_ratio",
        bfa_opts.storm_of_the_eternal_ratio, 0.0, 1.0 ) );
  add_option( opt_timespan( "bfa.font_of_power_precombat_channel",
        bfa_opts.font_of_power_precombat_channel, 0_ms, 34_s ) );
  add_option( opt_uint( "bfa.arcane_heart_hps", bfa_opts.arcane_heart_hps) );
  add_option( opt_int( "bfa.subroutine_recalibration_precombat_stacks",
    bfa_opts.subroutine_recalibration_precombat_stacks, 0, 11 ) );
  add_option( opt_int( "bfa.subroutine_recalibration_dummy_casts",
    bfa_opts.subroutine_recalibration_dummy_casts, 0, 11 ) );
  add_option( opt_float( "bfa.voidtwisted_titanshard_percent_duration",
    bfa_opts.voidtwisted_titanshard_percent_duration, 0.01, 1.0 ) );
  add_option( opt_timespan( "bfa.surging_vitality_damage_taken_period", bfa_opts.surging_vitality_damage_taken_period,
                            1_s, timespan_t::max() ) );
  add_option( opt_uint( "bfa.manifesto_allies_start", bfa_opts.manifesto_allies_start, 0, 12 ) );
  add_option( opt_uint( "bfa.manifesto_allies_end", bfa_opts.manifesto_allies_end, 0, 5 ) );
  add_option( opt_timespan( "bfa.symbiotic_presence_interval", bfa_opts.symbiotic_presence_interval, 1_s, timespan_t::max() ) );
  add_option( opt_float( "bfa.whispered_truths_offensive_chance", bfa_opts.whispered_truths_offensive_chance, 0.0, 1.0 ) );
  add_option( opt_bool( "bfa.nyalotha", bfa_opts.nyalotha ) );

  // Shadowlands
  add_option( opt_bool( "shadowlands.enabled", shadowlands_opts.enabled ) );
  add_option( opt_obsoleted( "shadowlands.combat_meditation_extend_chance" ) );
  add_option( opt_obsoleted( "shadowlands.pointed_courage_nearby" ) );
  add_option( opt_obsoleted( "shadowlands.lead_by_example_nearby" ) );
  add_option( opt_uint( "shadowlands.stone_legionnaires_in_party", shadowlands_opts.stone_legionnaires_in_party, 0, 4 ) );
  add_option( opt_uint( "shadowlands.crimson_choir_in_party", shadowlands_opts.crimson_choir_in_party, 0, 4 ) );
  add_option( opt_timespan( "shadowlands.memory_of_past_sins_precast", shadowlands_opts.memory_of_past_sins_precast, 0_s, 30_s ) );
  add_option( opt_uint( "shadowlands.shattered_psyche_allies", shadowlands_opts.shattered_psyche_allies, 0, 4 ) );
  add_option( opt_float( "shadowlands.judgment_of_the_arbiter_arc_chance", shadowlands_opts.judgment_of_the_arbiter_arc_chance, 0.0, 1.0 ) );
  add_option( opt_obsoleted( "shadowlands.volatile_solvent_type" ) );
  add_option( opt_bool( "shadowlands.disable_soul_igniter_second_use", shadowlands_opts.disable_soul_igniter_second_use ) );
  add_option( opt_string( "shadowlands.unbound_changeling_stat_type", shadowlands_opts.unbound_changeling_stat_type ) );
  add_option( opt_float( "shadowlands.anima_field_emitter_mean", shadowlands_opts.anima_field_emitter_mean, 0.0, std::numeric_limits<double>::max() ) );
  add_option( opt_float( "shadowlands.anima_field_emitter_stddev", shadowlands_opts.anima_field_emitter_stddev, 0.0, std::numeric_limits<double>::max() ) );
  add_option( opt_timespan( "shadowlands.retarget_shadowgrasp_totem", shadowlands_opts.retarget_shadowgrasp_totem ) );
  add_option( opt_bool( "shadowlands.disable_iqd_execute", shadowlands_opts.disable_iqd_execute ) );
  add_option( opt_float( "shadowlands.gluttonous_spike_overheal_chance", shadowlands_opts.gluttonous_spike_overheal_chance, 0.0, 1.0 ) );
  add_option( opt_float( "shadowlands.iqd_stat_fail_chance", shadowlands_opts.iqd_stat_fail_chance, 0.0, 1.0 ) );
  add_option( opt_obsoleted( "shadowlands.thrill_seeker_killing_blow_chance" ) );
  add_option( opt_obsoleted( "shadowlands.wild_hunt_tactics_duration_multiplier" ) );
  add_option( opt_obsoleted( "shadowlands.bonded_hearts_other_covenant_chance" ) );
  add_option( opt_obsoleted( "shadowlands.party_favor_type" ) );
  add_option( opt_obsoleted( "shadowlands.battlefield_presence_enemies" ) );
  add_option( opt_obsoleted( "shadowlands.better_together_ally" ) );
  add_option( opt_timespan( "shadowlands.salvaged_fusion_amplifier_precast", shadowlands_opts.salvaged_fusion_amplifier_precast, 0_s, 20_s ) );
  add_option( opt_float( "shadowlands.titanic_ocular_gland_worthy_chance", shadowlands_opts.titanic_ocular_gland_worthy_chance, 0.0, 1.0 ) );
  add_option( opt_obsoleted( "shadowlands.newfound_resolve_success_chance" ) );
  add_option( opt_obsoleted( "shadowlands.newfound_resolve_default_delay" ) );
  add_option( opt_obsoleted( "shadowlands.newfound_resolve_delay_relstddev" ) );
  add_option( opt_obsoleted( "shadowlands.pustule_eruption_interval" ) );
  add_option( opt_float( "shadowlands.shredded_soul_pickup_chance", shadowlands_opts.shredded_soul_pickup_chance, 0.0, 1.0 ) );
  add_option( opt_obsoleted( "shadowlands.valiant_strikes_heal_rate" ) );
  add_option( opt_string( "shadowlands.soleahs_secret_technique_type", shadowlands_opts.soleahs_secret_technique_type ) );
  add_option( opt_timespan( "shadowlands.shadowed_orb_of_torment_precombat_channel", shadowlands_opts.shadowed_orb_of_torment_precombat_channel, 0_ms, 42_s ) );
  add_option( opt_timespan( "shadowlands.reactive_defense_matrix_interval", shadowlands_opts.reactive_defense_matrix_interval, 0_ms, timespan_t::max() ) );
  add_option( opt_obsoleted( "shadowlands.precombat_pustules" ) );
  add_option( opt_obsoleted( "shadowlands.field_of_blossoms_duration_multiplier" ) );
  add_option( opt_float( "shadowlands.cruciform_veinripper_proc_rate", shadowlands_opts.cruciform_veinripper_proc_rate, 0.0, 1.0) );
  add_option( opt_float( "shadowlands.cruciform_veinripper_in_front_rate", shadowlands_opts.cruciform_veinripper_in_front_rate, 0.0, 1.0 ) );
  add_option( opt_obsoleted( "shadowlands.the_first_sigil_fleshcraft_cancel_time" ) );
  add_option( opt_uint( "shadowlands.earthbreakers_impact_weak_points", shadowlands_opts.earthbreakers_impact_weak_points, 0, 3 ) );
  add_option( opt_float( "shadowlands.grim_eclipse_dot_duration_multiplier", shadowlands_opts.grim_eclipse_dot_duration_multiplier, 0.0, 1.0 ) );
  add_option( opt_float( "shadowlands.grim_eclipse_buff_duration_multiplier", shadowlands_opts.grim_eclipse_buff_duration_multiplier, 0.0, 1.0 ) );
  add_option( opt_bool( "shadowlands.chains_of_domination_auto_break", shadowlands_opts.chains_of_domination_auto_break ) );
  add_option( opt_obsoleted( "shadowlands.first_strike_chance" ) );
  add_option( opt_obsoleted( "shadowlands.first_strike_period" ) );
  add_option( opt_obsoleted( "shadowlands.adaptive_armor_fragment_uptime" ) );
  add_option( opt_obsoleted( "shadowlands.soothing_shade_duration_multiplier" ) );

  // Dragonflight
  add_option( opt_timespan( "dragonflight.darkmoon_deck_watcher_deplete", dragonflight_opts.darkmoon_deck_watcher_deplete, 0_ms, timespan_t::max() ) );
  add_option( opt_string( "dragonflight.whispering_incarnate_icon_roles", dragonflight_opts.whispering_incarnate_icon_roles ) );
  add_option( opt_float( "dragonflight.decoration_of_flame_miss_chance", dragonflight_opts.decoration_of_flame_miss_chance, 0.0, 1.0 ) );
  add_option( opt_timespan( "dragonflight.alltotem_of_the_master_period", dragonflight_opts.alltotem_of_the_master_period, 0_s, timespan_t::max() ) );
  add_option( opt_uint( "dragonflight.dragon_games_kicks", dragonflight_opts.dragon_games_kicks, 0, 3 ) );
  add_option( opt_float( "dragonflight.dragon_games_rng", dragonflight_opts.dragon_games_rng, 0.0, 1.0 ) );
  add_option( opt_string( "dragonflight.primal_ritual_shell_blessing", dragonflight_opts.primal_ritual_shell_blessing ) );
  add_option( opt_uint( "dragonflight.allied_wristguards_allies", dragonflight_opts.allied_wristguards_allies, 0, 3 ) );
  add_option( opt_float( "dragonflight.allied_wristguards_ally_leave_chance", dragonflight_opts.allied_wristguards_ally_leave_chance, 0.0, 1.0 ) );
  add_option( opt_float( "dragonflight.corrupting_rage_uptime", dragonflight_opts.corrupting_rage_uptime, 0.1, 1.0 ) );
  add_option( opt_float( "dragonflight.hood_of_surging_time_chance", dragonflight_opts.hood_of_surging_time_chance, 0.0, 1.0 ) );
  add_option( opt_timespan( "dragonflight.hood_of_surging_time_period", dragonflight_opts.hood_of_surging_time_period, 1_s, timespan_t::max() ) );
  add_option( opt_uint( "dragonflight.hood_of_surging_time_stacks", dragonflight_opts.hood_of_surging_time_stacks, 0, 5 ) );
  add_option( opt_string( "dragonflight.ruby_whelp_shell_training", dragonflight_opts.ruby_whelp_shell_training ) );
  add_option( opt_string( "dragonflight.ruby_whelp_shell_context", dragonflight_opts.ruby_whelp_shell_context ) );
  add_option( opt_float( "dragonflight.blue_silken_lining_uptime", dragonflight_opts.blue_silken_lining_uptime, 0.0, 1.0 ) );
  add_option( opt_timespan( "dragonflight.blue_silken_lining_update_interval", dragonflight_opts.blue_silken_lining_update_interval, 1_s, timespan_t::max() ) );
  add_option( opt_timespan( "dragonflight.blue_silken_lining_update_interval_stddev", dragonflight_opts.blue_silken_lining_update_interval_stddev, 1_s, timespan_t::max() ) );
  add_option( opt_bool( "dragonflight.screaming_black_dragonscale_damage", dragonflight_opts.screaming_black_dragonscale_damage ) );
  add_option( opt_timespan( "dragonflight.adaptive_stonescales_period", dragonflight_opts.adaptive_stonescales_period, 0_s, timespan_t::max() ) );
  add_option( opt_float( "dragonflight.undulating_sporecloak_uptime", dragonflight_opts.undulating_sporecloak_uptime, 0.0, 1.0 ) );
  add_option( opt_timespan( "dragonflight.undulating_sporecloak_update_interval", dragonflight_opts.undulating_sporecloak_update_interval, 1_s, timespan_t::max() ) );
  add_option( opt_timespan( "dragonflight.undulating_sporecloak_update_interval_stddev", dragonflight_opts.undulating_sporecloak_update_interval_stddev, 1_s, timespan_t::max() ) );
  add_option( opt_float( "dragonflight.dreamtenders_charm_uptime", dragonflight_opts.dreamtenders_charm_uptime, 0.0, 1.0 ) );
  add_option( opt_timespan( "dragonflight.dreamtenders_charm_update_interval", dragonflight_opts.dreamtenders_charm_update_interval, 1_s, timespan_t::max() ) );
  add_option( opt_timespan( "dragonflight.dreamtenders_charm_update_interval_stddev", dragonflight_opts.dreamtenders_charm_update_interval_stddev, 1_s, timespan_t::max() ) );
  add_option( opt_float( "dragonflight.embersoul_dire_chance", dragonflight_opts.embersoul_dire_chance, 0.0, 1.0 ) );
  add_option( opt_timespan( "dragonflight.embersoul_dire_interval", dragonflight_opts.embersoul_dire_interval, 1_s, timespan_t::max() ) );
  add_option( opt_timespan( "dragonflight.embersoul_dire_interval_stddev", dragonflight_opts.embersoul_dire_interval_stddev, 1_s, timespan_t::max() ) );
  add_option( opt_timespan( "dragonflight.gift_of_ursine_vengeance_period", dragonflight_opts.gift_of_ursine_vengeance_period, 3_s, timespan_t::max() ) );

  // The War Within
}

// sim_t::parse_option ======================================================

bool sim_t::parse_option( const std::string& name, const std::string& value )
{
  if ( active_player )
  {
    try
    {
      auto ret = opts::parse( this, active_player->options, name, value );

      // Bail out early on player-specific option error states
      switch ( ret )
      {
        case opts::parse_status::DEPRECATED:
        case opts::parse_status::FAILURE:    return false;
        case opts::parse_status::OK:         return true;
        default:                             break;
      }
    }
    catch ( const std::exception& )
    {
      std::throw_with_nested( sc_invalid_player_argument( fmt::format( "{}", *active_player ) ) );
    }
  }

  try
  {
    auto ret = opts::parse( this, options, name, value );
    // With strict_parsing enabled, anything else than "ok" parse status will result in hard failure
    if ( strict_parsing && ret != opts::parse_status::OK )
      return false;

    // Can't find a player- or sim scope option with name, warn the user
    if ( ret == opts::parse_status::NOT_FOUND )
      error( "Warning: Unknown option '{}' with value '{}', ignoring", name, value );

    return ret != opts::parse_status::FAILURE;
  }
  catch ( const std::exception& )
  {
    std::throw_with_nested( sc_invalid_sim_argument( "Sim setup" ) );
  }
}

// sim_t::setup =============================================================

void sim_t::setup( sim_control_t* c )
{
  // Limitation: setup+execute is a one-way action that cannot be repeated or reset

  control = c;

  if ( !parent )
    cache::advance_era();

  // Global Options
  for ( const auto& option : control->options )
  {
    if ( option.scope != "global" )
      continue;

    if ( !parse_option( option.name, option.value ) )
    {
      throw sc_invalid_sim_argument(
        fmt::format( "Unknown sim option '{}' with value '{}'.", option.name, option.value ) );
    }
  }

  // Combat
  // Try very hard to limit this to just what would be displayed on the gui.
  // Super-users can use misc options.
  // xyz = control -> combat.xyz;

  // Players
  for ( size_t i = 0; i < control->players.size(); i++ )
    player_t::create( this, control->players[ i ] );

  // Player Options
  for ( size_t i = 0; i < control->options.size(); i++ )
  {
    option_tuple_t& o = control->options[ i ];
    if ( o.scope == "global" )
      continue;

    player_t* p = find_player( o.scope );
    if ( !p )
    {
      throw sc_invalid_sim_argument(
        fmt::format( "Player '{}' not found for sim option '{}' with value '{}'.", o.scope, o.name, o.value ) );
    }

    auto ret = opts::parse( this, p->options, o.name, o.value );
    if ( ret == opts::parse_status::FAILURE )
    {
      throw sc_invalid_sim_argument(
        fmt::format( "Invalid sim option '{}' with value '{}' for player '{}'.", o.name, o.value, p->name() ) );
    }
  }

  if ( player_list.empty() && spell_query == nullptr && !display_bonus_ids && display_build <= 1 )
  {
    fmt::print( "Nothing to sim! " );
    canceled = true;
    display_build = 2;
    return;
  }

  range::for_each( player_list, []( player_t* p ) { p->validate_sim_options(); } );

  if ( parent || profileset_enabled )
  {
    debug = false;
    log = 0;
  }
  else if ( !output_file_str.empty() )
  {
    std::shared_ptr<io::ofstream> o( new io::ofstream() );
    o->open( output_file_str );
    if ( o->is_open() )
    {
      out_debug = o;
      out_log = o;
    }
    else
    {
      throw sc_runtime_error( fmt::format( "Unable to open output file '{}'.", output_file_str ) );
    }
  }

  if ( debug_each )
    debug = true;

  if ( debug )
  {
    log = 1;
    print_options();
  }

  adjust_threads( threads );

  if ( log )
  {
    if ( ! debug_each )
      iterations = 1;

    threads = 1;
  }

  if ( iterations <= 0 )
  {
    iterations = 1000000; // limited by relative standard error

    if ( target_error <= 0 )
    {
      if ( scaling->calculate_scale_factors )
      {
        target_error = 0.05;
      }
      else
      {
        target_error = 0.2;
      }
    }
    if ( plot->dps_plot_iterations <= 0 )
    {
      if ( plot->dps_plot_target_error <= 0 )
      {
        plot->dps_plot_target_error = target_error;
      }
    }
    if ( reforge_plot->reforge_plot_iterations <= 0 )
    {
      if ( reforge_plot->reforge_plot_target_error <= 0 )
      {
        reforge_plot->reforge_plot_target_error = target_error;
      }
    }
  }

  if ( single_actor_batch )
  {
    work_queue->batches( player_no_pet_list.size() );
  }
  work_queue->init( iterations );
  if ( thread_index == 0 )
  {
    work_per_thread.resize( threads );
  }

  if ( deterministic && ( target_error != 0 ) )
  {
    throw sc_invalid_sim_argument( "'deterministic=1' cannot be used with non-zero target_error values!" );
  }
}

// sim_t::progress ==========================================================

sim_progress_t sim_t::progress( std::string* detailed, int index )
{
  auto total_progress = work_queue -> progress( index );

  // If strict work queue is used with target error, estimate that total iterations will be roughly
  // the total iterations of the main thread, multiplied by the total number of threads.
  if ( target_error > 0 && strict_work_queue )
  {
    total_progress.total_iterations *= threads;
  }

  // For work queues that are independent, collect all work done so far for the progressbar.
  if ( deterministic || strict_work_queue )
  {
    AUTO_LOCK( relatives_mutex );
    for ( const auto& child : children )
    {
      if ( child )
      {
        auto progress = child -> work_queue -> progress( index );
        total_progress.current_iterations += progress.current_iterations;
        // If no target error, include total iterations from the child threads as well
        if ( target_error <= 0 )
        {
          total_progress.total_iterations += progress.total_iterations;
        }
      }
    }
  }

  detailed_progress( detailed, total_progress.current_iterations, total_progress.total_iterations );

  return total_progress;
}

double sim_t::progress( std::string& phase, std::string* detailed, int index )
{
  if ( canceled )
  {
    phase = "Canceled";
    return 1.0;
  }

  if ( plot -> num_plot_stats > 0 &&
       plot -> remaining_plot_stats > 0 )
  {
    return plot -> progress( phase, detailed );
  }
  else if ( scaling -> calculate_scale_factors &&
            scaling -> num_scaling_stats > 0 &&
            scaling -> remaining_scaling_stats > 0 )
  {
    return scaling -> progress( phase, detailed );
  }
  else if ( reforge_plot -> num_stat_combos > 0 )
  {
    return reforge_plot -> progress( phase, detailed );
  }
  else if ( current_iteration >= 0 )
  {
    phase = "Simulating";
    return progress( detailed, index ).pct();
  }
  else if ( current_slot >= 0 )
  {
    phase = current_name;
    return current_slot / ( double ) SLOT_MAX;
  }

  return 0.0;
}

void sim_t::detailed_progress( std::string* detail, int current_iterations, int total_iterations )
{
  if ( detail )
  {
    detail -> clear();
    *detail = fmt::format("Iteration {:d}/{:d}", current_iterations, total_iterations );
  }
}

void sim_t::abort()
{
  std::stringstream s;
  for ( size_t i = 0; i < target_list.size(); ++i )
  {
    fmt::print( s, "{:.0f}", target_list[ i ]->resources.initial[ RESOURCE_HEALTH ] );
    if ( i < target_list.size() - 1 )
    {
      fmt::print( s, "{}", '/' );
    }
  }

  error( "Force abort, seed={} target_health={}", seed, s.str() );
  std::terminate();
}

/// add chart to sim for end of report processing
void sim_t::add_chart_data( const highchart::chart_t& chart )
{
  // the report script renders charts with an empty toggle id once their target div is in the DOM.
  chart_data[ chart.toggle_id_str_ ].push_back( chart.to_data() );
}

void sim_t::print_spell_query()
{
  if ( ! spell_query_xml_output_file_str.empty() )
  {
    io::cfile file( spell_query_xml_output_file_str, "w" );
    if ( ! file )
    {
      fmt::print( stderr, "Unable to open spell query xml output file '{}', using stdout instead\n",
                  spell_query_xml_output_file_str );
      file = io::cfile( stdout, io::cfile::no_close() );
    }
    auto root = xml_node_t( "spell_query" );

    report::print_spell_query( &root, file, *this, *spell_query, spell_query_level );
  }
  else
  {
    report::print_spell_query( std::cout, *this, *spell_query, spell_query_level );
  }
}

/* Build a divisor timeline vector appropriate to a given timeline
 * bucket size, from given simulation length data.
 */
std::vector<double> sc_timeline_t::build_divisor_timeline( const extended_sample_data_t& simulation_length, double bin_size )
{
  std::vector<double> divisor_timeline;
  // divisor_timeline is necessary because not all iterations go the same length of time
  size_t max_buckets = static_cast<size_t>( floor( simulation_length.max() / bin_size ) + 1);
  divisor_timeline.assign( max_buckets, 0.0 );

  size_t num_timelines = simulation_length.data().size();
  for ( size_t i = 0; i < num_timelines; i++ )
  {
    size_t last = static_cast<size_t>( floor( simulation_length.data()[ i ] / bin_size ) );
    assert( last < divisor_timeline.size() ); // We created it with max length

    static const bool use_old_behaviour = true;
    if ( use_old_behaviour )
    {
      // Add all visited buckets.
      for ( size_t j = 0; j <= last; j++ )
      {
        divisor_timeline[ j ] += 1.0;
      }
    }
    else
    {
      // First add fully visited buckets.
      for ( size_t j = 0; j < last; j++ )
      {
        divisor_timeline[ j ] += 1.0;
      }

      // Now add partial amount for the last incomplete bucket.
      double remainder = simulation_length.data()[ i ] / bin_size - last;
      if ( remainder > 0.0 )
      {
        assert( last < divisor_timeline.size() );
        divisor_timeline[ last ] += remainder;
      }
    }
  }

  return divisor_timeline;
}

/* This function adjusts the timeline by a appropriate divisor_timeline.
 * Each bucket of the timeline is divided by the "amount of simulation time spent in that bucket"
 */
void sc_timeline_t::adjust( sim_t& sim )
{
  // Check if we have divisor timeline cached
  auto it = sim.divisor_timeline_cache.find( bin_size_ );
  if ( it == sim.divisor_timeline_cache.end() )
  {
    // If we don't have a cached divisor timeline, build one
    sim.divisor_timeline_cache[ bin_size_ ] = build_divisor_timeline( sim.simulation_length, bin_size_ );
  }

  // Do the timeline adjustement
  timeline_t::adjust( sim.divisor_timeline_cache[ bin_size_ ] );
}

void sc_timeline_t::adjust( const extended_sample_data_t& adjustor )
{
  // Do the timeline adjustement
  timeline_t::adjust( build_divisor_timeline( adjustor, bin_size_ ) );
}

// FIXME!  Move this to util at some point.

void sim_t::enable_debug_seed()
{
  auto enabled = false;

  if ( debug_seed.size() == 1 && seed == debug_seed[ 0 ] )
  {
    enabled = true;
  }
  else
  {
    auto it = range::lower_bound( debug_seed, seed );
    enabled = it != debug_seed.end() && *it == seed;
  }

  if ( enabled )
  {
    if ( output_file_str.empty() )
    {
      errorf( "No 'output' option specified for debug_seed, not generating debug output ..." );
      return;
    }

    std::shared_ptr<io::ofstream> o(new io::ofstream());
    std::string fname = output_file_str + "." + util::to_string( seed );
    o -> open( fname );
    if ( o -> is_open() )
    {
      out_debug = o;
      out_log = o;

      fmt::print( "------ Iteration #{} (seed={}) ------", current_iteration, seed );
      std::fflush( stdout );
    }
    else
    {
      error( "Unable to open output file '{}'\n", fname );
      return;
    }

    debug = true;
    log = 1;
  }
}

void sim_t::disable_debug_seed()
{
  if ( output_file_str.empty() )
  {
    return;
  }

  auto enabled = false;

  if ( debug_seed.size() == 1 && seed == debug_seed[ 0 ] )
  {
    enabled = true;
  }
  else
  {
    auto it = range::lower_bound( debug_seed, seed );
    enabled = it != debug_seed.end() && *it == seed;
  }

  if ( enabled )
  {
    debug = false;
    log = 0;
  }
}

double sim_t::averaged_range( double min, double max )
{
  if ( average_range ) return ( min + max ) / 2.0;
  return rng().range( min, max );
}

// Activates the relevant actors in the simulator just before simulating, based on the relevant
// simulation mode (single vs multi actor).
void sim_t::activate_actors()
{
  // Clear out all callbacks
  target_list.reset_callbacks();
  target_non_sleeping_list.reset_callbacks();
  player_list.reset_callbacks();
  player_no_pet_list.reset_callbacks();
  player_non_sleeping_list.reset_callbacks();
  healing_no_pet_list.reset_callbacks();
  healing_pet_list.reset_callbacks();

  // Normal sim mode activates all actors .. and this method is only called once at the beginning of
  // the simulation run.
  if ( ! single_actor_batch )
  {
    range::for_each( player_list, []( player_t* p ) { p -> activate(); } );
  }
  // Single-actor batch mode activates the current active actor
  else
  {
    range::for_each( target_list, []( player_t* t ) { t -> actor_changed(); } );

    // Deactivate old actor
    if ( current_index > 0 )
    {
      player_no_pet_list[ current_index - 1 ] -> deactivate();
    }

    // Activate new actor
    player_no_pet_list[ current_index ] -> activate();
    if ( ! profileset_enabled )
    {
      progress_bar.set_phase( player_no_pet_list[ current_index ] -> name_str );
    }
  }

  if ( overrides.hunters_mark )
    target_non_sleeping_list.register_callback( [ this ]( player_t* ) {
      player_t* new_mark = nullptr;
      for (size_t i = 0; i < target_non_sleeping_list.size(); i++)
      {
        player_t* t = target_non_sleeping_list[ i ];
        if ( !t->debuffs.hunters_mark )
          continue;

        if ( !new_mark )
          new_mark = t;
        else
          t->debuffs.hunters_mark->expire();
      }
      if ( new_mark )
        new_mark->debuffs.hunters_mark->trigger();
    } );

  progress_bar.progress();

  current_iteration = -1;
  analyze_number = 0;
}

bool sim_t::has_raid_event( util::string_view type ) const
{
  return range::any_of( raid_events, [ &type ]( const std::unique_ptr<raid_event_t>& event ) {
      return util::str_compare_ci( type, event -> type );
  } );
}

// Determine when the main thread must clean up child threads (i.e., delete them)
bool sim_t::requires_cleanup() const
{
  // .. if we are a profileset simulation
  if ( profileset_enabled )
  {
    return true;
  }

  // .. if we are simulating a scale factor calculation
  if ( scaling -> scale_stat != STAT_NONE )
  {
    return true;
  }

  // .. if we are simulating a reforge plot
  if ( ! reforge_plot -> reforge_plot_stat_str.empty() )
  {
    return true;
  }

  // .. or finally, clean up child threads based on the "cleanup_threads" option value
  return cleanup_threads;
}

void sim_t::heartbeat_event_callback()
{
  for( size_t i = 0; i < heartbeat_event_callback_function.size(); ++i )
    heartbeat_event_callback_function[ i ]( this );
}

void sim_t::register_heartbeat_event_callback( std::function<void( sim_t* )> fn )
{
  heartbeat_event_callback_function.emplace_back( std::move( fn ) );
}

void sim_t::register_target_data_initializer( std::function<void( actor_target_data_t* )> fn )
{
  target_data_initializer.emplace_back( std::move( fn ) );
}

void sim_t::register_actor_initializer( int priority, std::function<void( player_t* )> fn, std::string name )
{
  if ( priority == 0 )
    throw sc_initialization_error( fmt::format( "Actor initializer '{}' priority cannot be 0.", name ) );

  for ( const auto& e : actor_initializer )
  {
    std::string_view e_name = std::get<std::string>( e );
    int e_prio = std::get<int>( e );

    if ( !name.empty() && util::str_compare_ci( e_name, name ) )
    {
      // Don't register duplicate initializers
      if ( e_prio == priority )
        return;
      // Otherwise enforce name uniqueness
      else
        throw sc_initialization_error( fmt::format( "Actor initializer '{}' already exists.", name ) );
    }

    // Prevent priority clashes without names to resolve them
    if ( name.empty() && e_name.empty() && e_prio == priority )
      throw sc_initialization_error( fmt::format( "Actor initializer with priority {} already exists.", priority ) );
  }

  actor_initializer.emplace_back( priority, std::move( fn ), std::move( name ) );
}

void sim_t::register_actor_initializer( int priority, void ( player_t::*fn)(), std::string name )
{
  register_actor_initializer( priority, [ fn ]( player_t* p ) { std::invoke( fn, p ); }, std::move( name ) );
}

void sim_t::register_actor_initializer( std::string_view base, int offset, std::function<void( player_t* )> fn,
                                        std::string name )
{
  if ( base.empty() )
    throw sc_initialization_error( fmt::format( "Empty base for offset of actor initializer '{}'.", name ) );

  auto it = range::find_if( actor_initializer, [ base ]( const auto& e ) {
    return std::get<std::string>( e ) == base;
  } );

  if ( it == actor_initializer.end() )
    throw sc_initialization_error( fmt::format( "Actor initializer '{}' not found as base for '{}'.", base, name ) );

  register_actor_initializer( std::get<int>( *it ) + offset, std::move( fn ), std::move( name ) );
}

void sim_t::register_actor_initializer( std::string_view base, int offset, void ( player_t::*fn )(), std::string name )
{
  register_actor_initializer( base, offset, [ fn ]( player_t* p ) { std::invoke( fn, p ); }, std::move( name ) );
}


bool sim_t::rethrow_exception_queue()
{
  if ( !exception_queue.empty() )
  {
    AUTO_LOCK( exception_mutex );
    while ( !exception_queue.empty() )
    {
      auto e = exception_queue.back();
      exception_queue.pop_back();
      std::rethrow_exception( e );
    }

    return true;
  }

  return false;
}
