// ==========================================================================
// Dedmonwakeen's Raid DPS/TPS Simulator.
// Send questions to natehieter@gmail.com
// ==========================================================================

#include "unique_gear_thewarwithin.hpp"

#include "action/absorb.hpp"
#include "action/action.hpp"
#include "action/dot.hpp"
#include "actor_target_data.hpp"
#include "buff/buff.hpp"
#include "darkmoon_deck.hpp"
#include "dbc/data_enums.hh"
#include "dbc/item_database.hpp"
#include "dbc/spell_data.hpp"
#include "ground_aoe.hpp"
#include "item/item.hpp"
#include "player/action_variable.hpp"
#include "player/consumable.hpp"
#include "player/pet_spawner.hpp"
#include "set_bonus.hpp"
#include "sim/cooldown.hpp"
#include "sim/proc_rng.hpp"
#include "sim/sim.hpp"
#include "unique_gear.hpp"
#include "unique_gear_helper.hpp"
#include "util/string_view.hpp"

namespace unique_gear::thewarwithin
{
wowv_t version_min = { 11 };
wowv_t version_max = { UINT8_MAX };

void reset_version_check()
{ version_min = { 11 }; version_max = { UINT8_MAX }; }

void set_min_version( wowv_t build )
{ version_min = build; }

void set_max_version( wowv_t build )
{ version_max = build; }

// from item_naming.inc
enum gem_color_e : unsigned
{
  GEM_RUBY     = 14110,
  GEM_AMBER    = 14111,
  GEM_EMERALD  = 14113,
  GEM_SAPPHIRE = 14114,
  GEM_ONYX     = 14115
};

static constexpr unsigned __gem_colors[] = { GEM_RUBY, GEM_AMBER, GEM_EMERALD, GEM_SAPPHIRE, GEM_ONYX };
static constexpr util::span<const unsigned> gem_colors = util::make_span( __gem_colors );

namespace consumables
{
// Food
static constexpr unsigned food_coeff_spell_id = 456961;
using selector_fn = std::function<stat_e( const player_t*, util::span<const stat_e> )>;

struct selector_food_buff_t : public consumable_buff_t<stat_buff_t>
{

  double amount;
  bool highest;

  selector_food_buff_t( const special_effect_t& e, bool b )
    : consumable_buff_t( e.player, e.name(), e.driver() ), highest( b )
  {
    amount = e.stat_amount;
  }

  void start( int s, double v, timespan_t d ) override
  {
    auto stat = highest ? util::highest_stat( player, secondary_ratings )
                        : util::lowest_stat( player, secondary_ratings );

    if( !manual_stats_added )
      add_stat( stat, amount );

    consumable_buff_t::start( s, v, d );
  }
};

custom_cb_t selector_food( unsigned id, bool highest, bool major = true )
{
  return [ = ]( special_effect_t& effect ) {
    effect.spell_id = id;

    auto coeff = effect.player->find_spell( food_coeff_spell_id );

    effect.stat_amount = coeff->effectN( 4 ).average( effect );
    if ( !major )
      effect.stat_amount *= coeff->effectN( 1 ).base_value() * 0.1;

    effect.custom_buff = new selector_food_buff_t( effect, highest );
  };
}

custom_cb_t primary_food( unsigned id, stat_e stat, size_t primary_idx = 3, bool major = true )
{
  return [ = ]( special_effect_t& effect ) {
    effect.spell_id = id;

    auto coeff = effect.player->find_spell( food_coeff_spell_id );

    auto buff = create_buff<consumable_buff_t<stat_buff_t>>( effect.player, effect.driver() );

    if ( primary_idx )
    {
      auto _amt = coeff->effectN( primary_idx ).average( effect );
      if ( !major )
        _amt *= coeff->effectN( 1 ).base_value() * 0.1;

      buff->add_stat( effect.player->convert_hybrid_stat( stat ), _amt );
    }

    if ( primary_idx == 3 )
    {
      auto _amt = coeff->effectN( 8 ).average( effect );
      if ( !major )
        _amt *= coeff->effectN( 1 ).base_value() * 0.1;

      buff->add_stat( STAT_STAMINA, _amt );
    }

    effect.custom_buff = buff;
  };
}

custom_cb_t secondary_food( unsigned id, stat_e stat1, stat_e stat2 = STAT_NONE )
{
  return [ = ]( special_effect_t& effect ) {
    effect.spell_id = id;

    auto coeff = effect.player->find_spell( food_coeff_spell_id );

    auto buff = create_buff<consumable_buff_t<stat_buff_t>>( effect.player, effect.driver() );

    // all single secondary stat food are minor foods. note that item tooltip for hearty versions are incorrect and do
    // not apply the minor food multiplier.
    if ( stat2 == STAT_NONE )
    {
      auto _amt = coeff->effectN( 4 ).average( effect ) * coeff->effectN( 1 ).base_value() * 0.1;
      buff->add_stat( stat1, _amt );
    }
    else
    {
      auto _amt = coeff->effectN( 5 ).average( effect );
      buff->add_stat( stat1, _amt );
      buff->add_stat( stat2, _amt );
    }

    effect.custom_buff = buff;
  };
}

// Flasks
// TODO: can you randomize into the same stat? same bonus stat? same penalty stats?
void flask_of_alchemical_chaos( special_effect_t& effect )
{
  if ( unique_gear::create_fallback_buffs( effect, { "flask_of_alchemical_chaos_vers", "flask_of_alchemical_chaos_mastery",
                                        "flask_of_alchemical_chaos_haste", "flask_of_alchemical_chaos_crit" } ) )
  {
    return;
  }

  struct flask_of_alchemical_chaos_buff_t : public consumable_buff_t<buff_t>
  {
    std::vector<std::pair<buff_t*, buff_t*>> buff_list;
    std::unordered_map<stat_e, std::pair<buff_t*, buff_t*>> stat_map;

    flask_of_alchemical_chaos_buff_t( const special_effect_t& e ) : consumable_buff_t( e.player, e.name(), e.driver() )
    {
      auto bonus = e.driver()->effectN( 5 ).average( e );
      auto penalty = -( e.driver()->effectN( 6 ).average( e ) );

      auto add_vers = create_buff<stat_buff_t>( e.player, "flask_of_alchemical_chaos_vers", e.driver() )
                          ->add_stat( STAT_VERSATILITY_RATING, bonus )
                          ->set_name_reporting( "Vers" )
                          ->set_constant_behavior( buff_constant_behavior::NEVER_CONSTANT );
      auto add_mastery = create_buff<stat_buff_t>( e.player, "flask_of_alchemical_chaos_mastery", e.driver() )
                             ->add_stat( STAT_MASTERY_RATING, bonus )
                             ->set_name_reporting( "Mastery" )
                             ->set_constant_behavior( buff_constant_behavior::NEVER_CONSTANT );
      auto add_haste = create_buff<stat_buff_t>( e.player, "flask_of_alchemical_chaos_haste", e.driver() )
                           ->add_stat( STAT_HASTE_RATING, bonus )
                           ->set_name_reporting( "Haste" )
                           ->set_constant_behavior( buff_constant_behavior::NEVER_CONSTANT );
      auto add_crit = create_buff<stat_buff_t>( e.player, "flask_of_alchemical_chaos_crit", e.driver() )
                          ->add_stat( STAT_CRIT_RATING, bonus )
                          ->set_name_reporting( "Crit" )
                          ->set_constant_behavior( buff_constant_behavior::NEVER_CONSTANT );

      auto sub_vers = create_buff<stat_buff_t>( e.player, "alchemical_chaos_vers_penalty", e.driver() )
        ->add_stat( STAT_VERSATILITY_RATING, penalty )->set_quiet( true );
      auto sub_mastery = create_buff<stat_buff_t>( e.player, "alchemical_chaos_mastery_penalty", e.driver() )
        ->add_stat( STAT_MASTERY_RATING, penalty )->set_quiet( true );
      auto sub_haste = create_buff<stat_buff_t>( e.player, "alchemical_chaos_haste_penalty", e.driver() )
        ->add_stat( STAT_HASTE_RATING, penalty )->set_quiet( true );
      auto sub_crit = create_buff<stat_buff_t>( e.player, "alchemical_chaos_crit_penalty", e.driver() )
        ->add_stat( STAT_CRIT_RATING, penalty )->set_quiet( true );

      buff_list.emplace_back( add_vers, sub_vers );
      buff_list.emplace_back( add_mastery, sub_mastery );
      buff_list.emplace_back( add_haste, sub_haste );
      buff_list.emplace_back( add_crit, sub_crit );

      stat_map[ STAT_VERSATILITY_RATING ] = std::make_pair( add_vers, sub_vers );
      stat_map[ STAT_MASTERY_RATING ]     = std::make_pair( add_mastery, sub_mastery );
      stat_map[ STAT_HASTE_RATING ]       = std::make_pair( add_haste, sub_haste );
      stat_map[ STAT_CRIT_RATING ]        = std::make_pair( add_crit, sub_crit );

      std::string opt_initial_stat = source->thewarwithin_opts.alchemical_initial_stat;
      stat_e initial_stat          = STAT_NONE;

      if ( util::str_compare_ci( opt_initial_stat, "versatility" ) || util::str_compare_ci( opt_initial_stat, "vers" ) )
        initial_stat = STAT_VERSATILITY_RATING;
      else if ( util::str_compare_ci( opt_initial_stat, "mastery" ) )
        initial_stat = STAT_MASTERY_RATING;
      else if ( util::str_compare_ci( opt_initial_stat, "haste" ) )
        initial_stat = STAT_HASTE_RATING;
      else if ( util::str_compare_ci( opt_initial_stat, "critical_strike" ) ||
                util::str_compare_ci( opt_initial_stat, "crit" ) )
        initial_stat = STAT_CRIT_RATING;

      std::string opt_initial_penalty = source->thewarwithin_opts.alchemical_initial_penalty;
      stat_e initial_penalty_1        = STAT_NONE;
      stat_e initial_penalty_2        = STAT_NONE;

      auto splits = util::string_split<std::string_view>( opt_initial_penalty, "/" );
      for ( auto s : splits )
      {
        if ( util::str_compare_ci( s, "vers" ) || util::str_compare_ci( s, "versatility" ) )
        {
          if ( initial_penalty_1 == STAT_NONE )
            initial_penalty_1 = STAT_VERSATILITY_RATING;
          else if ( initial_penalty_2 == STAT_NONE )
            initial_penalty_2 = STAT_VERSATILITY_RATING;
        }
        else if ( util::str_compare_ci( s, "mastery" ) )
        {
          if ( initial_penalty_1 == STAT_NONE )
            initial_penalty_1 = STAT_MASTERY_RATING;
          else if ( initial_penalty_2 == STAT_NONE )
            initial_penalty_2 = STAT_MASTERY_RATING;
        }
        else if ( util::str_compare_ci( s, "haste" ) )
        {
          if ( initial_penalty_1 == STAT_NONE )
            initial_penalty_1 = STAT_HASTE_RATING;
          else if ( initial_penalty_2 == STAT_NONE )
            initial_penalty_2 = STAT_HASTE_RATING;
        }
        else if ( util::str_compare_ci( s, "crit" ) || util::str_compare_ci( s, "critical_strike" ) )
        {
          if ( initial_penalty_1 == STAT_NONE )
            initial_penalty_1 = STAT_CRIT_RATING;
          else if ( initial_penalty_2 == STAT_NONE )
            initial_penalty_2 = STAT_CRIT_RATING;
        }

        if( initial_stat == initial_penalty_1 )
          initial_penalty_1 = STAT_NONE;  // don't allow the bonus stat to be a penalty
        if ( initial_stat == initial_penalty_2 )
          initial_penalty_2 = STAT_NONE;  // don't allow the bonus stat to be a penalty
      }
        
      set_tick_callback( [ this, initial_stat, initial_penalty_1, initial_penalty_2 ]( buff_t* b, int, timespan_t ) {
        rng().shuffle( buff_list.begin(), buff_list.end() );
        if ( b->current_tick == 0 && initial_stat != STAT_NONE )
        {
          stat_map[ initial_stat ].first->trigger();

          auto it = std::find( buff_list.begin(), buff_list.end(), stat_map[ initial_stat ] );
          std::rotate( buff_list.begin(), it, std::next( it ) );

          if ( initial_penalty_1 == STAT_NONE && initial_penalty_2 == STAT_NONE )
          {
            buff_list[ 1 ].second->trigger();
            buff_list[ 2 ].second->trigger();
            return;
          }

          if ( initial_penalty_1 != STAT_NONE )
            stat_map[ initial_penalty_1 ].second->trigger();

          if ( initial_penalty_2 != STAT_NONE && initial_penalty_1 != initial_penalty_2 )
            stat_map[ initial_penalty_2 ].second->trigger();
          else
          {
            for ( auto& pair : buff_list )
            {
              if ( pair.first->check() || pair.second->check() )
                continue;
              pair.second->trigger();
              break;
            }
          }
        }
        else
        {
          buff_list[ 0 ].first->trigger();  // bonus
          buff_list[ 0 ].second->expire();
          buff_list[ 1 ].first->expire();
          buff_list[ 1 ].second->trigger();  // penalty
          buff_list[ 2 ].first->expire();
          buff_list[ 2 ].second->trigger();  // penalty
          buff_list[ 3 ].first->expire();
          buff_list[ 3 ].second->expire();
        }
      } );
    }

    timespan_t tick_time() const override
    {
      if ( current_tick == 0 )
        return sim->rng().range( 1_ms, buff_period );
      else
        return buff_period;
    }
  };

  effect.custom_buff = new flask_of_alchemical_chaos_buff_t( effect );
}

// Potions
void tempered_potion( special_effect_t& effect )
{
  auto tempered_stat = STAT_NONE;

  if ( auto _flask = dynamic_cast<dbc_consumable_base_t*>( effect.player->find_action( "flask" ) ) )
    if ( auto _buff = _flask->consumable_buff; _buff && util::starts_with( _buff->name_str, "flask_of_tempered_" ) )
      tempered_stat = static_cast<stat_buff_t*>( _buff )->stats.front().stat;

  auto buff = create_buff<stat_buff_t>( effect.player, effect.driver() );
  auto amount = effect.driver()->effectN( 1 ).average( effect );

  for ( auto s : secondary_ratings )
    if ( s != tempered_stat )
      buff->add_stat( s, amount );

  effect.custom_buff = buff;
}

void potion_of_unwavering_focus( special_effect_t& effect )
{
  struct unwavering_focus_t : public generic_proc_t
  {
    double mul;

    unwavering_focus_t( const special_effect_t& e ) : generic_proc_t( e, e.name(), e.driver() )
    {
      target_debuff = e.driver();

      auto rank = e.item->parsed.data.crafting_quality;
      auto base = e.driver()->effectN( 2 ).base_value();

      mul = ( base + rank - 1 ) * 0.01;
    }

    buff_t* create_debuff( player_t* t ) override
    {
      auto debuff = generic_proc_t::create_debuff( t )
        ->set_default_value( mul )
        ->set_cooldown( 0_ms );

      player->get_target_data( t )->debuff.unwavering_focus = debuff;

      return debuff;
    }

    void impact( action_state_t* s ) override
    {
      generic_proc_t::impact( s );

      get_debuff( s->target )->trigger();
    }
  };

  effect.execute_action = create_proc_action<unwavering_focus_t>( "potion_of_unwavering_focus", effect );
}

// Oils
void oil_of_deep_toxins( special_effect_t& effect )
{
  effect.discharge_amount = effect.driver()->effectN( 1 ).average( effect );

  new dbc_proc_callback_t( effect.player, effect );
}

// Bubbling Wax
void bubbling_wax( special_effect_t& effect )
{
  // This is Rogue Only.
  if ( effect.player->type != ROGUE )
    return;

  // TODO: See if check later if RPPM increases while wearing two. Appears currently not?
  // Currently, this only works if you use the wax on your Main Hand and the offhand does not function.
  // Remove this if they fix it being Main Hand Only, and see below comment what to do incase of RPPM increase instead
  // of damage.
  if ( effect.item->slot != SLOT_MAIN_HAND && effect.player->bugs )
    return;

  auto wax_action = effect.player->find_action( "bubbling_wax" );

  auto damage_amount = effect.driver()->effectN( 1 ).average( effect );

  if ( !wax_action )
  {
    auto damage_id      = effect.driver()->effectN( 1 ).trigger_spell_id();
    auto damage         = create_proc_action<generic_aoe_proc_t>( "bubbling_wax", effect, damage_id, true );
    damage->base_dd_min = damage->base_dd_max = damage_amount;
    effect.execute_action                     = damage;
    new dbc_proc_callback_t( effect.player, effect );
  }
  else
  {
    // This would increase the damage if you had two, but due to the slot main_hand check above this will never occur
    // unless bugs=0 is set.
    // If this is ever fixed and RPPM increases with two instead, remove the if() else() block and initialise two procs,
    // one for each hand using the main code from the above if.
    wax_action->base_dd_min += damage_amount;
    wax_action->base_dd_max += damage_amount;
  }
}
}  // namespace consumables

namespace enchants
{
void authority_of_radiant_power( special_effect_t& effect )
{
  auto found = effect.player->find_action( "authority_of_radiant_power" );

  auto damage = create_proc_action<generic_proc_t>( "authority_of_radiant_power", effect, 448744 );
  auto damage_val = effect.driver()->effectN( 1 ).average( effect );
  damage->base_dd_min += damage_val;
  damage->base_dd_max += damage_val;

  auto stat_val = effect.driver()->effectN( 2 ).average( effect );
  stat_val *= attuned_mul( effect.player, effect.driver() );

  auto buff = create_buff<stat_buff_t>( effect.player, effect.player->find_spell( 448730 ) )
    ->add_stat_from_effect_type( A_MOD_STAT, stat_val );

  if ( found )
    return;

  damage->base_multiplier *= role_mult( effect.player, effect.player->find_spell( 445339 ) );
  damage->base_multiplier *= attuned_mul( effect.player, effect.driver() );

  effect.spell_id = effect.trigger()->id();  // rppm driver is the effect trigger

  effect.player->callbacks.register_callback_execute_function(
    effect.spell_id, [ buff, damage ]( auto, auto, player_t* t, auto ) {
      damage->execute_on_target( t );
      buff->trigger();
    } );

  new dbc_proc_callback_t( effect.player, effect );
}

// TODO: confirm coeff is per tick and not for entire dot
void authority_of_the_depths( special_effect_t& effect )
{
  auto found = effect.player->find_action( "suffocating_darkness" );

  auto damage = create_proc_action<generic_proc_t>( "suffocating_darkness", effect, 449217 );
  damage->base_td += effect.driver()->effectN( 1 ).average( effect );

  if ( found )
    return;

  damage->base_multiplier *= role_mult( effect.player, effect.player->find_spell( 445341 ) );
  damage->base_multiplier *= attuned_mul( effect.player, effect.driver() );

  effect.spell_id = effect.trigger()->id();  // rppm driver is the effect trigger

  effect.execute_action = damage;

  new dbc_proc_callback_t( effect.player, effect );
}

void authority_of_storms( special_effect_t& effect )
{
  // has data to suggest proc is supposed to be (or once was) a 12s buff that triggers damage at 6rppm, but currently in
  // game is a simple damage proc.

  auto found = effect.player->find_action( "authority_of_storms" ) ;

  auto damage_id = as<unsigned>( effect.trigger()->effectN( 1 ).misc_value1() );
  auto damage = create_proc_action<generic_aoe_proc_t>( "authority_of_storms", effect, damage_id );
  damage->base_dd_min += effect.driver()->effectN( 1 ).average( effect );
  damage->base_dd_max += effect.driver()->effectN( 1 ).average( effect );

  if ( found )
    return;

  damage->base_multiplier *= role_mult( effect.player, effect.player->find_spell( 445336 ) );
  damage->base_multiplier *= attuned_mul( effect.player, effect.driver() );

  effect.spell_id = effect.trigger()->id();  // rppm driver is the effect trigger

  effect.execute_action = damage;

  new dbc_proc_callback_t( effect.player, effect );
}

void secondary_weapon_enchant( special_effect_t& effect )
{
  auto buff_data = effect.trigger()->effectN( 1 ).trigger();
  auto buff_name = util::tokenize_fn( buff_data->name_cstr() );

  auto found = buff_t::find( effect.player, buff_name );

  auto stat_val = effect.driver()->effectN( 1 ).average( effect );
  stat_val *= attuned_mul( effect.player, effect.driver() );

  auto buff = create_buff<stat_buff_t>( effect.player, buff_name, buff_data )
    ->add_stat_from_effect_type( A_MOD_RATING, stat_val );

  if ( found )
    return;

  effect.spell_id = effect.trigger()->id();  // rppm driver is the effect trigger

  effect.custom_buff = buff;

  new dbc_proc_callback_t( effect.player, effect );
}

// 435500 driver
void culminating_blasphemite( special_effect_t& effect )
{
  auto pct = effect.driver()->effectN( 1 ).percent() * unique_gem_list( effect.player, gem_colors ).size();
  // check for prismatic null stone
  if ( auto null_stone = find_special_effect( effect.player, 435992 ) )
    pct *= 1.0 + null_stone->driver()->effectN( 1 ).percent();

  for ( school_e school = SCHOOL_NONE; school < SCHOOL_MAX_PRIMARY; school++ )
    effect.player->base.crit_damage_multiplier[ school ] *= 1.0 + pct;

  effect.player->base.crit_healing_multiplier *= 1.0 + pct;
}

// 435488 driver
void insightful_blasphemite( special_effect_t& effect )
{
  auto pct = effect.driver()->effectN( 1 ).percent() * unique_gem_list( effect.player, gem_colors ).size();
  // check for prismatic null stone
  if ( auto null_stone = find_special_effect( effect.player, 435992 ) )
    pct *= 1.0 + null_stone->driver()->effectN( 1 ).percent();

  effect.player->resources.base_multiplier[ RESOURCE_MANA ] *= 1.0 + pct;
}

void daybreak_spellthread( special_effect_t& effect )
{
  effect.player->resources.base_multiplier[ RESOURCE_MANA ] *= 1.0 + effect.driver()->effectN( 1 ).percent();
}

// Rune of Twilight Devastation
// 1225038 Driver
// 1225040 Damage
// 1225042 Value Spell/Default Driver - Lesser
// 1225045 Value Spell/Default Driver - Greater
// 1225074 Role Mult Spell - Lesser
// 1233223 Role Mult Spell - Greater
void twilight_devastation( special_effect_t& effect )
{
  struct twilight_devastation_t : public generic_proc_t
  {
    double current_mult;
    twilight_devastation_t( const special_effect_t& e )
      : generic_proc_t( e, "twilight_devastation", e.player->find_spell( 1225040 ) ), current_mult( 1.0 )
    {
      base_dd_min = base_dd_max = e.driver()->effectN( 1 ).average( e.player );
      base_multiplier *= role_mult( e.player, e.player->find_spell( 1233223 ) );
      aoe = 10;
    }

    double composite_aoe_multiplier( const action_state_t* s ) const override
    {
      double m = generic_proc_t::composite_aoe_multiplier( s );

      if ( s->chain_target > 0 )
        m *= pow( 0.65, s->chain_target );

      return m;
    }
  };

  auto damage = create_proc_action<twilight_devastation_t>( "twilight_devastation", effect );

  effect.execute_action = damage;
  effect.spell_id       = effect.player->find_spell( 1225038 )->id();
  new dbc_proc_callback_t( effect.player, effect );
}

// Rune of the Echoing Void
// 1225883 Driver
// 1225889 Damage
// 1225886 Stacking Buff
// 1225887 Periodic Buff
// 1225878 Value Spell/Default Driver - Lesser
// 1225880 Value Spell/Default Driver - Greater
// 1233355 Role Mult Spell - Lesser
// 1225873 Role Mult Spell - Greater
// TODO: Check the chance to trigger void collapse is correct.
void echoing_void( special_effect_t& effect )
{
  auto damage = create_proc_action<generic_aoe_proc_t>( "echoing_void_corruption", effect, 1225889, true );
  damage->name_str_reporting = "Corruption";
  damage->base_dd_min = damage->base_dd_max = effect.driver()->effectN( 1 ).average( effect.player );
  // Using the Greater version for the ID here, but, they should be the same.
  damage->base_multiplier *= role_mult( effect.player, effect.player->find_spell( 1233355 ) );

  auto new_driver = effect.player->find_spell( 1225883 );

  auto stacking_buff =
      create_buff<buff_t>( effect.player, "echoing_void_stacking", effect.player->find_spell( 1225886 ) );
  stacking_buff->name_str_reporting = "Stacking";
  auto ticking_buff =
      create_buff<buff_t>( effect.player, "echoing_void_ticking", effect.player->find_spell( 1225887 ) );
  ticking_buff->name_str_reporting = "Ticking";

  stacking_buff->set_stack_change_callback( [ effect, ticking_buff, new_driver ]( buff_t* b, int old_, int new_ ) {
    if ( new_ > old_ )
    {
      // Might not be correct, not seeing the % chance to trigger in the spell data, but seems to increase in chance the
      // more stacks you have.
      if ( effect.player->rng().roll( new_driver->effectN( 2 ).percent() * b->check() ) )
        ticking_buff->trigger( b->check() * 1_s );
    }
  } );

  ticking_buff->set_tick_callback( [ stacking_buff, damage ]( buff_t* b, int, timespan_t ) {
    stacking_buff->decrement();
    if ( b->source->base.distance <= 15 )
      damage->execute();
  } );

  effect.custom_buff = stacking_buff;
  effect.spell_id    = new_driver->id();

  effect.player->callbacks.register_callback_trigger_function(
      new_driver->id(), dbc_proc_callback_t::trigger_fn_type::CONDITION,
      [ ticking_buff ]( auto, const auto&, auto, auto, auto ) {
        return !ticking_buff->up();
      } );

  new dbc_proc_callback_t( effect.player, effect );
}

// Rune of the Twisted Appendage
// 1227300 Driver
// 1227303 Damage
// 1227301 Summon Spell
// 1227295 Value Spell/Default Driver - Lesser
// 1227297 Value Spell/Default Driver - Greater
// 1233392 Role Mult Spell - Lesser
// 1227294 Role Mult Spell - Greater
// TODO: Implement slow effect on enemy targeted by mind flay if it ever matters for sims.
void twisted_appendage( special_effect_t& effect )
{
  struct mind_flay_t : public spell_t
  {
    mind_flay_t( std::string_view n, pet_t* p, const spell_data_t* s, std::string_view options_str, action_t* a,
                 int driver_id )
      : spell_t( n, p, s )
    {
      base_td = p->find_spell( driver_id )->effectN( 1 ).average( p->owner );
      base_td_multiplier *= role_mult( p->owner, p->owner->find_spell( 1233392 ) );
      name_str_reporting = "mind_flay";

      channeled = true;

      auto proxy = a;
      auto it    = range::find( proxy->child_action, data().id(), &action_t::id );
      if ( it != proxy->child_action.end() )
        stats = ( *it )->stats;
      else
        proxy->add_child( this );

      parse_options( options_str );
    }
  };

  struct twisted_appendage_pet_t : unique_gear_pet_t
  {
    int driver_id;
    twisted_appendage_pet_t( const special_effect_t& e, int og_driver = 0, action_t* parent = nullptr )
      : unique_gear_pet_t( "twisted_appendage", e, &parent->data() ), driver_id( og_driver )
    {
      parent_action       = parent;
      use_auto_attack     = false;
      base.movement_speed = 0.0;
    }

    void init_action_list() override
    {
      unique_gear_pet_t::init_action_list();

      // Default "auto-pilot" pet APL (if everything is left on auto-cast)
      action_priority_list_t* def = get_action_priority_list( "default" );
      def->add_action( "mind_flay" );
    }

    action_t* create_action( std::string_view name, std::string_view options_str ) override
    {
      if ( name == "mind_flay" )
        return new mind_flay_t( name, this, find_spell( 1227303 ), options_str, parent_action, driver_id );

      return unique_gear_pet_t::create_action( name, options_str );
    }
  };

  struct twisted_appendage_cb_t : public dbc_proc_callback_t
  {
    spawner::pet_spawner_t<twisted_appendage_pet_t> appendage_spawner;

    twisted_appendage_cb_t( const special_effect_t& e, const int original_id )
      : dbc_proc_callback_t( e.player, e ), appendage_spawner( "twisted_appendage", e.player )
    {
      auto summon_spell = e.player->find_spell( 1227301 );
      auto appendage    = new action_t( action_e::ACTION_OTHER, "twisted_appendage", e.player, summon_spell );

      appendage_spawner.set_creation_callback( [ &e, original_id, appendage ]( player_t* ) {
        return new twisted_appendage_pet_t( e, original_id, appendage );
      } );
      appendage_spawner.set_default_duration( summon_spell->duration() );
    }

    void execute( const spell_data_t*, player_t*, action_state_t* ) override
    {
      appendage_spawner.spawn();
    }
  };

  int original_driver_id = effect.spell_id;
  effect.spell_id        = 1227300;
  new twisted_appendage_cb_t( effect, original_driver_id );
}

// Rune of the Void Ritual
// 1227315 Driver
// 1227316 Buff
// 1227312 Value Spell/Default Driver - Lesser
// 1227314 Value Spell/Default Driver - Greater
// TODO: Check if this still adheres to the increased chance if at least 2 players are wearing it.
void void_ritual( special_effect_t& effect )
{
  auto buff = create_buff<stat_buff_t>( effect.player, "the_end_is_coming", effect.player->find_spell( 1227316 ) )
                  ->add_stat_from_effect_type( A_MOD_RATING, effect.driver()->effectN( 1 ).average( effect.player ) )
                  ->set_refresh_behavior( buff_refresh_behavior::DISABLED );

  effect.custom_buff = buff;
  effect.spell_id    = effect.player->find_spell( 1227315 )->id();

  effect.player->callbacks.register_callback_trigger_function(
      effect.spell_id, dbc_proc_callback_t::trigger_fn_type::CONDITION,
      [ buff ]( auto, const auto&, auto, auto, auto ) { return !buff->up(); } );

  new dbc_proc_callback_t( effect.player, effect );
}

// Rune of the Gushing Wound
// 1227292 Driver
// 1227293 Damage
// 1227289 Value Spell/Default Driver - Lesser
// 1227291 Value Spell/Default Driver - Greater
// 1233385 Role Mult Spell - Lesser
// 1227288 Role Mult Spell - Greater
void gushing_wound( special_effect_t& effect )
{
  auto damage     = create_proc_action<generic_proc_t>( "gushing_wound", effect, 1227293 );
  damage->base_td = effect.driver()->effectN( 1 ).average( effect.player );
  // Using the Greater version for the ID here, but, they should be the same.
  damage->base_td_multiplier *= role_mult( effect.player, effect.player->find_spell( 1227288 ) );

  effect.execute_action = damage;
  effect.spell_id       = effect.player->find_spell( 1227292 )->id();

  new dbc_proc_callback_t( effect.player, effect );
}

// Rune of Infinite Stars
// 1227215 Driver
// 1227218 Damage/Debuff
// 1227216 Missile?
// 1227210 Value Spell/Default Driver - Lesser
// 1227211 Value Spell/Default Driver - Greater
// 1233375 Role Mult Spell - Lesser
// 1227206 Role Mult Spell - Greater
void infinite_stars( special_effect_t& effect )
{
  struct infinite_stars_t : public generic_proc_t
  {
    double bonus_damage;

    infinite_stars_t( const special_effect_t& e )
      : generic_proc_t( e, "infinite_stars", e.player->find_spell( 1227218 ) ), bonus_damage( 0 )
    {
      base_dd_min = base_dd_max = e.driver()->effectN( 1 ).average( e.player );
      base_multiplier *= role_mult( e.player, e.player->find_spell( 1227206 ) );

      bonus_damage  = e.driver()->effectN( 2 ).average( e.player );
      target_debuff = &data();
    }

    double bonus_da( const action_state_t* s ) const override
    {
      double b = generic_proc_t::bonus_da( s );

      auto debuff = find_debuff( s->target );
      if ( debuff )
        b += debuff->check() * bonus_damage;

      return b;
    }

    void impact( action_state_t* s ) override
    {
      generic_proc_t::impact( s );
      auto debuff = get_debuff( s->target );

      if ( debuff->at_max_stacks() )
        debuff->expire();
      else
        debuff->trigger();
    }
  };

  effect.execute_action = create_proc_action<infinite_stars_t>( "infinite_stars", effect );
  effect.spell_id       = effect.player->find_spell( 1227215 )->id();
  new dbc_proc_callback_t( effect.player, effect );
}

}  // namespace enchants

namespace embellishments
{
// 443743 driver, trigger buff
// 447005 buff
void blessed_weapon_grip( special_effect_t& effect )
{
  std::unordered_map<stat_e, buff_t*> buffs;

  create_all_stat_buffs( effect, effect.trigger(), effect.trigger()->effectN( 6 ).average( effect ),
    [ &buffs ]( stat_e s, buff_t* b ) { buffs[ s ] = b->set_reverse( true ); } );

  effect.player->callbacks.register_callback_execute_function(
    effect.spell_id, [ buffs ]( const dbc_proc_callback_t* cb, auto, auto, auto ) {
      auto stat = util::highest_stat( cb->listener, secondary_ratings );
      for ( auto [ s, b ] : buffs )
      {
        if ( s == stat )
          b->trigger();
        else
          b->expire();
      }
    } );

  new dbc_proc_callback_t( effect.player, effect );
}

// 453503 equip, trigger driver
//  e1: damage coeff?
// 453508 driver, trigger missile
//  e1: damage coeff?
// 453510 missile, trigger damage
// 453782 damage
// TODO: determine which coeff is the correct one. assuming driver is correct.
// TODO: confirm damage doesn't increase per extra target
void pouch_of_pocket_grenades( special_effect_t& effect )
{
  auto driver = effect.trigger();
  auto missile = driver->effectN( 1 ).trigger();
  auto damage = missile->effectN( 1 ).trigger();
  // TODO: determine which coeff is the correct one. assuming driver is correct.
  auto amount = driver->effectN( 1 ).average( effect );
  auto multiplier = role_mult( effect );

  effect.spell_id = driver->id();

  auto found = effect.player->find_action( "pocket_grenade" );

  // TODO: confirm damage doesn't increase per extra target
  auto grenade = create_proc_action<generic_aoe_proc_t>( "pocket_grenade", effect, damage );
  grenade->base_dd_min += amount;
  grenade->base_dd_max += amount;
  // We cannot use `*=`, as two copies of the embellishment would doubly apply role mult.
  grenade->base_multiplier = multiplier;

  if ( found )
    return;

  grenade->travel_speed = missile->missile_speed();

  effect.execute_action = grenade;

  new dbc_proc_callback_t( effect.player, effect );
}

// 461177 equip
//  e1: coeff, trigger driver
// 461180 driver
// 461185 holy damage from amber
// 461190 nature damage from emerald
// 461191 shadow damage from onyx
// 461192 fire damage from ruby
// 461193 frost damage from sapphire
void elemental_focusing_lens( special_effect_t& effect )
{
  auto gems = unique_gem_list( effect.player, gem_colors );

  if ( !gems.size() )
    return;

  auto amount = effect.driver()->effectN( 1 ).average( effect );
  auto multiplier = role_mult( effect );

  effect.spell_id = effect.trigger()->id();

  // guard against duplicate proxy/callback from multiple embellishments
  auto proxy = effect.player->find_action( "elemental_focusing_lens" );
  if ( !proxy )
  {
    proxy = new action_t( action_e::ACTION_OTHER, "elemental_focusing_lens", effect.player, effect.driver() );
    new dbc_proc_callback_t( effect.player, effect );
  }

  std::vector<action_t*> damages;

  static constexpr std::array<std::tuple<gem_color_e, unsigned, const char*>, 5> damage_ids = { {
    { GEM_RUBY,     461192, "ruby"     },
    { GEM_AMBER,    461185, "amber"    },
    { GEM_EMERALD,  461190, "emerald"  },
    { GEM_SAPPHIRE, 461193, "sapphire" },
    { GEM_ONYX,     461191, "onyx"     }
  } };

  for ( auto [ g, id, name ] : damage_ids )
  {
    if ( !range::contains( gems, static_cast<unsigned>( g ) ) )
      continue;

    auto dam = create_proc_action<generic_proc_t>( fmt::format( "elemental_focusing_lens_{}", name ), effect, id );
    dam->base_dd_min += amount;
    dam->base_dd_max += amount;
    // We cannot use `*=`, as two copies of the embellishment would doubly apply role mult.
    dam->base_multiplier = multiplier;
    dam->name_str_reporting = util::inverse_tokenize( name );
    damages.push_back( dam );
    proxy->add_child( dam );
  }

  effect.player->callbacks.register_callback_execute_function(
    effect.spell_id, [ damages ]( const dbc_proc_callback_t* cb, auto, player_t* t, auto ) {
      cb->rng().range( damages )->execute_on_target( t );
    } );
}

// 436085 on use
// 436132 Binding of Binding Driver
// 436159 Boon of Binding Buff
void binding_of_binding( special_effect_t& effect )
{
  struct binding_of_binding_cb_t : public dbc_proc_callback_t
   {
     target_specific_t<buff_t> buffs;
     double binding_of_binding_ally_trigger_chance;
     binding_of_binding_cb_t( const special_effect_t& e )
       : dbc_proc_callback_t( e.player, e ),
         buffs{ false },
         binding_of_binding_ally_trigger_chance( effect.player->thewarwithin_opts.binding_of_binding_ally_trigger_chance )
     {
       get_buff( effect.player );
     }

     buff_t* get_buff( player_t* buff_player )
     {
       if ( buffs[ buff_player ] )
         return buffs[ buff_player ];

       auto gems = unique_gem_list( buff_player, gem_colors );

       auto buff_spell = effect.player->find_spell( 436159 );

       auto buff = make_buff<stat_buff_t>( actor_pair_t{ buff_player, effect.player }, "boon_of_binding", buff_spell );

       for ( auto gem_color : gems )
       {
         switch ( static_cast<gem_color_e>( gem_color ) )
         {
           case GEM_RUBY:
             buff->add_stat_from_effect( 2, effect.driver()->effectN( 1 ).average( effect.player ) / 4 );
             break;
           case GEM_EMERALD:
             buff->add_stat_from_effect( 3, effect.driver()->effectN( 1 ).average( effect.player ) / 4 );
             break;
           case GEM_SAPPHIRE:
             buff->add_stat_from_effect( 4, effect.driver()->effectN( 1 ).average( effect.player ) / 4 );
             break;
           case GEM_ONYX:
             buff->add_stat_from_effect( 5, effect.driver()->effectN( 1 ).average( effect.player ) / 4 );
             break;
           default:
             break;
         }
       }

       buffs[ buff_player ] = buff;

       return buff;
     }

     void execute( const spell_data_t*, player_t*, action_state_t* ) override
     {
       if ( effect.player->thewarwithin_opts.binding_of_binding_on_you > 0 )
       {
         buffs[ effect.player ]->trigger();
       }
       else
       {
         if ( !effect.player->sim->single_actor_batch && effect.player->sim->player_non_sleeping_list.size() > 1 )
         {
           std::vector<player_t*> helper_vector = effect.player->sim->player_non_sleeping_list.data();
           rng().shuffle( helper_vector.begin(), helper_vector.end() );

           for ( auto p : helper_vector )
           {
             if ( p == effect.player || p->is_pet() )
               continue;

             if ( rng().roll( binding_of_binding_ally_trigger_chance ) )
               get_buff( p )->trigger();

             break;
           }
         }
       }
     }
   };

   new binding_of_binding_cb_t( effect );
}

// 457665 dawnthread driver
// 457666 dawnthread buff
// 457677 duskthread driver
// 457674 duskthread buff
void dawn_dusk_thread_lining( special_effect_t& effect )
{
  struct dawn_dusk_thread_lining_t : public stat_buff_t
  {
    rng::truncated_gauss_t interval;

    dawn_dusk_thread_lining_t( player_t* p, std::string_view n, const spell_data_t* s )
      : stat_buff_t( p, n, s ),
        interval( p->thewarwithin_opts.dawn_dusk_thread_lining_update_interval,
                  p->thewarwithin_opts.dawn_dusk_thread_lining_update_interval_stddev )
    {
    }
  };

  const spell_data_t* buff_spell = effect.player->find_spell( 457674 );

  if( effect.spell_id == 457665 )
    buff_spell = effect.player->find_spell( 457666 );

  auto buff = create_buff<dawn_dusk_thread_lining_t>( effect.player, buff_spell );
  buff->set_constant_behavior( buff_constant_behavior::NEVER_CONSTANT );
  bool first = !buff->manual_stats_added;
  // In some cases, the buff values from separate items don't stack. This seems to fix itself
  // when the player loses and regains the buff, so we just assume they stack properly.
  buff->add_stat_from_effect_type( A_MOD_RATING, effect.driver()->effectN( 1 ).average( effect ) );

  // In case the player has two copies of this embellishment, set up the buff events only once.
  if ( first && effect.player->thewarwithin_opts.dawn_dusk_thread_lining_uptime > 0.0 )
  {
    auto up = effect.player->get_uptime( buff_spell->_name )
                  ->collect_duration( *effect.player->sim )
                  ->collect_uptime( *effect.player->sim );

    buff->player->register_precombat_begin( [ buff, up ]( player_t* p ) {
      buff->trigger();
      up->update( true, p->sim->current_time() );

      auto pct = p->thewarwithin_opts.dawn_dusk_thread_lining_uptime;

      make_repeating_event(
          *p->sim, [ p, buff ] { return p->rng().gauss( buff->interval ); },
          [ buff, p, up, pct ] {
            if ( p->rng().roll( pct ) )
            {
              buff->trigger();
              up->update( true, p->sim->current_time() );
            }
            else
            {
              buff->expire();
              up->update( false, p->sim->current_time() );
            }
          } );
    } );
  }
}

// Deepening Darkness
// 443760 Driver
// 446753 Damage
// 446743 Buff
// 446836 movement speed debuff
// TODO: implement movement speed debuff
void deepening_darkness( special_effect_t& effect )
{
  auto damage =
    create_proc_action<generic_aoe_proc_t>( "deepening_darkness", effect, effect.player->find_spell( 446753 ), true );

  damage->base_dd_min = damage->base_dd_max =
    effect.driver()->effectN( 2 ).average( effect );
  damage->base_multiplier *= role_mult( effect );
  damage->base_multiplier *= writhing_mul( effect.player );

  auto buff = create_buff<buff_t>( effect.player, effect.player->find_spell( 446743 ) )
                  ->set_expire_callback( [ damage ]( buff_t*, int, timespan_t d ) {
                    if ( d > 0_ms )
                    {
                      damage->execute();
                    }
                  } )
                  ->set_expire_at_max_stack( true );

  effect.custom_buff = buff;

  new dbc_proc_callback_t( effect.player, effect );
}

// Spark of Beledar
// 443736 Driver
// 446224 Damage
// 446402 Damage with Debuff
// 446234 Debuff
void spark_of_beledar( special_effect_t& effect )
{
  struct spark_of_beledar_damage_t : public generic_proc_t
  {
    action_t* bonus_damage;
    const spell_data_t* debuff_spell;

    spark_of_beledar_damage_t( const special_effect_t& e, const spell_data_t* data )
      : generic_proc_t( e, "spark_of_beledar", data ),
        bonus_damage( nullptr ),
        debuff_spell( e.player->find_spell( 446234 ) )
    {
      bonus_damage =
          create_proc_action<generic_proc_t>( "blazing_spark_of_beledar", e, e.player->find_spell( 446402 ) );
      bonus_damage->base_dd_min = bonus_damage->base_dd_max = e.driver()->effectN( 3 ).average( e );

      base_dd_min = base_dd_max = e.driver()->effectN( 2 ).average( e );

      add_child( bonus_damage );
    }

    buff_t* create_debuff( player_t* t ) override
    {
      return make_buff( actor_pair_t( t, player ), "spark_of_beledar_debuff", debuff_spell );
    }

    void impact( action_state_t* s ) override
    {
      generic_proc_t::impact( s );
      auto debuff = get_debuff( s->target );
      if ( debuff->check() )
      {
        debuff->expire();
        bonus_damage->execute_on_target( s->target );
      }
      else
      {
        debuff->trigger();
      }
    }
  };

  effect.execute_action =
      create_proc_action<spark_of_beledar_damage_t>( "spark_of_beledar", effect, effect.player->find_spell( 446224 ) );

  new dbc_proc_callback_t( effect.player, effect );
}

// Adrenal Surge Clasp
// 443762 Driver
// 446108 Buff
void adrenal_surge( special_effect_t& effect )
{
  // create primary stat buff
  auto primary_stat_trigger = effect.driver()->effectN( 1 ).trigger();
  auto primary_value = primary_stat_trigger->effectN( 1 ).average( effect ) * writhing_mul( effect.player );
  auto primary_stat_buff = create_buff<stat_buff_t>( effect.player, "adrenal_surge", primary_stat_trigger )
    ->set_stat_from_effect_type( A_MOD_STAT, primary_value );


  // create mastery loss debuff
  // TODO: currently this does not scale with item level
  auto mastery_loss_trigger = primary_stat_trigger->effectN( 3 ).trigger();
  auto mastery_value = mastery_loss_trigger->effectN( 1 ).average( effect ) * writhing_mul( effect.player );
  auto mastery_loss_buff = create_buff<stat_buff_t>( effect.player, "adrenal_surge_debuff", mastery_loss_trigger )
    ->set_stat_from_effect_type( A_MOD_RATING, mastery_value )
    ->set_name_reporting( "Debuff" );

  effect.player->callbacks.register_callback_execute_function(
    effect.spell_id, [ primary_stat_buff, mastery_loss_buff ]( auto, auto, auto, auto ) {
      primary_stat_buff->trigger();
      mastery_loss_buff->trigger();
    } );

  new dbc_proc_callback_t( effect.player, effect );
}

// Siphoning Stilleto
// 453573 Driver
// Effect 1: Self Damage
// Effect 2: Damage
// Effect 3: Duration
// Effect 4: Range
// 458630 Self Damage
// 458624 Damage
void siphoning_stiletto( special_effect_t& effect )
{
  struct siphoning_stiletto_cb_t : public dbc_proc_callback_t
  {
    action_t* self;
    action_t* damage;
    timespan_t duration;
    siphoning_stiletto_cb_t( const special_effect_t& e )
      : dbc_proc_callback_t( e.player, e ),
        self( nullptr ),
        damage( nullptr ),
        duration( timespan_t::from_seconds( e.driver()->effectN( 3 ).base_value() ) )
    {
      self              = create_proc_action<generic_proc_t>( "siphoning_stiletto_self", e, 458630 );
      // TODO: Check if self damage is affected by the role multiplier
      self->base_dd_min = self->base_dd_max = e.driver()->effectN( 1 ).average( e ) * writhing_mul( e.player );
      self->stats->type = STATS_NEUTRAL;
      // TODO: Check if self damage can trigger other effects
      self->callbacks   = false;
      self->target      = e.player;

      damage              = create_proc_action<generic_proc_t>( "siphoning_stiletto", e, 458624 );
      damage->base_dd_min = damage->base_dd_max =
          e.driver()->effectN( 2 ).average( e );
      damage->base_multiplier *= role_mult( e );
      damage->base_multiplier *= writhing_mul( e.player );
    }

    void execute( const spell_data_t*, player_t*, action_state_t* ) override
    {
      self->execute_on_target( listener );
      // TODO: implement range check if it ever matters for specilizations that can use this.
      make_event( *listener->sim, duration, [ this ] {
        if ( !listener->sim->target_non_sleeping_list.empty() )
          damage->execute_on_target( rng().range( listener->sim->target_non_sleeping_list ) );
      } );
    }
  };

  new siphoning_stiletto_cb_t( effect );
}
}  // namespace embellishments

namespace items
{
struct stat_buff_with_multiplier_t : public stat_buff_t
{
  double stat_mul = 1.0;

  stat_buff_with_multiplier_t( player_t* p, std::string_view n, const spell_data_t* s ) : stat_buff_t( p, n, s ) {}

  double buff_stat_stack_amount( const buff_stat_t& stat, int s ) const override
  {
    return stat_buff_t::buff_stat_stack_amount( stat, s ) * stat_mul;
  }

  void expire_override( int s, timespan_t d ) override
  {
    stat_buff_t::expire_override( s, d );
    stat_mul = 1.0;
  }
};

// Trinkets
// 444958 equip driver
//  e1: stacking value
//  e2: on-use value
// 444959 on-use driver & buff
// 451199 proc projectile & buff
void spymasters_web( special_effect_t& effect )
{
  if ( unique_gear::create_fallback_buffs( effect, { "spymasters_web", "spymasters_report" } ) )
    return;

  unsigned equip_id = 444958;
  auto equip = find_special_effect( effect.player, equip_id );
  assert( equip && "Spymaster's Web missing equip effect" );

  auto equip_data = equip->driver();
  auto buff_data = equip->trigger();

  auto stacking_buff = create_buff<stat_buff_t>( effect.player, buff_data )
    ->set_stat_from_effect_type( A_MOD_STAT, equip_data->effectN( 1 ).average( effect ) )
    ->set_constant_behavior( buff_constant_behavior::NEVER_CONSTANT );

  equip->custom_buff = stacking_buff;

  new dbc_proc_callback_t( effect.player, *equip );

  auto use_buff = create_buff<stat_buff_t>( effect.player, effect.driver() )
    ->set_stat_from_effect_type( A_MOD_STAT, equip_data->effectN( 2 ).average( effect ) )
    ->set_max_stack( stacking_buff->max_stack() )
    ->set_cooldown( 0_ms );

  struct spymasters_web_t : public generic_proc_t
  {
    buff_t* stacking_buff;
    buff_t* use_buff;

    spymasters_web_t( const special_effect_t& e, buff_t* stack, buff_t* use )
      : generic_proc_t( e, "spymasters_web", e.driver() ), stacking_buff( stack ), use_buff( use )
    {}

    void execute() override
    {
      generic_proc_t::execute();

      if ( !stacking_buff->check() )
        return;

      use_buff->expire();
      use_buff->trigger( stacking_buff->check() );
      stacking_buff->expire();
    }
  };

  effect.disable_buff();
  effect.has_use_buff_override = true;
  effect.execute_action = create_proc_action<spymasters_web_t>( "spymasters_web", effect, stacking_buff, use_buff );
}

// 445593 equip
//  e1: damage value
//  e2: haste value
//  e3: mult per use stack
//  e4: unknown, damage cap? self damage?
//  e5: post-combat duration?
//  e6: unknown, chance to be silenced?
// 451895 is empowered buff
// 445619 on-use
// 452350 silence
// 451845 haste buff
// 451866 damage
// 452279 unknown, possibly unrelated?
// per-spec drivers?
//   452030, 452037, 452057, 452059, 452060, 452061,
//   452062, 452063, 452064, 452065, 452066, 452067,
//   452068, 452069, 452070, 452071, 452072, 452073
// TODO: confirm cycle doesn't rest on combat start
// TODO: replace with spec-specific driver id if possible
// TODO: confirm damage procs off procs
// TODO: determine when silence applies
void aberrant_spellforge( special_effect_t& effect )
{
  if ( unique_gear::create_fallback_buffs( effect, { "aberrant_empowerment", "aberrant_spellforge" } ) )
    return;

  // sanity check equip effect exists
  unsigned equip_id = 445593;
  auto equip = find_special_effect( effect.player, equip_id );
  assert( equip && "Aberrant Spellforge missing equip effect" );

  auto empowered = spell_from_spell_text( effect );
  if ( !empowered->ok() )
    return;

  // cache data
  auto data = equip->driver();
  auto period = effect.player->find_spell( 452030 )->effectN( 2 ).period();
  [[maybe_unused]] auto silence_dur = effect.player->find_spell( 452350 )->duration();

  // create buffs
  auto empowerment = create_buff<buff_t>( effect.player, effect.player->find_spell( 451895 ) )
                         ->set_constant_behavior( buff_constant_behavior::NEVER_CONSTANT );

  auto stack = create_buff<buff_t>( effect.player, effect.driver() )
                   ->set_cooldown( 0_ms )
                   ->set_constant_behavior( buff_constant_behavior::NEVER_CONSTANT );

  auto haste = create_buff<stat_buff_t>( effect.player, effect.player->find_spell( 451845 ) )
    ->set_stat_from_effect_type( A_MOD_RATING, data->effectN( 2 ).average( effect ) );

  // proc damage action
  struct aberrant_shadows_t : public generic_proc_t
  {
    buff_t* stack;
    double mult;

    aberrant_shadows_t( const special_effect_t& e, const spell_data_t* data, buff_t* b )
      : generic_proc_t( e, "aberrant_shadows", 451866 ), stack( b ), mult( 1.0 + data->effectN( 3 ).percent() )
    {
      base_dd_min = base_dd_max = data->effectN( 1 ).average( e );
      base_multiplier *= role_mult( e.player, e.player->find_spell( 445593 ) );

      for ( auto a : player->action_list )
      {
          if ( a->action_list && a->action_list->name_str == "precombat" &&
               a->name_str == "use_item_" + item->name_str )
          {
              a->harmful = false;
              break;
          }
      };
    }

    double action_multiplier() const override
    {
      // 125% per stack is applied exponentially
      return generic_proc_t::action_multiplier() * std::pow( mult, stack->check() );
    }
  };

  auto damage = create_proc_action<aberrant_shadows_t>( "aberrant_shadows", effect, data, stack );

  // setup equip effect
  // TODO: confirm cycle doesn't rest on combat start
  effect.player->register_precombat_begin( [ empowerment, period ]( player_t* p ) {
    empowerment->trigger();
    make_event( *p->sim, p->rng().range( 1_ms, period ), [ p, empowerment, period ] {
      empowerment->trigger();
      make_repeating_event( *p->sim, period, [ empowerment ] { empowerment->trigger(); } );
    } );
  } );

  // replace equip effect with per-spec driver
  // TODO: replace with spec-specific driver id if possible
  equip->spell_id = 452030;

  // TODO: confirm damage procs off procs
  // NOTE: if multiple abilities can proc, re-register the trigger function for 452030 in the class module and check for
  // all proccing abilities.
  effect.player->callbacks.register_callback_trigger_function( equip->spell_id,
      dbc_proc_callback_t::trigger_fn_type::CONDITION,
      [ id = empowered->id() ]( auto, const proc_data_t& data, auto, const action_state_t* s, auto ) {
        return s->result_amount && data->id() == id;
      } );

  effect.player->callbacks.register_callback_execute_function( equip->spell_id,
      [ damage, empowerment ]( auto, auto, player_t* t, const action_state_t* s ) {
        if ( empowerment->check() )
        {
          damage->execute_on_target( t );
          empowerment->consume( s->action );
        }
      } );

  auto cb = new dbc_proc_callback_t( effect.player, *equip );
  cb->deactivate();

  // setup on-use effect
  /* TODO: determine when silence applies
  auto silence = [ dur = effect.player->find_spell( 452350 )->duration() ]( player_t* p ) {
    p->buffs.stunned->increment();
    p->stun();

    make_event( *p->sim, dur, [ p ] { p->buffs.stunned->decrement(); } );
  };
  */

  empowerment->set_stack_change_callback( [ cb, haste, stack ]( buff_t*, int old_, int new_ ) {
    if ( !old_ )
    {
      cb->activate();
    }
    if ( !new_ )
    {
      cb->deactivate();

      if ( stack->at_max_stacks() )
        haste->trigger();
    }
  } );

  effect.custom_buff = stack;

  // TODO: unknown if this is hardcoded to 15s or based off the dummy data
  auto expire_delay = timespan_t::from_seconds( data->effectN( 5 ).base_value() ) * 2;
  effect.player->register_on_combat_state_callback( [ stack, expire_delay ]( player_t* p, bool c ) {
    if ( !c )
    {
      make_event( *p->sim, expire_delay, [ p, stack ] {
        if ( !p->in_combat )
          stack->expire();
      } );
    }
  } );
}

// 445203 data
//  e1: flourish damage
//  e2: flourish parry
//  e3: flourish avoidance
//  e4: decimation damage
//  e5: decimation damage to shields on crit
//  e6: barrage damage
//  e7: barrage speed
// 447970 on-use
// 445434 flourish damage
// 447962 flourish stance
// 448090 decimation damage
// 448519 decimation damage to shield on crit
// 447978 decimation stance
// 445475 barrage damage
// 448036 barrage stance
// 448433 barrage stacking buff
// 448436 barrage speed buff
// TODO: confirm order is flourish->decimation->barrage
// TODO: confirm stance can be changed pre-combat and does not reset on encounter start
// TODO: confirm flourish damage value is for entire dot and not per tick
// TODO: confirm decimation damage on crit to shield only counts the absorbed amount, instead of the full damage
void sikrans_endless_arsenal( special_effect_t& effect )
{
  unsigned equip_id = 445203;
  auto equip = find_special_effect( effect.player, equip_id );
  assert( equip && "Sikran's Shadow Arsenal missing equip effect" );

  auto data = equip->driver();

  struct sikrans_endless_arsenal_t : public generic_proc_t
  {
    std::vector<std::pair<action_t*, buff_t*>> stance;

    sikrans_endless_arsenal_t( const special_effect_t& e, const spell_data_t* data )
      : generic_proc_t( e, "sikrans_endless_arsenal", e.driver() )
    {
      // stances are populated in order: flourish->decimation->barrage
      // TODO: confirm order is flourish->decimation->barrage

      // setup flourish
      auto f_dam = create_proc_action<generic_proc_t>( "surekian_flourish", e, 445434 );
      f_dam->base_td = data->effectN( 1 ).average( e ) * f_dam->base_tick_time / f_dam->dot_duration;
      f_dam->base_multiplier *= role_mult( e.player, e.player->find_spell( 445434 ) );
      add_child( f_dam );

      auto f_stance = create_buff<stat_buff_t>( e.player, e.player->find_spell( 447962 ) )
        ->add_stat_from_effect( 1, data->effectN( 2 ).base_value() )
        ->add_stat_from_effect( 2, data->effectN( 3 ).base_value() );

      stance.emplace_back( f_dam, f_stance );

      // setup decimation
      auto d_dam = create_proc_action<generic_aoe_proc_t>( "surekian_decimation", e, 448090, true );
      d_dam->base_dd_min = d_dam->base_dd_max = data->effectN( 4 ).average( e );
      d_dam->base_multiplier *= role_mult( e.player, e.player->find_spell( 448090 ) );
      add_child( d_dam );

      auto d_shield = create_proc_action<generic_proc_t>( "surekian_brutality", e, 448519 );
      d_shield->base_dd_min = d_shield->base_dd_max = 1.0;  // for snapshot flag parsing
      add_child( d_shield );

      auto d_stance = create_buff<buff_t>( e.player, e.player->find_spell( 447978 ) );

      auto d_driver = new special_effect_t( e.player );
      d_driver->name_str = d_stance->name();
      d_driver->spell_id = d_stance->data().id();
      d_driver->proc_flags2_ = PF2_CRIT;
      e.player->special_effects.push_back( d_driver );

      // assume that absorbed amount equals result_mitigated - result_absorbed. this assumes everything in
      // player_t::assess_damage_imminent_pre_absorb are absorbs, but as for enemies this is currently unused and highly
      // unlikely to be used in the future, we should be fine with this assumption.
      // TODO: confirm only the absorbed amount counts, instead of the full damage
      e.player->callbacks.register_callback_execute_function( d_driver->spell_id,
          [ d_shield, mul = data->effectN( 5 ).percent() ]
          ( auto, auto, player_t* t, const action_state_t* s ) {
            auto absorbed = s->result_mitigated - s->result_absorbed;
            if ( absorbed > 0 )
            {
              // TODO: determine if this is affected by role mult
              d_shield->base_dd_min = d_shield->base_dd_max = mul * absorbed;
              d_shield->execute_on_target( t );
            }
          } );

      e.player->callbacks.register_callback_trigger_function( d_driver->spell_id,
        dbc_proc_callback_t::trigger_fn_type::CONDITION,
        []( auto, const auto&, player_t* t, auto, auto ) { return t->is_enemy(); } );

      auto d_cb = new dbc_proc_callback_t( e.player, *d_driver );
      d_cb->activate_with_buff( d_stance );

      stance.emplace_back( d_dam, d_stance );

      // setup barrage
      auto b_dam = create_proc_action<generic_aoe_proc_t>( "surekian_barrage", e, 445475 );
      b_dam->split_aoe_damage = false;
      b_dam->base_dd_min = b_dam->base_dd_max = data->effectN( 6 ).average( e );
      b_dam->base_multiplier *= role_mult( e.player, e.player->find_spell( 445475 ) );
      add_child( b_dam );

      auto b_stack = create_buff<buff_t>( e.player, e.player->find_spell( 448433 ) );

      auto b_speed = create_buff<buff_t>( e.player, e.player->find_spell( 448436 ) )
        ->set_max_stack( b_stack->max_stack() )
        ->set_movement_speed_buff_from_data( data->effectN( 7 ).percent() / b_stack->max_stack() );

      b_stack->set_expire_callback( [ b_speed ]( buff_t*, int, timespan_t ) {
        b_speed->trigger();
      } );

      e.player->register_movement_callback( [ b_stack ]( bool start ) {
        if ( start )
          b_stack->expire();
      } );

      auto b_stance = create_buff<buff_t>( e.player, e.player->find_spell( 448036 ) )
        ->set_tick_callback( [ b_stack ]( buff_t*, int, timespan_t ) {
          b_stack->trigger();
        } );

      stance.emplace_back( b_dam, b_stance );

      e.player->register_precombat_begin( [ this ]( player_t* ) {
        cycle_stance( false );
      } );
    }

    void init_finished() override
    {
      generic_proc_t::init_finished();

      // adjust for thewarwithin.sikrans.shadow_arsenal_stance= option
      const auto& option = player->thewarwithin_opts.sikrans_endless_arsenal_stance;
      if ( !option.is_default() )
      {
        if ( util::str_compare_ci( option, "decimation" ) )
          std::rotate( stance.begin(), stance.begin() + 1, stance.end() );
        else if ( util::str_compare_ci( option, "barrage" ) )
          std::rotate( stance.begin(), stance.begin() + 2, stance.end() );
        else if ( !util::str_compare_ci( option, "flourish" ) )
          throw sc_invalid_apl_argument(
            "Valid 'thewarwithin.sikrans.shadow_arsenal_stance' are: flourish, decimation, barrage" );
      }
    }

    void cycle_stance( bool action = true )
    {
      stance.back().second->expire();

      if ( action && target )
        stance.front().first->execute_on_target( target );

      stance.front().second->trigger();

      std::rotate( stance.begin(), stance.begin() + 1, stance.end() );
    }

    void execute() override
    {
      generic_proc_t::execute();
      cycle_stance();
    }
  };

  effect.has_use_damage_override = true;
  effect.execute_action = create_proc_action<sikrans_endless_arsenal_t>( "sikrans_endless_arsenal", effect, data );
}

// 444292 equip
//  e1: damage
//  e2: shield cap
//  e3: repeating period
// 444301 on-use
// 447093 scarab damage
// 447097 'retrieval'?
// 447134 shield
// TODO: determine absorb priority
// TODO: determine how scarabs select target
// TODO: create proxy action if separate equip/on-use reporting is needed
void swarmlords_authority( special_effect_t& effect )
{
  unsigned equip_id = 444292;
  auto equip = find_special_effect( effect.player, equip_id );
  assert( equip && "Swarmlord's Authority missing equip effect" );

  auto data = equip->driver();

  struct ravenous_scarab_t : public generic_proc_t
  {
    struct ravenous_scarab_buff_t : public absorb_buff_t
    {
      double absorb_pct;

      ravenous_scarab_buff_t( const special_effect_t& e, const spell_data_t* s, const spell_data_t* data )
        : absorb_buff_t( e.player, "ravenous_scarab", s ), absorb_pct( s->effectN( 2 ).percent() )
      {
        cumulative = true;

        // TODO: set high priority & add to player absorb priority if necessary
        set_default_value( data->effectN( 2 ).average( e ) );
      }

      double consume( double a, action_state_t* s ) override
      {
        return absorb_buff_t::consume( a * absorb_pct, s );
      }
    };

    buff_t* shield;
    double return_speed;

    ravenous_scarab_t( const special_effect_t& e, const spell_data_t* data )
      : generic_proc_t( e, "ravenous_swarm", e.trigger() )
    {
      base_dd_min = base_dd_max = data->effectN( 1 ).average( e );

      auto return_spell = e.player->find_spell( 447097 );
      shield = make_buff<ravenous_scarab_buff_t>( e, return_spell->effectN( 2 ).trigger(), data );
      return_speed = return_spell->missile_speed();
    }

    void impact( action_state_t* s ) override
    {
      generic_proc_t::impact( s );

      // TODO: determine how shield behaves during on-use
      make_event( *sim, timespan_t::from_seconds( player->get_player_distance( *s->target ) / return_speed ), [ this ] {
        shield->trigger();
      } );
    }
  };

  auto scarab = create_proc_action<ravenous_scarab_t>( "ravenous_swarm", effect, data );

  // setup equip
  equip->execute_action = scarab;
  new dbc_proc_callback_t( effect.player, *equip );

  // setup on-use
  effect.custom_buff = create_buff<buff_t>( effect.player, effect.driver() )
    ->set_tick_callback( [ scarab ]( buff_t*, int, timespan_t ) { scarab->execute(); } );
}

// 444264 on-use
// 444258 data + heal driver
// 446805 heal
// 446886 hp buff
// 446887 shield, unknown use
// TODO: determine out of combat decay
void foul_behemoths_chelicera( special_effect_t& effect )
{
  struct digestive_venom_t : public generic_proc_t
  {
    struct tasty_juices_t : public generic_heal_t
    {
      buff_t* buff;

      tasty_juices_t( const special_effect_t& e, const spell_data_t* data )
        : generic_heal_t( e, "tasty_juices", 446805 )
      {
        base_dd_min = base_dd_max = data->effectN( 2 ).average( e );

        // TODO: determine out of combat decay
        buff = create_buff<buff_t>( e.player, e.player->find_spell( 446886 ) )
          ->set_expire_callback( [ this ]( buff_t* b, int, timespan_t ) {
            player->resources.temporary[ RESOURCE_HEALTH ] -= b->current_value;
            player->recalculate_resource_max( RESOURCE_HEALTH );
          } );
      }

      void impact( action_state_t* s ) override
      {
        generic_heal_t::impact( s );

        if ( !buff->check() )
          buff->trigger();

        // overheal is result_total - result_amount
        auto overheal = s->result_total - s->result_amount;
        if ( overheal > 0 )
        {
          buff->current_value += overheal;
          player->resources.temporary[ RESOURCE_HEALTH ] += overheal;
          player->recalculate_resource_max( RESOURCE_HEALTH );
        }
      }
    };

    dbc_proc_callback_t* cb;

    digestive_venom_t( const special_effect_t& e ) : generic_proc_t( e, "digestive_venom", e.driver() )
    {
      auto data = e.player->find_spell( 444258 );
      base_td = data->effectN( 1 ).average( e ) * ( base_tick_time / dot_duration );

      auto driver = new special_effect_t( e.player );
      driver->name_str = data->name_cstr();
      driver->spell_id = data->id();
      driver->execute_action = create_proc_action<tasty_juices_t>( "tasty_juices", e, data );
      e.player->special_effects.push_back( driver );

      cb = new dbc_proc_callback_t( e.player, *driver );
      cb->deactivate();
    }

    void trigger_dot( action_state_t* s ) override
    {
      generic_proc_t::trigger_dot( s );

      cb->activate();
    }

    void last_tick( dot_t* d ) override
    {
      generic_proc_t::last_tick( d );

      cb->deactivate();
    }
  };

  effect.execute_action = create_proc_action<digestive_venom_t>( "digestive_venom", effect );
}

// 445066 equip + data
//  e1: primary
//  e2: secondary
//  e3: max stack
//  e4: reduction
//  e5: unreduced cap
//  e6: period
// 445560 on-use
// 449578 primary buff
// 449581 haste buff
// 449593 crit buff
// 449594 mastery buff
// 449595 vers buff
// TODO: confirm secondary precedence in case of tie is vers > mastery > haste > crit
void ovinaxs_mercurial_egg( special_effect_t& effect )
{
  unsigned equip_id = 445066;
  auto equip = find_special_effect( effect.player, equip_id );
  assert( equip && "Ovinax's Mercurial Egg missing equip effect" );

  auto data = equip->driver();

  struct ovinax_stat_buff_t : public stat_buff_t
  {
    double cap_mul;
    int cap;

    ovinax_stat_buff_t( player_t* p, std::string_view n, const spell_data_t* s, const spell_data_t* data )
      : stat_buff_t( p, n, s ),
        cap_mul( 1.0 - data->effectN( 4 ).percent() ),
        cap( as<int>( data->effectN( 5 ).base_value() ) )
    {}

    // values can be off by a +/-2 due to unknown rounding being performed by the in-game script
    // TODO: confirm truncation happens on final amount, and not per stack amount
    double buff_stat_stack_amount( const buff_stat_t& stat, int s ) const override
    {
      int under_cap = std::min( s, cap );
      int over_cap = s - under_cap;

      double amount = stat_buff_t::buff_stat_stack_amount( stat, under_cap );
      if ( over_cap > 0 )
        amount += stat_buff_t::buff_stat_stack_amount( stat, over_cap ) * cap_mul;

      return amount;
    }
  };

  // setup stat buffs
  auto primary = create_buff<ovinax_stat_buff_t>( effect.player, effect.player->find_spell( 449578 ), data );
  primary->set_stat_from_effect_type( A_MOD_STAT, data->effectN( 1 ).average( effect ) )
         ->set_constant_behavior( buff_constant_behavior::NEVER_CONSTANT );

  static constexpr std::array<unsigned, 4> buff_ids = { 449595, 449594, 449581, 449593 };

  std::unordered_map<stat_e, ovinax_stat_buff_t*> secondaries;

  for ( size_t i = 0; i < secondary_ratings.size(); i++ )
  {
    auto stat_str = util::stat_type_abbrev( secondary_ratings[ i ] );
    auto spell = effect.player->find_spell( buff_ids[ i ] );
    auto name = fmt::format( "{}_{}", util::tokenize_fn( spell->name_cstr() ), stat_str );

    auto buff = create_buff<ovinax_stat_buff_t>( effect.player, name, spell, data );
    buff->set_stat_from_effect_type( A_MOD_RATING, data->effectN( 2 ).average( effect ) )
        ->set_name_reporting( stat_str )
        ->set_constant_behavior( buff_constant_behavior::NEVER_CONSTANT );

    secondaries[ secondary_ratings[ i ] ] = buff;
  }

  // proxy buff for on-use
  auto halt = create_buff<buff_t>( effect.player, effect.driver() )->set_cooldown( 0_ms );

  // proxy buff for equip ticks
  auto ticks = create_buff<buff_t>( effect.player, equip->driver() )
    ->set_quiet( true )
    ->set_tick_zero( true )
    ->set_tick_callback( [ primary, secondaries, halt, p = effect.player ]( buff_t*, int, timespan_t ) {
      if ( halt->check() )
        return;

      // if player is moving decrement stack. if player is above desired primary stack and not casting, assume player
      // will sidestep to try to decrement.
      auto desired = p->thewarwithin_opts.ovinaxs_mercurial_egg_desired_primary_stacks;
      // randomly add leeway to desired to simulate player reaction
      auto leeway = p->thewarwithin_opts.ovinaxs_mercurial_egg_desired_primary_stacks_leeway;
      desired += p->rng().range( -leeway, leeway );

      if ( ( primary->check() > desired && ( !p->executing || p->executing->usable_moving() ) &&
             ( !p->channeling || p->channeling->usable_moving() ) ) ||
           p->is_moving() )
      {
        primary->decrement();

        // stat selection only updates on increment
        auto buff = secondaries.at( util::highest_stat( p, secondary_ratings ) );
        int stack = 1;

        if ( !buff->check() )  // new stat, expire all stats first
        {
          range::for_each( secondaries, []( const auto& b ) { b.second->expire(); } );

          stack = primary->max_stack() - primary->check();
        }

        if ( !buff->at_max_stacks() )
          buff->trigger( stack );
      }
      else
      {
        range::for_each( secondaries, []( const auto& b ) { b.second->decrement(); } );

        if ( !primary->at_max_stacks() )
          primary->trigger();
      }
    } );

  effect.player->register_precombat_begin(
      [ ticks, primary, secondaries ]( player_t* p ) {
        auto p_stacks = p->thewarwithin_opts.ovinaxs_mercurial_egg_initial_primary_stacks;
        auto s_stacks = primary->max_stack() - p_stacks;

        if ( p_stacks )
        {
          primary->trigger( p_stacks );
        }

        if ( s_stacks )
        {
          auto buff = secondaries.at( util::highest_stat( p, secondary_ratings ) );
          buff->trigger( s_stacks );
        }

        make_event( *p->sim, p->rng().range( 1_ms, ticks->buff_period ), [ ticks ] { ticks->trigger(); } );
      } );

  effect.custom_buff = halt;
}

// 449946 on use
// 446209 stat buff value container
// 449947 jump task
// 449952 collect orb
// 449948 stand here task
// 450025 stand here task AoE DR/stacking trigger
// 449954 primary buff
// TODO: Implement precombat use with timing option.
struct do_treacherous_transmitter_task_t : public action_t
{
  buff_t* task = nullptr;

  do_treacherous_transmitter_task_t( player_t* p, std::string_view opt )
    : action_t( ACTION_OTHER, "do_treacherous_transmitter_task", p, spell_data_t::nil() )
  {
    parse_options( opt );

    s_data_reporting   = p->find_spell( 446209 );
    name_str_reporting = "Complete Task";

    callbacks = harmful = false;
    trigger_gcd         = 0_ms;
  }

  bool ready() override
  {
    if ( task != nullptr )
    {
      // Set the minimum time it would reasonably take to complete the task
      // Prevents using the trinket and instantly completing the tasks, which is unreasonable.
      // Starting at a 1.5s minimum for all tasks
      if ( task->remains() > task->buff_duration() - 1.5_s )
        return false;

      switch ( task->data().id() )
      {
        case 449947:
          // Jumping takes almost no time, 1.5s minimum is fine.
          return task->check();
          break;
        case 449952:
          // Collecting the orb should take a bit longer, due to its movement, 2s minimum should be fine.
          if ( task->remains() <= task->buff_duration() - 2_s )
            return task->check();
          else
            return false;
          break;
        case 449948:
          // If the task is stand here, account for the movement time, and 2s for the stacking buff to occur.
          if ( task->remains() <= task->buff_duration() - 3_s )
            return task->check();
          else
            return false;
          break;
        default:
          return false;
          break;
      }
    }
    else
      return false;
  }

  void execute() override
  {
    task->expire();
  }
};

void treacherous_transmitter( special_effect_t& effect )
{
  if ( unique_gear::create_fallback_buffs(
           effect, { "cryptic_instructions", "errant_manaforge_emission", "realigning_nexus_convergence_divergence",
                     "ethereal_powerlink" } ) )
    return;

  struct cryptic_instructions_t : public generic_proc_t
  {
    std::vector<buff_t*> tasks;
    buff_t* stat_buff;
    std::vector<action_t*> apl_actions;
    action_t* use_action;
    const special_effect_t& effect;
    timespan_t task_dur;

    cryptic_instructions_t( const special_effect_t& e )
      : generic_proc_t( e, "cryptic_instructions", e.driver() ),
        effect( e ),
        task_dur( 0_ms )
    {
      harmful            = false;
      cooldown->duration = 0_ms;  // Handled by the item

      stat_buff =
          create_buff<stat_buff_t>( e.player, e.player->find_spell( 449954 ) )
              ->set_stat_from_effect_type( A_MOD_STAT, e.player->find_spell( 446209 )->effectN( 1 ).average( e ) );

      for ( auto& a : e.player->action_list )
      {
        if ( a->name_str == "do_treacherous_transmitter_task" )
        {
          apl_actions.push_back( a );
        }
        if ( a->action_list && a->action_list->name_str == "precombat" && a->name_str == "use_item_" + item->name_str )
        {
          a->harmful = harmful;
          use_action = a;
        }
      }

      if ( apl_actions.size() > 0 || use_action != nullptr )
      {
        buff_t* jump_task   = create_buff<buff_t>( e.player, e.player->find_spell( 449947 ) );
        buff_t* collect_orb = create_buff<buff_t>( e.player, e.player->find_spell( 449952 ) );
        buff_t* stand_here  = create_buff<buff_t>( e.player, e.player->find_spell( 449948 ) );

        tasks.push_back( jump_task );
        tasks.push_back( collect_orb );
        tasks.push_back( stand_here );

        for ( auto& t : tasks )
        {
          t->set_expire_callback( [ & ]( buff_t*, int, timespan_t d ) {
            if ( d > 0_ms )
            {
              stat_buff->trigger();
            }
          } );
        }

        // Set a default task for the actions ready() function, will be overwritten later
        for ( auto& a : apl_actions )
        {
          debug_cast<do_treacherous_transmitter_task_t*>( a )->task = tasks[ 0 ];
        }
      }

      task_dur = e.player->find_spell( 449947 )->duration();
    }

    void precombat_buff()
    {
      // shared cd (other trinkets & on-use items)
      auto cdgrp = player->get_cooldown( effect.cooldown_group_name() );

      timespan_t time = 0_ms;

      if ( time == 0_ms )  // No global override, check for an override from an APL variable
      {
        for ( auto v : player->variables )
        {
          if ( v->name_ == "treacherous_transmitter_precombat_cast" )
          {
            time = timespan_t::from_seconds( v->value() );
            break;
          }
        }
      }

      const auto& apl = player->precombat_action_list;

      auto it = range::find( apl, use_action );
      if ( it == apl.end() )
      {
        sim->print_debug(
            "WARNING: Precombat /use_item for Treacherous Transmitter exists but not found in precombat APL!" );
        return;
      }

      cdgrp->start( 1_ms );  // tap the shared group cd so we can get accurate action_ready() checks

      // total duration of the buff
      auto total = tasks[ 0 ]->buff_duration();
      // actual duration of the buff you'll get in combat
      auto actual = total - time;
      // cooldown on effect/trinket at start of combat
      // auto cd_dur = cooldown->duration - time;
      // shared cooldown at start of combat
      // auto cdgrp_dur = std::max( 0_ms, effect.cooldown_group_duration() - time );

      sim->print_debug( "PRECOMBAT: Treacherous Transmitter started {}s before combat via {}, {}s in-combat buff", time,
                        "APL", actual );

      tasks[ 0 ]->trigger( 1, buff_t::DEFAULT_VALUE(), 1.0, actual );

      if ( use_action )  // from the apl, so cooldowns will be started by use_item_t. adjust. we are still in precombat.
      {
        make_event( *sim, [ this, time, cdgrp ] {  // make an event so we adjust after cooldowns are started
          cooldown->adjust( -time );

          if ( use_action )
            use_action->cooldown->adjust( -time );

          cdgrp->adjust( -time );
        } );
      }
      if ( apl_actions.size() == 0 )
      {
        make_event( *sim, rng().range( 0_ms, actual - 1_ms ), [ this ] {
          tasks[ 0 ]->expire();
          stat_buff->trigger();
        } );
      }
    }

    void execute() override
    {
      if ( !player->in_combat && use_action )
      {
        precombat_buff();
        return;
      }

      generic_proc_t::execute();

      if ( apl_actions.size() > 0 )
      {
        rng().shuffle( tasks.begin(), tasks.end() );
        for ( auto& a : apl_actions )
        {
          debug_cast<do_treacherous_transmitter_task_t*>( a )->task = tasks[ 0 ];
        }
        tasks[ 0 ]->trigger();
      }
      else
      {
        make_event( *sim, rng().gauss_ab( 6_s, 3_s, 3_s, task_dur ), [ this ] { stat_buff->trigger(); } );
      }
    }
  };

  effect.disable_buff();
  effect.stat           = effect.player->convert_hybrid_stat( STAT_STR_AGI_INT );
  effect.execute_action = create_proc_action<cryptic_instructions_t>( "cryptic_instructions", effect );
}

// 443124 on-use
//  e1: damage
//  e2: trigger heal return
// 443128 coeffs
//  e1: damage
//  e2: heal
//  e3: unknown
//  e4: cdr on kill
// 446067 heal
// 455162 heal return
//  e1: dummy
//  e2: trigger heal
// TODO: confirm cast time is hasted
void mad_queens_mandate( special_effect_t& effect )
{
  unsigned coeff_id = 443128;
  auto coeff = find_special_effect( effect.player, coeff_id );
  assert( coeff && "Mad Queen's Mandate missing coefficient effect" );

  struct abyssal_gluttony_t : public generic_proc_t
  {
    cooldown_t* item_cd;
    action_t* heal;
    timespan_t cdr;
    double heal_speed;
    double hp_mul;

    abyssal_gluttony_t( const special_effect_t& e, const spell_data_t* data )
      : generic_proc_t( e, "abyssal_gluttony", e.driver() ),
        item_cd( e.player->get_cooldown( e.cooldown_name() ) ),
        cdr( timespan_t::from_seconds( data->effectN( 4 ).base_value() ) ),
        heal_speed( e.trigger()->missile_speed() ),
        hp_mul( 0.5 ) // not present in spell data
    {
      base_dd_min = base_dd_max = data->effectN( 1 ).average( e );
      base_multiplier *= role_mult( e );

      heal = create_proc_action<generic_heal_t>( "abyssal_gluttony_heal", e, "abyssal_gluttony_heal",
                                                 e.trigger()->effectN( 2 ).trigger() );
      heal->name_str_reporting = "abyssal_gluttony";
      heal->base_td = data->effectN( 2 ).average( e ) * ( heal->base_tick_time / heal->dot_duration );
    }

    bool usable_moving() const override { return true; }

    void execute() override
    {
      bool was_sleeping = target->is_sleeping();

      generic_proc_t::execute();

      auto delay = timespan_t::from_seconds( player->get_player_distance( *target ) / heal_speed );
      make_event( *sim, delay, [ this ] { heal->execute(); } );

      // Assume if target wasn't sleeping but is now, it was killed by the damage
      if ( !was_sleeping && target->is_sleeping() )
      {
        cooldown->adjust( -cdr );
        item_cd->adjust( -cdr );
      }
    }

    double composite_target_multiplier( player_t* t ) const override
    {
      auto mul = 1.0 + hp_mul * ( 100 - t->health_percentage() ) * 0.01;

      heal->base_td_multiplier = mul;

      return generic_proc_t::composite_target_multiplier( t ) * mul;
    }
  };

  effect.execute_action = create_proc_action<abyssal_gluttony_t>( "abyssal_gluttony", effect, coeff->driver() );
}

// Sigil of Algari Concordance
// Might have variations based on the players Specilization.
// Testing on DPS Death Knight showed only a single spawnable pet.
// 443378 Driver
// Effect 2: Thunder Bolt Damage
// Effect 3: Bolt Rain Damage
// Effect 4: Thundering Bolt Damage
// Effect 5: Unknown
// Effect 6: Unknown
// Effect 7: Unknown
// Effect 8: Unknown
// Effect 9: Mighty Smash Damage
// Effect 10: Earthen Ire Damage
// 452310 Summon Spell (DPS)
// 452335 Thunder Bolt - Damage Spell DPS Single Target
// 452334 Bolt Rain - Damage Spell DPS AoE
// 452445 Thundering Bolt - One Time Spell DPS
// 452496 Summon Spell (Tank)
// 452545 Mighty Smash - Damage Spell Tank
// 452514 Earthen Ire - One Time Spell Tank
// 452890 Earthen Ire - Ticking Damage
// 452325, 452457, and 452498 Periodic Triggers for pet actions
namespace sigil_of_algari_concordance
{
struct algari_pet_cast_event_t : public event_t
{
  action_t* st_action;
  action_t* aoe_action;
  action_t* one_time_action;
  unsigned tick;
  pet_t* pet;
  timespan_t period;

  algari_pet_cast_event_t( pet_t* p, timespan_t time_to_execute, unsigned tick, action_t* st_action,
                           action_t* aoe_action, action_t* one_time_action )
    : event_t( *p, time_to_execute ),
      st_action( st_action ),
      aoe_action( aoe_action ),
      one_time_action( one_time_action ),
      tick( tick ),
      pet( p ),
      period( 0_ms )
  {
    period = pet->find_spell( 452325 )->effectN( 1 ).period();
  }

  const char* name() const override
  {
    return "algari_pet_cast";
  }

  void execute() override
  {
    if ( pet->is_active() )
    {
      tick++;
      // Emulates the odd behavior where sometimes it will execute the one time action the first tick
      // while other times it will execute it later. While still guarenteeing it will cast sometime in its duration.
      if ( one_time_action != nullptr && rng().roll( 0.33 * tick ) )
      {
        one_time_action->execute();
        one_time_action = nullptr;
      }
      else if ( aoe_action != nullptr && pet->sim->target_non_sleeping_list.size() > 2 )
      {
        aoe_action->execute();
      }
      else
      {
        st_action->execute();
      }
      make_event<algari_pet_cast_event_t>( sim(), pet, period, tick, st_action, aoe_action, one_time_action );
    }
  }
};

struct sigil_of_algari_concordance_pet_t : public unique_gear_pet_t
{
  action_t* st_action;
  action_t* one_time_action;
  action_t* aoe_action;

  sigil_of_algari_concordance_pet_t( std::string_view name, const special_effect_t& e,
                                     const spell_data_t* summon_spell )
    : unique_gear_pet_t( name, e, summon_spell ),
      st_action( nullptr ),
      one_time_action( nullptr ),
      aoe_action( nullptr )
  {
    npc_id = summon_spell->effectN( 1 ).misc_value1();
  }

  void arise() override
  {
    unique_gear_pet_t::arise();
    make_event<algari_pet_cast_event_t>( *sim, this, 0_ms, 0, st_action, aoe_action, one_time_action );
  }
};

struct algari_concodance_pet_spell_t : public spell_t
{
  unsigned max_scaling_targets;
  bool scale_aoe_damage;
  algari_concodance_pet_spell_t( std::string_view n, pet_t* p, const spell_data_t* s, action_t* a )
    : spell_t( n, p, s ), max_scaling_targets( 5 ), scale_aoe_damage( false )
  {
    background = true;
    auto proxy = a;
    auto it    = range::find( proxy->child_action, data().id(), &action_t::id );
    if ( it != proxy->child_action.end() )
      stats = ( *it )->stats;
    else
      proxy->add_child( this );

    // TODO: determine if these are affected by role mult
  }

  player_t* p() const
  {
    return debug_cast<player_t*>( debug_cast<pet_t*>( this->player )->owner );
  }

  double composite_aoe_multiplier( const action_state_t* state ) const override
  {
    double am = spell_t::composite_aoe_multiplier( state );

    if ( scale_aoe_damage )
      am *= 1.0 + 0.3 * clamp( state->n_targets - 1u, 0u, max_scaling_targets );

    return am;
  }
};

struct algari_concodance_pet_heal_t : public heal_t
{
  unsigned max_scaling_targets;
  bool scale_aoe_damage;
  algari_concodance_pet_heal_t( std::string_view n, pet_t* p, const spell_data_t* s, action_t* a )
    : heal_t( n, p, s ), max_scaling_targets( 5 ), scale_aoe_damage( false )
  {
    background = true;
    auto proxy = a;
    auto it    = range::find( proxy->child_action, data().id(), &action_t::id );
    if ( it != proxy->child_action.end() )
      stats = ( *it )->stats;
    else
      proxy->add_child( this );

    // TODO: determine if these are affected by role mult

    if ( !target || target->is_enemy() )
      target = debug_cast<pet_t*>( this->player )->owner;
  }

  player_t* p() const
  {
    return debug_cast<player_t*>( debug_cast<pet_t*>( this->player )->owner );
  }

  void activate() override
  {
    sim->player_no_pet_list.register_callback( [ this ]( player_t* ) { target_cache.is_valid = false; } );
  }

  int num_targets() const override
  {
    return as<int>( range::count_if( sim->player_no_pet_list, []( player_t* t ) {
      if ( t->is_sleeping() )
        return false;
      return true;
    } ) );
  }

  size_t available_targets( std::vector<player_t*>& target_list ) const override
  {
    target_list.clear();
    target_list.push_back( p() );

    for ( const auto& t : sim->player_no_pet_list )
    {
      if ( t->is_sleeping() )
        continue;

      if ( t != p() && t->party == p()->party )
        target_list.push_back( t );
    }

    return target_list.size();
  }
};

struct thunder_bolt_silvervein_t : public algari_concodance_pet_spell_t
{
  thunder_bolt_silvervein_t( std::string_view name, pet_t* p, const special_effect_t& e, action_t* a )
    : algari_concodance_pet_spell_t( name, p, p->find_spell( 452335 ), a )
  {
    name_str_reporting = "thunder_bolt";
    base_dd_min = base_dd_max = e.driver()->effectN( 2 ).average( e );
  }
};

struct bolt_rain_t : public algari_concodance_pet_spell_t
{
  bolt_rain_t( std::string_view name, pet_t* p, const special_effect_t& e, action_t* a )
    : algari_concodance_pet_spell_t( name, p, p->find_spell( 452334 ), a )
  {
    aoe              = -1;
    split_aoe_damage = true;
    scale_aoe_damage = true;
    base_dd_min = base_dd_max = e.driver()->effectN( 3 ).average( e );
  }
};

struct thundering_bolt_t : public algari_concodance_pet_spell_t
{
  thundering_bolt_t( std::string_view name, pet_t* p, const special_effect_t& e, action_t* a )
    : algari_concodance_pet_spell_t( name, p, p->find_spell( 452445 ), a )
  {
    aoe              = -1;
    split_aoe_damage = true;
    scale_aoe_damage = true;
    base_dd_min = base_dd_max = e.driver()->effectN( 4 ).average( e );
  }
};

struct mighty_smash_t : public algari_concodance_pet_spell_t
{
  mighty_smash_t( std::string_view name, pet_t* p, const special_effect_t& e, action_t* a )
    : algari_concodance_pet_spell_t( name, p, p->find_spell( 452545 ), a )
  {
    aoe              = -1;
    split_aoe_damage = true;
    scale_aoe_damage = true;
    base_dd_min = base_dd_max = e.driver()->effectN( 9 ).average( e );
  }
};

struct earthen_ire_buff_t : public algari_concodance_pet_spell_t
{
  buff_t* ire_buff;

  earthen_ire_buff_t( std::string_view name, pet_t* p, const special_effect_t& e, action_t* a )
    : algari_concodance_pet_spell_t( name, p, e.player->find_spell( 452518 ), a )
  {
    background = true;

    auto ire_damage = create_proc_action<generic_aoe_proc_t>( "earthen_ire_aoe", e, 452890 );
    ire_damage->base_dd_min = ire_damage->base_dd_max = e.driver()->effectN( 10 ).average( e );
    ire_damage->stats = stats;
    stats->action_list.push_back( ire_damage );
    // manual init since this is created when the pet is dynamically created during runtime
    ire_damage->init();

    ire_buff = create_buff<buff_t>( e.player, e.player->find_spell( 452514 ) )
      ->set_tick_callback( [ ire_damage ]( buff_t*, int, timespan_t ) { ire_damage->execute(); } );
  }

  void execute() override
  {
    algari_concodance_pet_spell_t::execute();
    ire_buff->trigger();
  }
};

struct mending_the_cracks_heal_t : public algari_concodance_pet_heal_t
{
  mending_the_cracks_heal_t( std::string_view name, pet_t* p, const special_effect_t& e, action_t* a )
    : algari_concodance_pet_heal_t( name, p, e.player->find_spell( 452469 ), a )
  {
    name_str_reporting = "mending_the_cracks";
    background         = true;
    aoe                = 5;
    base_td            = e.driver()->effectN( 2 ).average( e ) / 5;
  }
};

struct brightstone_pet_t : public sigil_of_algari_concordance_pet_t
{
  action_t* action;
  const special_effect_t& effect;
  target_specific_t<buff_t> stat_buffs;

  brightstone_pet_t( const special_effect_t& e, action_t* a = nullptr, const spell_data_t* summon_spell = nullptr )
    : sigil_of_algari_concordance_pet_t( "brightstone", e, summon_spell ), action( a ), effect( e ), stat_buffs{ false }
  {
  }

  buff_t* get_buff( player_t* buff_player )
  {
    if ( stat_buffs[ buff_player ] )
      return stat_buffs[ buff_player ];

    if ( auto buff = buff_t::find( buff_player, "earthen_might", owner ) )
    {
      stat_buffs[ buff_player ] = buff;
      return buff;
    }

    auto stat_buff =
        make_buff<stat_buff_t>( actor_pair_t{ buff_player, owner }, "earthen_might", owner->find_spell( 452472 ) )
            ->add_stat_from_effect_type( A_MOD_STAT, effect.driver()->effectN( 7 ).average( effect ) );

    stat_buffs[ buff_player ] = stat_buff;

    return stat_buff;
  }

  void create_actions() override;
};

struct earthen_might_spell_t : public algari_concodance_pet_heal_t
{
  earthen_might_spell_t( std::string_view name, pet_t* p, const special_effect_t& e, action_t* a )
    : algari_concodance_pet_heal_t( name, p, e.player->find_spell( 452472 ), a )
  {
    name_str_reporting = "earthen_might";
    background         = true;
    aoe                = 5;
  }
  
  brightstone_pet_t* pet()
  {
    return debug_cast<brightstone_pet_t*>( player );
  }

  brightstone_pet_t* pet() const
  {
    return debug_cast<brightstone_pet_t*>( player );
  }
  
  void impact( action_state_t* s ) override
  {
    algari_concodance_pet_heal_t::impact( s );

    pet()->get_buff( s->target )->trigger();
  }
};

void brightstone_pet_t::create_actions()
{
  sigil_of_algari_concordance_pet_t::create_actions();
  st_action       = new mending_the_cracks_heal_t( "mending_the_cracks", this, effect, action );
  one_time_action = new earthen_might_spell_t( "earthen_might", this, effect, action );
}

struct silvervein_pet_t : public sigil_of_algari_concordance_pet_t
{
  action_t* action;
  const special_effect_t& effect;
  silvervein_pet_t( const special_effect_t& e, action_t* a = nullptr, const spell_data_t* summon_spell = nullptr )
    : sigil_of_algari_concordance_pet_t( "silvervein", e, summon_spell ), action( a ), effect( e )
  {
  }

  void create_actions() override
  {
    sigil_of_algari_concordance_pet_t::create_actions();
    st_action       = new thunder_bolt_silvervein_t( "thunder_bolt_silvervein", this, effect, action );
    aoe_action      = new bolt_rain_t( "bolt_rain", this, effect, action );
    one_time_action = new thundering_bolt_t( "thundering_bolt", this, effect, action );
  }
};

struct boulderbane_pet_t : public sigil_of_algari_concordance_pet_t
{
  action_t* action;
  const special_effect_t& effect;
  boulderbane_pet_t( const special_effect_t& e, action_t* a = nullptr, const spell_data_t* summon_spell = nullptr )
    : sigil_of_algari_concordance_pet_t( "boulderbane", e, summon_spell ), action( a ), effect( e )
  {
  }

  void create_actions() override
  {
    sigil_of_algari_concordance_pet_t::create_actions();
    st_action       = new mighty_smash_t( "mighty_smash", this, effect, action );
    one_time_action = new earthen_ire_buff_t( "earthen_ire", this, effect, action );
  }
};

void sigil_of_algari_concordance( special_effect_t& e )
{
  struct sigil_of_algari_concordance_t : public generic_proc_t
  {
    const spell_data_t* summon_spell;
    spawner::pet_spawner_t<silvervein_pet_t> silvervein_spawner;
    spawner::pet_spawner_t<boulderbane_pet_t> boulderbane_spawner;
    spawner::pet_spawner_t<brightstone_pet_t> brightstone_spawner;
    bool silvervein;
    bool boulderbane;
    bool brightstone;

    sigil_of_algari_concordance_t( const special_effect_t& e )
      : generic_proc_t( e, "sigil_of_algari_concordance", e.driver() ),
        summon_spell( nullptr ),
        silvervein_spawner( "silvervein", e.player ),
        boulderbane_spawner( "boulderbane", e.player ),
        brightstone_spawner( "brighstone", e.player ),
        silvervein( false ),
        boulderbane( false ),
        brightstone( false )
    {
      switch ( e.player->_spec )
      {
        case HUNTER_BEAST_MASTERY:
        case HUNTER_MARKSMANSHIP:
        case PRIEST_SHADOW:
        case SHAMAN_ELEMENTAL:
        case MAGE_ARCANE:
        case MAGE_FIRE:
        case MAGE_FROST:
        case WARLOCK_AFFLICTION:
        case WARLOCK_DEMONOLOGY:
        case WARLOCK_DESTRUCTION:
        case DRUID_BALANCE:
        case EVOKER_DEVASTATION:
        case EVOKER_AUGMENTATION:
          silvervein = true;
          break;
        case WARRIOR_PROTECTION:
        case PALADIN_PROTECTION:
        case DEATH_KNIGHT_BLOOD:
        case MONK_BREWMASTER:
        case DRUID_GUARDIAN:
        case DEMON_HUNTER_VENGEANCE:
          boulderbane = true;
          break;
        case PALADIN_HOLY:
        case PRIEST_DISCIPLINE:
        case PRIEST_HOLY:
        case SHAMAN_RESTORATION:
        case MONK_MISTWEAVER:
        case DRUID_RESTORATION:
        case EVOKER_PRESERVATION:
          brightstone = true;
          break;
        case WARRIOR_ARMS:
        case WARRIOR_FURY:
        case PALADIN_RETRIBUTION:
        case HUNTER_SURVIVAL:
        case ROGUE_ASSASSINATION:
        case ROGUE_OUTLAW:
        case ROGUE_SUBTLETY:
        case DEATH_KNIGHT_FROST:
        case DEATH_KNIGHT_UNHOLY:
        case SHAMAN_ENHANCEMENT:
        case MONK_WINDWALKER:
        case DRUID_FERAL:
        case DEMON_HUNTER_HAVOC:
        default:
          silvervein = true;
          break;
      }

      if ( silvervein )
      {
        summon_spell = e.player->find_spell( 452310 );
        silvervein_spawner.set_creation_callback(
            [ & ]( player_t* ) { return new silvervein_pet_t( e, this, summon_spell ); } );
        silvervein_spawner.set_default_duration( summon_spell->duration() );
      }
      if ( boulderbane )
      {
        summon_spell = e.player->find_spell( 452496 );
        boulderbane_spawner.set_creation_callback(
            [ & ]( player_t* ) { return new boulderbane_pet_t( e, this, summon_spell ); } );
        boulderbane_spawner.set_default_duration( summon_spell->duration() );
      }
      if ( brightstone )
      {
        summon_spell = e.player->find_spell( 452459 );
        brightstone_spawner.set_creation_callback(
            [ & ]( player_t* ) { return new brightstone_pet_t( e, this, summon_spell ); } );
        brightstone_spawner.set_default_duration( summon_spell->duration() );;
      }

      background = true;
    }

    void execute() override
    {
      generic_proc_t::execute();
      if ( boulderbane )
      {
        boulderbane_spawner.spawn();
      }
      if ( silvervein )
      {
        silvervein_spawner.spawn();
      }
      if ( brightstone )
      {
        brightstone_spawner.spawn();
      }
    }
  };

  e.execute_action = create_proc_action<sigil_of_algari_concordance_t>( "sigil_of_algari_concordance", e );
  new dbc_proc_callback_t( e.player, e );
}
}  // namespace sigil_of_algari_concordance

// Skarmorak Shard
// 443407 Main Buff & Driver
// 449792 Stacking Buff
void skarmorak_shard( special_effect_t& e )
{
  auto main_buff = create_buff<stat_buff_t>( e.player, e.driver() )
                       ->add_stat_from_effect_type( A_MOD_RATING, e.driver()->effectN( 1 ).average( e ) );

  auto on_kill_buff = create_buff<stat_buff_t>( e.player, e.player->find_spell( 449792 ) )
                          ->add_stat_from_effect_type( A_MOD_RATING, e.player->find_spell( 449792 )->effectN( 1 ).average( e ) );

  e.player->register_on_kill_callback( [ e, on_kill_buff ]( player_t* ) {
    if ( !e.player->sim->event_mgr.canceled )
      on_kill_buff->trigger();
  } );

  e.custom_buff = main_buff;
}

// Void Pactstone
// 443537 Driver
// 450960 Damage
// 450962 Buff
void void_pactstone( special_effect_t& e )
{
  auto buff = create_buff<stat_buff_t>( e.player, e.player->find_spell( 450962 ) )
                  // Will Throw a warning currently, as the mod rating misc_value1 is empty. Does not work in game either.
                  ->add_stat_from_effect_type( A_MOD_RATING, e.driver()->effectN( 2 ).average( e ) );

  auto damage         = create_proc_action<generic_aoe_proc_t>( "void_pulse", e, 450960 );
  damage->base_dd_min = damage->base_dd_max = e.driver()->effectN( 1 ).average( e );
  damage->base_multiplier *= role_mult( e );
  damage->split_aoe_damage = true;

  e.custom_buff    = buff;
  e.execute_action = damage;
  new dbc_proc_callback_t( e.player, e );
}

// Ravenous Honey Buzzer
// 448904 Driver
// 448903 Trigger, forced movement
// 448909 Damage
// TODO: implement possible lost uptime from forced movement
void ravenous_honey_buzzer( special_effect_t& e )
{
  struct ravenous_honey_buzzer_t : public generic_aoe_proc_t
  {
    timespan_t movement_dur;

    ravenous_honey_buzzer_t( const special_effect_t& e )
      : generic_aoe_proc_t( e, "ravenous_honey_buzzer", e.player->find_spell( 448909 ) ),
        movement_dur( timespan_t::from_seconds( e.trigger()->missile_speed() ) )
    {
      base_multiplier *= role_mult( e );
    }

    void execute() override
    {
      generic_aoe_proc_t::execute();

      // TODO: implement possible lost uptime from forced movement
      player->buffs.movement->trigger( movement_dur );
    }
  };

  e.execute_action = create_proc_action<ravenous_honey_buzzer_t>( "ravenous_honey_buzzer", e );
}

// Overclocked Gear-a-rang Launcher
// 443411 Use Driver
// 446764 Equip Driver
// 446811 Use Damage
// 449842 Ground Effect Trigger
// 449828 Equip Damage
// 450453 Equip Buff
// TODO: stagger travel time on targets to simulate the blade movement
void overclocked_geararang_launcher( special_effect_t& e )
{
  struct overclocked_strike_cb_t : public dbc_proc_callback_t
  {
    buff_t* buff;
    action_t* overclock_strike;

    overclocked_strike_cb_t( const special_effect_t& e, buff_t* buff, action_t* strike )
      : dbc_proc_callback_t( e.player, e ), buff( buff ), overclock_strike( strike )
    {
    }

    void execute( const spell_data_t*, player_t* t, action_state_t* ) override
    {
      buff->expire();
      overclock_strike->execute_on_target( t );
    }
  };

  struct overclock_cb_t : public dbc_proc_callback_t
  {
    buff_t* buff;
    cooldown_t* item_cd;
    cooldown_t* shared_trinket_cd;
    const spell_data_t* equip_driver;

    overclock_cb_t( const special_effect_t& e, const special_effect_t& use, buff_t* buff )
      : dbc_proc_callback_t( e.player, e ),
        buff( buff ),
        item_cd( e.player->get_cooldown( use.cooldown_name() ) ),
        shared_trinket_cd( e.player->get_cooldown( "item_cd_" + util::to_string( use.driver()->category() ) ) ),
        equip_driver( e.driver() )
    {
    }

    void execute( const spell_data_t*, player_t*, action_state_t* ) override
    {
      item_cd->adjust( timespan_t::from_seconds( -equip_driver->effectN( 1 ).base_value() ) );
      if ( listener->bugs )
      {
        shared_trinket_cd->adjust( timespan_t::from_seconds( -equip_driver->effectN( 1 ).base_value() ) );
      }
      buff->trigger();
    }
  };

  struct geararang_serration_t : public generic_proc_t
  {
    geararang_serration_t( const special_effect_t& e ) : generic_proc_t( e, "geararang_serration", 446811 )
    {
      aoe = -1;
      radius = e.driver()->effectN( 1 ).radius();
      base_multiplier *= role_mult( e );
      chain_multiplier = 0.95;  // not in spell data
      // TODO: stagger travel time on targets to simulate the blade movement
      range = 30;
      travel_speed = 20;  // guessed ~1.5s to reach max range of ~30yd
    }

    std::vector<player_t*>& target_list() const override
    {
      // to simulate mobs not always grouping up in the exact same order, re-create the target list every time.
      available_targets( target_cache.list );
      player->rng().shuffle( target_cache.list.begin(), target_cache.list.end() );

      // duplicate the list add in reverse to simulate the blade going out then returning
      std::vector<player_t*> tmp_tl = target_cache.list;  // make a copy

      while ( !tmp_tl.empty() )
      {
        target_cache.list.push_back( tmp_tl.back() );
        tmp_tl.pop_back();
      }

      return target_cache.list;
    }
  };

  unsigned equip_id = 446764;
  auto equip        = find_special_effect( e.player, equip_id );
  assert( equip && "Overclocked Gear-a-Rang missing equip effect" );

  auto equip_driver = equip->driver();

  auto damage_buff_spell = e.player->find_spell( 450453 );
  auto overclock_buff    = create_buff<buff_t>( e.player, damage_buff_spell );

  auto overclock_strike = create_proc_action<generic_proc_t>( "overclocked_strike", e, e.player->find_spell( 449828 ) );
  overclock_strike->base_dd_min = overclock_strike->base_dd_max = equip_driver->effectN( 2 ).average( e );
  overclock_strike->base_multiplier *= role_mult( e );

  auto damage          = new special_effect_t( e.player );
  damage->name_str     = "overclocked_strike_proc";
  damage->item         = e.item;
  damage->spell_id     = damage_buff_spell->id();
  damage->cooldown_    = 1_ms; // Artificial tiny ICD to prevent double proccing before the buff expires
  damage->proc_flags2_ = PF2_ALL_HIT;
  e.player->special_effects.push_back( damage );

  auto damage_cb = new overclocked_strike_cb_t( *damage, overclock_buff, overclock_strike );
  damage_cb->activate_with_buff( overclock_buff, true );

  auto overclock      = new special_effect_t( e.player );
  overclock->name_str = "overclock";
  overclock->item     = e.item;
  overclock->spell_id = equip_driver->id();
  e.player->special_effects.push_back( overclock );

  auto overclock_cb = new overclock_cb_t( *overclock, e, overclock_buff );
  overclock_cb->initialize();
  overclock_cb->activate();

  e.execute_action = create_proc_action<geararang_serration_t>( "geararang_serration", e );
  e.execute_action->add_child( overclock_strike );
}

// Remnant of Darkness
// 443530 Driver
// 451369 Buff
// 452032 Damage
// 451602 Transform Buff
void remnant_of_darkness( special_effect_t& e )
{
  auto damage         = create_proc_action<generic_aoe_proc_t>( "dark_swipe", e, 452032 );
  damage->base_dd_min = damage->base_dd_max = e.driver()->effectN( 2 ).average( e );
  damage->base_multiplier *= role_mult( e );

  auto transform_buff = create_buff<buff_t>( e.player, e.player->find_spell( 451602 ) )
                            ->set_tick_callback( [ damage ]( buff_t*, int, timespan_t ) { damage->execute(); } );

  auto stat_buff = create_buff<stat_buff_t>( e.player, e.player->find_spell( 451369 ) )
                       ->add_stat_from_effect_type( A_MOD_STAT, e.driver()->effectN( 1 ).average( e ) )
                       ->set_stack_change_callback( [ transform_buff ]( buff_t* b, int, int ) {
                         if ( b->at_max_stacks() )
                         {
                           transform_buff->trigger();
                         }
                       } );

  transform_buff->set_expire_callback( [ stat_buff ]( buff_t*, int, timespan_t ) { stat_buff->expire(); } );

  e.custom_buff = stat_buff;
  new dbc_proc_callback_t( e.player, e );
}

// Opressive Orator's Larynx
// 443552 Use Driver
// 446787 Equip Driver
// 451011 Buff
// 451015 Damage
void opressive_orators_larynx( special_effect_t& e )
{
  struct dark_oration_t : public generic_aoe_proc_t
  {
    double mult;
    dark_oration_t( const special_effect_t& e, const spell_data_t* equip_driver )
      : generic_aoe_proc_t( e, "oppressive_oration_damage", e.player->find_spell( 451015 ), false ), mult( 0 )
    {
      background = dual = true;
      base_dd_min = base_dd_max = equip_driver->effectN( 2 ).average( e );
      base_multiplier *= role_mult( e );
    }

    double composite_da_multiplier( const action_state_t* state ) const override
    {
      double m = generic_proc_t::composite_da_multiplier( state );

      m *= 1.0 + mult;

      return m;
    }
  };

  struct dark_oration_tick_t : public generic_proc_t
  {
    buff_t* buff;
    action_t* damage;
    double increase_per_stack;
    dark_oration_tick_t( const special_effect_t& e, buff_t* buff, action_t* damage )
      : generic_proc_t( e, "oppressive_oration", e.driver() ), buff( buff ), damage( damage ), increase_per_stack( 0 )
    {
      background         = true;
      tick_action        = damage;
      increase_per_stack = 0.25;  // Found through testing, doesnt appear to be in data
    }

    void execute() override
    {
      debug_cast<dark_oration_t*>( damage )->mult = buff->stack() * increase_per_stack;
      buff->expire();
      generic_proc_t::execute();
    }
  };

  unsigned equip_id = 446787;
  auto equip_effect = find_special_effect( e.player, equip_id );
  assert( equip_effect && "Oppressive Orator's Larynx missing equip effect" );

  auto equip_driver = equip_effect->driver();

  auto buff = create_buff<stat_buff_t>( e.player, e.player->find_spell( 451011 ) )
                  ->add_stat_from_effect_type( A_MOD_STAT, equip_driver->effectN( 1 ).average( e ) )
                  ->set_stack_behavior( buff_stack_behavior::ASYNCHRONOUS );

  auto equip         = new special_effect_t( e.player );
  equip->name_str    = "dark_orators_larynx";
  equip->item        = e.item;
  equip->spell_id    = equip_driver->id();
  equip->custom_buff = buff;
  e.player->special_effects.push_back( equip );

  auto equip_cb = new dbc_proc_callback_t( e.player, *equip );
  equip_cb->initialize();
  equip_cb->activate();

  auto damage        = create_proc_action<dark_oration_t>( "oppressive_oration_damage", e, equip_driver );
  auto ticking_spell = create_proc_action<dark_oration_tick_t>( "oppressive_oration", e, buff, damage );

  e.execute_action = ticking_spell;
}

// Ara-Kara Sacbrood
// 443541 Driver
// 452146 Buff
// 452226 Spiderling Buff
// 452227 Spiderfling Missile
// 452229 Damage
void arakara_sacbrood( special_effect_t& e )
{
  struct spiderfling_cb_t : public dbc_proc_callback_t
  {
    action_t* damage;
    action_t* missile;
    buff_t* buff;
    spiderfling_cb_t( const special_effect_t& e, buff_t* buff )
      : dbc_proc_callback_t( e.player, e ), damage( nullptr ), missile( nullptr ), buff( buff )
    {
      damage                 = create_proc_action<generic_proc_t>( "spidersting", e, e.player->find_spell( 452229 ) );
      damage->base_td        = e.player->find_spell( 443541 )->effectN( 2 ).average( e );
      damage->base_multiplier *= role_mult( e.player, e.player->find_spell( 443541 ) );
      missile                = create_proc_action<generic_proc_t>( "spiderfling", e, e.player->find_spell( 452227 ) );
      missile->impact_action = damage;
    }

    void execute( const spell_data_t*, player_t* t, action_state_t* ) override
    {
      missile->execute_on_target( t );
      buff->decrement();
    }
  };

  // In game this buff seems to stack infinitely, while data suggests 1 max stack.
  auto spiderling_buff = create_buff<buff_t>( e.player, e.player->find_spell( 452226 ) )
                         ->set_max_stack( 99 );

  auto spiderling      = new special_effect_t( e.player );
  spiderling->name_str = "spiderling";
  spiderling->item     = e.item;
  spiderling->spell_id = 452226;
  e.player->special_effects.push_back( spiderling );

  auto spiderling_cb = new spiderfling_cb_t( *spiderling, spiderling_buff );
  spiderling_cb->activate_with_buff( spiderling_buff, true );

  auto buff = create_buff<stat_buff_t>( e.player, e.player->find_spell( 452146 ) )
                  ->add_stat_from_effect_type( A_MOD_STAT, e.driver()->effectN( 1 ).average( e ) )
                  ->set_stack_behavior( buff_stack_behavior::ASYNCHRONOUS )
                  ->set_stack_change_callback( [ spiderling_buff ]( buff_t*, int old_, int new_ ) {
                    if ( old_ > new_ )
                    {
                      spiderling_buff->trigger();
                    }
                  } );

  e.custom_buff = buff;
  new dbc_proc_callback_t( e.player, e );
}

// Skyterror's Corrosive Organ
// 444489 Use Driver
// 444488 Equip Driver
// 447471 DoT
// 447495 AoE damage
void skyterrors_corrosive_organ( special_effect_t& e )
{
  struct volatile_acid_splash_t : public generic_proc_t
  {
    action_t* dot;
    volatile_acid_splash_t( const special_effect_t& e, const spell_data_t* equip_driver, action_t* dot )
      : generic_proc_t( e, "volatile_acid_splash", e.player->find_spell( 447495 ) ), dot( dot )
    {
      background       = true;
      aoe              = data().max_targets();
      split_aoe_damage = false;
      base_dd_min = base_dd_max = equip_driver->effectN( 2 ).average( e );
      base_multiplier *= role_mult( e );
    }

    double composite_da_multiplier( const action_state_t* s ) const override
    {
      double m = generic_proc_t::composite_da_multiplier( s );

      m *= dot->get_dot( s->target )->current_stack();

      return m;
    }

    // Doesnt hit the target that triggered the effect
    size_t available_targets( std::vector<player_t*>& tl ) const override
    {
      generic_proc_t::available_targets( tl );

      auto it = range::find( tl, target );
      if ( it != tl.end() )
      {
        tl.erase( it );
      }

      return tl.size();
    }
  };

  unsigned equip_id = 444488;
  auto equip        = find_special_effect( e.player, equip_id );
  assert( equip && "Skyterror's Corrosive Organ missing equip effect" );

  auto equip_driver   = equip->driver();
  auto dot            = create_proc_action<generic_proc_t>( "volatile_acid", e, 447471 );
  auto aoe_damage     = create_proc_action<volatile_acid_splash_t>( "volatile_acid_splash", e, equip_driver, dot );
  dot->dot_behavior   = DOT_NONE;  // Doesnt Refresh, just stacks
  dot->base_td        = equip_driver->effectN( 1 ).average( e ) * role_mult( e );
  dot->execute_action = aoe_damage;
  dot->add_child( aoe_damage );

  auto volatile_acid            = new special_effect_t( e.player );
  volatile_acid->name_str       = "volatile_acid";
  volatile_acid->spell_id       = equip_driver->id();
  volatile_acid->execute_action = dot;
  e.player->special_effects.push_back( volatile_acid );

  auto volatile_acid_proc = new dbc_proc_callback_t( e.player, *volatile_acid );
  volatile_acid_proc->initialize();
  volatile_acid_proc->activate();

  e.player->callbacks.register_callback_trigger_function(
      volatile_acid->spell_id, dbc_proc_callback_t::trigger_fn_type::CONDITION,
      [ dot ]( auto, const auto&, player_t* t, auto, auto  ) {
        return dot->get_dot( t )->is_ticking();
      } );

  e.execute_action = dot;
}

// 443415 driver
//  e1: trigger damage with delay
//  e2: damage coeff
//  e3: buff coeff
// 450921 damage
// 450922 area trigger
// 451247 buff return missile
// 451248 buff
void high_speakers_accretion( special_effect_t& effect )
{
  struct high_speakers_accretion_t : public generic_proc_t
  {
    struct high_speakers_accretion_damage_t : public generic_aoe_proc_t
    {
      std::vector<player_t*>& targets_hit;

      high_speakers_accretion_damage_t( const special_effect_t& e, std::vector<player_t*>& tl )
        : generic_aoe_proc_t( e, "high_speakers_accretion_damage", 450921 ), targets_hit( tl )
      {
        base_dd_min = base_dd_max = e.driver()->effectN( 2 ).average( e );
        base_multiplier *= role_mult( e );
      }

      void impact( action_state_t* s ) override
      {
        generic_aoe_proc_t::impact( s );

        if ( as<unsigned>( targets_hit.size() ) < 5u && !range::contains( targets_hit, s->target ) )
          targets_hit.emplace_back( s->target );
      }
    };

    ground_aoe_params_t params;
    std::vector<player_t*> targets_hit;

    high_speakers_accretion_t( const special_effect_t& e ) : generic_proc_t( e, "high_speakers_accretion", e.driver() )
    {
      auto damage =
        create_proc_action<high_speakers_accretion_damage_t>( "high_speakers_accretion_damage", e, targets_hit );
      damage->stats = stats;

      auto buff = create_buff<stat_buff_with_multiplier_t>( e.player, e.player->find_spell( 451248 ) );
      buff->add_stat_from_effect_type( A_MOD_STAT, e.driver()->effectN( 3 ).average( e ) );

      params.pulse_time( 1_s )
          .duration( e.trigger()->duration() )
          .action( damage )
          .expiration_callback(
              [ this, buff, delay = timespan_t::from_seconds( e.player->find_spell( 451247 )->missile_speed() ) ](
                  const action_state_t* ) {
                if ( targets_hit.empty() )
                  buff->stat_mul = 1.0;
                else
                  buff->stat_mul = 1.0 + 0.15 * ( as<unsigned>( targets_hit.size() ) - 1u );

                make_event( *sim, delay, [ buff ] { buff->trigger(); } );
              } );

      travel_delay = e.driver()->effectN( 1 ).misc_value1() * 0.001;
    }

    void impact( action_state_t* s ) override
    {
      generic_proc_t::impact( s );

      targets_hit.clear();
      params.start_time( timespan_t::min() ).target( target );  // reset start time
      make_event<ground_aoe_event_t>( *sim, player, params );
    }
  };

  effect.has_use_damage_override = true;
  effect.execute_action = create_proc_action<high_speakers_accretion_t>( "high_speakers_accretion", effect );
}

// 443380 driver
// 449267 fragment spawn
// 449259 fragment duration
// 449254 buff
struct pickup_entropic_skardyn_core_t : public action_t
{
  buff_t* buff = nullptr;
  buff_t* tracker = nullptr;

  pickup_entropic_skardyn_core_t( player_t* p, std::string_view opt )
    : action_t( ACTION_OTHER, "pickup_entropic_skardyn_core", p )
  {
    parse_options( opt );

    s_data_reporting = p->find_spell( 443380 );
    name_str_reporting = "Pickup";

    callbacks = harmful = false;
    trigger_gcd = 0_ms;
  }

  bool ready() override
  {
    return tracker && tracker->check();
  }

  void execute() override
  {
    buff->trigger();
    tracker->decrement();
  }
};

// 443380 driver
// 449267 crystal summon
// 449259 crystal duration
// 449254 buff
// TODO: determine reasonable default values for core pickup delay
void entropic_skardyn_core( special_effect_t& effect )
{
  if ( unique_gear::create_fallback_buffs( effect, { "entropic_skardyn_core", "entropic_reclamation" } ) )
    return;

  struct entropic_skardyn_core_cb_t : public dbc_proc_callback_t
  {
    rng::truncated_gauss_t pickup;
    buff_t* buff;
    buff_t* tracker;
    timespan_t delay;

    entropic_skardyn_core_cb_t( const special_effect_t& e )
      : dbc_proc_callback_t( e.player, e ),
        pickup( e.player->thewarwithin_opts.entropic_skardyn_core_pickup_delay,
                e.player->thewarwithin_opts.entropic_skardyn_core_pickup_stddev ),
        delay( timespan_t::from_seconds( e.trigger()->missile_speed() ) )
    {
      buff = create_buff<stat_buff_t>( e.player, e.player->find_spell( 449254 ) )
        ->add_stat_from_effect_type( A_MOD_STAT, e.driver()->effectN( 1 ).average( e ) );

      tracker = create_buff<buff_t>( e.player, e.trigger()->effectN( 1 ).trigger() )
        ->set_stack_behavior( buff_stack_behavior::ASYNCHRONOUS )
        ->set_max_stack( 6 );  // TODO: 'safe' value for 2 rppm. increase if necessary.

      for ( auto a : e.player->action_list )
      {
        if ( auto pickup_action = dynamic_cast<pickup_entropic_skardyn_core_t*>( a ) )
        {
          pickup_action->buff = buff;
          pickup_action->tracker = tracker;
        }
      }
    }

    void execute( const spell_data_t*, player_t*, action_state_t* ) override
    {
      make_event( *listener->sim, delay, [ this ] {                    // delay for spawn
        tracker->trigger();                                            // trigger tracker
        make_event( *listener->sim, rng().gauss( pickup ), [ this ] {  // delay for pickup
          if ( tracker->check() )                                      // check hasn't been picked up via action
          {
            buff->trigger();
            tracker->decrement();
          }
        } );
      } );
    }
  };

  new entropic_skardyn_core_cb_t( effect );
}

// 443538 driver
//  e1: trigger buff
// 449275 buff
void empowering_crystal_of_anubikkaj( special_effect_t& effect )
{
  std::vector<buff_t*> buffs;

  create_all_stat_buffs( effect, effect.trigger(), 0,
    [ &buffs ]( stat_e, buff_t* b ) { buffs.push_back( b ); } );

  effect.player->callbacks.register_callback_execute_function(
    effect.spell_id, [ buffs ]( const dbc_proc_callback_t* cb, auto, auto, auto ) {
      auto buff = cb->listener->rng().range( buffs );
      for ( auto b : buffs )
      {
        if ( b == buff )
          b->trigger();
        else
          b->expire();
      }
    } );

  new dbc_proc_callback_t( effect.player, effect );
}

// 450561 on-use
// 450641 equip
//  e1: stat coeff
//  e2: damage coeff
// 443539 debuff, damage, damage taken driver
// 450551 buff
// TODO: move vers buff to external/passive/custom buff system
// TODO: determine if attack needs to do damage to proc vers buff
void mereldars_toll( special_effect_t& effect )
{
  unsigned equip_id = 450641;
  auto equip = find_special_effect( effect.player, equip_id );
  assert( equip && "Mereldar's Toll missing equip effect" );

  auto data = equip->driver();

  struct mereldars_toll_t : public generic_proc_t
  {
    int allies;
    target_specific_t<buff_t> buffs;
    const spell_data_t* equip_data;
    const special_effect_t& driver_effect;


    mereldars_toll_t( const special_effect_t& e, const spell_data_t* data )
      : generic_proc_t( e, "mereldars_toll", e.driver() ),
        allies( as<int>( data->effectN( 3 ).base_value() ) ),
        buffs{ false },
        equip_data( data ),
        driver_effect( e )
    {
      target_debuff = e.trigger();

      impact_action = create_proc_action<generic_proc_t>( "mereldars_toll_damage", e, e.trigger() );
      impact_action->base_dd_min = impact_action->base_dd_max = data->effectN( 2 ).average( e );
      impact_action->base_multiplier *= role_mult( e );
      impact_action->stats = stats;

      // Pre-initialise the players own personal buff.
      get_buff( e.player );
    }

    buff_t* get_buff( player_t* buff_player )
    {
      if ( buffs[ buff_player ] )
        return buffs[ buff_player ];

      if ( auto buff = buff_t::find( buff_player, "mereldars_toll", player ) )
      {
        buffs[ buff_player ] = buff;
        return buff;
      }

      auto vers =
          make_buff<stat_buff_t>( actor_pair_t{ buff_player, player }, "mereldars_toll", player->find_spell( 450551 ) )
              ->add_stat_from_effect_type( A_MOD_RATING, equip_data->effectN( 1 ).average( driver_effect ) );

      buffs[ buff_player ] = vers;

      return vers;
    }

    buff_t* create_debuff( player_t* t ) override
    {
      auto debuff = generic_proc_t::create_debuff( t )
        ->set_max_stack( allies )
        ->set_reverse( true );

      auto toll = new special_effect_t( t );
      toll->name_str = "mereldars_toll_debuff";
      toll->spell_id = target_debuff->id();
      toll->disable_action();
      t->special_effects.push_back( toll );

      // TODO: determine if attack needs to do damage to proc vers buff
      t->callbacks.register_callback_execute_function(
        toll->spell_id, [ this, debuff ]( const dbc_proc_callback_t* cb, auto, auto, action_state_t* s ) {
          auto vers = get_buff( s->action->player );
          if ( vers && !vers->check() )
          {
            debuff->trigger();
            if ( cb->listener->rng().roll( cb->listener->thewarwithin_opts.mereldars_toll_ally_trigger_chance ) )
              vers->trigger();
          }
        } );

      auto cb = new dbc_proc_callback_t( t, *toll );
      cb->activate_with_buff( debuff, true );  // init = true as this is during runtime

      return debuff;
    }

    void impact( action_state_t* s ) override
    {
      generic_proc_t::impact( s );

      get_debuff( s->target )->trigger();
    }
  };

  effect.has_use_damage_override = true;
  effect.execute_action = create_proc_action<mereldars_toll_t>( "mereldars_toll", effect, data );
}

// 443527 driver
//  e1: buff trigger + coeff
//  e2: in light coeff
// 451367 buff
// 451368 in light buff
// TODO: determine reasonable default for delay in entering light
void carved_blazikon_wax( special_effect_t& effect )
{
  struct carved_blazikon_wax_cb_t : public dbc_proc_callback_t
  {
    rng::truncated_gauss_t delay;
    rng::truncated_gauss_t remain;
    buff_t* buff;
    buff_t* light;

    carved_blazikon_wax_cb_t( const special_effect_t& e )
      : dbc_proc_callback_t( e.player, e ),
        delay( e.player->thewarwithin_opts.carved_blazikon_wax_enter_light_delay,
               e.player->thewarwithin_opts.carved_blazikon_wax_enter_light_stddev ),
        remain( e.player->thewarwithin_opts.carved_blazikon_wax_stay_in_light_duration,
                e.player->thewarwithin_opts.carved_blazikon_wax_stay_in_light_stddev )
    {
      auto light_spell = e.player->find_spell( 451368 );
      auto buff_spell = e.player->find_spell( 451367 );
      light =
        create_buff<stat_buff_t>( e.player, util::tokenize_fn( light_spell->name_cstr() ) + "_light", light_spell )
          ->add_stat_from_effect_type( A_MOD_RATING, e.driver()->effectN( 2 ).average( e ) )
          ->set_name_reporting( "In Light" );

      buff = create_buff<stat_buff_t>( e.player, buff_spell )
        ->add_stat_from_effect_type( A_MOD_RATING, e.driver()->effectN( 1 ).average( e ) );
    }

    void execute( const spell_data_t*, player_t*, action_state_t* ) override
    {
      buff->trigger();

      auto wait = rng().gauss( delay );
      auto dur = light->buff_duration() - wait;

      if ( remain.mean > 0_ms )
        dur = std::min( dur, rng().gauss( remain ) );

      make_event( *light->sim, wait, [ this, dur ] { light->trigger( dur ); } );
    }
  };

  new carved_blazikon_wax_cb_t( effect );
}

// 443531 on-use, buff
// 450877 equip
//  e1: party coeff
//  e2: buff coeff
// 450882 party buff
// TODO: determine reasonable default for party buff options
// TODO: confirm you can have multiple party buffs at the same time
void signet_of_the_priory( special_effect_t& effect )
{
  unsigned equip_id = 450877;
  auto equip = find_special_effect( effect.player, equip_id );
  assert( equip && "Signet of the Priory missing equip effect" );

  auto data = equip->driver();

  struct signet_of_the_priory_t : public generic_proc_t
  {
    std::unordered_map<stat_e, buff_t*> buffs;
    std::unordered_map<stat_e, buff_t*> party_buffs;

    rng::truncated_gauss_t party_first_use;
    rng::truncated_gauss_t party_use;

    signet_of_the_priory_t( const special_effect_t& e, const spell_data_t* data )
      : generic_proc_t( e, "signet_of_the_priory", e.driver() ),
        party_first_use( 0_ms, e.player->thewarwithin_opts.signet_of_the_priory_party_use_stddev ),
        party_use( e.player->thewarwithin_opts.signet_of_the_priory_party_use_cooldown,
                   e.player->thewarwithin_opts.signet_of_the_priory_party_use_stddev, e.driver()->cooldown() )
    {
      create_all_stat_buffs( e, e.driver(), data->effectN( 2 ).average( e ),
        [ this ]( stat_e s, buff_t* b ) { buffs[ s ] = b; } );

      create_all_stat_buffs( e, e.player->find_spell( 450882 ), data->effectN( 1 ).average( e ),
        [ this ]( stat_e s, buff_t* b ) { party_buffs[ s ] = b; }, false );
    }

    void execute() override
    {
      generic_proc_t::execute();

      buffs.at( util::highest_stat( player, secondary_ratings ) )->trigger();
    }
  };

  effect.disable_buff();
  auto signet = debug_cast<signet_of_the_priory_t*>(
    create_proc_action<signet_of_the_priory_t>( "signet_of_the_priory", effect, data ) );
  effect.execute_action = signet;
  effect.stat           = STAT_ANY_DPS;

  // TODO: determine reasonable default for party buff options
  // TODO: confirm you can have multiple party buffs at the same time
  std::vector<buff_t*> party_buffs;
  auto option = effect.player->thewarwithin_opts.signet_of_the_priory_party_stats;

  for ( auto s : util::string_split<std::string_view>( option, "/" ) )
    if ( auto stat = util::parse_stat_type( s ); stat != STAT_NONE )
      party_buffs.push_back( signet->party_buffs.at( stat ) );

  for ( auto b : party_buffs )
  {
    effect.player->register_combat_begin( [ b, signet ]( player_t* ) {
      make_event( *b->sim, b->rng().gauss( signet->party_first_use ), [ b, signet ] {
        b->trigger();
        make_repeating_event( *b->sim,
          [ b, signet ] { return b->rng().gauss( signet->party_use ); },
          [ b ] { b->trigger(); } );
      } );
    } );
  }
}

// 451055 driver
//  e1: damage coeff
//  e2: buff coeff
// 451292 damage
// 451303 buff
// 443549 summon from back right?
// 451991 summon from back left?
// TODO: determine travel speed to hit target, assuming 5yd/s based on 443549 range/duration
// TODO: determine reasonable delay to intercept
void harvesters_edict( special_effect_t& effect )
{
  auto damage = create_proc_action<generic_aoe_proc_t>( "harvesters_edict", effect, effect.driver(), true );
  damage->base_dd_min = damage->base_dd_max =
    effect.driver()->effectN( 1 ).average( effect );
  damage->base_multiplier *= role_mult( effect );
  // TODO: determine travel speed to hit target, assuming 5yd/s based on 443549 range/duration
  damage->travel_speed = 5.0;

  auto buff = create_buff<stat_buff_t>( effect.player, effect.player->find_spell( 451303 ) )
    ->add_stat_from_effect_type( A_MOD_RATING, effect.driver()->effectN( 2 ).average( effect ) );

  // TODO: determine reasonable delay to intercept
  effect.player->callbacks.register_callback_execute_function(
    effect.spell_id, [ damage, buff ]( const dbc_proc_callback_t* cb, auto, auto, auto ) {
      if ( cb->rng().roll( cb->listener->thewarwithin_opts.harvesters_edict_intercept_chance ) )
        buff->trigger();
      else
        damage->execute();
    } );

  // adjust rppm if harvester's interdiction (455819) is equipped
  if ( find_special_effect( effect.player, 455819 ) )
  {
    effect.rppm_modifier_ =
      effect.player->dbc->real_ppm_modifier( effect.spell_id, effect.player, effect.item->item_level(), 455819 );
  }

  new dbc_proc_callback_t( effect.player, effect );
}

// 443525 driver
//  e1: damage coeff
// 450429 damage
// 450416 unknown, cart travel path?
// 450458 unknown, cart travel path?
// 450459 unknown, cart travel path?
// 450460 unknown, cart travel path?
// TODO: determine travel speed/delay, assuming 7.5yd/s based on summed cart path(?) radius/duration
void conductors_wax_whistle( special_effect_t& effect )
{
  // TODO: confirm damage does not increase per extra target
  auto damage = create_proc_action<generic_aoe_proc_t>( "candle_conductors_collision", effect, 450429, true );
  damage->base_dd_min = damage->base_dd_max = effect.driver()->effectN( 1 ).average( effect );
  damage->base_multiplier *= role_mult( effect );
  // TODO: determine travel speed/delay, assuming 7.5yd/s based on summed cart path(?) radius/duration
  damage->travel_speed = 7.5;

  effect.execute_action = damage;

  new dbc_proc_callback_t( effect.player, effect );
}

// 460469 on use
// 443337 cast spell
//  e1: damage coeff
//  e2: jump speed?
//  e3: unknown
// 448892 damage
// TODO: confirm lightning ball jump speed
void charged_stormrook_plume( special_effect_t& effect )
{
  // TODO: confirm damage does not increase per extra target
  auto damage = create_proc_action<generic_aoe_proc_t>( "charged_stormrook_plume", effect, 448892, true );
  auto cast_spell = effect.player->find_spell( 443337 );
  damage->base_dd_min = damage->base_dd_max = cast_spell->effectN( 1 ).average( effect );
  damage->base_multiplier *= role_mult( effect.player, cast_spell );
  damage->base_execute_time = cast_spell->cast_time();
  // TODO: confirm lightning ball jump speed
  damage->travel_speed = cast_spell->effectN( 2 ).base_value();

  effect.execute_action = damage;
}

// 443556 on use
// 450044 equip
//  e1: damage coeff
//  e2: unknown coeff, dual strike?
// 450157 use window
// 450119 melee damage
// 450151 can ranged strike (2nd)
// 450158 ranged damage
// 450340 ranged speed
// 450162 can dual strike (3rd)
// 450204 unknown
// TODO: add APL action for 2nd & 3rd use if needed. for now assumed to be used asap.
void twin_fang_instruments( special_effect_t& effect )
{
  unsigned equip_id = 450044;
  auto equip = find_special_effect( effect.player, equip_id );
  assert( equip && "Twin Fang Instruments missing equip effect" );

  auto data = equip->driver();

  struct twin_fang_instruments_t : public generic_proc_t
  {
    action_t* melee;
    action_t* range;
    timespan_t delay = 2_s;  // not in spell data

    twin_fang_instruments_t( const special_effect_t& e, const spell_data_t* data )
      : generic_proc_t( e, "twin_fang_instruments", e.driver() )
    {
      melee = create_proc_action<generic_aoe_proc_t>( "nxs_shadow_strike", e, e.player->find_spell( 450119 ) );
      melee->base_dd_min = melee->base_dd_max = data->effectN( 1 ).average( e ) * 0.5;
      melee->base_multiplier *= role_mult( e );
      melee->split_aoe_damage = false;
      add_child( melee );

      range = create_proc_action<generic_aoe_proc_t>( "vxs_frost_slash", e, e.player->find_spell( 450158 ), true );
      range->base_dd_min = range->base_dd_max = data->effectN( 1 ).average( e );
      range->base_multiplier *= role_mult( e );
      range->travel_speed = range->data().effectN( 3 ).trigger()->missile_speed();
      add_child( range );
    }

    void execute() override
    {
      generic_proc_t::execute();

      // TODO: add APL action for 2nd & 3rd use if needed. for now assumed to be used asap.
      melee->execute_on_target( target );

      make_event( *sim, delay, [ this ] {
        range->execute_on_target( target );
      } );

      make_event( *sim, delay * 2, [ this ] {
        melee->execute_on_target( target );
        range->execute_on_target( target );
      } );
    }
  };

  effect.has_use_damage_override = true;
  effect.execute_action = create_proc_action<twin_fang_instruments_t>( "twin_fang_instruments", effect, data );
}

// 463610 trinket equip
// 463232 embellishment equip
//  e1: trigger cycle
//  e2: buff coeff
// 455535 cycle
// 455536 buff
// 455537 self damage
// TODO: determine if self damage procs anything
void darkmoon_deck_symbiosis( special_effect_t& effect )
{
  bool is_embellishment = effect.spell_id == 463232;

  struct symbiosis_buff_t : public stat_buff_t
  {
    event_t* ev = nullptr;
    action_t* self_damage;
    timespan_t period;
    double self_damage_pct;

    symbiosis_buff_t( const special_effect_t& e )
      : stat_buff_t( e.player, "symbiosis", e.player->find_spell( 455536 ) ),
        period( e.player->find_spell( 455535 )->effectN( 1 ).period() )
    {
      self_damage = create_proc_action<generic_proc_t>( "symbiosis_self", e, 455537 );

      // We don't want this counted towards our dps
      // TODO: confirm this can trigger damage taken procs
      // TODO: confirm this cannot trigger damage done procs
      self_damage->stats->type = stats_e::STATS_NEUTRAL;
      self_damage->caster_callbacks = false;
      self_damage->target = player;
      self_damage_pct = self_damage->data().effectN( 1 ).percent();
    }

    void start_symbiosis()
    {
      ev = make_event( *player->sim, period, [ this ] { tick_symbiosis(); } );
    }

    void tick_symbiosis()
    {
      self_damage->execute_on_target( player, player->resources.max[ RESOURCE_HEALTH ] * self_damage_pct );
      trigger();
      ev = make_event( *player->sim, period, [ this ] { tick_symbiosis(); } );
    }

    void cancel_symbiosis()
    {
      if ( ev )
        event_t::cancel( ev );
    }
  };

  auto buff = buff_t::find( effect.player, "symbiosis" );
  symbiosis_buff_t* symbiosis = nullptr;

  if ( !buff )
  {
    buff      = make_buff<symbiosis_buff_t>( effect );
    symbiosis = debug_cast<symbiosis_buff_t*>( buff );
    effect.player->register_on_combat_state_callback( [ symbiosis ]( player_t*, bool c ) {
      if ( c )
        symbiosis->start_symbiosis();
      else
        symbiosis->cancel_symbiosis();
    } );
  }
  else
  {
    symbiosis = debug_cast<symbiosis_buff_t*>( buff );
  }

  double value = effect.driver()->effectN( 2 ).average( effect );
  if ( is_embellishment )
    value *= writhing_mul( effect.player );

  symbiosis->add_stat_from_effect_type( A_MOD_RATING, value );
}

// 454859 rppm data
// 454857 card driver/values
// 463611 embellish values (11.0.5 only)
// 454862 fire
// 454975 shadow
// 454976 nature
// 454977 frost
// 454978 holy
// 454979 arcane
// 454980 Physical
// 454982 Magical Multischool
void darkmoon_deck_vivacity( special_effect_t& effect )
{
  struct vivacity_cb_t : public dbc_proc_callback_t
  {
    buff_t* impact;
    buff_t* shadow;
    buff_t* nature;
    buff_t* frost;
    buff_t* holy;
    buff_t* arcane;
    buff_t* force;
    buff_t* magical_multi;

    vivacity_cb_t( const special_effect_t& e, const spell_data_t* values )
      : dbc_proc_callback_t( e.player, e ),
        impact( nullptr ),
        shadow( nullptr ),
        nature( nullptr ),
        frost( nullptr ),
        holy( nullptr ),
        arcane( nullptr ),
        force( nullptr ),
        magical_multi( nullptr )
    {
      impact = create_buff<stat_buff_t>( e.player, e.player->find_spell( 454862 ) )
        ->add_stat_from_effect( 1, values->effectN( 1 ).average( e ) )
        ->add_stat_from_effect( 2, values->effectN( 2 ).average( e ) );

      shadow = create_buff<stat_buff_t>( e.player, e.player->find_spell( 454975 ) )
        ->add_stat_from_effect( 1, values->effectN( 1 ).average( e ) )
        ->add_stat_from_effect( 2, values->effectN( 2 ).average( e ) );

      nature = create_buff<stat_buff_t>( e.player, e.player->find_spell( 454976 ) )
        ->add_stat_from_effect( 1, values->effectN( 1 ).average( e ) )
        ->add_stat_from_effect( 2, values->effectN( 2 ).average( e ) );

      frost = create_buff<stat_buff_t>( e.player, e.player->find_spell( 454977 ) )
        ->add_stat_from_effect( 1, values->effectN( 1 ).average( e ) )
        ->add_stat_from_effect( 2, values->effectN( 2 ).average( e ) );

      holy = create_buff<stat_buff_t>( e.player, e.player->find_spell( 454978 ) )
        ->add_stat_from_effect( 1, values->effectN( 1 ).average( e ) )
        ->add_stat_from_effect( 2, values->effectN( 2 ).average( e ) );

      arcane = create_buff<stat_buff_t>( e.player, e.player->find_spell( 454979 ) )
        ->add_stat_from_effect( 1, values->effectN( 1 ).average( e ) )
        ->add_stat_from_effect( 2, values->effectN( 2 ).average( e ) );

      force = create_buff<stat_buff_t>( e.player, e.player->find_spell( 454980 ) )
        ->add_stat_from_effect( 1, values->effectN( 1 ).average( e ) )
        ->add_stat_from_effect( 2, values->effectN( 2 ).average( e ) );

      magical_multi = create_buff<stat_buff_t>( e.player, e.player->find_spell( 454982 ) )
        ->add_stat_from_effect( 1, values->effectN( 1 ).average( e ) )
        ->add_stat_from_effect( 2, values->effectN( 2 ).average( e ) );
    }

    void execute( const spell_data_t* s_data, player_t*, action_state_t* ) override
    {
      switch ( s_data->get_school_type() )
      {
        case SCHOOL_FIRE:
          impact->trigger();
          break;
        case SCHOOL_SHADOW:
          shadow->trigger();
          break;
        case SCHOOL_NATURE:
          nature->trigger();
          break;
        case SCHOOL_FROST:
          frost->trigger();
          break;
        case SCHOOL_HOLY:
          holy->trigger();
          break;
        case SCHOOL_ARCANE:
          arcane->trigger();
          break;
        case SCHOOL_PHYSICAL:
          force->trigger();
          break;
        default:
          magical_multi->trigger();
          break;
      }
    }
  };

  auto data = effect.driver();
  effect.spell_id = 454859;

  effect.proc_flags2_ = PF2_ALL_HIT | PF2_PERIODIC_DAMAGE;

  new vivacity_cb_t( effect, data );
}

void algari_alchemist_stone( special_effect_t& e )
{
  auto stat = e.player->convert_hybrid_stat( STAT_STR_AGI_INT );
  const spell_data_t* buff_spell;
  switch ( stat )
  {
    case STAT_STRENGTH:
      buff_spell = e.player->find_spell( 299788 );
      break;
    case STAT_AGILITY:
      buff_spell = e.player->find_spell( 299789 );
      break;
    default:
      buff_spell = e.player->find_spell( 299790 );
      break;
  }

  auto buff = create_buff<stat_buff_t>( e.player, buff_spell )
    ->add_stat_from_effect( 1, e.driver()->effectN( 1 ).average( e ) );

  e.custom_buff = buff;
  new dbc_proc_callback_t( e.player, e );
}

// Darkmoon Deck Ascension
// 463095 Trinket Driver
// 458573 Embelishment Driver
// 457594 Periodic Trigger Buff
// 458502 Crit Buff
// 458503 Haste Buff
// 458525 Mastery Buff
// 458524 Vers Buff
void darkmoon_deck_ascension( special_effect_t& effect )
{
  bool is_embellishment = effect.spell_id == 458573;

  struct ascension_tick_t : public buff_t
  {
    std::vector<buff_t*> buff_list;
    buff_t* last_buff;
    unsigned stack;
    bool in_combat;

    ascension_tick_t( const special_effect_t& e, std::string_view n, const spell_data_t* s, bool embellish )
      : buff_t( e.player, n, s ), buff_list(), last_buff( nullptr ), stack( 0 ), in_combat( false )
    {
      add_stats( e, embellish );
      last_buff = buff_list[ 0 ];
      // refreshes if in combat on tick, otherwise buff expires naturally
      set_tick_callback( [ & ]( buff_t*, int, timespan_t ) {
        if ( in_combat )
          trigger_ascension();
        // Ticking stops if out of combat
        else
          make_event( *player->sim, 0_ms, [ & ] { expire(); } );
      } );
    }

    void add_stats( const special_effect_t& e, bool embellish )
    {
      static constexpr std::pair<unsigned, const char*> buff_entries[] = {
        { 458502, "Crit"    },
        { 458503, "Haste"   },
        { 458525, "Mastery" },
        { 458524, "Vers"    }
      };

      for ( const auto& [ id, stat ] : buff_entries )
      {
        auto s_data = e.player->find_spell( id );
        double value = 0;
        if ( embellish )
          value = e.driver()->effectN( 2 ).average( e ) * writhing_mul( e.player );
        else
          value = e.player->find_spell( 463059 )->effectN( 1 ).average( e );

        auto buff = create_buff<stat_buff_t>( e.player, fmt::format( "{}_{}", s_data->name_cstr(), stat ), s_data )
          ->add_stat_from_effect_type( A_MOD_RATING, value )
          ->set_name_reporting( stat );

        buff_list.push_back( buff );
      }
    }

    void trigger_ascension()
    {
      if ( stack < as<unsigned>( data().effectN( 1 ).base_value() ) )
      {
        if ( last_buff->check() && stack > 0 )
        {
          stack = last_buff->check() + 1;
        }
        else
        {
          ++stack;
        }
      }

      rng().shuffle( buff_list.begin(), buff_list.end() );

      if ( buff_list[ 0 ] == last_buff )
      {
        buff_list[ 0 ]->trigger();
      }
      else
      {
        if ( last_buff->check() )
        {
          last_buff->expire();
        }
        buff_list[ 0 ]->trigger( stack );
        last_buff = buff_list[ 0 ];
      }
    }

    void reset() override
    {
      buff_t::reset();
      stack = 0;
    }

    void start( int stacks, double value, timespan_t duration ) override
    {
      buff_t::start( stacks, value, duration );
      stack = 0;
    };

    void expire_override( int stacks, timespan_t duration ) override
    {
      buff_t::expire_override( stacks, duration );
      stack = 0;
    }
  };

  auto buff_name = "ascendance_darkmoon";
  auto buff = buff_t::find( effect.player, buff_name );
  if ( buff )
  {
    debug_cast<ascension_tick_t*>( buff )->add_stats( effect, is_embellishment );
    return;
  }

  buff = make_buff<ascension_tick_t>( effect, buff_name, effect.player->find_spell( 457594 ), is_embellishment );
  effect.name_str = "ascendance_darkmoon";
  effect.player->register_on_combat_state_callback( [ buff ]( player_t*, bool c ) {
    if ( c )
    {
      if ( !buff->check() )
      {
        buff->trigger();
      }

      debug_cast<ascension_tick_t*>( buff )->in_combat = true;
    }
    else
    {
      debug_cast<ascension_tick_t*>( buff )->in_combat = false;
    }
  } );
}

// Darkmoon Deck Radiance
// 463108 Trinket Driver
// 454558 Embelishment Driver
// 454560 Debuff/Accumulator
// 454785 Buff
// 454559 RPPM data
void darkmoon_deck_radiance( special_effect_t& effect )
{
  struct radiant_focus_debuff_t : public buff_t
  {
    double accumulated_damage;
    double max_damage;
    buff_t* buff;

    radiant_focus_debuff_t( actor_pair_t td, const special_effect_t& e, std::string_view n, const spell_data_t* s,
                            buff_t* b )
      : buff_t( td, n, s ), accumulated_damage( 0 ), max_damage( data().effectN( 1 ).average( e ) ), buff( b )
    {
      set_default_value( max_damage );
    }

    void reset() override
    {
      buff_t::reset();
      accumulated_damage = 0;
    }

    void start( int stacks, double value, timespan_t duration ) override
    {
      buff_t::start( stacks, value, duration );
      accumulated_damage = 0;
    };

    void expire_override( int stacks, timespan_t duration ) override
    {
      buff_t::expire_override( stacks, duration );
      double buff_value = std::min( 1.0, std::max( 0.5, accumulated_damage / max_damage ) ) * buff->default_value;

      auto stat_buff = debug_cast<stat_buff_t*>( buff );

      for ( auto& s : stat_buff->stats )
      {
        if ( s.stat == util::highest_stat( source, secondary_ratings ) )
        {
          s.amount = buff_value;
        }
        else
        {
          s.amount = 0;
        }
      }

      buff->trigger();

      accumulated_damage = 0;
    }
  };

  struct radiant_focus_cb_t : public dbc_proc_callback_t
  {
    const spell_data_t* debuff_spell;
    const special_effect_t& effect;
    buff_t* buff;

    radiant_focus_cb_t( const special_effect_t& e, buff_t* b )
      : dbc_proc_callback_t( e.player, e ), debuff_spell( e.player->find_spell( 454560 ) ), effect( e ), buff( b )
    {
      effect.player->callbacks.register_callback_execute_function(
          454560, [ & ]( auto, auto, player_t* t, const action_state_t* s ) {
            auto target_debuff = get_debuff( t );
            if ( s && s->result_amount > 0 && target_debuff->check() )
            {
              auto debuff = debug_cast<radiant_focus_debuff_t*>( target_debuff );
              debuff->accumulated_damage += s->result_amount;
              if ( debuff->accumulated_damage >= debuff->max_damage )
              {
                target_debuff->expire();
              }
            }
          } );

      effect.player->callbacks.register_callback_trigger_function(
          454560, dbc_proc_callback_t::trigger_fn_type::CONDITION,
          [ & ]( auto, const auto&, player_t* t, auto, auto ) {
            return get_debuff( t )->check();
          } );
    }

    buff_t* create_debuff( player_t* t ) override
    {
      auto debuff = make_buff<radiant_focus_debuff_t>( actor_pair_t( t, listener ), effect, "radiant_focus_debuff",
                                                       debuff_spell, buff );

      return debuff;
    }

    void execute( const spell_data_t*, player_t* t, action_state_t* ) override
    {
      auto debuff = get_debuff( t );
      // as of 8/17/2024, does not refresh or expire the debuff if it triggers again while active
      if ( !debuff->check() )
      {
        debuff->trigger();
      }
    }
  };

  auto radiant_focus      = new special_effect_t( effect.player );
  radiant_focus->name_str = "radiant_focus_darkmoon";
  radiant_focus->spell_id = 454560;
  effect.player->special_effects.push_back( radiant_focus );

  auto radiant_focus_proc = new dbc_proc_callback_t( effect.player, *radiant_focus );
  radiant_focus_proc->initialize();
  radiant_focus_proc->activate();

  bool embelish = effect.spell_id == 454558;

  auto buff = buff_t::find( effect.player, "radiance" );
  if ( !buff )
  {
    auto buff_spell = effect.player->find_spell( 454785 );

    // Very oddly setup buff, scripted to provide the highest secondary stat of the player
    // Data doesnt contain the other stats like usual, manually setting things up here.
    buff = create_buff<stat_buff_t>( effect.player, buff_spell )
               ->add_stat( STAT_CRIT_RATING, 0 )
               ->add_stat( STAT_MASTERY_RATING, 0 )
               ->add_stat( STAT_HASTE_RATING, 0 )
               ->add_stat( STAT_VERSATILITY_RATING, 0 );

    if ( embelish )
      buff->set_default_value( effect.driver()->effectN( 2 ).average( effect ) );
    else
      buff->set_default_value( effect.driver()->effectN( 1 ).average( effect ) );
  }
  else if ( buff )
  {
    if ( embelish )
      buff->modify_default_value( effect.driver()->effectN( 2 ).average( effect ) );
    else
      buff->modify_default_value( effect.driver()->effectN( 1 ).average( effect ) );
  }

  effect.spell_id = 454559;
  effect.name_str = "radiant_focus";

  new radiant_focus_cb_t( effect, buff );
}

// Nerubian Pheromone Secreter
// 441023 Driver
// 441428 Buff
// 441508, 441507, 441430 Area Triggers for Phearomone
// Gems:
// 227445 - Mastery, Bonus id 11314
// 227447 - Haste, Bonus id 11315
// 227448 - Crit, Bonus id 11316
// 227449 - Versatility, Bonus id 11317
struct pickup_nerubian_pheromone_t : public action_t
{
  buff_t* orb = nullptr;

  pickup_nerubian_pheromone_t( player_t* p, std::string_view opt )
    : action_t( ACTION_OTHER, "pickup_nerubian_pheromone", p, spell_data_t::nil() )
  {
    parse_options( opt );

    s_data_reporting   = p->find_spell( 441023 );
    name_str_reporting = "Picked up Nerubian Pheromone";

    callbacks = harmful = false;
    trigger_gcd         = 0_ms;
  }

  bool ready() override
  {
    return orb->check();
  }

  void execute() override
  {
    orb->decrement();
  }
};

void nerubian_pheromone_secreter( special_effect_t& effect )
{
  struct nerubian_pheromones_cb_t : public dbc_proc_callback_t
  {
    buff_t* stat_buff;
    buff_t* orb;
    std::vector<action_t*> apl_actions;

    nerubian_pheromones_cb_t( const special_effect_t& e )
      : dbc_proc_callback_t( e.player, e ), stat_buff( nullptr ), orb( nullptr ), apl_actions()
    {
      stat_buff = create_buff<stat_buff_t>( e.player, e.player->find_spell( 441428 ) )
        ->add_stat_from_effect_type( A_MOD_STAT, e.driver()->effectN( 1 ).average( e ) );

      for ( auto& a : e.player->action_list )
      {
        if ( a->name_str == "pickup_nerubian_pheromone" )
        {
          apl_actions.push_back( a );
        }
      }

      if ( apl_actions.size() > 0 )
      {
        orb = create_buff<buff_t>( e.player, e.player->find_spell( 441430 ) )
                  ->set_max_stack( e.player->thewarwithin_opts.nerubian_pheromone_secreter_pheromones )
                  ->set_duration( e.player->find_spell( 441430 )->duration() )
                  ->set_initial_stack( e.player->thewarwithin_opts.nerubian_pheromone_secreter_pheromones )
                  ->set_quiet( true )
                  ->set_expire_callback( [ & ]( buff_t*, int, timespan_t d ) {
                    if ( d > 0_ms )
                    {
                      stat_buff->trigger();
                    }
                  } );
      }

      // Set a default task for the actions ready() function, will be overwritten later
      for ( auto& a : apl_actions )
      {
        debug_cast<pickup_nerubian_pheromone_t*>( a )->orb = orb;
      }
    }

    void execute( const spell_data_t*, player_t*, action_state_t* ) override
    {
      if ( apl_actions.size() > 0 )
      {
        orb->trigger();
      }
      else
      {
        for ( int i = 0; i < listener->thewarwithin_opts.nerubian_pheromone_secreter_pheromones; i++ )
        {
          make_event( *listener->sim, rng().range( 200_ms, listener->find_spell( 441430 )->duration() ),
                      [ & ] { stat_buff->trigger(); } );
        }
      }
    }
  };

  new nerubian_pheromones_cb_t( effect );
}

// Shadowed Essence
// 455640 Driver
// 455643 Periodic Trigger Buff
// 455653 Damage missile
// 455654 Damage
// 455656 Crit Buff
// 455966 Primary Stat Buff
void shadowed_essence( special_effect_t& effect )
{
  struct shadowed_essence_buff_t : public buff_t
  {
    unsigned tick_n = 0;

    shadowed_essence_buff_t( const special_effect_t& e )
      : buff_t( e.player, "shadowed_essence_periodic", e.trigger() ), tick_n( 0 )
    {
      auto shadowed_essence = create_buff<stat_buff_t>( e.player, e.player->find_spell( 455966 ) )
                                  ->add_stat_from_effect_type( A_MOD_STAT, e.driver()->effectN( 2 ).average( e ) );

      auto dark_embrace = create_buff<stat_buff_t>( e.player, e.player->find_spell( 455656 ) )
                              ->add_stat_from_effect_type( A_MOD_RATING, e.driver()->effectN( 3 ).average( e ) );

      auto damage         = create_proc_action<generic_proc_t>( "shadowed_essence", e, 455654 );
      damage->base_dd_min = damage->base_dd_max = e.driver()->effectN( 1 ).average( e );
      damage->base_multiplier *= role_mult( e.player );

      auto missile           = create_proc_action<generic_proc_t>( "shadowed_essence_missile", e, 455653 );
      missile->impact_action = damage;

      set_quiet( true );
      set_tick_on_application( true );
      set_tick_callback( [ &, dark_embrace, shadowed_essence, missile ]( buff_t*, int, timespan_t ) {
        if ( tick_n == 0 )
        {
          dark_embrace->trigger();
        }
        else if ( tick_n % 3 == 0 )
        {
          if ( dark_embrace->check() )
            shadowed_essence->trigger();
          else
            dark_embrace->trigger();
        }
        else
        {
          missile->execute_on_target( e.player->target );
        }
        tick_n++;
      } );
    }

    void start( int stacks, double value, timespan_t duration ) override
    {
      buff_t::start( stacks, value, duration );
      tick_n = 0;
    }

    void expire_override( int stacks, timespan_t duration ) override
    {
      buff_t::expire_override( stacks, duration );
      tick_n = 0;
    }

    void reset() override
    {
      buff_t::reset();
      tick_n = 0;
    }
  };

  auto buff = buff_t::find( effect.player, "shadowed_essence_periodic" );
  if ( !buff )
  {
    buff = make_buff<shadowed_essence_buff_t>( effect );
  }

  effect.player->register_on_combat_state_callback( [ buff ]( player_t*, bool c ) {
    if ( c )
      buff->trigger();
    else
      buff->expire();
  } );
}

// Spelunker's Waning Candle
// 445419 driver
// 445420 buff
// 8-31-24 ally sharing is not functioning in game
void spelunkers_waning_candle( special_effect_t& effect )
{
  effect.custom_buff = create_buff<stat_buff_t>( effect.player, effect.trigger() )
                           ->add_stat_from_effect( 1, effect.driver()->effectN( 2 ).average( effect.item ) );

  new dbc_proc_callback_t( effect.player, effect );
}

// 455436 driver
// 455441 mastery
// 455454 crit
// 455455 haste
// 455456 vers
void unstable_power_core( special_effect_t& effect )
{
  static constexpr std::array<std::pair<unsigned, const char*>, 4> buff_ids = {
      { { 455441, "mastery" }, { 455454, "crit" }, { 455455, "haste" }, { 455456, "vers" } } };

  std::vector<buff_t*> buffs = {};

  auto buff_name = util::tokenize_fn( effect.driver()->name_cstr() );

  for ( const auto& [ id, stat_name ] : buff_ids )
  {
    auto buff  = make_buff<stat_buff_t>( effect.player, fmt::format( "{}_{}", buff_name, stat_name ),
                                        effect.player->find_spell( id ) );

    buff->add_stat_from_effect_type( A_MOD_RATING, effect.driver()->effectN( 1 ).average( effect.item ) );

    buffs.push_back( buff );
  }

  for ( auto& buff : buffs )
  {
    buff->set_expire_callback( [ effect, buffs ]( buff_t*, int, timespan_t remains ) {
      if ( remains > 0_ms )
        return;

      effect.player->rng().range( buffs )->trigger( effect.player->rng().range( 10_s, 30_s ) );
    } );
  }

  effect.player->register_precombat_begin( [ buffs ]( player_t* p ) {
    p->rng().range( buffs )->trigger( p->rng().range( 10_s, 30_s ) );
  } );
}

// 451742 driver
// 451750 buff scaling driver?
// 451748 buff
void stormrider_flight_badge( special_effect_t& effect )
{
  auto buff =
      create_buff<stat_buff_t>( effect.player, "stormrider_flight_badge", effect.driver()->effectN( 2 ).trigger() );
  buff->add_stat_from_effect_type( A_MOD_RATING, effect.driver()->effectN( 1 ).trigger()->effectN( 1 ).average( effect.item ) );

  effect.custom_buff = buff;

  new dbc_proc_callback_t( effect.player, effect );
}

// 435502 driver
// 440389 debuff
void shadowbinding_ritual_knife( special_effect_t& effect )
{
  auto primary_buff = create_buff<stat_buff_t>( effect.player, "shadowbinding_ritual_knife_primary", effect.driver() )
                          ->add_stat_from_effect( 1, effect.driver()->effectN( 1 ).average( effect ) )
                          ->set_chance( 1.0 )
                          ->set_rppm( RPPM_DISABLE )
                          ->set_duration( 0_s )
                          ->set_constant_behavior( buff_constant_behavior::ALWAYS_CONSTANT );

  effect.player->register_combat_begin( [ primary_buff ]( player_t* ) { primary_buff->trigger(); } );

  std::vector<buff_t*> negative_buffs;

  auto buff_spell = effect.driver()->effectN( 2 ).trigger();

  create_all_stat_buffs( effect, buff_spell, effect.driver()->effectN( 2 ).average( effect ),
    [ &negative_buffs ]( stat_e, buff_t* b ) { negative_buffs.push_back( b ); }, false );

  if ( negative_buffs.size() > 0 )
  {
    effect.player->callbacks.register_callback_execute_function(
      effect.spell_id, [ negative_buffs ]( const dbc_proc_callback_t* cb, auto, auto, auto ) {
        cb->listener->rng().range( negative_buffs )->trigger();
      } );
  }

  effect.buff_disabled = true;

  new dbc_proc_callback_t( effect.player, effect );
}

// 455432 Driver
// 455433 Damage Spell
// 455434 Healing Spell
void shining_arathor_insignia( special_effect_t& effect )
{
  // TODO: make it heal players as well
  // TODO: determine if this is affected by role mult
  auto damage_proc         = create_proc_action<generic_proc_t>( "shining_arathor_insignia", effect, 455433 );
  damage_proc->base_dd_min = damage_proc->base_dd_max = effect.driver()->effectN( 1 ).average( effect );

  effect.execute_action = damage_proc;

  new dbc_proc_callback_t( effect.player, effect );
}

// 455451 buff
//  e1: speed
//  e2: haste
void quickwick_candlestick( special_effect_t& effect )
{
  effect.custom_buff = create_buff<stat_buff_t>( effect.player, effect.driver(), effect.item )
    ->set_movement_speed_buff_from_data();
}

// 455435 driver
//  e1: weak light up (455443)
//  e2: weak not so gentle flame (455447)
//  e3: strong light up (455480)
//  e4: strong not so gentle flame (455479)
// 455445 summon waxx (weak light up)
// 455448 summon wayne (weak not so gentle flame)
// 455453 summon take (strong light up, strong not so gentle flame)
// 455443 weak light up
// 455447 weak not so gentle flame
// 455479 strong not so gentle flame
// 455480 strong light up
// TODO: Figure out Takes odd behavior
// Figure out the pets AP/SP coefficients for auto attacking pets
void candle_confidant( special_effect_t& effect )
{
  struct candle_confidant_pet_t : public unique_gear_pet_t
  {
  protected:
    using base_t = candle_confidant_pet_t;

    candle_confidant_pet_t( std::string_view name, const special_effect_t& e, const spell_data_t* summon_spell )
      : unique_gear_pet_t( name, e, summon_spell )
    {
      npc_id = summon_spell->effectN( 1 ).misc_value1();
      use_auto_attack = false;
    }

    void update_stats() override
    {
      unique_gear_pet_t::update_stats();
      // Currently doesnt seem to scale with haste
      if ( owner->bugs )
      {
        current_pet_stats.composite_melee_haste             = 1;
        current_pet_stats.composite_spell_haste             = 1;
        current_pet_stats.composite_melee_auto_attack_speed = 1;
        current_pet_stats.composite_spell_cast_speed        = 1;
      }
    }
  };

  struct auto_attack_melee_t : public melee_attack_t
  {
    auto_attack_melee_t( pet_t* p, std::string_view name = "main_hand", action_t* a = nullptr )
      : melee_attack_t( name, p )
    {
      this->background = this->repeating = true;
      this->not_a_proc = this->may_crit = true;
      this->special                     = false;
      this->weapon_multiplier           = 1.0;
      this->trigger_gcd                 = 0_ms;
      this->school                      = SCHOOL_PHYSICAL;
      this->stats->school               = SCHOOL_PHYSICAL;
      this->base_dd_min = this->base_dd_max = p->dbc->expected_stat( p->true_level ).creature_auto_attack_dps;
      this->base_multiplier                 = p->main_hand_weapon.swing_time.total_seconds();

      auto proxy = a;
      auto it    = range::find( proxy->child_action, name, &action_t::name );
      if ( it != proxy->child_action.end() )
        stats = ( *it )->stats;
      else
        proxy->add_child( this );
    }

    double composite_crit_chance() const override
    {
      // Currently their auto attacks dont seem to scale with player crit chance.
      return this->player->base.attack_crit_chance;
    }

    // They made these guys always miss... rather than fixing their AI.
    double miss_chance( double, player_t* ) const override
    {
      return 1.0;
    }

    // Pet melee attacks seem to still scale with aura 380 and 531
    double composite_da_multiplier( const action_state_t* s ) const override
    {
      double m = melee_attack_t::composite_da_multiplier( s );
      m *= this->player->cast_pet()->owner->cache.pet_damage_multiplier( s, player->type == PLAYER_GUARDIAN );
      return m;
    }

    double composite_target_multiplier( player_t* p ) const override
    {
      double m = melee_attack_t::composite_target_multiplier( p );
      m *= this->player->cast_pet()->owner->composite_player_target_pet_damage_multiplier( p, player->type == PLAYER_GUARDIAN );
      return m;
    }

    void execute() override
    {
      if ( this->player->executing )
        this->schedule_execute();
      else
        melee_attack_t::execute();
    }
  };

  struct candle_confidant_pet_spell_t : public spell_t
  {
    candle_confidant_pet_spell_t( std::string_view n, pet_t* p, const spell_data_t* s, std::string_view options_str,
                                  action_t* a )
      : spell_t( n, p, s )
    {
      auto proxy = a;
      auto it = range::find( proxy->child_action, data().id(), &action_t::id );
      if ( it != proxy->child_action.end() )
        stats = ( *it )->stats;
      else
        proxy->add_child( this );

      parse_options( options_str );
    }
  };

  struct weak_light_up_t : public candle_confidant_pet_spell_t
  {
    weak_light_up_t( const special_effect_t& e, candle_confidant_pet_t* p, std::string_view options_str, action_t* a )
      : candle_confidant_pet_spell_t( "light_up_waxx", p, p->find_spell( 455443 ), options_str, a )
    {
      base_dd_min = base_dd_max = e.driver()->effectN( 1 ).average( e );
      name_str_reporting = "light_up";
    }

    void execute() override
    {
      // Has the odd spell que delay where itll wait a bit before starting the next cast, about 2.75s on average.
      trigger_gcd = base_execute_time + rng().range( 500_ms, 1000_ms );
      candle_confidant_pet_spell_t::execute();
    }
  };

  struct weak_not_so_gentle_flame_t : public candle_confidant_pet_spell_t
  {
    weak_not_so_gentle_flame_t( const special_effect_t& e, candle_confidant_pet_t* p, std::string_view options_str,
                                action_t* a )
      : candle_confidant_pet_spell_t( "notsogentle_flame_wayne", p, p->find_spell( 455447 ), options_str, a )
    {
      base_dd_min = base_dd_max = e.driver()->effectN( 2 ).average( e );
      name_str_reporting = "notsogentle_flame";
    }

    void execute() override
    {
      // Has the odd spell que delay where itll wait a bit before starting the next cast, about 3.2s on average.
      cooldown->duration = 3_s + rng().range( 100_ms, 300_ms );
      candle_confidant_pet_spell_t::execute();
    }
  };

  struct strong_light_up_t : public candle_confidant_pet_spell_t
  {
    strong_light_up_t( const special_effect_t& e, candle_confidant_pet_t* p, std::string_view options_str, action_t* a )
      : candle_confidant_pet_spell_t( "light_up_take", p, p->find_spell( 455480 ), options_str, a )
    {
      base_dd_min = base_dd_max = e.driver()->effectN( 3 ).average( e );
      name_str_reporting = "light_up";
    }

    void execute() override
    {
      // TODO: Take is weird, lots of odd spell queing events, missed casts, and long delays between casts.
      // Figure out exactly whats going on here.
      // https://www.warcraftlogs.com/reports/PNwkxKmn1cgtMYh3#fight=68&type=damage-done&source=289&view=events
      cooldown->duration = 3_s + rng().range( 100_ms, 300_ms );
      candle_confidant_pet_spell_t::execute();
    }
  };

  struct strong_not_so_gentle_flame_t : public candle_confidant_pet_spell_t
  {
    strong_not_so_gentle_flame_t( const special_effect_t& e, candle_confidant_pet_t* p, std::string_view options_str,
                                  action_t* a )
      : candle_confidant_pet_spell_t( "notsogentle_flame_take", p, p->find_spell( 455479 ), options_str, a )
    {
      base_dd_min = base_dd_max = e.driver()->effectN( 4 ).average( e );
      name_str_reporting = "notsogentle_flame";
    }

    void execute() override
    {
      // TODO: Take is weird, lots of odd spell queing events, missed casts, and long delays between casts.
      // Figure out exactly whats going on here.
      // https://www.warcraftlogs.com/reports/PNwkxKmn1cgtMYh3#fight=68&type=damage-done&source=289&view=events
      cooldown->duration = 5_s + rng().range( 100_ms, 300_ms );
      candle_confidant_pet_spell_t::execute();
    }
  };

  struct waxx_pet_t : public candle_confidant_pet_t
  {
    waxx_pet_t( const special_effect_t& e, action_t* parent = nullptr )
      : base_t( "Waxx", e, e.player->find_spell( 455445 ) )
    {
      parent_action = parent;
    }

    action_t* create_action( std::string_view name, std::string_view options_str ) override
    {
      if ( name == "light_up" )
        return new weak_light_up_t( effect, this, options_str, parent_action );

      return base_t::create_action( name, options_str );
    }

    void init_action_list() override
    {
      base_t::init_action_list();
      action_priority_list_t* def = get_action_priority_list( "default" );
      def->add_action( "light_up" );
    }
  };

  struct wayne_pet_t : public candle_confidant_pet_t
  {
    wayne_pet_t( const special_effect_t& e, action_t* parent = nullptr )
      : base_t( "Wayne", e, e.player->find_spell( 455448 ) )
    {
      parent_action = parent;
      use_auto_attack = true;
      main_hand_weapon.type = WEAPON_BEAST;
      main_hand_weapon.swing_time = 2_s;
    }

    attack_t* create_auto_attack() override
    {
      auto a = new auto_attack_melee_t( this, "main_hand_wayne", parent_action );
      a->name_str_reporting = "Melee";
      return a;
    }

    action_t* create_action( std::string_view name, std::string_view options_str ) override
    {
      if ( name == "not_so_gentle_flame" )
        return new weak_not_so_gentle_flame_t( effect, this, options_str, parent_action );

      return base_t::create_action( name, options_str );
    }

    void init_action_list() override
    {
      base_t::init_action_list();
      action_priority_list_t* def = get_action_priority_list( "default" );
      def->add_action( "not_so_gentle_flame" );
    }
  };

  // TODO: Take is weird, lots of odd spell queing events, missed casts, and long delays between casts.
  // Figure out exactly whats going on here.
  // https://www.warcraftlogs.com/reports/PNwkxKmn1cgtMYh3#fight=68&type=damage-done&source=289&view=events
  struct take_pet_t : public candle_confidant_pet_t
  {
    take_pet_t( const special_effect_t& e, action_t* parent = nullptr )
      : base_t( "Take", e, e.player->find_spell( 455453 ) )
    {
      parent_action = parent;
      use_auto_attack = true;
      main_hand_weapon.type = WEAPON_BEAST;
      main_hand_weapon.swing_time = 2_s;
    }

    attack_t* create_auto_attack() override
    {
      auto a = new auto_attack_melee_t( this, "main_hand_take", parent_action );
      a->name_str_reporting = "Melee";
      return a;
    }

    action_t* create_action( std::string_view name, std::string_view options_str ) override
    {
      if ( name == "not_so_gentle_flame" )
        return new strong_not_so_gentle_flame_t( effect, this, options_str, parent_action );
      if ( name == "light_up" )
        return new strong_light_up_t( effect, this, options_str, parent_action );

      return base_t::create_action( name, options_str );
    }

    void init_action_list() override
    {
      base_t::init_action_list();
      action_priority_list_t* def = get_action_priority_list( "default" );
      def->add_action( "not_so_gentle_flame" );
      def->add_action( "light_up" );
    }
  };

  struct candle_confidant_t : public generic_proc_t
  {
    spawner::pet_spawner_t<waxx_pet_t> waxx_spawner;
    spawner::pet_spawner_t<wayne_pet_t> wayne_spawner;
    spawner::pet_spawner_t<take_pet_t> take_spawner;

    candle_confidant_t( const special_effect_t& e )
      : generic_proc_t( e, "candle_confidant", e.driver() ),
        waxx_spawner( "waxx", e.player ),
        wayne_spawner( "wayne", e.player ),
        take_spawner( "take", e.player )
    {
      auto waxx_summon_spell = e.player->find_spell( 455445 );
      auto waxx = new action_t( action_e::ACTION_OTHER, "waxx", e.player, waxx_summon_spell );
      waxx->name_str_reporting = "Waxx";
      waxx_spawner.set_creation_callback( [ &e, waxx ]( player_t* ) { return new waxx_pet_t( e, waxx ); } );
      waxx_spawner.set_default_duration( waxx_summon_spell->duration() );
      add_child( waxx );

      auto wayne_summon_spell = e.player->find_spell( 455448 );
      auto wayne = new action_t( action_e::ACTION_OTHER, "wayne", e.player, wayne_summon_spell );
      wayne->name_str_reporting = "Wayne";
      wayne_spawner.set_creation_callback( [ &e, wayne ]( player_t* ) { return new wayne_pet_t( e, wayne ); } );
      wayne_spawner.set_default_duration( wayne_summon_spell->duration() );
      add_child( wayne );

      auto take_summon_spell = e.player->find_spell( 455453 );
      auto take = new action_t( action_e::ACTION_OTHER, "take", e.player, take_summon_spell );
      take->name_str_reporting = "Take";
      take_spawner.set_creation_callback( [ &e, take ]( player_t* ) { return new take_pet_t( e, take ); } );
      take_spawner.set_default_duration( take_summon_spell->duration() );
      add_child( take );
    }

    void execute() override
    {
      generic_proc_t::execute();
      int pet_id = rng().range( 0, 3 );
      switch ( pet_id )
      {
        case 0:  waxx_spawner.spawn(); break;
        case 1:  wayne_spawner.spawn(); break;
        case 2:  take_spawner.spawn(); break;
        default: break;
      }
    }
  };

  effect.execute_action = create_proc_action<candle_confidant_t>( "candle_confidant", effect );

  new dbc_proc_callback_t( effect.player, effect );
}

// 435493 driver, buff
// 453425 hidden, unused?
// 440235 stun, NYI
void concoction_kiss_of_death( special_effect_t& effect )
{
  if ( unique_gear::create_fallback_buffs( effect, { "concoction_kiss_of_death" } ) )
    return;

  struct concoction_kiss_of_death_buff_t : public stat_buff_t
  {
    concoction_kiss_of_death_buff_t( player_t* p, std::string_view n, const spell_data_t* s, const item_t* i )
      : stat_buff_t( p, n, s, i )
    {
      if ( p->thewarwithin_opts.concoction_kiss_of_death_buff_remaining_max <
           p->thewarwithin_opts.concoction_kiss_of_death_buff_remaining_min )
      {
        sim->error( "thewarwithin.concoction_kiss_of_death_buff_remaining_max must be greater than or equal to "
                    "thewarwithin.concoction_kiss_of_death_buff_remaining_min." );

        p->thewarwithin_opts.concoction_kiss_of_death_buff_remaining_max =
          p->thewarwithin_opts.concoction_kiss_of_death_buff_remaining_min;
      }
    }

    void start( int s, double v, timespan_t d ) override
    {
      if ( d < 0_ms )
      {
        d = ( buff_duration() * get_time_duration_multiplier() ) -
            rng().range( player->thewarwithin_opts.concoction_kiss_of_death_buff_remaining_min,
                         player->thewarwithin_opts.concoction_kiss_of_death_buff_remaining_max );
      }

      stat_buff_t::start( s, v, d );
    }
  };

  // TODO: the driver has two cooldown categories, 1141 for the on-use and 2338 for the charge. currently the generation
  // script prioritizes the charge category so we manually set it here until the script can be adjusted.
  effect.cooldown_category_ = 1141;
  effect.custom_buff = create_buff<concoction_kiss_of_death_buff_t>( effect.player, effect.driver(), effect.item );
}

// 435473 driver
//  e1: coeff
// 440635 stacking counter
// 440645 damage driver
// 440646 damage
void everburning_lantern( special_effect_t& effect )
{
  // setup primary proc driver & counter buff
  auto counter = create_buff<buff_t>( effect.player, effect.player->find_spell( 440635 ) )
    ->set_refresh_behavior( buff_refresh_behavior::DISABLED );

  effect.custom_buff = counter;
  auto cb = new dbc_proc_callback_t( effect.player, effect );

  // setup damage proc callback driver & buff
  auto fireflies = create_buff<buff_t>( effect.player, effect.player->find_spell( 440645 ) )
    ->set_stack_change_callback( [ cb ]( buff_t*, int, int new_ ) {
      if ( new_ )
        cb->deactivate();
      else
        cb->activate();
    } );

  counter->set_expire_callback( [ fireflies ]( buff_t*, int s, timespan_t ) {
    fireflies->trigger( -1, as<double>( s ) );
  } );

  auto on_next = new special_effect_t( effect.player );
  on_next->name_str = fireflies->name();
  on_next->spell_id = fireflies->data().id();
  effect.player->special_effects.push_back( on_next );

  auto damage_cb = new dbc_proc_callback_t( effect.player, *on_next );
  damage_cb->activate_with_buff( fireflies );

  // setup damage
  auto damage = create_proc_action<generic_proc_t>( "fire_flies", effect, 440646 );
  damage->base_dd_min = damage->base_dd_max = effect.driver()->effectN( 1 ).average( effect );
  damage->base_multiplier *= role_mult( effect );

  effect.player->callbacks.register_callback_execute_function( on_next->spell_id,
    [ fireflies, damage ]( auto, auto, player_t* t, auto ) {
      if ( !fireflies->check() )  // prevent extra procs from multi-part hits
        return;

      auto stacks = as<unsigned>( fireflies->check_value() );
      fireflies->expire();

      while ( stacks > 0 )
      {
        damage->execute_on_target( t );
        stacks--;
      }
    } );
}

// 455484 driver
//  e1: coeff
//  e2: unknown
// 455487 damage
void detachable_fang( special_effect_t& effect )
{
  struct gnash_t : public generic_proc_t
  {
    player_t* gnash_target = nullptr;
    unsigned count = 0;

    gnash_t( const special_effect_t& e ) : generic_proc_t( e, "gnash", 455487 )
    {
      base_dd_min = base_dd_max = e.driver()->effectN( 1 ).average( e );
      base_multiplier *= role_mult( e );
    }

    void reset() override
    {
      gnash_target = nullptr;
      count = 1;
    }

    void execute() override
    {
      generic_proc_t::execute();

      if ( count == 3 )
        count = 1;
      else
        count++;
    }

    void set_target( player_t* t ) override
    {
      generic_proc_t::set_target( t );

      if ( !gnash_target || gnash_target != t )
      {
        gnash_target = t;
        count = 1;
      }
    }

    double composite_target_multiplier( player_t* t ) const override
    {
      auto ctm = generic_proc_t::composite_target_multiplier( t );

      if ( count == 3 )
      {
        // These values are not in spell data and may be hard scripted or based on a curve id
        auto hp = t->health_percentage();
        if ( hp < 30 )
          ctm *= 1.5;
        else if ( hp < 60 )
          ctm *= 1.25;
        else if ( hp < 90 )
          ctm *= 1.1;
      }

      return ctm;
    }
  };

  effect.execute_action = create_proc_action<gnash_t>( "gnash", effect );

  new dbc_proc_callback_t( effect.player, effect );

  effect.player->callbacks.register_callback_execute_function( effect.spell_id,
    []( const dbc_proc_callback_t* cb, auto, player_t* t, auto ) {
      if ( cb->listener->get_player_distance( *t ) <= cb->proc_action->range )
        cb->proc_action->execute_on_target( t );
    } );
}

// 459222 driver
// 459224 stacking buff
// 459228 max buff + driver
// 459231 damage
void scroll_of_momentum( special_effect_t& effect )
{
  if ( unique_gear::create_fallback_buffs( effect, { "full_momentum" } ) )
    return;

  // setup stacking buff + driver
  auto counter = create_buff<buff_t>( effect.player, effect.player->find_spell( 459224 ) )
    ->set_movement_speed_buff_from_data()
    ->set_expire_at_max_stack( true );

  effect.custom_buff = counter;

  auto cb = new dbc_proc_callback_t( effect.player, effect );

  // setup max buff
  auto max = create_buff<buff_t>( effect.player, effect.player->find_spell( 459228 ) )
    ->set_movement_speed_buff_from_data()
    ->set_stack_change_callback( [ cb ]( buff_t*, int, int new_ ) {
      if ( new_ )
        cb->deactivate();
      else
        cb->activate();
    } );

  counter->set_expire_callback( [ max ]( buff_t*, int, timespan_t ) {
    max->trigger();
  } );

  // setup damage
  struct high_velocity_impact_t : public generic_proc_t
  {
    high_velocity_impact_t( const special_effect_t& e ) : generic_proc_t( e, "highvelocity_impact", 459231 )
    {
      base_dd_min = base_dd_max = e.driver()->effectN( 1 ).average( e );
      base_multiplier *= role_mult( e );
    }

    double action_multiplier() const override
    {
      // hard scripted values, not in spell data
      return generic_proc_t::action_multiplier() * ( player->composite_movement_speed() + 17 ) * 0.04;
    }
  };

  auto full_momentum = new special_effect_t( effect.player );
  full_momentum->name_str = max->name();
  full_momentum->spell_id = max->data().id();
  full_momentum->execute_action = create_proc_action<high_velocity_impact_t>( "highvelocity_impact", effect );
  effect.player->special_effects.push_back( full_momentum );

  auto damage_cb = new dbc_proc_callback_t( effect.player, *full_momentum );
  damage_cb->activate_with_buff( max );
}

// 442429 driver
// 442801 damage
void wildfire_wick( special_effect_t& effect )
{
  auto dot = create_proc_action<generic_proc_t>( "wildfire_wick", effect, effect.trigger() );
  dot->base_td = effect.driver()->effectN( 1 ).average( effect );
  dot->base_multiplier *= role_mult( effect.player );  // not found on spell desc

  effect.execute_action = dot;

  new dbc_proc_callback_t( effect.player, effect );

  effect.player->callbacks.register_callback_execute_function( effect.spell_id,
    []( const dbc_proc_callback_t* cb, auto, player_t* t, auto ) {
      if ( cb->proc_action->get_dot( t )->is_ticking() )
      {
        if ( auto tnsl = cb->listener->sim->target_non_sleeping_list.data(); tnsl.size() > 1 )  // make a copy
        {
          range::erase_remove( tnsl, t );
          cb->proc_action->execute_on_target( cb->rng().range( tnsl ) );
        }
      }

      cb->proc_action->execute_on_target( t );
    } );
}

// 455452 equip
// 455464 counter buff
// 455467 on-use
void kaheti_shadeweavers_emblem( special_effect_t& effect )
{
  if ( unique_gear::create_fallback_buffs( effect, { "kaheti_shadeweavers_dark_ritual" } ) )
    return;

  struct kaheti_shadeweavers_emblem_t : public generic_proc_t
  {
    buff_t* counter;

    kaheti_shadeweavers_emblem_t( const special_effect_t& e )
      : generic_proc_t( e, "kaheti_shadeweavers_emblem", 455467 )
    {
      base_multiplier *= role_mult( e );

      unsigned equip_id = 455452;
      auto equip = find_special_effect( e.player, equip_id );
      assert( equip && "Kaheti Shadeweaver's Emblem missing equip effect" );

      counter = create_buff<buff_t>( e.player, equip->trigger() );
      equip->custom_buff = counter;

      new dbc_proc_callback_t( e.player, *equip );
    }

    double action_multiplier() const override
    {
      return generic_proc_t::action_multiplier() * counter->check();
    }

    void execute() override
    {
      generic_proc_t::execute();
      counter->expire();
    }
  };

  effect.execute_action = create_proc_action<kaheti_shadeweavers_emblem_t>( "kaheti_shadeweavers_emblem", effect );
}

// 469927 driver
// 469928 damage
// TODO: confirm if rolemult gets implemented in-game
void hand_of_justice( special_effect_t& effect )
{
  auto damage = create_proc_action<generic_proc_t>( "quick_strike", effect, 469928 );
  damage->base_dd_min = damage->base_dd_max = effect.driver()->effectN( 1 ).average( effect );
  damage->base_multiplier *= role_mult( effect );

  effect.execute_action = damage;

  new dbc_proc_callback_t( effect.player, effect );
}

// 469915 driver
//  e1: counter threshold
//  e2: damage coeff
// 469917 counter
// 469918 unknown
// 469919 missile, trigger damage
// 469920 damage
//  e1: damage coeff (unused?)
void golem_gearbox( special_effect_t& effect )
{
  auto counter = create_buff<buff_t>( effect.player, effect.player->find_spell( 469917 ) )
    ->set_max_stack( as<int>( effect.driver()->effectN( 1 ).base_value() ) );

  auto missile = create_proc_action<generic_proc_t>( "torrent_of_flames_missile", effect, 469919 );
  auto damage =
    create_proc_action<generic_proc_t>( "torrent_of_flames", effect, missile->data().effectN( 1 ).trigger() );
  damage->background = true;
  // TODO: confirm driver coeff is used and not damage spell coeff
  damage->base_dd_min = damage->base_dd_max = effect.driver()->effectN( 2 ).average( effect );
  damage->base_multiplier *= role_mult( effect );

  missile->impact_action = damage;

  effect.proc_flags2_ = PF2_CRIT;
  effect.custom_buff = counter;
  effect.execute_action = missile;

  new dbc_proc_callback_t( effect.player, effect );
}

// 469922 driver, trigger damage
// 469924 damage
void doperels_calling_rune( special_effect_t& effect )
{
  auto damage = create_proc_action<generic_proc_t>( "ghostly_ambush", effect, effect.trigger() );
  damage->base_dd_min = damage->base_dd_max = effect.driver()->effectN( 1 ).average( effect );
  damage->base_multiplier *= role_mult( effect );

  new dbc_proc_callback_t( effect.player, effect );
}

// 469925 on-use, buff, driver, trigger int buff
// 469925 int buff
// TODO: determine what can and cannot proc the int buff. mana cost does not seem to be a determining factor, as it will
// proc from harmful actions with no mana or resource cost, and buffs that reduce resource cost to 0 still allow the
// ability to proc the int buff. on the other hand, some mana cost non-harmful spell will not proc.
void burst_of_knowledge( special_effect_t& effect )
{
  auto int_buff = create_buff<stat_buff_t>( effect.player, effect.trigger(), effect.item );

  auto buff = create_buff<buff_t>( effect.player, effect.driver() )
                  ->set_cooldown( 0_ms )
                  ->set_expire_callback( [ int_buff ]( buff_t*, int, timespan_t ) { int_buff->expire(); } );

  effect.has_use_buff_override = true;
  effect.custom_buff           = buff;

  auto on_use_cb         = new special_effect_t( effect.player );
  on_use_cb->name_str    = effect.name() + "_cb";
  on_use_cb->spell_id    = effect.spell_id;
  on_use_cb->cooldown_   = effect.driver()->internal_cooldown();
  on_use_cb->custom_buff = int_buff;
  effect.player->special_effects.push_back( on_use_cb );

  auto cb = new dbc_proc_callback_t( effect.player, *on_use_cb );
  cb->activate_with_buff( buff );
}

void heart_of_roccor( special_effect_t& effect )
{
  // Currently missing the misc value for the buff type, manually setting it for now.
  // Implementation will probably be redundant once its fixed.
  auto buff = create_buff<stat_buff_t>( effect.player, effect.trigger(), effect.item )
                  ->add_stat( STAT_STRENGTH, effect.trigger()->effectN( 1 ).average( effect ) );

  effect.custom_buff = buff;
  new dbc_proc_callback_t( effect.player, effect );
}

// Wayward Vrykul's Lantern
// 467767 Driver
// 472360 Buff
void wayward_vrykuls_lantern( special_effect_t& effect )
{
  struct wayward_vrykuls_lantern_cb_t : public dbc_proc_callback_t
  {
    std::set<unsigned> proc_spell_id;
    buff_t* buff;
    double duration_multiplier;
    timespan_t last_activation_time;
    timespan_t max_dur;

    wayward_vrykuls_lantern_cb_t( const special_effect_t& e )
      : dbc_proc_callback_t( e.player, e ),
        proc_spell_id(),
        buff( nullptr ),
        duration_multiplier( 0 ),
        last_activation_time( timespan_t::zero() ),
        max_dur( timespan_t::zero() )
    {
      for ( auto& s : e.player->dbc->spells_by_label( LABEL_MAJOR_COOLDOWNS ) )
        if ( s->is_class( e.player->type ) )
        {
          proc_spell_id.insert( s->id() );
          e.player->sim->print_debug( "Wayward Vrykul's can Proc off of Spell: {}: {}\n", s->name_cstr(), s->id() );
        }

      buff = create_buff<stat_buff_t>( e.player, e.trigger(), e.item )
                 ->add_stat_from_effect_type( A_MOD_RATING, e.driver()->effectN( 1 ).average( e ) );

      // Odd formula, but, appears to be 0.222222~ seconds added to the buff duration per 1 second of time between
      // activations.
      duration_multiplier = buff->data().duration().total_seconds() / 36;
      max_dur             = buff->data().duration() * 5;
    }

    void trigger( const proc_data_t& data, player_t* t, action_state_t* s, proc_trigger_type_e type ) override
    {
      if ( range::contains( proc_spell_id, data->id() ) )
        return dbc_proc_callback_t::trigger( data, t, s, type );
    }

    void execute( const spell_data_t*, player_t*, action_state_t* ) override
    {
      // Assume for the first proc its been at least 3 minutes since the last proc, triggering it at the maximum
      // duration.
      if ( last_activation_time == timespan_t::zero() )
      {
        buff->trigger( max_dur );
        last_activation_time = listener->sim->current_time();
        return;
      }

      // If there was a valid last activation time, calculate the duration based on the time since the last activation.
      timespan_t trigger_dur = std::max(
          buff->buff_duration(),
          std::min( max_dur, ( listener->sim->current_time() - last_activation_time ) * duration_multiplier ) );

      // Only trigger the buff if the new duration would be greater than the current remaining duration.
      if ( buff->remains() < trigger_dur )
      {
        buff->trigger( trigger_dur );
        last_activation_time = listener->sim->current_time();
      }
    }

    void reset() override
    {
      dbc_proc_callback_t::reset();
      last_activation_time = timespan_t::zero();
    }
  };

  effect.proc_flags2_ = PF2_ALL_CAST;

  new wayward_vrykuls_lantern_cb_t( effect );
}

// Cursed Pirate Skull
// 468035 Driver
// 472228 Buff
// 472232 Damage
void cursed_pirate_skull( special_effect_t& effect )
{
  auto damage_spell   = effect.trigger()->effectN( 1 ).trigger();
  auto damage         = create_proc_action<generic_proc_t>( "cursed_pirate_skull", effect, damage_spell );
  damage->base_dd_min = damage->base_dd_max = effect.driver()->effectN( 1 ).average( effect );
  damage->aoe         = damage_spell->max_targets();
  // No Role Mult currently, likely to change in the future.
  // damage->base_multiplier *= role_mult( effect );

  auto buff = create_buff<buff_t>( effect.player, effect.trigger(), effect.item )
                  ->set_tick_callback( [ damage ]( buff_t*, int, timespan_t ) { damage->execute(); } );

  effect.custom_buff = buff;
  new dbc_proc_callback_t( effect.player, effect );
}

// Runecaster's Stormbound Rune
// 468033 Driver
// 472636 Periodic Trigger Buff
// 472637 Damage
void runecasters_stormbound_rune( special_effect_t& effect )
{
  auto damage_spell   = effect.player->find_spell( 472637 );
  auto damage         = create_proc_action<generic_proc_t>( "runecasters_stormbound_rune", effect, damage_spell );
  damage->base_dd_min = damage->base_dd_max = effect.driver()->effectN( 1 ).average( effect );
  // No Role Mult currently, likely to change in the future.
  // damage->base_multiplier *= role_mult( effect );

  auto buff_spell = effect.player->find_spell( 472636 );
  auto buff       = create_buff<buff_t>( effect.player, buff_spell )
                  ->set_tick_on_application( true )
                  ->set_tick_callback( [ &, damage ]( buff_t*, int, timespan_t ) {
                    if ( effect.player->sim->target_non_sleeping_list.size() > 0 )
                    {
                      auto target = effect.player->rng().range( effect.player->sim->target_non_sleeping_list );
                      damage->execute_on_target( target );
                    }
                  } );

  // TODO: Test if initial hit is truly on hit, or only enter combat. Proc flags on the driver are combat start.
  effect.player->register_on_combat_state_callback( [ buff ]( player_t*, bool c ) {
    if ( c )
      buff->trigger();
    else
      buff->expire();
  } );
}


// Darktide Wavebender's Orb
// 468034 Driver
// 472336 Missile
// 472337 Damage
void darktide_wavebenders_orb( special_effect_t& effect )
{
  auto damage_spell   = effect.player->find_spell( 472337 );
  auto damage         = create_proc_action<generic_proc_t>( "darktide_wavebenders_orb", effect, damage_spell );
  damage->base_dd_min = damage->base_dd_max = effect.driver()->effectN( 1 ).average( effect );
  damage->aoe         = damage_spell->max_targets();
  // No Role Mult currently, likely to change in the future.
  // damage->base_multiplier *= role_mult( effect );

  auto missile_spell = effect.player->find_spell( 472336 );
  auto missile       = create_proc_action<generic_proc_t>( "darktide_wavebenders_orb_missile", effect, missile_spell );
  missile->impact_action = damage;

  effect.execute_action = missile;
  new dbc_proc_callback_t( effect.player, effect );
}

// Torq's Big Red Button
// 470042 Values
// 470286 Driver & Stat Buff
// 472787 Stacking Buff
// 472784 Damage
void torqs_big_red_button( special_effect_t& effect )
{
  struct spiteful_zapbolt_t : public generic_proc_t
  {
    buff_t* stack_buff;
    const spell_data_t* value_spell;

    spiteful_zapbolt_t( const special_effect_t& e, buff_t* b, const spell_data_t* value )
      : generic_proc_t( e, "spiteful_zapbolt", 472784 ), stack_buff( b ), value_spell( value )
    {
      base_dd_min = base_dd_max = value_spell->effectN( 2 ).average( e );
      base_multiplier *= role_mult( e );
    }

    double composite_da_multiplier( const action_state_t* s ) const override
    {
      double v = generic_proc_t::composite_da_multiplier( s );

      // TODO: Double Check this formula is correct once this is testable. Might carry over to the next use?
      v *= 1.0 + ( ( stack_buff->max_stack() - stack_buff->stack() ) * value_spell->effectN( 3 ).percent() );

      return v;
    }
  };

  struct torqs_big_red_button_t : public generic_proc_t
  {
    buff_t* stat_buff;
    buff_t* stack_buff;

    torqs_big_red_button_t( const special_effect_t& e, std::string_view name, const spell_data_t* spell )
      : generic_proc_t( e.player, name, spell ), stat_buff( nullptr ), stack_buff( nullptr )
    {
      auto value_spell = e.player->find_spell( 470042 );
      assert( value_spell && "Torq's Big Red Button missing value spell" );

      stat_buff = create_buff<stat_buff_t>( e.player, e.driver(), e.item )
                      ->add_stat_from_effect( 1, value_spell->effectN( 1 ).average( e ) );

      stack_buff = create_buff<buff_t>( e.player, e.player->find_spell( 472787 ) )->set_reverse( true );

      auto damage = create_proc_action<spiteful_zapbolt_t>( "spiteful_zapbolt", e, stack_buff, value_spell );

      add_child( damage );

      auto on_next      = new special_effect_t( e.player );
      on_next->name_str = stack_buff->name();
      on_next->spell_id = stack_buff->data().id();
      e.player->special_effects.push_back( on_next );

      auto cb = new dbc_proc_callback_t( e.player, *on_next );
      cb->activate_with_buff( stack_buff );

      e.player->callbacks.register_callback_trigger_function(
          stack_buff->data().id(), dbc_proc_callback_t::trigger_fn_type::CONDITION,
          [ & ]( auto, const auto&, auto, auto, auto ) { return stack_buff->check(); } );

      e.player->callbacks.register_callback_execute_function(
          stack_buff->data().id(), [ &, damage ]( auto, auto, player_t* t, auto ) {
            if ( stack_buff->check() && e.player->specialization() != specialization_e::DEATH_KNIGHT_FROST )
            {
              damage->execute_on_target( t );
              stack_buff->decrement();
            }
          } );
    }

    void execute() override
    {
      generic_proc_t::execute();
      stat_buff->trigger();
      stack_buff->trigger();
    }
  };

  effect.execute_action = create_proc_action<torqs_big_red_button_t>( "torqs_big_red_button", effect,
                                                                      "torqs_big_red_button", effect.driver() );
}

// House of Cards
// 466681 Driver
// 466680 Values
// 1219158 Stacking Mastery
void house_of_cards( special_effect_t& effect )
{
  auto value_spell = effect.player->find_spell( 466680 );
  assert( value_spell && "House of Cards missing value spell" );

  auto stacking_buff =
      create_buff<buff_t>( effect.player, "stacked_deck_trinket", effect.player->find_spell( 1219158 ) )
          ->set_name_reporting( "stacked_deck" );

  effect.player->register_on_combat_state_callback( [ stacking_buff ]( player_t* p, bool c ) {
    if ( !c && !p->sim->event_mgr.canceled )
      stacking_buff->expire();
  } );

  struct house_of_cards_buff_t : public stat_buff_t
  {
    double range_min;
    double range_max;
    double stack_buff_mod;
    buff_t* stack_buff;

    house_of_cards_buff_t( player_t* p, std::string_view n, const special_effect_t& e, const spell_data_t* s,
                           buff_t* stack )
      : stat_buff_t( p, n, e.driver(), e.item ),
        range_min( 0 ),
        range_max( 0 ),
        stack_buff_mod( 0 ),
        stack_buff( stack )
    {
      add_stat_from_effect_type( A_MOD_RATING, s->effectN( 1 ).average( e ) );
      default_value  = s->effectN( 1 ).average( e );
      range_min      = 1.0 - ( s->effectN( 2 ).percent() );
      range_max      = 1.0 + ( s->effectN( 2 ).percent() );
      stack_buff_mod = s->effectN( 2 ).percent() / 3;
    }

    double randomize_stat_value()
    {
      double min = range_min + stack_buff_mod * stack_buff->check();
      double val = default_value * rng().range( min, range_max );

      for ( auto& buff_stat : stats )
      {
        double delta            = val - buff_stat.current_value;
        buff_stat.current_value = val;
        buff_stat.amount        = val;
        if ( delta > 0 )
        {
          player->stat_gain( buff_stat.stat, delta, stat_gain, nullptr, buff_duration() > timespan_t::zero() );
        }
        else if ( delta < 0 )
        {
          player->stat_loss( buff_stat.stat, std::fabs( delta ), stat_gain, nullptr,
                             buff_duration() > timespan_t::zero() );
        }
      }
      return val;
    }

    void bump( int stacks, double ) override
    {
      buff_t::bump( stacks, randomize_stat_value() );
      stack_buff->trigger();
    }

    void expire_override( int s, timespan_t d ) override
    {
      for ( auto& buff_stat : stats )
      {
        player->stat_loss( buff_stat.stat, buff_stat.current_value, stat_gain, nullptr,
                           buff_duration() > timespan_t::zero() );

        buff_stat.current_value = 0;
      }

      // Purposely skip over stat_buff_t::expire_override() as we do the lost stat calculations manually
      buff_t::expire_override( s, d );
    }
  };

  effect.custom_buff =
      create_buff<house_of_cards_buff_t>( effect.player, "house_of_cards", effect, value_spell, stacking_buff );
}

struct external_action_state_t : public action_state_t
{
  player_t* faked_player;

  external_action_state_t( action_t* a, player_t* t ) : action_state_t( a, t ), faked_player( nullptr )
  {
  }

  void initialize() override
  {
    action_state_t::initialize();
    faked_player = nullptr;
  }

  void copy_state( const action_state_t* o ) override
  {
    action_state_t::copy_state( o );
    faked_player = static_cast<const external_action_state_t*>( o )->faked_player;
  }
};

template <typename ab>
struct external_scaling_proc_t : public ab
{
public:
  player_t* faked_player;

  external_scaling_proc_t( const special_effect_t& effect, ::util::string_view name, const spell_data_t* s )
    : ab( effect, name, s ), faked_player( effect.player )
  {
  }

  external_scaling_proc_t( player_t* p, ::util::string_view name, const spell_data_t* s, const item_t* i = nullptr )
    : ab( p, name, s, i ), faked_player( p )
  {
  }

  action_state_t* new_state() override
  {
    return new external_action_state_t( this, ab::target );
  }

  external_action_state_t* cast_state( action_state_t* s )
  {
    return static_cast<external_action_state_t*>( s );
  }

  const external_action_state_t* cast_state( const action_state_t* s ) const
  {
    return static_cast<const external_action_state_t*>( s );
  }

  player_t* p( const action_state_t* state )
  {
    return cast_state( state )->faked_player;
  }

  player_t* p( const action_state_t* state ) const
  {
    return cast_state( state )->faked_player;
  }

private:
  using ab::composite_crit_chance;
  using ab::composite_crit_chance_multiplier;
  using ab::composite_haste;
  using ab::composite_target_armor;
  using ab::composite_target_crit_chance;
  using ab::composite_target_da_multiplier;
  using ab::composite_target_multiplier;
  using ab::composite_target_ta_multiplier;

public:
  double composite_attack_power( const action_state_t* s ) const
  {
    return p( s )->composite_total_attack_power_by_type( ab::get_attack_power_type() );
  }

  double composite_spell_power( const action_state_t* s ) const
  {
    double spell_power = 0;
    double tmp;

    auto _player = p( s );

    for ( auto base_school : ab::base_schools )
    {
      tmp = _player->composite_total_spell_power( base_school );
      if ( tmp > spell_power )
        spell_power = tmp;
    }

    return spell_power;
  }

  double composite_versatility( const action_state_t* s ) const override
  {
    return action_t::composite_versatility( s ) + p( s )->cache.damage_versatility();
  }

  virtual double composite_crit_chance( const action_state_t* s ) const
  {
    return action_t::composite_crit_chance() + p( s )->cache.spell_crit_chance();
  }

  virtual double composite_haste( const action_state_t* s ) const
  {
    return action_t::composite_haste() * p( s )->cache.spell_cast_speed();
  }

  double composite_crit_chance_multiplier( const action_state_t* s ) const
  {
    return action_t::composite_crit_chance_multiplier() * p( s )->composite_spell_crit_chance_multiplier();
  }

  double composite_player_critical_multiplier( const action_state_t* s ) const override
  {
    double player_critical_multiplier = 0.0;
    double tmp;

    for ( auto base_school : ab::base_schools )
    {
      tmp = p( s )->composite_player_critical_damage_multiplier( s, base_school );
      if ( tmp > player_critical_multiplier )
        player_critical_multiplier = tmp;
    }

    return player_critical_multiplier;
  }

  double composite_target_crit_chance( const action_state_t* s ) const
  {
    return p( s )->composite_player_target_crit_chance( s->target );
  }

  double composite_target_multiplier( const action_state_t* s ) const
  {
    return p( s )->composite_player_target_multiplier( s->target, ab::get_school() );
  }

  double composite_player_multiplier( const action_state_t* s ) const override
  {
    double player_school_multiplier = 0.0;
    double tmp;

    for ( auto base_school : ab::base_schools )
    {
      tmp = p( s )->cache.player_multiplier( base_school );
      if ( tmp > player_school_multiplier )
        player_school_multiplier = tmp;
    }

    return player_school_multiplier;
  }

  double composite_persistent_multiplier( const action_state_t* s ) const override
  {
    return p( s )->composite_persistent_multiplier( ab::get_school() );
  }

  virtual double composite_target_da_multiplier( const action_state_t* s ) const
  {
    return composite_target_multiplier( s );
  }

  virtual double composite_target_ta_multiplier( const action_state_t* s ) const
  {
    return composite_target_multiplier( s );
  }

  double composite_target_armor( const action_state_t* s ) const override
  {
    return p( s )->composite_player_target_armor( s->target );
  }

  void snapshot_internal( action_state_t* state, unsigned flags, result_amount_type rt ) override
  {
    assert( state );

    cast_state( state )->faked_player = faked_player;

    ab::snapshot_internal( state, flags, rt );

    if ( flags & STATE_CRIT )
      state->crit_chance = composite_crit_chance( state ) * composite_crit_chance_multiplier( state );

    if ( flags & STATE_HASTE )
      state->haste = composite_haste( state );

    if ( flags & STATE_AP )
      state->attack_power = composite_attack_power( state );

    if ( flags & STATE_SP )
      state->spell_power = composite_spell_power( state );

    if ( flags & STATE_TGT_MUL_DA )
      state->target_da_multiplier = composite_target_da_multiplier( state );

    if ( flags & STATE_TGT_MUL_TA )
      state->target_ta_multiplier = composite_target_ta_multiplier( state );

    if ( flags & STATE_TGT_CRIT )
      state->target_crit_chance = composite_target_crit_chance( state ) * composite_crit_chance_multiplier( state );

    // if ( flags & STATE_TGT_ARMOR )
    //   state->target_armor = composite_target_armor( state );
  }

  void snapshot_state( action_state_t* s, result_amount_type rt ) override
  {
    ab::snapshot_state( s, rt );
    cast_state( s )->faked_player = faked_player;
  }
};

template <typename T>
struct external_proc_cb_t : public dbc_proc_callback_t
{
  player_t* source;
  external_proc_cb_t( const special_effect_t& e, player_t* source )
    : dbc_proc_callback_t( e.player, e ), source( source )
  {
  }

  void execute( const spell_data_t* spell, player_t* t, action_state_t* s ) override
  {
    debug_cast<external_scaling_proc_t<T>*>( proc_action )->faked_player = source;
    dbc_proc_callback_t::execute( spell, t, s );
  }
};

// 443559 Driver
//  e1 - Primary
//  e2 - Secondary
//  e3 - Tertiary
//  e4 - Damage?
//  e5 - Healing?
//  e6 - Mana?
// 452365 DPS Proc Driver
// 452800 DPS Proc Action
// 452366 Healer Proc Driver - Healing
// 452801 Healer Proc Action
// 452361 Tank Proc Driver - Damage Taken - Overwrite with damage flags.
// 452804 Tank Proc Action
// 452337 Secondary Stat Proc - All Stats in effect, Grants Highest.
// 452288 Primary Stat Proc
void cirral_concoctory( special_effect_t& effect )
{
  struct cirral_concoctory_cb_t : public dbc_proc_callback_t
  {
    enum cirral_outcomes_e
    {
      LORD_PROC,
      ASCENDED_PROC,
      SUNDEERED_PROC,
      QUEEN_PROC,
      SAGE_PROC
    };

    const std::vector<std::pair<cirral_outcomes_e, double>> dps_cirral_weights = {
        { LORD_PROC, 0.4 },
        { ASCENDED_PROC, 0.4 },
        { SUNDEERED_PROC, 0.25 },
        { QUEEN_PROC, 0.02 },
    };

    const std::vector<std::pair<cirral_outcomes_e, double>> healer_cirral_weights = {
        { LORD_PROC, 0.4 }, { ASCENDED_PROC, 0.4 }, { SUNDEERED_PROC, 0.25 }, { QUEEN_PROC, 0.02 }, { SAGE_PROC, 0.08 },
    };

    const std::vector<std::pair<cirral_outcomes_e, double>> normalise_weights(
        const std::vector<std::pair<cirral_outcomes_e, double>>& to_norm )
    {
      std::vector<std::pair<cirral_outcomes_e, double>> normalised_vector;
      auto total_weight = 0.0;

      for ( auto [ _, weight ] : to_norm )
      {
        assert( weight >= 0 && "Weights must be positive" );
        total_weight += weight;
      }

      auto running_weight = 0.0;
      for ( auto [ outcome, weight ] : to_norm )
      {
        if ( weight > 0 )
        {
          running_weight += weight;
          normalised_vector.push_back( { outcome, running_weight / total_weight } );
        }
      }

      return normalised_vector;
    }

    const std::vector<std::pair<cirral_outcomes_e, double>> dps_cirral_normalised_weights;
    const std::vector<std::pair<cirral_outcomes_e, double>> healer_cirral_normalised_weights;

    target_specific_t<buff_t> primary_stat_buffs;
    target_specific_t<std::unordered_map<stat_e, buff_t*>> secondary_stat_buffs;
    target_specific_t<buff_t> proc_driver_buffs;
    std::vector<player_t*> potential_targets;

    external_scaling_proc_t<generic_heal_t>* healing_action;
    external_scaling_proc_t<generic_proc_t>* dps_action;
    external_scaling_proc_t<generic_aoe_proc_t>* tank_action;

    cirral_concoctory_cb_t( const special_effect_t& e )
      : dbc_proc_callback_t( e.player, e ),
        dps_cirral_normalised_weights( normalise_weights( ( dps_cirral_weights ) ) ),
        healer_cirral_normalised_weights( normalise_weights( ( healer_cirral_weights ) ) ),
        primary_stat_buffs{ false },
        secondary_stat_buffs{ true },
        proc_driver_buffs{ false },
        potential_targets{},
        healing_action( nullptr ),
        dps_action( nullptr ),
        tank_action( nullptr )
    {
      create_actions();
    }

    void create_actions()
    {
      auto healing_action_spell = listener->find_spell( 452801 );
      healing_action = new external_scaling_proc_t<generic_heal_t>( listener, "strand_of_the_sundered_healer",
                                                                    healing_action_spell );
      healing_action->base_dd_min = healing_action->base_dd_max = effect.driver()->effectN( 5 ).average( effect );

      auto dps_action_spell = listener->find_spell( 452800 );
      dps_action =
          new external_scaling_proc_t<generic_proc_t>( listener, "strand_of_the_sundered_dps", dps_action_spell );
      dps_action->base_dd_min = dps_action->base_dd_max = effect.driver()->effectN( 4 ).average( effect );

      auto tank_action_spell = listener->find_spell( 452804 );
      tank_action =
          new external_scaling_proc_t<generic_aoe_proc_t>( listener, "strand_of_the_sundered_tank", tank_action_spell );
      tank_action->base_dd_min = tank_action->base_dd_max = effect.driver()->effectN( 4 ).average( effect );
    }

    buff_t* get_primary_buff( player_t* buff_player )
    {
      if ( primary_stat_buffs[ buff_player ] )
        return primary_stat_buffs[ buff_player ];

      auto buff_spell = effect.player->find_spell( 452288 );

      auto buff = make_buff<stat_buff_t>( actor_pair_t{ buff_player, effect.player }, "strand_of_the_lord", buff_spell )
                      ->add_stat_from_effect( 1, effect.driver()->effectN( 1 ).average( effect ) );

      primary_stat_buffs[ buff_player ] = buff;

      return buff;
    }

    buff_t* get_secondary_buff( player_t* buff_player )
    {
      if ( secondary_stat_buffs[ buff_player ] )
        return secondary_stat_buffs[ buff_player ]->at( util::highest_stat( buff_player, secondary_ratings ) );

      auto buff_spell = effect.player->find_spell( 452337 );
      auto buff_name  = util::tokenize_fn( buff_spell->name_cstr() );
      auto amount     = effect.driver()->effectN( 2 ).average( effect );

      std::unordered_map<stat_e, buff_t*>* map_for_player = new std::unordered_map<stat_e, buff_t*>();

      for ( const auto& eff : buff_spell->effects() )
      {
        if ( eff.type() != E_APPLY_AURA || eff.subtype() != A_MOD_RATING )
          continue;

        auto stats = util::translate_all_rating_mod( eff.misc_value1() );
        auto stat  = stats.front();

        std::vector<std::string_view> stat_strs;
        range::transform( stats, std::back_inserter( stat_strs ), &util::stat_type_abbrev );

        auto name = fmt::format( "{}_{}", buff_name, util::string_join( stat_strs, "_" ) );
        auto buff = make_buff<stat_buff_t>( actor_pair_t{ buff_player, effect.player }, name, buff_spell )
                        ->add_stat( stat, amount ? amount : eff.average( effect ) )
                        ->set_name_reporting( util::string_join( stat_strs ) );

        ( *map_for_player )[ stat ] = buff;
      }

      secondary_stat_buffs[ buff_player ] = std::move( map_for_player );
      return secondary_stat_buffs[ buff_player ]->at( util::highest_stat( buff_player, secondary_ratings ) );
    }

    buff_t* get_proc_buff( player_t* buff_player )
    {
      if ( proc_driver_buffs[ buff_player ] )
        return proc_driver_buffs[ buff_player ];

      switch ( buff_player->primary_role() )
      {
        case ROLE_HEAL:
        case ROLE_HYBRID:
        {
          auto driver_spell = effect.player->find_spell( 452366 );

          auto buff_name = util::tokenize_fn( driver_spell->name_cstr() );

          auto driver_effect            = new special_effect_t( buff_player );
          driver_effect->name_str       = buff_name;
          driver_effect->spell_id       = driver_spell->id();
          driver_effect->execute_action = healing_action;
          buff_player->special_effects.push_back( driver_effect );

          auto buff = make_buff( actor_pair_t{ buff_player, effect.player }, buff_name, driver_spell );
          buff->set_chance( 1.0 )->set_rppm( RPPM_NONE );
          proc_driver_buffs[ buff_player ] = buff;

          auto healer_cb = new external_proc_cb_t<generic_heal_t>( *driver_effect, listener );
          healer_cb->activate_with_buff( buff, true );
          break;
        }
        case ROLE_TANK:
        {
          auto driver_spell     = effect.player->find_spell( 452361 );
          auto dps_driver_spell = effect.player->find_spell( 452365 );

          auto buff_name = util::tokenize_fn( driver_spell->name_cstr() );

          auto driver_effect            = new special_effect_t( buff_player );
          driver_effect->name_str       = buff_name;
          driver_effect->spell_id       = driver_spell->id();
          driver_effect->execute_action = tank_action;
          driver_effect->proc_flags_    = dps_driver_spell->proc_flags();
          buff_player->special_effects.push_back( driver_effect );

          auto buff = make_buff( actor_pair_t{ buff_player, effect.player }, buff_name, driver_spell );
          buff->set_chance( 1.0 )->set_rppm( RPPM_NONE );
          proc_driver_buffs[ buff_player ] = buff;

          auto tank_cb = new external_proc_cb_t<generic_aoe_proc_t>( *driver_effect, listener );
          tank_cb->activate_with_buff( buff, true );
          break;
        }
        default:
        {
          auto driver_spell = effect.player->find_spell( 452365 );
          auto buff_name    = util::tokenize_fn( driver_spell->name_cstr() );

          auto driver_effect            = new special_effect_t( buff_player );
          driver_effect->name_str       = buff_name;
          driver_effect->spell_id       = driver_spell->id();
          driver_effect->execute_action = dps_action;
          buff_player->special_effects.push_back( driver_effect );

          auto buff = make_buff( actor_pair_t{ buff_player, effect.player }, buff_name, driver_spell );
          buff->set_chance( 1.0 )->set_rppm( RPPM_NONE );
          proc_driver_buffs[ buff_player ] = buff;

          auto dps_cb = new external_proc_cb_t<generic_proc_t>( *driver_effect, listener );
          dps_cb->activate_with_buff( buff, true );
          break;
        }
      }

      return proc_driver_buffs[ buff_player ];
    }

    cirral_outcomes_e roll_for_outcome( const std::vector<std::pair<cirral_outcomes_e, double>> normalised_weights )
    {
      auto roll = rng().real();

      for ( auto [ outcome, weight ] : normalised_weights )
      {
        if ( weight > roll )
          return outcome;
      }

      assert( false && "This should be unreachable. Invalid Weights setup found." );
      return LORD_PROC;
    }

    void trigger_for_player( player_t* buff_player, cirral_outcomes_e outcome )
    {
      switch ( outcome )
      {
        case LORD_PROC:
          get_primary_buff( buff_player )->trigger();
          break;
        case ASCENDED_PROC:
          get_secondary_buff( buff_player )->trigger();
          break;
        case SUNDEERED_PROC:
          get_proc_buff( buff_player )->trigger();
          break;
        case QUEEN_PROC:
        case SAGE_PROC:
        default:
          break;
      }
    }

    void trigger_for_player( player_t* buff_player )
    {
      if ( buff_player->primary_role() == ROLE_HEAL || buff_player->primary_role() == ROLE_HYBRID )
      {
        trigger_for_player( buff_player, roll_for_outcome( healer_cirral_normalised_weights ) );
      }
      else
      {
        trigger_for_player( buff_player, roll_for_outcome( dps_cirral_normalised_weights ) );
      }
    }

    void execute( const spell_data_t*, player_t*, action_state_t* ) override
    {
      potential_targets.clear();

      for ( auto& potential_target : listener->sim->player_no_pet_list )
      {
        if ( potential_target != listener && !potential_target->is_sleeping() && potential_target->is_player() )
        {
          potential_targets.push_back( potential_target );
        }
      }

      if ( potential_targets.size() == 0 )
        return;

      auto potential_target = rng().range( potential_targets );
      // Healers are about one third as likely, probably. For now this is a good approximation.
      if ( ( potential_target->primary_role() == ROLE_HEAL || potential_target->primary_role() == ROLE_HYBRID ) &&
           rng().roll( 0.75 ) )
        potential_target = rng().range( potential_targets );

      trigger_for_player( potential_target );
    }
  };

  effect.proc_flags2_ = PF2_ALL_HIT | PF2_PERIODIC_DAMAGE | PF2_PERIODIC_HEAL;

  if ( !effect.player->sim->single_actor_batch )
    new cirral_concoctory_cb_t( effect );
}

// Eye of Kezan
// 469888 Driver
// 469889 Buff
// 1216593 Damage
// 1216594 Heal
void eye_of_kezan( special_effect_t& effect )
{
  struct eye_of_kezan_cb_t : public dbc_proc_callback_t
  {
    buff_t* stat_buff;
    action_t* damage;
    action_t* heal;

    eye_of_kezan_cb_t( const special_effect_t& e )
      : dbc_proc_callback_t( e.player, e ), stat_buff( nullptr ), damage( nullptr ), heal( nullptr )
    {
      stat_buff = create_buff<stat_buff_t>( e.player, e.player->find_spell( 469889 ) )
                      ->set_stat_from_effect_type( A_MOD_STAT, e.driver()->effectN( 1 ).average( e ) )
                      ->disable_ticking( true );

      auto out_of_combat_buff =
          create_buff<stat_buff_t>( e.player, "eye_of_kezan_out_of_combat", e.player->find_spell( 469889 ) )
              ->set_stat_from_effect_type( A_MOD_STAT, e.driver()->effectN( 1 ).average( e ) )
              ->set_reverse( true )
              ->set_duration( 20_s );  // Doesnt appear to be in data

      e.player->register_on_combat_state_callback( [ &, out_of_combat_buff ]( player_t* p, bool c ) {
        if ( c && !stat_buff->check() && out_of_combat_buff->check() )
        {
          stat_buff->trigger( out_of_combat_buff->check() );
          out_of_combat_buff->expire();
        }
        if ( !c && !p->sim->event_mgr.canceled && stat_buff->check() && !out_of_combat_buff->check() )
        {
          out_of_combat_buff->trigger( stat_buff->check() );
          stat_buff->expire();
        }
      } );

      damage              = create_proc_action<generic_proc_t>( "wrath_of_kezan", e, e.player->find_spell( 1216593 ) );
      damage->base_dd_min = damage->base_dd_max = e.driver()->effectN( 2 ).average( e );
      damage->base_multiplier *= role_mult( e );

      heal              = new heal_t( "vigor_of_kezan", e.player, e.player->find_spell( 1216594 ) );
      heal->base_dd_min = heal->base_dd_max = e.driver()->effectN( 3 ).average( e );
    }

    void execute( const spell_data_t*, player_t* t, action_state_t* ) override
    {
      if ( !stat_buff->at_max_stacks() )
      {
        stat_buff->trigger();
        return;
      }

      if ( t->is_enemy() )
        damage->execute_on_target( t );
      else
        heal->execute_on_target( t );
    }
  };
  effect.proc_flags2_ = PF2_ALL_HIT;

  new eye_of_kezan_cb_t( effect );
}

// Geargrinder's Remote
// 471059 Driver
// 471058 Value
// 472030 Damage
void geargrinders_remote( special_effect_t& effect )
{
  auto value_spell = effect.player->find_spell( 471058 );
  assert( value_spell && "Geargrinder's Remote missing Value spell" );
  auto damage_spell = effect.player->find_spell( 472030 );
  assert( damage_spell && "Geargrinder's Remote missing Damage spell" );

  auto damage         = create_proc_action<generic_aoe_proc_t>( "blaze_of_glory", effect, damage_spell, true );
  damage->base_dd_min = damage->base_dd_max = value_spell->effectN( 1 ).average( effect );
  damage->base_multiplier *= role_mult( effect );

  effect.execute_action = damage;
}

// Improvised Seaforium Pacemaker
// 1218714 crit buff driver
// 1218715 cooldown buff
// 1218713 crit buff
// 1218712 extension driver
void improvised_seaforium_pacemaker( special_effect_t& effect )
{
  if ( unique_gear::create_fallback_buffs( effect, { "maybe_stop_blowing_up", "explosive_adrenaline" } ) )
    return;

  auto crit_buff = create_buff<stat_buff_t>( effect.player, effect.player->find_spell( 1218713 ) )
    ->set_stat_from_effect_type( A_MOD_RATING, effect.driver()->effectN( 1 ).average( effect ) );

  auto cooldown_buff = create_buff<buff_t>( effect.player, effect.player->find_spell( 1218715 ) );

  struct explosive_adrenaline_cb_t : public dbc_proc_callback_t
  {
    buff_t* crit_buff;
    buff_t* cooldown_buff;
    timespan_t extension;
    int max_extensions;
    int extensions = 0;

    explosive_adrenaline_cb_t( const special_effect_t& e, buff_t* crit_buff, buff_t* cooldown_buff, const spell_data_t* s ) : dbc_proc_callback_t( e.player, e ),
      crit_buff( crit_buff ),
      cooldown_buff( cooldown_buff ),
      extension( timespan_t::from_seconds( s->effectN( 1 ).base_value() ) ),
      max_extensions( as<int>( s->effectN( 2 ).base_value() ) )
    {
      crit_buff->set_expire_callback( [ & ]( buff_t*, int, timespan_t ) { extensions = 0; } );
    }

    void trigger( const proc_data_t& data, player_t* t, action_state_t* s, proc_trigger_type_e type ) override
    {
      if ( extensions < max_extensions )
        dbc_proc_callback_t::trigger( data, t, s, type );
    }

    void execute( const spell_data_t*, player_t*, action_state_t* ) override
    {
      if ( extensions++ < max_extensions )
        crit_buff->extend_duration( extension );
    }

    void activate() override
    {
      dbc_proc_callback_t::activate();

      cooldown_buff->trigger();
    }

    void reset() override { extensions = 0; }
  };

  const spell_data_t* extension_driver = effect.player->find_spell( 1218712 );

  auto buff_extension          = new special_effect_t( effect.player );
  buff_extension->name_str     = extension_driver->name_cstr();
  buff_extension->spell_id     = extension_driver->id();
  buff_extension->proc_flags2_ = PF2_CRIT;
  effect.player->special_effects.push_back( buff_extension );

  auto cb = new explosive_adrenaline_cb_t( *buff_extension, crit_buff, cooldown_buff, extension_driver );
  cb->activate_with_buff( crit_buff );

  effect.cooldown_ = timespan_t::from_seconds( effect.driver()->effectN( 2 ).base_value() );
  effect.proc_flags2_ = PF2_ALL_CAST;
  effect.has_use_buff_override = false;
  new dbc_proc_callback_t( effect.player, effect );
}

// Reverb Radio
// 471567 Driver
// 1216212 Buff
void reverb_radio( special_effect_t& effect )
{
  struct hyped_buff_t : public stat_buff_t
  {
    timespan_t amped_duration;
    double amped_value;
    double base_value;
    bool amped;
    hyped_buff_t( player_t* p, util::string_view name, const spell_data_t* s, const special_effect_t& e,
                  const item_t* item = nullptr )
      : stat_buff_t( p, name, s, item ), amped_duration( 0_ms ), amped_value( 0 ), amped( false )
    {
      amped_duration = timespan_t::from_seconds( e.driver()->effectN( 3 ).base_value() );
      base_value     = e.driver()->effectN( 1 ).average( e );
      set_stat_from_effect_type( A_MOD_RATING, base_value );
      amped_value = 1.0 + e.driver()->effectN( 2 ).percent();
    }

    void expire_override( int s, timespan_t d ) override
    {
      if ( amped )
      {
        for ( auto& buff_stat : stats )
        {
          player->stat_loss( buff_stat.stat, buff_stat.current_value, stat_gain, nullptr,
                             buff_duration() > timespan_t::zero() );

          buff_stat.current_value = 0;
          buff_stat.amount        = base_value;
        }
        amped = false;
        set_refresh_behavior( buff_refresh_behavior::DURATION );
        buff_t::expire_override( s, d );
      }
      else
        stat_buff_t::expire_override( s, d );
    }

    void reset() override
    {
      stat_buff_t::reset();
      amped = false;
    }

    void amp_it_up()
    {
      amped = true;

      for ( auto& buff_stat : stats )
      {
        if ( buff_stat.check_func && !buff_stat.check_func( *this ) )
          continue;

        buff_stat.current_value *= amped_value;
        buff_stat.amount *= amped_value;
      }
      trigger( max_stack(), amped_duration );
      set_refresh_behavior( buff_refresh_behavior::DISABLED );
    }

    void bump( int stacks, double ) override
    {
      if ( at_max_stacks( stacks ) && !amped )
      {
        make_event( *sim, 0_ms, [ & ] { expire(); } );
        make_event( *sim, 0_ms, [ & ] { amp_it_up(); } );
        return;
      }
      else
        stat_buff_t::bump( stacks );
    }
  };

  auto buff = create_buff<hyped_buff_t>( effect.player, "hyped", effect.player->find_spell( 1216212 ), effect );
  effect.custom_buff = buff;
  effect.proc_flags2_ = PF2_ALL_HIT;

  new dbc_proc_callback_t( effect.player, effect );
}

// Mechano-core Amplifer
// 1214787 Driver
// e1: Highest stat value
// e2: Lowest stat value
// 1214806 Crit Buff
// 1214807 Haste Buff
// 1214808 Mastery Buff
// 1214810 Vers Buff
void mechanocore_amplifier( special_effect_t& effect )
{
  struct mechanocore_amplifier_buff_t : public stat_buff_t
  {
    double high_value;
    double low_value;
    mechanocore_amplifier_buff_t( player_t* p, util::string_view name, const spell_data_t* s, const special_effect_t& e,
                                  const item_t* item = nullptr )
      : stat_buff_t( p, name, s, item ), high_value( 0 ), low_value( 0 )
    {
      high_value = e.driver()->effectN( 1 ).average( e );
      low_value  = e.driver()->effectN( 2 ).average( e );
      set_default_value( 0 );
    }

    void set_given_stat_value( double val )
    {
      for ( auto& buffed_stat : stats )
      {
        buffed_stat.amount = val;
      }
    }

    void trigger_high()
    {
      set_given_stat_value( high_value );
      trigger();
    }

    void trigger_low()
    {
      set_given_stat_value( low_value );
      trigger();
    }
  };

  struct mechanocore_amplifier_cb_t : public dbc_proc_callback_t
  {
    std::unordered_map<stat_e, mechanocore_amplifier_buff_t*> buffs;

    mechanocore_amplifier_cb_t( const special_effect_t& e ) : dbc_proc_callback_t( e.player, e ), buffs()
    {
      static constexpr std::array<std::pair<stat_e, int>, 4> buff_spells = {
          std::make_pair( stat_e::STAT_CRIT_RATING, 1214806 ), std::make_pair( stat_e::STAT_HASTE_RATING, 1214807 ),
          std::make_pair( stat_e::STAT_MASTERY_RATING, 1214808 ),
          std::make_pair( stat_e::STAT_VERSATILITY_RATING, 1214810 ) };

      for ( auto& spell : buff_spells )
      {
        auto buff_spell     = e.player->find_spell( spell.second );
        auto buff_stat_name = util::stat_type_abbrev( spell.first );
        auto name           = fmt::format( "{}_{}", buff_spell->name_cstr(), buff_stat_name );
        auto buff           = create_buff<mechanocore_amplifier_buff_t>( e.player, name, buff_spell, e );
        buff->add_stat_from_effect_type( A_MOD_RATING, 0 );
        buff->set_name_reporting( buff_stat_name );
        buffs.insert( { spell.first, buff } );
      }
    }

    void execute( const spell_data_t*, player_t*, action_state_t* ) override
    {
      for ( const auto& b : buffs )
        b.second->expire();

      if ( rng().roll( 0.5 ) )
        buffs.at( util::highest_stat( listener, secondary_ratings ) )->trigger_high();
      else
        buffs.at( util::lowest_stat( listener, secondary_ratings ) )->trigger_low();
    }
  };

  new mechanocore_amplifier_cb_t( effect );
}

// Papa's Prized Putter
// 1215238 Driver
// 1215321 Damage
void papas_prized_putter( special_effect_t& effect )
{
  auto damage         = create_proc_action<generic_proc_t>( "papas_prized_putter", effect, 1215321 );
  damage->base_dd_min = damage->base_dd_max = effect.player->find_spell( 1215321 )->effectN( 1 ).average( effect );
  damage->base_multiplier                   = role_mult( effect );

  effect.execute_action = damage;

  new dbc_proc_callback_t( effect.player, effect );
}

// Turbo-Drain 5000
// 472125 Driver
// 472127 DoT
void turbodrain_5000( special_effect_t& effect )
{
  auto dot_spell    = effect.player->find_spell( 472127 );
  auto dot          = create_proc_action<generic_proc_t>( "turbodrain_5000", effect, dot_spell );
  auto total_damage = effect.driver()->effectN( 1 ).average( effect );
  auto ticks        = dot_spell->duration() / dot_spell->effectN( 1 ).period();
  dot->base_td      = total_damage / ticks;
  dot->base_td_multiplier = role_mult( effect );
  effect.execute_action = dot;

  new dbc_proc_callback_t( effect.player, effect );
}

// Noggenfogger Ultimate Deluxe
// 470675 Driver
// 471404 Summon Pet spell
// 233767 Pet NPC ID
// Pet currently only melee attacks.
// TODO: Determine if the pet should scale with aura 380 and 531
void noggenfogger_ultimate_deluxe( special_effect_t& effect )
{
  struct auto_attack_melee_t : public melee_attack_t
  {
    auto_attack_melee_t( pet_t* p, const special_effect_t& e, std::string_view name = "main_hand", action_t* a = nullptr )
      : melee_attack_t( name, p )
    {
      this->background = this->repeating = true;
      this->not_a_proc = this->may_crit = true;
      this->special                     = false;
      this->weapon_multiplier           = 1.0;
      this->trigger_gcd                 = 0_ms;
      this->school                      = SCHOOL_PHYSICAL;
      this->stats->school               = SCHOOL_PHYSICAL;
      this->base_dd_min = this->base_dd_max = a->data().effectN( 1 ).average( e );
      // Not in data, but the pet deals less damage on tank specs.
      this->base_multiplier                 = role_mult( e.player );

      auto proxy = a;
      auto it    = range::find( proxy->child_action, name, &action_t::name );
      if ( it != proxy->child_action.end() )
        stats = ( *it )->stats;
      else
        proxy->add_child( this );
    }

    double composite_target_multiplier( player_t* p ) const override
    {
      double m = melee_attack_t::composite_target_multiplier( p );
      m *= this->player->cast_pet()->owner->composite_player_target_pet_damage_multiplier( p, player->type == PLAYER_GUARDIAN );
      return m;
    }

    void execute() override
    {
      if ( this->player->executing )
        this->schedule_execute();
      else
        melee_attack_t::execute();
    }
  };

  struct blackwater_pirate_pet_t : public unique_gear_pet_t
  {
    const special_effect_t& effect;

    blackwater_pirate_pet_t( const special_effect_t& e, action_t* parent = nullptr )
      : unique_gear_pet_t( "blackwater_pirate", e, &parent->data() ), effect( e )
    {
      parent_action               = parent;
      main_hand_weapon.type       = WEAPON_BEAST;
      main_hand_weapon.swing_time = 2_s;
      use_auto_attack             = true;
    }

    void update_stats() override
    {
      unique_gear_pet_t::update_stats();
      // TODO: Needs more testing to see if its just haste and attack speed that this no longer scales with. 
      current_pet_stats.composite_melee_auto_attack_speed = 1.0;
      current_pet_stats.composite_spell_cast_speed        = 1.0;
      current_pet_stats.composite_melee_haste             = 1.0;
      current_pet_stats.composite_spell_haste             = 1.0;
      adjust_dynamic_cooldowns();
    }

    attack_t* create_auto_attack() override
    {
      auto a                = new auto_attack_melee_t( this, effect, "main_hand", parent_action );
      a->name_str_reporting = "Melee";
      return a;
    }
  };

  struct noggenfogger_ultimate_deluxe_t : public generic_proc_t
  {
    spawner::pet_spawner_t<blackwater_pirate_pet_t> pirate_spawner;

    noggenfogger_ultimate_deluxe_t( const special_effect_t& e )
      : generic_proc_t( e, "noggenfogger_utimate_deluxe", e.driver() ), pirate_spawner( "blackwater_pirate", e.player )
    {
      auto summon_spell          = e.player->find_spell( 471404 );
      auto pirate                = new action_t( action_e::ACTION_OTHER, "blackwater_pirate", e.player, summon_spell );
      pirate->name_str_reporting = "blackwater_pirate";
      pirate_spawner.set_creation_callback(
          [ &e, pirate ]( player_t* ) { return new blackwater_pirate_pet_t( e, pirate ); } );
      pirate_spawner.set_default_duration( summon_spell->duration() );
      add_child( pirate );
    }

    void execute() override
    {
      generic_proc_t::execute();
      pirate_spawner.spawn();
    }
  };

  // Name is currently typod in spell data, might need fixed if the data name changes.
  effect.execute_action = create_proc_action<noggenfogger_ultimate_deluxe_t>( "noggenfogger_utimate_deluxe", effect );
  effect.has_use_damage_override = true;
}

// Ratfang Toxin
// 1216605 Use Driver
// 1216603 Equip Driver & Values
// 1216604 Debuff
// 1216606 DoT
void ratfang_toxin( special_effect_t& effect )
{
  auto equip_driver = effect.player->find_spell( 1216603 );
  assert( equip_driver && "Ratfang Toxin missing Equip Driver" );

  struct ratfang_toxin_cb_t : public dbc_proc_callback_t
  {
    const spell_data_t* debuff_spell;

    ratfang_toxin_cb_t( const special_effect_t& e )
      : dbc_proc_callback_t( e.player, e ), debuff_spell( e.player->find_spell( 1216604 ) )
    {
    }

    buff_t* create_debuff( player_t* t ) override
    {
      if ( t->is_enemy() )
      {
        return make_buff( actor_pair_t( t, listener ), "ratfang_toxin_debuff", debuff_spell );
      }
      else
        return nullptr;
    }

    void trigger( const proc_data_t& data, player_t* t, action_state_t* s, proc_trigger_type_e type ) override
    {
      if ( auto d = get_debuff( t ); d && !d->at_max_stacks() )
        dbc_proc_callback_t::trigger( data, t, s, type );
    }

    void execute( const spell_data_t*, player_t* t, action_state_t* ) override
    {
      if ( buff_t* d = get_debuff( t ) )
        d->trigger();
    }
  };

  auto equip      = new special_effect_t( effect.player );
  equip->name_str = "ratfang_toxin_equip";
  equip->item     = effect.item;
  equip->spell_id = equip_driver->id();
  effect.player->special_effects.push_back( equip );

  auto equip_cb = new ratfang_toxin_cb_t( *equip );
  equip_cb->initialize();
  equip_cb->activate();

  struct ratfang_toxin_t : public generic_proc_t
  {
    buff_t* debuff;
    const spell_data_t* value_spell;
    double base_tick_damage;
    double debuff_increase;
    ratfang_toxin_cb_t& equip_callback;

    ratfang_toxin_t( const special_effect_t& e, std::string_view name, const spell_data_t* spell,
                     ratfang_toxin_cb_t& equip )
      : generic_proc_t( e, name, spell ),
        debuff( nullptr ),
        value_spell( e.player->find_spell( 1216603 ) ),
        base_tick_damage( 0 ),
        debuff_increase( 0 ),
        equip_callback( equip )
    {
      auto ticks         = spell->duration() / spell->effectN( 1 ).period();
      base_tick_damage   = value_spell->effectN( 2 ).average( e ) / ticks;
      base_td            = base_tick_damage;
      debuff_increase    = value_spell->effectN( 3 ).average( e ) / ticks;
      base_td_multiplier = role_mult( e );
    }

    void execute() override
    {
      debuff = equip_callback.get_debuff( target );
      if ( debuff->up() )
      {
        base_td += debuff_increase * debuff->check();
        debuff->expire();
      }
      generic_proc_t::execute();
    }

    void last_tick( dot_t* d ) override
    {
      generic_proc_t::last_tick( d );
      base_td = base_tick_damage;
    }

    void reset() override
    {
      generic_proc_t::reset();
      base_td = base_tick_damage;
    }
  };

  auto use = create_proc_action<ratfang_toxin_t>( "ratfang_toxin", effect, "ratfang_toxin",
                                                  effect.player->find_spell( 1216606 ), *equip_cb );

  effect.execute_action = use;
}

// Garbagemancer's Last Resort
// 1219294 Driver
// 1219314 Ground Trigger
// 1219296 Value spell
// 1219299 Damage
void garbagemancers_last_resort( special_effect_t& effect )
{
  struct garbagemancers_last_resort_t : public generic_proc_t
  {
    timespan_t pulse_time;
    action_t* damage_action;

    garbagemancers_last_resort_t( const special_effect_t& e, std::string_view n, const spell_data_t* s )
      : generic_proc_t( e, n, s )
    {
      auto value_spell = e.player->find_spell( 1219296 );
      pulse_time       = timespan_t::from_seconds( value_spell->effectN( 2 ).base_value() );
      damage_action    = create_proc_action<generic_aoe_proc_t>( "garbocalypse", e, 1219299, true );
      damage_action->base_dd_min = damage_action->base_dd_max = value_spell->effectN( 1 ).average( e );
    }

    void impact( action_state_t* s ) override
    {
      generic_proc_t::impact( s );
      // TODO: probably better ground targeting emulation for the damage, unlikely targets in a place will still be
      // there after 10s
      make_event<ground_aoe_event_t>( *sim, player,
                                      ground_aoe_params_t()
                                        .target( s->target )
                                        .pulse_time( pulse_time )
                                        .n_pulses( 1 )
                                        .action( damage_action ) );
    }
  };

  auto use = create_proc_action<garbagemancers_last_resort_t>( "garbagemancers_last_resort", effect,
                                                               "garbagemancers_last_resort", effect.driver() );

  effect.execute_action = use;
}

// Funhouse Lens
// 1213432 Driver
// 1214603 Value Spell
// 1213433 Crit Buff
// 1213434 Haste Buff
void funhouse_lens( special_effect_t& effect )
{
  struct funhouse_lens_t : public spell_t
  {
    buff_t* crit_buff;
    buff_t* haste_buff;
    funhouse_lens_t( const special_effect_t& e, std::string_view n, const spell_data_t* s )
      : spell_t( n, e.player, s ), crit_buff( nullptr ), haste_buff( nullptr )
    {
      crit_buff = create_buff<stat_buff_t>( e.player, "funhouse_lens_crit", e.player->find_spell( 1213433 ) )
                      ->add_stat_from_effect_type( A_MOD_RATING, s->effectN( 1 ).average( e ) )
                      ->set_name_reporting( "Crit" );

      haste_buff = create_buff<stat_buff_t>( e.player, "funhouse_lens_haste", e.player->find_spell( 1213434 ) )
                       ->add_stat_from_effect_type( A_MOD_RATING, s->effectN( 2 ).average( e ) )
                       ->set_name_reporting( "Haste" );
    }

    void execute() override
    {
      spell_t::execute();

      if ( rng().roll( 0.5 ) )
        crit_buff->trigger();
      else
        haste_buff->trigger();
    }
  };

  effect.stat = STAT_ANY_DPS;
  effect.disable_buff();
  effect.execute_action = create_proc_action<funhouse_lens_t>( "funhouse_lens", effect, "funhouse_lens",
                                                               effect.player->find_spell( 1214603 ) );
}

// Suspicious Energy Drink
// 1216625 Driver
// 1216650 Buff
void suspicious_energy_drink( special_effect_t& effect )
{
  struct suspicious_energy_drink_buff_t : public stat_buff_t
  {
    double bonus_value;
    double hp_limit;
    double base_buff_value;
    suspicious_energy_drink_buff_t( player_t* p, util::string_view n, const special_effect_t& e, const spell_data_t* s )
      : stat_buff_t( p, n, s ), bonus_value( 0 ), hp_limit( 0 )
    {
      base_buff_value = e.driver()->effectN( 1 ).average( e );
      set_stat_from_effect_type( A_MOD_RATING, base_buff_value );
      bonus_value = e.driver()->effectN( 2 ).average( e );
      hp_limit    = e.driver()->effectN( 3 ).base_value();
    }

    void start( int s, double v, timespan_t d ) override
    {
      for ( auto& stat : stats )
      {
        stat.amount = base_buff_value;
        if ( player->health_percentage() < hp_limit ||
             player->rng().roll( player->thewarwithin_opts.suspicious_energy_drink_bonus_chance ) )
        {
          stat.amount += bonus_value;
        }
      }

      stat_buff_t::start( s, v, d );
    }
  };

  auto buff = create_buff<suspicious_energy_drink_buff_t>( effect.player, "suspicious_energy_drink", effect,
                                                           effect.player->find_spell( 1216650 ) );

  effect.custom_buff = buff;
  new dbc_proc_callback_t( effect.player, effect );
}

// Mug's Moxie Jug
// 471548 Driver
// 474376 Hidden Buff Driver
// 474285 Buff
void mugs_moxie_jug( special_effect_t& effect )
{
  auto crit_buff = create_buff<stat_buff_t>( effect.player, effect.player->find_spell( 474285 ) )
                       ->add_stat_from_effect( 1, effect.driver()->effectN( 1 ).average( effect ) )
                       ->set_refresh_behavior( buff_refresh_behavior::DISABLED );

  auto buff_driver          = new special_effect_t( effect.player );
  buff_driver->name_str     = "moxie_frenzy";
  buff_driver->spell_id     = effect.driver()->effectN( 1 ).trigger_spell_id();
  buff_driver->proc_flags_  = PF_ALL_DAMAGE | PF_ALL_HEAL;
  buff_driver->proc_flags2_ = PF2_ALL_HIT | PF2_ALL_CAST | PF2_LANDED;
  buff_driver->custom_buff  = crit_buff;
  effect.player->special_effects.push_back( buff_driver );

  auto second_proc = new dbc_proc_callback_t( effect.player, *buff_driver );

  auto CT = []( player_t* p, std::string_view n ) { return p->find_talent_spell( talent_tree::CLASS, n ); };
  auto ST = []( player_t* p, std::string_view n ) { return p->find_talent_spell( talent_tree::SPECIALIZATION, n ); };

  switch ( effect.player->type )
  {
    case WARLOCK:
      // Pretend everything is triggering soul leech which is triggering the trinket. This is not quite true in practice
      // though.
      second_proc->allow_pet_procs = true;
      buff_driver->proc_flags_ |= PF_PERIODIC | PF_HELPFUL_PERIODIC;
      buff_driver->proc_flags2_ |= PF2_PERIODIC_DAMAGE | PF2_PERIODIC_HEAL;

      effect.player->callbacks.register_callback_trigger_function(
          buff_driver->spell_id, dbc_proc_callback_t::trigger_fn_type::CONDITION,
          []( auto, const auto&, auto, const action_state_t* s, auto ) {
            if ( s->action->player->type == PLAYER_GUARDIAN || s->action->player->type == PLAYER_PET )
            {
              // Allowing every pet to hit it grants far too high of an uptime
              return s->action->player->rng().roll( 0.1 );
            }
            // Dots probably do the same. Probably.
            if ( s->result_type == result_amount_type::DMG_OVER_TIME )
              return s->action->player->rng().roll( 0.15 );
            return true;
          } );
      break;
    case EVOKER:
      // Heals trigger Scarlet, which triggers the trinket. Otherwise burnout procs do. Hooking these would be ideal but
      // there is no easy way to do that, so instead just roll the same chance.
      if ( ST( effect.player, "Scarlet Adaptation" ).ok() )
      {
        buff_driver->proc_flags_ |= PF_HELPFUL_PERIODIC;
        buff_driver->proc_flags2_ |= PF2_PERIODIC_HEAL;
      }
      if ( CT( effect.player, "Burnout" ).ok() )
      {
        buff_driver->proc_flags_ |= PF_PERIODIC;
        buff_driver->proc_flags2_ |= PF2_PERIODIC_DAMAGE;

        effect.player->callbacks.register_callback_trigger_function(
            buff_driver->spell_id, dbc_proc_callback_t::trigger_fn_type::CONDITION,
            []( auto, const auto&, auto, const action_state_t* s, auto ) {
              if ( s->result_type != result_amount_type::DMG_OVER_TIME )
                return true;
              if ( s->action->player->rng().roll( 0.16 ) )
                return true;
              return false;
            } );
      }
      break;
    default:
      break;
  }
  second_proc->activate_with_buff( crit_buff, true );

  effect.cooldown_   = effect.duration();
  effect.custom_buff = crit_buff;

  new dbc_proc_callback_t( effect.player, effect );
}

// Flarendo's Pilot Light
// 471057 Effect Driver (Disabled)
//  Effect 1 - Int
//  Effect 2 - Damage
//  Effect 3 - Cleave Target Multiplier
//  Effect 4 - Cleave Targets Hit
// 471142 Use Driver & Buff
// 473147 Charging Buff
// 473219 Damage
void flarendos_pilot_light( special_effect_t& effect )
{
  struct blastburn_roarcannon_t : spell_t
  {
    double secondary_target_multiplier;
    blastburn_roarcannon_t( special_effect_t& effect, const spell_data_t* damage_spell,
                            const spell_data_t* driver_spell )
      : spell_t( util::tokenize_fn( damage_spell->name_cstr() ), effect.player, damage_spell ),
        secondary_target_multiplier( driver_spell->effectN( 3 ).percent() )
    {
      aoe         = as<int>( driver_spell->effectN( 4 ).base_value() );
      base_dd_min = base_dd_max = driver_spell->effectN( 2 ).average( effect );
    }

    double composite_da_multiplier( const action_state_t* s ) const override
    {
      auto m = spell_t::composite_da_multiplier( s );

      if ( s->chain_target > 0 )
        m *= secondary_target_multiplier;

      return m;
    }
  };

  auto effect_driver = effect.player->find_spell( 471057 );

  if ( !effect_driver->ok() )
    return;

  auto damage_spell = effect.player->find_spell( 473219 );

  auto int_buff = create_buff<stat_buff_t>( effect.player, effect.driver() )
                      ->add_stat_from_effect( 1, effect_driver->effectN( 1 ).average( effect ) );

  auto charging_buff = create_buff<buff_t>( effect.player, effect.driver()->effectN( 2 ).trigger() )
                           ->set_reverse( true )
                           ->set_cooldown( 0_s );

  auto charging_buff_effect = new special_effect_t( effect.player );

  charging_buff_effect->name_str     = util::tokenize_fn( effect.driver()->effectN( 2 ).trigger()->name_cstr() );
  charging_buff_effect->spell_id     = effect.driver()->effectN( 2 ).trigger_spell_id();
  charging_buff_effect->proc_flags2_ = PF2_ALL_HIT;
  charging_buff_effect->cooldown_    = 0_s;
  effect.player->special_effects.push_back( charging_buff_effect );

  auto cb = new dbc_proc_callback_t( effect.player, *charging_buff_effect );
  cb->activate_with_buff( charging_buff, true );

  int_buff->set_stack_change_callback( [ charging_buff ]( buff_t*, int _old, int _new ) {
    if ( _new > _old )
      charging_buff->trigger();
  } );

  auto damage_action = new blastburn_roarcannon_t( effect, damage_spell, effect_driver );

  effect.player->callbacks.register_callback_execute_function(
      effect.driver()->effectN( 2 ).trigger_spell_id(),
      [ charging_buff, damage_action ]( auto, auto, player_t* t, auto ) {
        if ( !charging_buff->check() )
          return;

        charging_buff->decrement();

        if ( !charging_buff->check() )
        {
          damage_action->execute_on_target( t );
        }
      } );

  effect.custom_buff = int_buff;
}

// Amorphous Relic
// 472120 Driver
// 472195 Periodic Trigger
// 472184 Haste Buff
// 472185 Primary Buff
void amorphous_relic( special_effect_t& effect )
{
  buff_t* haste_buff = create_buff<stat_buff_t>( effect.player, effect.player->find_spell( 472184 ) )
                           ->add_stat_from_effect( 2, effect.driver()->effectN( 4 ).average( effect ) )
                           ->add_stat_from_effect( 3, effect.driver()->effectN( 3 ).average( effect ) )
                           ->set_cooldown( 0_ms );

  buff_t* crit_buff = create_buff<stat_buff_t>( effect.player, effect.player->find_spell( 472185 ) )
                          ->add_stat_from_effect( 2, effect.driver()->effectN( 1 ).average( effect ) )
                          ->add_stat_from_effect( 3, effect.driver()->effectN( 2 ).average( effect ) )
                          ->set_cooldown( 0_ms );

  buff_t* periodic = create_buff<buff_t>( effect.player, effect.player->find_spell( 472195 ) )
                         ->set_tick_on_application( true )
                         ->set_cooldown( 60_s ) // Not in data, but the ticking aura doesnt reapply if re-entering combat before 60s has passed.
                         ->set_tick_callback( [ haste_buff, crit_buff ]( buff_t* b, int, timespan_t ) {
                           if ( b->source->in_combat )
                           {
                             if ( b->source->rng().roll( 0.5 ) )
                               haste_buff->trigger();
                             else
                               crit_buff->trigger();
                           }
                         } );

  effect.player->register_on_combat_state_callback( [ periodic ]( player_t*, bool c ) {
    if ( !c )
      periodic->expire();
    else
      periodic->trigger();
  } );
}

// Synergistic Brewterializer
// 443393 Driver
// 449376 Barrel Missile
// 449490 Barrel Summon
// 223724 Barrel NPC
// 449381 Barrel Team Buff
// 449386 Barrel Explosion
void synergistic_brewterializer( special_effect_t& effect )
{
  auto damage_spell = effect.player->find_spell( 449386 );

  // Initial implementation - Just trigger the damage outright.
  auto aoe_damage = create_proc_action<generic_aoe_proc_t>( "synergistic_brewterialization", effect, damage_spell, true );

  aoe_damage->base_dd_min = aoe_damage->base_dd_max = effect.driver()->effectN( 1 ).average( effect );
  aoe_damage->base_multiplier                       = role_mult( effect.player, effect.driver() );

  effect.execute_action = aoe_damage;

  new dbc_proc_callback_t( effect.player, effect );
}

// Zee's Thug Hotline
// 1217356 Driver
// Pocket Ace:
// 1217431 Summon
// 1217675 Gutstab - Only uses in ST
// 1217676 Fan of Stabs - Only uses in AoE
// Uses a basic auto attack as well
// Snake Eyes:
// 1217432 Summon
// 1217719 Snipe - Only Ability
// Does not auto attack
// Thwack Jack:
// 1217427 Summon
// 1217638 Thwack! - Only uses in ST
// 1217665 Thwack Thwack Thwack! - Only uses in AoE
// Uses a basic auto attack as well
void zees_thug_hotline( special_effect_t& effect )
{
  struct auto_attack_melee_t : public melee_attack_t
  {
    auto_attack_melee_t( pet_t* p, std::string_view name = "main_hand", action_t* a = nullptr,
                         const special_effect_t* e = nullptr )
      : melee_attack_t( name, p )
    {
      this->background = this->repeating = true;
      this->not_a_proc = this->may_crit = true;
      this->special                     = false;
      this->weapon_multiplier           = 0.7;
      this->trigger_gcd                 = 0_ms;
      this->school                      = SCHOOL_PHYSICAL;
      this->stats->school               = SCHOOL_PHYSICAL;
      this->base_multiplier = p->main_hand_weapon.swing_time.total_seconds();
      this->base_dd_min = this->base_dd_max = e->driver()->effectN( 5 ).average( *e );

      auto proxy = a;
      auto it    = range::find( proxy->child_action, name, &action_t::name );
      if ( it != proxy->child_action.end() )
        stats = ( *it )->stats;
      else
        proxy->add_child( this );
    }

    // Pet melee attacks seem to still scale with aura 380 and 531
    double composite_da_multiplier( const action_state_t* s ) const override
    {
      double m = melee_attack_t::composite_da_multiplier( s );
      m *= this->player->cast_pet()->owner->composite_player_pet_damage_multiplier( s, player->type == PLAYER_GUARDIAN );
      return m;
    }

    double composite_target_multiplier( player_t* p ) const override
    {
      double m = melee_attack_t::composite_target_multiplier( p );
      m *= this->player->cast_pet()->owner->composite_player_target_pet_damage_multiplier( p, player->type == PLAYER_GUARDIAN );
      return m;
    }

    void execute() override
    {
      if ( this->player->executing )
        this->schedule_execute();
      else
        melee_attack_t::execute();
    }
  };

  struct zees_thug_hotline_pet_spell_t : public spell_t
  {
    zees_thug_hotline_pet_spell_t( std::string_view n, pet_t* p, const spell_data_t* s, std::string_view options_str,
                                   action_t* a, const special_effect_t& e )
      : spell_t( n, p, s )
    {
      auto proxy = a;
      auto it    = range::find( proxy->child_action, data().id(), &action_t::id );
      if ( it != proxy->child_action.end() )
        stats = ( *it )->stats;
      else
        proxy->add_child( this );

      parse_options( options_str );

      base_multiplier = role_mult( e );
      cooldown->duration = 3.4_s;
    }
  };

  struct gutstab_t : public zees_thug_hotline_pet_spell_t
  {
    gutstab_t( const special_effect_t& e, unique_gear_pet_t* p, std::string_view options_str, action_t* a )
      : zees_thug_hotline_pet_spell_t( "gutstab", p, p->find_spell( 1217675 ), options_str, a, e )
    {
      base_dd_min = base_dd_max = e.driver()->effectN( 1 ).average( e );
    }
  };

  struct fan_of_stabs_t : public zees_thug_hotline_pet_spell_t
  {
    fan_of_stabs_t( const special_effect_t& e, unique_gear_pet_t* p, std::string_view options_str, action_t* a )
      : zees_thug_hotline_pet_spell_t( "fan_of_stabs", p, p->find_spell( 1217676 ), options_str, a, e )
    {
      aoe         = -1;
      base_dd_min = base_dd_max = e.driver()->effectN( 4 ).average( e );
    }
  };

  struct snipe_t : public zees_thug_hotline_pet_spell_t
  {
    snipe_t( const special_effect_t& e, unique_gear_pet_t* p, std::string_view options_str, action_t* a )
      : zees_thug_hotline_pet_spell_t( "snipe", p, p->find_spell( 1217719 ), options_str, a, e )
    {
      base_dd_min = base_dd_max = e.driver()->effectN( 3 ).average( e );
    }
  };

  struct thwack_t : public zees_thug_hotline_pet_spell_t
  {
    thwack_t( const special_effect_t& e, unique_gear_pet_t* p, std::string_view options_str, action_t* a )
      : zees_thug_hotline_pet_spell_t( "thwack", p, p->find_spell( 1217638 ), options_str, a, e )
    {
      base_dd_min = base_dd_max = e.driver()->effectN( 2 ).average( e );
    }
  };

  struct thwack_thwack_thwack_t : public zees_thug_hotline_pet_spell_t
  {
    thwack_thwack_thwack_t( const special_effect_t& e, unique_gear_pet_t* p, std::string_view options_str,
                            action_t* a )
      : zees_thug_hotline_pet_spell_t( "thwack_thwack_thwack", p, p->find_spell( 1217665 ), options_str, a, e )
    {
      aoe         = -1;
      base_dd_min = base_dd_max = e.driver()->effectN( 4 ).average( e );
    }
  };

  struct pocket_ace_pet_t : public unique_gear_pet_t
  {
    pocket_ace_pet_t( const special_effect_t& e, action_t* parent = nullptr )
      : base_t( "pocket_ace", e, e.player->find_spell( 1217431 ) )
    {
      parent_action               = parent;
      use_auto_attack             = true;
      main_hand_weapon.type       = WEAPON_BEAST;
      main_hand_weapon.swing_time = 1.6_s;
    }

    attack_t* create_auto_attack() override
    {
      auto a                = new auto_attack_melee_t( this, "main_hand_pocket_ace", parent_action, &effect );
      a->name_str_reporting = "Melee";
      return a;
    }

    action_t* create_action( std::string_view name, std::string_view options_str ) override
    {
      if ( name == "gutstab" )
        return new gutstab_t( effect, this, options_str, parent_action );
      if ( name == "fan_of_stabs" )
        return new fan_of_stabs_t( effect, this, options_str, parent_action );

      return base_t::create_action( name, options_str );
    }

    void init_action_list() override
    {
      base_t::init_action_list();
      action_priority_list_t* def = get_action_priority_list( "default" );
      def->add_action( "gutstab,if=active_enemies=1" );
      def->add_action( "fan_of_stabs,if=active_enemies>1" );
    }
  };

  struct snake_eyes_pet_t : public unique_gear_pet_t
  {
    snake_eyes_pet_t( const special_effect_t& e, action_t* parent = nullptr )
      : base_t( "snake_eyes", e, e.player->find_spell( 1217432 ) )
    {
      parent_action = parent;
    }

    action_t* create_action( std::string_view name, std::string_view options_str ) override
    {
      if ( name == "snipe" )
        return new snipe_t( effect, this, options_str, parent_action );

      return base_t::create_action( name, options_str );
    }

    void init_action_list() override
    {
      base_t::init_action_list();
      action_priority_list_t* def = get_action_priority_list( "default" );
      def->add_action( "snipe" );
    }
  };

  struct thwack_jack_pet_t : public unique_gear_pet_t
  {
    thwack_jack_pet_t( const special_effect_t& e, action_t* parent = nullptr )
      : base_t( "thwack_jack", e, e.player->find_spell( 1217427 ) )
    {
      parent_action               = parent;
      use_auto_attack             = true;
      main_hand_weapon.type       = WEAPON_BEAST;
      main_hand_weapon.swing_time = 2.6_s;
    }

    attack_t* create_auto_attack() override
    {
      auto a                = new auto_attack_melee_t( this, "main_hand_thwack_jack", parent_action, &effect );
      a->name_str_reporting = "Melee";
      return a;
    }

    action_t* create_action( std::string_view name, std::string_view options_str ) override
    {
      if ( name == "thwack" )
        return new thwack_t( effect, this, options_str, parent_action );
      if ( name == "thwack_thwack_thwack" )
        return new thwack_thwack_thwack_t( effect, this, options_str, parent_action );

      return base_t::create_action( name, options_str );
    }

    void init_action_list() override
    {
      base_t::init_action_list();
      action_priority_list_t* def = get_action_priority_list( "default" );
      def->add_action( "thwack,if=active_enemies=1" );
      def->add_action( "thwack_thwack_thwack,if=active_enemies>=2" );
    }
  };

  struct zees_thug_hotline_t : public generic_proc_t
  {
    spawner::pet_spawner_t<pocket_ace_pet_t> pocket_ace_spawner;
    spawner::pet_spawner_t<snake_eyes_pet_t> snake_eyes_spawner;
    spawner::pet_spawner_t<thwack_jack_pet_t> thwack_jack_spawner;

    zees_thug_hotline_t( const special_effect_t& e )
      : generic_proc_t( e, "zees_thug_hotline", e.driver() ),
        pocket_ace_spawner( "pocket_ace", e.player ),
        snake_eyes_spawner( "snake_eyes", e.player ),
        thwack_jack_spawner( "thwack_jack", e.player )
    {
      auto pocket_ace_summon_spell = e.player->find_spell( 1217431 );
      auto pocket_ace = new action_t( action_e::ACTION_OTHER, "call_pocket_ace", e.player, pocket_ace_summon_spell );
      pocket_ace_spawner.set_creation_callback(
          [ &e, pocket_ace ]( player_t* ) { return new pocket_ace_pet_t( e, pocket_ace ); } );
      pocket_ace_spawner.set_default_duration( pocket_ace_summon_spell->duration() );
      pocket_ace_spawner.set_max_pets( 1 );
      pocket_ace_spawner.set_replacement_strategy( spawner::pet_replacement_strategy::REPLACE_OLDEST );
      add_child( pocket_ace );

      auto snake_eyes_summon_spell = e.player->find_spell( 1217432 );
      auto snake_eyes = new action_t( action_e::ACTION_OTHER, "call_snake_eyes", e.player, snake_eyes_summon_spell );
      snake_eyes_spawner.set_creation_callback(
          [ &e, snake_eyes ]( player_t* ) { return new snake_eyes_pet_t( e, snake_eyes ); } );
      snake_eyes_spawner.set_default_duration( snake_eyes_summon_spell->duration() );
      snake_eyes_spawner.set_max_pets( 1 );
      snake_eyes_spawner.set_replacement_strategy( spawner::pet_replacement_strategy::REPLACE_OLDEST );
      add_child( snake_eyes );

      auto thwack_jack_summon_spell = e.player->find_spell( 1217427 );
      auto thwack_jack = new action_t( action_e::ACTION_OTHER, "call_thwack_jack", e.player, thwack_jack_summon_spell );
      thwack_jack_spawner.set_creation_callback(
          [ &e, thwack_jack ]( player_t* ) { return new thwack_jack_pet_t( e, thwack_jack ); } );
      thwack_jack_spawner.set_default_duration( thwack_jack_summon_spell->duration() );
      thwack_jack_spawner.set_max_pets( 1 );
      thwack_jack_spawner.set_replacement_strategy( spawner::pet_replacement_strategy::REPLACE_OLDEST );
      add_child( thwack_jack );

      e.player->buffs.bloodlust->add_stack_change_callback( [ & ]( buff_t*, int, int new_ ) {
          if ( new_ )
          {
            make_event( sim, [ this ] {
              pocket_ace_spawner.spawn();
              snake_eyes_spawner.spawn();
              thwack_jack_spawner.spawn();
            } );
          }
        } );
    }

    void execute() override
    {
      generic_proc_t::execute();
      int pet_id = rng().range( 0, 3 );
      switch ( pet_id )
      {
        case 0:
          pocket_ace_spawner.spawn();
          break;
        case 1:
          snake_eyes_spawner.spawn();
          break;
        case 2:
          thwack_jack_spawner.spawn();
          break;
        default:
          break;
      }
    }
  };

  effect.execute_action = create_proc_action<zees_thug_hotline_t>( "zees_thug_hotline", effect );
  effect.proc_flags2_ = PF2_ALL_HIT;

  new dbc_proc_callback_t( effect.player, effect );
}

// 443533 Equip Driver & Values
// 443535 On Use
// 443534 On Use Buff, radiance, double all effects
// 450696 50 verses of Resillience tracking buff
// 450699 50 verses of Radiance tracking buff
// 450706 Inner Resillience Proc driver
// 450720 Inner Radiance Proc driver
// 450719 Magic Absorb buff
// 450721 Ire of Devotion damage spell

// 443533 Values
// s1 - static value of 50
// s2 - crit strike amount increase - Used in 450720 buff
// s3 - devotion of ire damage - Used in 450721 spell
// s4 - armor increase - Used in 450706 buff
// s5 - magic absorb value - Used in 450719 buff
void tome_of_lights_devotion( special_effect_t& effect )
{
  auto equip_driver = effect.player->find_spell( 443533 );
  assert( equip_driver && "Tome of Lights Devotion equip driver not found" );

  if ( unique_gear::create_fallback_buffs(
    effect, { "inner_resilience", "inner_radiance", "ward_of_devotion" } ) )
    return;

  // Setup double value buff
  auto radiance_buff = create_buff<buff_t>( effect.player, "radiance_tome", effect.player->find_spell( 443534 ) )
    ->set_name_reporting( "radiance" );

  struct inner_resilience_cb_t : public dbc_proc_callback_t
  {
    struct ward_of_devotion_buff_t : public absorb_buff_t
    {
      ward_of_devotion_buff_t( const special_effect_t& e, const spell_data_t* s, const spell_data_t* data )
        : absorb_buff_t( e.player, "ward_of_devotion", s )
      {
        cumulative = false;
        set_default_value( data->effectN( 5 ).average( e ) );
      }
    };

    buff_t* radiance_buff;
    buff_t* ward_of_devotion_buff;

    const spell_data_t* data;

    inner_resilience_cb_t( const special_effect_t& e, buff_t* rb )
      : dbc_proc_callback_t( e.player, e ),
      radiance_buff( nullptr ),
      ward_of_devotion_buff( nullptr )
    {
      radiance_buff = rb;

      data = e.player->find_spell( 443533 );
      ward_of_devotion_buff = make_buff<ward_of_devotion_buff_t>( e, e.player->find_spell( 450719 ), data );
    }

    void execute( const spell_data_t*, player_t*, action_state_t* ) override
    {
      if ( radiance_buff->check() )
        ward_of_devotion_buff->trigger(-1, ward_of_devotion_buff->DEFAULT_VALUE() * 2 );
      else
        ward_of_devotion_buff->trigger();
    }
  };

  struct tome_of_lights_devotion_cb_t : public dbc_proc_callback_t
  {
    bool resilience_phase;
    dbc_proc_callback_t* inner_resilience_cb;
    dbc_proc_callback_t* inner_radiance_cb;

    // Setup both tracking buffs
    buff_t* resilience_verses_tracker;
    buff_t* radiance_verses_tracker;

    // Setup the armor and crit buffs
    buff_t* inner_radiance_buff;    // Crit buff
    buff_t* inner_resilience_buff;  // Armor buff

    // Pointer to radiance buff
    buff_t* radiance_buff;

    struct ire_of_devotion_t : generic_proc_t
    {
      buff_t* radiance_buff;
      ire_of_devotion_t( const special_effect_t& e, const spell_data_t* spell, const spell_data_t* data, buff_t* rb )
        : generic_proc_t( e, "ire_of_devotion", spell ),
          radiance_buff( nullptr )
      {
        radiance_buff = rb;
        base_dd_min = base_dd_max = data->effectN( 3 ).average( e.item );
      }

      double composite_da_multiplier( const action_state_t* s ) const override
      {
        double m = generic_proc_t::composite_da_multiplier( s );

        if ( radiance_buff->check() )
            m *= 2;

        return m;
      }
    };

    tome_of_lights_devotion_cb_t( const special_effect_t& e, buff_t* rb )
      : dbc_proc_callback_t( e.player, e ),
        resilience_phase( true ),
        resilience_verses_tracker( nullptr ),
        radiance_verses_tracker( nullptr ),
        inner_radiance_buff( nullptr ),
        inner_resilience_buff( nullptr ),
        radiance_buff( nullptr )
      {
        radiance_buff = rb;

        auto inner_resilience_driver = effect.player->find_spell( 450706 );
        assert( inner_resilience_driver && "Tome of Lights Devotion inner resilience driver not found" );

        auto inner_radiance_driver = effect.player->find_spell( 450720 );
        assert( inner_radiance_driver && "Tome of Lights Devotion inner radiance driver not found" );

        inner_radiance_buff = create_buff<stat_buff_with_multiplier_t>( e.player, e.player->find_spell( 450720 ) )
        ->set_stat_from_effect_type( A_MOD_RATING, e.player->find_spell( 443533 )->effectN( 2 ).average( e.item ) )
        ->set_rppm( RPPM_DISABLE )
        ->set_quiet( false );

        inner_resilience_buff = create_buff<stat_buff_with_multiplier_t>( e.player, e.player->find_spell( 450706 ) )
        ->set_stat( STAT_BONUS_ARMOR, e.player->find_spell( 443533 )->effectN( 4 ).average( e.item ) )
        ->add_invalidate( CACHE_BONUS_ARMOR )
        ->set_rppm( RPPM_DISABLE )
        ->set_quiet( false );


        resilience_verses_tracker = create_buff<buff_t>( e.player, e.player->find_spell( 450696 ) );
        resilience_verses_tracker->expire_at_max_stack = true;
        resilience_verses_tracker->set_expire_callback( [ this ]( buff_t*, int, timespan_t ) {
                                      resilience_phase = false;
                                      inner_resilience_buff->expire();
                                      inner_radiance_buff->trigger();
                                      radiance_verses_tracker->trigger();
                                      } );

        radiance_verses_tracker = create_buff<buff_t>( e.player, e.player->find_spell( 450699 ) );
        radiance_verses_tracker->expire_at_max_stack = true;
        radiance_verses_tracker->set_expire_callback( [ this ]( buff_t*, int, timespan_t ) {
                                      resilience_phase = true;
                                      inner_radiance_buff->expire();
                                      inner_resilience_buff->trigger();
                                      resilience_verses_tracker->trigger();
                                      } );

        auto inner_resilience = new special_effect_t( effect.player );
        inner_resilience->name_str = "inner_resilience";
        inner_resilience->spell_id = inner_resilience_driver->id();
        inner_resilience->item = e.item;
        inner_resilience->proc_flags2_ = PF2_ALL_HIT;
        inner_resilience->disable_buff();
        effect.player->special_effects.push_back( inner_resilience );

        inner_resilience_cb = new inner_resilience_cb_t( *inner_resilience, radiance_buff );
        inner_resilience_cb->activate_with_buff( resilience_verses_tracker, true );

        auto inner_radiance = new special_effect_t( effect.player );
        inner_radiance->name_str = "inner_radiance";
        inner_radiance->spell_id = inner_radiance_driver->id();
        inner_radiance->item = e.item;
        inner_radiance->proc_flags2_ = PF2_ALL_HIT;
        inner_radiance->disable_buff();
        inner_radiance->execute_action = create_proc_action<ire_of_devotion_t>( "ire_of_devotion", effect, e.player->find_spell( 450721 ), e.player->find_spell( 443533 ), radiance_buff );
        effect.player->special_effects.push_back( inner_radiance );

        inner_radiance_cb = new dbc_proc_callback_t( effect.player, *inner_radiance );
        inner_radiance_cb->activate_with_buff( radiance_verses_tracker, true );
      }

    void execute( const spell_data_t*, player_t*, action_state_t* ) override
    {
      if ( resilience_phase )
      {
        inner_resilience_buff->trigger();
        resilience_verses_tracker->trigger();
      }
      else
      {
        inner_radiance_buff->trigger();
        radiance_verses_tracker->trigger();
      }
    }
  };

  struct tome_of_lights_devotion_t : public generic_proc_t
  {
    tome_of_lights_devotion_cb_t* equip_cb;
    buff_t* radiance_buff;

    tome_of_lights_devotion_t( const special_effect_t& e, const spell_data_t* spell, tome_of_lights_devotion_cb_t* cb, buff_t* rb )
      : generic_proc_t( e, "tome_of_lights_devotion", spell )
    {
      equip_cb = cb;
      radiance_buff = rb;
    }

    void execute() override
    {
      generic_proc_t::execute();
      if ( equip_cb->resilience_phase )
      {
        if ( !equip_cb->resilience_verses_tracker->check() ) // New sim, no buffs up yet, force a trigger so we can expire cleanly
          equip_cb->resilience_verses_tracker->trigger();
        equip_cb->resilience_verses_tracker->expire();
      }
      else
      {
        if ( !equip_cb->radiance_verses_tracker->check() ) // New sim, no buffs up yet, force a trigger so we can expire cleanly
          equip_cb->radiance_verses_tracker->trigger();
        equip_cb->radiance_verses_tracker->expire();
      }

      radiance_buff->trigger();
      debug_cast<stat_buff_with_multiplier_t*>(equip_cb->inner_radiance_buff)->stat_mul = 2.0;
      debug_cast<stat_buff_with_multiplier_t*>(equip_cb->inner_resilience_buff)->stat_mul = 2.0;
    }
  };

  auto equip = new special_effect_t( effect.player );
  equip->name_str = "tome_of_lights_devotion_equip";
  equip->item = effect.item;
  equip->spell_id = equip_driver->id();
  equip->proc_flags_ = equip_driver->proc_flags();
  equip->proc_flags2_ = PF2_ALL_HIT;
  effect.player->special_effects.push_back( equip );

  auto equip_cb = new tome_of_lights_devotion_cb_t( *equip, radiance_buff );
  equip_cb->initialize();
  equip_cb->activate();

  effect.player->register_combat_begin( [equip_cb] ( player_t* ) {
    equip_cb->resilience_phase = true;
    equip_cb->inner_resilience_buff->trigger();
    equip_cb->resilience_verses_tracker->trigger();
  } );

  // Setup expire callback for radiance buff
  radiance_buff->set_expire_callback( [ equip_cb ]( buff_t*, int, timespan_t ) {
    debug_cast<stat_buff_with_multiplier_t*>(equip_cb->inner_radiance_buff)->stat_mul = 1.0;
    debug_cast<stat_buff_with_multiplier_t*>(equip_cb->inner_resilience_buff)->stat_mul = 1.0;
  } );

  effect.type = SPECIAL_EFFECT_USE;
  effect.execute_action = create_proc_action<tome_of_lights_devotion_t>( "tome_of_lights_devotion", effect, equip_driver, equip_cb, radiance_buff );
}

// Mister Lock-n-Stalk
// 467469 Equip Driver
// 467485 Use Driver
// 1215690 Precision Targeting damage
// 1215733 Mass Destruction damage
void mister_locknstalk( special_effect_t& effect )
{
  enum mister_locknstalk_modes_t
  {
    MODE_DYNAMIC,
    MODE_SINGLE_TARGET,
    MODE_AOE
  };

  struct mister_locknstalk_cb_t : public dbc_proc_callback_t
  {
    action_t* st_damage;
    action_t* aoe_damage;
    action_t* proxy;
    mister_locknstalk_modes_t mode;
    mister_locknstalk_cb_t( const special_effect_t& e )
      : dbc_proc_callback_t( e.player, e ),
        st_damage( nullptr ),
        aoe_damage( nullptr ),
        proxy( nullptr ),
        mode( MODE_DYNAMIC )
    {
      proxy                  = new action_t( action_e::ACTION_OTHER, "mister_locknstalk", e.player, e.driver() );
      auto st_damage_spell   = e.player->find_spell( 1215690 );
      st_damage              = create_proc_action<generic_proc_t>( "precision_targeting", e, st_damage_spell );
      st_damage->base_dd_min = st_damage->base_dd_max = e.driver()->effectN( 1 ).average( e );
      st_damage->base_multiplier                      = role_mult( e.player, e.player->find_spell( 467492 ) );
      proxy->add_child( st_damage );

      auto aoe_damage_spell   = e.player->find_spell( 1215733 );
      aoe_damage              = create_proc_action<generic_aoe_proc_t>( "mass_destruction", e, aoe_damage_spell, true );
      aoe_damage->base_dd_min = aoe_damage->base_dd_max = e.driver()->effectN( 2 ).average( e );
      aoe_damage->base_multiplier                       = role_mult( e.player, e.player->find_spell( 467497 ) );
      proxy->add_child( aoe_damage );
    }

    void execute( const spell_data_t*, player_t* t, action_state_t* )
    {
      switch ( mode )
      {
        case MODE_DYNAMIC:
          if ( listener->sim->target_non_sleeping_list.size() > 1 )
            aoe_damage->execute_on_target( t );
          else
            st_damage->execute_on_target( t );
          break;
        case MODE_SINGLE_TARGET:
          st_damage->execute_on_target( t );
          break;
        case MODE_AOE:
          aoe_damage->execute_on_target( t );
          break;
        default:
          break;
      }

      proxy->stats->add_execute( 0_ms, listener );
    }
  };

  effect.proc_flags2_ = PF2_ALL_HIT;

  auto cb = new mister_locknstalk_cb_t( effect );

  const auto& option = effect.player->thewarwithin_opts.mister_locknstalk_mode;
  if ( !option.is_default() )
  {
    if ( util::str_compare_ci( option, "dynamic" ) )
      cb->mode = MODE_DYNAMIC;
    else if ( util::str_compare_ci( option, "single_target" ) )
      cb->mode = MODE_SINGLE_TARGET;
    else if ( util::str_compare_ci( option, "aoe" ) )
      cb->mode = MODE_AOE;
    else
      throw sc_invalid_apl_argument( "Valid 'thewarwithin.mister_locknstalk_mode' are: dynamic, single_target, aoe" );
  }
}

// Junkmaestro's Mega Magnet
// 471211 equip driver
//  effect 1 damage per stack
//  effect 2 max aoe
//  effect 3 dot tick percent of damage
// 471212 on-use
// 1219661 charging buff
// 1219662 impact damage (splits into an addition hit every 10 stacks)
// 1220481 dot spell
// 1220483 tick damage spell
void junkmaestros_mega_magnet( special_effect_t& effect )
{
  if ( unique_gear::create_fallback_buffs( effect, { "junkmaestros_mega_magnet" } ) )
    return;

  unsigned equip_id = 471211;
  auto equip = find_special_effect( effect.player, equip_id );
  assert( equip && "Junkmaestro's Mega Magnet missing equip effect" );

  auto charging_buff = create_buff<buff_t>( effect.player, effect.player->find_spell( 1219661 ) )
    ->set_constant_behavior( buff_constant_behavior::NEVER_CONSTANT );

  equip->custom_buff = charging_buff;
  equip->proc_flags2_ = PF2_ALL_HIT;

  new dbc_proc_callback_t( effect.player, *equip );

  struct recycle_garbage_t : public generic_proc_t
  {
    struct junkmaestros_mega_magnet_t : public generic_proc_t
    {
      junkmaestros_mega_magnet_t( const special_effect_t& e ) : generic_proc_t( e, "junkmaestros_mega_magnet", e.player->find_spell( 1219662 ) )
      {
        base_multiplier *= role_mult( e );
      }
    };

    struct putrid_garbage_tick_t : public generic_proc_t
    {
      putrid_garbage_tick_t( const special_effect_t& e, int targets ) : generic_proc_t( e, "junkmaestros_putrid_garbage", e.player->find_spell( 1220483 ) )
      {
        aoe = targets;
      }

      size_t available_targets( std::vector< player_t* >& tl ) const override
      {
        generic_proc_t::available_targets( tl );

        range::erase_remove( tl, target );

        return tl.size();
      }
    };

    struct putrid_garbage_dot_t : public generic_proc_t
    {
      action_t* tick_damage;

      putrid_garbage_dot_t( const special_effect_t& e, action_t* tick ) : generic_proc_t( e, "junkmaestros_putrid_garbage_dot", e.player->find_spell( 1220481 ) ),
        tick_damage( tick )
      {
      }

      void tick( dot_t* d ) override
      {
        generic_proc_t::tick( d );

        tick_damage->execute_on_target( d->target );
      }
    };

    buff_t* charging_buff;
    action_t* damage;
    action_t* tick_damage;
    action_t* dot;
    double stack_damage;
    double tick_percent;

    recycle_garbage_t( const special_effect_t& e, buff_t* charging_buff, const spell_data_t* equip_data ) : generic_proc_t( e, "recycle_garbage", e.driver() ),
      charging_buff( charging_buff ),
      damage( create_proc_action<junkmaestros_mega_magnet_t>( "junkmaestros_mega_magnet", e ) ),
      tick_damage( create_proc_action<putrid_garbage_tick_t>( "junkmaestros_putrid_garbage", e, as<int>( equip_data->effectN( 2 ).base_value() ) ) ),
      dot( create_proc_action<putrid_garbage_dot_t>( "junkmaestros_putrid_garbage_dot", e, tick_damage ) ),
      stack_damage( equip_data->effectN( 1 ).average( e ) ),
      tick_percent( equip_data->effectN( 3 ).percent() / ( dot->data().duration() / dot->data().effectN( 1 ).period() ) )
    {
    }

    void execute() override
    {
      generic_proc_t::execute();

      int hits = 1 + as<int>( charging_buff->check() / 10 );
      double total = stack_damage * charging_buff->check();
      for ( int i = 0; i < hits; i++ )
        damage->execute_on_target( target, total / hits );

      tick_damage->base_dd_min = tick_damage->base_dd_max = total * tick_percent;
      dot->execute_on_target( target );

      charging_buff->expire();
    }
  };

  effect.execute_action = create_proc_action<recycle_garbage_t>( "recycle_garbage", effect, charging_buff, equip->driver() );
}

void imperfect_ascendancy_serum( special_effect_t& effect )
{
  struct ascension_channel_t : public proc_spell_t
  {
    buff_t* buff;
    action_t* use_action;  // if this exists, then we're prechanneling via the APL

    ascension_channel_t( const special_effect_t& e, buff_t* ascension )
      : proc_spell_t( "ascension_channel", e.player, e.driver(), e.item )
    {
      channeled = hasted_ticks = hasted_dot_duration = true;
      harmful                                        = false;
      dot_duration = base_tick_time = base_execute_time;
      base_execute_time             = 0_s;
      buff                          = ascension;
      effect                        = &e;
      interrupt_auto_attack         = false;

      for ( auto a : player->action_list )
      {
        if ( a->action_list && a->action_list->name_str == "precombat" && a->name_str == "use_item_" + item->name_str )
        {
          a->harmful = harmful;  // pass down harmful to allow action_t::init() precombat check bypass
          use_action = a;
          use_action->base_execute_time = base_tick_time;
          break;
        }
      }
    }

    void execute() override
    {
      if ( !player->in_combat )  // if precombat...
      {
        if ( use_action )  // ...and use_item exists in the precombat apl
        {
          precombat_buff();
        }
      }
      else
      {
        proc_spell_t::execute();
        event_t::cancel( player->readying );
        player->delay_ranged_auto_attacks( composite_dot_duration( execute_state ) );
      }
    }

    void last_tick( dot_t* d ) override
    {
      bool was_channeling = player->channeling == this;

      cooldown->adjust( d->duration() );

      auto cdgrp = player->get_cooldown( effect->cooldown_group_name() );
      cdgrp->adjust( d->duration() );

      proc_spell_t::last_tick( d );
      buff->trigger();

      if ( was_channeling && !player->readying )
        player->schedule_ready();
    }

    void precombat_buff()
    {
      timespan_t time = 0_ms;

      if ( time == 0_ms )  // No global override, check for an override from an APL variable
      {
        for ( auto v : player->variables )
        {
          if ( v->name_ == "imperfect_ascendancy_precombat_cast" )
          {
            time = timespan_t::from_seconds( v->value() );
            break;
          }
        }
      }

      // shared cd (other trinkets & on-use items)
      auto cdgrp = player->get_cooldown( effect->cooldown_group_name() );

      if ( time == 0_ms )  // No hardcoded override, so dynamically calculate timing via the precombat APL
      {
        time            = data().cast_time();
        const auto& apl = player->precombat_action_list;

        auto it = range::find( apl, use_action );
        if ( it == apl.end() )
        {
          sim->print_debug(
              "WARNING: Precombat /use_item for Imperfect Ascendancy Serum exists but not found in precombat APL!" );
          return;
        }

        cdgrp->start( 1_ms );  // tap the shared group cd so we can get accurate action_ready() checks

        // add cast time or gcd for any following precombat action
        std::for_each( it + 1, apl.end(), [ &time, this ]( action_t* a ) {
          if ( a->action_ready() )
          {
            timespan_t delta =
                std::max( std::max( a->base_execute_time.value(), a->trigger_gcd ) * a->composite_haste(), a->min_gcd );
            sim->print_debug( "PRECOMBAT: Imperfect Ascendancy Serum precast timing pushed by {} for {}", delta,
                              a->name() );
            time += delta;

            return a->harmful;  // stop processing after first valid harmful spell
          }
          return false;
        } );
      }
      else if ( time < base_tick_time )  // If APL variable can't set to less than cast time
      {
        time = base_tick_time;
      }

      // how long you cast for
      auto cast = base_tick_time;
      // total duration of the buff
      auto total = buff->buff_duration();
      // actual duration of the buff you'll get in combat
      auto actual = total + cast - time;
      // cooldown on effect/trinket at start of combat
      auto cd_dur = cooldown->duration + cast - time;
      // shared cooldown at start of combat
      auto cdgrp_dur = std::max( 0_ms, effect->cooldown_group_duration() + cast - time );

      sim->print_debug( "PRECOMBAT: Imperfect Ascendency Serum started {}s before combat via {}, {}s in-combat buff",
                        time, use_action ? "APL" : "TWW_OPT", actual );

      buff->trigger( 1, buff_t::DEFAULT_VALUE(), 1.0, actual );

      if ( use_action )  // from the apl, so cooldowns will be started by use_item_t. adjust. we are still in precombat.
      {
        make_event( *sim, [ this, cast, time, cdgrp ] {  // make an event so we adjust after cooldowns are started
          cooldown->adjust( cast - time );

          if ( use_action )
            use_action->cooldown->adjust( cast - time );

          cdgrp->adjust( cast - time );
        } );
      }
      else  // via bfa. option override, start cooldowns. we are in-combat.
      {
        cooldown->start( cd_dur );

        if ( use_action )
          use_action->cooldown->start( cd_dur );

        if ( cdgrp_dur > 0_ms )
          cdgrp->start( cdgrp_dur );
      }
    }
  };

  auto buff_spell = effect.driver();
  buff_t* buff    = create_buff<stat_buff_t>( effect.player, "ascension_trinket", buff_spell )
                     ->add_stat_from_effect( 1, effect.driver()->effectN( 1 ).average( effect ) )
                     ->add_stat_from_effect( 2, effect.driver()->effectN( 2 ).average( effect ) )
                     ->add_stat_from_effect( 4, effect.driver()->effectN( 4 ).average( effect ) )
                     ->add_stat_from_effect( 5, effect.driver()->effectN( 5 ).average( effect ) )
                     ->set_cooldown( 0_ms );

  auto action           = new ascension_channel_t( effect, buff );
  effect.execute_action = action;
  effect.disable_buff();
}

// Ringing Ritual Mud
// NYI: CDR from periodic damage taken
void ringing_ritual_mud( special_effect_t& effect )
{
  struct mudborne_t : absorb_t
  {
    action_t* tick;
    buff_t* damage_buff;
    buff_t* absorb_buff;

    mudborne_t( const special_effect_t& effect )
      : absorb_t( "mudborne", effect.player, effect.driver() ),
        tick( nullptr ),
        damage_buff( nullptr ),
        absorb_buff( nullptr )
    {
      const spell_data_t* equip = effect.player->find_spell( 1221145 );
      base_dd_min = base_dd_max = equip->effectN( 3 ).average( effect.item );

      tick = create_proc_action<generic_aoe_proc_t>(
          "mud_echo", effect, effect.driver()->effectN( 2 ).trigger()->effectN( 1 ).trigger(), true );

      double tick_count = effect.driver()->effectN( 2 ).trigger()->duration() /
                          effect.driver()->effectN( 2 ).trigger()->effectN( 1 ).period();

      tick->base_dd_min = tick->base_dd_max = equip->effectN( 1 ).average( effect.item );
      damage_buff = unique_gear::create_buff<buff_t>( effect.player, effect.driver()->effectN( 2 ).trigger() )
                        ->set_tick_callback( [ &, tick_count ]( buff_t* self, int, timespan_t ) {
                          tick->execute();
                          if ( !absorb_buff->check() && self->check() && self->current_tick < tick_count )
                            // Let events clear before expiring
                            make_event( *sim, 0_ms, [ self ] { self->expire(); } );
                        } );
    }

    absorb_buff_t* create_buff( const action_state_t* s ) override
    {
      auto b      = absorb_t::create_buff( s );
      absorb_buff = b;
      return b;
    }

    void execute() override
    {
      target = player;
      action_t::execute();
      damage_buff->trigger();
    }
  };

  effect.execute_action = create_proc_action<mudborne_t>( "mudborne", effect );
}

void hallowed_tome( special_effect_t& effect )
{
  auto buff_spell = effect.driver()->effectN( 2 ).trigger();

  auto buff = make_buff<stat_buff_t>( effect.player, util::tokenize_fn( buff_spell->name_cstr() ), buff_spell )
                  ->add_stat_from_effect_type( A_MOD_RATING, effect.driver()->effectN( 1 ).average( effect ) );

  effect.custom_buff = buff;
  new dbc_proc_callback_t( effect.player, effect );
}

// Gigazap's Zap-Cap
void gigazaps_zapcap( special_effect_t& effect )
{
  struct zap_t : generic_proc_t
  {
    buff_t* max_stack;
    const special_effect_t& effect;

    zap_t( const special_effect_t& effect, buff_t* max_stack )
      : generic_proc_t( effect, "zap", effect.player->find_spell( 1220419 ) ), max_stack( max_stack ), effect( effect )
    {
      base_dd_min = base_dd_max = effect.driver()->effectN( 1 ).average( effect.item );
      base_multiplier *= role_mult( effect );
      // the second impact is delayed 500ms, but snapshots multipliers as of
      // the primary execute. this is not exactly that, but somewhat close
      aoe = 1 + as<int>( effect.driver()->effectN( 5 ).base_value() );
    }

    double action_multiplier() const override
    {
      double m = generic_proc_t::action_multiplier();

      if ( max_stack->check() )
        m *= effect.driver()->effectN( 4 ).base_value();

      return m;
    }
  };

  auto max_stack_buff = create_buff<buff_t>( effect.player, effect.player->find_spell( 1220413 ) );

  auto ramp_buff = create_buff<buff_t>( effect.player, effect.player->find_spell( 1220415 ) )
                       ->set_expire_at_max_stack( true )
                       ->set_stack_change_callback( [ max_stack_buff ]( buff_t*, int old_, int new_ ) {
                         if ( old_ && !new_ )
                           max_stack_buff->trigger();
                       } );

  effect.custom_buff = ramp_buff;
  new dbc_proc_callback_t( effect.player, effect );

  effect.player->callbacks.register_callback_trigger_function(
      effect.spell_id, dbc_proc_callback_t::trigger_fn_type::CONDITION,
      [ max_stack_buff ]( auto, const auto&, auto, auto, auto ) {
        return !max_stack_buff->check();
      } );

  auto zap = create_proc_action<zap_t>( "zap", effect, max_stack_buff );

  effect.player->register_combat_begin( [ effect, zap, max_stack_buff ]( player_t* player ) {
    make_repeating_event( *player->sim, effect.driver()->effectN( 1 ).period(), [ player, zap, max_stack_buff ] {
      if ( player->in_combat && !max_stack_buff->check() )
        zap->execute();
    } );
    make_repeating_event( *player->sim, effect.driver()->effectN( 1 ).period() / 2.0, [ player, zap, max_stack_buff ] {
      if ( player->in_combat && max_stack_buff->check() )
        zap->execute();
    } );
  } );
}

// Diamantine Voidcore
// 1234996 Driver
// 1239221 Buff
// 1239233 low mana rppm modifier script
void diamantine_voidcore( special_effect_t& effect )
{
  auto buff = create_buff<stat_buff_t>( effect.player, effect.player->find_spell( 1239221 ) )
                  ->set_stat_from_effect_type( A_MOD_STAT, effect.driver()->effectN( 1 ).average( effect ) )
                  ->set_stack_behavior( buff_stack_behavior::ASYNCHRONOUS );

  effect.custom_buff = buff;

  struct diamantine_voidcore_cb_t : public dbc_proc_callback_t
  {
    double mana_threshold;
    double rppm_mod_orig;
    double rppm_mod_boost;

    diamantine_voidcore_cb_t( const special_effect_t& e )
      : dbc_proc_callback_t( e.player, e ),
        mana_threshold( e.driver()->effectN( 2 ).percent() ),
        rppm_mod_orig( e.rppm_modifier() ),
        rppm_mod_boost( e.player->dbc->real_ppm_modifier( e.spell_id, e.player, e.item->item_level(), 1239233 ) )
    {}

    void trigger( const proc_data_t& data, player_t* t, action_state_t* s, proc_trigger_type_e type ) override
    {
      if ( listener->resources.active_resource[ RESOURCE_MANA ] )
      {
        rppm->set_modifier( listener->resources.pct( RESOURCE_MANA ) <= mana_threshold ? rppm_mod_boost
                                                                                       : rppm_mod_orig );
      }

      dbc_proc_callback_t::trigger( data, t, s, type );
    }
  };

  new diamantine_voidcore_cb_t( effect );
}

// Unyielding Netherprism
// 1233553 Equip Driver & Values
// 1233556 Use Driver & Stat Buff
// 1239674 Damage
// 1239675 Stacking buff
void unyielding_netherprism( special_effect_t& effect )
{
  if ( unique_gear::create_fallback_buffs( effect, { "latent_energy", "unyielding_netherprism" } ) )
    return;

  auto equip_driver = effect.player->find_spell( 1233553 );
  assert( equip_driver && "Unyielding Netherprism missing Equip Driver" );

  struct unyielding_netherprism_use_t : public generic_proc_t
  {
    buff_t* stacking;
    buff_t* stat_buff;

    unyielding_netherprism_use_t( const special_effect_t& e, buff_t* stacking_buff, const spell_data_t* equip )
      : generic_proc_t( e, "unyielding_netherprism_use", e.driver() ), stacking( stacking_buff ), stat_buff( nullptr )
    {
      // Setting max stacks here for reporting to allow for quickly checking the average stacks consumed
      stat_e stat = e.player->convert_hybrid_stat( STAT_STR_AGI );
      int idx = stat == STAT_AGILITY ? 1 : 2;
      stat_buff = create_buff<stat_buff_t>( e.player, e.driver() )
                      ->add_stat_from_effect( idx, equip->effectN( 2 ).average( e ) )
                      ->set_cooldown( 0_ms )  // Handled by the trinket
                      ->set_max_stack( e.player->find_spell( 1239675 )->max_stacks() );
    }

    void execute() override
    {
      generic_proc_t::execute();

      // You can use this without actually having stacks - 07/05/2025
      if ( stacking->check() )
      {
        stat_buff->trigger( stacking->check() );
        stacking->expire();
      }
    }
  };

  struct unyielding_netherprism_damage_t : public generic_aoe_proc_t
  {
    buff_t* stacking;

    unyielding_netherprism_damage_t( const special_effect_t& e, const spell_data_t* equip, buff_t* stacking_buff )
      : generic_aoe_proc_t( e, "unyielding_netherprism_damage", e.player->find_spell( 1239674 ) ),
        stacking( stacking_buff )
    {
      base_dd_min = base_dd_max = equip->effectN( 1 ).average( e );
      base_multiplier *= role_mult( e.player, equip );

      name_str_reporting = "unyielding_netherprism";
    }

    void execute() override
    {
      generic_aoe_proc_t::execute();
      stacking->trigger();
    }
  };

  buff_t* stacking_buff = create_buff<buff_t>( effect.player, effect.player->find_spell( 1239675 ) )
                              ->set_constant_behavior( buff_constant_behavior::NEVER_CONSTANT );

  auto equip            = new special_effect_t( effect.player );
  equip->name_str       = fmt::format( "{}_{}", equip_driver->name_cstr(), "equip" );
  equip->spell_id       = equip_driver->id();
  equip->execute_action = create_proc_action<unyielding_netherprism_damage_t>( "unyielding_netherprism_damage", effect,
                                                                               equip_driver, stacking_buff );
  effect.player->special_effects.push_back( equip );

  auto cb = new dbc_proc_callback_t( effect.player, *equip );
  cb->initialize();
  cb->activate();

  effect.execute_action =
    create_proc_action<unyielding_netherprism_use_t>( "unyielding_netherprism", effect, stacking_buff, equip_driver );

  effect.stat = effect.player->convert_hybrid_stat( STAT_STR_AGI );
  effect.has_use_buff_override = true;
  effect.disable_buff();
}

// Araz's Ritual Forge
// 1232802 Driver
// 1232797 Value Spell
void arazs_ritual_forge( special_effect_t& effect )
{
  struct arazs_buff_t final : public stat_buff_t
  {
    const special_effect_t& effect;
    const spell_data_t* value_spell;
    int current_tick;
    double buff_val;
    double decrease;

    arazs_buff_t( const special_effect_t& e )
      : stat_buff_t( e.player, "arazs_ritual_forge", e.driver() ),
        effect( e ),
        value_spell( nullptr ),
        current_tick( 0 ),
        buff_val( 0 ),
        decrease( 0 )
    {
      auto n_ticks = e.driver()->duration() / e.driver()->effectN( 2 ).period();
      value_spell  = e.player->find_spell( 1232797 );
      buff_val     = value_spell->effectN( 1 ).average( e );
      decrease     = buff_val / n_ticks;

      set_stat_from_effect( 1, value_spell->effectN( 1 ).average( e ) );
      set_tick_callback( [ this ]( buff_t*, int, timespan_t ) { recalculate(); } );
    }

    double current_value()
    {
      double value = buff_val - ( decrease * current_tick );

      return value;
    }

    void recalculate()
    {
      current_tick++;
      for ( auto& buff_stat : stats )
      {
        double delta = buff_stat.current_value - current_value();

        if ( delta > 0 )
        {
          player->stat_loss( buff_stat.stat, decrease, stat_gain, nullptr, buff_duration() > timespan_t::zero() );
        }
        else if ( delta < 0 )
        {
          player->stat_gain( buff_stat.stat, std::fabs( delta ), stat_gain, nullptr,
                             buff_duration() > timespan_t::zero() );
        }
      }
    }

    void recalculate_expiry()
    {
      for ( auto& buff_stat : stats )
      {
        double delta = current_value();
        if ( delta > 0 )
        {
          player->stat_loss( buff_stat.stat, delta, stat_gain, nullptr, buff_duration() > timespan_t::zero() );
        }
        else if ( delta < 0 )
        {
          player->stat_gain( buff_stat.stat, std::fabs( delta ), stat_gain, nullptr,
                             buff_duration() > timespan_t::zero() );
        }
        buff_stat.current_value = 0;
      }
    }

    void expire_override( int s, timespan_t d ) override
    {
      // Skip stat_buff_t::expire_override() since we are manually handling stat changes.
      buff_t::expire_override( s, d );
      recalculate_expiry();
      current_tick = 0;
    }

    void reset() override
    {
      stat_buff_t::reset();
      current_tick = 0;
    }
  };

  effect.custom_buff = make_buff<arazs_buff_t>( effect );
}

// Astral Antenna
// 1234714 Driver
// 1239640 Orb Buff
// 1239641 Buff
// TODO: Investigate the area trigger, see if has importance for sims
void astral_antenna( special_effect_t& effect )
{
  auto buff = create_buff<stat_buff_t>( effect.player, "astral_antenna", effect.player->find_spell( 1239641 ) )
                  ->set_stat_from_effect_type( A_MOD_RATING, effect.driver()->effectN( 1 ).average( effect ) )
                  ->set_stack_behavior( buff_stack_behavior::ASYNCHRONOUS );

  auto orb = create_buff<buff_t>( effect.player, "astral_antenna_orb", effect.player->find_spell( 1239640 ) )
                 ->set_stack_behavior( buff_stack_behavior::ASYNCHRONOUS )
                 ->set_stack_change_callback( [ buff ]( buff_t* b, int old_, int new_ ) {
                   if ( new_ > old_ && !b->source->rng().roll( b->source->thewarwithin_opts.astral_antenna_miss_chance ) )
                     make_event( *b->source->sim, b->source->rng().gauss_ab( 5_s, 1_s, 500_ms, 19999_ms ), [ b, buff ] {
                       buff->trigger();
                       b->decrement();
                     } );
                 } );

  effect.custom_buff = orb;

  new dbc_proc_callback_t( effect.player, effect );
}

// Screams of a Forgotten Sky
// 1235272 Driver
// 1242875 Damage: An'xoth
// 1242895 Damage: An'zuq
// 1242897 Damage: An'shuul
// 1242881 Debuff
// 1242901 On Death damage
void screams_of_a_forgotten_sky( special_effect_t& effect )
{
  struct screams_of_a_forgotten_sky_base_t : public generic_proc_t
  {
    double debuff_stack_val;
    double on_death_val;
    action_t* on_death;

    screams_of_a_forgotten_sky_base_t( const special_effect_t& e, std::string_view n, const spell_data_t* s, action_t* on_death )
      : generic_proc_t( e, n, s ), debuff_stack_val( 0 ), on_death_val( 0 ), on_death( on_death )
    {
      base_dd_min = base_dd_max = e.driver()->effectN( 1 ).average( e );
      debuff_stack_val          = e.driver()->effectN( 2 ).percent();
      on_death_val              = e.driver()->effectN( 3 ).average( e );
      base_multiplier *= role_mult( e );
      if ( player->thewarwithin_opts.screams_of_a_forgotten_sky_initial_stacks > 0 )
        for ( auto& t : sim->target_list )
          if ( t->is_enemy() )
            t->register_on_arise_callback( t, [ &, t ] {
              if ( auto debuff = get_debuff( t ) )
                debuff->trigger( player->thewarwithin_opts.screams_of_a_forgotten_sky_initial_stacks );
            } );
    }

    double composite_target_multiplier( player_t* t ) const override
    {
      double m = generic_proc_t::composite_target_multiplier( t );

      if ( auto debuff = find_debuff( t ) )
        m *= 1.0 + ( debuff->check() * debuff_stack_val );

      return m;
    }

    buff_t* create_debuff( player_t* t ) override
    {
      auto buff = buff_t::find( t, "abyssal_gravity", player );
      if ( !buff )
      {
        buff = make_buff( actor_pair_t( t, player ), "abyssal_gravity", data().effectN( 2 ).trigger() );
        t->register_on_demise_callback( player, [ &, buff ]( player_t* tar ) {
          if ( buff->check() && !sim->event_mgr.canceled )
            on_death->execute_on_target( tar, buff->check() * on_death_val );
        } );
      }

      return buff;
    }

    void impact( action_state_t* s ) override
    {
      generic_proc_t::impact( s );
      get_debuff( s->target )->trigger();
    }
  };

  struct screams_of_a_forgotten_sky_cb_t : public dbc_proc_callback_t
  {
    action_t* anxoth;
    action_t* anzuq;
    action_t* anshuul;
    action_t* proxy;
    std::vector<action_t*> actions;

    screams_of_a_forgotten_sky_cb_t( const special_effect_t& e )
      : dbc_proc_callback_t( e.player, e ), anxoth( nullptr ), anzuq( nullptr ), anshuul( nullptr ), proxy( nullptr ), actions()
    {
      proxy = new action_t( action_e::ACTION_OTHER, "screams_of_a_forgotten_sky", e.player, e.driver() );

      action_t* on_death = create_proc_action<generic_aoe_proc_t>( "abyssal_implosion", e, 1242901, true );

      anxoth = create_proc_action<screams_of_a_forgotten_sky_base_t>( "screams_of_a_forgotten_sky_anxoth", e,
                                                                      "screams_of_a_forgotten_sky_anxoth",
                                                                      e.player->find_spell( 1242875 ), on_death );

      anzuq  = create_proc_action<screams_of_a_forgotten_sky_base_t>( "screams_of_a_forgotten_sky_anzuq", e, 
                                                                      "screams_of_a_forgotten_sky_anzuq", 
                                                                      e.player->find_spell( 1242895 ), on_death );

      anshuul = create_proc_action<screams_of_a_forgotten_sky_base_t>( "screams_of_a_forgotten_sky_anshuul", e,
                                                                       "screams_of_a_forgotten_sky_anshuul",
                                                                       e.player->find_spell( 1242897 ), on_death );

      actions.push_back( anxoth );
      actions.push_back( anzuq );
      actions.push_back( anshuul );

      proxy->add_child( on_death );

      for ( auto a : actions )
        proxy->add_child( a );
    }

    void execute( const spell_data_t*, player_t* t, action_state_t* ) override
    {
      buff_t* debuff = actions[ 0 ]->get_debuff( t );
      if ( !debuff )
      {
        listener->sim->error( "Screams of a Forgotten Sky: No debuff found on {} from {}.", *t, *listener );
        return;
      }
      if ( debuff->check() < 5 )
        actions[ 0 ]->execute_on_target( t );
      else if ( debuff->check() >= 5 && debuff->check() < 9 )
        actions[ 1 ]->execute_on_target( t );
      else
        actions[ 2 ]->execute_on_target( t );

      proxy->stats->add_execute( 0_ms, t );
    }
  };

  new screams_of_a_forgotten_sky_cb_t( effect );
}

// Eradicating Arcanocore
// 1233384 Driver
// 1240896 Stacking Buff
// 1241899 Delay Spell/Area Trigger
// 1240916 Damage
// 1241847 Unknown Dummy: 6 yard radius, maybe random visual location?
void eradicating_arcanocore( special_effect_t& effect )
{
  struct eradicating_arcanocore_t final : public generic_aoe_proc_t
  {
    buff_t* stacking_buff;
    int st_stacks;

    eradicating_arcanocore_t( const special_effect_t& e, buff_t* stacking )
      : generic_aoe_proc_t( e, "eradicating_arcanoblast", e.player->find_spell( 1240916 ) ),
        stacking_buff( stacking ),
        st_stacks( 0 )
    {
      travel_delay = e.player->find_spell( 1241899 )->duration().total_seconds();
      base_dd_min = base_dd_max = e.driver()->effectN( 1 ).average( e );
      base_multiplier *= role_mult( e );

      st_stacks = as<int>( e.driver()->effectN( 2 ).base_value() );
    }

    void impact( action_state_t* s ) override
    {
      if ( player->sim->target_non_sleeping_list.size() == 1 )
        stacking_buff->trigger( st_stacks );

      generic_aoe_proc_t::impact( s );
    }
  };

  auto buff = create_buff<buff_t>( effect.player, "eradicating_arcanoblast", effect.player->find_spell( 1240896 ) )
                  ->set_expire_at_max_stack( true );
  auto damage = create_proc_action<eradicating_arcanocore_t>( "eradicating_arcanocore", effect, buff );

  buff->set_expire_callback( [ damage ]( buff_t* b, int, timespan_t ) {
    if ( !b->source->sim->canceled )
      damage->execute();
  } );

  effect.custom_buff = buff;

  new dbc_proc_callback_t( effect.player, effect );
}

// Sigil of the Cosmic Hunt
// 1235360 Driver
// 1239401 Damage
// 1239403 AoE
void sigil_of_the_cosmic_hunt( special_effect_t& effect )
{
  struct cosmic_radiation_t final : public generic_proc_t
  {
    cosmic_radiation_t( const special_effect_t& e )
      : generic_proc_t( e, "cosmic_radiation", e.player->find_spell( 1239403 ) )
    {
      split_aoe_damage = true;
      aoe = -1;
    }

    size_t available_targets( std::vector<player_t*>& tl ) const override
    {
      generic_proc_t::available_targets( tl );

      auto it = range::find( tl, target );
      if ( it != tl.end() )
      {
        tl.erase( it );
      }

      return tl.size();
    }
  };

  struct cosmic_onslaught_t final : public generic_proc_t
  {
    action_t* aoe_damage;
    double hp_increase;
    double hp_percent;
    double damage_pct;

    cosmic_onslaught_t( const special_effect_t& e )
      : generic_proc_t( e, "cosmic_onslaught", e.driver()->effectN( 1 ).trigger() ),
        aoe_damage( nullptr ),
        hp_increase( 0 ),
        hp_percent( 0 ),
        damage_pct( 0 )
    {
      base_dd_min = base_dd_max = e.driver()->effectN( 1 ).average( e );
      base_multiplier *= role_mult( e );

      aoe_damage = create_proc_action<cosmic_radiation_t>( "cosmic_radiation", e );

      hp_increase = e.driver()->effectN( 3 ).percent();
      hp_percent  = 1;  // Not in spell data, using tooltip value
      damage_pct  = e.driver()->effectN( 4 ).percent();
    }

    double composite_target_multiplier( player_t* t ) const override
    {
      double m = generic_proc_t::composite_target_multiplier( t );

      m *= 1.0 + ( ( 100 - t->health_percentage() ) / hp_percent * hp_increase );

      return m;
    }

    void impact( action_state_t* s ) override
    {
      generic_proc_t::impact( s );
      aoe_damage->execute_on_target( s->target, s->result_amount * damage_pct );
    }
  };

  effect.execute_action = create_proc_action<cosmic_onslaught_t>( "cosmic_onslaught", effect );

  new dbc_proc_callback_t( effect.player, effect );
}

// Cursed Stone idol
// 1242326 Driver
// 1241801 Values
// 1241806 Crit Buff
// 1241809 Damage
void cursed_stone_idol( special_effect_t& effect )
{
  struct cursed_stone_idol_buff_t final : public stat_buff_t
  {
    int n_hit;
    double inc_per_hit;
    double max_inc;
    cursed_stone_idol_buff_t( player_t* p, std::string_view n, const special_effect_t& e )
      : stat_buff_t( p, n, p->find_spell( 1241806 ) ), n_hit( 0 ), inc_per_hit( 0 ), max_inc( 0 )
    {
      const spell_data_t* value_spell = p->find_spell( 1241801 );
      set_stat_from_effect_type( A_MOD_RATING, 0 );
      set_default_value( value_spell->effectN( 1 ).average( e ) );

      inc_per_hit = value_spell->effectN( 3 ).average( e );
      max_inc     = value_spell->effectN( 4 ).average( e );
    }

    void bump( int s, double v ) override
    {
      for ( auto& stat : stats )
      {
        double val         = std::min( default_value + inc_per_hit * n_hit, max_inc );
        double delta       = val - stat.current_value;
        stat.amount        = val;
        stat.current_value = val;

        if ( delta > 0 )
        {
          player->stat_gain( stat.stat, delta, stat_gain, nullptr, buff_duration() > timespan_t::zero() );
        }
        else if ( delta < 0 )
        {
          player->stat_loss( stat.stat, std::fabs( delta ), stat_gain, nullptr, buff_duration() > timespan_t::zero() );
        }
      }
      // Skip stat_buff_t::start since we handle stat gain manually
      buff_t::bump( s, v );
    }
  };

  struct cursed_stone_idol_damage_t final : public generic_aoe_proc_t
  {
    buff_t* buff;
    cursed_stone_idol_damage_t( const special_effect_t& e )
      : generic_aoe_proc_t( e, "cursed_stone_idol_damage", e.player->find_spell( 1241809 ), false ), buff( nullptr )
    {
      const spell_data_t* value_spell = e.player->find_spell( 1241801 );
      base_dd_min = base_dd_max = value_spell->effectN( 2 ).average( e );
      split_aoe_damage          = false;
      buff                      = create_buff<cursed_stone_idol_buff_t>( e.player, "cursed_stone_idol", e );
    }

    void execute() override
    {
      generic_aoe_proc_t::execute();
      cursed_stone_idol_buff_t* stat = debug_cast<cursed_stone_idol_buff_t*>( buff );
      stat->n_hit                    = as<int>( sim->target_non_sleeping_list.size() );
      stat->trigger();
    }
  };

  struct cursed_stone_idol_t final : public generic_proc_t
  {
    cursed_stone_idol_t( const special_effect_t& e )
      : generic_proc_t( e, "cursed_stone_idol", e.driver() )
    {
      impact_action = create_proc_action<cursed_stone_idol_damage_t>( "cursed_stone_idol_damage", e );
      add_child( impact_action );
      use_off_gcd = false;
    }
  };

  effect.stat = STAT_CRIT_RATING;
  effect.has_use_buff_override = true;
  effect.execute_action = create_proc_action<cursed_stone_idol_t>( "cursed_stone_idol", effect );
}

// Naazindhri's Mystic Lash
// 1235387 Driver
// 1239809 AoE Radius
// 1239810 Damage
void naazindhris_mystic_lash( special_effect_t& effect )
{
  struct naazindhris_mystic_lash_t final : public generic_aoe_proc_t
  {
    naazindhris_mystic_lash_t( const special_effect_t& e, std::string_view n )
      : generic_aoe_proc_t( e, n, e.player->find_spell( 1239810 ) )
    {
      base_dd_min = base_dd_max = e.driver()->effectN( 1 ).average( e );
      base_multiplier           = role_mult( e );
      radius                    = e.player->find_spell( 1239809 )->effectN( 1 ).radius_max();
    }

    double composite_da_multiplier( const action_state_t* s ) const override
    {
      double m = generic_aoe_proc_t::composite_da_multiplier( s );

      m *= 1.0 + ( ( player->composite_mastery() - player->base.mastery ) / 100 );

      return m;
    }
  };

  effect.execute_action = create_proc_action<naazindhris_mystic_lash_t>( "naazindhris_mystic_lash", effect );

  new dbc_proc_callback_t( effect.player, effect );
}

// Perfidious Projector
// 1244636 Driver
// 1235557 Value Spell
// 1235566 Ticking spell
// 1244444 Ground AoE Area Trigger
// 1244448 Damage
void perfidious_projector( special_effect_t& effect )
{
  auto value_spell = effect.player->find_spell( 1235557 );
  assert( value_spell && "Perfidious Projector Value Spell not found" );

  auto dot_spell = effect.player->find_spell( 1235566 );
  auto n_ticks   = dot_spell->duration() / dot_spell->effectN( 1 ).period();

  auto damage         = create_proc_action<generic_aoe_proc_t>( "shadowguard_to_me", effect, 1244448, true );
  auto damage_val     = value_spell->effectN( 1 ).average( effect ) / n_ticks;
  damage->base_dd_min = damage->base_dd_max = damage_val;
  // not present in tooltip desc, fallback to default value
  damage->base_multiplier = role_mult( effect.player );

  auto dot         = create_proc_action<generic_proc_t>( "perfidious_projector", effect, dot_spell );
  dot->tick_action = damage;

  effect.execute_action = dot;
}

// Incorporeal Warpclaw
// 1243118 Driver
// 1243133 Damage
void incorporeal_warpclaw( special_effect_t& effect )
{
  auto damage         = create_proc_action<generic_aoe_proc_t>( "incorporeal_warpstrike", effect, 1243133, true );
  damage->base_dd_min = damage->base_dd_max = effect.driver()->effectN( 1 ).average( effect );
  damage->base_multiplier *= role_mult( effect );

  effect.execute_action = damage;

  new dbc_proc_callback_t( effect.player, effect );
}

// Mind-Fracturing Odium
// 1245148 Driver
// 1245637 Stacking Buff
// 1245643 Haste Buff
void mind_fracturing_odium( special_effect_t& effect )
{
  struct mind_fracturing_odium_cb_t final : public dbc_proc_callback_t
  {
    buff_t* stacking;
    buff_t* stat;
    bool decrementing;

    mind_fracturing_odium_cb_t( const special_effect_t& e )
      : dbc_proc_callback_t( e.player, e ), stacking( nullptr ), stat( nullptr ), decrementing( false )
    {
      stat = create_buff<stat_buff_t>( e.player, "arcane_insanity", e.player->find_spell( 1245643 ) )
                 ->set_stat_from_effect_type( A_MOD_RATING, e.driver()->effectN( 1 ).average( e ) );

      stacking = create_buff<buff_t>( e.player, "mindfracturing_odium", e.driver()->effectN( 1 ).trigger() )
                     ->disable_ticking( true )
                     ->set_expire_callback( [ & ]( buff_t*, int, timespan_t ) {
                       decrementing = false;
                       stat->expire();
                     } );

      e.player->register_on_kill_callback( [ &, e ]( player_t* ) {
        if ( !e.player->sim->event_mgr.canceled )
          stacking->increment( 2 );
      } );

      e.player->register_on_arise_callback( effect.player, [ & ] {
        make_repeating_event( *listener->sim, e.driver()->effectN( 1 ).trigger()->effectN( 2 ).period(), [ & ] {
          if ( decrementing )
            stacking->decrement();
        } );
      } );
    }

    void reset() override
    {
      dbc_proc_callback_t::reset();
      decrementing = false;
    }

    void execute( const spell_data_t*, player_t*, action_state_t* ) override
    {
      if( !decrementing )
        stacking->trigger();
      // Check for stat even though not required to remove refreshes from report to avoid confusion.
      if ( stacking->at_max_stacks() && !stat->check() )
      {
        decrementing = true;
        stat->trigger();
      }
    }
  };

  new mind_fracturing_odium_cb_t( effect );
}

// Incorporeal Essence-Gorger
// 1244410 Driver & Damage
// 1247205 Value Spell
// 1247207 Buff
void incorporeal_essence_gorger( special_effect_t& effect )
{
  struct incorporeal_essence_gorger_t final : public generic_proc_t
  {
    std::unordered_map<stat_e, buff_t*> buffs;

    incorporeal_essence_gorger_t( const special_effect_t& e, std::string_view n ) : generic_proc_t( e, n, e.driver() )
    {
      base_dd_min = base_dd_max = e.driver()->effectN( 1 ).average( e );
      base_multiplier *= role_mult( e );
      auto buff_value           = e.player->find_spell( 1247205 )->effectN( 1 ).average( e );
      create_all_stat_buffs( e, e.player->find_spell( 1247207 ), buff_value, [ &, buff_value ]( stat_e s, buff_t* b ) {
        b->default_value = buff_value;
        buffs[ s ]       = b;
      } );
    }

    void impact( action_state_t* s ) override
    {
      generic_proc_t::impact( s );
      if ( player->thewarwithin_opts.incorporeal_essence_gorger_ethereal )
      {
        buffs.at( util::highest_stat( player, secondary_ratings ) )->trigger();
      }
      else
      {
        buffs.at( util::lowest_stat( player, secondary_ratings ) )->trigger();
      }
    }
  };

  effect.execute_action = create_proc_action<incorporeal_essence_gorger_t>( "incorporeal_essencegorger", effect );
}

// Void-Touched Fragment
// 1224856 Driver
// 1224918 Mastery Buff
// 1224917 on Death Trigger
// 1224916 Stacking Buff
void voidtouched_fragment( special_effect_t& effect )
{
  auto stat_buff =
      create_buff<stat_buff_t>( effect.player, "voidtouched_fragment", effect.player->find_spell( 1224918 ) )
          ->set_stat_from_effect_type( A_MOD_RATING, effect.driver()->effectN( 1 ).average( effect ) );
  auto stacking_buff =
      create_buff<buff_t>( effect.player, "voidtouched_fragment_stacking", effect.player->find_spell( 1224916 ) )
          ->set_expire_callback( [ stat_buff ]( buff_t*, int, timespan_t ) { stat_buff->trigger(); } )
          ->set_expire_at_max_stack( true );

  effect.player->register_on_kill_callback( [ &effect, stacking_buff ]( player_t* ) {
    if ( !effect.player->sim->event_mgr.canceled )
      stacking_buff->trigger();
  } );

  effect.custom_buff = stacking_buff;

  new dbc_proc_callback_t( effect.player, effect );
}

// Soulbreaker's Sigil
// 1224870 Driver
// 1225149 DoT
// 1225151 Vers Buff
void soulbreakers_sigil( special_effect_t& effect )
{
  auto dot_spell = effect.player->find_spell( 1225149 );
  auto dot       = create_proc_action<generic_proc_t>( "soulbreakers_sigil", effect, dot_spell );
  auto n_ticks   = dot_spell->duration() / dot_spell->effectN( 1 ).period();
  dot->base_td   = effect.driver()->effectN( 1 ).average( effect ) / n_ticks;
  dot->base_td_multiplier *= role_mult( effect );

  auto buff = create_buff<stat_buff_t>( effect.player, "soulbreakers_sigil", effect.player->find_spell( 1225151 ) )
                  ->set_stat_from_effect_type( A_MOD_RATING, effect.driver()->effectN( 2 ).average( effect ) );

  effect.player->register_on_kill_callback( [ &effect, buff ]( player_t* t ) {
    if ( !effect.player->sim->event_mgr.canceled )
    {
      auto d = t->get_dot( "soulbreakers_sigil", effect.player );
      if ( d->is_ticking() )
        buff->trigger();
    }
  } );

  effect.execute_action = dot;

  new dbc_proc_callback_t( effect.player, effect );
}

// Depleted K'areshi Battery
// 1231107 Driver
// 1231099 Values
// 1231104 Damage
void depleted_kareshi_battery( special_effect_t& effect )
{
  auto value_spell = effect.player->find_spell( 1231099 );

  assert( value_spell && "Depleted Kareshi Battery missing value spell." );

  auto dot =
      create_proc_action<generic_proc_t>( "depleted_kareshi_battery", effect, effect.driver()->effectN( 1 ).trigger() );
  dot->base_td = value_spell->effectN( 1 ).average( effect );

  effect.execute_action = dot;

  new dbc_proc_callback_t( effect.player, effect );
}

// Azhiccaran Parapodia
// 1243818 Driver
// 1243843 Buff
// 1243828 DoT
void azhiccaran_parapodia( special_effect_t& effect )
{
  struct azhiccaran_mite_t final : public generic_proc_t
  {
    buff_t* buff;

    azhiccaran_mite_t( const special_effect_t& e, std::string_view n )
      : generic_proc_t( e, n, e.player->find_spell( 1243828 ) ), buff( nullptr )
    {
      base_td = e.driver()->effectN( 1 ).average( e );

      buff = create_buff<stat_buff_t>( e.player, "mitey_feast", e.player->find_spell( 1243843 ) )
                 ->set_stat_from_effect_type( A_MOD_STAT, e.driver()->effectN( 2 ).average( e ) )
                 ->set_stack_behavior( buff_stack_behavior::ASYNCHRONOUS );
    }

    void last_tick( dot_t* d ) override
    {
      generic_proc_t::last_tick( d );
      // Only triggers if the DoT finishes.
      make_event( *sim, timespan_t::from_seconds( data().missile_min_duration() ), [ & ] { buff->trigger(); } );
    }
  };

  effect.execute_action = create_proc_action<azhiccaran_mite_t>( "azhiccaran_mite", effect );

  new dbc_proc_callback_t( effect.player, effect );
}

// Essence-Hunter's Eyeglass
// 1244402 Driver
// 1245376 Buff
void essence_hunters_eyeglass( special_effect_t& effect )
{
  auto buff = create_buff<stat_buff_t>( effect.player, "arcane_hunter", effect.driver()->effectN( 1 ).trigger() )
                  ->set_stat_from_effect_type( A_MOD_RATING, effect.driver()->effectN( 1 ).average( effect ) );

  effect.custom_buff = buff;

  effect.proc_flags2_ = PF2_CRIT;

  new dbc_proc_callback_t( effect.player, effect );
}

// Soulbinder's Embrace
// 1235218 equip coeffs
// 1235425 on-use buff
// 1235633 damage
void soulbinders_embrace( special_effect_t& effect )
{
  unsigned equip_id = 1235218;
  auto equip = find_special_effect( effect.player, equip_id );
  assert( equip && "Soulbinder's Embrace missing equip effect" );

  auto equip_data = equip->driver();

  struct soulbinders_embrace_buff_t : public absorb_buff_t
  {
    double absorb_pct;

    soulbinders_embrace_buff_t( const special_effect_t& e )
      : absorb_buff_t( e.player, "soulbinders_embrace", e.player->find_spell( 1235425 ) ),
        absorb_pct( data().effectN( 2 ).percent() )
    {}

    double consume( double a, action_state_t* s ) override
    {
      return absorb_buff_t::consume( a * absorb_pct, s );
    }
  };

  effect.custom_buff = make_buff<soulbinders_embrace_buff_t>( effect )
    ->set_default_value( equip_data->effectN( 1 ).average( effect ) );

  auto damage = create_proc_action<generic_aoe_proc_t>( "soulbinders_embrace", effect, 1235633 );
  damage->base_dd_min = damage->base_dd_max = equip_data->effectN( 2 ).average( effect );
  damage->split_aoe_damage = false;

  effect.execute_action = damage;
}

// brand of ceaseless ire
// 1235225 driver
// 1235879 counter
// 1235946 damage
// 1235973 shield
void brand_of_ceaseless_ire( special_effect_t& effect )
{
  struct brand_of_ceaseless_ire_t : public generic_aoe_proc_t
  {
    buff_t* counter;
    buff_t* shield;
    double shield_amount;

    brand_of_ceaseless_ire_t( const special_effect_t& e )
      : generic_aoe_proc_t( e, "brand_of_ceaseless_ire", 1235946 ),
        shield_amount( e.driver()->effectN( 1 ).average( e ) )
    {
      base_dd_min = base_dd_max = e.driver()->effectN( 2 ).average( e );

      shield = create_buff<absorb_buff_t>( e.player, e.player->find_spell( 1235973 ) );
      counter = create_buff<buff_t>( e.player, e.trigger() )
        ->set_freeze_stacks( true )
        ->set_tick_callback( [ p = e.player ]( buff_t* b, int, timespan_t ) {
          if ( !p->in_combat )
            make_event( *p->sim, [ b ] { b->decrement(); } );
        } );
    }

    void execute() override
    {
      generic_aoe_proc_t::execute();

      shield->trigger( -1, shield_amount * ( 1 + counter->check() ) );
      counter->trigger();
    }

    double action_multiplier() const override
    {
      return generic_aoe_proc_t::action_multiplier() * ( 1 + counter->check() );
    }
  };

  effect.execute_action = create_proc_action<brand_of_ceaseless_ire_t>( "brand_of_ceaseless_ire", effect );

  // assume full uptime in dungeons since we're always getting hit
  if ( effect.player->sim->fight_style == FIGHT_STYLE_DUNGEON_SLICE ||
       effect.player->sim->fight_style == FIGHT_STYLE_DUNGEON_ROUTE ||
       effect.player->thewarwithin_opts.brand_of_ceaseless_ire_force_full_uptime )
  {
    effect.proc_flags_ = PF_MELEE_ABILITY;
    effect.proc_flags2_ = PF2_LANDED;
  }

  new dbc_proc_callback_t( effect.player, effect );
}

// sybiotic ethergauze
// 1244406 driver
// 1245429 damage
// 1245431 shield
void symbiotic_ethergauze( special_effect_t& effect )
{
  struct symbiotic_ethergauze_cb_t : public dbc_proc_callback_t
  {
    buff_t* shield;
    action_t* damage;
    bool dungeon;

    symbiotic_ethergauze_cb_t( const special_effect_t& e )
      : dbc_proc_callback_t( e.player, e ),
        dungeon( e.player->sim->fight_style == FIGHT_STYLE_DUNGEON_SLICE ||
                 e.player->sim->fight_style == FIGHT_STYLE_DUNGEON_ROUTE )
    {
      shield = create_buff<absorb_buff_t>( e.player, e.driver()->effectN( 2 ).trigger() )
        ->set_default_value( e.driver()->effectN( 2 ).average( e ) );

      damage =
        create_proc_action<generic_aoe_proc_t>( "symbiotic_ethergauze", e, e.driver()->effectN( 1 ).trigger(), true );
      damage->base_dd_min = damage->base_dd_max = e.driver()->effectN( 1 ).average( e );
    }

    void trigger( const proc_data_t& data, player_t* t, action_state_t* s, proc_trigger_type_e type ) override
    {
      if ( dungeon )
      {
        auto block = listener->cache.block();
        auto dodge = listener->cache.dodge();
        auto parry = listener->cache.parry();

        if ( rng().roll( block ) || rng().roll( dodge ) || rng().roll( parry ) )
        {
          dbc_proc_callback_t::trigger( data, t, s, type );
        }
      }
      else
      {
        if ( s->result == result_e::RESULT_DODGE || s->result == result_e::RESULT_PARRY ||
             s->block_result == block_result_e::BLOCK_RESULT_BLOCKED ||
             s->block_result == block_result_e::BLOCK_RESULT_CRIT_BLOCKED )
        {
          dbc_proc_callback_t::trigger( data, t, s, type );
        }
      }
    }

    void execute( const spell_data_t*, player_t*, action_state_t* ) override
    {
      shield->trigger();
      damage->execute();
    }
  };

  // assume each outgoing damage is incoming damage for dungeons and roll vs block/dodge/parry chance
  if ( effect.player->sim->fight_style == FIGHT_STYLE_DUNGEON_SLICE ||
       effect.player->sim->fight_style == FIGHT_STYLE_DUNGEON_ROUTE )
  {
    effect.proc_flags_ = PF_MELEE_ABILITY;
    effect.proc_flags2_ = PF2_LANDED;
  }

  new symbiotic_ethergauze_cb_t( effect );
}

// veiling mana shroud
// 1231217 coeff
// 1231220 driver
// 1231221 buff
void veiling_mana_shroud( special_effect_t& effect )
{
  unsigned coeff_id = 1231217;
  auto coeff = find_special_effect( effect.player, coeff_id );
  assert( coeff && "Veiling Mana Shround missing coeff effect" );

  effect.custom_buff = create_buff<stat_buff_t>( effect.player, effect.trigger() )
    ->add_stat_from_effect_type( A_MOD_RATING, coeff->driver()->effectN( 1 ).average( effect ) );

  // assume full uptime in dungeons since we're always getting hit
  if ( effect.player->sim->fight_style == FIGHT_STYLE_DUNGEON_SLICE ||
       effect.player->sim->fight_style == FIGHT_STYLE_DUNGEON_ROUTE )
  {
    effect.proc_flags_ = PF_MELEE_ABILITY;
    effect.proc_flags2_ = PF2_LANDED;
  }

  new dbc_proc_callback_t( effect.player, effect );
}

// all-devouring nucleus
// 1235500 driver
// 1236689 damage
// 1236690 heal
// 1236691 cheat death lockout
// 1236692 cheat death effect
// 1236991 unknown
void alldevouring_nucleus( special_effect_t& effect )
{
  struct devouring_void_t : public generic_aoe_proc_t
  {
    action_t* heal;
    double heal_pct;
    double total_damage = 0.0;

    devouring_void_t( const special_effect_t& e )
      : generic_aoe_proc_t( e, "devouring_void", 1236689 ), heal_pct( e.driver()->effectN( 2 ).percent() )
    {
      base_dd_min = base_dd_max = e.driver()->effectN( 1 ).average( e );

      heal = create_proc_action<generic_heal_t>( "devouring_void_heal", e, "devouring_void_heal", 1236690 );
      heal->name_str_reporting = "devouring_void";
    }

    void execute() override
    {
      total_damage = 0.0;

      generic_aoe_proc_t::execute();

      if ( total_damage )
      {
        heal->base_dd_min = heal->base_dd_max = total_damage * heal_pct;
        heal->execute();
      }
    }

    void impact( action_state_t* s ) override
    {
      generic_aoe_proc_t::impact( s );

      total_damage += s->result_amount;
    }
  };

  effect.execute_action = create_proc_action<devouring_void_t>( "devouring_void", effect );

  // assume full uptime in dungeons since we're always getting hit
  if ( effect.player->sim->fight_style == FIGHT_STYLE_DUNGEON_SLICE ||
       effect.player->sim->fight_style == FIGHT_STYLE_DUNGEON_ROUTE )
  {
    effect.proc_flags_ = PF_MELEE_ABILITY;
    effect.proc_flags2_ = PF2_LANDED;
  }

  new dbc_proc_callback_t( effect.player, effect );
}

// chaotic nethergate
// 1244008 driver
// 1246637 damage
// 1246649 unknown
// 1246837 coeff
//  e1: damage
//  e2: heal
//  e3: period
//  e4: heal target cap
// 1246851 heal
void chaotic_nethergate( special_effect_t& effect )
{
  unsigned coeff_id = 1246837;
  auto coeff = find_special_effect( effect.player, coeff_id );
  assert( coeff && "Chaotic Nethergate missing coeff effect" );

  struct chaotic_nethergate_t : public generic_proc_t
  {
    struct chaotic_nethergate_damage_t : public generic_aoe_proc_t
    {
      action_t* heal;
      double heal_amount;
      int cap;

      chaotic_nethergate_damage_t( const special_effect_t& e, const spell_data_t* data )
        : generic_aoe_proc_t( e, "chaotic_nethergate_damage", 1246637, false ),
          heal_amount( data->effectN( 2 ).average( e ) ),
          cap( as<int>( data->effectN( 4 ).base_value() ) )
      {
        base_dd_min = base_dd_max = data->effectN( 1 ).average( e );
        dual = true;
        split_aoe_damage = false;
        name_str_reporting = "chaotic_nethergate";

        heal = create_proc_action<generic_heal_t>( "chaotic_nethergate_heal", e, "chaotic_nethergate_heal", 1246851 );
        heal->name_str_reporting = "chaotic_nethergate";
      }

      void execute() override
      {
        generic_aoe_proc_t::execute();

        heal->base_dd_min = heal->base_dd_max = heal_amount * std::min( num_targets_hit, cap );
        heal->execute();
      }
    };

    ground_aoe_params_t params;

    chaotic_nethergate_t( const special_effect_t& e, const spell_data_t* data )
      : generic_proc_t( e, "chaotic_nethergate", e.driver() )
    {
      auto damage = create_proc_action<chaotic_nethergate_damage_t>( "chaotic_nethergate_damage", e, data );
      damage->stats = stats;

      params.pulse_time( timespan_t::from_seconds( data->effectN( 3 ).base_value() ) )
        .duration( e.driver()->duration() )
        .action( damage );
    }

    void execute() override
    {
      generic_proc_t::execute();

      params
        .start_time( timespan_t::min() )  // reset start time
        .target( target )
        .x( player->x_position )
        .y( player->y_position );

      make_event<ground_aoe_event_t>( *sim, player, params );
    }
  };

  effect.execute_action = create_proc_action<chaotic_nethergate_t>( "chaotic_nethergate", effect, coeff->driver() );
}

// manaforged aethercell
// 1244405 driver
// 1245397 buff
void manaforged_aethercell( special_effect_t& effect )
{
  if ( unique_gear::create_fallback_buffs( effect, { "manaforged_aethercell" } ) )
    return;

  auto buff_data = effect.trigger();
  auto buff_seconds = buff_data->duration().total_seconds();

  // in-game, buff only has one stack and is scripted to decay. for simc purposes we make it a 15 stack reverse buff
  auto val = effect.driver()->effectN( 1 ).average( effect ) / buff_seconds;

  auto buff = create_buff<stat_buff_t>( effect.player, effect.trigger() )
    ->add_stat_from_effect_type( A_MOD_RATING, val )
    ->set_max_stack( as<int>( buff_seconds ) )
    ->set_reverse( true );

  effect.custom_buff = buff;

  if ( effect.player->specialization() == PRIEST_SHADOW )
  {
    effect.player->callbacks.register_callback_trigger_function(
        effect.spell_id, dbc_proc_callback_t::trigger_fn_type::CONDITION,
        []( auto, const proc_data_t& data, auto, auto, auto ) {
          // Renew or Flashheal
          if ( data->id() == 139 || data->id() == 2061 )
            return true;
          return false;
        } );
  }

  new dbc_proc_callback_t( effect.player, effect );
}

// automatic footbomb dispenser
// 1234022 driver
//  e1: coeff
//  e2: # of bombs
// 1234025 bomb area trigger?
// 1234219 damage
void automatic_footbomb_dispenser( special_effect_t& effect )
{
  // as bombs spawn within melee range, assume popping them will be trivial. explode the first immediately and explode
  // the second after a random 0.1-10s. use a proxy buff to control this behavior.
  struct automatic_footbomb_dispenser_proxy_buff_t : public buff_t
  {
    automatic_footbomb_dispenser_proxy_buff_t( const special_effect_t& e )
      : buff_t( e.player, "automatic_footbomb_dispenser", e.player->find_spell( 1234025 ) )
    {
      auto damage = create_proc_action<generic_aoe_proc_t>( "footbomb_to_the_face", e, 1234219, true );
      damage->base_dd_min = damage->base_dd_max = e.driver()->effectN( 1 ).average( e );
      damage->base_multiplier *= role_mult( e );

      set_quiet( true );
      set_stack_change_callback( [ damage, p = e.player ]( buff_t*, int, int ) {
        // assume "explosions" (buff expired) out of combat do no damage for dslice/droute
        if ( p->in_combat )
          damage->execute();
      } );
    }

    timespan_t buff_duration() const
    {
      return rng().range( 100_ms, base_buff_duration );
    }
  };

  effect.custom_buff = make_buff<automatic_footbomb_dispenser_proxy_buff_t>( effect );

  new dbc_proc_callback_t( effect.player, effect );
}

// observer's soul fetters
// 1230281 equip coeff
// 1230285 use driver
void observers_soul_fetters( special_effect_t& effect )
{
  unsigned coeff_id = 1230281;
  auto coeff = find_special_effect( effect.player, coeff_id );
  assert( coeff && "Observer's Soul Fetters missing coeff effect" );

  effect.custom_buff = create_buff<stat_buff_t>( effect.player, effect.driver() )
    ->add_stat_from_effect_type( A_MOD_STAT, coeff->driver()->effectN( 1 ).average( effect ) );
}

// nexus-king's command
// 1232776 driver
// 1239997 debuff
// 1240000 buff
// 1240002 shield NYI
void nexuskings_command( special_effect_t& effect )
{
  if ( unique_gear::create_fallback_buffs( effect, { "oathbound", "boon_of_the_oathsworn" } ) )
    return;

  // emulate this as a buff on player for APL purposes
  auto bound = create_buff<buff_t>( effect.player, effect.player->find_spell( 1239997 ) );

  // for normal sims assume max 20 stack to represent 20 man raid. for dungeon sims limit to 5 stacks
  if ( effect.player->sim->fight_style == FIGHT_STYLE_DUNGEON_SLICE ||
       effect.player->sim->fight_style == FIGHT_STYLE_DUNGEON_ROUTE )
  {
    bound->set_max_stack( 5 );
  }
  else
  {
    bound->set_max_stack( 20 );
  }

  // start precombat with a stack of the debuff
  effect.player->register_precombat_begin( bound );

  // debuff is wiped on pull, gain a debuff every 30s during combat
  effect.player->register_combat_begin( [ bound, dur = effect.driver()->effectN( 1 ).period() ]( player_t* ) {
    bound->expire();
    make_event( *bound->sim, bound->rng().range( 0_ms, dur ), [ bound, dur ] {
      bound->trigger();
      make_repeating_event( *bound->sim, dur, [ bound ] { bound->trigger(); } );
    } );
  } );

  // assume you always heal the debuffed target
  effect.custom_buff = create_buff<stat_buff_t>( effect.player, effect.player->find_spell( 1240000 ) )
    ->set_stat_from_effect_type( A_MOD_STAT, effect.driver()->effectN( 1 ).average( effect ) );

  effect.player->callbacks.register_callback_trigger_function( effect.spell_id,
    dbc_proc_callback_t::trigger_fn_type::CONDITION,
    []( auto, const proc_data_t& data, auto, auto, auto ) {
      return data->affected_by_label( LABEL_HEALING_SPELLS );
    } );

  effect.player->callbacks.register_callback_execute_function( effect.spell_id,
    [ bound ]( const dbc_proc_callback_t* cb, auto, auto, auto ) {
      cb->proc_buff->trigger();
      bound->decrement();
    } );

  auto cb = new dbc_proc_callback_t( effect.player, effect );
  cb->activate_with_buff( bound );
}

// Weapons

// 443384 driver
// 443585 damage
// 443515 unknown buff
// 443519 debuff
// 443590 stat buff
// TODO: damage spell data is shadowfrost and not cosmic
// TODO: confirm buff/debuff is based on target type and not triggering spell type
// TODO: confirm cannot proc on pets
void fateweaved_needle( special_effect_t& effect )
{
  struct fateweaved_needle_cb_t : public dbc_proc_callback_t
  {
    action_t* damage;
    const spell_data_t* buff_spell;
    const spell_data_t* debuff_spell;
    double stat_amt;

    fateweaved_needle_cb_t( const special_effect_t& e )
      : dbc_proc_callback_t( e.player, e ),
      buff_spell( e.player->find_spell( 443590 ) ),
      debuff_spell( e.player->find_spell( 443519 ) ),
      stat_amt( e.driver()->effectN( 2 ).average( e ) )
    {
      // TODO: damage spell data is shadowfrost and not cosmic
      damage = create_proc_action<generic_proc_t>( "fated_pain", e, 443585 );
      damage->base_dd_min = damage->base_dd_max = e.driver()->effectN( 1 ).average( e );
      damage->base_multiplier *= role_mult( e );
    }

    buff_t* create_debuff( player_t* t ) override
    {
      // TODO: confirm buff/debuff is based on target type and not triggering spell type
      if ( t->is_enemy() )
      {
        return make_buff( actor_pair_t( t, listener ), "thread_of_fate_debuff", debuff_spell )
          ->set_expire_callback( [ this ]( buff_t* b, int, timespan_t ) {
            damage->execute_on_target( b->player );
          } );
      }
      else
      {
        return make_buff<stat_buff_t>( actor_pair_t( t, listener ), "thread_of_fate_buff", buff_spell )
          ->set_stat_from_effect_type( A_MOD_STAT, stat_amt )
          ->set_name_reporting( "thread_of_fate" );
      }
    }

    void trigger( const proc_data_t& data, player_t* t, action_state_t* s, proc_trigger_type_e type ) override
    {
      // TODO: confirm cannot proc on pets
      if ( t->is_enemy() || ( t != listener && t->is_player() ) )
        return dbc_proc_callback_t::trigger( data, t, s, type );
    }

    void execute( const spell_data_t*, player_t* t, action_state_t* ) override
    {
      get_debuff( t )->trigger();
      // From logs whenever it triggers on an enemy/ally it also triggers on yourself
      get_debuff( listener )->trigger();
    }
  };

  new fateweaved_needle_cb_t( effect );
}

// 442205 driver
// 442268 dot
// 442267 on-next buff
// 442280 on-next damage
// TODO: confirm on-next buff/damage stacks per dot expired
// TODO: determine if on-next buff ICD affects how often it can be triggered
// TODO: determine if on-next buff ICD affects how often it can be consumed
void befoulers_syringe( special_effect_t& effect )
{
  struct befouled_blood_t : public generic_proc_t
  {
    buff_t* bloodlust;  // on-next buff

    befouled_blood_t( const special_effect_t& e, buff_t* b )
      : generic_proc_t( e, "befouled_blood", e.trigger() ), bloodlust( b )
    {
      base_td = e.driver()->effectN( 1 ).average( e );
      base_multiplier *= role_mult( e );
      dot_max_stack = 1;
      dot_behavior = dot_behavior_e::DOT_REFRESH_DURATION;
      target_debuff = e.trigger();
    }

    buff_t* create_debuff( player_t* t ) override
    {
      return generic_proc_t::create_debuff( t )
        ->set_stack_behavior( buff_stack_behavior::ASYNCHRONOUS )
        ->set_activated( true )
        // trigger on-next buff here as buffs are cleared before dots in demise()
        // TODO: confirm on-next buff/damage stacks per dot expired
        // TODO: determine if on-next buff ICD affects how often it can be triggered
        ->set_expire_callback( [ this ]( buff_t*, int stack, timespan_t remains ) {
          if ( remains > 0_ms && stack )
            bloodlust->trigger( stack );
        } );
    }

    double composite_target_multiplier( player_t* t ) const override
    {
      auto ta = generic_proc_t::composite_target_multiplier( t );

      if ( auto debuff = find_debuff( t ) )
        ta *= debuff->check();

      return ta;
    }

    void trigger_dot( action_state_t* s ) override
    {
      generic_proc_t::trigger_dot( s );

      // get dot refresh duration, as it accounts for the ongoing tick
      auto duration = calculate_dot_refresh_duration( get_dot( s->target ), dot_duration );

      get_debuff( s->target )->trigger( duration + 1_ms );  // add 1ms to ensure last tick is buffed
    }
  };

  // create on-next melee damage
  auto strike = create_proc_action<generic_proc_t>( "befouling_strike", effect, 442280 );
  strike->base_dd_min = strike->base_dd_max = effect.driver()->effectN( 2 ).average( effect );
  strike->base_multiplier *= role_mult( effect );

  // create on-next melee buff
  auto bloodlust = create_buff<buff_t>( effect.player, effect.player->find_spell( 442267 ) );

  auto on_next = new special_effect_t( effect.player );
  on_next->name_str = bloodlust->name();
  on_next->spell_id = bloodlust->data().id();
  effect.player->special_effects.push_back( on_next );

  // TODO: determine if on-next buff ICD affects how often it can be consumed
  effect.player->callbacks.register_callback_execute_function( on_next->spell_id,
      [ bloodlust, strike ]( auto, auto, player_t* t, const action_state_t* s ) {
        strike->execute_on_target( t );
        bloodlust->consume( s->action );
      } );

  auto cb = new dbc_proc_callback_t( effect.player, *on_next );
  cb->activate_with_buff( bloodlust );

  effect.execute_action = create_proc_action<befouled_blood_t>( "befouled_blood", effect, bloodlust );

  new dbc_proc_callback_t( effect.player, effect );
}

// 455887 driver
//  e1: damage coeff
//  e2: stat coeff
// 455888 vfx?
// 455910 damage
// 456652 buff
void voltaic_stormcaller( special_effect_t& effect )
{
  struct voltaic_stormstrike_t : public generic_aoe_proc_t
  {
    stat_buff_with_multiplier_t* buff;

    voltaic_stormstrike_t( const special_effect_t& e ) : generic_aoe_proc_t( e, "voltaic_stormstrike", 455910, false )
    {
      travel_delay = 0.95;  // not in spell data, estimated from logs

      split_aoe_damage = false;  // TODO: confirm this remains true in 11.1
      base_dd_min = base_dd_max = e.driver()->effectN( 1 ).average( e );
      base_multiplier *= role_mult( e );

      buff = create_buff<stat_buff_with_multiplier_t>( e.player, e.player->find_spell( 456652 ) );
      buff->add_stat_from_effect_type( A_MOD_RATING, e.driver()->effectN( 2 ).average( e ) );
    }

    void impact( action_state_t* s ) override
    {
      generic_aoe_proc_t::impact( s );

      buff->stat_mul = generic_aoe_proc_t::composite_aoe_multiplier( execute_state );
      // buff is delayed by ~250ms, not in spell data, estimated from logs
      make_event( *sim, 250_ms, [ this ] { buff->trigger(); } );
    }
  };

  effect.execute_action = create_proc_action<voltaic_stormstrike_t>( "voltaic_stormstrike", effect );

  new dbc_proc_callback_t( effect.player, effect );
}

// 455819 driver
// 455821 damage
void harvesters_interdiction( special_effect_t& effect )
{
  auto dot = create_proc_action<generic_proc_t>( "interdictive_injection", effect, 455821 );
  dot->base_td = effect.driver()->effectN( 1 ).average( effect );
  dot->base_multiplier *= role_mult( effect );

  effect.execute_action = dot;
  // adjust rppm if harvester's edict (451055) is equipped
  if ( find_special_effect( effect.player, 451055 ) )
  {
    effect.rppm_modifier_ =
      effect.player->dbc->real_ppm_modifier( effect.spell_id, effect.player, effect.item->item_level(), 451055 );
  }

  new dbc_proc_callback_t( effect.player, effect );
}

// 469936 driver
// 469937 crit buff
// 469938 haste buff
// 469941 mastery buff
// 469942 versatility buff
// TODO: confirm buff cycle doesn't reset during middle of dungeon
void guiding_stave_of_wisdom( special_effect_t& effect )
{
  struct guiding_stave_of_wisdom_cb_t : public dbc_proc_callback_t
  {
    std::vector<buff_t*> buffs;

    guiding_stave_of_wisdom_cb_t( const special_effect_t& e ) : dbc_proc_callback_t( e.player, e )
    {
      for ( auto id : { 469937, 469938, 469941, 469942 } )
      {
        auto buff = create_buff<stat_buff_t>( effect.player, effect.player->find_spell( id ) )
          ->set_stat_from_effect_type( A_MOD_RATING, effect.driver()->effectN( 1 ).average( effect ) );

        buffs.push_back( buff );
      }
    }

    void reset() override
    {
      std::rotate( buffs.begin(), buffs.begin() + effect.player->rng().range( 4 ), buffs.end() );
    }

    void execute( const spell_data_t*, player_t*, action_state_t* ) override
    {
      buffs.front()->trigger();
      std::rotate( buffs.begin(), buffs.begin() + 1, buffs.end() );
    }
  };

  new guiding_stave_of_wisdom_cb_t( effect );
}

// 470641 driver, trigger damage
// 470642 damage
// 470643 reflect, NYI
void flame_wrath( special_effect_t& effect )
{
  auto damage = create_proc_action<generic_aoe_proc_t>( "flame_wrath", effect, effect.trigger(), true );
  damage->base_dd_min = damage->base_dd_max =
    effect.driver()->effectN( 1 ).average( effect ) + effect.trigger()->effectN( 1 ).average( effect );
  damage->base_multiplier *= role_mult( effect );

  effect.execute_action = damage;

  // TODO: damage reflect shield NYI
  new dbc_proc_callback_t( effect.player, effect );
}

// 470647 Driver
// 470648 Damage
void force_of_magma( special_effect_t& effect )
{
  auto damage         = create_proc_action<generic_proc_t>( "force_of_magma", effect, effect.trigger() );
  damage->base_dd_min = damage->base_dd_max =
      effect.driver()->effectN( 1 ).average( effect ) + effect.trigger()->effectN( 1 ).average( effect );
  damage->base_multiplier *= role_mult( effect );

  effect.execute_action = damage;
  new dbc_proc_callback_t( effect.player, effect );
}

// Vile Contamination
// 471316 Driver
// 473602 DoT
void vile_contamination( special_effect_t& effect )
{
  auto dot     = create_proc_action<generic_proc_t>( "vile_contamination", effect, effect.trigger() );
  dot->base_td += effect.driver()->effectN( 1 ).average( effect );
  // Setting a reasonably high non 0 duration so the DoT works as expected. Data contains no duration resulting in it
  // never applying.
  dot->dot_duration = 300_s;
  dot->base_td_multiplier = role_mult( effect );

  effect.execute_action = dot;
  effect.proc_flags2_ = PF2_ALL_HIT;
  new dbc_proc_callback_t( effect.player, effect );
}

// Best-in-Slots
// 473402 Use Driver & On Use Stat buff
// 471063 Equip Driver & Values
// 473492 Proc Stat Buff
void best_in_slots( special_effect_t& effect )
{
  auto equip_driver = effect.player->find_spell( 471063 );
  assert( equip_driver && "Best-in-Slots missing equip driver" );

  struct best_in_slots_stat_buff_t : stat_buff_t
  {
    double range_min;
    double range_max;

    best_in_slots_stat_buff_t( const special_effect_t& e, util::string_view name, const spell_data_t* s,
                               const item_t* item = nullptr )
      : stat_buff_t( e.player, name, s, item ), range_min( 0 ), range_max( 0 )
    {
      auto equip_driver = e.player->find_spell( 471063 );
      auto mod          = equip_driver->effectN( 2 ).percent();
      range_min         = 1 - mod;
      range_max         = 1 + mod;
    }

    double randomize_stat_value()
    {
      double val = default_value * rng().range( range_min, range_max );
      for ( auto& buff_stat : stats )
      {
        double delta            = val - buff_stat.current_value;
        buff_stat.current_value = val;
        buff_stat.amount        = val;
        if ( delta > 0 )
        {
          player->stat_gain( buff_stat.stat, delta, stat_gain, nullptr, buff_duration() > timespan_t::zero() );
        }
        else if ( delta < 0 )
        {
          player->stat_loss( buff_stat.stat, std::fabs( delta ), stat_gain, nullptr,
                             buff_duration() > timespan_t::zero() );
        }
      }
      return val;
    }

    void bump( int stacks, double ) override
    {
      buff_t::bump( stacks, randomize_stat_value() );
    }

    void expire_override( int s, timespan_t d ) override
    {
      for ( auto& buff_stat : stats )
      {
        player->stat_loss( buff_stat.stat, buff_stat.current_value, stat_gain, nullptr,
                           buff_duration() > timespan_t::zero() );

        buff_stat.current_value = 0;
      }

      // Purposely skip over stat_buff_t::expire_override() as we do the lost stat calculations manually
      buff_t::expire_override( s, d );
    }
  };

  struct best_in_slots_cb_t : public dbc_proc_callback_t
  {
    std::unordered_map<stat_e, buff_t*> buffs;

    best_in_slots_cb_t( const special_effect_t& equip, const special_effect_t& use )
      : dbc_proc_callback_t( equip.player, equip ), buffs()
    {
      auto buff_value      = equip.driver()->effectN( 1 ).average( use );
      auto proc_buff_spell = equip.player->find_spell( 473492 );

      create_all_stat_buffs<best_in_slots_stat_buff_t>( equip, proc_buff_spell, buff_value,
                                                        [ &, buff_value ]( stat_e s, buff_t* b ) {
                                                          b->default_value = buff_value;
                                                          buffs[ s ]       = b;
                                                        } );
    }

    void execute( const spell_data_t*, player_t*, action_state_t* ) override
    {
      auto buff = buffs.at( rng().range( secondary_ratings ) );
      if ( !buff->check() )
      {
        range::for_each( buffs, []( auto& b ) { b.second->expire(); } );
      }
      buff->trigger();
    }
  };

  auto equip      = new special_effect_t( effect.player );
  equip->name_str = equip_driver->name_cstr();
  equip->spell_id = equip_driver->id();
  effect.player->special_effects.push_back( equip );

  auto cb = new best_in_slots_cb_t( *equip, effect );
  cb->initialize();
  cb->activate();

  struct cheating_t : public spell_t
  {
    std::unordered_map<stat_e, buff_t*> buffs;

    cheating_t( const special_effect_t& e, const spell_data_t* equip_driver )
      : spell_t( "cheating", e.player, e.driver() ), buffs()
    {
      auto value_mod  = 1 + equip_driver->effectN( 2 ).percent();
      auto buff_value = equip_driver->effectN( 1 ).average( e ) * value_mod;

      create_all_stat_buffs( e, e.driver(), buff_value, [ &, buff_value ]( stat_e s, buff_t* b ) {
        b->default_value = buff_value;
        buffs[ s ]       = b;
        b->cooldown->duration = 0_ms; // Handled by the action
      } );
    }

    void execute() override
    {
      spell_t::execute();
      buffs.at( util::highest_stat( player, secondary_ratings ) )->trigger();
    }
  };

  effect.disable_buff();
  effect.spell_id       = 473402;
  effect.execute_action = create_proc_action<cheating_t>( "cheating", effect, equip_driver );
}

// Machine Gob's Iron Grin
// 1218442 Driver
// 1218471 Big Damage
// 1218469 Medium Damage
// 1218463 Small Damage
void machine_gobs_iron_grin( special_effect_t& effect )
{
  struct machine_gobs_iron_grin_cb_t : public dbc_proc_callback_t
  {
    action_t* big_damage;
    action_t* medium_damage;
    action_t* small_damage;
    action_t* proxy;

    machine_gobs_iron_grin_cb_t( const special_effect_t& e )
      : dbc_proc_callback_t( e.player, e ), big_damage( nullptr ), medium_damage( nullptr ), small_damage( nullptr ), proxy( nullptr )
    {
      proxy = new action_t( action_e::ACTION_OTHER, "machine_gobs_iron_grin", e.player, e.driver() );
      big_damage = create_proc_action<generic_aoe_proc_t>( "machine_gobs_bellowing_laugh", e, 1218471, true );
      big_damage->base_dd_min = big_damage->base_dd_max = e.driver()->effectN( 3 ).average( e );
      proxy->add_child( big_damage );

      medium_damage              = create_proc_action<generic_aoe_proc_t>( "machine_gobs_big_grin", e, 1218469, true );
      medium_damage->base_dd_min = medium_damage->base_dd_max = e.driver()->effectN( 2 ).average( e );
      proxy->add_child( medium_damage );

      small_damage              = create_proc_action<generic_aoe_proc_t>( "machine_gobs_hiccup", e, 1218463, true );
      small_damage->base_dd_min = small_damage->base_dd_max = e.driver()->effectN( 1 ).average( e );
      proxy->add_child( small_damage );
    }

    void execute( const spell_data_t*, player_t* t, action_state_t* ) override
    {
      auto rand = rng().range( 0, 3 );
      switch ( rand )
      {
        case 0:
          big_damage->execute_on_target( t );
          break;
        case 1:
          medium_damage->execute_on_target( t );
          break;
        case 2:
          small_damage->execute_on_target( t );
          break;
      }
      proxy->stats->add_execute( 0_ms, listener );
    }
  };

  new machine_gobs_iron_grin_cb_t( effect );
}

void capos_molten_knuckles( special_effect_t& effect )
{
  effect.execute_action = create_proc_action<generic_proc_t>( "capos_molten_knuckles", effect, effect.player->find_spell( 473626 ) );
  effect.execute_action->base_dd_min = effect.execute_action->base_dd_max =
    effect.driver()->effectN( 1 ).average( effect.item );
  effect.execute_action->base_multiplier *= role_mult( effect );

  const spell_data_t* dot_spell = effect.driver()->effectN( 1 ).trigger()->effectN( 2 ).trigger();
  effect.execute_action->execute_action = create_proc_action<generic_proc_t>( "molten_gold", effect, dot_spell );

  effect.execute_action->execute_action->tick_action =
    create_proc_action<generic_proc_t>( "molten_gold_tick", effect, effect.player->find_spell( 473704 ) );

  effect.execute_action->execute_action->tick_action->base_dd_min =
    effect.execute_action->execute_action->tick_action->base_dd_max =
    effect.driver()->effectN( 2 ).average( effect.item );
  effect.execute_action->execute_action->tick_action->base_multiplier *= role_mult( effect );

  effect.execute_action->execute_action->tick_action->aoe = -1;
  // Not in spell data, needs to be tested.
  effect.execute_action->execute_action->tick_action->reduced_aoe_targets = 8.0;

  effect.execute_action->add_child( effect.execute_action->execute_action );

  new dbc_proc_callback_t( effect.player, effect );
}

// Nightfall Shadow Quake
// 1224457 driver
//   e1: damage
// 1228149 aoe
void shadow_quake( special_effect_t& effect )
{
  struct shadow_quake_cb_t : public dbc_proc_callback_t
  {
    action_t* damage;
    std::vector<int> target_list;

    shadow_quake_cb_t( const special_effect_t& e ) : dbc_proc_callback_t( e.player, e ), target_list()
    {
      damage = create_proc_action<generic_aoe_proc_t>( "shadow_quake", e, 1228149, true );
      damage->base_dd_min = damage->base_dd_max = e.driver()->effectN( 1 ).average( e );

      // Leaving combat will reset the first-hit limit (e.g. Vanish or Shadowmeld in DungeonSlice/DungeonRoute)
      e.player->register_on_combat_state_callback( [ & ]( player_t*, bool c ) {
        if ( !c )
          target_list.clear();
      } );
    }

    void execute( const spell_data_t*, player_t* t, action_state_t* s ) override
    {
      if ( !s->action->harmful )
        return;

      if ( range::contains( target_list, t->actor_spawn_index ) )
        return;

      damage->execute_on_target( t );
      target_list.push_back( t->actor_spawn_index );
    }

    void reset() override
    {
      dbc_proc_callback_t::reset();
      target_list.clear();
    }
  };

  effect.proc_flags2_ = PF2_ALL_HIT;

  new shadow_quake_cb_t( effect );
}

// Voidglass Shards
// 1235136 Driver
// 1238693 Damage
// TODO: implement Absorb if it ever matters in sims rather than fizzling
void voidglass_shards( special_effect_t& effect )
{
  struct voidglass_shards_cb_t : public dbc_proc_callback_t
  {
    action_t* damage;
    double damage_chance;

    voidglass_shards_cb_t( const special_effect_t& e ) : dbc_proc_callback_t( e.player, e ), damage( nullptr )
    {
      damage = create_proc_action<generic_proc_t>( "voidglass_shards", e, 1238693 );
      damage->base_dd_min = damage->base_dd_max = e.driver()->effectN( 1 ).average( e );
      damage->base_multiplier *= role_mult( e );
    }

    void execute( const spell_data_t*, player_t* t, action_state_t* s ) override
    {
      if ( !s ) return;

      if ( s->result_type == result_amount_type::DMG_DIRECT || s->result_type == result_amount_type::DMG_OVER_TIME )
      {
        damage->execute_on_target( t );
      }
    }
  };

  effect.proc_flags2_ = PF2_ALL_HIT;

  new voidglass_shards_cb_t( effect );
}

// warplance strike
// 1243411 driver
void warplance_strike( special_effect_t& effect )
{
  effect.aoe = -1;
  effect.discharge_amount = effect.driver()->effectN( 1 ).average( effect ) * role_mult( effect );
}

// Armor

// 457815 driver
// 457918 nature damage driver
// 457925 counter
// 457928 dot
void seal_of_the_poisoned_pact( special_effect_t& effect )
{
  unsigned nature_id = 457918;
  auto nature = find_special_effect( effect.player, nature_id );
  assert( nature && "Seal of the Poisoned Pact missing nature damage driver" );

  auto dot = create_proc_action<generic_proc_t>( "venom_shock", effect, 457928 );
  dot->base_td = effect.driver()->effectN( 1 ).average( effect ) * dot->base_tick_time / dot->dot_duration;
  dot->base_multiplier *= role_mult( effect );

  auto counter = create_buff<buff_t>( effect.player, effect.player->find_spell( 457925 ) )
    ->set_expire_at_max_stack( true )
    ->set_expire_callback( [ dot ]( buff_t* b, int, timespan_t ) {
      dot->execute_on_target( b->player->target );
    } );

  effect.custom_buff = counter;

  new dbc_proc_callback_t( effect.player, effect );

  // TODO: confirm nature damage driver is entirely independent
  nature->name_str = nature->name() + "_nature";
  nature->custom_buff = counter;

  effect.player->callbacks.register_callback_trigger_function( nature_id,
    dbc_proc_callback_t::trigger_fn_type::CONDITION,
    []( auto, const auto&, auto, const action_state_t* s, auto ) {
      return dbc::has_common_school( s->action->get_school(), SCHOOL_NATURE );
    } );

  new dbc_proc_callback_t( effect.player, *nature );
}

// 455799 Driver
// 455820 First Dig
// 455826 Second Dig
// 455827 Third Dig
void excavation( special_effect_t& effect )
{
  // Currently does nothing if multiple of these are equipped at the same time
  if ( buff_t::find( effect.player, "Uncommon Treasure" ) )
    return;

  struct excavation_cb_t : public dbc_proc_callback_t
  {
    std::vector<buff_t*> buff_list;
    unsigned dig_count;

    excavation_cb_t( const special_effect_t& e ) : dbc_proc_callback_t( e.player, e ), buff_list(), dig_count( 0 )
    {
      auto uncommon = create_buff<stat_buff_t>( e.player, e.player->find_spell( 455820 ) )
                          ->add_stat_from_effect_type( A_MOD_STAT, e.driver()->effectN( 1 ).average( e ) * 0.9 );

      buff_list.push_back( uncommon );

      auto rare = create_buff<stat_buff_t>( e.player, e.player->find_spell( 455826 ) )
                      ->add_stat_from_effect_type( A_MOD_STAT, e.driver()->effectN( 1 ).average( e ) );

      buff_list.push_back( rare );

      auto epic = create_buff<stat_buff_t>( e.player, e.player->find_spell( 455827 ) )
                      ->add_stat_from_effect_type( A_MOD_STAT, e.driver()->effectN( 1 ).average( e ) * 1.1 );

      buff_list.push_back( epic );
    }

    void execute( const spell_data_t*, player_t*, action_state_t* ) override
    {
      buff_list[ dig_count ]->trigger();
      if ( dig_count < buff_list.size() - 1 )
        dig_count++;
      else
        dig_count = 0;
    }
  };

  new excavation_cb_t( effect );
}

void sureki_zealots_insignia( special_effect_t& e )
{
  auto buff = create_buff<stat_buff_t>( e.player, e.player->find_spell( 457684 ) )
                  ->add_stat_from_effect_type( A_MOD_RATING, e.driver()->effectN( 1 ).average( e ) );

  e.custom_buff = buff;

  // The Drivers flags are for Healing Taken. Swap flags to damage flags to at least get personal valuation.
  e.proc_flags_  = PF_ALL_DAMAGE | PF_PERIODIC;
  e.proc_flags2_ = PF2_ALL_HIT | PF2_PERIODIC_DAMAGE;

  e.rppm_modifier_ = e.player->thewarwithin_opts.sureki_zealots_insignia_rppm_multiplier;

  new dbc_proc_callback_t( e.player, e );
}

// The Jastor Diamond
// 1214161 Value Spell
// 1214822 Driver
// 1215043 Cooldown spell
// 1214823 Self Buff
// 1214826 Ally Buff
// TODO: NYI Bug - Randomly just breaks and stops triggering.
// https://cdn.discordapp.com/attachments/1240061447372017760/1333977502577721554/image.png?ex=67aaacdc&is=67a95b5c&hm=3ba419d6968805aa51d124df52b5d0312d90e669099f8540f1d8bc4691ac9e59&
// TODO: Appears to dynamically update the stat value given if the targeted players highest stat changes. This might be an absolute headache.
void the_jastor_diamond( special_effect_t& effect )
{
  auto equip_driver = effect.player->find_spell( 1214822 );
  assert( equip_driver && "Jastor Diamond Equip Driver not found." );

  auto cooldown_spell = effect.player->find_spell( 1215043 );
  assert( cooldown_spell && "Jastor Diamond Cooldown spell not found." );

  struct jastor_diamond_buff_base_t : public stat_buff_t
  {
    double current_total_value;
    jastor_diamond_buff_base_t( actor_pair_t p, std::string_view n, const spell_data_t* s )
      : stat_buff_t( p, n, s ), current_total_value( 0 )
    {
      set_default_value( 0 );
      add_stat_from_effect( 1, 0 );
      add_stat_from_effect( 2, 0 );
      add_stat_from_effect( 3, 0 );
      add_stat_from_effect( 4, 0 );
    }

    virtual void add_ally_stat( stat_e s, double val )
    {
      current_total_value += val;
      for ( auto& buff_stat : stats )
      {
        if ( buff_stat.stat == s )
        {
          buff_stat.amount = current_total_value;

          double delta = current_total_value - buff_stat.current_value;
          if ( delta > 0 )
          {
            player->stat_gain( buff_stat.stat, delta, stat_gain, nullptr, buff_duration() > timespan_t::zero() );
          }
          else if ( delta < 0 )
          {
            player->stat_loss( buff_stat.stat, std::fabs( delta ), stat_gain, nullptr,
                               buff_duration() > timespan_t::zero() );
          }

          buff_stat.current_value += delta;
        }
        else
        {
          buff_stat.amount = 0;
          player->stat_loss( buff_stat.stat, buff_stat.current_value, stat_gain, nullptr,
                             buff_duration() > timespan_t::zero() );
          buff_stat.current_value = 0;
        }
      }
    }

    void expire_override( int s, timespan_t d ) override
    {
      for ( auto& buff_stat : stats )
      {
        player->stat_loss( buff_stat.stat, buff_stat.current_value, stat_gain, nullptr,
                           buff_duration() > timespan_t::zero() );

        buff_stat.current_value = 0;
      }

      // Purposely skip over stat_buff_t::expire_override() as we do the lost stat calculations manually
      buff_t::expire_override( s, d );
      current_total_value = 0;
    }

    buff_stat_t& get_stat( stat_e s )
    {
      for ( auto& buff_stat : stats )
      {
        if ( buff_stat.stat == s )
          return buff_stat;
      }
      // Fallback if the above fails for any reason.
      return stats[ 0 ];
    }

    void reset() override
    {
      stat_buff_t::reset();
      current_total_value = 0;
    }

    void bump( int stacks, double /* value */ ) override
    {
      // Purposely skip over stat_buff_t::bump() as we do the added stat calculations manually
      buff_t::bump( stacks );
    }

    double buff_stat_stack_amount( const buff_stat_t&, int ) const override
    {
      return 0;
    }
  };

  struct i_did_that_buff_t : public jastor_diamond_buff_base_t
  {
    int fake_stacks;
    int max_fake_stacks;

    i_did_that_buff_t( actor_pair_t p, std::string_view n, const spell_data_t* s )
      : jastor_diamond_buff_base_t( p, n, s ), fake_stacks( 0 ), max_fake_stacks( 0 )
    {
      max_fake_stacks = as<int>( source->find_spell( 1214161 )->effectN( 2 ).base_value() );
      set_constant_behavior( buff_constant_behavior::NEVER_CONSTANT );
    }

    void add_ally_stat( stat_e s, double val ) override
    {
      if ( fake_stacks++ < max_fake_stacks )
      {
        jastor_diamond_buff_base_t::add_ally_stat( s, val );
      }
    }

    double get_current_stat_value( stat_e s )
    {
      auto stat = get_stat( s );
      return stat.current_value;
    }

    void reset() override
    {
      jastor_diamond_buff_base_t::reset();
      fake_stacks = 0;
    }

    void expire_override( int s, timespan_t d ) override
    {
      fake_stacks = 0;
      jastor_diamond_buff_base_t::expire_override( s, d );
    }
  };

  struct no_i_did_that_buff_t : public jastor_diamond_buff_base_t
  {
    no_i_did_that_buff_t( actor_pair_t p, std::string_view n, const spell_data_t* s )
      : jastor_diamond_buff_base_t( p, n, s )
    {
    }
  };

  struct the_jastor_diamond_cb_t : public dbc_proc_callback_t
  {
    i_did_that_buff_t* self_buff;
    const spell_data_t* value_spell;
    const spell_data_t* ally_buff_spell;
    double buff_value;
    std::unordered_map<player_t*, no_i_did_that_buff_t*> ally_buffs;
    vector_with_callback<player_t*> ally_list;
    // Bug Related vars
    player_t* linked_player;
    stat_e rolled_stat;

    the_jastor_diamond_cb_t( const special_effect_t& e )
      : dbc_proc_callback_t( e.player, e ),
        self_buff( nullptr ),
        value_spell( e.player->find_spell( 1214161 ) ),
        ally_buff_spell( e.player->find_spell( 1214826 ) ),
        buff_value( 0 ),
        ally_buffs(),
        ally_list(),
        linked_player( nullptr ),
        rolled_stat( STAT_NONE )
    {
      assert( value_spell && "The Jastor Diamond missing value spell." );
      buff_value = value_spell->effectN( 1 ).average( e );

      self_buff = create_buff<i_did_that_buff_t>( e.player, "i_did_that", e.player->find_spell( 1214823 ) );

      if ( e.player->sim->player_no_pet_list.size() > 1 && !e.player->sim->single_actor_batch )
      {
        ally_list = e.player->sim->player_no_pet_list;
        ally_list.find_and_erase( e.player );
        if ( ally_list.size() > 0 )
        {
          for ( auto& ally : ally_list )
          {
            auto ally_buff =
                make_buff<no_i_did_that_buff_t>( actor_pair_t{ ally, e.player }, "no_i_did_that", ally_buff_spell );
            ally_buffs.insert( { { ally }, { ally_buff } } );
          }

          linked_player = rng().range( ally_list );
        }
      }

      // Currently bugged, and seems to get stuck on a single player, never changing.
      // To emulate this, give players the option to chose their allied players highest stat, or randomly roll one
      // for them every iteration.
      if ( e.player->bugs )
      {
        const auto& desired_stat = e.player->thewarwithin_opts.jastor_diamond_ally_stat;
        if ( util::str_compare_ci( desired_stat, "none" ) || desired_stat.is_default() )
          rolled_stat = rng().range( secondary_ratings );

        if ( util::str_compare_ci( desired_stat, "haste" ) )
          rolled_stat = STAT_HASTE_RATING;

        if ( util::str_compare_ci( desired_stat, "mastery" ) )
          rolled_stat = STAT_MASTERY_RATING;

        if ( util::str_compare_ci( desired_stat, "critical_strike" ) || util::str_compare_ci( desired_stat, "crit" ) )
          rolled_stat = STAT_CRIT_RATING;

        if ( util::str_compare_ci( desired_stat, "versatility" ) || util::str_compare_ci( desired_stat, "vers" ) )
          rolled_stat = STAT_VERSATILITY_RATING;

        if ( rolled_stat == STAT_NONE )
        {
          listener->sim->error(
              "{} is not a valid stat for Jastors Diamond, randomly selecting stat. \n Valid options are haste, "
              "crit, mastery, or vers.",
              desired_stat );
          rolled_stat = rng().range( secondary_ratings );
        }
      }
    }

    player_t* pick_random_target()
    {
      std::vector<player_t*> eligible;
      for ( auto p : ally_list )
        if ( !p->is_sleeping() )
          eligible.push_back( p );
      assert( !eligible.empty() );
      return rng().range( eligible );
    }

    void execute( const spell_data_t*, player_t*, action_state_t* ) override
    {
      if ( ally_list.size() > 0 )
      {
        player_t* random_target;
        // Currently bugged, and gets stuck on one target. This target seems to be the same every pull.
        if ( listener->bugs )
        {
          if ( linked_player == nullptr || linked_player->is_sleeping() )
            linked_player = pick_random_target();

          random_target = linked_player;
        }
        else
          random_target = pick_random_target();

        if ( self_buff->check() && rng().roll( value_spell->effectN( 3 ).percent() ) )
        {
          no_i_did_that_buff_t* buff = ally_buffs.at( random_target );
          for ( auto stat : secondary_ratings )
          {
            double val = self_buff->get_current_stat_value( stat );
            buff->add_ally_stat( stat, val );
          }
          buff->trigger();
          self_buff->expire();
        }
        else
        {
          auto stat = util::highest_stat( random_target, secondary_ratings );
          self_buff->add_ally_stat( stat, buff_value );
          self_buff->trigger();
        }
      }
      else
      {
        if ( self_buff->check() && rng().roll( value_spell->effectN( 3 ).percent() ) )
        {
          self_buff->expire();
        }
        else
        {
          if ( !listener->bugs )
            rolled_stat = rng().range( secondary_ratings );

          self_buff->add_ally_stat( rolled_stat, buff_value );
          self_buff->trigger();
        }
      }
    }
  };

  effect.cooldown_ = cooldown_spell->duration();
  effect.spell_id  = equip_driver->id();
  new the_jastor_diamond_cb_t( effect );
}

double reshii_wraps_rppm( special_effect_t& effect )
{
  // 50%, 40%, 30%, 20%
  static constexpr std::array<unsigned, 4> aura_ids = { 1235409, 1254905, 1254904, 1254906 };

  for ( auto id : aura_ids )
  {
    if ( find_special_effect( effect.player, id ) )
    {
      return effect.player->dbc->real_ppm_modifier(
        effect.spell_id, effect.player, effect.item->item_level(), id );
    }
  }

  return effect.rppm_modifier();
}

// Reshii Wraps: Ethereal Reaping
// 1217091 Value Spell
// 1217101 Driver
// 1223419 Missile
// 1223417 Damage
void ethereal_reaping( special_effect_t& effect )
{
  struct ethereal_reaping_t final : public generic_aoe_proc_t
  {
    double hp_pct;
    double execute_mult;

    ethereal_reaping_t( const special_effect_t& e )
      : generic_aoe_proc_t( e, "ethereal_reaping", e.player->find_spell( 1223417 ) ), hp_pct( 0.0 ), execute_mult( 0.0 )
    {
      const spell_data_t* value_spell = e.player->find_spell( 1217091 );

      hp_pct       = value_spell->effectN( 4 ).base_value();
      execute_mult = value_spell->effectN( 5 ).percent();

      base_dd_min = base_dd_max = value_spell->effectN( 1 ).average( e );
    }

    double composite_target_multiplier( player_t* t ) const override
    {
      double v = generic_proc_t::composite_target_multiplier( t );

      if ( t->health_percentage() <= hp_pct )
        v *= 1.0 + execute_mult;

      return v;
    }
  };

  auto damage = create_proc_action<ethereal_reaping_t>( "ethereal_reaping", effect );

  auto missile           = create_proc_action<generic_proc_t>( "ethereal_reaping_missile", effect, 1223419 );
  missile->impact_action = damage;

  effect.execute_action = missile;
  effect.rppm_modifier_ = reshii_wraps_rppm( effect );

  new dbc_proc_callback_t( effect.player, effect );
}

// Reshii Wraps equip driver
// 1217091 Driver Spell
// All this does is swap which effect is present based on spec
void ethereal_energy( special_effect_t& effect )
{
  // Default to DPS specilizations Ethereal Reaping in case something goes VERY wrong
  int spell_id = 1217101;

  switch ( effect.player->_spec )
  {
    case HUNTER_BEAST_MASTERY:
    case HUNTER_MARKSMANSHIP:
    case PRIEST_SHADOW:
    case SHAMAN_ELEMENTAL:
    case MAGE_ARCANE:
    case MAGE_FIRE:
    case MAGE_FROST:
    case WARLOCK_AFFLICTION:
    case WARLOCK_DEMONOLOGY:
    case WARLOCK_DESTRUCTION:
    case DRUID_BALANCE:
    case EVOKER_DEVASTATION:
    case EVOKER_AUGMENTATION:
    case WARRIOR_ARMS:
    case WARRIOR_FURY:
    case PALADIN_RETRIBUTION:
    case HUNTER_SURVIVAL:
    case ROGUE_ASSASSINATION:
    case ROGUE_OUTLAW:
    case ROGUE_SUBTLETY:
    case DEATH_KNIGHT_FROST:
    case DEATH_KNIGHT_UNHOLY:
    case SHAMAN_ENHANCEMENT:
    case MONK_WINDWALKER:
    case DRUID_FERAL:
    case DEMON_HUNTER_HAVOC:
      spell_id = 1217101;
      effect.spell_id = spell_id;
      ethereal_reaping( effect );
      break;
    case WARRIOR_PROTECTION:
    case PALADIN_PROTECTION:
    case DEATH_KNIGHT_BLOOD:
    case MONK_BREWMASTER:
    case DRUID_GUARDIAN:
    case DEMON_HUNTER_VENGEANCE:
      spell_id = 1217096;
      effect.spell_id = spell_id;
      break;
    case PALADIN_HOLY:
    case PRIEST_DISCIPLINE:
    case PRIEST_HOLY:
    case SHAMAN_RESTORATION:
    case MONK_MISTWEAVER:
    case DRUID_RESTORATION:
    case EVOKER_PRESERVATION:
      spell_id = 1217103;
      effect.spell_id = spell_id;
      break;
    default:
      spell_id = 1217101;
      effect.spell_id = spell_id;
      break;
  }
}
}  // namespace items

namespace sets
{
// 444067 driver
// 448643 unknown (0.2s duration, 6yd radius, outgoing aoe hit?)
// 448621 unknown (0.125s duration)
// 448669 damage
void void_reapers_contract( special_effect_t& effect )
{
  struct void_reapers_contract_cb_t : public dbc_proc_callback_t
  {
    action_t* major;
    action_t* minor;
    action_t* queensbane = nullptr;
    double hp_pct;

    void_reapers_contract_cb_t( const special_effect_t& e )
      : dbc_proc_callback_t( e.player, e ), hp_pct( e.driver()->effectN( 2 ).base_value() )
    {
      auto damage_spell = effect.player->find_spell( 448669 );
      auto damage_name = std::string( damage_spell->name_cstr() );
      auto damage_amount = effect.driver()->effectN( 1 ).average( effect );

      major = create_proc_action<generic_aoe_proc_t>( damage_name, effect, damage_spell );
      major->base_dd_min = major->base_dd_max = damage_amount;
      major->split_aoe_damage = false;
      major->base_multiplier *= role_mult( effect );
      major->base_aoe_multiplier = effect.driver()->effectN( 5 ).percent();

      minor = create_proc_action<generic_aoe_proc_t>( damage_name + "_echo", effect, damage_spell );
      minor->base_dd_min = minor->base_dd_max = damage_amount * effect.driver()->effectN( 3 ).percent();
      minor->split_aoe_damage = false;
      minor->base_multiplier *= role_mult( effect );
      minor->base_aoe_multiplier = effect.driver()->effectN( 5 ).percent();
      minor->name_str_reporting = "Echo";
      major->add_child( minor );
    }

    void initialize() override
    {
      dbc_proc_callback_t::initialize();

      if ( listener->sets->has_set_bonus( listener->specialization(), TWW_KCI, B2 ) )
        if ( auto claw = find_special_effect( listener, 444135 ) )
          queensbane = claw->execute_action;
    }

    void execute( const spell_data_t*, player_t* t, action_state_t* ) override
    {
      major->execute_on_target( t );

      bool echo = false;

      if ( queensbane )
      {
        auto dot = queensbane->find_dot( t );
        if ( dot && dot->is_ticking() )
          echo = true;
      }

      if ( !echo && t->health_percentage() < hp_pct )
        echo = true;

      if ( echo )
      {
        // each echo delayed by 300ms
        make_repeating_event( *listener->sim, 300_ms, [ this, t ] {
          if ( !t->is_sleeping() )
            minor->execute_on_target( t );
        }, 2 );
      }
    }
  };

  new void_reapers_contract_cb_t( effect );
}

// 444135 driver
// 448862 dot (trigger)
void void_reapers_warp_blade( special_effect_t& effect )
{
  auto dot_data = effect.trigger();
  auto dot = create_proc_action<generic_proc_t>( "queensbane", effect, dot_data );
  dot->base_td =
    effect.driver()->effectN( 1 ).average( effect ) * dot_data->effectN( 1 ).period() / dot_data->duration();
  dot->base_multiplier *= role_mult( effect );

  effect.execute_action = dot;

  new dbc_proc_callback_t( effect.player, effect );
}

// Woven Dusk
// 457655 Driver
// 457630 Buff
void woven_dusk( special_effect_t& effect )
{
  if ( unique_gear::create_fallback_buffs( effect, { "woven_dusk" } ) )
    return;

  // Need to force player sccaling for equipment set
  auto buff = create_buff<stat_buff_t>( effect.player, effect.player->find_spell( 457630 ) )
                  ->add_stat_from_effect_type( A_MOD_RATING, effect.driver()->effectN( 2 ).average( effect ) );

  // The buff has RPPM in spell data, but this is not used when it triggers from the driver.
  buff->set_chance( 1.0 )->set_rppm( RPPM_DISABLE );

  effect.custom_buff = buff;
  effect.proc_flags2_ = PF2_ALL_HIT;

  new dbc_proc_callback_t( effect.player, effect );

  if ( effect.player->bugs )
  {
    // If the player is casting a spell, the buff does not seem to be applied.
    effect.player->callbacks.register_callback_execute_function( effect.spell_id,
      [ buff ]( const dbc_proc_callback_t* cb, auto, auto, auto )
    {
      if ( !cb->listener->executing )
        buff->trigger();
    } );
  }
}

// Woven Dawn
// 455521 Driver
// 457627 Buff
void woven_dawn( special_effect_t& effect )
{
  if ( unique_gear::create_fallback_buffs( effect, { "woven_dawn" } ) )
    return;

  // Need to force player sccaling for equipment set
  auto buff = create_buff<stat_buff_t>( effect.player, effect.player->find_spell( 457627 ) )
                  ->add_stat_from_effect_type( A_MOD_RATING, effect.driver()->effectN( 2 ).average( effect ) );

  // The buff has RPPM in spell data, but this is not used when it triggers from the driver.
  buff->set_chance( 1.0 )->set_rppm( RPPM_DISABLE );

  effect.custom_buff = buff;

  // Driver procs off Druid hostile abilities (Probably) as well as Priest hostile abilities (confirmed) as they always historically do
  if ( effect.player->type == player_e::DRUID || effect.player->type == player_e::PRIEST )
    effect.proc_flags_ |= PF_MAGIC_SPELL | PF_MELEE_ABILITY;

  new dbc_proc_callback_t( effect.player, effect );
}


// Embrace of the Cinderbee
// 443764 Driver
// 451698 Orb Available Buff
// 451699 Player Stat Buff
// 451980 Ally stat buff ( NYI )
struct pickup_cinderbee_orb_t : public action_t
{
  buff_t* orb = nullptr;

  pickup_cinderbee_orb_t( player_t* p, std::string_view opt )
    : action_t( ACTION_OTHER, "pickup_cinderbee_orb", p, spell_data_t::nil() )
  {
    parse_options( opt );

    s_data_reporting   = p->find_spell( 451698 );
    name_str_reporting = "Cinderbee Orb Collected";

    callbacks = harmful = false;
    trigger_gcd         = 0_ms;
  }

  bool ready() override
  {
    return orb->check();
  }

  void execute() override
  {
    if ( !rng().roll( player->thewarwithin_opts.embrace_of_the_cinderbee_miss_chance ) )
    {
      orb->decrement();
    }
  }
};

void embrace_of_the_cinderbee( special_effect_t& effect )
{
  if ( unique_gear::create_fallback_buffs( effect, { "embrace_of_the_cinderbee_orb" } ) )
    return;

  struct embrace_of_the_cinderbee_t : public dbc_proc_callback_t
  {
    buff_t* orb;
    std::unordered_map<stat_e, buff_t*> buffs;
    std::vector<action_t*> apl_actions;
    player_t* player;

    embrace_of_the_cinderbee_t( const special_effect_t& e ) : dbc_proc_callback_t( e.player, e ), player( e.player )
    {
      auto value = e.player->find_spell( 451699 )->effectN( 5 ).average( e );
      create_all_stat_buffs( e, e.player->find_spell( 451699 ), value,
                             [ this ]( stat_e s, buff_t* b ) { buffs[ s ] = b; } );

      orb = create_buff<buff_t>( e.player, "embrace_of_the_cinderbee_orb", e.player->find_spell( 451698 ) )
                ->set_max_stack( 10 )
                ->set_stack_behavior( buff_stack_behavior::ASYNCHRONOUS )
                ->set_stack_change_callback( [ & ]( buff_t*, int old_, int new_ ) {
                  if ( old_ > new_ )
                  {
                    buffs.at( util::highest_stat( e.player, secondary_ratings ) )->trigger();
                  }
                } );

      for ( auto& a : e.player->action_list )
      {
        if ( a->name_str == "pickup_cinderbee_orb" )
        {
          apl_actions.push_back( a );
        }
      }

      if ( apl_actions.size() > 0 )
      {
        for ( auto& a : apl_actions )
        {
          debug_cast<pickup_cinderbee_orb_t*>( a )->orb = orb;
        }
      }
    }

    void execute( const spell_data_t*, player_t*, action_state_t* ) override
    {
      if ( apl_actions.size() > 0 )
      {
        orb->trigger();
      }
      else
      {
        timespan_t timing  = player->thewarwithin_opts.embrace_of_the_cinderbee_timing;
        double miss_chance = player->thewarwithin_opts.embrace_of_the_cinderbee_miss_chance;
        make_event( *player->sim, timing > 0_ms ? timing : rng().range( 100_ms, orb->data().duration() ),
                    [ this, miss_chance ] {
                      if ( !rng().roll( miss_chance ) )
                      {
                        buffs.at( util::highest_stat( player, secondary_ratings ) )->trigger();
                      }
                    } );
      }
    }
  };

  new embrace_of_the_cinderbee_t( effect );
}

// 443773 driver
// 449440 buff
// 449441 orb
void fury_of_the_stormrook( special_effect_t& effect )
{
  struct fury_of_the_stormrook_cb_t : public dbc_proc_callback_t
  {
    rng::truncated_gauss_t pickup;
    buff_t* buff;

    fury_of_the_stormrook_cb_t( const special_effect_t& e )
      : dbc_proc_callback_t( e.player, e ),
        pickup( e.player->thewarwithin_opts.fury_of_the_stormrook_pickup_delay,
                e.player->thewarwithin_opts.fury_of_the_stormrook_pickup_stddev )
    {
      buff = create_buff<stat_buff_t>( e.player, e.player->find_spell( 449440 ) );
    }

    void execute( const spell_data_t*, player_t*, action_state_t* ) override
    {
      make_event( *listener->sim, rng().gauss( pickup ), [ this ] { buff->trigger(); } );
    }
  };

  new fury_of_the_stormrook_cb_t( effect );
}

void shards_of_the_void( special_effect_t& effect )
{
  // Shares a name with the weapon effects, change it here to pevent special effect merging
  effect.name_str = fmt::format( "{}_{}", effect.driver()->name_cstr(), "set" );

  effect.player->register_init_finished_callback( [ &effect ]( player_t* p ) {
    buff_t* buff = buff_t::find( p, "diamantine_voidcore", p );
    if ( buff )
    {
      p->sim->print_debug( "Registering Shards of the Void callback" );
      action_t* damage = p->find_action( "voidglass_shards" );
      if ( damage )
      {
        buff->set_stack_change_callback( [ &effect, damage ]( buff_t*, int old_, int new_ ) {
          if ( new_ > old_ && new_ == 1 )
            damage->base_multiplier = 1.0 + effect.driver()->effectN( 1 ).percent();
          if ( new_ == 0 )
            damage->base_multiplier = 1.0;
        } );
      }
    }
  } );
}
}  // namespace sets

namespace singing_citrines
{
enum singing_citrines_drivers_e
{
  CITRINE_DRIVER_NONE = 0,
  // Thunder
  STORM_SEWERS_CITRINE           = 462532,  // Absorb
  ROARING_WARQUEENS_CITRINE      = 462526,  // Trigger 4 Nearby Ally Singing Thunder Citrines
  STORMBRINGERS_RUNED_CITRINE    = 462536,  // Equal Secondary Stat Split
  THUNDERLORDS_CRACKLING_CITRINE = 462540,  // ST Damage Proc

  // Sea
  MARINERS_HALLOWED_CITRINE    = 462530,  // NYI - Heal ally, jumps to 2 nearby.
  SEABED_LEVIATHANS_CITRINE    = 462527,  // Stamina & Size increase. At >80% HP attacks take dmg.
  FATHOMDWELLERS_RUNED_CITRINE = 462535,  // Mastery stat. All (?) other effects increased based on mastery.
  UNDERSEA_OVERSEERS_CITRINE   = 462538,  // Damage, jumps to 2 nearby.

  // Wind
  OLD_SALTS_BARDIC_CITRINE   = 462531,  // NYI - Heal 5t AOE
  LEGENDARY_SKIPPERS_CITRINE = 462528,  // Random other gem, 150% effect.
  WINDSINGERS_RUNED_CITRINE  = 462534,  // Highest Secondary Stat
  SQUALL_SAILORS_CITRINE     = 462539,  // Damage 5t AOE

  // Ring Driver
  CYRCES_CIRCLET =
      462342  // The ring itself. Never implemented and not a stone. Easier to reference for setting up stones.
};

enum singing_citrine_type_e
{
  CITRINE_TYPE_NONE = 0,
  CITRINE_TYPE_DAMAGE,
  CITRINE_TYPE_HEAL,
  CITRINE_TYPE_ABSORB,
  CITRINE_TYPE_STAT,
  CITRINE_TYPE_OTHER
};

singing_citrine_type_e get_singing_citrine_type( unsigned driver )
{
  switch ( driver )
  {
    case THUNDERLORDS_CRACKLING_CITRINE:
    case UNDERSEA_OVERSEERS_CITRINE:
    case SQUALL_SAILORS_CITRINE:
      return CITRINE_TYPE_DAMAGE;
    case MARINERS_HALLOWED_CITRINE:
    case OLD_SALTS_BARDIC_CITRINE:
      return CITRINE_TYPE_HEAL;
    case STORM_SEWERS_CITRINE:
      return CITRINE_TYPE_ABSORB;
    case STORMBRINGERS_RUNED_CITRINE:
    case FATHOMDWELLERS_RUNED_CITRINE:
    case SEABED_LEVIATHANS_CITRINE:
      return CITRINE_TYPE_STAT;
    case WINDSINGERS_RUNED_CITRINE:
    case LEGENDARY_SKIPPERS_CITRINE:
    case ROARING_WARQUEENS_CITRINE:
      return CITRINE_TYPE_OTHER;
    default:
      break;
  }

  return CITRINE_TYPE_NONE;
}

action_t* find_citrine_action( player_t* player, unsigned driver )
{
  switch ( driver )
  {
    // damage stones
    case THUNDERLORDS_CRACKLING_CITRINE:
      return player->find_action( "thunderlords_crackling_citrine" );
    case UNDERSEA_OVERSEERS_CITRINE:
      return player->find_action( "undersea_overseers_citrine" );
    case SQUALL_SAILORS_CITRINE:
      return player->find_action( "squall_sailors_citrine" );

    // healing stones
    case MARINERS_HALLOWED_CITRINE:
      return player->find_action( "mariners_hallowed_citrine" );
    case OLD_SALTS_BARDIC_CITRINE:
      return player->find_action( "old_salts_bardic_citrine" );

    // absorb stones
    case STORM_SEWERS_CITRINE:
      return player->find_action( "storm_sewers_citrine" );

    // Stat Stones
    case STORMBRINGERS_RUNED_CITRINE:
      return nullptr;
    case FATHOMDWELLERS_RUNED_CITRINE:
      return nullptr;
    case WINDSINGERS_RUNED_CITRINE:
      return player->find_action( "windsingers_runed_citrine_proc" );

    // other
    case ROARING_WARQUEENS_CITRINE:
      return player->find_action( "roaring_warqueens_citrine" );
    case LEGENDARY_SKIPPERS_CITRINE:
      return nullptr;
    case SEABED_LEVIATHANS_CITRINE:
      return player->find_action( "seabed_leviathans_citrine" );

    default:
      break;
  }

  return nullptr;
}

buff_t* find_citrine_proc_buff( player_t* player, unsigned driver )
{
  if ( get_singing_citrine_type( driver ) != CITRINE_TYPE_STAT )
    return nullptr;

  switch ( driver )
  {
    case STORMBRINGERS_RUNED_CITRINE:
      return buff_t::find( player, "stormbringers_runed_citrine_proc", player );
    case FATHOMDWELLERS_RUNED_CITRINE:
      return buff_t::find( player, "fathomdwellers_runed_citrine_proc", player );
    case SEABED_LEVIATHANS_CITRINE:
      return buff_t::find( player, "seabed_leviathans_citrine_proc", player );

    default:
      break;
  }

  return nullptr;
}

// TODO: Convert this to a better way I was tired when I did this.
struct stat_buff_current_value_t : stat_buff_t
{
  bool has_fathomdwellers;
  bool skipper_proc;
  double skipper_mult;
  bool queen_proc;
  bool is_proc;
  double proc_mult;

  stat_buff_current_value_t( actor_pair_t q, util::string_view name, const spell_data_t* s,
                             const item_t* item = nullptr )
    : stat_buff_t( q, name, s, item ),
      has_fathomdwellers( find_special_effect(
          player, FATHOMDWELLERS_RUNED_CITRINE ) ),  // By default, initialise this to the status. If it does not apply
                                                     // to current buff then after creation flag false.
      skipper_proc( false ),
      skipper_mult( 0 ),
      queen_proc( false ),
      is_proc( false ),
      proc_mult( 1.3 )
  {
    skipper_mult = player->find_spell( LEGENDARY_SKIPPERS_CITRINE )->effectN( 3 ).percent();
    // Stat procs dont update their value unless bumped, so only recalculate passive buffs.
    // Seems to have a heartbeat update, likely the same 5.25s heartbeat as usual. Tested with Ovinax movement buff
    // changing stack values. Last tested 19-12-2024.
    if ( data().duration() == timespan_t::zero() )
      player->sim->register_heartbeat_event_callback( [ & ]( sim_t* ) { force_recalculate(); } );
  }

  double get_buff_size()
  {
    double amount = default_value;

    if ( has_fathomdwellers )
      amount *= 1.0 + ( source->apply_combat_rating_dr(
      RATING_MASTERY, source->composite_mastery_rating() / source->current.rating.mastery ) ) /
      240;
    if ( skipper_proc )
      amount *= skipper_mult;
    // Windsingers Mastery proc doesnt seem to be affected by this... for reasons?
    if (  is_proc &&
      ( ( data().id() == 465963 && util::highest_stat( source, secondary_ratings ) != STAT_MASTERY_RATING ) ||
        data().id() != 465963 ) )
    {
      amount *= proc_mult;
    }

    return amount;
  }

  void force_recalculate()
  {
    double value = get_buff_size();
    for ( auto& buff_stat : stats )
    {
      if ( buff_stat.check_func && !buff_stat.check_func( *this ) )
        continue;

      buff_stat.amount = value;

      double delta = buff_stat_stack_amount( buff_stat, current_stack ) - buff_stat.current_value;
      if ( delta > 0 )
      {
        player->stat_gain( buff_stat.stat, delta, stat_gain, nullptr, buff_duration() > timespan_t::zero() );
      }
      else if ( delta < 0 )
      {
        player->stat_loss( buff_stat.stat, std::fabs( delta ), stat_gain, nullptr,
                           buff_duration() > timespan_t::zero() );
      }

      buff_stat.current_value += delta;
    }
  }

  void start( int stacks, double, timespan_t duration ) override
  {
    if ( skipper_proc || queen_proc )
      is_proc = true;
    else
      is_proc = false;
    buff_t::start( stacks, get_buff_size(), duration );
    if ( skipper_proc || queen_proc )
      skipper_proc = queen_proc = false;
  }

  void reset() override
  {
    buff_t::reset();
    skipper_proc = false;
  }

  void bump( int stacks, double value ) override
  {
    buff_t::bump( stacks, value );
    force_recalculate();
  }
};

template <typename BASE>
struct citrine_base_t : public BASE
{
  bool has_fathomdwellers;
  const spell_data_t* cyrce_driver;

  template <typename... ARGS>
  citrine_base_t( const special_effect_t& effect, ARGS&&... args )
    : BASE( std::forward<ARGS>( args )... ),
      has_fathomdwellers( find_special_effect( effect.player, FATHOMDWELLERS_RUNED_CITRINE ) ),
      cyrce_driver( effect.player->find_spell( CYRCES_CIRCLET ) )
  {
    BASE::background = true;
  }

  double action_multiplier() const override
  {
    double m = BASE::action_multiplier();

    if ( has_fathomdwellers )
    {
      // Seems to only use gear rating
      m *= 1.0 + ( BASE::player->apply_combat_rating_dr(
        RATING_MASTERY, BASE::player->composite_mastery_rating() / BASE::player->current.rating.mastery ) ) /
        120;
    }

    return m;
  }
};

struct damage_citrine_t : citrine_base_t<generic_proc_t>
{
  const spell_data_t* driver_spell;

  damage_citrine_t( const special_effect_t& e, std::string_view name, unsigned spell, singing_citrines_drivers_e scd )
    : citrine_base_t( e, e, name, spell ), driver_spell( e.player->find_spell( scd ) )
  {
    // TODO: Confirm bug behaviour
    // Currently the role multiplier of damaging citrines does not appear to be applying. Tested Discipline Priest and
    // Holy Priest 13/12/2024.
    if ( has_role_mult( e.player, driver_spell ) )
      this->base_multiplier *= role_mult( e.player, driver_spell );
  }

  void execute() override
  {
    if ( !target->is_enemy() )
    {
      target_cache.is_valid = false;
      target                = rng().range( target_list() );
    }

    citrine_base_t::execute();
  }
};

struct heal_citrine_t : citrine_base_t<generic_heal_t>
{
  const spell_data_t* driver_spell;
  heal_citrine_t( const special_effect_t& e, std::string_view name, unsigned spell, singing_citrines_drivers_e scd )
    : citrine_base_t( e, e, name, spell ), driver_spell( e.player->find_spell( scd ) )
  {
    if ( has_role_mult( e.player, driver_spell ) )
      this->base_multiplier *= role_mult( e.player, driver_spell );
  }

  void execute() override
  {
    if ( target->is_enemy() )
    {
      target                = player;
      target_cache.is_valid = false;
      target = rng().range( target_list() );
    }

    citrine_base_t::execute();
  }
};

struct absorb_citrine_t : citrine_base_t<absorb_t>
{
  const spell_data_t* driver_spell;
  absorb_citrine_t( const special_effect_t& e, std::string_view name, unsigned spell, singing_citrines_drivers_e scd )
    : citrine_base_t( e, name, e.player, e.player->find_spell( spell ) ), driver_spell( e.player->find_spell( scd ) )
  {
    if ( has_role_mult( e.player, driver_spell ) )
      this->base_multiplier *= role_mult( e.player, driver_spell );
  }
  void execute() override
  {
    if ( target->is_enemy() )
    {
      target                = player;
      target_cache.is_valid = false;
      target                = rng().range( target_list() );
    }

    citrine_base_t::execute();
  }

  absorb_buff_t* create_buff( const action_state_t* s ) override
  {
    absorb_buff_t* b = absorb_t::create_buff( s );

    if ( s->target->is_pet() )
      b->set_quiet( true );

    return b;
  }
};

struct thunderlords_crackling_citrine_t : public damage_citrine_t
{
  thunderlords_crackling_citrine_t( const special_effect_t& e )
    : damage_citrine_t( e, "thunderlords_crackling_citrine", 462951, THUNDERLORDS_CRACKLING_CITRINE )
  {
    base_dd_min = base_dd_max = driver_spell->effectN( 1 ).average( e ) * cyrce_driver->effectN( 3 ).percent();
  }
};

struct undersea_overseers_citrine_t : public damage_citrine_t
{
  undersea_overseers_citrine_t( const special_effect_t& e )
    : damage_citrine_t( e, "undersea_overseers_citrine", 462953, UNDERSEA_OVERSEERS_CITRINE )
  {
    base_dd_min = base_dd_max = driver_spell->effectN( 1 ).average( e ) * cyrce_driver->effectN( 3 ).percent();
  }
};

struct squall_sailors_citrine_t : public damage_citrine_t
{
  squall_sailors_citrine_t( const special_effect_t& e )
    : damage_citrine_t( e, "squall_sailors_citrine", 462952, SQUALL_SAILORS_CITRINE )
  {
    base_dd_min = base_dd_max = driver_spell->effectN( 1 ).average( e ) * cyrce_driver->effectN( 3 ).percent();
  }
};

struct seabed_leviathans_citrine_t : public damage_citrine_t
{
  seabed_leviathans_citrine_t( const special_effect_t& e )
    : damage_citrine_t( e, "seabed_leviathans_citrine", 468990, SEABED_LEVIATHANS_CITRINE )
  {
    base_dd_min = base_dd_max = driver_spell->effectN( 1 ).average( e ) * cyrce_driver->effectN( 3 ).percent();
  }
};

struct mariners_hallowed_citrine_t : public heal_citrine_t
{
  mariners_hallowed_citrine_t( const special_effect_t& e )
    : heal_citrine_t( e, "mariners_hallowed_citrine", 462960, MARINERS_HALLOWED_CITRINE )
  {
    base_dd_min = base_dd_max = driver_spell->effectN( 1 ).average( e ) * cyrce_driver->effectN( 3 ).percent();
  }
};

struct old_salts_bardic_citrine_t : public heal_citrine_t
{
  old_salts_bardic_citrine_t( const special_effect_t& e )
    : heal_citrine_t( e, "old_salts_bardic_citrine", 462959, OLD_SALTS_BARDIC_CITRINE )
  {
    base_td = driver_spell->effectN( 1 ).average( e ) * cyrce_driver->effectN( 3 ).percent() / 6;
  }
};

struct storm_sewers_citrine_t : public absorb_citrine_t
{
  struct storm_sewers_citrine_damage_t : public spell_t
  {
    storm_sewers_citrine_damage_t( player_t* p ) : spell_t( "storm_sewers_citrine_damage", p, p->find_spell( 468422 ) )
    {
      name_str_reporting = "storm_sewers_citrine";
    }
  };

  action_t* damage;
  storm_sewers_citrine_t( const special_effect_t& e )
    : absorb_citrine_t( e, "storm_sewers_citrine", 462958, STORM_SEWERS_CITRINE )
  {
    base_dd_min = base_dd_max = cyrce_driver->effectN( 1 ).average( e ) * driver_spell->effectN( 2 ).percent();
    damage = new storm_sewers_citrine_damage_t( e.player );
  }

  void impact( action_state_t* s )
  {
    absorb_citrine_t::impact( s );

    // Always execute the damage portion because normal sims do not have damage events to break the absorb shield.
    if ( result_is_hit( s->result ) )
    {
      player_t* potential_target = s->action->player->target;
      if ( !potential_target || !potential_target->is_enemy() || potential_target->is_sleeping() )
      {
        for ( auto* t : s->action->player->sim->target_non_sleeping_list )
        {
          if ( !t->is_enemy() || t->is_sleeping() )
            continue;

          potential_target = t;
          break;
        }
      }
      if ( potential_target && potential_target->is_enemy() && !potential_target->is_sleeping() && !potential_target->is_pet() )
      {
        damage->execute_on_target( potential_target, s->result_amount * driver_spell->effectN( 3 ).percent() );
      }
    }
  }
};

action_t* create_citrine_action( const special_effect_t& effect, singing_citrines_drivers_e driver );

struct roaring_warqueen_citrine_t : public spell_t
{
  static constexpr std::array<singing_citrines_drivers_e, 3> CITRINE_DRIVERS = {
      STORM_SEWERS_CITRINE, STORMBRINGERS_RUNED_CITRINE, THUNDERLORDS_CRACKLING_CITRINE };

  enum gem_type_t
  {
    NONE = 0,
    ACTION,
    BUFF
  };

  struct citrine_data_t
  {
    gem_type_t gem_type             = gem_type_t::NONE;
    action_t* action                = nullptr;
    stat_buff_current_value_t* buff = nullptr;

    citrine_data_t()
    {
    }
  };

  target_specific_t<citrine_data_t> citrine_data;
  bool estimate_group_value;
  action_t* thunder_gem;

  roaring_warqueen_citrine_t( const special_effect_t& e )
    : spell_t( "roaring_warqueens_citrine", e.player, e.player->find_spell( 462964 ) ),
      citrine_data{ true },
      estimate_group_value( false ),
      thunder_gem( create_citrine_action( e, THUNDERLORDS_CRACKLING_CITRINE ) )
  {
    background = true;
    aoe        = as<int>( e.player->find_spell( ROARING_WARQUEENS_CITRINE )->effectN( 2 ).base_value() );

    setup_ally_gem( player );
  }

  void setup_ally_gem( player_t* t )
  {
    if ( citrine_data[ t ] )
      return;

    if ( t->is_pet() || t->is_enemy() )
      return;

    citrine_data[ t ] = new citrine_data_t();

    special_effect_t* circlet = unique_gear::find_special_effect( t, CYRCES_CIRCLET );
    if ( !circlet )
      return;

    singing_citrines_drivers_e citrine = CITRINE_DRIVER_NONE;
    for ( auto& d : CITRINE_DRIVERS )
    {
      if ( unique_gear::find_special_effect( t, d ) )
      {
        citrine = d;
        break;
      }
    }

    if ( citrine == CITRINE_DRIVER_NONE || citrine == ROARING_WARQUEENS_CITRINE )
      return;

    if ( auto proc_buff = find_citrine_proc_buff( t, citrine ) )
    {
      auto buff                   = debug_cast<stat_buff_current_value_t*>( proc_buff );
      citrine_data[ t ]->gem_type = gem_type_t::BUFF;
      citrine_data[ t ]->buff     = buff;
      return;
    }

    if ( auto proc_action = find_citrine_action( t, citrine ) )
    {
      citrine_data[ t ]->gem_type = gem_type_t::ACTION;
      citrine_data[ t ]->action   = proc_action;
    }
  }

  void activate() override
  {
    if ( !estimate_group_value && !sim->single_actor_batch )
    {
      sim->player_no_pet_list.register_callback( [ this ]( player_t* t ) { setup_ally_gem( t ); } );

      for ( const auto& t : sim->player_no_pet_list )
      {
        setup_ally_gem( t );
      }
    }
  }

  void trigger_ally_gem( player_t* t, bool trigger_own = false )
  {
    if ( t->is_sleeping() || ( target == player && !trigger_own ) )
      return;

    if ( !citrine_data[ t ] )
      setup_ally_gem( t );

    switch ( citrine_data[ t ]->gem_type )
    {
      case gem_type_t::ACTION:
        assert( citrine_data[ t ]->action && "There must be a valid action pointer if the gem type is set to ACTION" );
        citrine_data[ t ]->action->execute();
        break;
      case gem_type_t::BUFF:
        assert( citrine_data[ t ]->buff && "There must be a valid buff pointer if the gem type is set to BUFF" );
        citrine_data[ t ]->buff->queen_proc = true;
        citrine_data[ t ]->buff->trigger();
        break;
      default:
        break;
    }
  }

  size_t available_targets( std::vector<player_t*>& target_list ) const override
  {
    target_list.clear();

    if ( estimate_group_value )
    {
      int _n_targets = aoe > 0 ? aoe : 4;
      for ( int i = 0; i < _n_targets; i++ )
      {
        target_list.push_back( player );
      }
    }
    else
    {
      for ( const auto& t : sim->player_no_pet_list )
      {
        if ( t->is_sleeping() )
          continue;

        if ( !citrine_data[ t ] || citrine_data[ t ]->gem_type == gem_type_t::NONE || t == player )
        {
          continue;
        }

        target_list.push_back( t );
      }
    }

    return target_list.size();
  }

  void impact( action_state_t* s ) override
  {
    spell_t::impact( s );

    if ( s->target != player || s->chain_target == 0 )
    {
      trigger_ally_gem( s->target, estimate_group_value );
    }

    if ( s->target == player && ( s->chain_target > 0 || citrine_data[ player ]->gem_type == gem_type_t::NONE ) )
    {
      thunder_gem->execute();
    }
  }

  void execute() override
  {
    if ( target_list().size() == 0 )
    {
      // We have no targets at all. Free state(s) and abandon ship.
      if ( pre_execute_state )
      {
        action_state_t::release( pre_execute_state );
      }
      if ( execute_state )
      {
        action_state_t::release( execute_state );
      }
      return;
    }

    rng().shuffle( target_list().begin(), target_list().end() );
    target = *target_list().begin();

    spell_t::execute();
  }
};

// Proxy action just to trigger the highest stat buff. Mostly for reporting purposes.
// Might be a better way to do this, but this will do for now.
struct windsingers_runed_citrine_proc_t : public generic_proc_t
{
  std::unordered_map<stat_e, buff_t*> buffs;
  windsingers_runed_citrine_proc_t( const special_effect_t& e )
    : generic_proc_t( e, "windsingers_runed_citrine_proc", WINDSINGERS_RUNED_CITRINE ), buffs()
  {
    background = true;
    harmful = false;
    const spell_data_t* buff_driver = e.player->find_spell( WINDSINGERS_RUNED_CITRINE );
    const spell_data_t* buff_spell = e.player->find_spell( 465963 );
    const spell_data_t* cyrce_driver = e.player->find_spell( CYRCES_CIRCLET );
    double stat_value = buff_driver->effectN( 1 ).average( e ) * cyrce_driver->effectN( 5 ).percent() / 3;

    create_all_stat_buffs<stat_buff_current_value_t>( e, buff_spell, stat_value,
                                                      [ &, stat_value ]( stat_e s, buff_t* b )
                                                      {
                                                        b->default_value = stat_value;
                                                        b->name_str_reporting = fmt::format( "{}_{}", b->name_str, "proc");
                                                        buffs[ s ] = b;
                                                      } );
  }

  void execute() override
  {
    generic_proc_t::execute();
    // Ensure only one instance of Windsingers proc buff can be up at any time.
    for ( auto& b : buffs )
    {
      if ( b.first == util::highest_stat( player, secondary_ratings ) )
      {
        debug_cast<stat_buff_current_value_t*>( b.second )->skipper_proc = true;
        b.second->trigger();
      }
      else
        b.second->expire();
    }
  }
};

action_t* create_citrine_action( const special_effect_t& effect, singing_citrines_drivers_e driver )
{
  action_t* action = find_citrine_action( effect.player, driver );
  if ( action )
  {
    return action;
  }

  switch ( driver )
  {
    // damage stones
    case THUNDERLORDS_CRACKLING_CITRINE:
      return new thunderlords_crackling_citrine_t( effect );
    case UNDERSEA_OVERSEERS_CITRINE:
      return new undersea_overseers_citrine_t( effect );
    case SQUALL_SAILORS_CITRINE:
      return new squall_sailors_citrine_t( effect );

    // healing stones
    case MARINERS_HALLOWED_CITRINE:
      return new mariners_hallowed_citrine_t( effect );
    case OLD_SALTS_BARDIC_CITRINE:
      return new old_salts_bardic_citrine_t( effect );

    // absorb stones
    case STORM_SEWERS_CITRINE:
      return new storm_sewers_citrine_t( effect );

    // Stat Stones
    case STORMBRINGERS_RUNED_CITRINE:
      return nullptr;
    case FATHOMDWELLERS_RUNED_CITRINE:
      return nullptr;
    case WINDSINGERS_RUNED_CITRINE:
      return new windsingers_runed_citrine_proc_t( effect );

    // other
    case ROARING_WARQUEENS_CITRINE:
      return new roaring_warqueen_citrine_t( effect );
    case LEGENDARY_SKIPPERS_CITRINE:
      return nullptr;
    case SEABED_LEVIATHANS_CITRINE:
      return new seabed_leviathans_citrine_t( effect );

    default:
      break;
  }

  return nullptr;
}

struct seabed_leviathans_citrine_proc_buff_t : stat_buff_current_value_t
{
  seabed_leviathans_citrine_proc_buff_t( player_t* p, const special_effect_t& effect )
    : stat_buff_current_value_t( p, "seabed_leviathans_citrine_proc", p->find_spell( 462963 ), effect.item )
  {
    const spell_data_t* cyrce_driver = effect.player->find_spell( CYRCES_CIRCLET );
    auto buff_driver                 = effect.player->find_spell( SEABED_LEVIATHANS_CITRINE );
    double stat_value = buff_driver->effectN( 1 ).average( effect ) * cyrce_driver->effectN( 5 ).percent() / 3;

    default_value = stat_value;

    add_stat_from_effect_type( A_MOD_STAT, stat_value );

    auto damage_action     = create_citrine_action( effect, SEABED_LEVIATHANS_CITRINE );
    auto hp_threshhold     = buff_driver->effectN( 6 ).base_value();
    auto proc_spell        = effect.player->find_spell( 462963 );
    auto damage            = new special_effect_t( p );
    damage->name_str       = "seabed_leviathans_citrine_proc";
    damage->item           = effect.item;
    damage->spell_id       = proc_spell->id();
    damage->proc_flags_    = PF_ALL_DAMAGE_TAKEN;
    damage->proc_flags2_   = PF2_ALL_HIT;
    damage->proc_chance_   = 1.0;
    damage->execute_action = damage_action;
    effect.player->special_effects.push_back( damage );

    effect.player->callbacks.register_callback_trigger_function(
        proc_spell->id(), dbc_proc_callback_t::trigger_fn_type::CONDITION,
        [ &, hp_threshhold ]( auto, const auto&, auto, auto, auto ) {
          return effect.player->health_percentage() > hp_threshhold;
        } );

    auto damage_cb = new dbc_proc_callback_t( p, *damage );
    damage_cb->activate_with_buff( this, true );
  }
};

buff_t* create_citrine_proc_buff( const special_effect_t& effect, singing_citrines_drivers_e driver )
{
  if ( get_singing_citrine_type( driver ) != CITRINE_TYPE_STAT )
    return nullptr;

  buff_t* action = find_citrine_proc_buff( effect.player, driver );
  if ( action )
  {
    return action;
  }

  switch ( driver )
  {
    case STORMBRINGERS_RUNED_CITRINE:
    {
      const spell_data_t* buff_driver  = effect.player->find_spell( driver );
      const spell_data_t* buff_spell   = effect.player->find_spell( 465961 );
      const spell_data_t* cyrce_driver = effect.player->find_spell( CYRCES_CIRCLET );
      double stat_value = buff_driver->effectN( 1 ).average( effect ) * cyrce_driver->effectN( 5 ).percent() / 3;

      buff_t* buff =
          create_buff<stat_buff_current_value_t>( effect.player, "stormbringers_runed_citrine_proc", buff_spell )
              ->add_stat_from_effect( 1, stat_value )
              ->set_default_value( stat_value );
      return buff;
    }
    case FATHOMDWELLERS_RUNED_CITRINE:
    {
      const spell_data_t* buff_driver  = effect.player->find_spell( driver );
      const spell_data_t* buff_spell   = effect.player->find_spell( 465962 );
      const spell_data_t* cyrce_driver = effect.player->find_spell( CYRCES_CIRCLET );
      double stat_value = buff_driver->effectN( 1 ).average( effect ) * cyrce_driver->effectN( 5 ).percent() / 3;

      buff_t* buff =
          create_buff<stat_buff_current_value_t>( effect.player, "fathomdwellers_runed_citrine_proc", buff_spell )
              ->add_stat_from_effect( 1, stat_value )
              ->set_default_value( stat_value );

      return buff;
    }
    case SEABED_LEVIATHANS_CITRINE:
      return new seabed_leviathans_citrine_proc_buff_t( effect.player, effect );
    default:
      break;
  }

  return nullptr;
}

/** Thunderlords Crackling Citrine
 * id=462342 Ring Driver
 * id=462540 Driver
 * id=462951 Damage
 */
void thunderlords_crackling_citrine( special_effect_t& effect )
{
  effect.execute_action = create_citrine_action( effect, THUNDERLORDS_CRACKLING_CITRINE );

  new dbc_proc_callback_t( effect.player, effect );
}

/** Squall Sailors Citrine
 * id=462342 Ring Driver
 * id=462539 Driver
 * id=462952 Damage
 */
void squall_sailors_citrine( special_effect_t& effect )
{
  effect.execute_action = create_citrine_action( effect, SQUALL_SAILORS_CITRINE );

  new dbc_proc_callback_t( effect.player, effect );
}

/** Undersea Overseers Citrine
 * id=462342 Ring Driver
 * id=462538 Driver
 * id=462953 Damage
 */
void undersea_overseers_citrine( special_effect_t& effect )
{
  effect.execute_action = create_citrine_action( effect, UNDERSEA_OVERSEERS_CITRINE );

  new dbc_proc_callback_t( effect.player, effect );
}
/** Storm Sewers Citrine
 * id=462342 Ring Driver
 * id=462530 Driver
 * id=462960 Heal
 */
void mariners_hallowed_citrine( special_effect_t& effect )
{
  effect.execute_action = create_citrine_action( effect, MARINERS_HALLOWED_CITRINE );

  new dbc_proc_callback_t( effect.player, effect );
}

/**  Old Salts Bardic Citrine
 * id=462342 Ring Driver
 * id=462531 Driver
 * id=462959 Heal
 */
void old_salts_bardic_citrine( special_effect_t& effect )
{
  effect.execute_action = create_citrine_action( effect, OLD_SALTS_BARDIC_CITRINE );

  new dbc_proc_callback_t( effect.player, effect );
}

/** Storm Sewers Citrine
 * id=462342 Ring Driver
 * id=462532 Driver
 * id=462958 Absorb
 * id=468422 Damage
 */
void storm_sewers_citrine( special_effect_t& effect )
{
  effect.execute_action = create_citrine_action( effect, STORM_SEWERS_CITRINE );

  new dbc_proc_callback_t( effect.player, effect );
}

/** Windsingers Runed Citrine
 * id=462342 Ring Driver
 * id=462534 Driver
 * id=465963 Proc Buff
 */
void windsingers_runed_citrine( special_effect_t& effect )
{
  auto cyrce_driver = effect.player->find_spell( CYRCES_CIRCLET );
  auto stat_value   = effect.driver()->effectN( 1 ).average( effect ) * cyrce_driver->effectN( 5 ).percent() / 3;

  std::unordered_map<stat_e, buff_t*> buffs;

  create_all_stat_buffs<stat_buff_current_value_t>( effect, effect.driver(), stat_value,
                                                    [ &buffs, stat_value ]( stat_e s, buff_t* b ) {
                                                      b->default_value = stat_value;
                                                      buffs[ s ]       = b;
                                                    } );

  // Windsinger does not update its given passive stat if the highest stat changes as of 19-12-2024.
  const auto& desired_stat = effect.player->thewarwithin_opts.windsingers_passive_stat;
  stat_e stat              = STAT_NONE;
  if ( util::str_compare_ci( desired_stat, "haste" ) )
    stat = STAT_HASTE_RATING;

  if ( util::str_compare_ci( desired_stat, "mastery" ) )
    stat = STAT_MASTERY_RATING;

  if ( util::str_compare_ci( desired_stat, "critical_strike" ) || util::str_compare_ci( desired_stat, "crit" ) )
    stat = STAT_CRIT_RATING;

  if ( util::str_compare_ci( desired_stat, "versatility" ) || util::str_compare_ci( desired_stat, "vers" ) )
    stat = STAT_VERSATILITY_RATING;

  if ( stat != STAT_NONE )
    effect.player->register_on_arise_callback( effect.player, [ buffs, stat ] { buffs.at( stat )->trigger(); } );
  else
    effect.player->register_on_arise_callback( effect.player, [ &, buffs ] {
      buffs.at( util::highest_stat( effect.player, secondary_ratings ) )->trigger();
    } );
}

/** Fathomdwellers Runed Citrine
 * id=462342 Ring Driver
 * id=462535 Driver
 * id=465962 Proc Buff
 */
void fathomdwellers_runed_citrine( special_effect_t& effect )
{
  auto cyrce_driver = effect.player->find_spell( CYRCES_CIRCLET );
  auto stat_value   = effect.driver()->effectN( 1 ).average( effect ) * cyrce_driver->effectN( 5 ).percent() / 3;

  auto buff = create_buff<stat_buff_t>( effect.player, "fathomdwellers_runed_citrine", effect.driver() )
                  ->add_stat_from_effect( 1, stat_value );

  effect.player->register_on_arise_callback( effect.player, [ buff ] { buff->trigger(); } );
}

void legendary_skippers_citrine( special_effect_t& effect )
{
  static constexpr std::array<singing_citrines_drivers_e, 11> possible_stones = {
      // DAMAGE
      THUNDERLORDS_CRACKLING_CITRINE,
      UNDERSEA_OVERSEERS_CITRINE,
      SQUALL_SAILORS_CITRINE,

      // Stats
      STORMBRINGERS_RUNED_CITRINE,
      FATHOMDWELLERS_RUNED_CITRINE,
      WINDSINGERS_RUNED_CITRINE,
      SEABED_LEVIATHANS_CITRINE,

      // Absorb
      STORM_SEWERS_CITRINE,

      // Heal
      MARINERS_HALLOWED_CITRINE,
      OLD_SALTS_BARDIC_CITRINE

      // Ally Trigger
      //ROARING_WARQUEENS_CITRINE

      // Itself
      // LEGENDARY_SKIPPERS_CITRINE,
  };

  struct legendary_skippers_citrine_t : public spell_t
  {
    std::vector<action_t*> citrine_actions;
    std::vector<buff_t*> citrine_buffs;
    double multiplier;
    int wq_targets;

    legendary_skippers_citrine_t( const special_effect_t& effect )
      : spell_t( "legendary_skippers_citrine", effect.player, effect.player->find_spell( 462962 ) ),
        citrine_actions(),
        citrine_buffs(),
        multiplier(),
        wq_targets( as<int>( effect.player->find_spell( ROARING_WARQUEENS_CITRINE )->effectN( 2 ).base_value() ) )
    {
      background = true;

      multiplier  = effect.player->find_spell( LEGENDARY_SKIPPERS_CITRINE )->effectN( 3 ).percent();

      for ( auto driver : possible_stones )
      {
        switch ( get_singing_citrine_type( driver ) )
        {
          case CITRINE_TYPE_STAT:
            citrine_buffs.push_back( create_citrine_proc_buff( effect, driver ) );
            break;
          default:
            citrine_actions.push_back( create_citrine_action( effect, driver ) );
            break;
        }
      }
    }

    void impact( action_state_t* s ) override
    {
      spell_t::impact( s );

      if ( result_is_hit( s->result ) )
      {
        auto ix = rng().range( citrine_actions.size() + citrine_buffs.size() );
        if ( ix < citrine_actions.size() )
        {
          if ( auto action = citrine_actions[ ix ] )
          {
              auto old_base = action->base_multiplier;
              action->base_multiplier *= multiplier;
              action->execute_on_target( s->target );
              action->base_multiplier = old_base;
          }
        }
        else
        {
          if ( auto buff = citrine_buffs[ ix - citrine_actions.size() ] )
          {
            debug_cast<stat_buff_current_value_t*>( buff )->skipper_proc = true;
            buff->trigger();
          }
        }
      }
    }
  };

  effect.execute_action = create_proc_action<legendary_skippers_citrine_t>( "legendary_skippers_citrine", effect );

  new dbc_proc_callback_t( effect.player, effect );
}


/** Stormbringers Runed Citrine
 * id=462342 Ring Driver
 * id=462536 Driver
 * id=465961 Proc Buff
 */
void stormbringers_runed_citrine( special_effect_t& effect )
{
  auto cyrce_driver = effect.player->find_spell( CYRCES_CIRCLET );
  auto stat_value = effect.driver()->effectN( 1 ).average( effect ) * cyrce_driver->effectN( 5 ).percent() / 3;

  auto buff = create_buff<stat_buff_current_value_t>( effect.player, "stormbringers_runed_citrine", effect.driver() )
                  ->add_stat_from_effect( 1, stat_value )
                  ->set_default_value( stat_value );

  // Always create stormbringers proc buff in case another player has Roaring Warqueen's Citrine
  create_citrine_proc_buff( effect, STORMBRINGERS_RUNED_CITRINE );
  effect.player->register_on_arise_callback( effect.player, [ buff ] { buff->trigger(); } );
}

/** Seabed Leviathan's Citrine
 * id=462342 Ring Driver
 * id=462527 Driver
 * id=462963 Proc Buff
 * id=468990 Damage
 */
void seabed_leviathans_citrine( special_effect_t& effect )
{
  auto damage = create_citrine_action( effect, SEABED_LEVIATHANS_CITRINE );
  // Manually setting the proc flags, Driver appears to use a 0 value absorb buff
  // to check for incoming damage, rather than traditional proc flags.
  effect.proc_flags_    = PF_ALL_DAMAGE_TAKEN;
  effect.proc_flags2_   = PF2_ALL_HIT;
  effect.proc_chance_   = 1.0;
  effect.execute_action = damage;

  effect.player->callbacks.register_callback_trigger_function(
      effect.spell_id, dbc_proc_callback_t::trigger_fn_type::CONDITION,
      [ & ]( auto, const auto&, auto, auto, auto ) {
        return effect.player->health_percentage() > effect.driver()->effectN( 6 ).base_value();
      } );

  new dbc_proc_callback_t( effect.player, effect );

  auto cyrce_driver = effect.player->find_spell( CYRCES_CIRCLET );
  auto stat_value   = effect.driver()->effectN( 1 ).average( effect ) * cyrce_driver->effectN( 5 ).percent() / 3;

  auto buff = create_buff<stat_buff_current_value_t>( effect.player, "seabed_leviathans_citrine", effect.driver() )
                  ->set_stat_from_effect_type( A_MOD_STAT, stat_value )
                  ->set_default_value( stat_value );

  effect.player->register_on_arise_callback( effect.player, [ buff ] { buff->trigger(); } );
}

void roaring_warqueens_citrine( special_effect_t& effect )
{
  effect.execute_action = create_citrine_action( effect, ROARING_WARQUEENS_CITRINE );

  new dbc_proc_callback_t( effect.player, effect );
}
}  // namespace singing_citrines

namespace durable_information_securing_chamber
{
enum titan_disc_effect_e
{
  TITAN_DISC_VALUE_SPELL = 1236137,
  CHARGED_BOLTS          = 1236109,
  CAUTERIZING_BOLTS      = 1236122,
  CRITICAL_CHAIN         = 1236272,
  SPARK_BURST            = 1236273,
  STATIC_CHARGE          = 1236275,
  CHARGED_TOUCH          = 1236277,
  ENERGY_SHIELD          = 1236278,
  CHARGED_CRYSTAL        = 1236279,
  ELECTRIC_CURRENT       = 1236961,
};

// Currently doesnt work in game, and is entirely untestable.
// Implementation is speculative and based on the spell data alone.
void charged_bolts( special_effect_t& effect )
{
  struct charged_bolts_t : public buff_t
  {
    action_t* damage;

    charged_bolts_t( player_t* player, std::string_view name, special_effect_t& effect, const spell_data_t* trigger )
      : buff_t( player, name, trigger ), damage( nullptr )
    {
      const spell_data_t* damage_spell_data  = trigger->effectN( 1 ).trigger();
      const spell_data_t* tooltip_spell_data = player->find_spell( 1241244 );
      const spell_data_t* value_spell_data   = player->find_spell( titan_disc_effect_e::TITAN_DISC_VALUE_SPELL );

      // Manually handled in bump since it triggers on refresh as well.
      set_tick_zero( false );
      set_refresh_behavior( buff_refresh_behavior::TICK );

      damage = create_proc_action<generic_proc_t>( util::tokenize_fn( damage_spell_data->name_cstr() ), effect,
                                                   damage_spell_data );
      damage->base_dd_min = damage->base_dd_max = value_spell_data->effectN( 1 ).average( effect );
      damage->base_multiplier *= role_mult( player, tooltip_spell_data );
    }

    void trigger_damage()
    {
      player_t* target = player->target;

      if ( sim->target_non_sleeping_list.size() > 1 )
        target = sim->target_non_sleeping_list[ rng().range( sim->target_non_sleeping_list.size() ) ];

      damage->execute_on_target( target );
    }

    void bump( int stacks, double val ) override
    {
      buff_t::bump( stacks, val );
      trigger_damage();
    }
  };

  const spell_data_t* driver  = effect.player->find_spell( titan_disc_effect_e::CHARGED_BOLTS );
  const spell_data_t* trigger = effect.player->find_spell( 1236110 );

  effect.name_str     = util::tokenize_fn( driver->name_cstr() );
  effect.proc_flags_  = driver->proc_flags();
  effect.proc_flags2_ = PF2_ALL_HIT;
  effect.ppm_         = driver->_rppm;
  effect.custom_buff = create_buff<charged_bolts_t>( effect.player, util::tokenize_fn( trigger->name_cstr() ), effect, trigger );

  new dbc_proc_callback_t( effect.player, effect );
}

void cauterizing_bolts( special_effect_t& )
{
  // NYI: Healing effect lol
}

void critical_chain( special_effect_t& effect )
{
  struct critical_overload_t : public buff_t
  {
    buff_t* stacking_crit;

    critical_overload_t( player_t* player, std::string_view name, const spell_data_t* spell_data,
                         const special_effect_t& effect )
      : buff_t( player, name, spell_data ), stacking_crit( nullptr )
    {
      const spell_data_t* stack_buff_data  = spell_data->effectN( 1 ).trigger();
      const spell_data_t* value_spell_data = player->find_spell( titan_disc_effect_e::TITAN_DISC_VALUE_SPELL );

      stacking_crit = create_buff<stat_buff_t>( player, stack_buff_data )
                          ->add_stat_from_effect_type( A_MOD_RATING, value_spell_data->effectN( 3 ).average( effect ) );

      quiet           = true;
      tick_callback   = [ & ]( buff_t*, int, timespan_t ) { stacking_crit->increment(); };
      expire_callback = [ & ]( buff_t*, int, timespan_t ) { stacking_crit->expire(); };
    }
  };

  const spell_data_t* driver       = effect.player->find_spell( titan_disc_effect_e::CRITICAL_CHAIN );
  const spell_data_t* trigger_buff = driver->effectN( 1 ).trigger();

  effect.name_str     = util::tokenize_fn( driver->name_cstr() );
  effect.proc_flags2_ = PF2_ALL_CAST;
  effect.ppm_         = driver->_rppm;
  effect.custom_buff =
      create_buff<critical_overload_t>( effect.player, util::tokenize_fn( driver->name_cstr() ), trigger_buff, effect );

  effect.player->callbacks.register_callback_trigger_function(
    effect.spell_id, dbc_proc_callback_t::trigger_fn_type::CONDITION,
    [ effect ]( auto, const auto&, auto, auto, auto )
    {
      return !effect.custom_buff->check();
    } );

  new dbc_proc_callback_t( effect.player, effect );
}

void spark_burst( special_effect_t& effect )
{
  const spell_data_t* driver      = effect.player->find_spell( titan_disc_effect_e::SPARK_BURST );
  const spell_data_t* stat_buff   = driver->effectN( 1 ).trigger();
  const spell_data_t* value_spell = effect.player->find_spell( titan_disc_effect_e::TITAN_DISC_VALUE_SPELL );

  effect.name_str     = util::tokenize_fn( driver->name_cstr() );
  effect.proc_flags2_ = PF2_ALL_CAST;
  effect.ppm_         = driver->_rppm;
  effect.custom_buff  = create_buff<stat_buff_t>( effect.player, util::tokenize_fn( driver->name_cstr() ), stat_buff )
                           ->add_stat_from_effect_type( A_MOD_RATING, value_spell->effectN( 4 ).average( effect ) );

  new dbc_proc_callback_t( effect.player, effect );
}

void static_charge( special_effect_t& effect )
{
  struct decrement_proc_callback_t : public dbc_proc_callback_t
  {
    buff_t* buff;

    decrement_proc_callback_t( player_t* player, const special_effect_t& effect, buff_t* buff )
      : dbc_proc_callback_t( player, effect ), buff( buff )
    {
      activate_with_buff( buff );
    }

    void execute( const spell_data_t*, player_t*, action_state_t* ) override
    {
      buff->decrement();
    }
  };

  const spell_data_t* driver      = effect.player->find_spell( titan_disc_effect_e::STATIC_CHARGE );
  const spell_data_t* stat_buff   = driver->effectN( 1 ).trigger();
  const spell_data_t* value_spell = effect.player->find_spell( titan_disc_effect_e::TITAN_DISC_VALUE_SPELL );

  effect.name_str     = util::tokenize_fn( driver->name_cstr() );
  effect.proc_flags2_ = PF2_ALL_CAST;
  effect.custom_buff  = create_buff<stat_buff_t>( effect.player, util::tokenize_fn( driver->name_cstr() ), stat_buff )
                           ->add_stat_from_effect_type( A_MOD_RATING, value_spell->effectN( 5 ).average( effect ) )
                           ->set_reverse( true )
                           ->set_reverse_stack_count( 1 );

  special_effect_t* decrement_stack = new special_effect_t( effect.player );
  decrement_stack->spell_id         = stat_buff->id();
  decrement_stack->name_str         = util::tokenize_fn( stat_buff->name_cstr() );
  decrement_stack->proc_flags2_     = PF2_ALL_HIT;
  decrement_stack->cooldown_        = stat_buff->internal_cooldown();
  effect.player->special_effects.push_back( decrement_stack );

  new dbc_proc_callback_t( effect.player, effect );
  new decrement_proc_callback_t( effect.player, *decrement_stack, effect.custom_buff );
}

void electric_current( special_effect_t& effect )
{
  /*
   * This is implementable strictly as a repeating `event_t`, but that introduces
   * a fair bit of complexity. Given that deriving from `buff_t` should be a bit
   * more clear, we'll just use that instead.
   */

  struct driver_buff_t : public buff_t
  {
    buff_t* child;
    int previous_stack;
    bool reverse;

    driver_buff_t( player_t* player, std::string_view name, special_effect_t& effect )
      : buff_t( player, name, spell_data_t::nil() ), child( nullptr ), previous_stack( 0 ), reverse( true )
    {
      const spell_data_t* driver      = effect.player->find_spell( titan_disc_effect_e::ELECTRIC_CURRENT );
      const spell_data_t* stat_buff   = effect.player->find_spell( 1236937 );
      const spell_data_t* value_spell = effect.player->find_spell( titan_disc_effect_e::TITAN_DISC_VALUE_SPELL );

      child = create_buff<stat_buff_t>( player, util::tokenize_fn( driver->name_cstr() ), stat_buff )
                  ->add_stat_from_effect_type( A_MOD_RATING, value_spell->effectN( 7 ).average( effect ) )
                  ->set_constant_behavior( buff_constant_behavior::NEVER_CONSTANT );

      quiet = true;
      set_period( driver->effectN( 1 ).period() );
      set_duration( 8_s );
      tick_on_application = true;

      tick_callback = [ & ]( buff_t* self, int, timespan_t ) {
        self->refresh();

        int current_stack = child->check();
        if ( current_stack == previous_stack )
          reverse = !reverse;

        if ( reverse && current_stack > 1 )
          child->decrement();

        if ( !reverse )
          child->increment();

        previous_stack = current_stack;
      };

      expire_callback = [ & ]( buff_t*, int, timespan_t ) { child->expire(); };
    }
  };

  effect.name_str    = "electric_current_driver";
  effect.custom_buff = create_buff<driver_buff_t>( effect.player, "electric_current_driver", effect );

  effect.player->register_on_combat_state_callback( [ & ]( player_t* player, bool in_combat ) {
    if ( player != effect.player )
      return;

    if ( in_combat )
      effect.custom_buff->trigger();
    else
      effect.custom_buff->expire();
  } );
}

void charged_touch( special_effect_t& )
{
  // NYI: Healing effect lol
}

void energy_shield( special_effect_t& effect )
{
  struct energy_shield_t : public absorb_t
  {
    action_t* energy_wave;
    double energy_wave_mod;
    energy_shield_t( std::string_view name, special_effect_t& effect )
      : absorb_t( name, effect.player, effect.player->find_spell( 1236993 ) ),
        energy_wave( nullptr ),
        energy_wave_mod( 0.0 )
    {
      const spell_data_t* value_spell = player->find_spell( titan_disc_effect_e::TITAN_DISC_VALUE_SPELL );
      base_dd_min = base_dd_max = value_spell->effectN( 11 ).average( effect );
      target                    = effect.player;
      background                = true;
      harmful                   = false;

      energy_wave =
          create_proc_action<generic_aoe_proc_t>( "energy_wave", effect, effect.player->find_spell( 1237011 ) );
      energy_wave_mod = value_spell->effectN( 12 ).percent();
    }

    absorb_buff_t* create_buff( const action_state_t* s ) override
    {
      auto b = absorb_t::create_buff( s );

      b->set_expire_callback( [ this ]( buff_t* b, int, timespan_t d ) {
        // Dont bother executing energy wave if the absorb is entirely consumed
        if ( d == timespan_t::zero() )
        {
          energy_wave->base_dd_min = energy_wave->base_dd_max = b->current_value * energy_wave_mod;
          energy_wave->execute();
        }
      } );

      return b;
    }
  };

  effect.execute_action = new energy_shield_t( util::tokenize_fn( effect.driver()->name_cstr() ), effect );
  new dbc_proc_callback_t( effect.player, effect );
}

void charged_crystal( special_effect_t& effect )
{
  const spell_data_t* driver      = effect.player->find_spell( titan_disc_effect_e::CHARGED_CRYSTAL );
  const spell_data_t* trigger     = driver->effectN( 1 ).trigger();
  const spell_data_t* value_spell = effect.player->find_spell( titan_disc_effect_e::TITAN_DISC_VALUE_SPELL );

  effect.name_str     = util::tokenize_fn( driver->name_cstr() );
  effect.proc_flags_  = driver->proc_flags();
  effect.proc_flags2_ = PF2_ALL_HIT;
  effect.ppm_         = driver->_rppm;
  effect.execute_action =
      create_proc_action<generic_aoe_proc_t>( util::tokenize_fn( trigger->name_cstr() ), effect, trigger, true );
  effect.execute_action->base_dd_min = effect.execute_action->base_dd_max =
      value_spell->effectN( 13 ).average( effect );
  effect.execute_action->base_multiplier *= role_mult( effect.player, effect.player->find_spell( 1241240 ) );

  new dbc_proc_callback_t( effect.player, effect );
}

void titan_disc_replaced_effect( special_effect_t& effect )
{
  effect.spell_id = effect.item->parsed.titan_disc_driver_id;

  switch ( effect.item->parsed.titan_disc_driver_id )
  {
    case CHARGED_BOLTS:
      charged_bolts( effect );
      break;
    case CAUTERIZING_BOLTS:
      cauterizing_bolts( effect );
      break;
    case CRITICAL_CHAIN:
      critical_chain( effect );
      break;
    case SPARK_BURST:
      spark_burst( effect );
      break;
    case STATIC_CHARGE:
      static_charge( effect );
      break;
    case CHARGED_TOUCH:
      charged_touch( effect );
      break;
    case ENERGY_SHIELD:
      energy_shield( effect );
      break;
    case CHARGED_CRYSTAL:
      charged_crystal( effect );
      break;
    case ELECTRIC_CURRENT:
      electric_current( effect );
      break;
    default:
      effect.spell_id = CHARGED_BOLTS;
      charged_bolts( effect );
      break;
  }
}

}  // namespace durable_information_securing_chamber

void register_special_effects()
{
  // NOTE: use unique_gear:: namespace for static consumables so we don't activate them with enable_all_item_effects
  // Food
  unique_gear::register_special_effect( 457302, consumables::selector_food( 461957, true ) );  // the sushi special
  unique_gear::register_special_effect( 455960, consumables::selector_food( 454137 /*Maybe Wrong Spell id, had to guess*/, false ) );  // everything stew
  unique_gear::register_special_effect( 454149, consumables::selector_food( 461957, true ) );  // beledar's bounty, empress' farewell, jester's board, outsider's provisions
  unique_gear::register_special_effect( 457282, consumables::selector_food( 461939, false, false ) );  // pan seared mycobloom, hallowfall chili, coreway kabob, flash fire fillet
  unique_gear::register_special_effect( 454087, consumables::selector_food( 461943, false, false ) );  // unseasoned field steak, roasted mycobloom, spongey scramble, skewered fillet, simple stew
  unique_gear::register_special_effect( 457283, consumables::primary_food( 457284, STAT_STR_AGI_INT, 2 ) );  // feast of the divine day
  unique_gear::register_special_effect( 457285, consumables::primary_food( 457284, STAT_STR_AGI_INT, 2 ) );  // feast of the midnight masquerade
  unique_gear::register_special_effect( 457294, consumables::primary_food( 461925, STAT_STRENGTH ) );  // sizzling honey roast
  unique_gear::register_special_effect( 457136, consumables::primary_food( 461924, STAT_AGILITY ) );  // mycobloom risotto
  unique_gear::register_special_effect( 457295, consumables::primary_food( 461922, STAT_INTELLECT ) );  // stuffed cave peppers
  unique_gear::register_special_effect( 457296, consumables::primary_food( 461927, STAT_STAMINA, 7 ) );  // angler's delight
  unique_gear::register_special_effect( 457298, consumables::primary_food( 461947, STAT_STRENGTH, 3, false ) );  // meat and potatoes
  unique_gear::register_special_effect( 457297, consumables::primary_food( 461948, STAT_AGILITY, 3, false ) );  // rib stickers
  unique_gear::register_special_effect( 457299, consumables::primary_food( 461949, STAT_INTELLECT, 3, false ) );  // sweet and sour meatballs
  unique_gear::register_special_effect( 457300, consumables::primary_food( 461946, STAT_STAMINA, 7, false ) );  // tender twilight jerky
  unique_gear::register_special_effect( 457286, consumables::secondary_food( 461861, STAT_HASTE_RATING ) );  // zesty nibblers
  unique_gear::register_special_effect( 456968, consumables::secondary_food( 461860, STAT_CRIT_RATING ) );  // fiery fish sticks
  unique_gear::register_special_effect( 457287, consumables::secondary_food( 461859, STAT_VERSATILITY_RATING ) );  // ginger glazed fillet
  unique_gear::register_special_effect( 457288, consumables::secondary_food( 461858, STAT_MASTERY_RATING ) );  // salty dog
  unique_gear::register_special_effect( 457289, consumables::secondary_food( 461857, STAT_HASTE_RATING, STAT_CRIT_RATING ) );  // deepfin patty
  unique_gear::register_special_effect( 457290, consumables::secondary_food( 461856, STAT_HASTE_RATING, STAT_VERSATILITY_RATING ) );  // sweet and spicy soup
  unique_gear::register_special_effect( 457291, consumables::secondary_food( 461854, STAT_CRIT_RATING, STAT_VERSATILITY_RATING ) );  // fish and chips
  unique_gear::register_special_effect( 457292, consumables::secondary_food( 461853, STAT_MASTERY_RATING, STAT_CRIT_RATING ) );  // salt baked seafood
  unique_gear::register_special_effect( 457293, consumables::secondary_food( 461845, STAT_MASTERY_RATING, STAT_VERSATILITY_RATING ) );  // marinated tenderloins
  unique_gear::register_special_effect( 457301, consumables::secondary_food( 461855, STAT_MASTERY_RATING, STAT_HASTE_RATING ) );  // chippy tea

  // Flasks
  unique_gear::register_special_effect( 432021, consumables::flask_of_alchemical_chaos, true );

  // Potions
  unique_gear::register_special_effect( 431932, consumables::tempered_potion );
  unique_gear::register_special_effect( 431914, consumables::potion_of_unwavering_focus );

  // Oils
  register_special_effect( { 451904, 451909, 451912 }, consumables::oil_of_deep_toxins );
  register_special_effect( 448000, consumables::bubbling_wax );

  // Enchants & gems
  register_special_effect( { 448710, 448714, 448716 }, enchants::authority_of_radiant_power );
  register_special_effect( { 449221, 449223, 449222 }, enchants::authority_of_the_depths );
  register_special_effect( { 449018, 449019, 449020 }, enchants::authority_of_storms );
  register_special_effect( { 449055, 449056, 449059,                                          // council's guile (crit)
                             449095, 449096, 449097,                                          // stormrider's fury (haste)
                             449112, 449113, 449114,                                          // stonebound artistry (mastery)
                             449120, 449118, 449117 }, enchants::secondary_weapon_enchant );  // oathsworn tenacity (vers)
  register_special_effect( 435500, enchants::culminating_blasphemite );
  register_special_effect( 435488, enchants::insightful_blasphemite );
  register_special_effect( { 457615, 457616, 457617 }, enchants::daybreak_spellthread );
  set_min_version( wowv_t( 11, 1, 5 ) );
  set_max_version( wowv_t( 11, 2, 0 ) );
  register_special_effect( { 1225042, 1225045 }, enchants::twilight_devastation );
  register_special_effect( { 1225878, 1225880 }, enchants::echoing_void );
  register_special_effect( { 1227295, 1227297 }, enchants::twisted_appendage );
  register_special_effect( { 1227312, 1227314 }, enchants::void_ritual );
  register_special_effect( { 1227289, 1227291 }, enchants::gushing_wound );
  register_special_effect( { 1227210, 1227211 }, enchants::infinite_stars );
  reset_version_check();

  // Embellishments & Tinkers
  register_special_effect( 443743, embellishments::blessed_weapon_grip );
  register_special_effect( 453503, embellishments::pouch_of_pocket_grenades );
  register_special_effect( 435992, DISABLED_EFFECT );  // prismatic null stone
  register_special_effect( 461177, embellishments::elemental_focusing_lens );
  register_special_effect( { 457665, 457677 }, embellishments::dawn_dusk_thread_lining );
  register_special_effect( 443760, embellishments::deepening_darkness );
  register_special_effect( 443736, embellishments::spark_of_beledar );
  register_special_effect( 443762, embellishments::adrenal_surge );
  register_special_effect( 443902, DISABLED_EFFECT );  // writhing armor banding
  register_special_effect( 436132, embellishments::binding_of_binding );
  register_special_effect( 436085, DISABLED_EFFECT ); // Binding of Binding on use
  register_special_effect( 453573, embellishments::siphoning_stiletto );

  // Trinkets
  register_special_effect( 444959, items::spymasters_web, true );
  register_special_effect( 444958, DISABLED_EFFECT );  // spymaster's web
  register_special_effect( 445619, items::aberrant_spellforge, true );
  register_special_effect( 445593, DISABLED_EFFECT );  // aberrant spellforge
  register_special_effect( 447970, items::sikrans_endless_arsenal );
  register_special_effect( 445203, DISABLED_EFFECT );  // sikran's shadow arsenal
  register_special_effect( 444301, items::swarmlords_authority );
  register_special_effect( 444292, DISABLED_EFFECT );  // swarmlord's authority
  register_special_effect( 444264, items::foul_behemoths_chelicera );
  register_special_effect( 445560, items::ovinaxs_mercurial_egg );
  register_special_effect( 445066, DISABLED_EFFECT );  // ovinax's mercurial egg
  register_special_effect( 449946, items::treacherous_transmitter, true );
  register_special_effect( 446209, DISABLED_EFFECT );  // treacherous transmitter
  register_special_effect( 443124, items::mad_queens_mandate );
  register_special_effect( 443128, DISABLED_EFFECT );  // mad queen's mandate
  register_special_effect( 443378, items::sigil_of_algari_concordance::sigil_of_algari_concordance );
  register_special_effect( 443407, items::skarmorak_shard );
  register_special_effect( 443409, DISABLED_EFFECT );  // skarmorak's shard
  register_special_effect( 443537, items::void_pactstone );
  register_special_effect( 448904, items::ravenous_honey_buzzer );
  register_special_effect( 443411, items::overclocked_geararang_launcher );
  register_special_effect( 446764, DISABLED_EFFECT ); // overclocked gear-a-rang launcher
  register_special_effect( 443530, items::remnant_of_darkness );
  register_special_effect( 443552, items::opressive_orators_larynx );
  register_special_effect( 446787, DISABLED_EFFECT ); // opressive orator's larynx
  register_special_effect( 443541, items::arakara_sacbrood );
  register_special_effect( 444489, items::skyterrors_corrosive_organ );
  register_special_effect( 444488, DISABLED_EFFECT );  // skyterror's corrosive organ
  register_special_effect( 443415, items::high_speakers_accretion );
  register_special_effect( 443380, items::entropic_skardyn_core, true );
  register_special_effect( 443538, items::empowering_crystal_of_anubikkaj );
  register_special_effect( 450561, items::mereldars_toll );
  register_special_effect( 450641, DISABLED_EFFECT );  // mereldar's toll
  register_special_effect( 443527, items::carved_blazikon_wax );
  register_special_effect( 443531, items::signet_of_the_priory );
  register_special_effect( 450877, DISABLED_EFFECT );  // signet of the priory
  register_special_effect( 451055, items::harvesters_edict );
  register_special_effect( 443525, items::conductors_wax_whistle );
  register_special_effect( 460469, items::charged_stormrook_plume );
  register_special_effect( 443556, items::twin_fang_instruments );
  register_special_effect( 450044, DISABLED_EFFECT );  // twin fang instruments
  register_special_effect( { 463610, 463232 }, items::darkmoon_deck_symbiosis );
  register_special_effect( 455482, items::imperfect_ascendancy_serum );
  register_special_effect( { 454857, 463611 }, items::darkmoon_deck_vivacity );
  register_special_effect( 432421, items::algari_alchemist_stone );
  register_special_effect( { 458573, 463095 }, items::darkmoon_deck_ascension );
  register_special_effect( { 454558, 463108 }, items::darkmoon_deck_radiance );
  register_special_effect( 441023, items::nerubian_pheromone_secreter );
  register_special_effect( 455640, items::shadowed_essence );
  register_special_effect( 455419, items::spelunkers_waning_candle );
  register_special_effect( 455436, items::unstable_power_core );
  register_special_effect( 451742, items::stormrider_flight_badge );
  register_special_effect( 451750, DISABLED_EFFECT );  // stormrider flight badge special effect
  register_special_effect( 435502, items::shadowbinding_ritual_knife );
  register_special_effect( 455432, items::shining_arathor_insignia );
  register_special_effect( 455451, items::quickwick_candlestick );
  register_special_effect( 455435, items::candle_confidant );
  register_special_effect( 435493, items::concoction_kiss_of_death, true );
  register_special_effect( 435473, items::everburning_lantern );
  register_special_effect( 455484, items::detachable_fang );
  register_special_effect( 459222, items::scroll_of_momentum, true );
  register_special_effect( 442429, items::wildfire_wick );
  register_special_effect( 455467, items::kaheti_shadeweavers_emblem, true );
  register_special_effect( 455452, DISABLED_EFFECT );  // kaheti shadeweaver's emblem
  register_special_effect( 469927, items::hand_of_justice );
  register_special_effect( 469915, items::golem_gearbox );
  register_special_effect( 469922, items::doperels_calling_rune );
  register_special_effect( 469925, items::burst_of_knowledge );
  register_special_effect( 469768, items::heart_of_roccor );
  register_special_effect( 467767, items::wayward_vrykuls_lantern );
  register_special_effect( 468035, items::cursed_pirate_skull );
  register_special_effect( 468033, items::runecasters_stormbound_rune );
  register_special_effect( 468034, items::darktide_wavebenders_orb );
  register_special_effect( 470286, items::torqs_big_red_button );
  register_special_effect( 466681, items::house_of_cards );
  register_special_effect( 443559, items::cirral_concoctory );
  register_special_effect( 469888, items::eye_of_kezan );
  register_special_effect( 471059, items::geargrinders_remote );
  register_special_effect( 1218714, items::improvised_seaforium_pacemaker, true );
  register_special_effect( 471567, items::reverb_radio );
  register_special_effect( 1214787, items::mechanocore_amplifier );
  register_special_effect( 1215238, items::papas_prized_putter );
  register_special_effect( 472125, items::turbodrain_5000 );
  register_special_effect( 470675, items::noggenfogger_ultimate_deluxe );
  register_special_effect( 1216605, items::ratfang_toxin );
  register_special_effect( 1216603, DISABLED_EFFECT ); // Ratfang toxin equip driver
  register_special_effect( 1219294, items::garbagemancers_last_resort );
  register_special_effect( 1213432, items::funhouse_lens );
  register_special_effect( 1214603, DISABLED_EFFECT ); // Funhouse Lens value spell
  register_special_effect( 1216625, items::suspicious_energy_drink );
  register_special_effect( 472120, items::amorphous_relic );
  register_special_effect( 1217356, items::zees_thug_hotline );
  register_special_effect( 467469, items::mister_locknstalk );
  register_special_effect( 467485, DISABLED_EFFECT );
  register_special_effect( 471548, items::mugs_moxie_jug );
  register_special_effect( 471057, DISABLED_EFFECT ); // Effect Amount for Flarendo's Pilot Light
  register_special_effect( 471142, items::flarendos_pilot_light );
  register_special_effect( 443533, DISABLED_EFFECT ); // Tome of Lights Devotion equip driver
  register_special_effect( 443535, items::tome_of_lights_devotion, true );
  register_special_effect( 443393, items::synergistic_brewterializer );
  register_special_effect( 471212, items::junkmaestros_mega_magnet, true );
  register_special_effect( 471211, DISABLED_EFFECT ); // junkmaestro's mega magnet
  register_special_effect( 1219102, items::ringing_ritual_mud );
  register_special_effect( 1221145, DISABLED_EFFECT );
  register_special_effect( 1219103, items::gigazaps_zapcap );
  register_special_effect( { 1223886, 1223899, 1223902, 1223904 }, items::hallowed_tome );
  set_min_version( wowv_t( 11, 2, 0 ) );
  register_special_effect( 1234996, items::diamantine_voidcore );
  register_special_effect( 1233556, items::unyielding_netherprism, true );
  register_special_effect( 1233553, DISABLED_EFFECT ); // Unyielding Netherprism equip driver
  register_special_effect( 1232802, items::arazs_ritual_forge );
  register_special_effect( 1234714, items::astral_antenna );
  register_special_effect( 1235272, items::screams_of_a_forgotten_sky );
  register_special_effect( 1233384, items::eradicating_arcanocore );
  register_special_effect( 1235360, items::sigil_of_the_cosmic_hunt );
  register_special_effect( 1242326, items::cursed_stone_idol );
  register_special_effect( 1235387, items::naazindhris_mystic_lash );
  register_special_effect( 1244636, items::perfidious_projector );
  register_special_effect( 1243118, items::incorporeal_warpclaw );
  register_special_effect( 1245148, items::mind_fracturing_odium );
  register_special_effect( 1244410, items::incorporeal_essence_gorger );
  register_special_effect( 1224856, items::voidtouched_fragment );
  register_special_effect( 1224870, items::soulbreakers_sigil );
  register_special_effect( 1231107, items::depleted_kareshi_battery );
  register_special_effect( 1243818, items::azhiccaran_parapodia );
  register_special_effect( 1244402, items::essence_hunters_eyeglass );
  register_special_effect( 1235425, items::soulbinders_embrace );
  register_special_effect( 1235218, DISABLED_EFFECT );  // soulbinder's embrace
  register_special_effect( 1235225, items::brand_of_ceaseless_ire );
  register_special_effect( 1244406, items::symbiotic_ethergauze );
  register_special_effect( 1231220, items::veiling_mana_shroud );
  register_special_effect( 1231217, DISABLED_EFFECT );  // veiling mana shroud
  register_special_effect( 1235500, items::alldevouring_nucleus );
  register_special_effect( 1244008, items::chaotic_nethergate );
  register_special_effect( 1246837, DISABLED_EFFECT );  // chaotic nethergate
  register_special_effect( 1244405, items::manaforged_aethercell, true );
  register_special_effect( 1234022, items::automatic_footbomb_dispenser );
  register_special_effect( 1230285, items::observers_soul_fetters );
  register_special_effect( 1230281, DISABLED_EFFECT );  // observer's soul fetters
  register_special_effect( 1232776, items::nexuskings_command, true );
  reset_version_check();

  // Weapons
  register_special_effect( 443384, items::fateweaved_needle );
  register_special_effect( 442205, items::befoulers_syringe );
  register_special_effect( 455887, items::voltaic_stormcaller );
  register_special_effect( 455819, items::harvesters_interdiction );
  register_special_effect( 469936, items::guiding_stave_of_wisdom );
  register_special_effect( 470641, items::flame_wrath );
  register_special_effect( 470647, items::force_of_magma );
  register_special_effect( 471316, items::vile_contamination );
  register_special_effect( { 473400, 473401 }, items::best_in_slots );
  register_special_effect( 471063, DISABLED_EFFECT );  // best in slots equip driver
  register_special_effect( 1218442, items::machine_gobs_iron_grin );
  register_special_effect( 467774, items::capos_molten_knuckles );
  register_special_effect( 1224457, items::shadow_quake );
  set_min_version( wowv_t( 11, 2, 0 ) );
  register_special_effect( 1235136, items::voidglass_shards );
  register_special_effect( 1243411, items::warplance_strike );
  reset_version_check();

  // Armor
  register_special_effect( 457815, items::seal_of_the_poisoned_pact );
  register_special_effect( 457918, DISABLED_EFFECT );  // seal of the poisoned pact
  register_special_effect( 455799, items::excavation );
  register_special_effect( 457683, items::sureki_zealots_insignia );
  register_special_effect( 1214161, items::the_jastor_diamond );
  set_min_version( wowv_t( 11, 2, 0 ) );
  register_special_effect( 1217091, items::ethereal_energy ); // Reshii Wraps equip driver
  register_special_effect( 1254906, DISABLED_EFFECT ); // Reshii Grace 20%
  register_special_effect( 1254904, DISABLED_EFFECT ); // Reshii Grace 30%
  register_special_effect( 1254905, DISABLED_EFFECT ); // Reshii Grace 50%
  register_special_effect( 1235409, DISABLED_EFFECT ); // Reshii Grace 50%
  reset_version_check();

  // Sets
  register_special_effect( 444067, sets::void_reapers_contract );    // kye'veza's cruel implements trinket
  register_special_effect( 444135, sets::void_reapers_warp_blade );  // kye'veza's cruel implements weapon
  register_special_effect( 444166, DISABLED_EFFECT );                // kye'veza's cruel implements
  register_special_effect( 457655, sets::woven_dusk, true );
  register_special_effect( 455521, sets::woven_dawn, true );
  register_special_effect( 443764, sets::embrace_of_the_cinderbee, true );
  register_special_effect( 443773, sets::fury_of_the_stormrook );
  set_min_version( wowv_t( 11, 2, 0 ) );
  register_special_effect( 1235130, sets::shards_of_the_void );  // Shards of the Void set bonus
  reset_version_check();

  // Singing Citrines
  register_special_effect( singing_citrines::CYRCES_CIRCLET,                    DISABLED_EFFECT );  // Disable ring driver.
  register_special_effect( singing_citrines::THUNDERLORDS_CRACKLING_CITRINE,    singing_citrines::thunderlords_crackling_citrine );
  register_special_effect( singing_citrines::UNDERSEA_OVERSEERS_CITRINE,        singing_citrines::undersea_overseers_citrine );
  register_special_effect( singing_citrines::SQUALL_SAILORS_CITRINE,            singing_citrines::squall_sailors_citrine );
  register_special_effect( singing_citrines::WINDSINGERS_RUNED_CITRINE,         singing_citrines::windsingers_runed_citrine );
  register_special_effect( singing_citrines::FATHOMDWELLERS_RUNED_CITRINE,      singing_citrines::fathomdwellers_runed_citrine );
  register_special_effect( singing_citrines::STORMBRINGERS_RUNED_CITRINE,       singing_citrines::stormbringers_runed_citrine );
  register_special_effect( singing_citrines::ROARING_WARQUEENS_CITRINE,         singing_citrines::roaring_warqueens_citrine );
  register_special_effect( singing_citrines::LEGENDARY_SKIPPERS_CITRINE,        singing_citrines::legendary_skippers_citrine );
  register_special_effect( singing_citrines::OLD_SALTS_BARDIC_CITRINE,          singing_citrines::old_salts_bardic_citrine );
  register_special_effect( singing_citrines::MARINERS_HALLOWED_CITRINE,         singing_citrines::mariners_hallowed_citrine );
  register_special_effect( singing_citrines::STORM_SEWERS_CITRINE,              singing_citrines::storm_sewers_citrine );
  register_special_effect( singing_citrines::SEABED_LEVIATHANS_CITRINE,         singing_citrines::seabed_leviathans_citrine );

  // Durable Information Securing Container
  set_min_version( wowv_t( 11, 1, 7 ) );
  register_special_effect( 1236138, durable_information_securing_chamber::titan_disc_replaced_effect );
  reset_version_check();
}

void register_target_data_initializers( sim_t& )
{}

void register_actor_initializers( sim_t& sim )
{
  // 20+11 for wow version 11.x
  sim.register_actor_initializer( INIT_ACTOR_CREATE_BUFFS + 31, []( player_t* p ) {
    // Potion Bomb of Power Primary Stat
    // Buff cannot stack
    // Does not take into account the fire damage on enemies
    if ( !p->external_buffs.potion_bomb_of_power.empty() )
    {
      auto driver_spell = p->find_spell( 453205 );
      auto buff_spell = p->find_spell( 453245 );

      // Value in buff data is for 5 people, need to split based on targets for a single player
      auto main_stat_amount = buff_spell->effectN( 1 ).average( p ) / driver_spell->effectN( 4 ).base_value();

      auto buff = make_buff<stat_buff_t>( p, "potion_bomb_of_power_external", buff_spell )
        ->add_stat_from_effect_type( A_MOD_STAT, main_stat_amount );

      p->register_timed_buff_triggers( buff, p->external_buffs.potion_bomb_of_power );
    }
  }, "create_buffs_thewarwithin" );
}

void register_hotfixes()
{}

action_t* create_action( player_t* p, std::string_view n, std::string_view options )
{
  // Trinket Actions
  if ( n == "pickup_entropic_skardyn_core" ) return new items::pickup_entropic_skardyn_core_t( p, options );
  if ( n == "do_treacherous_transmitter_task" ) return new items::do_treacherous_transmitter_task_t( p, options );
  if ( n == "pickup_nerubian_pheromone" ) return new items::pickup_nerubian_pheromone_t( p, options );

  // Set Actions
  if ( n == "pickup_cinderbee_orb" ) return new sets::pickup_cinderbee_orb_t( p, options );

  return nullptr;
}

// writhing armor banding embellishment, doubles nerubian embellishment values
double writhing_mul( player_t* p )
{
  if ( unique_gear::find_special_effect( p, 443902 ) )
    return 2.0;  // hardcoded
  else
    return 1.0;
}

// attuned to the aether renown perk
double attuned_mul( player_t* p, const spell_data_t* spell )
{
  if ( !p->thewarwithin_opts.attuned_to_the_aether )
    return 1.0;

  auto attuned = p->find_spell( 1242344 );
  const auto& eff = spell_data_t::find_spelleffect( *attuned, *spell, E_APPLY_AURA );

  return 1.0 + eff.percent();
}
}  // namespace unique_gear::thewarwithin
