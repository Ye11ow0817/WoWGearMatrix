// ==========================================================================
// Dedmonwakeen's Raid DPS/TPS Simulator.
// Send questions to natehieter@gmail.com
// ==========================================================================

#include "event.hpp"
#include "player/actor.hpp"
#include "sim.hpp" // replace with event manager dependency

// ==========================================================================
// Event
// ==========================================================================

event_t::event_t( sim_t& s, actor_t* a )
  : _sim( s ),
    next( nullptr ),
    time( 0_ms ),
    reschedule_time( no_reschedule ),
    id( 0 ),
    canceled( false ),
    recycled( false ),
    scheduled( false )
#ifdef ACTOR_EVENT_BOOKKEEPING
    ,
    actor( a )
#endif
{
#ifndef ACTOR_EVENT_BOOKKEEPING
  (void)a;
#endif
}

event_t::event_t( actor_t& a ) : event_t( *a.sim, &a )
{
}

timespan_t event_t::remains() const
{ return occurs() - _sim.event_mgr.current_time; }

rng::rng_t& event_t::rng()
{ return sim().rng(); }

/// Placement-new operator for creating events. Do not use in user-code.
void* event_t::operator new( std::size_t size, sim_t& sim )
{
  return sim.event_mgr.allocate_event( size );
}

void event_t::reschedule( timespan_t delta_time )
{
  id = ++_sim.event_mgr.global_event_id;
  delta_time += _sim.event_mgr.current_time;

  if ( _sim.debug )
  {
    if ( reschedule_time == no_reschedule )
    {
      _sim.print_debug("Rescheduling event {} from {} to {}",
          *this, time, delta_time );
    }
    else
    {
      _sim.print_debug( "Adjusting reschedule of event {} from {} to {} time={}",
          *this, reschedule_time, delta_time, time );
    }
  }

  reschedule_time = delta_time;
}

// event_t::cancel ==========================================================

void event_t::cancel( event_t*& e )
{
  if ( !e )
    return;

#ifdef ACTOR_EVENT_BOOKKEEPING
  if ( e->_sim.debug && e->actor && !e->canceled )
  {
    e->actor->event_counter--;
    if ( e->actor->event_counter < 0 )
    {
      fmt::print(stderr, "event_t::cancel assertion error: e -> player -> events < 0. event '{}' from '{}'.\n", e->name(), e->actor->name());
      assert( false );
    }
  }
#endif

  e->canceled = true;
  e           = nullptr;
}

void sc_format_to( const event_t& e, fmt::format_context::iterator out )
{
  fmt::format_to( out, "{}(#{})", e.name(), e.id );
}
