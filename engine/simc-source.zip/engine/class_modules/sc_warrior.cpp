// ==========================================================================
// Dedmonwakeen's DPS-DPM Simulator.
// Send questions to natehieter@gmail.com
// ==========================================================================

#include "dbc/specialization.hpp"
#include "simulationcraft.hpp"
#include "class_modules/apl/apl_warrior.hpp"
#include "action/parse_effects.hpp"

namespace
{  // UNNAMED NAMESPACE
// ==========================================================================
// Warrior
// To Do: Clean up green text
// Fury -
// Arms -
// ==========================================================================

struct warrior_t;

// Finds an action with the given name. If no action exists, a new one will
// be created.
//
// Use this with secondary background actions to ensure the player only has
// one copy of the action.
// Shamelessly borrowed from the mage module
template <typename Action, typename Actor, typename... Args>
action_t* get_action( util::string_view name, Actor* actor, Args&&... args )
{
  action_t* a = actor->find_action( name );
  if ( !a )
    a = new Action( name, actor, std::forward<Args>( args )... );
  assert( dynamic_cast<Action*>( a ) && a->name_str == name && a->background );
  return a;
}

template <typename V>
  static const spell_data_t* resolve_spell_data( V data )
  {
    if constexpr (std::is_invocable_v<decltype( &spell_data_t::ok ), V>)
      return data;
    else if constexpr (std::is_invocable_v<decltype( &buff_t::data ), V>)
      return &data->data();
    else if constexpr (std::is_invocable_v<decltype( &action_t::data ), V>)
      return &data->data();

    assert( false && "Could not resolve find_effect argument to spell data." );
    return nullptr;
  }

  // finds a spell effect
  // 1) first argument can be either player_talent_t, spell_data_t*, buff_t*, action_t*
  // 2) if the second argument is player_talent_t, spell_data_t*, buff_t*, or action_t* then only effects that affect it are returned
  // 3) if the third (or second if the above does not apply) argument is effect subtype, then the type is assumed to be E_APPLY_AURA
  // further arguments can be given to filter for full type + subtype + property
  template <typename T, typename U, typename... Ts>
  static const spelleffect_data_t& find_effect( T val, U type, Ts&&... args )
  {
    const spell_data_t* data = resolve_spell_data<T>( val );

    if constexpr (std::is_same_v<U, effect_subtype_t>)
      return spell_data_t::find_spelleffect( *data, E_APPLY_AURA, type, std::forward<Ts>( args )... );
    else if constexpr (std::is_same_v<U, effect_type_t>)
      return spell_data_t::find_spelleffect( *data, type, std::forward<Ts>( args )... );
    else
    {
      const spell_data_t* affected = resolve_spell_data<U>( type );

      if constexpr (std::is_same_v<std::tuple_element_t<0, std::tuple<Ts...>>, effect_subtype_t>)
        return spell_data_t::find_spelleffect( *data, *affected, E_APPLY_AURA, std::forward<Ts>( args )... );
      else if constexpr (std::is_same_v<std::tuple_element_t<0, std::tuple<Ts...>>, effect_type_t>)
        return spell_data_t::find_spelleffect( *data, *affected, std::forward<Ts>( args )... );
      else
        return spell_data_t::find_spelleffect( *data, *affected, E_APPLY_AURA );
    }

    assert( false && "Could not resolve find_effect argument to type/subtype." );
    return spelleffect_data_t::nil();
  }

  template <typename T, typename U, typename... Ts>
  static size_t find_effect_index( T val, U type, Ts&&... args )
  {
    return find_effect( val, type, std::forward<Ts>( args )... ).index() + 1;
  }

  // finds the first effect with a trigger spell
  // argument can be either player_talent_t, spell_data_t*, buff_t*, action_t*
  template <typename T>
  static const spelleffect_data_t& find_trigger( T val )
  {
    const spell_data_t* data = resolve_spell_data<T>( val );

    for (const auto& eff : data->effects())
    {
      switch (eff.type())
      {
        case E_TRIGGER_SPELL:
        case E_TRIGGER_SPELL_WITH_VALUE:
          return eff;
        case E_APPLY_AURA:
        case E_APPLY_AREA_AURA_PARTY:
          switch (eff.subtype())
          {
            case A_PROC_TRIGGER_SPELL:
            case A_PROC_TRIGGER_SPELL_WITH_VALUE:
            case A_PERIODIC_TRIGGER_SPELL:
            case A_PERIODIC_TRIGGER_SPELL_WITH_VALUE:
              return eff;
            default:
              break;
          }
          break;
        default:
          break;
      }
    }

    return spelleffect_data_t::nil();
  }

struct warrior_td_t : public actor_target_data_t
{
  dot_t* dots_deep_wounds;
  dot_t* dots_gushing_wound;
  dot_t* dots_rend;
  buff_t* debuffs_colossus_smash;
  buff_t* debuffs_fatal_mark;
  buff_t* debuffs_demoralizing_shout;
  buff_t* debuffs_honed_reflexes;
  buff_t* debuffs_taunt;
  buff_t* debuffs_punish;
  buff_t* debuffs_ravaged;
  buff_t* debuffs_callous_reprisal;
  buff_t* debuffs_overwhelmed;
  buff_t* debuffs_wrecked;  // Dominance of the Colossus
  buff_t* debuffs_devastating_focus;
  buff_t* debuffs_phalanx;
  bool hit_by_fresh_meat;

  warrior_t& warrior;
  warrior_td_t( player_t& target, warrior_t& p );

  void target_demise();
};

// utility to create target_effect_t compatible functions from warrior_td_t member references
template <typename T>
static std::function<int( actor_target_data_t* )> d_fn( T d, bool stack = true )
{
  if constexpr ( std::is_invocable_v<decltype( &buff_t::check ), std::invoke_result_t<T, warrior_td_t>> )
  {
    if ( stack )
      return [ d ]( actor_target_data_t* t ) {
        return std::invoke( d, static_cast<warrior_td_t*>( t ) )->check();
      };
    else
      return [ d ]( actor_target_data_t* t ) {
        return std::invoke( d, static_cast<warrior_td_t*>( t ) )->check() > 0;
      };
  }
  else if constexpr ( std::is_invocable_v<decltype( &dot_t::is_ticking ), std::invoke_result_t<T, warrior_td_t>> )
  {
    if ( stack )
      return [ d ]( actor_target_data_t* t ) {
        return std::invoke( d, static_cast<warrior_td_t*>( t ) )->current_stack();
      };
    else
      return [ d ]( actor_target_data_t* t ) {
        return std::invoke( d, static_cast<warrior_td_t*>( t ) )->is_ticking();
      };
  }
  else
  {
    static_assert( static_false<T>, "Not a valid member of warrior_td_t" );
    return nullptr;
  }
}

using data_t        = std::pair<std::string, simple_sample_data_with_min_max_t>;
using simple_data_t = std::pair<std::string, simple_sample_data_t>;

template <typename T_CONTAINER, typename T_DATA>
T_CONTAINER* get_data_entry( util::string_view name, std::vector<T_DATA*>& entries )
{
  for ( size_t i = 0; i < entries.size(); i++ )
  {
    if ( entries[ i ]->first == name )
    {
      return &( entries[ i ]->second );
    }
  }

  entries.push_back( new T_DATA( name, T_CONTAINER() ) );
  return &( entries.back()->second );
}

struct warrior_t : public parse_player_effects_t
{
public:
  bool non_dps_mechanics, warrior_fixed_time;
  int into_the_fray_friends;
  int never_surrender_percentage;
  bool first_rampage_attack_missed;
  int slayers_strike_attempts_since_last_proc;
  int master_of_warfare_attempts_since_last_proc;
  int fury_mid2_2pc_extensions;

  auto_dispose<std::vector<data_t*> > cd_waste_exec, cd_waste_cumulative;
  auto_dispose<std::vector<simple_data_t*> > cd_waste_iter;

  // Active
  struct active_t
  {
    action_t* deep_wounds;
    action_t* fatality;
    action_t* tough_as_nails;
    action_t* slayers_strike;
    action_t* ravager_whirling_blade;
    action_t* bloody_rebuke;  // Protection MID2 4pc
  } active;

  // Buffs
  struct buffs_t
  {
    buff_t* avatar;
    buff_t* battle_stance;
    buff_t* battle_shout_highlight;
    buff_t* battlelord;
    buff_t* berserker_rage;
    buff_t* berserker_stance;
    buff_t* best_served_cold;
    buff_t* bladestorm;
    buff_t* bloodcraze;
    buff_t* crushing_combo;
    buff_t* scent_of_blood;
    buff_t* ragedrinker;
    buff_t* executioners_precision;
    buff_t* executioners_wrath;
    buff_t* surge_of_adrenaline;
    buff_t* bloodborne;
    buff_t* bounding_stride;
    buff_t* brace_for_impact;
    buff_t* charge_movement;
    buff_t* collateral_damage;
    buff_t* champions_spear;
    buff_t* defensive_stance;
    buff_t* die_by_the_sword;
    buff_t* enrage;
    buff_t* frenzy;
    buff_t* hack_and_slash;
    buff_t* heroic_leap_movement;
    buff_t* ignore_pain;
    buff_t* intervene_movement;
    buff_t* into_the_fray;
    buff_t* last_stand;
    buff_t* martial_prowess;
    buff_t* rallying_cry;
    buff_t* ravager;
    buff_t* recklessness;
    buff_t* revenge;
    buff_t* shield_block;
    buff_t* shield_charge_movement;
    buff_t* shield_wall;
    buff_t* spell_reflection;
    buff_t* sudden_death;
    buff_t* sweeping_strikes;
    buff_t* tactical_edge;
    buff_t* whirlwind;
    buff_t* wild_strikes;

    // Arms Apex
    buff_t* master_of_warfare_proc;
    buff_t* master_of_warfare; // Damage buff
    buff_t* heroic_might_accumulator;
    buff_t* heroic_might;

    // Fury Apex
    buff_t* berserk;

    // Protection Apex
    buff_t* phalanx;

    buff_t* seeing_red;
    buff_t* seeing_red_tracking;
    buff_t* violent_outburst;

    // Colossus
    buff_t* colossal_might;
    buff_t* cut_to_the_bone;
    buff_t* celeritous_conclusion_haste;
    buff_t* celeritous_conclusion_crit;

    // Slayer
    buff_t* executioner;
    buff_t* imminent_demise;
    buff_t* brutal_finish;
    buff_t* fierce_followthrough;
    buff_t* opportunist;
    buff_t* violent_euphoria;

    // Mountain Thane
    buff_t* thunder_blast;
    buff_t* steadfast_as_the_peaks;
    buff_t* burst_of_power;

    // 12.1 Tier Sets
    buff_t* winding_up;
    buff_t* fury_mid2_4pc_crit;
    buff_t* vengeful_shield;  // Protection 2pc
  } buff;

  struct rppm_t
  {
    real_ppm_t* revenge;
    real_ppm_t* sudden_death;
    real_ppm_t* whirling_blade;
  } rppm;

  // Cooldowns
  struct cooldowns_t
  {
    cooldown_t* avatar;
    cooldown_t* recklessness;
    cooldown_t* berserker_rage;
    cooldown_t* bladestorm;
    cooldown_t* bloodthirst;
    cooldown_t* bloodbath;
    cooldown_t* cleave;
    cooldown_t* colossus_smash;
    cooldown_t* demoralizing_shout;
    cooldown_t* enraged_regeneration;
    cooldown_t* execute;
    cooldown_t* heroic_leap;
    cooldown_t* iron_fortress_icd;
    cooldown_t* impending_victory;
    cooldown_t* last_stand;
    cooldown_t* mortal_strike;
    cooldown_t* odyns_fury;
    cooldown_t* overpower;
    cooldown_t* pummel;
    cooldown_t* rage_from_auto_attack;
    cooldown_t* rage_from_crit_block;
    cooldown_t* rage_of_the_valarjar_icd;
    cooldown_t* raging_blow;
    cooldown_t* crushing_blow;
    cooldown_t* ravager;
    cooldown_t* shield_charge;
    cooldown_t* shield_slam;
    cooldown_t* shield_wall;
    cooldown_t* shockwave;
    cooldown_t* storm_bolt;
    cooldown_t* sudden_death_icd;
    cooldown_t* tough_as_nails_icd;
    cooldown_t* thunder_clap;
    cooldown_t* champions_spear;
    cooldown_t* cold_steel_hot_blood_icd;
    cooldown_t* reap_the_storm_icd;
    cooldown_t* demolish;
    cooldown_t* burst_of_power_icd;
    cooldown_t* slayers_dominance_icd;
    cooldown_t* hack_and_slash_icd;
  } cooldown;

  // Gains
  struct gains_t
  {
    gain_t* archavons_heavy_hand;
    gain_t* avatar;
    gain_t* avoided_attacks;
    gain_t* battlelord;
    gain_t* bloodsurge;
    gain_t* charge;
    gain_t* critical_block;
    gain_t* execute;
    gain_t* frothing_berserker;
    gain_t* just_warming_up;
    gain_t* melee_crit;
    gain_t* melee_main_hand;
    gain_t* melee_off_hand;
    gain_t* raging_blow;
    gain_t* ravager;
    gain_t* revenge;
    gain_t* shield_charge;
    gain_t* shield_slam;
    gain_t* champions_spear;
    gain_t* whirlwind;
    gain_t* booming_voice;
    gain_t* thunder_blast;
    gain_t* thunder_clap;
    gain_t* endless_rage;
    gain_t* instigate;
    gain_t* war_machine_demise;
    gain_t* thorims_might;
    gain_t* burst_of_power;

    // Legendarys, Azerite, and Special Effects
    gain_t* execute_refund;
    gain_t* rage_from_damage_taken;
    gain_t* ceannar_rage;
    gain_t* cold_steel_hot_blood;
    gain_t* lord_of_war;
    gain_t* simmering_rage;
  } gain;

  // Spells
  struct spells_t
  {
    // Core Class Spells
    const spell_data_t* avatar;
    const spell_data_t* battle_shout;
    const spell_data_t* berserker_rage;
    const spell_data_t* charge;
    const spell_data_t* execute;
    const spell_data_t* execute_rage_refund;
    const spell_data_t* hamstring;
    const spell_data_t* heroic_throw;
    const spell_data_t* pummel;
    const spell_data_t* shield_block;
    const spell_data_t* shield_slam;
    const spell_data_t* slam;
    const spell_data_t* taunt;
    const spell_data_t* victory_rush;
    const spell_data_t* whirlwind;
    const spell_data_t* ravaged_debuff;

    // Arms
    const spell_data_t* heroic_strike;
    const spell_data_t* master_of_warfare_2_buff;
    const spell_data_t* battlelord_buff;
    const spell_data_t* rend_dot;

    // Fury
    const spell_data_t* rampaging_ruin_damage;

    // Protection
    const spell_data_t* devastating_focus_debuff;
    const spell_data_t* phalanx_buff;
    const spell_data_t* phalanx_debuff;

    // Extra Spells To Make Things Work

    const spell_data_t* colossus_smash_debuff;
    const spell_data_t* fatal_mark_debuff;
    const spell_data_t* ravager;
    const spell_data_t* recklessness_buff;
    const spell_data_t* shield_block_buff;
    const spell_data_t* whirlwind_buff;
    const spell_data_t* aftershock_duration;
    const spell_data_t* shield_wall;
    const spell_data_t* devastator;
    const spell_data_t* bloodsurge_energize;
    const spell_data_t* deep_wounds_dot;
    const spell_data_t* sudden_death_buff;

    // Colossus
    const spell_data_t* wrecked_debuff;

    // Slayer
    const spell_data_t* slayers_strike;
    const spell_data_t* overwhelmed_debuff;
    const spell_data_t* reap_the_storm;

    // Mountain Thane
    const spell_data_t* lightning_strike;
  } spell;

  // Mastery
  struct mastery_t
  {
    const spell_data_t* master_of_arms;  // Arms
    const spell_data_t* critical_block;  // Protection
    const spell_data_t* unshackled_fury; // Fury
  } mastery;

  // Procs
  struct procs_t
  {
    proc_t* battlelord;
    proc_t* battlelord_wasted;
    proc_t* delayed_auto_attack;
    proc_t* tactician;
  } proc;

  // Spec Passives
  struct spec_t
  {
    // Class Aura
    const spell_data_t* warrior;
    const spell_data_t* warrior_2;

    // Arms Spells
    const spell_data_t* arms_warrior;
    const spell_data_t* arms_warrior_2;
    const spell_data_t* seasoned_soldier;
    const spell_data_t* sweeping_strikes;

    // Fury Spells
    const spell_data_t* fury_warrior;
    const spell_data_t* fury_warrior_2;
    const spell_data_t* enrage;
    const spell_data_t* execute;
    const spell_data_t* whirlwind;

    const spell_data_t* bloodbath; // BT replacement
    const spell_data_t* crushing_blow; // RB replacement

    // Protection Spells
    const spell_data_t* protection_warrior;
    const spell_data_t* protection_warrior_2;
    const spell_data_t* protection_warrior_3;
    const spell_data_t* devastate;
    const spell_data_t* riposte;
    const spell_data_t* vanguard;

    const spell_data_t* revenge_trigger;
    const spell_data_t* shield_block_2;

  } spec;

  // Talents
  struct talents_t
  {
    struct class_talents_t
    {
      // Row 1
      player_talent_t battle_stance;
      player_talent_t berserker_stance;
      player_talent_t defensive_stance;
      // Row 2
      player_talent_t fast_footwork;
      player_talent_t war_machine;
      player_talent_t thunder_clap;
      player_talent_t leeching_strikes;
      // Row 3
      player_talent_t impending_victory;
      player_talent_t heroic_leap;
      player_talent_t crackling_thunder;
      player_talent_t storm_bolt;
      // Row 4
      player_talent_t rend;
      player_talent_t storm_of_blood;
      player_talent_t blood_and_thunder;
      player_talent_t second_wind;
      player_talent_t frothing_berserker;
      player_talent_t bounding_stride;
      player_talent_t pain_and_gain;
      player_talent_t intervene;
      player_talent_t interpose;  // NYI
      // Row 5
      player_talent_t shockwave;
      player_talent_t overwhelming_rage;
      player_talent_t rallying_cry;
      player_talent_t field_dressing;  // NYI
      player_talent_t spell_reflection;
      // Row 6
      player_talent_t wrecking_throw;
      player_talent_t shattering_throw;
      player_talent_t rumbling_earth;
      player_talent_t berserker_shout;
      player_talent_t fearless;
      player_talent_t intimidating_shout;
      player_talent_t piercing_howl;
      player_talent_t honed_reflexes;
      // Row 7
      player_talent_t armored_to_the_teeth;
      player_talent_t double_time;
      player_talent_t reinforced_plates;
      // Row 8
      player_talent_t barbaric_training;
      player_talent_t javelineer;
      player_talent_t resonant_voice;
      player_talent_t crushing_force;
      // Row 9
      player_talent_t cruel_strikes;
      player_talent_t two_handed_weapon_specialization;  // Arms
      player_talent_t dual_wield_specialization;  // Fury
      player_talent_t one_handed_weapon_specialization;  // Prot
      player_talent_t wild_strikes;
      player_talent_t anger_management;
      player_talent_t champions_spear;
      player_talent_t stance_mastery;
      player_talent_t battlefield_commander;
    } warrior;

    struct arms_talents_t
    {
      // Row 1
      player_talent_t mortal_strike;
      // Row 2
      player_talent_t overpower;
      player_talent_t sudden_death;
      // Row 3
      player_talent_t fueled_by_violence;
      player_talent_t ignore_pain;
      player_talent_t die_by_the_sword;
      // Row 4
      player_talent_t bloodsurge;
      player_talent_t improved_overpower;
      player_talent_t improved_execute;
      player_talent_t fervor_of_battle;
      // Row 5
      player_talent_t tactician;
      player_talent_t colossus_smash;
      player_talent_t impale;
      // Row 6
      player_talent_t brute_force;
      player_talent_t efficiency;
      player_talent_t overpowering_finish;
      player_talent_t strength_of_arms;
      player_talent_t just_warming_up;
      player_talent_t broad_strokes;
      player_talent_t sharpened_blades;
      player_talent_t cleave;
      player_talent_t collateral_damage;
      // Row 7
      player_talent_t martial_prowess;
      player_talent_t dreadnaught;
      player_talent_t deep_wounds;
      player_talent_t tactical_edge;
      player_talent_t crushing_combo;
      player_talent_t massacre;
      player_talent_t mass_execution;
      player_talent_t improved_sweeping_strikes;
      player_talent_t powerful_momentum;
      // Row 8
      player_talent_t bloodborne;
      player_talent_t bladestorm;
      player_talent_t ravager;
      player_talent_t critical_thinking;
      // Row 9
      player_talent_t battlelord;
      player_talent_t bloodletting;
      player_talent_t executioners_precision;
      player_talent_t fatality;
      // Row 10
      player_talent_t master_tactician;
      player_talent_t mortal_wounds;
      player_talent_t avatar;
      // Apex
      player_talent_t master_of_warfare_1;
      player_talent_t master_of_warfare_2;
      player_talent_t master_of_warfare_3;
    } arms;

    struct fury_talents_t
    {
      // Row 1
      player_talent_t bloodthirst;
      // Row 2
      player_talent_t raging_blow;
      // Row 3
      player_talent_t sudden_death;
      player_talent_t frenzied_enrage;
      player_talent_t powerful_enrage;
      player_talent_t improved_execute;
      // Row 4
      player_talent_t focus_in_chaos;
      player_talent_t enraged_regeneration;
      player_talent_t warpaint;
      player_talent_t improved_whirlwind;
      // Row 5
      player_talent_t massacre;
      player_talent_t fresh_meat;
      player_talent_t invigorating_fury;
      player_talent_t rampage;
      player_talent_t improved_raging_blow;
      player_talent_t rampaging_ruin;
      // Row 6
      player_talent_t deep_wounds;
      player_talent_t spite;
      player_talent_t scent_of_blood;
      player_talent_t kill_or_be_killed;  // NYI
      player_talent_t hack_and_slash;
      player_talent_t cruelty;
      player_talent_t meat_cleaver;
      player_talent_t carving_blades;
      // Row 7
      player_talent_t cold_steel_hot_blood;
      player_talent_t ragedrinker;
      player_talent_t recklessness;
      player_talent_t bloodcraze;
      player_talent_t wrath_and_fury;
      // Row 8
      player_talent_t deft_experience;
      player_talent_t frenzy;
      player_talent_t critical_thinking;
      // Row 9
      player_talent_t vicious_contempt;
      player_talent_t odyns_fury;
      player_talent_t bloodborne;
      player_talent_t surge_of_adrenaline;
      // Row 10
      player_talent_t executioners_wrath;
      player_talent_t reckless_abandon;
      player_talent_t avatar;
      player_talent_t bladestorm;
      // Apex
      player_talent_t rampaging_berserker_1;
      player_talent_t rampaging_berserker_2;
      player_talent_t rampaging_berserker_3;
    } fury;

    struct protection_talents_t
    {
      // Row 1
      player_talent_t ignore_pain;
      // Row 2
      player_talent_t demoralizing_shout;
      player_talent_t revenge;
      // Row 3
      player_talent_t brace_for_impact;
      player_talent_t armor_specialization;
      player_talent_t fight_through_the_flames;
      player_talent_t devastator;
      // Row 4
      player_talent_t disrupting_shout;  // NYI
      player_talent_t strategist;
      player_talent_t devastating_focus;
      // Row 5
      player_talent_t brutal_vitality;
      player_talent_t instigate;
      player_talent_t shield_wall;
      player_talent_t bloodsurge;
      player_talent_t best_served_cold;
      // Row 6
      player_talent_t spellbreaker; // NYI
      player_talent_t hunker_down;  // NYI
      player_talent_t thunderlord;
      player_talent_t defenders_aegis;
      player_talent_t impenetrable_wall;
      player_talent_t last_stand;
      player_talent_t bloodborne;
      player_talent_t sudden_death;
      player_talent_t punish;
      // Row 7
      player_talent_t tough_as_nails;
      player_talent_t fueled_by_violence;
      player_talent_t enduring_defenses;
      player_talent_t unyielding_stance;
      player_talent_t deep_wounds;
      // Row 8
      player_talent_t heavy_repercussions;
      player_talent_t into_the_fray;
      player_talent_t focused_vigor;
      player_talent_t shield_specialization;
      player_talent_t enduring_alacrity;
      player_talent_t avatar;
      // Row 9
      player_talent_t massacre;
      player_talent_t booming_voice;
      player_talent_t indomitable;
      player_talent_t violent_outburst;
      player_talent_t heavy_handed;
      // Row 10
      player_talent_t shield_charge;
      player_talent_t battle_scarred_veteran;
      player_talent_t whirling_blade;
      player_talent_t ravager;
      // Apex
      player_talent_t phalanx_1;
      player_talent_t phalanx_2;
      player_talent_t phalanx_3;
    } protection;

    struct colossus_talents_t
    {
      player_talent_t demolish;
      player_talent_t martial_expert;
      player_talent_t colossal_might;
      player_talent_t boneshaker; // NYI
      player_talent_t earthquaker;
      player_talent_t decimator;  // NYI
      player_talent_t one_against_many;
      player_talent_t arterial_bleed;
      player_talent_t tide_of_battle;
      player_talent_t no_stranger_to_pain;
      player_talent_t veteran_vitality; // NYI
      player_talent_t cut_to_the_bone;
      player_talent_t practiced_strikes;
      player_talent_t precise_might;
      player_talent_t mountain_of_muscle_and_scars;
      player_talent_t celeritous_conclusion;
      player_talent_t dominance_of_the_colossus;
    } colossus;

    struct slayer_talents_t
    {
      player_talent_t slayers_dominance;
      player_talent_t imminent_demise;
      player_talent_t overwhelming_blades;
      player_talent_t relentless_pursuit; // NYI
      player_talent_t vicious_agility; // NYI
      player_talent_t violent_euphoria;  // NYI
      player_talent_t death_drive; // NYI
      player_talent_t culling_cyclone;
      player_talent_t brutal_finish;
      player_talent_t fierce_followthrough;
      player_talent_t opportunist;
      player_talent_t deadly_focus;  // NYI
      player_talent_t show_no_mercy;
      player_talent_t reap_the_storm;
      player_talent_t slayers_malice;
      player_talent_t unhinged;
      player_talent_t unrelenting_onslaught;
    } slayer;

    struct mountain_thane_talents_t
    {
      player_talent_t lightning_strikes;
      player_talent_t crashing_thunder;
      player_talent_t ground_current;
      player_talent_t strength_of_the_mountain;
      player_talent_t storm_surge;
      player_talent_t thunder_blast;
      player_talent_t storm_bolts;
      player_talent_t storm_shield; // NYI
      player_talent_t keep_your_feet_on_the_ground; // NYI
      player_talent_t steadfast_as_the_peaks;
      player_talent_t conductivity;
      player_talent_t flashing_skies;
      player_talent_t snap_induction;
      player_talent_t gathering_clouds;
      player_talent_t thorims_might;
      player_talent_t burst_of_power;
      player_talent_t capacitance;  // NYI
      player_talent_t avatar_of_the_storm;
    } mountain_thane;

    struct shared_talents_t
    {
      player_talent_t avatar;
      player_talent_t bladestorm;
      player_talent_t fueled_by_violence;
      player_talent_t ravager;
      player_talent_t bloodsurge;
      player_talent_t sudden_death;
      player_talent_t deep_wounds;
      player_talent_t ignore_pain;
    } shared;

  } talents;

  struct warrior_options_t
  {
  } options;

  // Default consumables
  std::string default_potion() const override;
  std::string default_flask() const override;
  std::string default_food() const override;
  std::string default_rune() const override;
  std::string default_temporary_enchant() const override;

  warrior_t( sim_t* sim, util::string_view name, race_e r = RACE_NIGHT_ELF )
    : parse_player_effects_t( sim, WARRIOR, name, r ),
      first_rampage_attack_missed( false ),
      active(),
      buff(),
      cooldown(),
      gain(),
      spell(),
      mastery(),
      proc(),
      spec(),
      talents()
  {
    non_dps_mechanics =
        true;  // When set to false, disables stuff that isn't important, such as second wind, bloodthirst heal, etc.
    warrior_fixed_time    = true;
    into_the_fray_friends = -1;
    never_surrender_percentage = 70;
    slayers_strike_attempts_since_last_proc = 0;
    master_of_warfare_attempts_since_last_proc = 0;
    fury_mid2_2pc_extensions = 0;
    resource_regeneration = regen_type::DISABLED;
  }

  // Character Definition
  void init_spells() override;
  void init_items() override;
  void init_base_stats() override;
  void init_scaling() override;
  void create_buffs() override;
  void init_finished() override;
  void init_gains() override;
  void init_position() override;
  void init_procs() override;
  void init_special_effects() override;
  void arise() override;
  void combat_begin() override;
  void init_rng() override;
  bool validate_fight_style( fight_style_e style ) const override;
  bool validate_actor() override;
  double composite_attribute( attribute_e attr ) const override;
  double composite_attribute_multiplier( attribute_e attr ) const override;
  double matching_gear_multiplier( attribute_e attr ) const override;
  double composite_armor_multiplier() const override;
  double composite_bonus_armor() const override;
  double composite_block() const override;
  double composite_block_value( const action_state_t* s ) const override;
  double composite_parry_rating() const override;
  double composite_parry() const override;
  double composite_attack_power_multiplier() const override;
  double composite_melee_crit_chance() const override;
  double composite_leech() const override;
  block_result_e target_block_resolution( const action_state_t* ) const override;
  double resource_gain( resource_e, double, gain_t* = nullptr, action_t* = nullptr ) override;
  void teleport( double yards, timespan_t duration ) override;
  void trigger_movement( double distance, movement_direction_type direction ) override;
  void interrupt() override;
  void reset() override;
  void moving() override;
  void create_actions() override;
  void create_options() override;
  std::string create_profile( save_e type ) override;
  void invalidate_cache( cache_e ) override;

  void apl_default();
  void init_action_list() override;
  void init_blizzard_action_list() override;
  void parse_assisted_combat_step( const assisted_combat_step_data_t& step, action_priority_list_t* assisted_combat ) override;
  parsed_assisted_combat_rule_t parse_assisted_combat_rule( const assisted_combat_rule_data_t& rule, const assisted_combat_step_data_t& step ) const override;
  std::vector<std::string> action_names_from_spell_id( unsigned int spell_id ) const override;

  action_t* create_action( util::string_view name, util::string_view options ) override;
  void activate() override;
  resource_e primary_resource() const override
  {
    return RESOURCE_RAGE;
  }
  role_e primary_role() const override;
  stat_e convert_hybrid_stat( stat_e s ) const override;
  // void assess_damage_imminent_pre_absorb( school_e, result_amount_type, action_state_t* s ) override;
  // void assess_damage_imminent( school_e, result_amount_type, action_state_t* s ) override;
  void assess_damage( school_e, result_amount_type, action_state_t* ) override;
  void target_mitigation( school_e, result_amount_type, action_state_t* ) override;
  void copy_from( player_t* ) override;
  void merge( player_t& ) override;
  void parse_player_effects();

  void datacollection_begin() override;
  void datacollection_end() override;

  target_specific_t<warrior_td_t> target_data;

  const warrior_td_t* find_target_data( const player_t* target ) const override
  {
    return target_data[ target ];
  }

  warrior_td_t* get_target_data( player_t* target ) const override
  {
    warrior_td_t*& td = target_data[ target ];

    if ( !td )
    {
      td = new warrior_td_t( *target, const_cast<warrior_t&>( *this ) );
    }
    return td;
  }

  // Secondary Action Tracking - From Rogue
private:
  std::vector<action_t*> background_actions;

public:
  template <typename T, typename... Ts>
  T* get_background_action( util::string_view n, Ts&&... args )
  {
    auto it = range::find( background_actions, n, &action_t::name_str );
    if ( it != background_actions.cend() )
    {
      return dynamic_cast<T*>( *it );
    }

    auto action = new T( n, this, std::forward<Ts>( args )... );
    action->background = true;
    background_actions.push_back( action );
    return action;
  }

  void enrage()
  {
    buff.enrage->trigger();
  }
};

namespace
{  // UNNAMED NAMESPACE
// Template for common warrior action code. See priest_action_t.
template <class Base>
struct warrior_action_t : public parse_action_effects_t<Base>
{
  struct affected_by_t
  {
    // talents
    bool sweeping_strikes;

    affected_by_t()
      : sweeping_strikes( false )
    {
    }
  } affected_by;

  bool usable_while_channeling;

private:
  using ab = parse_action_effects_t<Base>;
public:
  using base_t = warrior_action_t<Base>;
  bool track_cd_waste;
  simple_sample_data_with_min_max_t *cd_wasted_exec, *cd_wasted_cumulative;
  simple_sample_data_t* cd_wasted_iter;
  bool initialized;

  action_t* replacement_action;
  buff_t* replacement_action_buff;
  bool always_replace;
  bool was_replaced;
  warrior_action_t( util::string_view n, warrior_t* player, const spell_data_t* s = spell_data_t::nil() )
    : ab( n, player, s ),
      usable_while_channeling( false ),
      track_cd_waste( s->cooldown() > timespan_t::zero() || s->charge_cooldown() > timespan_t::zero() ),
      cd_wasted_exec( nullptr ),
      cd_wasted_cumulative( nullptr ),
      cd_wasted_iter( nullptr ),
      initialized( false ),
      replacement_action( nullptr ),
      replacement_action_buff( nullptr ),
      always_replace( false ),
      was_replaced( false )
  {
    ab::may_crit = true;

    if ( this->data().ok() )
    {
      apply_buff_effects();

      if ( this->type == action_e::ACTION_SPELL || this->type == action_e::ACTION_ATTACK )
      {
        apply_debuff_effects();
      }

      if ( this->data().flags( spell_attribute::SX_ABILITY ) || this->trigger_gcd > 0_ms )
      {
        this->not_a_proc = true;
      }
    }
  }

  void apply_buff_effects()
  {
    // Shared
    parse_effects( p()->buff.avatar, effect_mask_t( true ).disable( 6, 7, 8, 9, 10 ) );

    if ( p()->specialization() == WARRIOR_ARMS )
    {
      if ( p()->talents.warrior.stance_mastery->ok() )
        parse_effects( p()->buff.battle_stance, effect_mask_t( false ).enable( 4 ) );

      // Add Flat Modifier (107): Spell Cooldown (11) isn't yet supported by parse_effects.
      parse_effects( p()->buff.avatar, effect_mask_t( false ).enable( 6 ) );
      if( p()->main_hand_weapon.group() == WEAPON_2H )
        parse_effects( p()->mastery.master_of_arms );

      parse_effects( p()->buff.collateral_damage );
      if ( ab::sim->dbc->wowv() < wowv_t( 12, 1, 0 ) )
        parse_effects( p()->buff.ravager, effect_mask_t( false ).enable( 4 ) );
      parse_effects( p()->buff.executioners_precision );
      parse_effects( p()->buff.martial_prowess );
      parse_effects( p()->buff.master_of_warfare );
      parse_effects( p()->buff.battlelord );

      if ( p()->sets->has_set_bonus( WARRIOR_ARMS, MID2, B4 ) )
        parse_effects( p()->buff.winding_up );
    }
    else if ( p()->specialization() == WARRIOR_FURY )
    {
      parse_effects( p()->mastery.unshackled_fury, [ this ] { return p()->buff.enrage->check(); } );
      parse_effects( p()->buff.berserker_stance, effect_mask_t( true ).disable( 6 ) );

      parse_effects( p()->buff.avatar, effect_mask_t( false ).enable( 7 ) );

      parse_effects( p()->buff.bloodcraze );

      parse_effects( p()->buff.scent_of_blood );

      parse_effects( p()->buff.ragedrinker );

      parse_effects( p()->buff.executioners_wrath );

      parse_effects( p()->buff.surge_of_adrenaline );

      parse_effects( p()->buff.bloodborne );

      parse_effects( p()->buff.hack_and_slash, effect_mask_t( true ).enable( 1 ) );

      parse_effects( p()->buff.recklessness, effect_mask_t( true ).disable( 11, 12, 13, 14, 15 ) );
      if ( p()->talents.fury.reckless_abandon->ok() )
        parse_effects( p()->buff.recklessness, effect_mask_t( false ).enable( 11, 12, 13 ) );
      if ( p()->talents.fury.rampaging_berserker_2->ok() )
        parse_effects( p()->buff.recklessness, effect_mask_t( false ).enable( 14, 15 ) );

      parse_effects( p()->talents.fury.wrath_and_fury, effect_mask_t( false ).enable( 2 ), [ this ] { return p()->buff.enrage->check(); } );
    }
    else if ( p()->specialization() == WARRIOR_PROTECTION )
    {
      if ( p()->talents.warrior.stance_mastery->ok() )
        parse_effects( p()->buff.battle_stance, effect_mask_t( false ).enable( 4 ) );
      parse_effects( p()->buff.avatar, effect_mask_t( false ).enable( 8 ) );
      parse_effects( p()->buff.brace_for_impact, effect_mask_t( true ).disable( 2 ) );
      parse_effects( p()->buff.violent_outburst, effect_mask_t( false ).enable( 1 ) );

      parse_effects( p()->buff.revenge );

      parse_effects( p()->buff.best_served_cold );

      if ( ab::sim->dbc->wowv() >= wowv_t( 12, 1, 0 ) )
        parse_effects( p()->buff.vengeful_shield );

      if ( ab::sim->dbc->wowv() < wowv_t( 12, 1, 0 ) && ( p()->talents.protection.ravager.ok() || p()->talents.protection.whirling_blade.ok() ) )
        parse_effects( p()->buff.ravager, effect_mask_t( false ).enable( 5 ) );

      parse_effects( p()->buff.shield_block, effect_mask_t( false ).enable( 2, 4 ) );

      // Apex
      parse_effects( p()->buff.phalanx );
    }

    // Colossus
    if ( p()->talents.colossus.demolish->ok() )
    {
      parse_effects( p()->buff.colossal_might, effect_mask_t( false ).enable( 1 ) );
      if ( p()->talents.colossus.arterial_bleed->ok() )
      {
        parse_effects( p()->buff.colossal_might, effect_mask_t( false ).enable( 2 ) );
      }
      if ( p()->talents.colossus.tide_of_battle->ok() )
      {
        parse_effects( p()->buff.colossal_might, effect_mask_t( false ).enable( 3, 4 ) );
      }
      parse_effects( p()->buff.cut_to_the_bone );

      parse_effects( p()->buff.celeritous_conclusion_crit );
    }

    // Slayer
    if ( p()->talents.slayer.slayers_dominance->ok() )
    {
      parse_effects( p()->buff.brutal_finish );
      parse_effects( p()->buff.fierce_followthrough );
      parse_effects( p()->buff.opportunist );
      parse_effects( p()->buff.executioner, effect_mask_t( false ).enable( 1 ) );
      if ( p()->talents.slayer.show_no_mercy->ok() )
        parse_effects( p()->buff.executioner, effect_mask_t( false ).enable( 2, 3 ) );
    }

    // Mountain Thane
    if ( p()->talents.mountain_thane.lightning_strikes->ok() )
    {
      parse_effects( p()->buff.burst_of_power, effect_mask_t( false ).enable( 2 ) );

      if ( p()->talents.mountain_thane.storm_surge->ok() )
        parse_effects( p()->buff.avatar, effect_mask_t( false ).enable( 9, 10 ) );
    }
  }

  void apply_debuff_effects()
  {
    // Shared

    // Arms and Prot both benefit from ravaged debuff
    if ( ab::sim->dbc->wowv() >= wowv_t( 12, 1, 0 ) )
      parse_target_effects( d_fn( &warrior_td_t::debuffs_ravaged ), p()->spell.ravager->effectN( 3 ).trigger() );

    // Arms
    if ( ab::sim->dbc->wowv() >= wowv_t( 12, 1, 0 ) )
      parse_target_effects( d_fn( &warrior_td_t::dots_rend ), p()->spell.rend_dot );

    // Fury

    // Protection
    parse_target_effects( d_fn( &warrior_td_t::debuffs_demoralizing_shout ),
                          p()->talents.protection.demoralizing_shout );
    parse_target_effects( d_fn( &warrior_td_t::debuffs_devastating_focus ),
                          p()->spell.devastating_focus_debuff );
    parse_target_effects( d_fn( &warrior_td_t::debuffs_phalanx ),
                          p()->spell.phalanx_debuff );

    // Colossus
    if ( p()->talents.colossus.demolish->ok() )
    {
      // Wrecked has a value of 10 in spelldata, but it needs to be interpreted as 1% per stack
      parse_target_effects( d_fn( &warrior_td_t::debuffs_wrecked ),
                            p()->spell.wrecked_debuff, effect_mask_t( false ).enable( 2 ), p()->spell.wrecked_debuff->effectN( 2 ).base_value() / 1000 );
    }

    // Slayer
    if ( p()->talents.slayer.slayers_dominance->ok() )
    {
      parse_target_effects( d_fn( &warrior_td_t::debuffs_overwhelmed ),
                            p()->spell.overwhelmed_debuff );
    }

    // Mountain Thane
  }

  template <typename... Ts>
  void parse_effects( Ts&&... args ) { ab::parse_effects( std::forward<Ts>( args )... ); }
  template <typename... Ts>
  void parse_target_effects( Ts&&... args ) { ab::parse_target_effects( std::forward<Ts>( args )... ); }

  void init() override
  {
    if ( initialized )
      return;

    ab::init();

    if ( track_cd_waste )
    {
      cd_wasted_exec = get_data_entry<simple_sample_data_with_min_max_t, data_t>( ab::name_str, p()->cd_waste_exec );
      cd_wasted_cumulative =
          get_data_entry<simple_sample_data_with_min_max_t, data_t>( ab::name_str, p()->cd_waste_cumulative );
      cd_wasted_iter = get_data_entry<simple_sample_data_t, simple_data_t>( ab::name_str, p()->cd_waste_iter );
    }

    affected_by.sweeping_strikes         = ab::data().affected_by( p()->spec.sweeping_strikes->effectN( 1 ) );

    initialized = true;
  }

  std::string full_name() const
  {
    std::string n = ab::data().name_cstr();
    return n.empty() ? ab::name_str : n;
  }

  warrior_t* p()
  {
    return debug_cast<warrior_t*>( ab::player );
  }

  const warrior_t* p() const
  {
    return debug_cast<warrior_t*>( ab::player );
  }

  warrior_td_t* td( player_t* t ) const
  {
    return p()->get_target_data( t );
  }

  int n_targets() const override
  {
    if ( affected_by.sweeping_strikes && p()->buff.sweeping_strikes->check() )
    {
      return static_cast<int>( 1 + p()->spec.sweeping_strikes->effectN( 1 ).base_value() );
    }

    return ab::n_targets();
  }

  double composite_da_multiplier( const action_state_t* s ) const override
  {
    double dm = ab::composite_da_multiplier( s );

    if ( affected_by.sweeping_strikes && s->chain_target > 0 )
    {
      dm *= p()->spec.sweeping_strikes->effectN( 2 ).percent();
    }

    return dm;
  }

  double cost() const override
  {
    if ( !this->replacement_action )
      return ab::cost();

    if ( this->always_replace || ( this->replacement_action_buff && this->replacement_action_buff->check() ) )
      return this->replacement_action->cost();

    return ab::cost();
  }

  void queue_execute( execute_type et ) override
  {
    if ( !this->replacement_action || this->cooldown->duration == 0_ms )
      return ab::queue_execute( et );

    if ( this->always_replace || ( this->replacement_action_buff && this->replacement_action_buff->check() ) )
      return this->replacement_action->queue_execute( et );

    return ab::queue_execute( et );
  }

  void execute() override
  {
    if ( this->replacement_action )
    {
      if ( this->always_replace || ( this->replacement_action_buff && this->replacement_action_buff->check() ) )
      {
        this->replacement_action->set_target( this->target );
        this->replacement_action->execute();

        if ( !this->always_replace )
          this->stats->add_execute( 0_ms, this->target );

        this->was_replaced = true;
        return;
      }
    }

    this->was_replaced = false;
    ab::execute();

    // 388539 is the rend dot for arms.  Collateral damage is not procced from it, but is procced from other background actions like demolish
    if ( affected_by.sweeping_strikes && p()->talents.arms.collateral_damage.ok() && p()->buff.sweeping_strikes->up() && ab::num_targets_hit >= 2 && !( ab::data().id() == 388539 ) )
      p()->buff.collateral_damage->trigger();

    if ( affected_by.sweeping_strikes && p()->buff.sweeping_strikes->up() && ab::num_targets_hit >= 2 )
      p()->buff.sweeping_strikes->decrement();
  }

  bool ready() override
  {
    if ( this->replacement_action )
    {
      if ( this->always_replace || ( this->replacement_action_buff && this->replacement_action_buff->check() ) )
        return this->replacement_action->ready();
    }

    if ( !ab::ready() )
      return false;

    // -1 melee range implies that the ability can be used at any distance from the target.
    if ( p()->current.distance_to_move > ab::range && ab::range != -1 )
      return false;

    if ( ( p()->channeling || p()->buff.bladestorm->check() ) && !usable_while_channeling )
      return false;

    return true;
  }

  bool action_ready() override
  {
    if ( !this->replacement_action || this->cooldown->duration == 0_ms )
      return ab::action_ready();

    if ( this->always_replace || ( this->replacement_action_buff && this->replacement_action_buff->check() ) )
      return this->replacement_action->action_ready();

    return ab::action_ready();
  }

  void update_ready( timespan_t cd ) override
  {
    if ( cd_wasted_exec &&
         ( cd > timespan_t::zero() || ( cd <= timespan_t::zero() && ab::cooldown->duration > timespan_t::zero() ) ) &&
         ab::cooldown->current_charge == ab::cooldown->charges && ab::cooldown->last_charged > timespan_t::zero() &&
         ab::cooldown->last_charged < ab::sim->current_time() )
    {
      double time_ = ( ab::sim->current_time() - ab::cooldown->last_charged ).total_seconds();
      if ( p()->sim->debug )
      {
        p()->sim->out_debug.printf( "%s %s cooldown waste tracking waste=%.3f exec_time=%.3f", p()->name(), ab::name(),
                                    time_, ab::time_to_execute.total_seconds() );
      }
      time_ -= ab::time_to_execute.total_seconds();

      if ( time_ > 0 )
      {
        cd_wasted_exec->add( time_ );
        cd_wasted_iter->add( time_ );
      }
    }
    ab::update_ready( cd );
  }

  bool usable_moving() const override
  {  // All warrior abilities are usable while moving, the issue is being in range.
    return true;
  }

  void impact( action_state_t* s ) override
  {
    ab::impact( s );

    if ( ab::sim->log )
    {
      // TODO: Sorry Arma, had to fix composite_player_critical_damage_multiplier - Tae
      double player_critical_multiplier = 0.0;
      double tmp;

      for ( auto base_school : ab::base_schools )
      {
        tmp = p()->composite_player_critical_damage_multiplier( s, base_school );
        if ( tmp > player_critical_multiplier )
          player_critical_multiplier = tmp;
      }

      ab::sim->out_debug.printf(
          "Strength: %4.4f, AP: %4.4f, Crit: %4.4f%%, Crit Dmg Mult: %4.4f,  Mastery: %4.4f%%, Haste: %4.4f%%, "
          "Versatility: %4.4f%%, Bonus Armor: %4.4f, Tick Multiplier: %4.4f, Direct Multiplier: %4.4f, Action "
          "Multiplier: %4.4f",
          p()->cache.strength(), p()->cache.attack_power() * p()->composite_attack_power_multiplier(),
          p()->cache.attack_crit_chance() * 100, player_critical_multiplier,
          p()->cache.mastery_value() * 100, ( 1 / p()->cache.attack_haste() - 1 ) * 100,
          p()->cache.damage_versatility() * 100, p()->cache.bonus_armor(), s->composite_ta_multiplier(),
          s->composite_da_multiplier(), s->action->action_multiplier() );
    }
  }

  void tick( dot_t* d ) override
  {
    ab::tick( d );

    if ( ab::sim->log )
    {
      // TODO: Sorry Arma, had to fix composite_player_critical_damage_multiplier - Tae
      double player_critical_multiplier = 0.0;
      double tmp;

      for ( auto base_school : ab::base_schools )
      {
        tmp = p()->composite_player_critical_damage_multiplier( d->state, base_school );
        if ( tmp > player_critical_multiplier )
          player_critical_multiplier = tmp;
      }

      ab::sim->out_debug.printf(
          "Strength: %4.4f, AP: %4.4f, Crit: %4.4f%%, Crit Dmg Mult: %4.4f,  Mastery: %4.4f%%, Haste: %4.4f%%, "
          "Versatility: %4.4f%%, Bonus Armor: %4.4f, Tick Multiplier: %4.4f, Direct Multiplier: %4.4f, Action "
          "Multiplier: %4.4f",
          p()->cache.strength(), p()->cache.attack_power() * p()->composite_attack_power_multiplier(),
          p()->cache.attack_crit_chance() * 100, player_critical_multiplier,
          p()->cache.mastery_value() * 100, ( 1 / p()->cache.attack_haste() - 1 ) * 100,
          p()->cache.damage_versatility() * 100, p()->cache.bonus_armor(), d->state->composite_ta_multiplier(),
          d->state->composite_da_multiplier(), d->state->action->action_ta_multiplier() );
    }
  }

  void consume_resource() override
  {
    ab::consume_resource();

    double rage = ab::last_resource_cost;

    if ( p()->talents.warrior.anger_management->ok() )
    {
      anger_management( rage );
    }

    if ( p()->talents.arms.tactician.ok() && rage > 0 && !ab::background )
    {
      double proc_chance = p()->talents.arms.tactician->effectN( 1 ).percent();
      // Brute forces causes Slam (1464) and heroic strike (1269383) to have a 10% increase proc rate
      if ( p()->talents.arms.brute_force.ok() && ( ab::id == 1464 || ab::id == 1269383 ) )
        proc_chance += 0.10;
      if ( ab::sim->dbc->wowv() < wowv_t( 12, 1, 0 ) && p()->talents.arms.tactical_edge.ok() && p()->buff.tactical_edge->check() && ab::id == p()->talents.arms.mortal_strike->id() )
        proc_chance += p()->buff.tactical_edge->value();
      if ( ab::rng().roll( proc_chance ) )
      {
        p()->cooldown.overpower->reset( true );
        p()->proc.tactician->occur();
        if ( p()->talents.slayer.opportunist->ok() )
          p()->buff.opportunist->trigger();
      }
    }

    if ( rage > 0 && !ab::aoe && ab::execute_state && ab::result_is_miss( ab::execute_state->result ) )
    {
      p()->resource_gain( RESOURCE_RAGE, rage * 0.8, p()->gain.avoided_attacks );
    }

    // Protection Warrior Violent Outburst Seeing Red Tracking
    if ( p()->specialization() == WARRIOR_PROTECTION && p()->talents.protection.violent_outburst.ok() && rage > 0 )
    {
      // Trigger the buff to create an empty buff if we don't already have it active so we can assume it's already up
      if ( !p()->buff.seeing_red->check() )
      {
        p()->buff.seeing_red->trigger();
      }

      double original_value = p()->buff.seeing_red->current_value;
      p()->buff.seeing_red->current_value += rage;
      p()->sim->print_debug( "{} increments seeing_red by {}. Old={} New={}", p()->name(), rage,
                            original_value, p()->buff.seeing_red->current_value );

      if ( p()->buff.seeing_red->current_value >= p()->talents.protection.violent_outburst->effectN( 1 ).base_value() )
      {
        double overflow = p()->buff.seeing_red->current_value - p()->talents.protection.violent_outburst->effectN( 1 ).base_value();
        p()->sim->print_debug( "{} seeing_red triggering violent outburst.  overflow rage {}", p()->name(), overflow );
        p()->buff.seeing_red->expire();
        p()->buff.violent_outburst->trigger();
        if( overflow > 0)
          p()->buff.seeing_red->trigger( 1, overflow );
      }
    }
  }

  void anger_management( double rage )
  {
    if ( rage > 0 )
    {
      // Anger management reduces some cds by 1 sec per n rage spent (different per spec)
      double cd_time_reduction = -1.0 * rage;

      if ( p()->specialization() == WARRIOR_FURY )
      {
        cd_time_reduction /= p()->talents.warrior.anger_management->effectN( 3 ).base_value();
        p()->cooldown.avatar->adjust( timespan_t::from_seconds( cd_time_reduction ) );
        p()->cooldown.recklessness->adjust( timespan_t::from_seconds( cd_time_reduction ) );
      }
      else if ( p()->specialization() == WARRIOR_ARMS )
      {
        if ( ab::id == 190456 )  // Ignore pain can not trigger anger management for arms
          return;

        cd_time_reduction /= p()->talents.warrior.anger_management->effectN( 1 ).base_value();
        p()->cooldown.avatar->adjust( timespan_t::from_seconds( cd_time_reduction ) );
        p()->cooldown.colossus_smash->adjust( timespan_t::from_seconds( cd_time_reduction ) );
      }
      else if ( p()->specialization() == WARRIOR_PROTECTION )
      {
        cd_time_reduction /= p()->talents.warrior.anger_management->effectN( 2 ).base_value();
        p()->cooldown.avatar->adjust( timespan_t::from_seconds( cd_time_reduction ) );
        p()->cooldown.shield_wall->adjust( timespan_t::from_seconds( cd_time_reduction ) );
      }
    }
  }

  void set_replacement_action( action_t* a, buff_t* buff = nullptr )
  {
    if ( !a )
    {
      p()->sim->errorf( "%s Attempting to set null replacement action for %s. Ignoring.\n", p()->name(),
                        full_name().c_str() );
      return;
    }

    this->replacement_action = a;

    if ( buff )
    {
      this->replacement_action_buff = buff;
      this->add_child( a );
    }
    else
      this->always_replace = true;
  }

  void set_replacement_action( int id, buff_t* buff = nullptr )
  {
    action_t* a = find_action_by_id( id );
    if ( !a )
    {
      p()->sim->errorf(
          "%s Attempting to set replacement action by id %d for %s, but no such action exists. Ignoring.\n",
          p()->name(), id, full_name().c_str() );
      return;
    }
    set_replacement_action( a, buff );
  }

  void set_replacement_action( std::string_view name, buff_t* buff = nullptr )
  {
    action_t* a = p()->find_action( name );
    if ( !a )
    {
      p()->sim->errorf(
          "%s Attempting to set replacement action by name '%s' for %s, but no such action exists. Ignoring.\n",
          p()->name(), name.data(), full_name().c_str() );
      return;
    }
    set_replacement_action( a, buff );
  }

  action_t* find_action_by_id( int id )
  {
    for ( auto& a : p()->action_list )
    {
      if ( a->data().id() == id )
        return a.get();
    }
    return nullptr;
  }

  // Delayed Execute Event ====================================================

  struct delayed_execute_event_t : public event_t
  {
    action_t* action;
    player_t* target;

    delayed_execute_event_t( warrior_t* p, action_t* a, player_t* t, timespan_t delay )
      : event_t( *p->sim, delay ), action( a ), target( t )
    {
      assert( action->background );
    }

    const char* name() const override
    {
      return action->name();
    }

    void execute() override
    {
      if ( !target->is_sleeping() )
      {
        action->set_target( target );
        action->execute();
      }
    }
  };
};

struct warrior_heal_t : public warrior_action_t<heal_t>
{  // Main Warrior Heal Class
  warrior_heal_t( util::string_view n, warrior_t* p, const spell_data_t* s = spell_data_t::nil() ) : base_t( n, p, s )
  {
    may_crit = tick_may_crit = hasted_ticks = false;
    target                                  = p;
  }
};

struct warrior_spell_t : public warrior_action_t<spell_t>
{  // Main Warrior Spell Class - Used for spells that deal no damage, usually buffs.
  warrior_spell_t( util::string_view n, warrior_t* p, const spell_data_t* s = spell_data_t::nil() ) : base_t( n, p, s )
  {
    may_miss = may_glance = may_block = may_dodge = may_parry = may_crit = false;
  }
};

struct warrior_attack_t : public warrior_action_t<melee_attack_t>
{  // Main Warrior Attack Class
  double slayers_strike_proc_chance;
  double master_of_warfare_proc_chance;
  bool proc_slayers_strike;
  bool proc_slayers_strike_per_target;
  warrior_attack_t( util::string_view n, warrior_t* p, const spell_data_t* s = spell_data_t::nil() )
    : base_t( n, p, s ),
    slayers_strike_proc_chance( 0 ),
    master_of_warfare_proc_chance( 0 ),
    proc_slayers_strike( false ),
    proc_slayers_strike_per_target( false )
  {
    if ( p->talents.slayer.slayers_dominance->ok() )
    {
      if ( sim->dbc->wowv() < wowv_t( 12, 1, 0 ) )
        slayers_strike_proc_chance = prd::find_constant( p->talents.slayer.slayers_dominance->effectN( 1 ).percent() );
      else if ( sim->dbc->wowv() >= wowv_t( 12, 1, 0 ) )
      {
        if ( p->specialization() == WARRIOR_ARMS )
          slayers_strike_proc_chance = prd::find_constant( p->talents.slayer.slayers_dominance->effectN( 2 ).percent() );
        else if ( p->specialization() == WARRIOR_FURY )
          slayers_strike_proc_chance = prd::find_constant( p->talents.slayer.slayers_dominance->effectN( 1 ).percent() );
      }
    }

    if ( p->talents.arms.master_of_warfare_1.ok() )
      master_of_warfare_proc_chance = prd::find_constant( 0.15 );  // Not in spelldata
    special = true;
  }

  void impact( action_state_t* s ) override
  {
    warrior_action_t::impact( s );

    if ( sim->dbc->wowv() < wowv_t( 12, 1, 0 ) && 
            p()->talents.protection.whirling_blade->ok() &&
            s->target == p()->target && p()->rppm.whirling_blade->trigger() )
    {
      p()->active.ravager_whirling_blade->execute_on_target( s->target );
    }

    if ( !special )  // Procs below only trigger on special attacks, not autos
      return;

    // Tested July 4th 2026 on ptr
    if ( sim->dbc->wowv() >= wowv_t( 12, 1, 0 ) &&
            !background &&
            p()->talents.protection.whirling_blade->ok() &&
            s->target == p()->target && p()->rppm.whirling_blade->trigger() )
    {
      p()->active.ravager_whirling_blade->execute_on_target( s->target );
    }

    // TODO confirm slayers strike proc rate, currently this is just reading 15% from effect 1
    // However, I am pretty sure this is using pseudo_random_c_from_p from dk module
    if ( p()->talents.slayer.slayers_dominance->ok() &&
          ( s->target == p()->target || proc_slayers_strike_per_target ) &&
          p()->cooldown.slayers_dominance_icd->up() && proc_slayers_strike &&
          p()->rng().roll( slayers_strike_proc_chance * ++p()->slayers_strike_attempts_since_last_proc ) )
    {
      p()->slayers_strike_attempts_since_last_proc = 0;
      p()->active.slayers_strike->execute_on_target(s->target);
      p()->cooldown.slayers_dominance_icd->start();
    }
  }


  void execute() override
  {
    base_t::execute();
    if ( !special )  // Procs below only trigger on special attacks, not autos
      return;

    if ( ( p()->talents.shared.sudden_death.ok() && !background )
           && p()->cooldown.sudden_death_icd->up() && p()->rppm.sudden_death->trigger() )
    {
      p()->buff.sudden_death->trigger();
      p()->cooldown.sudden_death_icd->start();
      p()->cooldown.execute->reset( true );
    }
  }

  double composite_target_multiplier( player_t* target ) const override
  {
    double m = base_t::composite_target_multiplier( target );
    auto target_data = td( target );
    if ( target_data && target_data->debuffs_colossus_smash->up() )
    {
      auto multi = 1.0 + p()->spell.colossus_smash_debuff->effectN( 1 ).percent();
      if ( p()->talents.arms.master_of_warfare_3.ok() && p()->buff.heroic_might->up() )
        multi += p()->buff.heroic_might->stack_value() / 100;
      m *= multi;
    }
    return m;
  }

  player_t* select_random_target() const
  {
    if ( sim->distance_targeting_enabled )
    {
      std::vector<player_t*> targets;
      range::for_each( sim->target_non_sleeping_list, [&targets, this]( player_t* t ) {
        if ( p()->get_player_distance( *t ) <= radius + t->combat_reach )
        {
          targets.push_back( t );
        }
      } );

      auto random_idx = rng().range( targets.size() );
      return !targets.empty() ? targets[ random_idx ] : nullptr;
    }
    else
    {
      auto random_idx = rng().range( size_t(), sim->target_non_sleeping_list.size() );
      return sim->target_non_sleeping_list[ random_idx ];
    }
  }
};

// Avatar ===================================================================

struct avatar_t : public warrior_spell_t
{
  timespan_t avatar_of_the_storm_duration;
  bool from_avatar_of_the_storm;
  avatar_t( warrior_t* p, util::string_view options_str, util::string_view n, const spell_data_t* spell )
    : warrior_spell_t( n, p, spell ),
    avatar_of_the_storm_duration( 0_s ),
    from_avatar_of_the_storm( false )
  {

    parse_options( options_str );
    harmful   = false;
    target    = p;

    if ( p->talents.mountain_thane.avatar_of_the_storm->ok() )
      avatar_of_the_storm_duration = timespan_t::from_seconds( p->talents.mountain_thane.avatar_of_the_storm->effectN( 3 ).base_value() );
  }

  // Background action version
  avatar_t( util::string_view name, warrior_t* p )
    : warrior_spell_t( name, p, p->spell.avatar ),
    avatar_of_the_storm_duration( 0_s ),
    from_avatar_of_the_storm( false )
  {
    background = true;
    cooldown->duration = 0_s;
    trigger_gcd = timespan_t::zero();
    harmful    = false;
    target     = p;

    if ( p->talents.mountain_thane.avatar_of_the_storm->ok() )
      avatar_of_the_storm_duration = timespan_t::from_seconds( p->talents.mountain_thane.avatar_of_the_storm->effectN( 3 ).base_value() );
  }

  struct state_t : public action_state_t
  {
    using action_state_t::action_state_t;

    proc_types2 cast_proc_type2() const override
    {
      // This spell can trigger on-cast procs even if it is backgrounded
      return PROC2_CAST_GENERIC;
    }
  };

  action_state_t* new_state() override
  {
    return new state_t( this, target );
  }

  void execute() override
  {
    warrior_spell_t::execute();

    if ( !background )  // For Hard Cast Avatar
    {
      // Trigger main buff
      p()->buff.avatar->extend_duration_or_trigger();

      // Arms

      // Protection

      // Hero Talents
      // Mountain Thane
      if ( p()->talents.mountain_thane.avatar_of_the_storm->ok() )
      {
        p()->buff.thunder_blast->trigger( as<int> ( p()->talents.mountain_thane.avatar_of_the_storm->effectN( 1 ).base_value() ) );
        p()->cooldown.thunder_clap->reset( true );
      }
    }
    else  // For background triggered avatar procs
    {
      // Mountain Thane
      if ( from_avatar_of_the_storm )
        p()->buff.avatar->extend_duration_or_trigger( avatar_of_the_storm_duration );
    }
  }
};

// Reap the Storm ===========================================================

struct reap_the_storm_t : public warrior_attack_t
{
  reap_the_storm_t( util::string_view name, warrior_t* p ) : warrior_attack_t( name, p, p->spell.reap_the_storm )
  {
    background = true;
    aoe = -1;
    reduced_aoe_targets = p->talents.slayer.reap_the_storm->effectN( 1 ).base_value();
    weapon = &( p->main_hand_weapon );
  }

  void impact( action_state_t* state ) override
  {
    warrior_attack_t::impact( state );

    if ( p()->talents.slayer.overwhelming_blades->ok() && p()->talents.slayer.reap_the_storm->ok() )
    {
      td( state->target )->debuffs_overwhelmed->trigger();
    }
  }
};

// Devastate ================================================================

struct devastate_t : public warrior_attack_t
{
  double shield_slam_reset;
  devastate_t( warrior_t* p, util::string_view options_str )
    : warrior_attack_t( "devastate", p, p->spec.devastate ),
      shield_slam_reset( p->talents.protection.strategist->effectN( 1 ).percent() )
  {
    weapon        = &( p->main_hand_weapon );
    parse_options( options_str );

    if ( p->talents.protection.strategist->ok() )
    {
      // For some reason on PTR strategist is referencing shield slam reset chance from devastator
      shield_slam_reset = p->spell.devastator->effectN( 2 ).percent();
    }
  }

  void init_finished() override
  {
    warrior_attack_t::init_finished();

    gain = p()->gain.instigate;
  }

  void execute() override
  {
    warrior_attack_t::execute();

    if ( result_is_hit( execute_state->result ) && rng().roll( shield_slam_reset ) )
      p()->cooldown.shield_slam->reset( true );
  }

  bool ready() override
  {
    if ( !p()->has_shield_equipped() || p()->talents.protection.devastator->ok() )
    {
      return false;
    }
    return warrior_attack_t::ready();
  }
};

// Melee Attack =============================================================
struct devastator_t : warrior_attack_t
{
  double shield_slam_reset;

  devastator_t( warrior_t* p ) : warrior_attack_t( "devastator", p, p->talents.protection.devastator->effectN( 1 ).trigger() ),
      shield_slam_reset( p->talents.protection.devastator->effectN( 2 ).percent() )
  {
    background = true;
  }

  void init_finished() override
  {
    warrior_attack_t::init_finished();

    gain = p()->gain.instigate;
  }

  void impact( action_state_t* state ) override
  {
    warrior_attack_t::impact( state );

    if ( p()->talents.protection.devastating_focus.ok() )
    {
      auto target_data = td( state->target );
      // If we do not currently have devastating focus on our target, scan the list of enemies, if any of them have it
      // Clear it, then apply it to our current target
      if ( target_data )
      {
        if ( !target_data->debuffs_devastating_focus->up() )
        {
          for ( auto t : p()->sim->target_non_sleeping_list )
          {
            warrior_td_t* dev_focus_td = p()->get_target_data( t );
            if ( dev_focus_td->debuffs_devastating_focus->up() )
              dev_focus_td->debuffs_devastating_focus->expire();
          }
        }
      }
      target_data->debuffs_devastating_focus->trigger();
    }
  }

  void execute() override
  {
    warrior_attack_t::execute();

    if ( rng().roll( shield_slam_reset ) )
    {
      p() -> cooldown.shield_slam -> reset( true );
    }
  }
};

struct melee_t : public warrior_attack_t
{
  int sync_weapons;
  bool first;
  bool mh_lost_melee_contact, oh_lost_melee_contact;
  double base_rage_generation, arms_rage_multiplier, fury_rage_multiplier, prot_rage_multiplier, seasoned_soldier_crit_mult;
  double war_machine_rage_multiplier;
  double enrage_chance;
  devastator_t* devastator;
  melee_t( util::string_view name, warrior_t* p, int sw )
    : warrior_attack_t( name, p, spell_data_t::nil() ),
      sync_weapons( sw ),
      first( true ),
      mh_lost_melee_contact( true ),
      oh_lost_melee_contact( true ),
      base_rage_generation( 1.75 ),
      arms_rage_multiplier( 1.0 + p->spec.arms_warrior->effectN( 7 ).percent() ),
      fury_rage_multiplier( 1.0 + p->spec.fury_warrior->effectN( 6 ).percent() ),
      prot_rage_multiplier( 1.0 + p->spec.protection_warrior_3->effectN( 5 ).percent() ),
      seasoned_soldier_crit_mult( p->spec.seasoned_soldier->effectN( 1 ).percent() ),
      war_machine_rage_multiplier( 1.0 ),
      devastator( nullptr )
  {
    school                    = SCHOOL_PHYSICAL;
    may_crit                  = true;
    may_glance                = true;
    background                = true;
    allow_class_ability_procs = true;
    not_a_proc                = true;
    repeating                 = true;
    trigger_gcd               = timespan_t::zero();
    special                   = false;

    usable_while_channeling   = true;

    weapon_multiplier = 1.0;
    if ( p->dual_wield() )
    {
      base_hit -= 0.19;
    }
    if ( p->talents.protection.devastator->ok() )
    {
      devastator = new devastator_t( p );
      add_child( devastator );
    }

    if ( p->talents.warrior.war_machine->ok() )
    {
      switch ( p->specialization() )
      {
        case WARRIOR_ARMS:
          war_machine_rage_multiplier = 1.0 + p->talents.warrior.war_machine->effectN( 2 ).percent();
          break;
        case WARRIOR_FURY:
          war_machine_rage_multiplier = 1.0 + p->talents.warrior.war_machine->effectN( 3 ).percent();
          break;
        case WARRIOR_PROTECTION:
          war_machine_rage_multiplier = 1.0 + p->talents.warrior.war_machine->effectN( 4 ).percent();
          break;
        default:
          break;
      }
    }

    // explicitly apply here as the calls in warrior_action_t require valid spell data
    apply_buff_effects();
    apply_debuff_effects();
  }

  void reset() override
  {
    warrior_attack_t::reset();

    first = true;
    mh_lost_melee_contact = oh_lost_melee_contact = true;
  }

  timespan_t execute_time() const override
  {
    timespan_t t = warrior_attack_t::execute_time();
    if ( weapon->slot == SLOT_MAIN_HAND && mh_lost_melee_contact )
    {
      return timespan_t::zero();  // If contact is lost, the attack is instant.
    }
    else if ( weapon->slot == SLOT_OFF_HAND && ( oh_lost_melee_contact || first ) )  // Also used for the first attack.
    {
      if ( sync_weapons )
        return timespan_t::zero();

      // From testing and log analysis, when you charge in, around 50ms is a very common offset
      // for the off hand attack.  If you walk up and auto the boss, it's typically 50% of your swing time offset.
      return timespan_t::from_millis( rng().gauss_ab( 50, 25, 10, static_cast<double>( (t * 0.5).total_millis() ) ) );
    }
    else
    {
      return t;
    }
  }

  void schedule_execute( action_state_t* s ) override
  {
    warrior_attack_t::schedule_execute( s );
    if ( weapon->slot == SLOT_MAIN_HAND )
    {
      mh_lost_melee_contact = false;
    }
    else if ( weapon->slot == SLOT_OFF_HAND )
    {
      oh_lost_melee_contact = false;
    }
  }

  double composite_hit() const override
  {
    if ( p()->talents.fury.focus_in_chaos.ok() && p()->buff.enrage->check() )
    {
      return 1.0;
    }
    return warrior_attack_t::composite_hit();
  }

  void execute() override
  {
    if ( first )
      first = false;

    if ( p()->current.distance_to_move > 5 )
    {  // Cancel autoattacks, auto_attack_t will restart them when we're back in range.
      if ( weapon->slot == SLOT_MAIN_HAND )
      {
        p()->proc.delayed_auto_attack->occur();
        mh_lost_melee_contact = true;
        player->main_hand_attack->cancel();
      }
      else
      {
        p()->proc.delayed_auto_attack->occur();
        oh_lost_melee_contact = true;
        player->off_hand_attack->cancel();
      }
    }
    else
    {
      warrior_attack_t::execute();

      if ( result_is_hit( execute_state->result ) )
      {
        if ( p()->talents.protection.devastator->ok() )
        {
          devastator->target = execute_state->target;
          devastator->schedule_execute();
        }
        trigger_rage_gain( execute_state );
      }
    }
  }

  void impact( action_state_t* s ) override
  {
    warrior_attack_t::impact( s );

    if ( p()->talents.warrior.wild_strikes->ok() && s->result == RESULT_CRIT )
    {
      p()->buff.wild_strikes->trigger();
    }

    if ( sim->dbc->wowv() >= wowv_t( 12, 1, 0 ) && p()->specialization() == WARRIOR_PROTECTION && p()->rppm.revenge->trigger() )
        p()->buff.revenge->trigger();
  }

  void trigger_rage_gain( const action_state_t* s )
  {
    double rage_gain = weapon->swing_time.total_seconds() * base_rage_generation;

    if ( p()->specialization() == WARRIOR_ARMS )
    {
      rage_gain *= arms_rage_multiplier;
      if ( s->result == RESULT_CRIT )
      {
        rage_gain *= 1.0 + seasoned_soldier_crit_mult;
      }
    }
    else if ( p() -> specialization() == WARRIOR_FURY )
    {
      rage_gain *= fury_rage_multiplier;
      if ( weapon->slot == SLOT_OFF_HAND )
      {
        rage_gain *= 0.5;
      }
    }
    else
    {
      rage_gain *= prot_rage_multiplier;
    }

    if ( p()->talents.warrior.war_machine->ok() )
    {
      rage_gain *= war_machine_rage_multiplier;
    }

    rage_gain = util::round( rage_gain, 1 );

    if ( p()->specialization() == WARRIOR_ARMS && s->result == RESULT_CRIT )
    {
      p()->resource_gain( RESOURCE_RAGE, rage_gain, p()->gain.melee_crit );
    }
    else
    {
      p()->resource_gain( RESOURCE_RAGE, rage_gain,
                          weapon->slot == SLOT_OFF_HAND ? p()->gain.melee_off_hand : p()->gain.melee_main_hand );
    }
  }
};

// Auto Attack ==============================================================

struct auto_attack_t : public warrior_attack_t
{
  int sync_weapons;
  auto_attack_t( warrior_t* p, util::string_view options_str ) : warrior_attack_t( "auto_attack", p ), sync_weapons( 0 )
  {
    add_option( opt_bool( "sync_weapons", sync_weapons ) );
    parse_options( options_str );
    assert( p->main_hand_weapon.type != WEAPON_NONE );
    ignore_false_positive = usable_while_channeling = true;
    range = 5;

    if ( p->main_hand_weapon.group() == WEAPON_2H && p->has_shield_equipped() && p->specialization() != WARRIOR_FURY )
    {
      sim->errorf( "Player %s is using a 2 hander + shield while specced as Protection or Arms. Disabling autoattacks.",
                   name() );
    }
    else
    {
      p->main_hand_attack                    = new melee_t( "auto_attack_mh", p, sync_weapons );
      p->main_hand_attack->weapon            = &( p->main_hand_weapon );
      p->main_hand_attack->base_execute_time = p->main_hand_weapon.swing_time;
    }

    if ( p->off_hand_weapon.type != WEAPON_NONE && p->specialization() == WARRIOR_FURY )
    {
      p->off_hand_attack                    = new melee_t( "auto_attack_oh", p, sync_weapons );
      p->off_hand_attack->weapon            = &( p->off_hand_weapon );
      p->off_hand_attack->base_execute_time = p->off_hand_weapon.swing_time;
      p->off_hand_attack->id                = 1;
    }
    trigger_gcd = timespan_t::zero();
  }

  void execute() override
  {
    if ( p()->main_hand_attack && p()->main_hand_attack->execute_event == nullptr )
    {
      p()->main_hand_attack->schedule_execute();
    }
    if ( p()->off_hand_attack && p()->off_hand_attack->execute_event == nullptr )
    {
      p()->off_hand_attack->schedule_execute();
    }
  }

  bool ready() override
  {
    bool ready = warrior_attack_t::ready();
    if ( ready )  // Range check
    {
      if ( p()->main_hand_attack && p()->main_hand_attack->execute_event == nullptr )
      {
        return ready;
      }
      if ( p()->off_hand_attack && p()->off_hand_attack->execute_event == nullptr )
      {
        // Don't check for execute_event if we don't have an offhand.
        return ready;
      }
    }
    return false;
  }
};

// Fueled by Violence Heal ============================================
struct fueled_by_violence_heal_t : public warrior_heal_t
{
  fueled_by_violence_heal_t ( std::string_view name, warrior_t* p )
    : warrior_heal_t( name, p, p->find_spell( 383104 ) )
  {
    callbacks = false;
    background = true;
    target = p;
    attack_power_mod.direct = attack_power_mod.tick = 0;
    dot_duration = base_tick_time = 0_ms;
  }
};

// Rend ==============================================================

struct rend_dot_t : public warrior_attack_t
{
  double bloodsurge_chance, rage_from_bloodsurge;
  action_t* fueled_by_violence_heal;
  rend_dot_t( warrior_t* p )
    : warrior_attack_t( "rend_dot", p, p->spell.rend_dot ),
      bloodsurge_chance( p->talents.shared.bloodsurge->proc_chance() ),
      rage_from_bloodsurge( p->talents.shared.bloodsurge->effectN( 1 ).trigger()->effectN( 1 ).resource( RESOURCE_RAGE ) ),
      fueled_by_violence_heal( nullptr )
  {
    background = tick_may_crit = true;
    hasted_ticks               = true;

    if ( p->talents.shared.fueled_by_violence.ok() )
      fueled_by_violence_heal = get_action<fueled_by_violence_heal_t>( "fueled_by_violence", p );
  }

  void tick( dot_t* d ) override
  {
    warrior_attack_t::tick( d );

    if ( fueled_by_violence_heal && d->state->result_amount )
    {
      fueled_by_violence_heal->base_dd_min = fueled_by_violence_heal->base_dd_max = d->state->result_amount * p()->talents.shared.fueled_by_violence->effectN( 1 ).percent();
      fueled_by_violence_heal->execute();
    }
  }
};

struct rend_t : public warrior_attack_t
{
  warrior_attack_t* rend_dot;
  int aoe_targets;
  rend_t( warrior_t* p, util::string_view options_str )
    : warrior_attack_t( "rend", p, p->talents.warrior.rend ),
      rend_dot( nullptr )
  {
    parse_options( options_str );
    tick_may_crit = true;
    hasted_ticks  = true;
    rend_dot      = new rend_dot_t( p );
    radius = 5;
    if ( sim->dbc->wowv() < wowv_t( 12, 1, 0 ) )
    {
      radius = 8;
      aoe = -1;
      reduced_aoe_targets = data().effectN( 2 ).base_value();
    }
  }

  void impact( action_state_t* s ) override
  {
    warrior_attack_t::impact( s );

    rend_dot->execute_on_target( s->target );
  }

  bool ready() override
  {
    if ( p()->main_hand_weapon.type == WEAPON_NONE )
    {
      return false;
    }
    return warrior_attack_t::ready();
  }
};

// Lightning Strike =========================================================

struct ground_current_t : public warrior_attack_t
{
  ground_current_t( util::string_view name, warrior_t* p )
    : warrior_attack_t( name, p, p->find_spell( 460670 ) )
  {
    background = true;
    aoe = -1;
    reduced_aoe_targets = data().effectN( 2 ).base_value();
    target_filter_callback = secondary_targets_only();
  }
};

struct lightning_strike_t : public warrior_attack_t
{
  action_t* ground_current;
  action_t* avatar;
  lightning_strike_t( util::string_view name, warrior_t* p )
    : warrior_attack_t( name, p, p->spell.lightning_strike ),
    ground_current( nullptr ),
    avatar( nullptr )
  {
    background = true;
    if ( p->talents.mountain_thane.ground_current->ok() )
    {
      std::string s = "ground_current_";
      s += name;
      ground_current = get_action<ground_current_t>( s, p );
      add_child( ground_current );
    }

    if ( p->talents.mountain_thane.avatar_of_the_storm->ok() )
    {
      avatar = new avatar_t( "avatar_avatar_of_the_storm", p );
      debug_cast<avatar_t*>(avatar)->from_avatar_of_the_storm = true;
    }
  }

  void init_finished() override
  {
    warrior_attack_t::init_finished();

    gain = p()->gain.thorims_might;
  }

  void impact( action_state_t* s ) override
  {
    warrior_attack_t::impact( s );

    if ( ground_current )
    {
      ground_current->execute_on_target( s->target );
    }
  }

  void execute() override
  {
    warrior_attack_t::execute();
    if ( p()->talents.mountain_thane.burst_of_power->ok() )
      p()->buff.burst_of_power->trigger();

    if ( p()->talents.mountain_thane.avatar_of_the_storm->ok() && !p()->buff.avatar->check() )
    {
      if ( rng().roll( p()->talents.mountain_thane.avatar_of_the_storm->effectN( 2 ).percent() ) )
        avatar->schedule_execute();
    }
  }
};

// Slayer's Strike ==========================================================
struct slayers_strike_t : public warrior_attack_t
{
  int imminent_demise_tracker;
  int imminent_demise_trigger_threshold;
  slayers_strike_t( warrior_t* p )
    : warrior_attack_t( "slayers_strike", p, p->spell.slayers_strike ),
    imminent_demise_tracker( 0 ),
    imminent_demise_trigger_threshold( 0 )
  {
    special = true;
    background = true;

    if( p->talents.slayer.imminent_demise -> ok() && p->talents.shared.sudden_death->ok() )
      imminent_demise_trigger_threshold = as<int>( p->talents.slayer.imminent_demise -> effectN( 1 ).base_value() );
  }

  slayers_strike_t( util::string_view name, warrior_t* p )
    : warrior_attack_t( name, p, p->spell.slayers_strike ),
    imminent_demise_tracker( 0 ),
    imminent_demise_trigger_threshold( 0 )
  {
    special = true;
    background = true;

    if( p->talents.slayer.imminent_demise -> ok() && p->talents.shared.sudden_death->ok() )
      imminent_demise_trigger_threshold = as<int>( p->talents.slayer.imminent_demise -> effectN( 1 ).base_value() );
  }

  void execute() override
  {
    warrior_attack_t::execute();

    if ( p() -> talents.slayer.imminent_demise -> ok() && p()->talents.shared.sudden_death->ok() )
    {
      imminent_demise_tracker++;
      if ( imminent_demise_tracker == imminent_demise_trigger_threshold )
      {
        imminent_demise_tracker = 0;
        p() -> buff.sudden_death -> trigger( 1, buff_t::DEFAULT_VALUE(), 1.0 );
        p()->cooldown.execute->reset( true );
      }
    }

    if ( p()->talents.slayer.slayers_dominance->ok() )
      p()->buff.executioner->trigger();
  }

  void reset() override
  {
    warrior_attack_t::reset();
    imminent_demise_tracker = 0;
  }
};

// Ignore Pain =============================================================

struct ignore_pain_buff_t : public absorb_buff_t
{
  ignore_pain_buff_t( warrior_t* player ) : absorb_buff_t( player, "ignore_pain", player->talents.shared.ignore_pain )
  {
    cooldown->duration = 0_ms;
    set_absorb_source( player->get_stats( "ignore_pain" ) );
    set_absorb_gain( player->get_gain( "ignore_pain" ) );
  }

  // Custom consume implementation to allow minimum absorb amount.
  double consume( double amount, action_state_t* ) override
  {
    // Effect 2 stores the % of damage that is absorbed
    amount *= debug_cast< warrior_t* >( player ) -> talents.shared.ignore_pain -> effectN( 2 ).percent();
    double absorbed = absorb_buff_t::consume( amount );

    return absorbed;
  }
};

struct ignore_pain_t : public warrior_spell_t
{
  double max_hp_percent_cap;
  ignore_pain_t( warrior_t* p, util::string_view options_str )
    : warrior_spell_t( "ignore_pain", p, p->talents.shared.ignore_pain ),
    max_hp_percent_cap( 1.0 )  // Let arms have a full health bar worth of IP max
  {
    parse_options( options_str );
    may_crit     = false;
    use_off_gcd  = true;
    harmful      = false;
    range        = -1;
    target       = player;
    base_dd_max = base_dd_min = 0;
    resource_current = RESOURCE_RAGE;

    if ( p->specialization() == WARRIOR_PROTECTION )
      max_hp_percent_cap = p->talents.protection.ignore_pain->effectN( 4 ).percent();
  }

  ignore_pain_t ( util::string_view name, warrior_t* p )
    : warrior_spell_t( name, p, p->talents.shared.ignore_pain )
    {
      may_crit    = false;
      background  = true;
      harmful     = false;
      range       = -1;
      target      = player;
      base_dd_min = base_dd_max = 0;

      if ( p->specialization() == WARRIOR_PROTECTION )
        max_hp_percent_cap = p->talents.protection.ignore_pain->effectN( 4 ).percent();
    }

  void impact( action_state_t* s ) override
  {
    double new_ip = s -> result_amount;

    double previous_ip = p() -> buff.ignore_pain -> current_value;

    // IP is capped to 30% of max health
    double ip_max_health_cap = p() -> max_health() * max_hp_percent_cap;

    new_ip = std::min( previous_ip + new_ip, ip_max_health_cap );

    if ( new_ip > 0.0 )
    {
      p()->buff.ignore_pain->trigger( 1, new_ip );
    }
  }

  double cost() const override
  {
    if ( background )
      return 0;
    return warrior_spell_t::cost();
  }
};

// Bloodthirst Heal =========================================================

struct bloodthirst_heal_t : public warrior_heal_t
{
  bloodthirst_heal_t( warrior_t* p, const spell_data_t* s ) : warrior_heal_t( "bloodthirst_heal", p, s )
  {
    base_pct_heal = data().effectN( 1 ).percent();
    background    = true;
  }

  resource_e current_resource() const override
  {
    return RESOURCE_NONE;
  }
};

// Bloodthirst ==============================================================

struct gushing_wound_dot_t : public warrior_attack_t
{
  gushing_wound_dot_t( warrior_t* p ) : warrior_attack_t( "gushing_wound", p, p->find_spell( 385042 ) ) //288080 & 4 is CB
  {
    background = tick_may_crit = true;
    hasted_ticks               = false;
    //base_td = p->talents.fury.cold_steel_hot_blood.value( 2 );
  }
};

struct bloodthirst_t : public warrior_attack_t
{
  bloodthirst_heal_t* bloodthirst_heal;
  bloodthirst_heal_t* ragedrinker_heal;
  warrior_attack_t* gushing_wound;
  int aoe_targets;
  double enrage_chance;
  double rage_from_cold_steel_hot_blood;
  double rage_from_burst_of_power;
  bool unhinged;
  bloodthirst_t( warrior_t* p, util::string_view options_str )
    : warrior_attack_t( "bloodthirst", p, p->talents.fury.bloodthirst ),
      bloodthirst_heal( nullptr ),
      ragedrinker_heal( nullptr ),
      gushing_wound( nullptr ),
      aoe_targets( as<int>( p->spell.whirlwind_buff->effectN( 1 ).base_value() ) ),
      enrage_chance( p->talents.fury.bloodthirst->effectN( 3 ).percent() ),
      rage_from_cold_steel_hot_blood( p->find_spell( 383978 )->effectN( 1 ).base_value() / 10.0 ),
      rage_from_burst_of_power( 0 ),
      unhinged( false )
  {
    parse_options( options_str );

    weapon = &( p->main_hand_weapon );
    radius = 5;
    proc_slayers_strike = true;
    if ( p->non_dps_mechanics )
    {
      bloodthirst_heal = new bloodthirst_heal_t( p, p->find_spell( 117313 ) );
      if ( p->talents.fury.ragedrinker.ok() )
        ragedrinker_heal = new bloodthirst_heal_t( p, p->find_spell( 1265356 ) );
    }
    base_aoe_multiplier = p->spell.whirlwind_buff->effectN( 2 ).percent();

    if ( p->talents.fury.cold_steel_hot_blood.ok() )
    {
      gushing_wound = new gushing_wound_dot_t( p );
    }

    if ( p->talents.mountain_thane.burst_of_power->ok() )
    {
      rage_from_burst_of_power = p->talents.mountain_thane.burst_of_power->effectN( 1 ).trigger()->effectN( 3 ).resource( RESOURCE_RAGE );
    }
  }

  // Background version for use with Unhinged
  bloodthirst_t( util::string_view name, warrior_t* p )
    : warrior_attack_t( name, p, p->talents.fury.bloodthirst ),
      bloodthirst_heal( nullptr ),
      ragedrinker_heal( nullptr ),
      gushing_wound( nullptr ),
      aoe_targets( as<int>( p->spell.whirlwind_buff->effectN( 1 ).base_value() ) ),
      enrage_chance( p->talents.fury.bloodthirst->effectN( 3 ).percent() ),
      rage_from_cold_steel_hot_blood( p->find_spell( 383978 )->effectN( 1 ).base_value() / 10.0 ),
      rage_from_burst_of_power( 0 ),
      unhinged( false )
  {
    background = true;
    proc_slayers_strike = true;

    weapon = &( p->main_hand_weapon );
    radius = 5;
    if ( p->non_dps_mechanics )
    {
      bloodthirst_heal = new bloodthirst_heal_t( p, p->find_spell( 117313 ) );
      if ( p->talents.fury.ragedrinker.ok() )
        ragedrinker_heal = new bloodthirst_heal_t( p, p->find_spell( 1265356 ) );
    }
    base_aoe_multiplier = p->spell.whirlwind_buff->effectN( 2 ).percent();

    if ( p->talents.fury.cold_steel_hot_blood.ok() )
    {
      gushing_wound = new gushing_wound_dot_t( p );
    }

    if ( p->talents.mountain_thane.burst_of_power->ok() )
    {
      rage_from_burst_of_power = p->talents.mountain_thane.burst_of_power->effectN( 1 ).trigger()->effectN( 3 ).resource( RESOURCE_RAGE );
    }
  }

  // Constructor for unhinged specfic version, so we can disable sweeping strikes, as well as have a bool to check
  bloodthirst_t( util::string_view name, warrior_t* p, bool unhinged )
    : bloodthirst_t( name, p )
  {
    this->unhinged = unhinged;
    if ( unhinged )
      base_multiplier = p->talents.slayer.unhinged->effectN( 2 ).percent();
  }

  int n_targets() const override
  {
    if ( !unhinged && p()->buff.whirlwind->check() )
    {
      return aoe_targets + 1;
    }
    return warrior_attack_t::n_targets();
  }

  double action_multiplier() const override
  {
    double am = warrior_attack_t::action_multiplier();

    if ( p()->talents.fury.vicious_contempt->ok() && ( target->health_percentage() < 35 ) )
    {
      am *= 1.0 + ( p()->talents.fury.vicious_contempt->effectN( 1 ).percent() );
    }

    if ( p()->talents.fury.cruelty->ok() && p()->buff.enrage->check() )
    {
      am *= 1.0 + p()->talents.fury.cruelty->effectN( 1 ).percent();
    }

    return am;
  }

  void impact( action_state_t* s ) override
  {
    warrior_attack_t::impact( s );

    if ( gushing_wound && s->result == RESULT_CRIT )
    {
      gushing_wound->execute_on_target( s->target );
    }

    if ( p()->talents.fury.cold_steel_hot_blood.ok() && s->result == RESULT_CRIT &&
         p()->cooldown.cold_steel_hot_blood_icd->up() )
    {
      p()->resource_gain( RESOURCE_RAGE, rage_from_cold_steel_hot_blood, p()->gain.cold_steel_hot_blood );
      p() -> cooldown.cold_steel_hot_blood_icd->start();
    }

    // We schedule this one to trigger after the action fully resolves, as we need to expire the buff if it already exists
    if ( p()->talents.slayer.fierce_followthrough->ok() && s->result == RESULT_CRIT && s->chain_target == 0 )
      make_event( sim, [ this ] { p()->buff.fierce_followthrough->trigger(); } );

    if ( p()->talents.mountain_thane.burst_of_power->ok() && p()->buff.burst_of_power->up() && p()->cooldown.burst_of_power_icd->up() )
    {
      p()->cooldown.burst_of_power_icd->start();
      p()->buff.burst_of_power->decrement();
      p()->resource_gain( RESOURCE_RAGE, rage_from_burst_of_power, p()->gain.burst_of_power );
      // Reset CD after everything resolves
      make_event( *p()->sim, [ this ] { p()->cooldown.bloodbath->reset( true );
                                        p()->cooldown.bloodthirst->reset( true ); } );
    }
  }

  void execute() override
  {
    warrior_attack_t::execute();

    if ( !unhinged )
      p()->buff.whirlwind->decrement();

    if ( execute_state && result_is_hit( execute_state->result ) )
    {
      if ( bloodthirst_heal )
        bloodthirst_heal->execute();

      if ( ragedrinker_heal )
        ragedrinker_heal->execute();

      if ( rng().roll( enrage_chance ) )
        p()->enrage();

      if( p()->talents.fury.fresh_meat.ok() && execute_state && !td( execute_state->target )->hit_by_fresh_meat )
      {
        p()->buff.enrage->trigger();
        td( execute_state->target )->hit_by_fresh_meat = true;
      }
    }

    if ( p()->buff.enrage->up() )
    {
      p()->buff.enrage->extend_duration( p()->talents.fury.deft_experience->effectN( 2 ).time_value() );
      // Double the benefit on crit
      if( execute_state && execute_state->result == RESULT_CRIT )
        p()->buff.enrage->extend_duration( p()->talents.fury.deft_experience->effectN( 2 ).time_value() );
    }

    p()->buff.fierce_followthrough->expire();

    if ( p()->talents.mountain_thane.thunder_blast->ok() && rng().roll( p()->talents.mountain_thane.thunder_blast->effectN( 1 ).percent() ) )
    {
      p()->buff.thunder_blast->trigger();
    }

    if ( p()->buff.scent_of_blood->up() )
      p()->buff.scent_of_blood->decrement();

    if ( p()->talents.fury.ragedrinker->ok() && execute_state->result == RESULT_CRIT )
    {
      p()->buff.ragedrinker->trigger();
      if ( bloodthirst_heal )
        bloodthirst_heal->execute();
    }

    if ( p()->talents.fury.bloodborne->ok() )
      p()->buff.bloodborne->trigger();

    if ( p()->sets->has_set_bonus( WARRIOR_FURY, MID2, B4 ) && p()->buff.recklessness->up() )
      p()->buff.fury_mid2_4pc_crit->trigger( 1 );

    p()->buff.bloodcraze->expire();
  }

  bool ready() override
  {
    if ( p()->talents.fury.reckless_abandon->ok() && p()->buff.recklessness->check() && !background )
    {
      return false;
    }

    return warrior_attack_t::ready();
  }
};

// Bloodbath ==============================================================
struct bloodbath_dot_t : public warrior_attack_t
{
  bloodbath_dot_t( warrior_t* p ) : warrior_attack_t( "bloodbath_dot", p, p->find_spell( 113344 ) )
  {
    background = true;
    hasted_ticks = false;
    may_miss = false;
    dot_behavior = DOT_EXTEND;
  }
};

struct bloodbath_t : public warrior_attack_t
{
  bloodthirst_heal_t* bloodthirst_heal;
  bloodthirst_heal_t* ragedrinker_heal;
  warrior_attack_t* gushing_wound;
  warrior_attack_t* bloodbath_dot;
  int aoe_targets;
  double enrage_chance;
  double rage_from_cold_steel_hot_blood;
  double rage_from_burst_of_power;
  bool unhinged;
  bloodbath_t( warrior_t* p, util::string_view options_str )
    : warrior_attack_t( "bloodbath", p, p->spec.bloodbath ),
      bloodthirst_heal( nullptr ),
      ragedrinker_heal( nullptr ),
      gushing_wound( nullptr ),
      bloodbath_dot( nullptr ),
      aoe_targets( as<int>( p->spell.whirlwind_buff->effectN( 1 ).base_value() ) ),
      enrage_chance( p->spec.bloodbath->effectN( 3 ).percent() ),
      rage_from_cold_steel_hot_blood( p->find_spell( 383978 )->effectN( 1 ).base_value() / 10.0 ),
      rage_from_burst_of_power( 0 ),
      unhinged( false )
  {
    parse_options( options_str );

    weapon = &( p->main_hand_weapon );
    radius = 5;
    cooldown = p->cooldown.bloodthirst;
    track_cd_waste = true;
    if ( p->non_dps_mechanics )
    {
      bloodthirst_heal = new bloodthirst_heal_t( p, p->find_spell( 117313 ) );
      if ( p->talents.fury.ragedrinker.ok() )
        ragedrinker_heal = new bloodthirst_heal_t( p, p->find_spell( 1265356 ) );
    }
    base_aoe_multiplier = p->spell.whirlwind_buff->effectN( 2 ).percent();

    if ( p->talents.fury.cold_steel_hot_blood.ok() )
    {
      gushing_wound = new gushing_wound_dot_t( p );
    }

    bloodbath_dot = new bloodbath_dot_t( p );

    if ( p->talents.mountain_thane.burst_of_power->ok() )
    {
      rage_from_burst_of_power = p->talents.mountain_thane.burst_of_power->effectN( 1 ).trigger()->effectN( 3 ).resource( RESOURCE_RAGE );
    }
  }

  // Background version for use with unhinged
  bloodbath_t( util::string_view name, warrior_t* p )
    : warrior_attack_t( name, p, p->spec.bloodbath ),
      bloodthirst_heal( nullptr ),
      ragedrinker_heal( nullptr ),
      gushing_wound( nullptr ),
      bloodbath_dot( nullptr ),
      aoe_targets( as<int>( p->spell.whirlwind_buff->effectN( 1 ).base_value() ) ),
      enrage_chance( p->spec.bloodbath->effectN( 3 ).percent() ),
      rage_from_cold_steel_hot_blood( p->find_spell( 383978 )->effectN( 1 ).base_value() / 10.0 ),
      rage_from_burst_of_power( 0 ),
      unhinged( false )
  {
    background = true;

    weapon = &( p->main_hand_weapon );
    radius = 5;
    if ( p->non_dps_mechanics )
    {
      bloodthirst_heal = new bloodthirst_heal_t( p, p->find_spell( 117313 ) );
      if ( p->talents.fury.ragedrinker.ok() )
        ragedrinker_heal = new bloodthirst_heal_t( p, p->find_spell( 1265356 ) );
    }
    base_aoe_multiplier = p->spell.whirlwind_buff->effectN( 2 ).percent();

    if ( p->talents.fury.cold_steel_hot_blood.ok() )
    {
      gushing_wound = new gushing_wound_dot_t( p );
    }

    bloodbath_dot = new bloodbath_dot_t( p );

    if ( p->talents.mountain_thane.burst_of_power->ok() )
    {
      rage_from_burst_of_power = p->talents.mountain_thane.burst_of_power->effectN( 1 ).trigger()->effectN( 3 ).resource( RESOURCE_RAGE );
    }
  }

  // Constructor for unhinged specfic version, so we can disable sweeping strikes, as well as have a bool to check
  bloodbath_t( util::string_view name, warrior_t* p, bool unhinged )
    : bloodbath_t( name, p )
  {
    this->unhinged = unhinged;
    if ( unhinged )
      base_multiplier = p->talents.slayer.unhinged->effectN( 2 ).percent();
  }

  int n_targets() const override
  {
    if ( !unhinged && p()->buff.whirlwind->check() )
    {
      return aoe_targets + 1;
    }
    return warrior_attack_t::n_targets();
  }

  double action_multiplier() const override
  {
    double am = warrior_attack_t::action_multiplier();

    if ( p()->talents.fury.vicious_contempt->ok() && ( target->health_percentage() < 35 ) )
    {
      am *= 1.0 + ( p()->talents.fury.vicious_contempt->effectN( 1 ).percent() );
    }

    if ( p()->talents.fury.cruelty->ok() && p()->buff.enrage->check() )
    {
      am *= 1.0 + p()->talents.fury.cruelty->effectN( 1 ).percent();
    }

    return am;
  }

  void impact( action_state_t* s ) override
  {
    warrior_attack_t::impact( s );

    if ( gushing_wound && s->result == RESULT_CRIT )
    {
      gushing_wound->set_target( s->target );
      gushing_wound->execute();
    }

    if ( bloodbath_dot )
    {
      bloodbath_dot->execute_on_target( s->target );
    }

    if ( p()->talents.fury.cold_steel_hot_blood.ok() && execute_state->result == RESULT_CRIT &&
         p()->cooldown.cold_steel_hot_blood_icd->up() )
    {
      p()->resource_gain( RESOURCE_RAGE, rage_from_cold_steel_hot_blood, p()->gain.cold_steel_hot_blood );
      p()->cooldown.cold_steel_hot_blood_icd->start();
    }

    // We schedule this one to trigger after the action fully resolves, as we need to expire the buff if it already exists
    if ( p()->talents.slayer.fierce_followthrough->ok() && s->result == RESULT_CRIT && s->chain_target == 0 )
      make_event( sim, [ this ] { p()->buff.fierce_followthrough->trigger(); } );

    if ( p()->talents.mountain_thane.burst_of_power->ok() && p()->buff.burst_of_power->up() && p()->cooldown.burst_of_power_icd->up() )
    {
      p()->cooldown.burst_of_power_icd->start();
      p()->buff.burst_of_power->decrement();
      p()->resource_gain( RESOURCE_RAGE, rage_from_burst_of_power, p()->gain.burst_of_power );
      make_event( *p()->sim, [ this ] { p()->cooldown.bloodbath->reset( true );
                                        p()->cooldown.bloodthirst->reset( true ); } );
    }
  }

  void execute() override
  {
    warrior_attack_t::execute();

    if ( !unhinged )
      p()->buff.whirlwind->decrement();

    if ( execute_state && result_is_hit( execute_state->result ) )
    {
      if ( bloodthirst_heal )
        bloodthirst_heal->execute();

      if ( ragedrinker_heal )
        ragedrinker_heal->execute();

      if ( rng().roll( enrage_chance ) )
        p()->enrage();

      if( p()->talents.fury.fresh_meat.ok() && execute_state && !td( execute_state->target )->hit_by_fresh_meat )
      {
        p()->buff.enrage->trigger();
        td( execute_state->target )->hit_by_fresh_meat = true;
      }
    }

    if ( p()->buff.enrage->up() )
    {
      p()->buff.enrage->extend_duration( p()->talents.fury.deft_experience->effectN( 2 ).time_value() );
      // Double the benefit on crit
      if( execute_state && execute_state->result == RESULT_CRIT )
        p()->buff.enrage->extend_duration( p()->talents.fury.deft_experience->effectN( 2 ).time_value() );
    }

    p()->buff.fierce_followthrough->expire();

    if ( p()->talents.mountain_thane.thunder_blast->ok() && rng().roll( p()->talents.mountain_thane.thunder_blast->effectN( 1 ).percent() ) )
    {
      p()->buff.thunder_blast->trigger();
    }

    if ( p()->buff.scent_of_blood->up() )
      p()->buff.scent_of_blood->decrement();

    if ( p()->talents.fury.ragedrinker->ok() && execute_state->result == RESULT_CRIT )
    {
      p()->buff.ragedrinker->trigger();
      if ( bloodthirst_heal )
        bloodthirst_heal->execute();
    }

    if ( p()->talents.fury.bloodborne->ok() )
      p()->buff.bloodborne->trigger();

    if ( p()->sets->has_set_bonus( WARRIOR_FURY, MID2, B4 ) && p()->buff.recklessness->up() )
      p()->buff.fury_mid2_4pc_crit->trigger( 1 );

    p()->buff.bloodcraze->expire();
  }

  bool ready() override
  {
    if ( !p()->talents.fury.reckless_abandon->ok() )
      return false;
    if ( !p()->buff.recklessness->check() )
      return false;
    return warrior_attack_t::ready();
  }
};

// Mortal Strike ============================================================
struct mortal_strike_t : public warrior_attack_t
{
  double cost_rage;
  double frothing_berserker_chance;
  double rage_from_frothing_berserker;
  warrior_attack_t* rend_dot;
  bool unhinged;
  mortal_strike_t( warrior_t* p, util::string_view options_str )
    : warrior_attack_t( "mortal_strike", p, p->talents.arms.mortal_strike ),
      frothing_berserker_chance( p->talents.warrior.frothing_berserker->proc_chance() ),
      rage_from_frothing_berserker( p->talents.warrior.frothing_berserker->effectN( 1 ).percent() ),
      rend_dot( nullptr ),
      unhinged( false )
  {
    parse_options( options_str );

    weapon           = &( p->main_hand_weapon );
    cooldown->hasted = true;  // Doesn't show up in spelldata for some reason.
    rend_dot = new rend_dot_t( p );
    proc_slayers_strike = true;
  }

  // This version is used for unhinged and other background actions
  mortal_strike_t( util::string_view name, warrior_t* p )
    : warrior_attack_t( name, p, p->talents.arms.mortal_strike ),
      frothing_berserker_chance( p->talents.warrior.frothing_berserker->proc_chance() ),
      rage_from_frothing_berserker( p->talents.warrior.frothing_berserker->effectN( 1 ).percent() ),
      rend_dot( nullptr ),
      unhinged( true )
  {
    background = true;
    rend_dot = new rend_dot_t( p );
    cooldown->duration = 0_s;
    proc_slayers_strike = true;
  }

  // This version is used for unhinged, to set the variable, as unhinged does not cleave
  mortal_strike_t( util::string_view name, warrior_t* p, bool unhinged )
    : mortal_strike_t( name, p )
  {
    this->unhinged = unhinged;
    if ( unhinged )
      base_multiplier = p->talents.slayer.unhinged->effectN( 2 ).percent();
  }

  void init() override
  {
    warrior_attack_t::init();
    if ( unhinged )
    {
      affected_by.sweeping_strikes = false;
    }
  }

  double cost() const override
  {
    if ( background )
      return 0;
    return warrior_attack_t::cost();
  }

  void execute() override
  {
    warrior_attack_t::execute();

    cost_rage = last_resource_cost;
    if ( !background && p()->talents.warrior.frothing_berserker->ok() && rng().roll( frothing_berserker_chance ) )
    {
      p()->resource_gain(RESOURCE_RAGE, last_resource_cost * rage_from_frothing_berserker, p()->gain.frothing_berserker);
    }

    if ( execute_state && result_is_hit( execute_state->result ) )
    {
      if ( !sim->overrides.mortal_wounds && execute_state->target->debuffs.mortal_wounds )
      {
        execute_state->target->debuffs.mortal_wounds->trigger();
      }
    }

    p()->buff.brutal_finish->expire();

    p()->buff.fierce_followthrough->expire();

    p()->buff.celeritous_conclusion_crit->expire();

    p()->buff.executioners_precision->expire();
    p()->buff.martial_prowess->expire();

    if( sim->dbc->wowv() < wowv_t( 12, 1, 0 ) && !background )
      p()->buff.tactical_edge->decrement();

    if ( !background )
      p()->buff.battlelord->expire();

    if ( p()->sets->has_set_bonus( WARRIOR_ARMS, MID2, B4 ) )
      p()->buff.winding_up->trigger();
  }

  void impact( action_state_t* s ) override
  {
    warrior_attack_t::impact( s );

    if ( p()->talents.arms.fatality->ok() && p()->rng().roll( p()->talents.arms.fatality->effectN( 1 ).percent() ) )
      td( s->target )->debuffs_fatal_mark->trigger();

    if ( p()->talents.arms.bloodletting.ok() && p()->talents.warrior.rend.ok() && ( target->health_percentage() < p()->talents.arms.bloodletting->effectN( 3 ).base_value() ) )
      rend_dot->execute_on_target( s->target );

    // We schedule this one to trigger after the action fully resolves, as we need to expire the buff if it already exists
    if ( p()->talents.slayer.fierce_followthrough->ok() && s->result == RESULT_CRIT && s->chain_target == 0 )
      make_event( sim, [ this ] { p()->buff.fierce_followthrough->trigger(); } );

    if ( p()->talents.colossus.colossal_might->ok() )
    {
      // Gain 2 stacks on a crit with precise might, 1 otherwise.
      if ( p()->talents.colossus.precise_might->ok() && s->result == RESULT_CRIT )
      {
        if ( sim->dbc->wowv() < wowv_t( 12, 1, 0 ) && p()->talents.colossus.dominance_of_the_colossus->ok() && p()->buff.colossal_might->at_max_stacks() )
        {
          p()->cooldown.demolish->adjust( - timespan_t::from_seconds( p()->talents.colossus.dominance_of_the_colossus->effectN( 2 ).base_value() * 2 ) );
        }
        p()->buff.colossal_might->trigger( 2 );
      }
      else
      {
        if ( sim->dbc->wowv() < wowv_t( 12, 1, 0 ) && p()->talents.colossus.dominance_of_the_colossus->ok() && p()->buff.colossal_might->at_max_stacks() )
        {
          p()->cooldown.demolish->adjust( - timespan_t::from_seconds( p()->talents.colossus.dominance_of_the_colossus->effectN( 2 ).base_value() ) );
        }
        p()->buff.colossal_might->trigger();
      }
    }

    if ( s->result == RESULT_CRIT && p()->talents.colossus.cut_to_the_bone->ok() )
      p()->buff.cut_to_the_bone->trigger();

    if ( s->result == RESULT_CRIT && p()->talents.arms.mortal_wounds->ok() )
      p()->active.deep_wounds->execute_on_target( s->target );

    auto target_data = td( s->target );

    if ( p()->sets->has_set_bonus( WARRIOR_ARMS, MID1, B4 ) &&
            target_data && target_data->debuffs_colossus_smash->up() )
    {
      target_data->debuffs_colossus_smash->extend_duration_or_trigger( p()->sets->set( WARRIOR_ARMS, MID1, B4 )->effectN( 1 ).time_value() );
    }

    if ( !background && p()->talents.arms.master_of_warfare_1.ok() && !p()->buff.master_of_warfare_proc->up() && p()->rng().roll( master_of_warfare_proc_chance * ++p()->master_of_warfare_attempts_since_last_proc ) )
    {
      p()->buff.master_of_warfare_proc->trigger();
      p()->master_of_warfare_attempts_since_last_proc = 0;
    }
  }

  bool ready() override
  {
    if ( p()->main_hand_weapon.type == WEAPON_NONE )
    {
      return false;
    }
    return warrior_attack_t::ready();
  }
};

// Bladestorm ===============================================================

struct bladestorm_tick_t : public warrior_attack_t
{
  bladestorm_tick_t( warrior_t* p, util::string_view name, const spell_data_t* spell )
    : warrior_attack_t( name, p, spell )
  {
    dual = true;
    aoe = -1;
    reduced_aoe_targets = 8.0;
    background = true;
    if ( p->specialization() == WARRIOR_ARMS )
    {
      // Arms does not generate rage when bladestorming
      energize_amount = 0;
      energize_resource = RESOURCE_NONE;
    }
  }

  double composite_da_multiplier( const action_state_t* state ) const override
  {
    double m = warrior_attack_t::composite_da_multiplier( state );

    if ( p()->talents.slayer.culling_cyclone->ok() )
      m *= 1.0 + ( p()->talents.slayer.culling_cyclone->effectN( 1 ).percent() / p()->sim->target_non_sleeping_list.size() );

    return m;
  }

  void impact( action_state_t* state ) override
  {
    warrior_attack_t::impact( state );

    if ( p()->talents.slayer.overwhelming_blades->ok() && data().id() == 50622 ) // 50622 is MH bladestorm attack.  We only proc overwhelmed debuff from MH hits
    {
      td( state->target )->debuffs_overwhelmed->trigger();
    }
  }
};

struct bladestorm_t : public warrior_attack_t
{
  attack_t *bladestorm_mh, *bladestorm_oh;
  mortal_strike_t* mortal_strike;
  bloodthirst_t* bloodthirst;
  bloodbath_t* bloodbath;

  bladestorm_t( warrior_t* p, util::string_view options_str, util::string_view n, const spell_data_t* spell )
    : warrior_attack_t( n, p, spell ),
    bladestorm_mh( new bladestorm_tick_t( p, fmt::format( "{}_mh", n ), spell->effectN( 1 ).trigger() ) ),
      bladestorm_oh( nullptr ),
      mortal_strike( nullptr ),
      bloodthirst( nullptr ),
      bloodbath( nullptr )
  {
    parse_options( options_str );
    channeled = false;
    tick_zero = true;
    interrupt_auto_attack = false;
    travel_speed                      = 0;
    internal_cooldown->duration = 0_s; // allow Anger Management to reduce the cd properly due to having both charges and cooldown entries

    bladestorm_mh->weapon             = &( player->main_hand_weapon );
    add_child( bladestorm_mh );
    if ( player->off_hand_weapon.type != WEAPON_NONE && player->specialization() == WARRIOR_FURY )
    {
      bladestorm_oh         = new bladestorm_tick_t( p, fmt::format( "{}_oh", n ), spell->effectN( 1 ).trigger()->effectN( 2 ).trigger() );
      bladestorm_oh->weapon = &( player->off_hand_weapon );
      add_child( bladestorm_oh );
    }

    if ( p->talents.slayer.unhinged->ok() && p->specialization() == WARRIOR_ARMS )
    {
      mortal_strike = new mortal_strike_t( "mortal_strike_bladestorm_unhinged", p, true );
      add_child( mortal_strike );
    }

    if ( p->talents.slayer.unhinged->ok() && p->specialization() == WARRIOR_FURY )
    {
      bloodthirst = new bloodthirst_t( "bloodthirst_bladestorm_unhinged", p, true );
      add_child( bloodthirst );

      if ( p->talents.fury.reckless_abandon->ok() )
      {
        bloodbath = new bloodbath_t( "bloodbath_bladestorm_unhinged", p, true );
        add_child( bloodbath );
      }
    }
  }

  void execute() override
  {
    warrior_attack_t::execute();

    p()->buff.bladestorm->trigger();
  }

  timespan_t composite_dot_duration( const action_state_t* s ) const override
  {
    auto new_dot_duration = warrior_attack_t::composite_dot_duration( s );

    if ( p() -> talents.slayer.imminent_demise -> ok() && p()->talents.shared.sudden_death->ok() )
    {
      new_dot_duration = tick_time( s ) * ( dot_duration.total_seconds() + p() -> buff.imminent_demise -> stack() );
    }

    return new_dot_duration;
  }

  timespan_t tick_time ( const action_state_t* s ) const override
  {
    auto new_base_tick_time = warrior_attack_t::tick_time( s );

    // Normally we get 6 ticks of bladestorm, but with imminent demise, we get 1-3 extra ticks, in the same amount of time
    if ( p() -> talents.slayer.imminent_demise->ok() && p()->talents.shared.sudden_death->ok() )
    {
      new_base_tick_time *= ( dot_duration.total_seconds() / ( dot_duration.total_seconds() + p() -> buff.imminent_demise -> stack() ) );
    }

    return new_base_tick_time;
  }

  void tick( dot_t* d ) override
  {
    // dont tick if BS buff not up
    // since first tick is instant the buff won't be up yet
    if ( d->ticks_left() < d->num_ticks() && !p()->buff.bladestorm->up() )
    {
      make_event( sim, [ d ] { d->cancel(); } );
      return;
    }

    warrior_attack_t::tick( d );
    // As of TWW, since bladestorm has an initial tick, unhinged procs on odd ticks
    if ( ( mortal_strike || bloodthirst || bloodbath ) && ( d->current_tick % 2 == 1 ) )
    {
      auto t = p() -> target;
      if ( ! p() -> target || p() -> target->is_sleeping() )
        t = select_random_target();

      if ( t )
      {
        if ( mortal_strike )
          mortal_strike->execute_on_target( t );
        if ( bloodthirst || bloodbath )
        {
          if ( bloodbath && p()->talents.fury.reckless_abandon->ok() && p()->buff.recklessness->check() )
            bloodbath->execute_on_target( t );
          else
            bloodthirst->execute_on_target( t );
        }
      }
    }

    bladestorm_mh->execute();

    if ( bladestorm_mh->result_is_hit( execute_state->result ) && bladestorm_oh )
    {
      bladestorm_oh->execute();
    }
  }

  void last_tick( dot_t* d ) override
  {
    warrior_attack_t::last_tick( d );
    p()->buff.bladestorm->expire();

    if ( p()->talents.slayer.imminent_demise->ok() && p()->talents.shared.sudden_death->ok() )
      p()->buff.imminent_demise->expire();

    if ( p()->talents.slayer.brutal_finish->ok() )
      p()->buff.brutal_finish->trigger();

    if ( p()->talents.slayer.violent_euphoria->ok() )
      p()->buff.violent_euphoria->trigger();
  }
};

// Charge ===================================================================

struct charge_t : public warrior_attack_t
{
  // Split the damage, resource gen and other triggered effects from the movement part of Charge
  struct charge_impact_t : public warrior_attack_t
  {
    const spell_data_t* damage_spell;

    charge_impact_t( warrior_t* p ) :
      warrior_attack_t( "charge_impact", p, p -> spell.charge ),
      damage_spell( p->find_spell( 126664 ) )
    {
      background = true;
      cooldown->duration = 0_ms;

      energize_resource       = RESOURCE_RAGE;
      energize_type           = action_energize::ON_CAST;
      attack_power_mod.direct = damage_spell->effectN( 1 ).ap_coeff();
    }
  };

  bool first_charge;
  double movement_speed_increase, min_range;
  charge_t( warrior_t* p, util::string_view options_str )
    : warrior_attack_t( "charge", p, p->spell.charge ),
      first_charge( true ),
      movement_speed_increase( 5.0 ),
      min_range( data().min_range() )
  {
    parse_options( options_str );
    movement_directionality = movement_direction_type::OMNI;

    impact_action = new charge_impact_t( p );

    // Rage gen is handled in the impact action
    energize_amount = 0;
    energize_resource = RESOURCE_NONE;
  }

  timespan_t calc_charge_time( double distance )
  {
    return timespan_t::from_seconds( distance /
      ( p()->current.movement_speed * ( 1 + p()->stacking_movement_modifier() + movement_speed_increase ) ) );
  }

  void execute() override
  {
    if ( p()->current.distance_to_move > 5 )
    {
      p()->buff.charge_movement->trigger( 1, movement_speed_increase, 1, calc_charge_time( p()->current.distance_to_move ) );
      p()->current.moving_away = 0;
    }

    warrior_attack_t::execute();

  }

  void reset() override
  {
    warrior_attack_t::reset();
    first_charge = true;
  }

  bool ready() override
  {
    if ( first_charge )  // Assumes that we charge into combat, instead of setting initial distance to 20 yards.
    {
      return warrior_attack_t::ready();
    }
    if ( p()->current.distance_to_move < min_range )  // Cannot charge if too close to the target.
    {
      return false;
    }
    if ( p()->buff.charge_movement->check() || p()->buff.heroic_leap_movement->check() ||
         p()->buff.intervene_movement->check() || p() -> buff.shield_charge_movement->check() )
    {
      return false;
    }
    return warrior_attack_t::ready();
  }
};

// Slam =====================================================================
struct concussive_slam_t : public warrior_attack_t
{
  concussive_slam_t( util::string_view name, warrior_t* p )
    : warrior_attack_t( name, p, p->find_spell( 1300660 ) )
    {
      background = true;
      aoe = -1;
      reduced_aoe_targets = data().effectN( 2 ).base_value();
      target_filter_callback = secondary_targets_only();
    }
};

struct slam_base_t : public warrior_attack_t
{
  bool from_fervor;
  int aoe_targets;
  action_t* concussive_slam;
  slam_base_t( std::string_view n, warrior_t* p, const spell_data_t* s )
    : warrior_attack_t( n, p, s ), from_fervor( false ),
      aoe_targets( as<int>( p->spell.whirlwind_buff->effectN( 1 ).base_value() ) )
  {
    weapon                       = &( p->main_hand_weapon );
    radius = 5;
    proc_slayers_strike = true;
    if ( player->specialization() == WARRIOR_FURY )
    {
      base_aoe_multiplier = p->spell.whirlwind_buff->effectN( 2 ).percent();
    }

    if ( p->sets->has_set_bonus( WARRIOR_ARMS, MID2, B2 ) )
      concussive_slam = get_action<concussive_slam_t>( "concussive_slam", p );
  }

  slam_base_t( std::string_view n, warrior_t* p, const spell_data_t* s, std::string_view options_str )
    : slam_base_t( n, p, s )
  {
    parse_options( options_str );
  }

  double composite_da_multiplier( const action_state_t* state ) const override
  {
    double m = warrior_attack_t::composite_da_multiplier( state );
    if ( p()->talents.arms.fervor_of_battle.ok() && from_fervor )
    {
      m *= 1.0 + p()->talents.arms.fervor_of_battle->effectN( 2 ).percent();
    }
    return m;
  }

  int n_targets() const override
  {
    if ( p()->buff.whirlwind->check() )
    {
      return aoe_targets + 1;
    }
    return warrior_attack_t::n_targets();
  }

  double cost() const override
  {
    if ( from_fervor )
      return 0;

    return warrior_attack_t::cost();
  }

  void impact( action_state_t* state ) override
  {
    warrior_attack_t::impact( state );
    if ( !background && p()->talents.arms.master_of_warfare_1.ok() && !p()->buff.master_of_warfare_proc->up() && p()->rng().roll( master_of_warfare_proc_chance * ++p()->master_of_warfare_attempts_since_last_proc ) )
    {
      p()->buff.master_of_warfare_proc->trigger();
      p()->master_of_warfare_attempts_since_last_proc = 0;
    }

    if ( state->result == RESULT_CRIT && p()->talents.arms.mortal_wounds->ok() && sim->dbc->wowv() >= wowv_t( 12, 0, 5 ) )
      p()->active.deep_wounds->execute_on_target( state->target );
  }

  void execute() override
  {
    warrior_attack_t::execute();

    if ( was_replaced )
      return;

    p()->buff.whirlwind->decrement();

    if ( p()->talents.arms.martial_prowess.ok() )
      p()->buff.martial_prowess->trigger();

    if ( p()->sets->has_set_bonus( WARRIOR_ARMS, MID2, B2 ) )
      concussive_slam->execute();

    if ( p()->sets->has_set_bonus( WARRIOR_ARMS, MID2, B4 ) && p()->buff.winding_up->up() )
      p()->buff.winding_up->expire();
  }

  bool ready() override
  {
    if ( p()->main_hand_weapon.type == WEAPON_NONE )
    {
      return false;
    }
    return warrior_attack_t::ready();
  }
};

struct heroic_strike_t : public slam_base_t
{
  heroic_strike_t( warrior_t* p, std::string_view options_str )
    : slam_base_t( "heroic_strike", p, p->spell.heroic_strike, options_str )
  {

  }

  heroic_strike_t( std::string_view name, warrior_t* p )
    : slam_base_t( name, p, p->spell.heroic_strike )
  {
    background = true;
  }

  void execute() override
  {
    slam_base_t::execute();

    p()->buff.master_of_warfare_proc->expire();
    p()->buff.master_of_warfare->trigger();

    if ( p()->talents.arms.master_of_warfare_3.ok() )
      p()->buff.heroic_might_accumulator->trigger();
  }

  bool ready() override
  {
    if ( !p()->buff.master_of_warfare_proc->up() )
      return false;

    return slam_base_t::ready();
  }
};

struct slam_t : public slam_base_t
{
  slam_t( warrior_t* p, std::string_view options_str )
    : slam_base_t( "slam", p, p->spell.slam )
  {
    parse_options( options_str );
    // If we have heroic strike used in the apl, re-use that one, if not, create a new one
    if ( p->find_action( "heroic_strike" ) )
      set_replacement_action( "heroic_strike", p->buff.master_of_warfare_proc );
    else
      set_replacement_action( new heroic_strike_t( p, options_str ), p->buff.master_of_warfare_proc );
  }

  slam_t( util::string_view name, warrior_t* p )
  : slam_base_t( name, p, p->spell.slam )
  {
    background = true;
    std::string heroic_strike_name = "heroic_strike_";
    if ( util::starts_with( name, "slam_") )
      heroic_strike_name += name.substr(5);
    else
      heroic_strike_name += name;
    set_replacement_action( get_action<heroic_strike_t>( heroic_strike_name, p ), p->buff.master_of_warfare_proc );
  }
};

// Cleave ===================================================================
struct cleave_t : public warrior_attack_t
{
  slam_t* fervor_slam;
  double cost_rage;
  double frothing_berserker_chance;
  double rage_from_frothing_berserker;
  action_t* reap_the_storm;
  warrior_attack_t* rend;
  cleave_t( warrior_t* p, util::string_view options_str )
    : warrior_attack_t( "cleave", p, p->talents.arms.cleave ),
    fervor_slam( nullptr ),
    frothing_berserker_chance( p->talents.warrior.frothing_berserker->proc_chance() ),
    rage_from_frothing_berserker( p->talents.warrior.frothing_berserker->effectN( 1 ).percent() ),
    reap_the_storm( nullptr ),
    rend( nullptr )
  {
    parse_options( options_str );
    weapon = &( player->main_hand_weapon );
    aoe = -1;
    reduced_aoe_targets = p->talents.arms.cleave->effectN( 2 ).base_value();

    proc_slayers_strike = true;
    proc_slayers_strike_per_target = true;

    if ( p->talents.arms.fervor_of_battle->ok() )
    {
      fervor_slam                               = new slam_t( "slam_cleave_fervor_of_battle", p );
      fervor_slam->from_fervor                  = true;
      add_child( fervor_slam );
    }
    if ( p->talents.slayer.reap_the_storm->ok() )
    {
      reap_the_storm = get_action<reap_the_storm_t>( "reap_the_storm_cleave", p );
      add_child( reap_the_storm );
    }

    if ( sim->dbc->wowv() >= wowv_t( 12, 1, 0 ) && p->talents.warrior.rend.ok() )
      rend = new rend_dot_t( p );
  }

  double composite_target_multiplier( player_t* target ) const override
  {
    double m = warrior_attack_t::composite_target_multiplier( target );
    if ( p()->talents.arms.mass_execution.ok() && target->health_percentage() < p()->talents.arms.mass_execution->effectN( 2 ).base_value() )
      m *= 1.0 + p()->talents.arms.mass_execution->effectN( 1 ).percent();
    return m;
  }

  double composite_da_multiplier( const action_state_t* state ) const override
  {
    double m = warrior_attack_t::composite_da_multiplier( state );

    if ( p()->talents.colossus.one_against_many->ok() )
    {
      m *= 1.0 + ( p()->talents.colossus.one_against_many->effectN( 1 ).percent() * std::min( state -> n_targets,  as<unsigned int>( p()->talents.colossus.one_against_many->effectN( 2 ).base_value() ) ) );
    }

    return m;
  }

  void impact( action_state_t* s ) override
  {
    warrior_attack_t::impact( s );

    auto target_data = td( s->target );

    if ( p()->sets->has_set_bonus( WARRIOR_ARMS, MID1, B4 ) &&
        target_data && target_data->debuffs_colossus_smash->up() &&
        s->n_targets >= p()->sets->set( WARRIOR_ARMS, MID1, B4 )->effectN( 2 ).base_value() )
    {
      target_data->debuffs_colossus_smash->extend_duration_or_trigger( p()->sets->set( WARRIOR_ARMS, MID1, B4 )->effectN( 1 ).time_value() );
    }

    if ( rend && p()->dbc->wowv() >= wowv_t( 12, 1, 0 ) && p()->talents.warrior.rend.ok() )
      rend->execute_on_target( s->target );
  }

  void execute() override
  {
    warrior_attack_t::execute();

    cost_rage = last_resource_cost;
    if ( p()->talents.warrior.frothing_berserker->ok() && rng().roll( frothing_berserker_chance ) )
    {
      p()->resource_gain(RESOURCE_RAGE, last_resource_cost * rage_from_frothing_berserker, p()->gain.frothing_berserker);
    }

    if ( p()->talents.arms.collateral_damage.ok() && p()->buff.collateral_damage->up()  )
      p()->buff.collateral_damage->expire();

    if ( p() -> talents.arms.fervor_of_battle.ok() && num_targets_hit >= p() -> talents.arms.fervor_of_battle -> effectN( 1 ).base_value() )
      fervor_slam->execute_on_target( target );

    if ( p()->talents.colossus.colossal_might->ok() && execute_state -> n_targets >= p()->talents.colossus.colossal_might->effectN( 1 ).base_value() )
    {
      if ( sim->dbc->wowv() < wowv_t( 12, 1, 0 ) && p()->talents.colossus.dominance_of_the_colossus->ok() && p()->buff.colossal_might->at_max_stacks() )
      {
        p()->cooldown.demolish->adjust( - timespan_t::from_seconds( p()->talents.colossus.dominance_of_the_colossus->effectN( 2 ).base_value() ) );
      }
      p()->buff.colossal_might->trigger();
    }

    if ( p()->talents.slayer.reap_the_storm->ok() )
    {
      if ( p()->cooldown.reap_the_storm_icd->is_ready() && execute_state->n_targets >= p()->talents.slayer.reap_the_storm->effectN( 2 ).base_value() && rng().roll( p()->talents.slayer.reap_the_storm->effectN( 3 ).percent() ) )
      {
        reap_the_storm->execute();
        p()->cooldown.reap_the_storm_icd->start();
      }
    }

    if( p()->buff.crushing_combo->up() )
    {
      p()->cooldown.cleave->reset( true );
      p()->buff.crushing_combo->decrement();
    }
  }
};

// Colossus Smash ===========================================================

struct colossus_smash_t : public warrior_attack_t
{
  colossus_smash_t( warrior_t* p, util::string_view options_str )
    : warrior_attack_t( "colossus_smash", p, p->talents.arms.colossus_smash )
  {
    parse_options( options_str );
    weapon = &( player->main_hand_weapon );
    aoe = -1;
    reduced_aoe_targets = p->talents.arms.colossus_smash->effectN( 3 ).base_value();
  }

  void impact( action_state_t* s ) override
  {
    warrior_attack_t::impact( s );

    if ( result_is_hit( s->result ) )
    {
      td( s->target )->debuffs_colossus_smash->trigger();
    }
  }

  void execute() override
  {
    warrior_attack_t::execute();

    if ( sim->dbc->wowv() >= wowv_t( 12, 1, 0 ) && p()->talents.arms.tactical_edge.ok() )
      p()->buff.sudden_death->trigger( as<int>( p()->talents.arms.tactical_edge->effectN( 1 ).base_value() ) );

    if ( p()->talents.arms.master_of_warfare_3.ok() && p()->buff.heroic_might_accumulator->up() )
    {
      p()->buff.heroic_might->trigger( p()->buff.heroic_might_accumulator->stack(), buff_t::DEFAULT_VALUE(), 1.0, p()->spell.colossus_smash_debuff->duration() );
      p()->buff.heroic_might_accumulator->expire();
    }

    if ( sim->dbc->wowv() < wowv_t( 12, 1, 0 ) && p()->talents.arms.tactical_edge.ok() )
      p()->buff.tactical_edge->trigger();

    if ( p()->talents.arms.crushing_combo.ok() )
      p()->buff.crushing_combo->trigger( p()->talents.arms.crushing_combo->effectN( 1 ).trigger()->max_stacks() );

    if ( p()->talents.arms.broad_strokes.ok() )
    {
      if ( sim->dbc->wowv() < wowv_t( 12, 1, 0 ) )
        p()->buff.sweeping_strikes->trigger( p()->spec.sweeping_strikes->max_stacks() );
      else if ( sim->dbc->wowv() >= wowv_t( 12, 1, 0 ) )
        p()->buff.sweeping_strikes->trigger( as<int>( p()->talents.arms.broad_strokes->effectN( 1 ).base_value() ) );
    }

    if ( p()->talents.arms.just_warming_up.ok() )
      p()->resource_gain(RESOURCE_RAGE, p()->talents.arms.just_warming_up->effectN( 1 ).resource( RESOURCE_RAGE ), p()->gain.just_warming_up );
  }
};

// Protection MID2 4pc ===========================================================
struct bloody_rebuke_dot_t : public warrior_attack_t
{
  bloody_rebuke_dot_t( warrior_t* p )
    : warrior_attack_t( "bloody_rebuke", p, p->find_spell( 1300690 ) )
  {
    background = tick_may_crit = true;
  }
};


// Deep Wounds ARMS ==============================================================
struct deep_wounds_t : public warrior_attack_t
{
  action_t* fueled_by_violence_heal;
  deep_wounds_t( warrior_t* p ) : warrior_attack_t( "deep_wounds", p, p->spell.deep_wounds_dot ),
  fueled_by_violence_heal( nullptr )
  {
    background = tick_may_crit = true;
    rolling_periodic           = true;

    if ( p->talents.shared.fueled_by_violence.ok() )
      fueled_by_violence_heal = get_action<fueled_by_violence_heal_t>( "fueled_by_violence", p );
  }

  void tick( dot_t* d ) override
  {
    warrior_attack_t::tick( d );

    if ( fueled_by_violence_heal && d->state->result_amount )
    {
      fueled_by_violence_heal->base_dd_min = fueled_by_violence_heal->base_dd_max = d->state->result_amount * p()->talents.shared.fueled_by_violence->effectN( 1 ).percent();
      fueled_by_violence_heal->execute();
    }
  }
};

// Demolish =================================================================

struct demolish_damage_t : public warrior_attack_t
{
  demolish_damage_t( util::string_view name, warrior_t* p,  const spell_data_t* demolish )
    : warrior_attack_t( name, p, demolish )
  {
    background = true;
    dual = true;
    // Third attack is aoe
    if ( data().id() == 440888 )
    {
      aoe = -1;
      reduced_aoe_targets = p->talents.colossus.demolish->effectN( 1 ).base_value();
    }
  }

  void impact( action_state_t* state ) override
  {
    warrior_attack_t::impact( state );

    if ( p()->talents.colossus.dominance_of_the_colossus->ok() && p()->buff.colossal_might->up() )
      td( state->target )->debuffs_wrecked->trigger( p()->buff.colossal_might->stack() );

    if ( data().id() == 440888 && p()->talents.colossus.decimator->ok() ) // Third Attack
      p()->active.deep_wounds->execute_on_target( state->target );
  }
};

struct demolish_t : public warrior_attack_t
{
  demolish_damage_t* demolish_first_attack;
  demolish_damage_t* demolish_second_attack;
  demolish_damage_t* demolish_third_attack;
  demolish_t( warrior_t* p, util::string_view options_str )
    : warrior_attack_t( "demolish", p, p->talents.colossus.demolish ),
      demolish_first_attack( nullptr ),
      demolish_second_attack( nullptr ),
      demolish_third_attack( nullptr )
    {
      parse_options( options_str );
      channeled = true;
      hasted_ticks = true;
      weapon = &( player->main_hand_weapon );
      demolish_first_attack = new demolish_damage_t( "demolish_first_attack", p, p->find_spell( 440884 ) );
      demolish_second_attack = new demolish_damage_t( "demolish_second_attack", p, p->find_spell( 440886 ) );
      demolish_third_attack = new demolish_damage_t( "demolish_third_attack", p, p->find_spell( 440888 ) );
      add_child( demolish_first_attack );
      add_child( demolish_second_attack );
      add_child( demolish_third_attack );
    }

  void tick( dot_t* d ) override
  {
    warrior_attack_t::tick( d );
    if ( d->current_tick == 1 )
    {
      demolish_first_attack->execute();
    }
    else if ( d->current_tick == 3 )
    {
      demolish_second_attack->execute();
    }
    else if ( d->current_tick == 8 )
    {
      demolish_third_attack->execute();
    }
  }

  void last_tick( dot_t* d ) override
  {
    warrior_attack_t::last_tick( d );
    p()->buff.colossal_might->expire();

    if ( p()->talents.colossus.celeritous_conclusion.ok() )
    {
      p()->buff.celeritous_conclusion_haste->trigger();
      p()->buff.celeritous_conclusion_crit->trigger();
    }
  }
};

// Demoralizing Shout =======================================================

struct demoralizing_shout_t : public warrior_attack_t
{
  demoralizing_shout_t( warrior_t* p, util::string_view options_str )
    : warrior_attack_t( "demoralizing_shout", p, p->talents.protection.demoralizing_shout )
  {
    parse_options( options_str );
    usable_while_channeling = true;
    aoe = -1;
  }

  void init_finished() override
  {
    warrior_attack_t::init_finished();

    gain = p()->gain.booming_voice;
  }

  void execute() override
  {
    warrior_attack_t::execute();

    if ( p()->talents.mountain_thane.snap_induction->ok() )
    {
      p()->buff.thunder_blast->trigger();
    }
  }

  void impact( action_state_t* s ) override
  {
    warrior_attack_t::impact( s );
    td( s->target ) -> debuffs_demoralizing_shout -> trigger(
      1, data().effectN( 1 ).percent(), 1.0, p()->talents.protection.demoralizing_shout->duration()  );
  }
};

// Thunder Clap =============================================================
struct thunder_blast_t : public warrior_attack_t
{
  double rage_gain;
  double shield_slam_reset;
  warrior_attack_t* rend;
  action_t* lightning_strike;
  thunder_blast_t( warrior_t* p, util::string_view options_str )
    : warrior_attack_t( "thunder_blast", p, p->find_spell( 435222 ) ),
      rage_gain( data().effectN( 4 ).resource( RESOURCE_RAGE ) ),
      shield_slam_reset( p->talents.protection.strategist->effectN( 1 ).percent() ),
      rend( nullptr ),
      lightning_strike( nullptr )
  {
    parse_options( options_str );
    aoe       = -1;
    may_dodge = may_parry = may_block = false;

    // Shared cooldown with thunder clap
    cooldown = p->cooldown.thunder_clap;

    energize_type = action_energize::NONE;

    if ( sim->dbc->wowv() < wowv_t( 12, 1, 0 ) && p->talents.warrior.rend.ok() )
      rend = new rend_dot_t( p );

    // Protection
    if ( sim->dbc->wowv() >= wowv_t( 12, 1, 0 ) && p->talents.warrior.blood_and_thunder.ok() )
      rend = new rend_dot_t( p );

    // Fury
    if ( sim->dbc->wowv() >= wowv_t( 12, 1, 0 ) && p->talents.warrior.storm_of_blood.ok() && p->talents.mountain_thane.crashing_thunder.ok() )
      rend = new rend_dot_t( p );

    if ( p->talents.mountain_thane.lightning_strikes->ok() )
    {
      lightning_strike = get_action<lightning_strike_t>( "lightning_strike_thunder_blast", p );
      add_child( lightning_strike );
    }

    if ( p->talents.protection.strategist->ok() )
    {
      // For some reason on PTR strategist is referencing shield slam reset chance from devastator
      shield_slam_reset = p->spell.devastator->effectN( 2 ).percent();
    }
  }

  double composite_da_multiplier( const action_state_t* state ) const override
  {
    double m = warrior_attack_t::composite_da_multiplier( state );
    if ( p()->talents.fury.meat_cleaver->ok() && p()->talents.mountain_thane.crashing_thunder.ok() &&
          p()->sim->target_non_sleeping_list.size() >= p()->talents.fury.meat_cleaver->effectN( 2 ).base_value() )
      m *= 1.0 + p()->talents.fury.meat_cleaver->effectN( 1 ).percent();
    return m;
  }

  void execute() override
  {
    warrior_attack_t::execute();

    if ( rng().roll( shield_slam_reset ) )
    {
      p()->cooldown.shield_slam->reset( true );
    }

    if ( p()->talents.protection.thunderlord.ok() )
    {
      p()->cooldown.demoralizing_shout->adjust(
          -p()->talents.protection.thunderlord->effectN( 1 ).time_value() *
          std::min( execute_state->n_targets,
                    as<unsigned int>( p()->talents.protection.thunderlord->effectN( 2 ).base_value() ) ) );
    }

    auto total_rage_gain = rage_gain;

    p()->resource_gain( RESOURCE_RAGE, total_rage_gain, p()->gain.thunder_blast, this );

    if ( p()->talents.mountain_thane.crashing_thunder.ok() )
    {
      if ( p()->talents.fury.improved_whirlwind->ok() )
      {
        p()->buff.whirlwind->trigger( p()->buff.whirlwind->max_stack() );
      }
    }

    if ( p()->talents.mountain_thane.lightning_strikes->ok() )
    {
      auto chance = p()->talents.mountain_thane.lightning_strikes->effectN( 1 ).percent();
      if ( p()->buff.avatar->check() )
        chance *= 1.0 + p()->talents.mountain_thane.lightning_strikes->effectN( 2 ).percent();
      if ( rng().roll( chance ) )
      {
        lightning_strike->execute();
      }
    }

    if ( p()->talents.mountain_thane.flashing_skies->ok() )
    {
      lightning_strike->execute();
    }

    p()->buff.thunder_blast->decrement();

    if ( p()->talents.mountain_thane.capacitance->ok() && p()->buff.avatar->up() )
      p()->buff.avatar->extend_duration_or_trigger( p()->talents.mountain_thane.capacitance->effectN( 1 ).time_value() );

    if ( p()->talents.protection.phalanx_1.ok() )
      p()->buff.phalanx->trigger();
  }

  void impact( action_state_t* state ) override
  {
    warrior_attack_t::impact( state );

    if ( sim->dbc->wowv() < wowv_t( 12, 1, 0 ) && p()->talents.warrior.rend.ok() && rend )
      rend->execute_on_target( state->target );

    // Protection
    if ( sim->dbc->wowv() >= wowv_t( 12, 1, 0 ) && p()->talents.warrior.blood_and_thunder.ok() && rend )
      rend->execute_on_target( state->target );

    // Fury Mountain Thane
    if ( sim->dbc->wowv() >= wowv_t( 12, 1, 0 ) && p()->talents.warrior.storm_of_blood.ok() && p()->talents.mountain_thane.crashing_thunder.ok() && rend )
      rend->execute_on_target( state->target );
  }

  bool ready() override
  {
    if ( ! p()->buff.thunder_blast->check() && !background )
      return false;
    // Thunderclap is required.  TODO check if you need TC if it's a background action
    if ( ! p()->talents.warrior.thunder_clap->ok() && !background )
      return false;
    return warrior_attack_t::ready();
  }
};

struct thunder_clap_t : public warrior_attack_t
{
  double rage_gain;
  double shield_slam_reset;
  warrior_attack_t* rend;
  action_t* lightning_strike;
  thunder_clap_t( warrior_t* p, util::string_view options_str )
    : warrior_attack_t( "thunder_clap", p, p->talents.warrior.thunder_clap ),
      rage_gain( data().effectN( 4 ).resource( RESOURCE_RAGE ) ),
      shield_slam_reset( p->talents.protection.strategist->effectN( 1 ).percent() ),
      rend( nullptr ),
      lightning_strike( nullptr )
  {
    parse_options( options_str );
    aoe       = -1;
    may_dodge = may_parry = may_block = false;

    cooldown = p->cooldown.thunder_clap;

    energize_type = action_energize::NONE;

    if ( sim->dbc->wowv() < wowv_t( 12, 1, 0 ) && p->talents.warrior.rend.ok() )
      rend = new rend_dot_t( p );

    // Protection
    if ( sim->dbc->wowv() >= wowv_t( 12, 1, 0 ) && p->talents.warrior.blood_and_thunder.ok() )
      rend = new rend_dot_t( p );

    // Fury
    if ( sim->dbc->wowv() >= wowv_t( 12, 1, 0 ) && p->talents.warrior.storm_of_blood.ok() && p->talents.mountain_thane.crashing_thunder.ok() )
      rend = new rend_dot_t( p );

    if ( p->talents.mountain_thane.lightning_strikes->ok() )
    {
      lightning_strike = get_action<lightning_strike_t>( "lightning_strike_thunder_clap", p );
      add_child( lightning_strike );
    }

    if ( p->talents.protection.strategist->ok() )
    {
      // For some reason on PTR strategist is referencing shield slam reset chance from devastator
      shield_slam_reset = p->spell.devastator->effectN( 2 ).percent();
    }
  }

  double composite_da_multiplier( const action_state_t* state ) const override
  {
    double m = warrior_attack_t::composite_da_multiplier( state );
    if ( p()->talents.fury.meat_cleaver->ok() && p()->talents.mountain_thane.crashing_thunder.ok() &&
          p()->sim->target_non_sleeping_list.size() >= p()->talents.fury.meat_cleaver->effectN( 2 ).base_value() )
      m *= 1.0 + p()->talents.fury.meat_cleaver->effectN( 1 ).percent();
    return m;
  }

  void execute() override
  {
    warrior_attack_t::execute();

    if ( rng().roll( shield_slam_reset ) )
    {
      p()->cooldown.shield_slam->reset( true );
    }

    if ( p()->talents.protection.thunderlord.ok() )
    {
      p()->cooldown.demoralizing_shout->adjust(
          -p()->talents.protection.thunderlord->effectN( 1 ).time_value() *
          std::min( execute_state->n_targets,
                    as<unsigned int>( p()->talents.protection.thunderlord->effectN( 2 ).base_value() ) ) );
    }

    auto total_rage_gain = rage_gain;

    p()->resource_gain( RESOURCE_RAGE, total_rage_gain, p()->gain.thunder_clap, this );

    if ( p()->talents.mountain_thane.crashing_thunder.ok() )
    {
      if ( p()->talents.fury.improved_whirlwind->ok() )
      {
        p()->buff.whirlwind->trigger( p()->buff.whirlwind->max_stack() );
      }
    }

    if ( p()->talents.mountain_thane.lightning_strikes->ok() )
    {
      auto chance = p()->talents.mountain_thane.lightning_strikes->effectN( 1 ).percent();
      if ( p()->buff.avatar->check() )
        chance *= 1.0 + p()->talents.mountain_thane.lightning_strikes->effectN( 2 ).percent();
      if ( rng().roll( chance ) )
      {
        lightning_strike->execute();
      }
    }

    if ( p()->talents.protection.phalanx_1.ok() )
      p()->buff.phalanx->trigger();
  }

  void impact( action_state_t* state ) override
  {
    warrior_attack_t::impact( state );

    if ( sim->dbc->wowv() < wowv_t( 12, 1, 0 ) && p()->talents.warrior.rend.ok() && rend )
      rend->execute_on_target( state->target );

    // Protection
    if ( sim->dbc->wowv() >= wowv_t( 12, 1, 0 ) && p()->talents.warrior.blood_and_thunder.ok() && rend )
      rend->execute_on_target( state->target );

    // Fury Mountain Thane
    if ( sim->dbc->wowv() >= wowv_t( 12, 1, 0 ) && p()->talents.warrior.storm_of_blood.ok() && p()->talents.mountain_thane.crashing_thunder.ok() && rend )
      rend->execute_on_target( state->target );
  }

  bool ready() override
  {
    if ( p()->buff.thunder_blast->check() && !background )
      return false;
    return warrior_attack_t::ready();
  }
};

// Arms Execute ==================================================================

struct finishing_wound_t : public residual_action::residual_periodic_action_t<warrior_attack_t>
{
  finishing_wound_t( util::string_view name, warrior_t* p ) :
    base_t( name, p, p->find_spell( 426284 ) )
  {
    dual = true;
  }
};

struct execute_damage_t : public warrior_attack_t
{
  double max_rage;
  double cost_rage;
  finishing_wound_t* finishing_wound;
  execute_damage_t( warrior_t* p, util::string_view options_str )
    : warrior_attack_t( "execute_damage", p, p->spell.execute->effectN( 1 ).trigger() ), max_rage( 40 ),
    finishing_wound( nullptr )
  {
    parse_options( options_str );
    weapon = &( p->main_hand_weapon );
    background = true;
    finishing_wound = new finishing_wound_t( "finishing_wound", p);
    add_child( finishing_wound );

    if ( p->talents.protection.heavy_handed->ok() )
    {
      base_aoe_multiplier = p->talents.protection.heavy_handed->effectN( 2 ).percent();
    }
  }

  double action_multiplier() const override
  {
    double am = warrior_attack_t::action_multiplier();

    if ( cost_rage == 0 )  // If it was free, it's a full damage execute.
      am *= 2.0;
    else
      am *= 2.0 * ( std::min( max_rage, cost_rage ) / max_rage );
    return am;
  }

  void impact( action_state_t* state ) override
  {
    warrior_attack_t::impact( state );

    if ( p()->talents.shared.deep_wounds->ok() )
      p()->active.deep_wounds->execute_on_target( state->target );

    if( p()->talents.arms.fatality.ok() && td( state->target )->debuffs_fatal_mark->check() )
      p()->active.fatality->execute_on_target( state->target );

    if ( p()->talents.arms.master_of_warfare_1.ok() && !p()->buff.master_of_warfare_proc->up() &&
         p()->rng().roll( master_of_warfare_proc_chance * ++p()->master_of_warfare_attempts_since_last_proc ) )
    {
      p()->buff.master_of_warfare_proc->trigger();
      p()->master_of_warfare_attempts_since_last_proc = 0;
    }
  }
};

struct execute_arms_t : public warrior_attack_t
{
  execute_damage_t* trigger_attack;
  action_t* lightning_strike;
  action_t* slayers_strike;
  action_t* reap_the_storm;
  double max_rage;
  double execute_pct;
  double shield_slam_reset;
  execute_arms_t( warrior_t* p, util::string_view options_str )
    : warrior_attack_t( "execute", p, p->spell.execute ),
    trigger_attack( nullptr ),
    lightning_strike( nullptr ),
    slayers_strike( nullptr ),
    reap_the_storm( nullptr ),
    max_rage( 40 ),
    execute_pct( 20 ),
    shield_slam_reset( p -> talents.protection.strategist -> effectN( 1 ).percent() )
  {
    parse_options( options_str );
    weapon        = &( p->main_hand_weapon );

    trigger_attack = new execute_damage_t( p, options_str );
    trigger_attack->proc_slayers_strike = true;
    add_child( trigger_attack );

    if ( p->talents.arms.massacre->ok() )
    {
      execute_pct = p->talents.arms.massacre->effectN( 2 )._base_value;
    }
    if ( p->talents.protection.massacre->ok() )
    {
      execute_pct = p->talents.protection.massacre->effectN( 2 ).base_value();
    }

    if ( p->talents.mountain_thane.lightning_strikes->ok() )
    {
      lightning_strike = get_action<lightning_strike_t>( "lightning_strike_execute", p );
      add_child( lightning_strike );
    }

    if ( p->talents.protection.strategist->ok() )
    {
      // For some reason on PTR strategist is referencing shield slam reset chance from devastator
      shield_slam_reset = p->spell.devastator->effectN( 2 ).percent();
    }

    if ( p->talents.slayer.reap_the_storm->ok() && p->talents.slayer.imminent_demise.ok() )
    {
      reap_the_storm = get_action<reap_the_storm_t>( "reap_the_storm_execute", p );
      add_child( reap_the_storm );
    }
  }

  double cost() const override
  {
    double c = warrior_attack_t::cost();
    c        = std::min( max_rage, std::max( p()->resources.current[ RESOURCE_RAGE ], c ) );

    if ( p()->buff.sudden_death->check() )
    {
      return 0;  // The cost reduction isn't in the spell data
    }
    return c;
  }

  void execute() override
  {
    warrior_attack_t::execute();

    trigger_attack->cost_rage = last_resource_cost;
    trigger_attack->execute();
    if ( p()->talents.arms.improved_execute->ok() && !p()->talents.arms.critical_thinking->ok() )
    {
      p()->resource_gain( RESOURCE_RAGE, last_resource_cost * p()->spell.execute_rage_refund->effectN( 2 ).percent(),
                          p()->gain.execute_refund );  // Not worth the trouble to check if the target died.
    }
    if ( p()->talents.arms.improved_execute->ok() && p()->talents.arms.critical_thinking->ok() )
    {
      p()->resource_gain( RESOURCE_RAGE, last_resource_cost * ( p()->talents.arms.critical_thinking->effectN( 2 ).percent() +
                                                 p()->spell.execute_rage_refund->effectN( 2 ).percent() ),
                          p()->gain.execute_refund );  // Not worth the trouble to check if the target died.
    }

    if ( p()->buff.sudden_death->up() )
    {
      p()->buff.sudden_death->decrement();

      if ( p()->talents.slayer.imminent_demise->ok() && p()->talents.shared.sudden_death->ok() )
        p()->buff.imminent_demise->trigger();

      if ( p()->talents.slayer.reap_the_storm->ok() && p()->talents.slayer.imminent_demise.ok() &&
            p()->cooldown.reap_the_storm_icd->is_ready() && rng().roll( p()->talents.slayer.imminent_demise->effectN( 2 ).percent() ) )
      {
        reap_the_storm->execute();
        p()->cooldown.reap_the_storm_icd->start();
      }

      if ( p()->talents.slayer.unrelenting_onslaught->ok() && p()->buff.executioner->up() )
      {
          p()->cooldown.bladestorm->adjust( - ( timespan_t::from_seconds( p()->talents.slayer.unrelenting_onslaught->effectN( 1 ).base_value() * p()->buff.executioner->stack() ) ) );
          td( p()->target )->debuffs_overwhelmed->trigger( as<int>( p()->talents.slayer.unrelenting_onslaught->effectN( 2 ).base_value() ) * p()->buff.executioner->stack() );
      }
    }

    if ( rng().roll( shield_slam_reset ) )
    {
      p()->cooldown.shield_slam->reset( true );
    }

    if ( p()->talents.mountain_thane.lightning_strikes->ok() )
    {
      auto chance = p()->talents.mountain_thane.lightning_strikes->effectN( 1 ).percent();
      if ( p()->buff.avatar->check() )
        chance *= 1.0 + p()->talents.mountain_thane.lightning_strikes->effectN( 2 ).percent();
      if ( rng().roll( chance ) )
      {
        lightning_strike->execute();
      }
    }

    if ( p()->talents.arms.executioners_precision.ok() )
      p()->buff.executioners_precision->trigger();
  }

  bool target_ready( player_t* candidate_target ) override
  {
    // Sudden Death allow execution on any target
    bool always = p()->buff.sudden_death->check();

    if ( ! always && candidate_target->health_percentage() > execute_pct )
    {
      return false;
    }

    return warrior_attack_t::target_ready( candidate_target );
  }

};

// Fatality ===============================================================================
struct fatality_t : public warrior_attack_t
{
  fatality_t( warrior_t* p ) : warrior_attack_t( "fatality", p, p->find_spell( 383706 ) )
  {
    background = true;
    may_crit   = false;
  }

  double composite_target_multiplier( player_t* target ) const override
  {
    double m = warrior_attack_t::composite_target_multiplier( target );
    m *= td( target )->debuffs_fatal_mark->stack();
    return m;
  }

  void impact( action_state_t* state ) override
  {
    warrior_attack_t::impact( state );
    td( state->target )->debuffs_fatal_mark->expire();
  }
};

// Fury Execute ======================================================================
struct execute_main_hand_t : public warrior_attack_t
{
  int aoe_targets;
  execute_main_hand_t( warrior_t* p, const char* name, const spell_data_t* s )
    : warrior_attack_t( name, p, s ),
      aoe_targets( as<int>( p->spell.whirlwind_buff->effectN( 1 ).base_value() ) )
  {
    background = true;
    dual   = true;
    weapon = &( p->main_hand_weapon );
    radius = 5;
    proc_slayers_strike = true;
    base_aoe_multiplier = p->spell.whirlwind_buff->effectN( 2 ).percent();
  }

  int n_targets() const override
  {
    if ( p()->buff.whirlwind->check() )
    {
      return aoe_targets + 1;
    }
    return warrior_attack_t::n_targets();
  }

  void impact( action_state_t* state ) override
  {
    warrior_attack_t::impact( state );

    if( p()->talents.shared.deep_wounds->ok() )
      p()->active.deep_wounds->execute_on_target( state->target );
  }
};

struct execute_off_hand_t : public warrior_attack_t
{
  int aoe_targets;
  execute_off_hand_t( warrior_t* p, const char* name, const spell_data_t* s )
    : warrior_attack_t( name, p, s ),
      aoe_targets( as<int>( p->spell.whirlwind_buff->effectN( 1 ).base_value() ) )
  {
    background = true;
    dual     = true;
    may_miss = may_dodge = may_parry = may_block = false;
    weapon                                       = &( p->off_hand_weapon );
    radius = 5;
    base_aoe_multiplier = p->spell.whirlwind_buff->effectN( 2 ).percent();
  }

  int n_targets() const override
  {
    if ( p()->buff.whirlwind->check() )
    {
      return aoe_targets + 1;
    }
    return warrior_attack_t::n_targets();
  }
};

struct execute_fury_t : public warrior_attack_t
{
  execute_main_hand_t* mh_attack;
  execute_off_hand_t* oh_attack;
  action_t* lightning_strike;
  action_t* slayers_strike;
  action_t* reap_the_storm;
  bool improved_execute;
  double execute_pct;
  //double cost_rage;
  double max_rage;
  execute_fury_t( warrior_t* p, util::string_view options_str )
    : warrior_attack_t( "execute", p, p->spec.execute ),
      mh_attack( nullptr ),
      oh_attack( nullptr ),
      lightning_strike( nullptr ),
      slayers_strike( nullptr ),
      reap_the_storm( nullptr ),
      improved_execute( false ),
      execute_pct( 20 ),
      max_rage( 40 )
  {
    parse_options( options_str );
    mh_attack = new execute_main_hand_t( p, "execute_mainhand", p->spec.execute->effectN( 1 ).trigger() );
    oh_attack = new execute_off_hand_t( p, "execute_offhand", p->spec.execute->effectN( 2 ).trigger() );
    add_child( mh_attack );
    add_child( oh_attack );

    if ( p->talents.fury.massacre->ok() )
    {
      execute_pct = p->talents.fury.massacre->effectN( 2 ).base_value();
      if ( cooldown->action == this )
      {
        cooldown -> duration -= timespan_t::from_millis( p -> talents.fury.massacre -> effectN( 3 ).base_value() );
      }
    }

    if ( p->talents.mountain_thane.lightning_strikes->ok() )
    {
      lightning_strike = get_action<lightning_strike_t>( "lightning_strike_execute", p );
      add_child( lightning_strike );
    }

    if ( p->talents.slayer.reap_the_storm->ok() && p->talents.slayer.imminent_demise.ok() )
    {
      reap_the_storm = get_action<reap_the_storm_t>( "reap_the_storm_execute", p );
      add_child( reap_the_storm );
    }
  }

  void execute() override
  {
    warrior_attack_t::execute();

    mh_attack->execute();

    if ( p()->specialization() == WARRIOR_FURY && result_is_hit( execute_state->result ) &&
         p()->off_hand_weapon.type != WEAPON_NONE )
      // If MH fails to land, or if there is no OH weapon for Fury, oh attack does not execute.
      oh_attack->execute();

    p()->buff.whirlwind->decrement();
    if ( p() -> buff.sudden_death -> up() )
    {
      p()->buff.sudden_death->decrement();

      if ( p()->talents.slayer.imminent_demise->ok() && p()->talents.shared.sudden_death->ok() )
        p()->buff.imminent_demise->trigger();

      if ( p()->talents.slayer.reap_the_storm->ok() && p()->talents.slayer.imminent_demise.ok() &&
            p()->cooldown.reap_the_storm_icd->is_ready() && rng().roll( p()->talents.slayer.imminent_demise->effectN( 2 ).percent() ) )
      {
        reap_the_storm->execute();
        p()->cooldown.reap_the_storm_icd->start();
      }

      if ( p()->talents.slayer.unrelenting_onslaught->ok() && p()->buff.executioner->up() )
      {
        p()->cooldown.bladestorm->adjust( - ( timespan_t::from_seconds( p()->talents.slayer.unrelenting_onslaught->effectN( 1 ).base_value() * p()->buff.executioner->stack() ) ) );
        td( p()->target )->debuffs_overwhelmed->trigger( as<int>( p()->talents.slayer.unrelenting_onslaught->effectN( 2 ).base_value() ) * p()->buff.executioner->stack() );
      }
    }

    if ( p()->talents.mountain_thane.lightning_strikes->ok() )
    {
      auto chance = p()->talents.mountain_thane.lightning_strikes->effectN( 1 ).percent();
      if ( p()->buff.avatar->check() )
        chance *= 1.0 + p()->talents.mountain_thane.lightning_strikes->effectN( 2 ).percent();
      if ( rng().roll( chance ) )
      {
        lightning_strike->execute();
      }
    }

    if ( p()->talents.fury.executioners_wrath->ok() )
      p()->buff.executioners_wrath->trigger();
  }

  bool target_ready( player_t* candidate_target ) override
  {
    // Sudden Death allow execution on any target
    bool always = p()->buff.sudden_death->check();

    if ( ! always && candidate_target->health_percentage() > execute_pct )
    {
      return false;
    }

    return warrior_attack_t::target_ready( candidate_target );
  }
};

// Hamstring ==============================================================

struct hamstring_t : public warrior_attack_t
{
  int aoe_targets;
  hamstring_t( warrior_t* p, util::string_view options_str ) : warrior_attack_t( "hamstring", p, p->spell.hamstring ),
  aoe_targets( as<int>( p->spell.whirlwind_buff->effectN( 1 ).base_value() ) )
  {
    parse_options( options_str );
    weapon = &( p->main_hand_weapon );

    radius = 5;
    base_aoe_multiplier = p->spell.whirlwind_buff->effectN( 2 ).percent();
  }

  int n_targets() const override
  {
    if ( p()->buff.whirlwind->check() )
    {
      return aoe_targets + 1;
    }
    return warrior_attack_t::n_targets();
  }

  void execute() override
  {
    warrior_attack_t::execute();
    p() -> buff.whirlwind->decrement();
  }
};

// Piercing Howl ==============================================================

struct piercing_howl_t : public warrior_attack_t
{
  piercing_howl_t( warrior_t* p, util::string_view options_str )
    : warrior_attack_t( "piercing_howl", p, p->talents.warrior.piercing_howl )
  {
    parse_options( options_str );
  }
};

// Heroic Throw ==============================================================

struct heroic_throw_t : public warrior_attack_t
{
  heroic_throw_t( warrior_t* p, util::string_view options_str )
    : warrior_attack_t( "heroic_throw", p, p->find_class_spell( "Heroic Throw" ) )
  {
    parse_options( options_str );

    weapon    = &( player->main_hand_weapon );
    may_dodge = may_parry = may_block = false;
  }

  bool ready() override
  {
    if ( p()->current.distance_to_move > range ||
         p()->current.distance_to_move < data().min_range() )  // Cannot heroic throw unless target is in range.
    {
      return false;
    }
    if ( p()->main_hand_weapon.type == WEAPON_NONE )
    {
      return false;
    }
    return warrior_attack_t::ready();
  }
};

// Heroic Leap ==============================================================

struct heroic_leap_t : public warrior_attack_t
{
  const spell_data_t* heroic_leap_damage;
  heroic_leap_t( warrior_t* p, util::string_view options_str )
    : warrior_attack_t( "heroic_leap", p, p->talents.warrior.heroic_leap ),
      heroic_leap_damage( p->find_spell( 52174 ) )
  {
    parse_options( options_str );
    ignore_false_positive = true;
    aoe                   = -1;
    may_dodge = may_parry = may_miss = may_block = false;
    movement_directionality                      = movement_direction_type::OMNI;
    base_teleport_distance                       = data().max_range();
    range                                        = -1;
    attack_power_mod.direct                      = heroic_leap_damage->effectN( 1 ).ap_coeff();
    radius                                       = heroic_leap_damage->effectN( 1 ).radius();

    // This bug is likely fixed in spelldata for 11.1 PTR.  Recheck after PTR is up.
    cooldown->duration = data().charge_cooldown();  // Fixes bug in spelldata for now.
  }

  // TOCHECK: Shouldn't this scale with distance to travel?
  timespan_t travel_time() const override
  {
    return timespan_t::from_seconds( 0.5 );
  }

  void execute() override
  {
    warrior_attack_t::execute();
    if ( p()->current.distance_to_move > 0 && !p()->buff.heroic_leap_movement->check() )
    {
      double speed = std::min( p()->current.distance_to_move, base_teleport_distance ) /
                     ( p()->current.movement_speed * ( 1 + p()->stacking_movement_modifier() ) ) /
                     travel_time().total_seconds();
      p()->buff.heroic_leap_movement->trigger( 1, speed, 1, travel_time() );
    }
  }

  bool ready() override
  {
    if ( p()->buff.intervene_movement->check() || p()->buff.charge_movement->check() ||
         p()->buff.shield_charge_movement->check() )
    {
      return false;
    }

    return warrior_attack_t::ready();
  }
};

// Impending Victory Heal ========================================================

struct impending_victory_heal_t : public warrior_heal_t
{
  impending_victory_heal_t( warrior_t* p ) : warrior_heal_t( "impending_victory_heal", p, p->find_spell( 202166 ) )
  {
    base_pct_heal = data().effectN( 1 ).percent();
    background    = true;
  }

  proc_types proc_type() const override
  {
    return PROC1_NONE_HELPFUL;
  }

  resource_e current_resource() const override
  {
    return RESOURCE_NONE;
  }
};

// Impending Victory ==============================================================

struct impending_victory_t : public warrior_attack_t
{
  impending_victory_heal_t* impending_victory_heal;
  int aoe_targets;
  impending_victory_t( warrior_t* p, util::string_view options_str )
    : warrior_attack_t( "impending_victory", p, p->talents.warrior.impending_victory ), impending_victory_heal( nullptr ),
    aoe_targets( as<int>( p->spell.whirlwind_buff->effectN( 1 ).base_value() ) )
  {
    parse_options( options_str );
    if ( p->non_dps_mechanics )
    {
      impending_victory_heal = new impending_victory_heal_t( p );
    }
    radius = 5;
    base_aoe_multiplier = p->spell.whirlwind_buff->effectN( 2 ).percent();
  }

  int n_targets() const override
  {
    if ( p()->buff.whirlwind->check() )
    {
      return aoe_targets + 1;
    }
    return warrior_attack_t::n_targets();
  }

  void execute() override
  {
    warrior_attack_t::execute();

    if ( impending_victory_heal )
    {
      impending_victory_heal->execute();
    }

    p() -> buff.whirlwind -> decrement();
  }
};

// Intervene ===============================================================
// Note: Conveniently ignores that you can only intervene a friendly target.
// For the time being, we're just going to assume that there is a friendly near the target
// that we can intervene to. Maybe in the future with a more complete movement system, we will
// fix this to work in a raid simulation that includes multiple melee.

struct intervene_t : public warrior_attack_t
{
  double movement_speed_increase;
  intervene_t( warrior_t* p, util::string_view options_str )
    : warrior_attack_t( "intervene", p, p->talents.warrior.intervene ), movement_speed_increase( 5.0 )
  {
    parse_options( options_str );
    ignore_false_positive   = true;
    movement_directionality = movement_direction_type::OMNI;
  }

  void execute() override
  {
    warrior_attack_t::execute();
    if ( p()->current.distance_to_move > 0 )
    {
      p()->buff.intervene_movement->trigger(
          1, movement_speed_increase, 1,
          timespan_t::from_seconds(
              p()->current.distance_to_move /
              ( p()->current.movement_speed * ( 1 + p()->stacking_movement_modifier() + movement_speed_increase ) ) ) );
      p()->current.moving_away = 0;
    }
  }

  bool ready() override
  {
    if ( p()->buff.heroic_leap_movement->check() || p()->buff.charge_movement->check() )
    {
      return false;
    }

    return warrior_attack_t::ready();
  }
};

// Heroic Charge ============================================================

struct heroic_charge_t : public warrior_attack_t
{
  //TODO: do actual movement for distance targeting sims
  warrior_attack_t* heroic_leap;
  charge_t* charge;
  int heroic_leap_distance;

  heroic_charge_t( warrior_t* p, util::string_view options_str ) :
    warrior_attack_t( "heroic_charge", p, spell_data_t::nil() ),
    heroic_leap( new heroic_leap_t( p, "" ) ),
    charge( new charge_t( p, "" ) ),
    heroic_leap_distance( 10 )
  {
    // The user can set the distance that they want to travel with heroic leap before charging if they want
    add_option( opt_int( "distance", heroic_leap_distance ) );
    parse_options( options_str );

    if ( heroic_leap_distance > heroic_leap -> data().max_range() ||
         heroic_leap_distance < heroic_leap -> data().min_range() )
    {
      sim -> error( "{} has an invalid heroic leap distance of {}, defaulting to 10", p -> name(), heroic_leap_distance );
      heroic_leap_distance = 10;
    }
    callbacks = false;
  }

  timespan_t execute_time() const override
  {
    // Execute time is equal to the sum of heroic leap's travel time (a fixed 0.5s atm)
    // and charge's time to travel based on heroic leap's distance travelled
    return heroic_leap -> travel_time() + charge -> calc_charge_time( heroic_leap_distance );
  }

  void execute() override
  {
    warrior_attack_t::execute();

    // At the end of the execution, start cooldowns, adjusted for execute time
    heroic_leap -> cooldown -> start( heroic_leap -> cooldown_duration() - execute_time() );
    charge -> cooldown -> start( charge -> cooldown_duration() - charge -> calc_charge_time( heroic_leap_distance ) );

    // Execute charge damage and whatever else it's supposed to proc
    charge -> impact_action -> execute();
  }

  bool ready() override
  {
    // TODO: Enable heroic leaping mid-movement while making sure it doesn't break anything
    if ( ! heroic_leap -> cooldown -> is_ready() || ! charge -> cooldown -> is_ready() ||
         p()->buffs.movement->check() || p() -> buff.heroic_leap_movement -> check() || p() -> buff.charge_movement -> check() )
    {
      return false;
    }
    return warrior_attack_t::ready();
  }
};

// Pummel ===================================================================

struct pummel_t : public warrior_attack_t
{
  pummel_t( warrior_t* p, util::string_view options_str )
    : warrior_attack_t( "pummel", p, p->find_class_spell( "Pummel" ) )
  {
    parse_options( options_str );
    ignore_false_positive = true;
    may_miss = may_block = may_dodge = may_parry = false;
    is_interrupt = true;
  }

  void impact( action_state_t* state ) override
  {
    warrior_attack_t::impact( state );

    if ( p()->talents.warrior.honed_reflexes->ok() )
      td( state->target )->debuffs_honed_reflexes->trigger();
  }

  bool target_ready( player_t* candidate_target ) override
  {
    if ( !candidate_target->debuffs.casting || !candidate_target->debuffs.casting->check() )
      return false;

    return warrior_attack_t::target_ready( candidate_target );
  }
};

// Raging Blow ==============================================================

struct raging_blow_attack_t : public warrior_attack_t
{
  int aoe_targets;
  raging_blow_attack_t( warrior_t* p, const char* name, const spell_data_t* s )
    : warrior_attack_t( name, p, s ),
    aoe_targets( as<int>( p->spell.whirlwind_buff->effectN( 1 ).base_value() ) )
  {
    may_miss = may_dodge = may_parry = may_block = false;
    dual                                         = true;
    background = true;
    proc_slayers_strike = true;

    base_aoe_multiplier = p->spell.whirlwind_buff->effectN( 2 ).percent();
  }

  int n_targets() const override
  {
    if ( p()->buff.whirlwind->check() )
    {
      return aoe_targets + 1;
    }
    return warrior_attack_t::n_targets();
  }

  double action_multiplier() const override
  {
    double am = warrior_attack_t::action_multiplier();

    if ( p()->talents.fury.cruelty->ok() && p()->buff.enrage->check() )
    {
      am *= 1.0 + p()->talents.fury.cruelty->effectN( 1 ).percent();
    }

    return am;
  }
};

struct raging_blow_t : public warrior_attack_t
{
  raging_blow_attack_t* mh_attack;
  raging_blow_attack_t* oh_attack;
  action_t* lightning_strike;
  double cd_reset_chance;
  double wrath_and_fury_reset_chance;
  bool opportunist_up;
  raging_blow_t( warrior_t* p, util::string_view options_str )
    : warrior_attack_t( "raging_blow", p, p->talents.fury.raging_blow ),
      mh_attack( nullptr ),
      oh_attack( nullptr ),
      lightning_strike( nullptr ),
      cd_reset_chance( p->talents.fury.raging_blow->effectN( 1 ).percent() ),
      wrath_and_fury_reset_chance( p->talents.fury.wrath_and_fury->effectN( 1 ).percent() ),
      opportunist_up( false )
  {
    parse_options( options_str );

    oh_attack         = new raging_blow_attack_t( p, "raging_blow_oh", p->talents.fury.raging_blow->effectN( 4 ).trigger() );
    oh_attack->weapon = &( p->off_hand_weapon );
    add_child( oh_attack );
    mh_attack         = new raging_blow_attack_t( p, "raging_blow_mh", p->talents.fury.raging_blow->effectN( 3 ).trigger() );
    mh_attack->weapon = &( p->main_hand_weapon );
    add_child( mh_attack );
    cooldown->reset( false );
    track_cd_waste = true;

    if ( p->talents.mountain_thane.lightning_strikes->ok() )
    {
      lightning_strike = get_action<lightning_strike_t>( "lightning_strike_raging_blow", p );
      add_child( lightning_strike );
    }
  }

  void init() override
  {
    warrior_attack_t::init();
    cooldown->hasted = true;
  }

  void execute() override
  {
    opportunist_up = p()->buff.opportunist->check();

    warrior_attack_t::execute();

    if ( result_is_hit( execute_state->result ) )
    {
      mh_attack->execute();
      oh_attack->execute();
    }

    p()->buff.opportunist->expire();

    if ( p()->talents.fury.improved_raging_blow->ok() && p()->talents.fury.wrath_and_fury->ok() &&
         p()->buff.enrage->check() )
    {
      if ( rng().roll( cd_reset_chance + wrath_and_fury_reset_chance ) )
      {
        cooldown->reset( true );
        // If opportunist was up when we used the skill, in game it refreshes, then fades.  For simc purposes, do not proc if we
        // cast with opportunist up.
        if ( p()->talents.slayer.opportunist->ok() && !opportunist_up )
          p()->buff.opportunist->trigger();

        if ( p()->talents.fury.surge_of_adrenaline->ok() )
          p()->buff.surge_of_adrenaline->trigger();
      }
    }
    else if ( p()->talents.fury.improved_raging_blow->ok() )
    {
      if ( rng().roll( cd_reset_chance ) )
      {
        cooldown->reset( true );
        // If opportunist was up when we used the skill, in game it refreshes, then fades.  For simc purposes, do not proc if we
        // cast with opportunist up.
        if ( p()->talents.slayer.opportunist->ok() && !opportunist_up )
          p()->buff.opportunist->trigger();

        if ( p()->talents.fury.surge_of_adrenaline->ok() )
          p()->buff.surge_of_adrenaline->trigger();
      }
    }
    p()->buff.whirlwind->decrement();

    if ( p()->talents.fury.bloodcraze->ok() )
    {
      p()->buff.bloodcraze->trigger();
    }

    if ( p()->talents.mountain_thane.lightning_strikes->ok() )
    {
      auto chance = p()->talents.mountain_thane.lightning_strikes->effectN( 1 ).percent();
      if ( p()->buff.avatar->check() )
        chance *= 1.0 + p()->talents.mountain_thane.lightning_strikes->effectN( 2 ).percent();
      if ( rng().roll( chance ) )
      {
        lightning_strike->execute();
      }
    }

    if ( p()->sets->has_set_bonus( WARRIOR_FURY, MID2, B2 ) && p()->buff.recklessness->up() &&
          p()->fury_mid2_2pc_extensions < as<int>( p()->sets->set( WARRIOR_FURY, MID2, B2 )->effectN( 3 ).base_value() ) )
    {
      p()->buff.recklessness->extend_duration_or_trigger( p()->sets->set( WARRIOR_FURY, MID2, B2 )->effectN( 2 ).time_value() );
      p()->fury_mid2_2pc_extensions++;
    }

    p()->buff.hack_and_slash->decrement();
  }

  bool ready() override
  {
    // Needs weapons in both hands
    if ( p()->main_hand_weapon.type == WEAPON_NONE || p()->off_hand_weapon.type == WEAPON_NONE )
    {
      return false;
    }

    if ( p()->talents.fury.reckless_abandon->ok() && p()->buff.recklessness->check() )
    {
      return false;
    }
    return warrior_attack_t::ready();
  }
};

// Crushing Blow ==============================================================

struct crushing_blow_attack_t : public warrior_attack_t
{
  int aoe_targets;
  crushing_blow_attack_t( warrior_t* p, const char* name, const spell_data_t* s )
    : warrior_attack_t( name, p, s ),
    aoe_targets( as<int>( p->spell.whirlwind_buff->effectN( 1 ).base_value() ) )
  {
    may_miss = may_dodge = may_parry = may_block = false;
    dual                                         = true;
    background = true;
    proc_slayers_strike = true;

    base_aoe_multiplier = p->spell.whirlwind_buff->effectN( 2 ).percent();
  }

  int n_targets() const override
  {
    if ( p()->buff.whirlwind->check() )
    {
      return aoe_targets + 1;
    }
    return warrior_attack_t::n_targets();
  }

  double action_multiplier() const override
  {
    double am = warrior_attack_t::action_multiplier();

    if ( p()->talents.fury.cruelty->ok() && p()->buff.enrage->check() )
    {
      am *= 1.0 + p()->talents.fury.cruelty->effectN( 1 ).percent();
    }

    return am;
  }
};

struct crushing_blow_t : public warrior_attack_t
{
  crushing_blow_attack_t* mh_attack;
  crushing_blow_attack_t* oh_attack;
  double cd_reset_chance;
  double wrath_and_fury_reset_chance;
  action_t* lightning_strike;
  bool opportunist_up;
  crushing_blow_t( warrior_t* p, util::string_view options_str )
    : warrior_attack_t( "crushing_blow", p, p->spec.crushing_blow ),
      mh_attack( nullptr ),
      oh_attack( nullptr ),
      cd_reset_chance( p->spec.crushing_blow->effectN( 1 ).percent() ),
      wrath_and_fury_reset_chance( p->talents.fury.wrath_and_fury->effectN( 1 ).percent() ),
      lightning_strike( nullptr ),
      opportunist_up( false )
  {
    parse_options( options_str );

    oh_attack         = new crushing_blow_attack_t( p, "crushing_blow_oh", p->spec.crushing_blow->effectN( 4 ).trigger() );
    oh_attack->weapon = &( p->off_hand_weapon );
    add_child( oh_attack );
    mh_attack         = new crushing_blow_attack_t( p, "crushing_blow_mh", p->spec.crushing_blow->effectN( 3 ).trigger() );
    mh_attack->weapon = &( p->main_hand_weapon );
    add_child( mh_attack );
    cooldown->reset( false );
    cooldown = p -> cooldown.raging_blow;
    track_cd_waste = true;

    if ( p->talents.mountain_thane.lightning_strikes->ok() )
    {
      lightning_strike = get_action<lightning_strike_t>( "lightning_strike_crushing_blow", p );
      add_child( lightning_strike );
    }
  }

  void init() override
  {
    warrior_attack_t::init();
    cooldown->hasted = true;
  }

  void execute() override
  {
    opportunist_up = p()->buff.opportunist->check();

    warrior_attack_t::execute();

    if ( result_is_hit( execute_state->result ) )
    {
      mh_attack->execute();
      oh_attack->execute();
    }

    p()->buff.opportunist->expire();

    if ( p()->talents.fury.improved_raging_blow->ok() && p()->talents.fury.wrath_and_fury->ok() &&
         p()->buff.enrage->check() )
    {
      if ( rng().roll( cd_reset_chance + wrath_and_fury_reset_chance ) )
      {
        cooldown->reset( true );
        // If opportunist was up when we used the skill, in game it refreshes, then fades.  For simc purposes, do not proc if we
        // cast with opportunist up.
        if ( p()->talents.slayer.opportunist->ok() && !opportunist_up )
          p()->buff.opportunist->trigger();

        if ( p()->talents.fury.surge_of_adrenaline->ok() )
          p()->buff.surge_of_adrenaline->trigger();
      }
    }
    else if ( p()->talents.fury.improved_raging_blow->ok() && rng().roll( cd_reset_chance ) )
    {
      cooldown->reset( true );
      // If opportunist was up when we used the skill, in game it refreshes, then fades.  For simc purposes, do not proc if we
      // cast with opportunist up.
      if ( p()->talents.slayer.opportunist->ok() && !opportunist_up )
        p()->buff.opportunist->trigger();

      if ( p()->talents.fury.surge_of_adrenaline->ok() )
        p()->buff.surge_of_adrenaline->trigger();
    }

    p()->buff.whirlwind->decrement();

    if ( p()->talents.fury.bloodcraze->ok() )
    {
      p()->buff.bloodcraze->trigger();
    }

    if ( p()->talents.mountain_thane.lightning_strikes->ok() )
    {
      auto chance = p()->talents.mountain_thane.lightning_strikes->effectN( 1 ).percent();
      if ( p()->buff.avatar->check() )
        chance *= 1.0 + p()->talents.mountain_thane.lightning_strikes->effectN( 2 ).percent();
      if ( rng().roll( chance ) )
      {
        lightning_strike->execute();
      }
    }

    if ( p()->sets->has_set_bonus( WARRIOR_FURY, MID2, B2 ) && p()->buff.recklessness->up() &&
      p()->fury_mid2_2pc_extensions < as<int>( p()->sets->set( WARRIOR_FURY, MID2, B2 )->effectN( 3 ).base_value() ) )
    {
      p()->buff.recklessness->extend_duration_or_trigger( p()->sets->set( WARRIOR_FURY, MID2, B2 )->effectN( 2 ).time_value() );
      p()->fury_mid2_2pc_extensions++;
    }

    p()->buff.hack_and_slash->decrement();
  }

  bool ready() override
  {
    // Needs weapons in both hands
    if ( p()->main_hand_weapon.type == WEAPON_NONE || p()->off_hand_weapon.type == WEAPON_NONE )
    {
      return false;
    }

    if ( !p()->talents.fury.reckless_abandon->ok() )
      return false;

    if ( !p()->buff.recklessness->check() )
      return false;
    return warrior_attack_t::ready();
  }
};

// Shattering Throw ========================================================

struct shattering_throw_damage_t : public warrior_attack_t
{
  shattering_throw_damage_t( util::string_view name, warrior_t* p )
    : warrior_attack_t( name, p, p->talents.warrior.shattering_throw->effectN( 2 ).trigger() )
  {
    background = dual = true;
    ignores_armor = true;
    may_crit = false;
    may_dodge = may_parry = may_block = false;
  }
};

struct shattering_throw_t : public warrior_attack_t
{
  shattering_throw_t( warrior_t* p, util::string_view options_str )
    : warrior_attack_t( "shattering_throw", p, p->talents.warrior.shattering_throw )
  {
    parse_options( options_str );
    weapon = &( player->main_hand_weapon );

    execute_action = get_action<shattering_throw_damage_t>( "shattering_throw_damage", p );
    execute_action->stats = stats;
    stats->action_list.push_back( execute_action );
  }
  //add absorb shield bonus (are those even in SimC?), add cast time?
};

// Sweeping Strikes ===================================================================

struct sweeping_strikes_t : public warrior_spell_t
{
  sweeping_strikes_t( warrior_t* p, util::string_view options_str )
    : warrior_spell_t( "sweeping_strikes", p, p->spec.sweeping_strikes )
  {
    parse_options( options_str );
    callbacks = false;
  }

  void execute() override
  {
    warrior_spell_t::execute();

    if ( sim->dbc->wowv() >= wowv_t( 12, 1, 0 ) )
      p()->buff.sweeping_strikes->trigger( as<int>( p()->spec.sweeping_strikes->effectN( 4 ).base_value() ) );
    else if ( sim->dbc->wowv() < wowv_t( 12, 1, 0 ) )
      p()->buff.sweeping_strikes->trigger( p()->spec.sweeping_strikes->max_stacks() );
  }
};

// Odyn's Fury ==========================================================

struct odyns_fury_off_hand_t : public warrior_attack_t
{
  odyns_fury_off_hand_t( warrior_t* p, util::string_view name, const spell_data_t* spell )
    : warrior_attack_t( name, p, spell )
  {
    background          = true;
    aoe                 = -1;
    reduced_aoe_targets = p->talents.fury.odyns_fury->effectN( 6 ).base_value();
  }
};

struct odyns_fury_main_hand_t : public warrior_attack_t
{
  int num_targets;
  odyns_fury_main_hand_t( warrior_t* p, util::string_view name, const spell_data_t* spell )
    : warrior_attack_t( name, p, spell ),
    num_targets( 0 )
  {
    background = true;
    aoe        = -1;
    reduced_aoe_targets = p->talents.fury.odyns_fury->effectN( 6 ).base_value();
  }

  double composite_ta_multiplier( const action_state_t* state ) const override
  {
    double ta = warrior_attack_t::composite_ta_multiplier( state );

    if ( num_targets > reduced_aoe_targets )
    {
      ta *= std::sqrt( reduced_aoe_targets / std::min<int>( sim->max_aoe_enemies, num_targets ) );
    }

    return ta;
  }

  void execute() override
  {
    // sqrt is snapshot on execute for the number of targets hit
    num_targets = as<int>( sim->target_non_sleeping_list.size() );

    warrior_attack_t::execute();
  }
};

struct odyns_fury_t : warrior_attack_t
{
  odyns_fury_main_hand_t* mh_attack;
  odyns_fury_main_hand_t* mh_attack2;
  odyns_fury_off_hand_t* oh_attack;
  odyns_fury_off_hand_t* oh_attack2;
  odyns_fury_t( warrior_t* p, util::string_view options_str, util::string_view n, const spell_data_t* spell )
    : warrior_attack_t( n, p, spell ),
      mh_attack( new odyns_fury_main_hand_t( p, fmt::format( "{}_mh", n ), spell->effectN( 1 ).trigger() ) ),
      mh_attack2( new odyns_fury_main_hand_t( p, fmt::format( "{}_mh", n ), spell->effectN( 3 ).trigger() ) ),
      oh_attack( new odyns_fury_off_hand_t( p, fmt::format( "{}_oh", n ), spell->effectN( 2 ).trigger() ) ),
      oh_attack2( new odyns_fury_off_hand_t( p, fmt::format( "{}_oh", n ), spell->effectN( 4 ).trigger() ) )
  {
    parse_options( options_str );
    radius = data().effectN( 1 ).trigger()->effectN( 1 ).radius_max();

    if ( p->main_hand_weapon.type != WEAPON_NONE )
    {
      mh_attack->weapon = &( p->main_hand_weapon );
      add_child( mh_attack );
      mh_attack->radius = radius;
      mh_attack2->weapon = &( p->main_hand_weapon );
      mh_attack2->radius = radius;
      add_child( mh_attack2 );
      if ( p->off_hand_weapon.type != WEAPON_NONE )
      {
        oh_attack->weapon = &( p->off_hand_weapon );
        add_child( oh_attack );
        oh_attack->radius = radius;
        oh_attack2->weapon = &( p->off_hand_weapon );
        add_child( oh_attack2 );
        oh_attack2->radius = radius;
      }
    }
  }

  void execute() override
  {
    warrior_attack_t::execute();

    p()->buff.enrage->trigger();

    mh_attack->execute();
    oh_attack->execute();
    mh_attack2->execute();
    oh_attack2->execute();
  }

  bool ready() override
  {
    if ( p()->main_hand_weapon.type == WEAPON_NONE )
    {
      return false;
    }
    return warrior_attack_t::ready();
  }
};

// Overpower ============================================================

struct dreadnaught_t : warrior_attack_t
{
  dreadnaught_t( warrior_t* p )
    : warrior_attack_t( "dreadnaught", p, p->find_spell( 315961 ) )
  {
    aoe = -1;
    reduced_aoe_targets = 5.0;
    background  = true;
    if ( sim->dbc->wowv() >= wowv_t( 12, 1, 0 ) )
      target_filter_callback = secondary_targets_only();
  }

  double composite_target_multiplier( player_t* target ) const override
  {
    double m = warrior_attack_t::composite_target_multiplier( target );
    if ( p()->talents.arms.overpowering_finish.ok() && target->health_percentage() < p()->talents.arms.overpowering_finish->effectN( 2 ).base_value() )
      m *= 1.0 + p()->talents.arms.overpowering_finish->effectN( 1 ).percent();
    return m;
  }
};

struct overpower_t : public warrior_attack_t
{
  double battlelord_chance;
  warrior_attack_t* dreadnaught;

  overpower_t( warrior_t* p, util::string_view options_str )
    : warrior_attack_t( "overpower", p, p->talents.arms.overpower ),
      battlelord_chance( p->talents.arms.battlelord->proc_chance() ),
      dreadnaught( nullptr )
  {
    parse_options( options_str );
    may_block = may_parry = may_dodge = false;
    weapon                            = &( p->main_hand_weapon );
    proc_slayers_strike = true;

    if ( p->talents.arms.dreadnaught->ok() )
    {
      dreadnaught = new dreadnaught_t( p );
      add_child( dreadnaught );
    }
  }

  double composite_target_multiplier( player_t* target ) const override
  {
    double m = warrior_attack_t::composite_target_multiplier( target );
    if ( p()->talents.arms.overpowering_finish.ok() && target->health_percentage() < p()->talents.arms.overpowering_finish->effectN( 2 ).base_value() )
      m *= 1.0 + p()->talents.arms.overpowering_finish->effectN( 1 ).percent();
    return m;
  }

  void impact( action_state_t* s ) override
  {
    warrior_attack_t::impact( s );

    // Dreadnaught fires off per target hit by overpower.  SS will cause casts
    if ( dreadnaught && result_is_hit( s->result ) )
    {
      if ( sim->dbc->wowv() < wowv_t( 12, 1, 0 ) )
        dreadnaught->execute_on_target( s->target );
      else if ( sim->dbc->wowv() >= wowv_t( 12, 1, 0 ) && sim->target_non_sleeping_list.size() > 1 )
        dreadnaught->execute_on_target( s->target );
    }

    if ( !background && p()->talents.arms.master_of_warfare_1.ok() && !p()->buff.master_of_warfare_proc->up() && p()->rng().roll( master_of_warfare_proc_chance * ++p()->master_of_warfare_attempts_since_last_proc ) )
    {
      p()->buff.master_of_warfare_proc->trigger();
      p()->master_of_warfare_attempts_since_last_proc = 0;
    }
  }

  void execute() override
  {
    warrior_attack_t::execute();
    if ( p()->talents.arms.battlelord->ok() && rng().roll( battlelord_chance ) )
    {
      if ( !p()->cooldown.mortal_strike->up() )
        p()->proc.battlelord_wasted->occur();
      else
        p()->proc.battlelord->occur();

      p()->cooldown.mortal_strike->reset( true );
      p()->buff.battlelord->trigger();
    }

    p()->buff.opportunist->expire();

    if ( p()->talents.arms.martial_prowess.ok() )
      p()->buff.martial_prowess->trigger();

    if ( p()->sets->has_set_bonus( WARRIOR_ARMS, MID2, B4 ) )
      p()->buff.winding_up->trigger();
  }

  bool ready() override
  {
    if ( p()->main_hand_weapon.type == WEAPON_NONE )
    {
      return false;
    }
    return warrior_attack_t::ready();
  }
};

// Rampage ================================================================

struct rampage_attack_base_t : public warrior_attack_t
{
  int aoe_targets;
  bool first_attack, simmering_rage;
  double hack_and_slash_chance;
  rampage_attack_base_t( util::string_view name, warrior_t* p, const spell_data_t* rampage )
    : warrior_attack_t( name, p, rampage ),
      aoe_targets( as<int>( p->spell.whirlwind_buff->effectN( 1 ).base_value() ) ),
      first_attack( false ),
      simmering_rage( false ),
      hack_and_slash_chance( p->talents.fury.hack_and_slash->proc_chance() )
  {
    background = true;
    dual = true;
  }

  double composite_da_multiplier( const action_state_t* state ) const override
  {
    double m = warrior_attack_t::composite_da_multiplier( state );

    if ( p()->talents.fury.rampaging_berserker_2->ok() && p()->buff.recklessness->check() )
      m *= 1.0 + p()->talents.fury.rampaging_berserker_2->effectN( 2 ).percent();

    return m;
  }

  void execute() override
  {
    warrior_attack_t::execute();

    if ( first_attack && result_is_miss( execute_state->result ) )
      p()->first_rampage_attack_missed = true;
    else if ( first_attack )
      p()->first_rampage_attack_missed = false;
  }

  void impact( action_state_t* s ) override
  {
    if ( !p()->first_rampage_attack_missed )
    {  // If the first attack misses, all of the rest do as well. However, if any other attack misses, the attacks after
       // continue. The animations and timing of everything else still occur, so we can't just cancel rampage.
      warrior_attack_t::impact( s );
    }
  }
};

struct rampage_attack_t : public rampage_attack_base_t
{
  action_t* reap_the_storm;
  rampage_attack_t( util::string_view name, warrior_t* p, const spell_data_t* rampage )
    : rampage_attack_base_t( name, p, rampage ),
    reap_the_storm( nullptr )
  {
    base_aoe_multiplier = p->spell.whirlwind_buff->effectN( 2 ).percent();
    if ( p->talents.fury.rampage->effectN( 2 ).trigger() == rampage )
      first_attack = true;

    // Set up reap to trigger off the 4th hit
    if( p->talents.fury.rampage->effectN( 5 ).trigger()->id() == data().id() &&
        sim->dbc->wowv() >= wowv_t( 12, 0, 5 )  && p->talents.slayer.reap_the_storm.ok() &&
        p->talents.fury.improved_whirlwind.ok() )
    {
      reap_the_storm = get_action<reap_the_storm_t>( "reap_the_storm_rampage", p );
      add_child( reap_the_storm );
    }
  }

  void execute() override
  {
    rampage_attack_base_t::execute();
    // Expire buffs after the fourth attack triggers
    // Also fire frenzy buff after the 4th attack triggers
    if ( p()->talents.fury.rampage->effectN( 5 ).trigger()->id() == data().id() )
    {
      p()->buff.whirlwind->decrement();
      p()->buff.brutal_finish->expire();

      if ( p()->talents.fury.frenzy->ok() )
        p()->buff.frenzy->trigger();

      if ( sim->dbc->wowv() >= wowv_t( 12, 0, 5 ) && p()->talents.fury.improved_whirlwind.ok() &&
          p()->cooldown.reap_the_storm_icd->is_ready() && reap_the_storm &&
          execute_state->n_targets >= p()->talents.slayer.reap_the_storm->effectN( 2 ).base_value() &&
          rng().roll( p()->talents.slayer.reap_the_storm->effectN( 4 ).percent() ) )
      {
        reap_the_storm->execute();
        p()->cooldown.reap_the_storm_icd->start();
      }
    }

    if ( first_attack && sim->dbc->wowv() >= wowv_t( 12, 0, 5 )  &&
          p()->talents.fury.hack_and_slash.ok() &&
          p()->cooldown.hack_and_slash_icd->up() && rng().roll( hack_and_slash_chance ) )
    {
      p()->cooldown.raging_blow->reset( true );
      p()->cooldown.crushing_blow->reset( true );
      p()->cooldown.hack_and_slash_icd->start();
      p()->buff.hack_and_slash->trigger();
    }
  }

  int n_targets() const override
  {
    if ( p()->buff.whirlwind->check() )
    {
      return aoe_targets + 1;
    }
    return warrior_attack_t::n_targets();
  }
};

struct rampage_attack_aoe_t : public rampage_attack_base_t
{
  action_t* reap_the_storm;
  rampage_attack_aoe_t( util::string_view name, warrior_t* p, const spell_data_t* rampage )
    : rampage_attack_base_t( name, p, rampage ),
    reap_the_storm( nullptr )
  {
    if ( p->talents.fury.rampage->effectN( 6 ).trigger() == rampage )
      first_attack = true;

    aoe = -1;
    reduced_aoe_targets = p->talents.fury.rampage->effectN( 10 ).base_value();

     // Set up reap to trigger off the 4th hit
    if( p->talents.fury.rampage->effectN( 9 ).trigger()->id() == data().id() &&
        sim->dbc->wowv() >= wowv_t( 12, 0, 5 )  && p->talents.slayer.reap_the_storm.ok() &&
        p->talents.fury.improved_whirlwind.ok() )
    {
      reap_the_storm = get_action<reap_the_storm_t>( "reap_the_storm_rampage_aoe", p );
      add_child( reap_the_storm );
    }
  }

  void execute() override
  {
    rampage_attack_base_t::execute();
    // Expire buffs after the fourth attack triggers
    // Also fire frenzy buff after the 4th attack triggers
    if ( p()->talents.fury.rampage->effectN( 9 ).trigger()->id() == data().id() )
    {
      p()->buff.whirlwind->decrement();
      p()->buff.brutal_finish->expire();

      if ( p()->talents.fury.frenzy->ok() )
        p()->buff.frenzy->trigger();

      if ( sim->dbc->wowv() >= wowv_t( 12, 0, 5 ) && p()->talents.fury.improved_whirlwind.ok() &&
          p()->cooldown.reap_the_storm_icd->is_ready() && reap_the_storm &&
          execute_state->n_targets >= p()->talents.slayer.reap_the_storm->effectN( 2 ).base_value() &&
          rng().roll( p()->talents.slayer.reap_the_storm->effectN( 4 ).percent() ) )
      {
        reap_the_storm->execute();
        p()->cooldown.reap_the_storm_icd->start();
      }
    }
  }
};

struct rampaging_ruin_attack_t : public rampage_attack_base_t
{
  rampaging_ruin_attack_t( util::string_view name, warrior_t* p )
    : rampage_attack_base_t( name, p, p->spell.rampaging_ruin_damage )
  {
    background = true;
    aoe = -1;
    reduced_aoe_targets = data().effectN( 2 ).base_value();
    target_filter_callback = secondary_targets_only();
    weapon = &( p->off_hand_weapon );
  }
};

struct rampage_parent_t : public warrior_attack_t
{
  double cost_rage;
  double frothing_berserker_chance;
  double rage_from_frothing_berserker;
  rampage_attack_t* rampage1_oh;
  rampage_attack_t* rampage2_mh;
  rampage_attack_t* rampage3_oh;
  rampage_attack_t* rampage4_mh;
  rampage_attack_aoe_t* rampage1_aoe_oh;
  rampage_attack_aoe_t* rampage2_aoe_mh;
  rampage_attack_aoe_t* rampage3_aoe_oh;
  rampage_attack_aoe_t* rampage4_aoe_mh;
  rampaging_ruin_attack_t* rampaging_ruin_aoe;

  rampage_parent_t( warrior_t* p, util::string_view options_str )
    : warrior_attack_t( "rampage", p, p->talents.fury.rampage ),
    frothing_berserker_chance( p->talents.warrior.frothing_berserker->proc_chance() ),
    rage_from_frothing_berserker( p->talents.warrior.frothing_berserker->effectN( 1 ).percent()),
    rampage1_oh( nullptr ),
    rampage2_mh( nullptr ),
    rampage3_oh( nullptr ),
    rampage4_mh( nullptr ),
    rampage1_aoe_oh( nullptr ),
    rampage2_aoe_mh( nullptr ),
    rampage3_aoe_oh( nullptr ),
    rampage4_aoe_mh( nullptr ),
    rampaging_ruin_aoe( nullptr )
  {
    parse_options( options_str );

    rampage1_oh = new rampage_attack_t( "rampage1", p, p->talents.fury.rampage->effectN( 2 ).trigger() );
    rampage1_oh->weapon = &(p->off_hand_weapon);
    add_child( rampage1_oh );
    rampage2_mh = new rampage_attack_t( "rampage2", p, p->talents.fury.rampage->effectN( 3 ).trigger() );
    rampage2_mh->weapon = &(p->main_hand_weapon);
    add_child( rampage2_mh );
    rampage3_oh = new rampage_attack_t( "rampage3", p, p->talents.fury.rampage->effectN( 4 ).trigger() );
    rampage3_oh->weapon = &(p->off_hand_weapon);
    add_child( rampage3_oh );
    rampage4_mh = new rampage_attack_t( "rampage4", p, p->talents.fury.rampage->effectN( 5 ).trigger() );
    rampage4_mh->weapon = &(p->main_hand_weapon);
    rampage4_mh->proc_slayers_strike = true;
    add_child( rampage4_mh );

    if ( p->talents.fury.rampaging_ruin->ok() )
    {
      if ( sim->dbc->wowv() < wowv_t( 12, 1, 0 ) )
      {
      // AOE attacks
        rampage1_aoe_oh = new rampage_attack_aoe_t( "rampage1_aoe", p, p->talents.fury.rampage->effectN( 6 ).trigger() );
        rampage1_aoe_oh->weapon = &(p->off_hand_weapon);
        add_child( rampage1_aoe_oh );
        rampage2_aoe_mh = new rampage_attack_aoe_t( "rampage2_aoe", p, p->talents.fury.rampage->effectN( 7 ).trigger() );
        rampage2_aoe_mh->weapon = &(p->main_hand_weapon);
        add_child( rampage2_aoe_mh );
        rampage3_aoe_oh = new rampage_attack_aoe_t( "rampage3_aoe", p, p->talents.fury.rampage->effectN( 8 ).trigger() );
        rampage3_aoe_oh->weapon = &(p->off_hand_weapon);
        add_child( rampage3_aoe_oh );
        rampage4_aoe_mh = new rampage_attack_aoe_t( "rampage4_aoe", p, p->talents.fury.rampage->effectN( 9 ).trigger() );
        rampage4_aoe_mh->weapon = &(p->main_hand_weapon);
        add_child( rampage4_aoe_mh );
      }
      else if ( sim->dbc->wowv() >= wowv_t( 12, 1, 0 ) )
      {
        rampaging_ruin_aoe = new rampaging_ruin_attack_t( "rampaging_ruin", p );
        add_child( rampaging_ruin_aoe );
      }
    }
    track_cd_waste = false;

    rage_from_frothing_berserker = p->talents.warrior.frothing_berserker->effectN( 2 ).percent();
  }

  double cost() const override
  {
    double c = warrior_attack_t::cost();

    if ( p()->talents.fury.rampaging_berserker_2->ok() && p()->buff.recklessness->check() )
      c += ( p()->talents.fury.rampaging_berserker_2->effectN( 1 ).base_value() / 10 );

    return c;
  }

  void execute() override
  {
    warrior_attack_t::execute();

    cost_rage = last_resource_cost;
    if ( p()->talents.warrior.frothing_berserker->ok() && rng().roll( frothing_berserker_chance ) )
    {
      p()->resource_gain(RESOURCE_RAGE, last_resource_cost * rage_from_frothing_berserker, p()->gain.frothing_berserker);
    }

    p()->enrage();

    if ( p()->talents.fury.scent_of_blood->ok() )
      p()->buff.scent_of_blood->trigger();

    // Berserk triggers after the first hit of rampage lands, so add 1_ms to it

    if( sim->dbc->wowv() < wowv_t( 12, 1, 0 ) && p()->talents.fury.rampaging_ruin.ok() && p()->buff.whirlwind->up() )
    {
      make_event<delayed_execute_event_t>( *sim, p(), rampage1_aoe_oh, p()->target, timespan_t::from_millis(p()->talents.fury.rampage->effectN( 6 ).misc_value1()) );
      if ( p()->talents.fury.rampaging_berserker_1->ok() )
        make_event( sim, timespan_t::from_millis(p()->talents.fury.rampage->effectN( 6 ).misc_value1()) + 1_ms, [ this ]() { p()->buff.berserk->trigger(); } );
      make_event<delayed_execute_event_t>( *sim, p(), rampage2_aoe_mh, p()->target, timespan_t::from_millis(p()->talents.fury.rampage->effectN( 7 ).misc_value1()) );
      make_event<delayed_execute_event_t>( *sim, p(), rampage3_aoe_oh, p()->target, timespan_t::from_millis(p()->talents.fury.rampage->effectN( 8 ).misc_value1()) );
      make_event<delayed_execute_event_t>( *sim, p(), rampage4_aoe_mh, p()->target, timespan_t::from_millis(p()->talents.fury.rampage->effectN( 9 ).misc_value1()) );
    }
    else
    {
      make_event<delayed_execute_event_t>( *sim, p(), rampage1_oh, p()->target, timespan_t::from_millis(p()->talents.fury.rampage->effectN( 2 ).misc_value1()) );
      if ( p()->talents.fury.rampaging_berserker_1->ok() )
        make_event( sim, timespan_t::from_millis(p()->talents.fury.rampage->effectN( 2 ).misc_value1()) + 1_ms, [ this ]() { p()->buff.berserk->trigger(); } );
      make_event<delayed_execute_event_t>( *sim, p(), rampage2_mh, p()->target, timespan_t::from_millis(p()->talents.fury.rampage->effectN( 3 ).misc_value1()) );
      make_event<delayed_execute_event_t>( *sim, p(), rampage3_oh, p()->target, timespan_t::from_millis(p()->talents.fury.rampage->effectN( 4 ).misc_value1()) );
      make_event<delayed_execute_event_t>( *sim, p(), rampage4_mh, p()->target, timespan_t::from_millis(p()->talents.fury.rampage->effectN( 5 ).misc_value1()) );
      if ( sim->dbc->wowv() >= wowv_t( 12, 1, 0 ) && p()->talents.fury.rampaging_ruin.ok() && p()->buff.whirlwind->up() )
        make_event<delayed_execute_event_t>( *sim, p(), rampaging_ruin_aoe, p()->target, timespan_t::from_millis(p()->talents.fury.rampage->effectN( 6 ).misc_value1() ) );
    }

    if ( p()->sets->has_set_bonus( WARRIOR_FURY, MID1, B4 ) )
      p()->cooldown.odyns_fury->adjust( - p()->sets->set( WARRIOR_FURY, MID1, B4 )->effectN( 1 ).time_value() );
  }

  bool ready() override
  {
    if ( p()->main_hand_weapon.type == WEAPON_NONE || p()->off_hand_weapon.type == WEAPON_NONE )
    {
      return false;
    }
    return warrior_attack_t::ready();
  }
};

// Ravager ==============================================================

struct ravager_tick_t : public warrior_attack_t
{
  double rage_from_ravager;
  timespan_t ravaged_debuff_duration;
  ravager_tick_t( warrior_t* p, util::string_view name, timespan_t ravaged_debuff_duration )
    : warrior_attack_t( name, p, p->find_spell( 156287 ) ),
      rage_from_ravager( p->specialization() == WARRIOR_PROTECTION ? p->find_spell( 334934 )->effectN( 1 ).resource( RESOURCE_RAGE ) : 0 ),
      ravaged_debuff_duration( ravaged_debuff_duration )
  {
    aoe = -1;
    reduced_aoe_targets = data().effectN( 2 ).base_value();
    dual = true;
    background = true;
  }

  void impact( action_state_t* state ) override
  {
    warrior_attack_t::impact( state );

    if ( sim->dbc->wowv() >= wowv_t( 12, 1, 0 ) )
    {
      td( state->target )->debuffs_ravaged->trigger( ravaged_debuff_duration );

      if ( p()->specialization() == WARRIOR_PROTECTION && p()->sets->has_set_bonus( WARRIOR_PROTECTION, MID2, B4 ) )
        p()->active.bloody_rebuke->execute_on_target( state->target );
    }
  }

  void execute() override
  {
    warrior_attack_t::execute();

    if ( execute_state->n_targets > 0 )
    {
      if( sim->dbc->wowv() < wowv_t( 12, 1, 0 ) )
        p()->resource_gain( RESOURCE_RAGE, rage_from_ravager, p()->gain.ravager, this );
      else if ( sim->dbc->wowv() >= wowv_t( 12, 1, 0 ) && p()->specialization() == WARRIOR_PROTECTION )
        p()->resource_gain( RESOURCE_RAGE, rage_from_ravager, p()->gain.ravager, this );
    }
  }
};

struct ravager_t : public warrior_attack_t
{
  ravager_tick_t* ravager;
  timespan_t duration;
  int num_ticks;
  ravager_t( warrior_t* p, util::string_view options_str )
    : warrior_attack_t( "ravager", p, p->talents.shared.ravager ),
      ravager( new ravager_tick_t( p, "ravager_tick", p->spell.ravager->duration() ) ),
      duration( 0_s ),
      num_ticks( 0 )
  {
    parse_options( options_str );
    if ( sim->dbc->wowv() < wowv_t( 12, 1, 0 ) )
    {
      ignore_false_positive   = true;
      hasted_ticks            = true;
      ground_aoe              = true;
      base_tick_time = dot_duration = 0_ms;  // Handled by event
      radius     = data().effectN( 2 ).radius_max();
      internal_cooldown->duration = 0_s; // allow Anger Management to reduce the cd properly due to having both charges and cooldown entries
      attack_power_mod.direct = attack_power_mod.tick = 0;
      duration = p->buff.ravager->data().duration();
      num_ticks = 6;  // Not in spelldata, can be found in the variables in 228920
    }
    if ( sim->dbc->wowv() >= wowv_t( 12, 1, 0 ) )
    {
      ground_aoe = true;
      internal_cooldown->duration = 0_s;
      duration = p->spell.ravager->duration();
      base_tick_time = dot_duration = 0_ms; // Handled by the event
    }

    add_child( ravager );
  }

  // This background version is strictly for use with whirling blade talent
  ravager_t( util::string_view name, warrior_t* p )
    : warrior_attack_t( name, p, p->spell.ravager ),
    ravager( new ravager_tick_t( p, "ravager_tick_whirling_blade", p->talents.protection.whirling_blade->effectN( 1 ).time_value() ) )
    {
      if ( sim->dbc->wowv() < wowv_t( 12, 1, 0 ) )
      {
        ignore_false_positive = true;
        hasted_ticks = true;
        ground_aoe = true;
        base_tick_time = dot_duration = 0_ms; // Handled by the event
        radius = data().effectN( 2 ).radius_max();
        internal_cooldown->duration = 0_s;
        attack_power_mod.direct = attack_power_mod.tick = 0;
        duration = p->talents.protection.whirling_blade->effectN( 1 ).time_value();
        num_ticks = 2;  // Not in spelldata, but we get 2 ticks from the 4s buff.
        cooldown->duration = 0_ms;  // No cooldown for whirling blade
      }

      if ( sim->dbc->wowv() >= wowv_t( 12, 1, 0 ) )
      {
        ground_aoe = true;
        internal_cooldown->duration = 0_s;
        cooldown->duration = 0_ms;  // No cooldown for whirling blade
        duration = p->talents.protection.whirling_blade->effectN( 1 ).time_value();
        base_tick_time = dot_duration = 0_ms; // Handled by the event
      }

      add_child( ravager );
    }


  void init_finished() override
  {
    warrior_attack_t::init_finished();
    // Merge stats with the damage object
    ravager->stats = stats;
    stats->action_list.push_back( ravager );
  }

  void impact( action_state_t* state ) override
  {
    warrior_attack_t::impact( state );

    if ( sim->dbc->wowv() >= wowv_t( 12, 1, 0 ) )
      td( state->target )->debuffs_ravaged->trigger( duration );
  }

  void execute() override
  {
    warrior_attack_t::execute();

    if ( sim->dbc->wowv() < wowv_t( 12, 1, 0 ) )
    {
      p()->buff.ravager->trigger( duration * p()->cache.attack_haste() );

      make_event<ground_aoe_event_t>(
      *sim, p(),
      ground_aoe_params_t()
          .target( target )
          .pulse_time( compute_tick_time() )
          .action( ravager )
          .n_pulses( num_ticks )
          .hasted( ground_aoe_params_t::ATTACK_HASTE )
          .x( target->x_position )
          .y( target->y_position ),
        false /* Immediate pulse */ );
    }

    if ( sim->dbc->wowv() >= wowv_t( 12, 1, 0 ) )
    {
      make_event<ground_aoe_event_t>(
      *sim, p(),
      ground_aoe_params_t()
          .target( target )
          .duration( duration )
          .pulse_time( p()->spell.ravager->effectN( 2 ).period() )
          .action( ravager )
          .x( target->x_position )
          .y( target->y_position ),
        false /* Immediate pulse */ );
    }
  }

  timespan_t compute_tick_time() const
  {
    auto base = data().effectN( 3 ).period();

    return base;
  }
};

// Revenge ==================================================================
struct revenge_t : public warrior_attack_t
{
  double shield_slam_reset;
  action_t* lightning_strike;
  double frothing_berserker_chance;
  double rage_from_frothing_berserker;
  revenge_t( warrior_t* p, util::string_view options_str )
    : warrior_attack_t( "revenge", p, p->talents.protection.revenge ),
      shield_slam_reset( p->talents.protection.strategist->effectN( 1 ).percent() ),

      lightning_strike( nullptr ),
      frothing_berserker_chance( p->talents.warrior.frothing_berserker->proc_chance() ),
      rage_from_frothing_berserker( p->talents.warrior.frothing_berserker->effectN( 1 ).percent() )
    {
      parse_options( options_str );
      aoe           = -1;

      if ( p->talents.mountain_thane.lightning_strikes->ok() )
      {
        lightning_strike = get_action<lightning_strike_t>( "lightning_strike_revenge", p );
        add_child( lightning_strike );
      }

      rage_from_frothing_berserker = p->talents.warrior.frothing_berserker->effectN( 3 ).percent();

      if ( p->talents.protection.strategist->ok() )
      {
        // For some reason on PTR strategist is referencing shield slam reset chance from devastator
        shield_slam_reset = p->spell.devastator->effectN( 2 ).percent();
      }
  }

  void execute() override
  {
    bool free_revenge = p()->buff.revenge->up();

    warrior_attack_t::execute();
    p()->buff.revenge->expire();

    if ( free_revenge && p()->sets->has_set_bonus( WARRIOR_PROTECTION, MID2, B2 ) )
      p()->buff.vengeful_shield->trigger();

    if ( rng().roll( shield_slam_reset ) )
      p()->cooldown.shield_slam->reset( true );

    if ( p()->talents.warrior.frothing_berserker->ok() && !background && rng().roll( frothing_berserker_chance ) )
    {
      p()->resource_gain( RESOURCE_RAGE, last_resource_cost * rage_from_frothing_berserker, p()->gain.frothing_berserker );
    }

    if ( !background && p()->talents.colossus.colossal_might->ok() && execute_state -> n_targets >= p()->talents.colossus.colossal_might->effectN( 1 ).base_value() )
    {
      if ( sim->dbc->wowv() < wowv_t( 12, 1, 0 ) && p()->talents.colossus.dominance_of_the_colossus->ok() && p()->buff.colossal_might->at_max_stacks() )
      {
        p()->cooldown.demolish->adjust( - timespan_t::from_seconds( p()->talents.colossus.dominance_of_the_colossus->effectN( 2 ).base_value() ) );
      }
      p()->buff.colossal_might->trigger();
    }

    if ( p()->talents.mountain_thane.lightning_strikes->ok() )
    {
      auto chance = p()->talents.mountain_thane.lightning_strikes->effectN( 1 ).percent();
      if ( p()->buff.avatar->check() )
        chance *= 1.0 + p()->talents.mountain_thane.lightning_strikes->effectN( 2 ).percent();
      if ( rng().roll( chance ) )
      {
        lightning_strike->execute();
      }
    }
  }

  void impact( action_state_t* s ) override
  {
    warrior_attack_t::impact( s );

    if ( p()->buff.revenge->up() && p()->sets->has_set_bonus( WARRIOR_PROTECTION, MID2, B4 ) )
      p()->active.bloody_rebuke->execute_on_target( s->target );
  }

  bool ready() override
  {
    if ( p()->main_hand_weapon.type == WEAPON_NONE )
    {
      return false;
    }
    return warrior_attack_t::ready();
  }

  double composite_da_multiplier( const action_state_t* state ) const override
  {
    double m = warrior_attack_t::composite_da_multiplier( state );

    if ( p()->talents.colossus.one_against_many->ok() )
    {
      m *= 1.0 + ( p()->talents.colossus.one_against_many->effectN( 1 ).percent() * std::min( state -> n_targets,  as<unsigned int>( p()->talents.colossus.one_against_many->effectN( 2 ).base_value() ) ) );
    }

    return m;
  }
};

// Enraged Regeneration ===============================================

struct enraged_regeneration_t : public warrior_heal_t
{
  enraged_regeneration_t( warrior_t* p, util::string_view options_str )
    : warrior_heal_t( "enraged_regeneration", p, p->talents.fury.enraged_regeneration )
  {
    parse_options( options_str );
    range         = -1;
    base_pct_heal = data().effectN( 1 ).percent();
  }
};

// Shield Charge ============================================================

struct shield_charge_damage_t : public warrior_attack_t
{
  double rage_gain;
  shield_charge_damage_t( util::string_view name, warrior_t* p )
    : warrior_attack_t( name, p, p->find_spell( 385954 ) ),
    rage_gain( p->find_spell( 385954 )->effectN( 4 ).resource( RESOURCE_RAGE ) )
  {
    background = true;
    may_miss = false;
    energize_type = action_energize::NONE;

    aoe = 0;
    // this spell has both coefficients in it, force #1
    attack_power_mod.direct = data().effectN( 1 ).ap_coeff();
  }

  void execute() override
  {
    warrior_attack_t::execute();

    p()->buff.shield_block->extend_duration_or_trigger( p()->buff.shield_block->buff_duration() );
    p()->resource_gain( RESOURCE_RAGE, rage_gain, p() -> gain.shield_charge );
  }
};

struct shield_charge_damage_aoe_t : public warrior_attack_t
{
  shield_charge_damage_aoe_t( util::string_view name, warrior_t* p )
    : warrior_attack_t( name, p, p->find_spell( 385954 ) )
  {
    background = true;
    may_miss = false;
    energize_type = action_energize::NONE;

    aoe = -1;
    target_filter_callback  = secondary_targets_only();

    // this spell has both coefficients in it, force #2
    attack_power_mod.direct = data().effectN( 2 ).ap_coeff();
  }
};

struct shield_charge_t : public warrior_attack_t
{
  double movement_speed_increase;
  action_t* shield_charge_damage;
  action_t* shield_charge_damage_aoe;
  shield_charge_t( warrior_t* p, util::string_view options_str )
    : warrior_attack_t( "shield_charge", p, p->talents.protection.shield_charge ),
      movement_speed_increase( 5.0 )
  {
    parse_options( options_str );
    energize_type = action_energize::NONE;
    movement_directionality = movement_direction_type::OMNI;

    shield_charge_damage = get_action<shield_charge_damage_t>( "shield_charge_main", p );
    shield_charge_damage_aoe = get_action<shield_charge_damage_aoe_t>( "shield_charge_aoe", p );
    add_child( shield_charge_damage );
    add_child( shield_charge_damage_aoe );
  }

  timespan_t calc_charge_time( double distance )
  {
    return timespan_t::from_seconds( distance /
      ( p()->current.movement_speed * ( 1 + p()->stacking_movement_modifier() + movement_speed_increase ) ) );
  }

  void execute() override
  {
    if ( p()->current.distance_to_move > 0 )
    {
      p()->buff.shield_charge_movement->trigger( 1, movement_speed_increase, 1, calc_charge_time( p()->current.distance_to_move ) );
      p()->current.moving_away = 0;
    }
    warrior_attack_t::execute();

    shield_charge_damage->execute_on_target( target );
    // If we have more than one target, trigger aoe as well
    if ( sim -> target_non_sleeping_list.size() > 1 )
      shield_charge_damage_aoe->execute_on_target( target );

    if ( p()->sets->has_set_bonus( WARRIOR_PROTECTION, MID1, B4 ) )
      p()->buff.revenge->trigger();
  }

  bool ready() override
  {
    if ( p()->buff.charge_movement->check() || p()->buff.heroic_leap_movement->check() ||
         p()->buff.intervene_movement->check() || p()->buff.shield_charge_movement->check() )
    {
      return false;
    }
    return warrior_attack_t::ready();
  }
};

// Shield Slam ==============================================================
struct phalanx_t : public warrior_attack_t
{
  phalanx_t( std::string_view name, warrior_t* p )
    : warrior_attack_t( name, p, p->find_spell( 1270116 ) )
    {
      background = true;
      aoe = -1;
    }

    void impact( action_state_t* state ) override
    {
      warrior_attack_t::impact( state );

      auto target_data = td( state->target );
      if ( target_data && p()->talents.protection.phalanx_3.ok() )
        target_data->debuffs_phalanx->trigger();
    }
};

struct shield_slam_t : public warrior_attack_t
{
  double rage_gain;
  int aoe_targets;
  action_t* ignore_pain;
  action_t* phalanx;
  shield_slam_t( warrior_t* p, util::string_view options_str )
    : warrior_attack_t( "shield_slam", p, p->spell.shield_slam ),
    rage_gain( p->spell.shield_slam->effectN( 3 ).resource( RESOURCE_RAGE ) ),
    aoe_targets( as<int>( p->spell.whirlwind_buff->effectN( 1 ).base_value() ) ),
    ignore_pain( nullptr ),
    phalanx( nullptr )
  {
    parse_options( options_str );
    energize_type = action_energize::NONE;

    radius = 5;
    base_aoe_multiplier = p->spell.whirlwind_buff->effectN( 2 ).percent();

    if ( p->talents.protection.violent_outburst->ok() )
    {
      ignore_pain = get_action<ignore_pain_t>( "ignore_pain_violent_outburst", p );
    }

    if ( p->talents.protection.phalanx_1.ok() )
    {
      phalanx = get_action<phalanx_t>( "phalanx", p );
      add_child(phalanx);
    }
  }

  int n_targets() const override
  {
    if ( p()->buff.whirlwind->check() )
    {
      return aoe_targets + 1;
    }
    return warrior_attack_t::n_targets();
  }

  void execute() override
  {
    warrior_attack_t::execute();

    if ( p()->buff.shield_block->up() && p()->talents.protection.heavy_repercussions->ok() )
    {
      p()->buff.shield_block->extend_duration(
          timespan_t::from_seconds( p()->talents.protection.heavy_repercussions->effectN( 1 ).percent() ) );
    }

    if ( p()->talents.protection.impenetrable_wall->ok() )
    {
      p()->cooldown.shield_wall->adjust( - timespan_t::from_seconds( p()->talents.protection.impenetrable_wall->effectN( 1 ).base_value() ) );
    }

    auto total_rage_gain = rage_gain;

    if ( p() -> talents.protection.brace_for_impact->ok() )
      p() -> buff.brace_for_impact -> trigger();

    if ( p()->buff.violent_outburst->check() )
    {
      ignore_pain->execute();
      p()->buff.violent_outburst->expire();
      total_rage_gain *= 1.0 + p() -> buff.violent_outburst->data().effectN( 2 ).percent();
    }

    p() -> buff.whirlwind->decrement();

    p()->resource_gain( RESOURCE_RAGE, total_rage_gain, p()->gain.shield_slam, this );

    if ( p()->talents.mountain_thane.thunder_blast->ok() && rng().roll( p()->talents.mountain_thane.thunder_blast->effectN( 1 ).percent() ) )
    {
      p()->buff.thunder_blast->trigger();
    }

    p()->buff.celeritous_conclusion_crit->expire();

    if ( p()->talents.protection.phalanx_1.ok() && p()->buff.phalanx->up() )
    {
      phalanx->execute_on_target( p()->target );
      p()->buff.phalanx->expire();
    }

    p()->buff.vengeful_shield->expire();
  }

  void impact( action_state_t* state ) override
  {
    warrior_attack_t::impact( state );

    warrior_td_t* td = p() -> get_target_data( state -> target );

    if ( p()->talents.protection.punish.ok() )
    {
      td -> debuffs_punish -> trigger();
    }

    if ( p()->talents.colossus.colossal_might->ok() )
    {
      // Gain 2 stacks on a crit with precise might, 1 otherwise.
      if ( p()->talents.colossus.precise_might->ok() && state->result == RESULT_CRIT )
      {
        if ( sim->dbc->wowv() < wowv_t( 12, 1, 0 ) && p()->talents.colossus.dominance_of_the_colossus->ok() && p()->buff.colossal_might->at_max_stacks() )
        {
          p()->cooldown.demolish->adjust( - timespan_t::from_seconds( p()->talents.colossus.dominance_of_the_colossus->effectN( 2 ).base_value() * 2 ) );
        }
        p()->buff.colossal_might->trigger( 2 );
      }
      else
      {
        if ( sim->dbc->wowv() < wowv_t( 12, 1, 0 ) && p()->talents.colossus.dominance_of_the_colossus->ok() && p()->buff.colossal_might->at_max_stacks() )
        {
          p()->cooldown.demolish->adjust( - timespan_t::from_seconds( p()->talents.colossus.dominance_of_the_colossus->effectN( 2 ).base_value() ) );
        }
        p()->buff.colossal_might->trigger();
      }
    }

    if ( p()->talents.mountain_thane.burst_of_power->ok() && p()->buff.burst_of_power->up() && p()->cooldown.burst_of_power_icd->up() )
    {
      p()->cooldown.burst_of_power_icd->start();
      p()->buff.burst_of_power->decrement();
      // Reset CD after everything resolves
      make_event( *p()->sim, [ this ] { p()->cooldown.shield_slam->reset( true ); } );
    }

    if ( state->result == RESULT_CRIT && p()->talents.colossus.cut_to_the_bone->ok() )
      p()->buff.cut_to_the_bone->trigger();
  }

  bool ready() override
  {
    if ( !p()->has_shield_equipped() )
    {
      return false;
    }
    return warrior_attack_t::ready();
  }
};

// Shockwave ================================================================

struct shockwave_t : public warrior_attack_t
{
  shockwave_t( warrior_t* p, util::string_view options_str )
    : warrior_attack_t( "shockwave", p, p->talents.warrior.shockwave )
  {
    parse_options( options_str );
    may_dodge = may_parry = may_block = false;
    aoe                               = -1;
  }

  void impact( action_state_t* state ) override
  {
    warrior_attack_t::impact( state );

    if ( state -> n_targets >= as<size_t>( p() -> talents.warrior.rumbling_earth->effectN( 1 ).base_value() ) )
    {
      p()->cooldown.shockwave->adjust(
          timespan_t::from_seconds( p()->talents.warrior.rumbling_earth->effectN( 2 ).base_value() ) );
    }
  }

  double composite_da_multiplier( const action_state_t* state ) const override
  {
    double m = warrior_attack_t::composite_da_multiplier( state );

    if ( p()->talents.colossus.one_against_many->ok() )
    {
      m *= 1.0 + ( p()->talents.colossus.one_against_many->effectN( 1 ).percent() * std::min( state -> n_targets,  as<unsigned int>( p()->talents.colossus.one_against_many->effectN( 2 ).base_value() ) ) );
    }

    return m;
  }
};

// Storm Bolt ===============================================================

struct storm_bolt_t : public warrior_attack_t
{
  storm_bolt_t( warrior_t* p, util::string_view options_str )
    : warrior_attack_t( "storm_bolt", p, p->talents.warrior.storm_bolt )
  {
    parse_options( options_str );
    may_dodge = may_parry = may_block = false;
    aoe = 1 + as<int>( data().effectN( 2 ).base_value() );
    if ( p->talents.slayer.unrelenting_onslaught->ok() )
      usable_while_channeling = true;
  }

  bool ready() override
  {
    if ( p()->main_hand_weapon.type == WEAPON_NONE )
    {
      return false;
    }
    return warrior_attack_t::ready();
  }
};

// Tough as Nails ===========================================================

struct tough_as_nails_t : public warrior_attack_t
{
  bool critical_block;
  tough_as_nails_t( warrior_t* p ) :
    warrior_attack_t( "tough_as_nails", p, p -> find_spell( 385890 ) ),
    critical_block( false )
  {
    may_crit = false;

    background = true;
  }

  double composite_da_multiplier( const action_state_t* state ) const override
  {
    double m = warrior_attack_t::composite_da_multiplier( state );

    // TODO this does not seem to currently work on PTR, so stub it out
    // if ( p()->sim->dbc->wowv() > wowv_t { 11, 2, 0 } )
    // {
    //   if ( critical_block )
    //     m *= 2.0;  // Not in spelldata, but critical blocks deal double damage
    // }

    return m;
  }

  void execute() override
  {
    warrior_attack_t::execute();

    p() -> cooldown.tough_as_nails_icd -> start();
  }
};

// Victory Rush =============================================================

struct victory_rush_heal_t : public warrior_heal_t
{
  victory_rush_heal_t( warrior_t* p ) : warrior_heal_t( "victory_rush_heal", p, p->find_spell( 118779 ) )
  {
    base_pct_heal = data().effectN( 1 ).percent();
    background    = true;
  }
  resource_e current_resource() const override
  {
    return RESOURCE_NONE;
  }
};

struct victory_rush_t : public warrior_attack_t
{
  victory_rush_heal_t* victory_rush_heal;
  int aoe_targets;

  victory_rush_t( warrior_t* p, util::string_view options_str )
    : warrior_attack_t( "victory_rush", p, p->spell.victory_rush ), victory_rush_heal( new victory_rush_heal_t( p ) ),
    aoe_targets( as<int>( p->spell.whirlwind_buff->effectN( 1 ).base_value() ) )
  {
    parse_options( options_str );
    if ( p->non_dps_mechanics )
    {
      // With imp ww while you do hit every target, you still only get the single MT heal
      execute_action = victory_rush_heal;
    }
    cooldown->duration = timespan_t::from_seconds( 1000.0 );

    radius = 5;
    base_aoe_multiplier = p->spell.whirlwind_buff->effectN( 2 ).percent();
  }

  int n_targets() const override
  {
    if ( p()->buff.whirlwind->check() )
    {
      return aoe_targets + 1;
    }
    return warrior_attack_t::n_targets();
  }

  void execute() override
  {
    warrior_attack_t::execute();
    p() -> buff.whirlwind->decrement();
  }
};

// Whirlwind ================================================================

struct whirlwind_fury_damage_t : public warrior_attack_t
{
  warrior_attack_t* rend;
  whirlwind_fury_damage_t( util::string_view name, warrior_t* p, const spell_data_t* whirlwind )
    : warrior_attack_t( name, p, whirlwind ),
    rend( nullptr )
  {
    background = true;
    aoe = -1;
    reduced_aoe_targets = 5.0;

    if ( sim->dbc->wowv() < wowv_t( 12, 1, 0 ) && p->talents.warrior.rend.ok() && p->talents.fury.improved_whirlwind.ok() )
      rend = new rend_dot_t( p );
    if ( sim->dbc->wowv() >= wowv_t( 12, 1, 0 ) && p->talents.warrior.storm_of_blood.ok() )
      rend = new rend_dot_t( p );
  }

  void impact( action_state_t* state ) override
  {
    warrior_attack_t::impact( state );

    if ( p()->talents.warrior.rend.ok() && p()->talents.fury.improved_whirlwind.ok() &&
          rend && data().id() == p()->spec.whirlwind->effectN( 4 ).trigger()->id() &&
          sim->dbc->wowv() < wowv_t( 12, 1, 0 ) )
      rend->execute_on_target( state->target );
    else if ( sim->dbc->wowv() >= wowv_t( 12, 1, 0 ) && p()->talents.warrior.storm_of_blood.ok() &&
          rend && data().id() == p()->spec.whirlwind->effectN( 4 ).trigger()->id() )
      rend->execute_on_target( state->target );
  }

  double composite_da_multiplier( const action_state_t* state ) const override
  {
    double m = warrior_attack_t::composite_da_multiplier( state );
    if ( p()->talents.fury.meat_cleaver->ok() && p()->sim->target_non_sleeping_list.size() >= p()->talents.fury.meat_cleaver->effectN( 2 ).base_value() )
      m *= 1.0 + p()->talents.fury.meat_cleaver->effectN( 1 ).percent();

    if ( sim->dbc->wowv() >= wowv_t( 12, 1, 0 ) && p()->talents.fury.carving_blades.ok() &&
          state->n_targets == as<unsigned int>( p()->talents.fury.carving_blades->effectN( 2 ).base_value() ) )
    {
      m *= 1.0 + p()->talents.fury.carving_blades->effectN( 1 ).percent();
    }
    return m;
  }
};

struct fury_whirlwind_parent_t : public warrior_attack_t
{
  whirlwind_fury_damage_t* mh_first_attack;
  whirlwind_fury_damage_t* oh_first_attack;
  whirlwind_fury_damage_t* mh_other_attack;
  whirlwind_fury_damage_t* oh_other_attack;
  double base_rage_gain;
  double additional_rage_gain_per_target;
  fury_whirlwind_parent_t( warrior_t* p, util::string_view options_str )
    : warrior_attack_t( "whirlwind", p, p->spec.whirlwind ),
      mh_first_attack( nullptr ),
      oh_first_attack( nullptr ),
      mh_other_attack( nullptr ),
      oh_other_attack( nullptr ),
      base_rage_gain( p->spec.whirlwind->effectN( 1 ).base_value() ),
      additional_rage_gain_per_target( p->spec.whirlwind->effectN( 2 ).base_value() )
  {
    parse_options( options_str );
    radius = data().effectN( 1 ).trigger()->effectN( 1 ).radius_max();

    if ( p->main_hand_weapon.type != WEAPON_NONE )
    {
      mh_first_attack         = new whirlwind_fury_damage_t( "whirlwind_mh_first", p, data().effectN( 4 ).trigger() );
      mh_first_attack->weapon = &( p->main_hand_weapon );
      mh_first_attack->radius = radius;
      add_child( mh_first_attack );

      mh_other_attack         = new whirlwind_fury_damage_t( "whirlwind_mh_others", p, data().effectN( 6 ).trigger() );
      mh_other_attack->weapon = &( p->main_hand_weapon );
      mh_other_attack->radius = radius;
      add_child( mh_other_attack );

      if ( p->off_hand_weapon.type != WEAPON_NONE )
      {
        oh_first_attack         = new whirlwind_fury_damage_t( "whirlwind_oh_first", p, data().effectN( 5 ).trigger() );
        oh_first_attack->weapon = &( p->off_hand_weapon );
        oh_first_attack->radius = radius;
        add_child( oh_first_attack );

        oh_other_attack         = new whirlwind_fury_damage_t( "whirlwind_oh_others", p, data().effectN( 7 ).trigger() );
        oh_other_attack->weapon = &( p->off_hand_weapon );
        oh_other_attack->radius = radius;
        add_child( oh_other_attack );
      }
    }
  }

  void execute() override
  {
    warrior_attack_t::execute();

    // Rage gain is a little different between 12.1 and 12.0.

    if ( sim->dbc->wowv() < wowv_t( 12, 1, 0 ) )
    {
      if ( p()->talents.fury.improved_whirlwind->ok() )
      {
        const int num_available_targets = std::min( 5, as<int>( target_list().size() ));  // Capped to 5 targets
        p()->resource_gain( RESOURCE_RAGE, ( base_rage_gain + additional_rage_gain_per_target * num_available_targets ),
                          p()->gain.whirlwind );

        p()->buff.whirlwind->trigger( p()->buff.whirlwind->max_stack() );
      }
    }
    else if ( sim->dbc->wowv() >= wowv_t( 12, 1, 0 ) )
    {
      double rage_gained = base_rage_gain;
      if ( p()->talents.fury.improved_whirlwind.ok() )
      {
        const int num_available_targets = std::min( as<int>( p()->spec.whirlwind->effectN( 3 ).base_value() ), as<int>( target_list().size() ));  // Capped to 5 targets
        rage_gained += ( additional_rage_gain_per_target * num_available_targets );
        p()->buff.whirlwind->trigger( p()->buff.whirlwind->max_stack() );
      }
      p()->resource_gain( RESOURCE_RAGE, rage_gained, p()->gain.whirlwind );
    }

    mh_first_attack->execute_on_target( target );
    if ( oh_first_attack )
      oh_first_attack->execute_on_target( target );

    make_event( *sim, timespan_t::from_millis(data().effectN( 6 ).misc_value1()), [ this ]() { mh_other_attack->execute_on_target( target ); } );
    make_event( *sim, timespan_t::from_millis(data().effectN( 8 ).misc_value1()), [ this ]() { mh_other_attack->execute_on_target( target ); } );
    if ( oh_other_attack )
    {
      make_event( *sim, timespan_t::from_millis(data().effectN( 7 ).misc_value1()), [ this ]() { oh_other_attack->execute_on_target( target ); } );
      make_event( *sim, timespan_t::from_millis(data().effectN( 9 ).misc_value1()), [ this ]() { oh_other_attack->execute_on_target( target ); } );
    }
  }

  bool ready() override
  {
    if ( p()->main_hand_weapon.type == WEAPON_NONE )
    {
      return false;
    }

    return warrior_attack_t::ready();
  }
};

// Arms Whirlwind ========================================================

struct whirlwind_arms_damage_t : public warrior_attack_t
{
  whirlwind_arms_damage_t( util::string_view name, warrior_t* p, const spell_data_t* whirlwind )
    : warrior_attack_t( name, p, whirlwind )
  {
    aoe = -1;
    reduced_aoe_targets = 5.0;
    background = true;
  }

  double composite_da_multiplier( const action_state_t* state ) const override
  {
    double m = warrior_attack_t::composite_da_multiplier( state );

    if ( p()->talents.colossus.one_against_many->ok() && p()->specialization() == WARRIOR_ARMS )
    {
      m *= 1.0 + ( p()->talents.colossus.one_against_many->effectN( 1 ).percent() * std::min( state -> n_targets,  as<unsigned int>( p()->talents.colossus.one_against_many->effectN( 2 ).base_value() ) ) );
    }

    return m;
  }

  double composite_target_multiplier( player_t* target ) const override
  {
    double m = warrior_attack_t::composite_target_multiplier( target );
    if ( p()->talents.arms.mass_execution.ok() && target->health_percentage() < p()->talents.arms.mass_execution->effectN( 2 ).base_value() )
      m *= 1.0 + p()->talents.arms.mass_execution->effectN( 1 ).percent();
    return m;
  }

  void execute() override
  {
    warrior_attack_t::execute();

    if ( p()->talents.arms.collateral_damage.ok() && p()->buff.collateral_damage->up() && data().id() == 411547 )
      p()->buff.collateral_damage->expire();
  }
};

struct arms_whirlwind_parent_t : public warrior_attack_t
{
  double max_rage;
  slam_t* fervor_slam;
  whirlwind_arms_damage_t* first_attack;
  whirlwind_arms_damage_t* second_attack;
  whirlwind_arms_damage_t* third_attack;

  arms_whirlwind_parent_t( warrior_t* p, util::string_view options_str )
    : warrior_attack_t( "whirlwind", p, p->spell.whirlwind ),
      fervor_slam( nullptr ),
      first_attack( nullptr ),
      second_attack( nullptr ),
      third_attack( nullptr )
  {
    parse_options( options_str );
    radius = data().effectN( 1 ).trigger()->effectN( 1 ).radius_max();

    if ( p->main_hand_weapon.type != WEAPON_NONE )
    {
      first_attack         = new whirlwind_arms_damage_t( "whirlwind_1", p, data().effectN( 1 ).trigger() );
      first_attack->weapon = &( p->main_hand_weapon );
      first_attack->radius = radius;
      add_child( first_attack );

      second_attack         = new whirlwind_arms_damage_t( "whirlwind_2", p, data().effectN( 2 ).trigger() );
      second_attack->weapon = &( p->main_hand_weapon );
      second_attack->radius = radius;
      add_child( second_attack );

      third_attack         = new whirlwind_arms_damage_t( "whirlwind_3", p, data().effectN( 3 ).trigger() );
      third_attack->weapon = &( p->main_hand_weapon );
      third_attack->radius = radius;
      add_child( third_attack );

      if ( p->talents.arms.fervor_of_battle->ok() )
      {
        fervor_slam                               = new slam_t( "slam_whirlwind_fervor_of_battle", p );
        fervor_slam->from_fervor                  = true;
        add_child( fervor_slam );
      }
    }
  }

  void execute() override
  {
    warrior_attack_t::execute();

    first_attack->execute_on_target( target );

    if ( p() -> talents.arms.fervor_of_battle.ok() && first_attack->num_targets_hit >= p() -> talents.arms.fervor_of_battle -> effectN( 1 ).base_value() )
      fervor_slam->execute_on_target( target );

    make_event( *sim, timespan_t::from_millis(data().effectN( 2 ).misc_value1()), [ this ]() { second_attack->execute_on_target( target ); } );
    make_event( *sim, timespan_t::from_millis(data().effectN( 3 ).misc_value1()), [ this ]() { third_attack->execute_on_target( target ); } );
  }

  bool ready() override
  {
    if ( p()->main_hand_weapon.type == WEAPON_NONE )
    {
      return false;
    }

    return warrior_attack_t::ready();
  }
};

// Wrecking Throw ========================================================

struct wrecking_throw_damage_t : public warrior_attack_t
{
  wrecking_throw_damage_t( util::string_view name, warrior_t* p )
    : warrior_attack_t( name, p, p->talents.warrior.wrecking_throw->effectN( 1 ).trigger() )
  {
    background = dual = true;
    ignores_armor = true;
    may_crit = false;
    may_dodge = may_parry = may_block = false;
  }
};

struct wrecking_throw_t : public warrior_attack_t
{
  wrecking_throw_t( warrior_t* p, util::string_view options_str )
    : warrior_attack_t( "wrecking_throw", p, p->talents.warrior.wrecking_throw )
  {
    parse_options( options_str );
    may_crit = may_parry = may_dodge = may_block = false;
    weapon = &( player->main_hand_weapon );

    execute_action = get_action<wrecking_throw_damage_t>( "wrecking_throw_damage", p );
    execute_action->stats = stats;
    stats->action_list.push_back( execute_action );
  }
  // add absorb shield bonus (are those even in SimC?)
};

// Champion's Spear==========================================================

struct champions_leap_t : public warrior_attack_t
{
  champions_leap_t( warrior_t* p, util::string_view options_str )
    : warrior_attack_t( "champions_leap", p, p->find_spell( 1271985 ) )
    {
      parse_options( options_str );
      aoe = -1;
      reduced_aoe_targets        = 5.0;
      cooldown->duration = p->find_spell( 1271980 )->cooldown();
    }

  bool ready() override
  {
    if ( !p()->buff.champions_spear->up() )
      return false;

    return warrior_attack_t::ready();
  }
};

struct champions_spear_damage_t : public warrior_attack_t
{
  double rage_gain;
  champions_spear_damage_t( util::string_view name, warrior_t* p ) : warrior_attack_t( name, p, p->find_spell( 376080 ) ),
  rage_gain( p->find_spell( 376080 )->effectN( 3 ).resource( RESOURCE_RAGE ) )
  {
    background = tick_may_crit = true;
    hasted_ticks               = true;
    aoe                        = -1;
    reduced_aoe_targets        = 5.0;
    dual                       = true;
    allow_class_ability_procs  = true;
    energize_type     = action_energize::NONE;
  }

  void execute() override
  {
    warrior_attack_t::execute();

    p()->resource_gain( RESOURCE_RAGE, rage_gain, p()->gain.champions_spear, this );
    p()->buff.champions_spear->trigger();
  }
};

struct champions_spear_t : public warrior_attack_t
{
  action_t* champions_spear_attack;
  champions_spear_t( warrior_t* p, util::string_view options_str )
    : warrior_attack_t( "champions_spear", p, p->talents.warrior.champions_spear ),
    champions_spear_attack( get_action<champions_spear_damage_t>( "champions_spear_damage", p ) )
  {
    parse_options( options_str );
    may_dodge = may_parry = may_block = false;
    aoe = -1;
    reduced_aoe_targets               = 5.0;

    execute_action = champions_spear_attack;
    add_child( execute_action );

    energize_type     = action_energize::NONE;
  }
};

// ==========================================================================
// Warrior Spells
// ==========================================================================

// Battle Shout ===================================================================

struct battle_shout_t : public warrior_spell_t
{
  battle_shout_t( warrior_t* p, util::string_view options_str )
    : warrior_spell_t( "battle_shout", p, p->spell.battle_shout )
  {
    parse_options( options_str );
    usable_while_channeling = true;
    harmful = false;
    target  = p;

    background = sim->overrides.battle_shout != 0;
  }

  void execute() override
  {
    sim->auras.battle_shout->trigger();
  }

  bool ready() override
  {
    return warrior_spell_t::ready() && !sim->auras.battle_shout->check();
  }
};

// Berserker Rage ===========================================================

struct berserker_rage_t : public warrior_spell_t
{
  berserker_rage_t( warrior_t* p, util::string_view options_str )
    : warrior_spell_t( "berserker_rage", p, p->spell.berserker_rage )
  {
    parse_options( options_str );
    callbacks   = false;
    use_off_gcd = true;
    range       = -1;
  }

  void execute() override
  {
    warrior_spell_t::execute();

    p()->buff.berserker_rage->trigger();
  }
};

// Battle Stance ===============================================================

struct battle_stance_t : public warrior_spell_t
{
  std::string onoff;
  bool onoffbool;
  battle_stance_t( warrior_t* p, util::string_view options_str )
    : warrior_spell_t( "battle_stance", p, p->talents.warrior.battle_stance ), onoff(), onoffbool( false )
  {
    add_option( opt_string( "toggle", onoff ) );
    parse_options( options_str );
    harmful = false;
    target  = p;

    if ( onoff == "on" )
    {
      onoffbool = true;
    }
    else if ( onoff == "off" )
    {
      onoffbool = false;
    }
    else
    {
      sim->errorf( "Battle stance must use the option 'toggle=on' or 'toggle=off'" );
      background = true;
    }

    use_off_gcd = true;

    //background = sim->overrides.battle_stance != 0;
  }

  void execute() override
  {
    warrior_spell_t::execute();
    if ( onoffbool )
    {
      p()->buff.battle_stance->trigger();
    }
    else
    {
      p()->buff.battle_stance->expire();
    }
  }

  bool ready() override
  {
    if ( onoffbool && p()->buff.battle_stance->check() )
    {
      return false;
    }
    else if ( !onoffbool && !p()->buff.battle_stance->check() )
    {
      return false;
    }

    return warrior_spell_t::ready(); // && !sim->auras.battle_stance->check();
  }
};

// Berserker Stance ===============================================================

struct berserker_stance_t : public warrior_spell_t
{
  std::string onoff;
  bool onoffbool;
  berserker_stance_t( warrior_t* p, util::string_view options_str )
    : warrior_spell_t( "berserker_stance", p, p->talents.warrior.berserker_stance ), onoff(), onoffbool( false )
  {
    add_option( opt_string( "toggle", onoff ) );
    parse_options( options_str );
    harmful = false;
    target  = p;

    if ( onoff == "on" )
    {
      onoffbool = true;
    }
    else if ( onoff == "off" )
    {
      onoffbool = false;
    }
    else
    {
      sim->errorf( "Berserker stance must use the option 'toggle=on' or 'toggle=off'" );
      background = true;
    }

    use_off_gcd = true;
  }

  void execute() override
  {
    warrior_spell_t::execute();
    if ( onoffbool )
    {
      p()->buff.berserker_stance->trigger();
    }
    else
    {
      p()->buff.berserker_stance->expire();
    }
  }

  bool ready() override
  {
    if ( onoffbool && p()->buff.berserker_stance->check() )
    {
      return false;
    }
    else if ( !onoffbool && !p()->buff.berserker_stance->check() )
    {
      return false;
    }

    return warrior_spell_t::ready();
  }
};

// Defensive Stance ===============================================================

struct defensive_stance_t : public warrior_spell_t
{
  std::string onoff;
  bool onoffbool;
  defensive_stance_t( warrior_t* p, util::string_view options_str )
    : warrior_spell_t( "defensive_stance", p, p->talents.warrior.defensive_stance ), onoff(), onoffbool( false )
  {
    add_option( opt_string( "toggle", onoff ) );
    parse_options( options_str );
    harmful = false;
    target = p;

    if ( onoff == "on" )
    {
      onoffbool = true;
    }
    else if ( onoff == "off" )
    {
      onoffbool = false;
    }
    else
    {
      sim->errorf( "Defensive stance must use the option 'toggle=on' or 'toggle=off'" );
      background = true;
    }

    use_off_gcd = true;
  }

  void execute() override
  {
    warrior_spell_t::execute();
    if ( onoffbool )
    {
      p()->buff.defensive_stance->trigger();
    }
    else
    {
      p()->buff.defensive_stance->expire();
    }
  }

  bool ready() override
  {
    if ( onoffbool && p()->buff.defensive_stance->check() )
    {
      return false;
    }
    else if ( !onoffbool && !p()->buff.defensive_stance->check() )
    {
      return false;
    }

    return warrior_spell_t::ready();
  }
};

// Die By the Sword  ==============================================================

struct die_by_the_sword_t : public warrior_spell_t
{
  die_by_the_sword_t( warrior_t* p, util::string_view options_str )
    : warrior_spell_t( "die_by_the_sword", p, p->talents.arms.die_by_the_sword )
  {
    parse_options( options_str );
    callbacks = false;
    range     = -1;
  }

  void execute() override
  {
    warrior_spell_t::execute();
    p()->buff.die_by_the_sword->trigger();
  }

  bool ready() override
  {
    if ( p()->main_hand_weapon.type == WEAPON_NONE )
    {
      return false;
    }

    return warrior_spell_t::ready();
  }
};

// Rallying Cry ===============================================================

struct rallying_cry_t : public warrior_spell_t
{
  rallying_cry_t( warrior_t* p, util::string_view options_str )
    : warrior_spell_t( "rallying_cry", p, p->talents.warrior.rallying_cry )
  {
    parse_options( options_str );
    callbacks = false;
    range     = -1;
  }

  void execute() override
  {
    warrior_spell_t::execute();

    assert( p()->buff.rallying_cry );
    p()->buff.rallying_cry->trigger();
  }
};

// Recklessness =============================================================

struct recklessness_t : public warrior_spell_t
{
  recklessness_t( warrior_t* p, util::string_view options_str, util::string_view n, const spell_data_t* spell )
    : warrior_spell_t( n, p, spell )
  {
    parse_options( options_str );
    callbacks  = false;
    harmful    = false;
    target     = p;

    if ( p->talents.fury.reckless_abandon->ok() )
    {
      energize_amount   = p->talents.fury.reckless_abandon->effectN( 1 ).base_value() / 10.0;
      energize_type     = action_energize::ON_CAST;
      energize_resource = RESOURCE_RAGE;
    }
  }

  void execute() override
  {
    warrior_spell_t::execute();

    p()->buff.recklessness->extend_duration_or_trigger();
    p()->fury_mid2_2pc_extensions = 0;  // Reset counter on hard cast
    if ( p()->buff.fury_mid2_4pc_crit )
      p()->buff.fury_mid2_4pc_crit->expire();

    if ( p()->talents.mountain_thane.snap_induction->ok() )
      p()->buff.thunder_blast->trigger();

    if ( p()->talents.fury.rampaging_berserker_3->ok() )
      p()->buff.berserk->trigger( as<int>( p()->talents.fury.rampaging_berserker_3->effectN( 2 ).base_value() ) );
  }
};

// Shield Block =============================================================

struct shield_block_t : public warrior_spell_t
{
  shield_block_t( warrior_t* p, util::string_view options_str )
    : warrior_spell_t( "shield_block", p, p->spell.shield_block )
  {
    parse_options( options_str );
    cooldown->hasted = true;
    cooldown->charges += as<int>( p->spec.shield_block_2->effectN( 1 ).base_value() );
  }

  void execute() override
  {
    warrior_spell_t::execute();

    p()->buff.shield_block->extend_duration_or_trigger( p()->buff.shield_block->buff_duration() );

  }

  bool ready() override
  {
    if ( !p()->has_shield_equipped() )
    {
      return false;
    }

    return warrior_spell_t::ready();
  }
};

// Shield Wall ==============================================================

struct shield_wall_t : public warrior_spell_t
{
  action_t* avatar;
  shield_wall_t( warrior_t* p, util::string_view options_str )
    : warrior_spell_t( "shield_wall", p, p->talents.protection.shield_wall ),
    avatar( nullptr )
  {
    parse_options( options_str );
    harmful = false;
    range   = -1;
  }

  void execute() override
  {
    warrior_spell_t::execute();

    p()->buff.shield_wall->trigger( 1, p()->buff.shield_wall->data().effectN( 1 ).percent() );
    if( p()->talents.protection.last_stand->ok() )
      p()->buff.last_stand->trigger();
  }
};

// Spell Reflection  ==============================================================

struct spell_reflection_t : public warrior_spell_t
{
  spell_reflection_t( warrior_t* p, util::string_view options_str )
    : warrior_spell_t( "spell_reflection", p, p->talents.warrior.spell_reflection )
  {
    parse_options( options_str );
    use_off_gcd = usable_while_channeling = true;
  }

  void execute() override
  {
    warrior_spell_t::execute();
    p()->buff.spell_reflection->trigger();
  }
};

// Taunt =======================================================================

struct taunt_t : public warrior_spell_t
{
  taunt_t( warrior_t* p, util::string_view options_str )
    : warrior_spell_t( "taunt", p, p->find_class_spell( "Taunt" ) )
  {
    parse_options( options_str );
    use_off_gcd = ignore_false_positive = true;
  }

  void impact( action_state_t* s ) override
  {
    if ( s->target->is_enemy() )
    {
      target->taunt( player );
    }

    warrior_spell_t::impact( s );
  }
};

// ==========================================================================
// Warrior Proc Callbacks
// ==========================================================================
struct warrior_proc_callback_t : public dbc_proc_callback_t
{
  warrior_proc_callback_t( const special_effect_t& e ) : dbc_proc_callback_t( e.player, e )
  {
    initialize();
    activate();
  }

  warrior_t* p() const
  {
    return debug_cast<warrior_t*>( listener );
  }
  warrior_t* p()
  {
    return debug_cast<warrior_t*>( listener );
  }
};

}  // UNNAMED NAMESPACE

// warrior_t::create_action  ================================================

action_t* warrior_t::create_action( util::string_view name, util::string_view options_str )
{
  if ( name == "auto_attack" )
    return new auto_attack_t( this, options_str );
  if ( name == "avatar" )
    return new avatar_t( this, options_str, name, talents.shared.avatar );
  if ( name == "battle_shout" )
    return new battle_shout_t( this, options_str );
  if ( name == "recklessness" )
    return new recklessness_t( this, options_str, name, specialization() == WARRIOR_FURY ? talents.fury.recklessness : find_spell( 1719 ) );
  if ( name == "battle_stance" )
    return new battle_stance_t( this, options_str );
  if ( name == "berserker_rage" )
    return new berserker_rage_t( this, options_str );
  if ( name == "berserker_stance" )
    return new berserker_stance_t( this, options_str );
  if ( name == "bladestorm" )
    return new bladestorm_t( this, options_str, name, talents.slayer.unrelenting_onslaught->ok() && talents.shared.bladestorm.ok() ? find_spell( 446035 ) : talents.shared.bladestorm );
  if ( name == "bloodthirst" )
    return new bloodthirst_t( this, options_str );
  if ( name == "bloodbath" )
    return new bloodbath_t( this, options_str );
  if ( name == "charge" )
    return new charge_t( this, options_str );
  if ( name == "cleave" )
    return new cleave_t( this, options_str );
  if ( name == "colossus_smash" )
    return new colossus_smash_t( this, options_str );
  if ( name == "defensive_stance" )
    return new defensive_stance_t( this, options_str );
  if ( name == "demoralizing_shout" )
    return new demoralizing_shout_t( this, options_str );
  if ( name == "devastate" )
    return new devastate_t( this, options_str );
  if ( name == "die_by_the_sword" )
    return new die_by_the_sword_t( this, options_str );
  if ( name == "enraged_regeneration" )
    return new enraged_regeneration_t( this, options_str );
  if ( name == "execute" )
  {
    if ( specialization() == WARRIOR_FURY )
    {
      return new execute_fury_t( this, options_str );
    }
    else
    {
      return new execute_arms_t( this, options_str );
    }
  }
  if ( name == "hamstring" )
    return new hamstring_t( this, options_str );
  if ( name == "heroic_charge" )
    return new heroic_charge_t( this, options_str );
  if ( name == "heroic_leap" )
    return new heroic_leap_t( this, options_str );
  if ( name == "heroic_strike" )
    return new heroic_strike_t( this, options_str );
  if ( name == "heroic_throw" )
    return new heroic_throw_t( this, options_str );
  if ( name == "impending_victory" )
    return new impending_victory_t( this, options_str );
  if ( name == "intervene" )
    return new intervene_t( this, options_str );
  if ( name == "mortal_strike" )
    return new mortal_strike_t( this, options_str );
  if ( name == "odyns_fury" )
    return new odyns_fury_t( this, options_str, name, talents.fury.odyns_fury );
  if ( name == "overpower" )
    return new overpower_t( this, options_str );
  if ( name == "piercing_howl" )
    return new piercing_howl_t( this, options_str );
  if ( name == "pummel" )
    return new pummel_t( this, options_str );
  if ( name == "raging_blow" )
    return new raging_blow_t( this, options_str );
  if ( name == "crushing_blow" )
    return new crushing_blow_t( this, options_str );
  if ( name == "rallying_cry" )
    return new rallying_cry_t( this, options_str );
  if ( name == "rampage" )
    return new rampage_parent_t( this, options_str );
  if ( name == "ravager" )
    return new ravager_t( this, options_str );
  if ( name == "rend" )
      return new rend_t( this, options_str );
  if ( name == "revenge" )
    return new revenge_t( this, options_str );
  if ( name == "shattering_throw" )
    return new shattering_throw_t( this, options_str );
  if ( name == "shield_block" )
    return new shield_block_t( this, options_str );
  if ( name == "shield_charge" )
    return new shield_charge_t( this, options_str );
  if ( name == "shield_slam" )
    return new shield_slam_t( this, options_str );
  if ( name == "shield_wall" )
    return new shield_wall_t( this, options_str );
  if ( name == "shockwave" )
    return new shockwave_t( this, options_str );
  if ( name == "slam" )
    return new slam_t( this, options_str );
  if ( name == "champions_leap" )
    return new champions_leap_t( this, options_str );
  if ( name == "champions_spear" )
    return new champions_spear_t( this, options_str );
  if ( name == "spell_reflection" )
    return new spell_reflection_t( this, options_str );
  if ( name == "storm_bolt" )
    return new storm_bolt_t( this, options_str );
  if ( name == "sweeping_strikes" )
    return new sweeping_strikes_t( this, options_str );
  if ( name == "taunt" )
    return new taunt_t( this, options_str );
  if ( name == "thunder_clap" )
    return new thunder_clap_t( this, options_str );
  if ( name == "thunder_blast" )
    return new thunder_blast_t( this, options_str );
  if ( name == "victory_rush" )
    return new victory_rush_t( this, options_str );
  if ( name == "ignore_pain" )
    return new ignore_pain_t( this, options_str );
  if ( name == "whirlwind" )
  {
    if ( specialization() == WARRIOR_FURY )
    {
      return new fury_whirlwind_parent_t( this, options_str );
    }
    else if ( specialization() == WARRIOR_ARMS )
    {
      return new arms_whirlwind_parent_t( this, options_str );
    }
  }
  if ( name == "wrecking_throw" )
    return new wrecking_throw_t( this, options_str );
  if ( name == "demolish" )
    return new demolish_t( this, options_str );

  return parse_player_effects_t::create_action( name, options_str );
}

// warrior_t::init_spells ===================================================

void warrior_t::init_spells()
{
  parse_player_effects_t::init_spells();

  // Core Class Spells
  spell.avatar                  = find_spell( 107574 );
  spell.battle_shout            = find_class_spell( "Battle Shout" );
  spell.berserker_rage          = find_class_spell( "Berserker Rage" );
  spell.charge                  = find_class_spell( "Charge" );
  spell.execute                 = find_class_spell( "Execute" );
  spell.execute_rage_refund     = find_spell( 163201 );
  spell.hamstring               = find_class_spell( "Hamstring" );
  spell.heroic_throw            = find_class_spell( "Heroic Throw" );
  spell.pummel                  = find_class_spell( "Pummel" );
  spell.shield_block            = find_class_spell( "Shield Block" );
  spell.shield_slam             = find_class_spell( "Shield Slam" );
  spell.slam                    = find_class_spell( "Slam" );
  spell.taunt                   = find_class_spell( "Taunt" );
  spell.victory_rush            = find_class_spell( "Victory Rush" );
  spell.whirlwind               = find_class_spell( "Whirlwind" );
  spell.shield_block_buff       = find_spell( 132404 );
  spell.recklessness_buff       = find_spell( 1719 ); // lookup to allow Warlord to use Reck
  spell.ravaged_debuff          = find_spell( 1299405 );

  // Class Passives
  spec.warrior                  = find_spell( 137047 );
  spec.warrior_2                = find_spell( 462116 );

  // Arms Spells
  mastery.master_of_arms        = find_mastery_spell( WARRIOR_ARMS );
  spec.arms_warrior             = find_specialization_spell( "Arms Warrior" );
  spec.arms_warrior_2           = find_spell( 462115 ); // Trinket aura
  spec.seasoned_soldier         = find_specialization_spell( "Seasoned Soldier" );
  spec.sweeping_strikes         = find_specialization_spell( "Sweeping Strikes" );
  spell.colossus_smash_debuff   = find_spell( 208086 );
  spell.deep_wounds_dot         = find_spell( 262115 );
  spell.fatal_mark_debuff       = find_spell( 383704 );
  spell.heroic_strike           = find_spell( 1269383 );
  spell.master_of_warfare_2_buff= find_spell( 1269394 );
  spell.battlelord_buff         = find_spell( 386631 );
  spell.rend_dot                = find_spell( 388539 );

  // Fury Spells
  mastery.unshackled_fury       = find_mastery_spell( WARRIOR_FURY );
  spec.fury_warrior             = find_specialization_spell( "Fury Warrior" );
  spec.fury_warrior_2           = find_spell( 462117 );  // Trinket aura
  spec.execute                  = find_specialization_spell( "Execute" );
  spec.whirlwind                = find_specialization_spell( "Whirlwind" );
  spec.bloodbath                = find_spell(335096);
  spec.crushing_blow            = find_spell(335097);
  spell.whirlwind_buff          = find_spell( 85739, WARRIOR_FURY );
  if ( sim->dbc->wowv() >= wowv_t( 12, 1, 0 ) )
    spell.rampaging_ruin_damage   = find_spell( 1299944 );

  // Protection Spells
  mastery.critical_block        = find_mastery_spell( WARRIOR_PROTECTION );
  spec.protection_warrior       = find_specialization_spell( "Protection Warrior" );  // Main spec effects
  spec.protection_warrior_2     = find_spell( 462119 );  // Trinket aura
  spec.protection_warrior_3     = find_spell( 1258163 );  // More spec effects
  spec.devastate                = find_specialization_spell( "Devastate" );
  spec.riposte                  = find_specialization_spell( "Riposte" );
  spec.vanguard                 = find_specialization_spell( "Vanguard" );
  spec.revenge_trigger          = find_specialization_spell("Revenge Trigger");
  spec.shield_block_2           = find_specialization_spell( 231847 ); // extra charge
  spell.shield_wall             = find_spell( 871 );
  spell.devastator              = find_spell( 236279 );
  spell.devastating_focus_debuff= find_spell( 1277983 );
  spell.phalanx_buff            = find_spell( 1278009 );
  spell.phalanx_debuff          = find_spell( 1292071 );

  // Shared Spells
  spell.bloodsurge_energize     = find_spell( 384362 );
  spell.ravager                 = find_spell( 228920 );
  spell.sudden_death_buff       = find_spell( 52437 );

  // Colossus Spells
  spell.wrecked_debuff              = find_spell( 447513 );

  // Slayer Spells
  spell.slayers_strike              = find_spell( 445579 );
  spell.overwhelmed_debuff          = find_spell( 445836 );
  spell.reap_the_storm              = find_spell( 446005 );

  // Mountain Thane Spells
  spell.lightning_strike            = find_spell( 435791 );

  // Class Talents
  // Arms Battle / Defensive
  // Fury Berserker / Defensive
  // Prot Battle / Defensive
  // Row 1
  talents.warrior.battle_stance                    = find_talent_spell( talent_tree::CLASS, "Battle Stance" );
  talents.warrior.berserker_stance                 = find_talent_spell( talent_tree::CLASS, "Berserker Stance" );
  talents.warrior.defensive_stance                 = find_talent_spell( talent_tree::CLASS, "Defensive Stance" );
  // Row 2
  talents.warrior.fast_footwork                    = find_talent_spell( talent_tree::CLASS, "Fast Footwork" );
  talents.warrior.war_machine                      = find_talent_spell( talent_tree::CLASS, "War Machine", specialization() );
  talents.warrior.thunder_clap                     = find_talent_spell( talent_tree::CLASS, "Thunder Clap", specialization() );
  talents.warrior.leeching_strikes                 = find_talent_spell( talent_tree::CLASS, "Leeching Strikes" );
  // Row 3
  talents.warrior.impending_victory                = find_talent_spell( talent_tree::CLASS, "Impending Victory" );
  talents.warrior.heroic_leap                      = find_talent_spell( talent_tree::CLASS, "Heroic Leap" );
  talents.warrior.crackling_thunder                = find_talent_spell( talent_tree::CLASS, "Crackling Thunder" );
  talents.warrior.storm_bolt                       = find_talent_spell( talent_tree::CLASS, "Storm Bolt" );
  // Row 4
  talents.warrior.rend                             = find_talent_spell( talent_tree::CLASS, "Rend" );
  talents.warrior.storm_of_blood                   = find_talent_spell( talent_tree::CLASS, "Storm of Blood", specialization() );
  talents.warrior.blood_and_thunder                = find_talent_spell( talent_tree::CLASS, "Blood and Thunder", specialization() );
  talents.warrior.second_wind                      = find_talent_spell( talent_tree::CLASS, "Second Wind" );
  talents.warrior.frothing_berserker               = find_talent_spell( talent_tree::CLASS, "Frothing Berserker", specialization() );
  talents.warrior.bounding_stride                  = find_talent_spell( talent_tree::CLASS, "Bounding Stride" );
  talents.warrior.pain_and_gain                    = find_talent_spell( talent_tree::CLASS, "Pain and Gain" );
  talents.warrior.intervene                        = find_talent_spell( talent_tree::CLASS, "Intervene" );
  talents.warrior.interpose                        = find_talent_spell( talent_tree::CLASS, "Interpose" );
  // Row 5
  talents.warrior.shockwave                        = find_talent_spell( talent_tree::CLASS, "Shockwave" );
  talents.warrior.overwhelming_rage                = find_talent_spell( talent_tree::CLASS, "Overwhelming Rage" );
  talents.warrior.rallying_cry                     = find_talent_spell( talent_tree::CLASS, "Rallying Cry" );
  talents.warrior.field_dressing                   = find_talent_spell( talent_tree::CLASS, "Field Dressing" );
  talents.warrior.spell_reflection                 = find_talent_spell( talent_tree::CLASS, "Spell Reflection" );
  // Row 6
  talents.warrior.wrecking_throw                   = find_talent_spell( talent_tree::CLASS, "Wrecking Throw" );
  talents.warrior.shattering_throw                 = find_talent_spell( talent_tree::CLASS, "Shattering Throw" );
  talents.warrior.rumbling_earth                   = find_talent_spell( talent_tree::CLASS, "Rumbling Earth" );
  talents.warrior.berserker_shout                  = find_talent_spell( talent_tree::CLASS, "Berserker Shout" );
  talents.warrior.fearless                         = find_talent_spell( talent_tree::CLASS, "Fearless" );
  talents.warrior.intimidating_shout               = find_talent_spell( talent_tree::CLASS, "Intimidating Shout" );
  talents.warrior.piercing_howl                    = find_talent_spell( talent_tree::CLASS, "Piercing Howl" );
  talents.warrior.honed_reflexes                   = find_talent_spell( talent_tree::CLASS, "Honed Reflexes" );
  // Row 7
  talents.warrior.armored_to_the_teeth             = find_talent_spell( talent_tree::CLASS, "Armored to the Teeth" );
  talents.warrior.double_time                      = find_talent_spell( talent_tree::CLASS, "Double Time" );
  talents.warrior.reinforced_plates                = find_talent_spell( talent_tree::CLASS, "Reinforced Plates" );
  // Row 8
  talents.warrior.barbaric_training                = find_talent_spell( talent_tree::CLASS, "Barbaric Training" );
  talents.warrior.javelineer                       = find_talent_spell( talent_tree::CLASS, "Javelineer" );
  talents.warrior.resonant_voice                   = find_talent_spell( talent_tree::CLASS, "Resonant Voice" );
  talents.warrior.crushing_force                   = find_talent_spell( talent_tree::CLASS, "Crushing Force", specialization() );
  // Row 9
  talents.warrior.cruel_strikes                    = find_talent_spell( talent_tree::CLASS, "Cruel Strikes" );
  talents.warrior.two_handed_weapon_specialization = find_talent_spell( talent_tree::CLASS, "Two-Handed Weapon Specialization", specialization() );
  talents.warrior.dual_wield_specialization        = find_talent_spell( talent_tree::CLASS, "Dual Wield Specialization", specialization() );
  talents.warrior.one_handed_weapon_specialization = find_talent_spell( talent_tree::CLASS, "One-Handed Weapon Specialization", specialization() );
  talents.warrior.wild_strikes                     = find_talent_spell( talent_tree::CLASS, "Wild Strikes" );
  // Row 10
  talents.warrior.anger_management                 = find_talent_spell( talent_tree::CLASS, "Anger Management", specialization() );
  talents.warrior.champions_spear                  = find_talent_spell( talent_tree::CLASS, "Champion's Spear" );
  talents.warrior.stance_mastery                   = find_talent_spell( talent_tree::CLASS, "Stance Mastery" );
  talents.warrior.battlefield_commander            = find_talent_spell( talent_tree::CLASS, "Battlefield Commander" );

  // Arms Talents
  // Row 1
  talents.arms.mortal_strike             = find_talent_spell( talent_tree::SPECIALIZATION, "Mortal Strike" );
  // Row 2
  talents.arms.overpower                 = find_talent_spell( talent_tree::SPECIALIZATION, "Overpower" );
  talents.arms.sudden_death              = find_talent_spell( talent_tree::SPECIALIZATION, "Sudden Death", WARRIOR_ARMS );
  // Row 3
  talents.arms.fueled_by_violence        = find_talent_spell( talent_tree::SPECIALIZATION, "Fueled by Violence", WARRIOR_ARMS );
  talents.arms.ignore_pain               = find_talent_spell( talent_tree::SPECIALIZATION, "Ignore Pain", WARRIOR_ARMS );
  talents.arms.die_by_the_sword          = find_talent_spell( talent_tree::SPECIALIZATION, "Die by the Sword" );
  // Row 4
  talents.arms.bloodsurge                = find_talent_spell( talent_tree::SPECIALIZATION, "Bloodsurge", WARRIOR_ARMS );
  talents.arms.improved_overpower        = find_talent_spell( talent_tree::SPECIALIZATION, "Improved Overpower" );
  talents.arms.improved_execute          = find_talent_spell( talent_tree::SPECIALIZATION, "Improved Execute", WARRIOR_ARMS );
  talents.arms.fervor_of_battle          = find_talent_spell( talent_tree::SPECIALIZATION, "Fervor of Battle" );
  // Row 5
  talents.arms.tactician                 = find_talent_spell( talent_tree::SPECIALIZATION, "Tactician" );
  talents.arms.colossus_smash            = find_talent_spell( talent_tree::SPECIALIZATION, "Colossus Smash" );
  talents.arms.impale                    = find_talent_spell( talent_tree::SPECIALIZATION, "Impale" );
  // Row 6
  talents.arms.brute_force               = find_talent_spell( talent_tree::SPECIALIZATION, "Brute Force" );
  talents.arms.efficiency                = find_talent_spell( talent_tree::SPECIALIZATION, "Efficiency" );
  talents.arms.overpowering_finish       = find_talent_spell( talent_tree::SPECIALIZATION, "Overpowering Finish" );
  talents.arms.strength_of_arms          = find_talent_spell( talent_tree::SPECIALIZATION, "Strength of Arms", WARRIOR_ARMS );
  talents.arms.just_warming_up           = find_talent_spell( talent_tree::SPECIALIZATION, "Just Warming Up" );
  talents.arms.broad_strokes             = find_talent_spell( talent_tree::SPECIALIZATION, "Broad Strokes" );
  talents.arms.sharpened_blades          = find_talent_spell( talent_tree::SPECIALIZATION, "Sharpened Blades" );
  talents.arms.cleave                    = find_talent_spell( talent_tree::SPECIALIZATION, "Cleave" );
  talents.arms.collateral_damage         = find_talent_spell( talent_tree::SPECIALIZATION, "Collateral Damage" );
  // Row 7
  talents.arms.martial_prowess           = find_talent_spell( talent_tree::SPECIALIZATION, "Martial Prowess" );
  talents.arms.dreadnaught               = find_talent_spell( talent_tree::SPECIALIZATION, "Dreadnaught" );
  talents.arms.deep_wounds               = find_talent_spell( talent_tree::SPECIALIZATION, "Deep Wounds", WARRIOR_ARMS );
  talents.arms.tactical_edge             = find_talent_spell( talent_tree::SPECIALIZATION, "Tactical Edge" );
  talents.arms.crushing_combo            = find_talent_spell( talent_tree::SPECIALIZATION, "Crushing Combo" );
  talents.arms.massacre                  = find_talent_spell( talent_tree::SPECIALIZATION, "Massacre", WARRIOR_ARMS );
  talents.arms.mass_execution            = find_talent_spell( talent_tree::SPECIALIZATION, "Mass Execution" );
  talents.arms.improved_sweeping_strikes = find_talent_spell( talent_tree::SPECIALIZATION, "Improved Sweeping Strikes", WARRIOR_ARMS );
  talents.arms.powerful_momentum         = find_talent_spell( talent_tree::SPECIALIZATION, "Powerful Momentum" );
  // Row 8
  talents.arms.bloodborne                = find_talent_spell( talent_tree::SPECIALIZATION, "Bloodborne", WARRIOR_ARMS );
  talents.arms.bladestorm                = find_talent_spell( talent_tree::SPECIALIZATION, "Bladestorm", WARRIOR_ARMS );
  talents.arms.ravager                   = find_talent_spell( talent_tree::SPECIALIZATION, "Ravager", WARRIOR_ARMS );
  talents.arms.critical_thinking         = find_talent_spell( talent_tree::SPECIALIZATION, "Critical Thinking", WARRIOR_ARMS );
  // Row 9
  talents.arms.battlelord                = find_talent_spell( talent_tree::SPECIALIZATION, "Battlelord" );
  talents.arms.bloodletting              = find_talent_spell( talent_tree::SPECIALIZATION, "Bloodletting" );  
  talents.arms.executioners_precision    = find_talent_spell( talent_tree::SPECIALIZATION, "Executioner's Precision" );
  talents.arms.fatality                  = find_talent_spell( talent_tree::SPECIALIZATION, "Fatality" );
  // Row 10
  talents.arms.master_tactician          = find_talent_spell( talent_tree::SPECIALIZATION, "Master Tactician" );
  talents.arms.mortal_wounds             = find_talent_spell( talent_tree::SPECIALIZATION, "Mortal Wounds" );
  talents.arms.avatar                    = find_talent_spell( talent_tree::SPECIALIZATION, "Avatar", WARRIOR_ARMS );
  // Apex
  talents.arms.master_of_warfare_1       = find_talent_spell( talent_tree::SPECIALIZATION, 1269314 );
  talents.arms.master_of_warfare_2       = find_talent_spell( talent_tree::SPECIALIZATION, 1269306 );
  talents.arms.master_of_warfare_3       = find_talent_spell( talent_tree::SPECIALIZATION, 1269307 );

  // Fury Talents
  // Row 1
  talents.fury.bloodthirst           = find_talent_spell( talent_tree::SPECIALIZATION, "Bloodthirst" );
  // Row 2
  talents.fury.raging_blow           = find_talent_spell( talent_tree::SPECIALIZATION, "Raging Blow" );
  // Row 3
  talents.fury.sudden_death          = find_talent_spell( talent_tree::SPECIALIZATION, "Sudden Death", WARRIOR_FURY );
  talents.fury.frenzied_enrage       = find_talent_spell( talent_tree::SPECIALIZATION, "Frenzied Enrage" );
  talents.fury.powerful_enrage       = find_talent_spell( talent_tree::SPECIALIZATION, "Powerful Enrage" );
  talents.fury.improved_execute      = find_talent_spell( talent_tree::SPECIALIZATION, "Improved Execute", WARRIOR_FURY );
  // Row 4
  talents.fury.focus_in_chaos        = find_talent_spell( talent_tree::SPECIALIZATION, "Focus in Chaos" );
  talents.fury.enraged_regeneration  = find_talent_spell( talent_tree::SPECIALIZATION, "Enraged Regeneration" );
  talents.fury.warpaint              = find_talent_spell( talent_tree::SPECIALIZATION, "Warpaint" );
  talents.fury.improved_whirlwind    = find_talent_spell( talent_tree::SPECIALIZATION, "Improved Whirlwind" );
  // Row 5
  talents.fury.massacre              = find_talent_spell( talent_tree::SPECIALIZATION, "Massacre", WARRIOR_FURY );
  talents.fury.fresh_meat            = find_talent_spell( talent_tree::SPECIALIZATION, "Fresh Meat" );
  talents.fury.invigorating_fury     = find_talent_spell( talent_tree::SPECIALIZATION, "Invigorating Fury" );
  talents.fury.rampage               = find_talent_spell( talent_tree::SPECIALIZATION, "Rampage" );
  talents.fury.improved_raging_blow  = find_talent_spell( talent_tree::SPECIALIZATION, "Improved Raging Blow" );
  talents.fury.rampaging_ruin        = find_talent_spell( talent_tree::SPECIALIZATION, "Rampaging Ruin" );
  // Row 6
  talents.fury.deep_wounds           = find_talent_spell( talent_tree::SPECIALIZATION, "Deep Wounds", WARRIOR_FURY );
  talents.fury.spite                 = find_talent_spell( talent_tree::SPECIALIZATION, "Spite" );
  talents.fury.scent_of_blood        = find_talent_spell( talent_tree::SPECIALIZATION, "Scent of Blood" );
  talents.fury.kill_or_be_killed     = find_talent_spell( talent_tree::SPECIALIZATION, "Kill or Be Killed" );
  talents.fury.hack_and_slash        = find_talent_spell( talent_tree::SPECIALIZATION, "Hack and Slash" );
  talents.fury.cruelty               = find_talent_spell( talent_tree::SPECIALIZATION, "Cruelty" );
  talents.fury.meat_cleaver          = find_talent_spell( talent_tree::SPECIALIZATION, "Meat Cleaver" );
  talents.fury.carving_blades        = find_talent_spell( talent_tree::SPECIALIZATION, "Carving Blades" );
  // Row 7
  talents.fury.cold_steel_hot_blood  = find_talent_spell( talent_tree::SPECIALIZATION, "Cold Steel, Hot Blood" );
  talents.fury.ragedrinker           = find_talent_spell( talent_tree::SPECIALIZATION, "Ragedrinker" );
  talents.fury.recklessness          = find_talent_spell( talent_tree::SPECIALIZATION, "Recklessness" );
  talents.fury.bloodcraze            = find_talent_spell( talent_tree::SPECIALIZATION, "Bloodcraze" );
  talents.fury.wrath_and_fury        = find_talent_spell( talent_tree::SPECIALIZATION, "Wrath and Fury" );
  // Row 8
  talents.fury.deft_experience       = find_talent_spell( talent_tree::SPECIALIZATION, "Deft Experience", WARRIOR_FURY );
  talents.fury.frenzy                = find_talent_spell( talent_tree::SPECIALIZATION, "Frenzy" );
  talents.fury.critical_thinking     = find_talent_spell( talent_tree::SPECIALIZATION, "Critical Thinking", WARRIOR_FURY );
  //Row 9
  talents.fury.vicious_contempt      = find_talent_spell( talent_tree::SPECIALIZATION, "Vicious Contempt" );
  talents.fury.odyns_fury            = find_talent_spell( talent_tree::SPECIALIZATION, "Odyn's Fury" );
  talents.fury.bloodborne            = find_talent_spell( talent_tree::SPECIALIZATION, "Bloodborne", WARRIOR_FURY );
  talents.fury.surge_of_adrenaline   = find_talent_spell( talent_tree::SPECIALIZATION, "Surge of Adrenaline" );
  // Row 10
  talents.fury.executioners_wrath    = find_talent_spell( talent_tree::SPECIALIZATION, "Executioner's Wrath" );
  talents.fury.reckless_abandon      = find_talent_spell( talent_tree::SPECIALIZATION, "Reckless Abandon" );
  talents.fury.avatar                = find_talent_spell( talent_tree::SPECIALIZATION, "Avatar", WARRIOR_FURY );
  talents.fury.bladestorm            = find_talent_spell( talent_tree::SPECIALIZATION, "Bladestorm", WARRIOR_FURY );
  // Apex
  talents.fury.rampaging_berserker_1 = find_talent_spell( talent_tree::SPECIALIZATION, 1269308 );
  talents.fury.rampaging_berserker_2 = find_talent_spell( talent_tree::SPECIALIZATION, 1269309 );
  talents.fury.rampaging_berserker_3 = find_talent_spell( talent_tree::SPECIALIZATION, 1269310 );

  // Protection Talents
  // Row 1
  talents.protection.ignore_pain            = find_talent_spell( talent_tree::SPECIALIZATION, "Ignore Pain", WARRIOR_PROTECTION );
  // Row 2
  talents.protection.demoralizing_shout     = find_talent_spell( talent_tree::SPECIALIZATION, "Demoralizing Shout" );
  talents.protection.revenge                = find_talent_spell( talent_tree::SPECIALIZATION, "Revenge" );
  // Row 3
  talents.protection.brace_for_impact       = find_talent_spell( talent_tree::SPECIALIZATION, "Brace for Impact" );
  talents.protection.armor_specialization   = find_talent_spell( talent_tree::SPECIALIZATION, "Armor Specialization", WARRIOR_PROTECTION );
  talents.protection.fight_through_the_flames = find_talent_spell( talent_tree::SPECIALIZATION, "Fight Through the Flames" );
  talents.protection.devastator             = find_talent_spell( talent_tree::SPECIALIZATION, "Devastator" );
  // Row 4
  talents.protection.disrupting_shout       = find_talent_spell( talent_tree::SPECIALIZATION, "Disrupting Shout" );
  talents.protection.strategist             = find_talent_spell( talent_tree::SPECIALIZATION, "Strategist" );
  talents.protection.devastating_focus      = find_talent_spell( talent_tree::SPECIALIZATION, "Devastating Focus" );
  // Row 5
  talents.protection.brutal_vitality        = find_talent_spell( talent_tree::SPECIALIZATION, "Brutal Vitality" ); // NYI
  talents.protection.instigate              = find_talent_spell( talent_tree::SPECIALIZATION, "Instigate" );
  talents.protection.shield_wall            = find_talent_spell( talent_tree::SPECIALIZATION, "Shield Wall" );
  talents.protection.bloodsurge             = find_talent_spell( talent_tree::SPECIALIZATION, "Bloodsurge", WARRIOR_PROTECTION );
  talents.protection.best_served_cold       = find_talent_spell( talent_tree::SPECIALIZATION, "Best Served Cold" );
  // Row 6
  talents.protection.spellbreaker           = find_talent_spell( talent_tree::SPECIALIZATION, "Spell Breaker", WARRIOR_PROTECTION );
  talents.protection.hunker_down            = find_talent_spell( talent_tree::SPECIALIZATION, "Hunker Down", WARRIOR_PROTECTION );
  talents.protection.thunderlord            = find_talent_spell( talent_tree::SPECIALIZATION, "Thunderlord" );
  talents.protection.defenders_aegis        = find_talent_spell( talent_tree::SPECIALIZATION, "Defender's Aegis" );
  talents.protection.impenetrable_wall      = find_talent_spell( talent_tree::SPECIALIZATION, "Impenetrable Wall" );
  talents.protection.last_stand             = find_talent_spell( talent_tree::SPECIALIZATION, "Last Stand", WARRIOR_PROTECTION );
  talents.protection.bloodborne             = find_talent_spell( talent_tree::SPECIALIZATION, "Bloodborne", WARRIOR_PROTECTION );
  talents.protection.sudden_death           = find_talent_spell( talent_tree::SPECIALIZATION, "Sudden Death", WARRIOR_PROTECTION );
  talents.protection.punish                 = find_talent_spell( talent_tree::SPECIALIZATION, "Punish" );
  // Row 7
  talents.protection.tough_as_nails         = find_talent_spell( talent_tree::SPECIALIZATION, "Tough as Nails" );
  talents.protection.fueled_by_violence     = find_talent_spell( talent_tree::SPECIALIZATION, "Fueled by Violence", WARRIOR_PROTECTION );
  talents.protection.enduring_defenses      = find_talent_spell( talent_tree::SPECIALIZATION, "Enduring Defenses" );
  talents.protection.unyielding_stance      = find_talent_spell( talent_tree::SPECIALIZATION, "Unyielding Stance", WARRIOR_PROTECTION );
  talents.protection.deep_wounds            = find_talent_spell( talent_tree::SPECIALIZATION, "Deep Wounds", WARRIOR_PROTECTION );
  // Row 8
  talents.protection.heavy_repercussions    = find_talent_spell( talent_tree::SPECIALIZATION, "Heavy Repercussions" );
  talents.protection.into_the_fray          = find_talent_spell( talent_tree::SPECIALIZATION, "Into the Fray" );
  talents.protection.focused_vigor          = find_talent_spell( talent_tree::SPECIALIZATION, "Focused Vigor" );
  talents.protection.shield_specialization  = find_talent_spell( talent_tree::SPECIALIZATION, "Shield Specialization" );
  talents.protection.enduring_alacrity      = find_talent_spell( talent_tree::SPECIALIZATION, "Enduring Alacrity" );
  talents.protection.avatar                 = find_talent_spell( talent_tree::SPECIALIZATION, "Avatar", WARRIOR_PROTECTION );
  // Row 9
  talents.protection.massacre               = find_talent_spell( talent_tree::SPECIALIZATION, "Massacre", WARRIOR_PROTECTION );
  talents.protection.booming_voice          = find_talent_spell( talent_tree::SPECIALIZATION, "Booming Voice" );
  talents.protection.indomitable            = find_talent_spell( talent_tree::SPECIALIZATION, "Indomitable" );
  talents.protection.violent_outburst       = find_talent_spell( talent_tree::SPECIALIZATION, "Violent Outburst" );
  talents.protection.heavy_handed           = find_talent_spell( talent_tree::SPECIALIZATION, "Heavy Handed", WARRIOR_PROTECTION );
  // Row 10
  talents.protection.shield_charge          = find_talent_spell( talent_tree::SPECIALIZATION, "Shield Charge" );
  talents.protection.battle_scarred_veteran = find_talent_spell( talent_tree::SPECIALIZATION, "Battle-Scarred Veteran" );
  talents.protection.whirling_blade         = find_talent_spell( talent_tree::SPECIALIZATION, "Whirling Blade", WARRIOR_PROTECTION );
  talents.protection.ravager                = find_talent_spell( talent_tree::SPECIALIZATION, "Ravager", WARRIOR_PROTECTION );
  // Apex
  talents.protection.phalanx_1              = find_talent_spell( talent_tree::SPECIALIZATION, 1269311 );
  talents.protection.phalanx_2              = find_talent_spell( talent_tree::SPECIALIZATION, 1269312 );
  talents.protection.phalanx_3              = find_talent_spell( talent_tree::SPECIALIZATION, 1269313 );

  // Colossus Hero Talents
  talents.colossus.demolish                     = find_talent_spell( talent_tree::HERO, "Demolish" );
  talents.colossus.martial_expert               = find_talent_spell( talent_tree::HERO, "Martial Expert" );
  talents.colossus.colossal_might               = find_talent_spell( talent_tree::HERO, "Colossal Might" );
  talents.colossus.boneshaker                   = find_talent_spell( talent_tree::HERO, "Boneshaker" );
  talents.colossus.earthquaker                  = find_talent_spell( talent_tree::HERO, "Earthquaker" );
  talents.colossus.decimator                    = find_talent_spell( talent_tree::HERO, "Decimator" );
  talents.colossus.one_against_many             = find_talent_spell( talent_tree::HERO, "One Against Many" );
  talents.colossus.arterial_bleed               = find_talent_spell( talent_tree::HERO, "Arterial Bleed" );
  talents.colossus.tide_of_battle               = find_talent_spell( talent_tree::HERO, "Tide of Battle" );
  talents.colossus.no_stranger_to_pain          = find_talent_spell( talent_tree::HERO, "No Stranger to Pain" );
  talents.colossus.veteran_vitality             = find_talent_spell( talent_tree::HERO, "Veteran Vitality" );
  talents.colossus.cut_to_the_bone              = find_talent_spell( talent_tree::HERO, "Cut to the Bone" );
  talents.colossus.practiced_strikes            = find_talent_spell( talent_tree::HERO, "Practiced Strikes" );
  talents.colossus.precise_might                = find_talent_spell( talent_tree::HERO, "Precise Might" );
  talents.colossus.mountain_of_muscle_and_scars = find_talent_spell( talent_tree::HERO, "Mountain of Muscle and Scars" );
  talents.colossus.celeritous_conclusion        = find_talent_spell( talent_tree::HERO, "Celeritous Conclusion" );
  talents.colossus.dominance_of_the_colossus    = find_talent_spell( talent_tree::HERO, "Dominance of the Colossus" );

  // Slayer Hero Talents
  talents.slayer.slayers_dominance     = find_talent_spell( talent_tree::HERO, "Slayer's Dominance" );
  talents.slayer.imminent_demise       = find_talent_spell( talent_tree::HERO, "Imminent Demise" );
  talents.slayer.overwhelming_blades   = find_talent_spell( talent_tree::HERO, "Overwhelming Blades" );
  talents.slayer.relentless_pursuit    = find_talent_spell( talent_tree::HERO, "Relentless Pursuit" );
  talents.slayer.vicious_agility       = find_talent_spell( talent_tree::HERO, "Vicious Agility" );
  talents.slayer.violent_euphoria      = find_talent_spell( talent_tree::HERO, "Violent Euphoria" );
  talents.slayer.death_drive           = find_talent_spell( talent_tree::HERO, "Death Drive" );
  talents.slayer.culling_cyclone       = find_talent_spell( talent_tree::HERO, "Culling Cyclone" );
  talents.slayer.brutal_finish         = find_talent_spell( talent_tree::HERO, "Brutal Finish" );
  talents.slayer.fierce_followthrough  = find_talent_spell( talent_tree::HERO, "Fierce Followthrough" );
  talents.slayer.opportunist           = find_talent_spell( talent_tree::HERO, "Opportunist" );
  talents.slayer.deadly_focus          = find_talent_spell( talent_tree::HERO, "Deadly Focus" );
  talents.slayer.show_no_mercy         = find_talent_spell( talent_tree::HERO, "Show No Mercy" );
  talents.slayer.reap_the_storm        = find_talent_spell( talent_tree::HERO, "Reap the Storm" );
  talents.slayer.slayers_malice        = find_talent_spell( talent_tree::HERO, "Slayer's Malice" );
  talents.slayer.unhinged              = find_talent_spell( talent_tree::HERO, "Unhinged" );
  talents.slayer.unrelenting_onslaught = find_talent_spell( talent_tree::HERO, "Unrelenting Onslaught" );

  // Mountain Thane Hero Talents
  talents.mountain_thane.lightning_strikes            = find_talent_spell( talent_tree::HERO, "Lightning Strikes" );
  talents.mountain_thane.crashing_thunder             = find_talent_spell( talent_tree::HERO, "Crashing Thunder" );
  talents.mountain_thane.ground_current               = find_talent_spell( talent_tree::HERO, "Ground Current" );
  talents.mountain_thane.strength_of_the_mountain     = find_talent_spell( talent_tree::HERO, "Strength of the Mountain" );
  talents.mountain_thane.storm_surge                  = find_talent_spell( talent_tree::HERO, "Storm Surge" );
  talents.mountain_thane.thunder_blast                = find_talent_spell( talent_tree::HERO, "Thunder Blast" );
  talents.mountain_thane.storm_bolts                  = find_talent_spell( talent_tree::HERO, "Storm Bolts" );
  talents.mountain_thane.storm_shield                 = find_talent_spell( talent_tree::HERO, "Storm Shield" );
  talents.mountain_thane.keep_your_feet_on_the_ground = find_talent_spell( talent_tree::HERO, "Keep Your Feet on the Ground" );
  talents.mountain_thane.steadfast_as_the_peaks       = find_talent_spell( talent_tree::HERO, "Steadfast as the Peaks" );
  talents.mountain_thane.conductivity                 = find_talent_spell( talent_tree::HERO, "Conductivity" );
  talents.mountain_thane.flashing_skies               = find_talent_spell( talent_tree::HERO, "Flashing Skies" );
  talents.mountain_thane.snap_induction               = find_talent_spell( talent_tree::HERO, "Snap Induction" );
  talents.mountain_thane.gathering_clouds             = find_talent_spell( talent_tree::HERO, "Gathering Clouds" );
  talents.mountain_thane.thorims_might                = find_talent_spell( talent_tree::HERO, "Thorim's Might" );
  talents.mountain_thane.burst_of_power               = find_talent_spell( talent_tree::HERO, "Burst of Power" );
  talents.mountain_thane.capacitance                  = find_talent_spell( talent_tree::HERO, "Capacitance" );
  talents.mountain_thane.avatar_of_the_storm          = find_talent_spell( talent_tree::HERO, "Avatar of the Storm" );

  // Register passives
  if ( main_hand_weapon.type == WEAPON_NONE || off_hand_weapon.type == WEAPON_NONE )
    deregister_passive_spell( talents.warrior.dual_wield_specialization );

  if ( main_hand_weapon.group() != WEAPON_1H )
    deregister_passive_spell( talents.warrior.one_handed_weapon_specialization );

  if ( main_hand_weapon.group() != WEAPON_2H )
    deregister_passive_spell( talents.warrior.two_handed_weapon_specialization );

  // Flagged as passive, but requires enrage thus is dynamic
  deregister_passive_spell( talents.fury.cruelty );
  deregister_passive_spell( talents.fury.wrath_and_fury );

  // Non-scripted effects not active for fury
  if ( specialization() == WARRIOR_FURY )
    deregister_passive_spell( talents.mountain_thane.thunder_blast );

  register_passive_effect_mask( talents.warrior.barbaric_training,
    specialization() == WARRIOR_ARMS   ? effect_mask_t( false ).enable( 1, 2 )
    : specialization() == WARRIOR_FURY ? effect_mask_t( false ).enable( 3, 4, 5, 6 )
                                       : effect_mask_t( false ).enable( 7, 8 ) );

  register_passive_effect_mask ( talents.warrior.crushing_force,
    specialization() == WARRIOR_ARMS   ? effect_mask_t( false ).enable( 1, 2 )
    : specialization() == WARRIOR_FURY ? effect_mask_t( false ).enable( 3, 4 )
                                       : effect_mask_t( false ).enable( 5, 6 ) );


  if ( sim->dbc->wowv() >= wowv_t( 12, 0, 5 ) )
  {
    register_passive_effect_mask( talents.colossus.practiced_strikes,
    specialization() == WARRIOR_ARMS ? effect_mask_t( true ).disable( 3, 4, 5 )
                                     : effect_mask_t( true ).disable( 1, 2 ) );
  }
  else
  {
    register_passive_effect_mask( talents.colossus.practiced_strikes,
    specialization() == WARRIOR_ARMS ? effect_mask_t( true ).disable( 2, 3 )
                                     : effect_mask_t( true ).disable( 1 ) );
  }

  register_passive_effect_mask( talents.mountain_thane.avatar_of_the_storm,
    specialization() == WARRIOR_FURY ? effect_mask_t( true ).disable( 4 )
                                     : effect_mask_t( true ) );

  register_passive_effect_mask( talents.mountain_thane.crashing_thunder,
    specialization() == WARRIOR_PROTECTION ? effect_mask_t( true ).disable( 5, 6, 7, 8 )
                                           : effect_mask_t( true ) );

  register_passive_effect_mask( sets->set( HERO_MOUNTAIN_THANE, TWW3, B2 ),
    specialization() == WARRIOR_FURY ? effect_mask_t( true ).disable( 3 )
                                     : effect_mask_t( true ) );

  register_passive_effect_mask( talents.slayer.slayers_malice,
    specialization() == WARRIOR_ARMS ? effect_mask_t( true ).disable( 2 )
                                     : effect_mask_t( true ).disable( 1 ) );

  // Armor Handled Manually for ATTT
  register_passive_effect_mask( talents.protection.armor_specialization, effect_mask_t( false ).enable( 1, 2 ) );
  register_passive_effect_mask( talents.protection.focused_vigor, effect_mask_t( false ).enable( 2 ) );

  // As of Midnight Beta  Nov 18 2025 Bounding Stride effect 2 makes the cooldown of leap go negative
  register_passive_affect_list ( talents.warrior.bounding_stride, affect_list_t( 2 ).remove_spell( 6544 ) );

  if ( talents.arms.master_of_warfare_2.ok() )
  {
    register_passive_effect_override( talents.arms.master_of_warfare_2->effectN( 1 ), talents.arms.master_of_warfare_2->effectN( 1 ).base_value() / 10 );
    register_passive_effect_override( talents.arms.master_of_warfare_2->effectN( 2 ), talents.arms.master_of_warfare_2->effectN( 2 ).base_value() / 10 );
  }

  if ( talents.fury.spite.ok() )
  {
    register_passive_effect_override( talents.fury.spite->effectN( 1 ),
                                        talents.fury.spite->effectN( 1 ).base_value() / 10 );
    register_passive_effect_override( talents.fury.spite->effectN( 2 ),
                                        talents.fury.spite->effectN( 2 ).base_value() / 10 );
  }

  if ( talents.arms.master_of_warfare_2.ok() )
  {
    register_passive_effect_override( spell.master_of_warfare_2_buff->effectN( 2 ),
                                        talents.arms.master_of_warfare_2->effectN( 1 ).base_value() );
    register_passive_effect_override( spell.master_of_warfare_2_buff->effectN( 3 ),
                                        talents.arms.master_of_warfare_2->effectN( 2 ).base_value() );
  }

  parse_all_class_passives();
  parse_all_passive_talents();
  parse_all_passive_sets();
  parse_raid_buffs();

  // Shared Talents - needed when using the same spell data with a spec check (ravager)

  auto find_shared_talent = []( std::vector<player_talent_t*> talents ) {
    for ( const auto t : talents )
    {
      if ( t->ok() )
      {
        return *t;
      }
    }
    return *talents[ 0 ];
  };

  talents.shared.avatar = find_shared_talent( { &talents.arms.avatar, &talents.fury.avatar, &talents.protection.avatar } );
  talents.shared.bladestorm = find_shared_talent( { &talents.arms.bladestorm, &talents.fury.bladestorm } );
  talents.shared.fueled_by_violence = find_shared_talent( { &talents.arms.fueled_by_violence, &talents.protection.fueled_by_violence } );
  talents.shared.ravager = find_shared_talent( { &talents.arms.ravager, &talents.protection.ravager } );
  talents.shared.bloodsurge = find_shared_talent( { &talents.arms.bloodsurge, &talents.protection.bloodsurge } );
  talents.shared.sudden_death = find_shared_talent( { &talents.arms.sudden_death, &talents.fury.sudden_death, &talents.protection.sudden_death } );
  talents.shared.deep_wounds = find_shared_talent( { &talents.arms.deep_wounds, &talents.fury.deep_wounds, &talents.protection.deep_wounds } );
  talents.shared.ignore_pain = find_shared_talent( { &talents.arms.ignore_pain, &talents.protection.ignore_pain } );

  // Active spells
  active.deep_wounds    = nullptr;
  active.fatality       = nullptr;
  active.slayers_strike = nullptr;
  active.bloody_rebuke  = nullptr;

  // Cooldowns
  cooldown.avatar         = get_cooldown( "avatar" );
  cooldown.recklessness   = get_cooldown( "recklessness" );
  cooldown.berserker_rage = get_cooldown( "berserker_rage" );
  cooldown.bladestorm     = get_cooldown( "bladestorm" );
  cooldown.bloodthirst    = get_cooldown( "bloodthirst" );
  cooldown.bloodbath      = get_cooldown( "bloodbath" );

  cooldown.cleave                           = get_cooldown( "cleave" );
  cooldown.colossus_smash                   = get_cooldown( "colossus_smash" );
  cooldown.demoralizing_shout               = get_cooldown( "demoralizing_shout" );
  cooldown.enraged_regeneration             = get_cooldown( "enraged_regeneration" );
  cooldown.execute                          = get_cooldown( "execute" );
  cooldown.heroic_leap                      = get_cooldown( "heroic_leap" );
  cooldown.mortal_strike                    = get_cooldown( "mortal_strike" );
  cooldown.odyns_fury                       = get_cooldown( "odyns_fury" );
  cooldown.overpower                        = get_cooldown( "overpower" );
  cooldown.pummel                           = get_cooldown( "pummel" );
  cooldown.rage_from_auto_attack            = get_cooldown( "rage_from_auto_attack" );
  cooldown.rage_from_auto_attack->duration  = timespan_t::from_seconds ( 1.0 );
  cooldown.rage_from_crit_block             = get_cooldown( "rage_from_crit_block" );
  cooldown.rage_from_crit_block->duration   = timespan_t::from_seconds( 3.0 );
  cooldown.raging_blow                      = get_cooldown( "raging_blow" );
  cooldown.crushing_blow                    = get_cooldown( "raging_blow" );
  cooldown.ravager                          = get_cooldown( "ravager" );
  cooldown.shield_charge                    = get_cooldown( "shield_charge" );
  cooldown.shield_slam                      = get_cooldown( "shield_slam" );
  cooldown.shield_wall                      = get_cooldown( "shield_wall" );
  cooldown.shockwave                        = get_cooldown( "shockwave" );
  cooldown.storm_bolt                       = get_cooldown( "storm_bolt" );
  cooldown.sudden_death_icd                 = get_cooldown( "sudden_death" );
  cooldown.sudden_death_icd->duration       = talents.shared.sudden_death->internal_cooldown();
  cooldown.tough_as_nails_icd               = get_cooldown( "tough_as_nails" );
  cooldown.tough_as_nails_icd -> duration   = talents.protection.tough_as_nails-> internal_cooldown();
  cooldown.thunder_clap                     = get_cooldown( "thunder_clap" );
  cooldown.cold_steel_hot_blood_icd         = get_cooldown( "cold_steel_hot_blood" );
  cooldown.cold_steel_hot_blood_icd -> duration = talents.fury.cold_steel_hot_blood->internal_cooldown();
  cooldown.reap_the_storm_icd               = get_cooldown( "reap_the_storm" );
  cooldown.reap_the_storm_icd -> duration   = talents.slayer.reap_the_storm->internal_cooldown();
  cooldown.demolish                         = get_cooldown( "demolish" );
  cooldown.burst_of_power_icd               = get_cooldown( "burst_of_power" );
  cooldown.burst_of_power_icd -> duration = find_spell( 437121 )->internal_cooldown();
  cooldown.slayers_dominance_icd            = get_cooldown( "slayers_dominance" );
  cooldown.slayers_dominance_icd -> duration = find_spell( 444767 )->internal_cooldown();
  if( sim->dbc->wowv() >= wowv_t( 12, 0, 5) )
  {
    cooldown.hack_and_slash_icd               = get_cooldown( "hack_and_slash" );
    cooldown.hack_and_slash_icd->duration = talents.fury.hack_and_slash->internal_cooldown();
  }
}

// warrior_t::init_items ===============================================

void warrior_t::init_items()
{
  parse_player_effects_t::init_items();

  set_bonus_type_e tier_to_enable;
  switch ( specialization() )
  {
    case WARRIOR_ARMS:
      tier_to_enable = DF1;
      break;
    case WARRIOR_FURY:
      tier_to_enable = DF2;
      break;
    case WARRIOR_PROTECTION:
      tier_to_enable = DF3;
      break;
    default:
      return;
  }

  if ( sets->has_set_bonus( specialization(), DF4, B2 ) )
    sets->enable_set_bonus( specialization(), tier_to_enable, B2 );

  if ( sets->has_set_bonus( specialization(), DF4, B4 ) )
    sets->enable_set_bonus( specialization(), tier_to_enable, B4 );
}


// warrior_t::init_base =====================================================

void warrior_t::init_base_stats()
{
  if ( base.distance < 1 )
    base.distance = 5.0;

  base.attack_power_per_strength = 1.0;
  base.attack_power_per_agility  = 0.0;
  base.spell_power_per_intellect = 1.0;

  parse_player_effects_t::init_base_stats();
}

// warrior_t::merge ==========================================================

void warrior_t::merge( player_t& other )
{
  parse_player_effects_t::merge( other );

  const warrior_t& s = static_cast<warrior_t&>( other );

  for ( size_t i = 0, end = cd_waste_exec.size(); i < end; i++ )
  {
    cd_waste_exec[ i ]->second.merge( s.cd_waste_exec[ i ]->second );
    cd_waste_cumulative[ i ]->second.merge( s.cd_waste_cumulative[ i ]->second );
  }
}

// warrior_t::datacollection_begin ===========================================

void warrior_t::datacollection_begin()
{
  if ( active_during_iteration )
  {
    for ( size_t i = 0, end = cd_waste_iter.size(); i < end; ++i )
    {
      cd_waste_iter[ i ]->second.reset();
    }
  }

  parse_player_effects_t::datacollection_begin();
}

// warrior_t::datacollection_end =============================================

void warrior_t::datacollection_end()
{
  if ( requires_data_collection() )
  {
    for ( size_t i = 0, end = cd_waste_iter.size(); i < end; ++i )
    {
      cd_waste_cumulative[ i ]->second.add( cd_waste_iter[ i ]->second.sum() );
    }
  }

  parse_player_effects_t::datacollection_end();
}

// NO Spec Combat Action Priority List

void warrior_t::apl_default()
{
  action_priority_list_t* default_list = get_action_priority_list( "default" );

  default_list->add_action( this, "Heroic Throw" );
}

// ==========================================================================
// Warrior Buffs
// ==========================================================================

namespace buffs
{
template <typename Base>
struct warrior_buff_t : public Base
{
public:
  using base_t = warrior_buff_t;


  warrior_buff_t( warrior_td_t& td, util::string_view name, const spell_data_t* s = spell_data_t::nil(),
                 const item_t* item = nullptr )
    : Base( td, name, s, item )
  {
  }

  warrior_buff_t( warrior_t& p, util::string_view name, const spell_data_t* s = spell_data_t::nil(),
                 const item_t* item = nullptr )
    : Base( &p, name, s, item )
  {
  }

protected:
  warrior_t& warrior()
  {
    return *debug_cast<warrior_t*>( Base::source );
  }
  const warrior_t& warrior() const
  {
    return *debug_cast<warrior_t*>( Base::source );
  }
};


// Rallying Cry ==============================================================

struct rallying_cry_t : public buff_t
{
  double health_change;
  rallying_cry_t( player_t* p ) :
    buff_t( p, "rallying_cry", p->find_spell( 97463 ) ), health_change( p->find_spell( 97462 )->effectN( 1 ).percent() )
  { }

  void start( int stacks, double value, timespan_t duration ) override
  {
    buff_t::start( stacks, value, duration );

    double old_health = player -> resources.current[ RESOURCE_HEALTH ];
    double old_max_health = player -> resources.max[ RESOURCE_HEALTH ];

    player -> resources.initial_multiplier[ RESOURCE_HEALTH ] *= 1.0 + health_change;
    player -> recalculate_resource_max( RESOURCE_HEALTH );
    player -> resources.current[ RESOURCE_HEALTH ] *= 1.0 + health_change; // Update health after the maximum is increased

    sim -> print_debug( "{} gains Rallying Cry: health pct change {}%, current health: {} -> {}, max: {} -> {}",
                        player -> name(), health_change * 100.0,
                        old_health, player -> resources.current[ RESOURCE_HEALTH ],
                        old_max_health, player -> resources.max[ RESOURCE_HEALTH ] );
  }

  void expire_override( int, timespan_t ) override
  {
    double old_max_health = player -> resources.max[ RESOURCE_HEALTH ];
    double old_health = player -> resources.current[ RESOURCE_HEALTH ];

    player -> resources.initial_multiplier[ RESOURCE_HEALTH ] /= 1.0 + health_change;
    player -> resources.current[ RESOURCE_HEALTH ] /= 1.0 + health_change; // Update health before the maximum is reduced
    player -> recalculate_resource_max( RESOURCE_HEALTH );

    sim -> print_debug( "{} loses Rallying Cry: health pct change {}%, current health: {} -> {}, max: {} -> {}",
                        player -> name(), health_change * 100.0,
                        old_health, player -> resources.current[ RESOURCE_HEALTH ],
                        old_max_health, player -> resources.max[ RESOURCE_HEALTH ] );
  }
};

// Steadfast as the Peaks =====================================================

struct steadfast_as_the_peaks_buff_t : public warrior_buff_t<buff_t>
{
  double health_change;
  steadfast_as_the_peaks_buff_t( warrior_t& p, util::string_view n, const spell_data_t* s ) :
    base_t( p, n, s ), health_change( data().effectN( 3 ).percent() )
  {
    add_invalidate( CACHE_BLOCK );
    set_cooldown( timespan_t::zero() );
  }

  void start( int stacks, double value, timespan_t duration ) override
  {
    warrior_buff_t<buff_t>::start( stacks, value, duration );

    double old_health = player -> resources.current[ RESOURCE_HEALTH ];
    double old_max_health = player -> resources.max[ RESOURCE_HEALTH ];

    player -> resources.initial_multiplier[ RESOURCE_HEALTH ] *= 1.0 + health_change;
    player -> recalculate_resource_max( RESOURCE_HEALTH );
    player -> resources.current[ RESOURCE_HEALTH ] *= 1.0 + health_change; // Update health after the maximum is increased

    sim -> print_debug( "{} gains Steadfast as the Peaks: health pct change {}%, current health: {} -> {}, max: {} -> {}",
                        player -> name(), health_change * 100.0,
                        old_health, player -> resources.current[ RESOURCE_HEALTH ],
                        old_max_health, player -> resources.max[ RESOURCE_HEALTH ] );
  }

  void expire_override( int, timespan_t ) override
  {
    double old_max_health = player -> resources.max[ RESOURCE_HEALTH ];
    double old_health = player -> resources.current[ RESOURCE_HEALTH ];

    player -> resources.initial_multiplier[ RESOURCE_HEALTH ] /= 1.0 + health_change;
    player -> resources.current[ RESOURCE_HEALTH ] /= 1.0 + health_change;
    player -> recalculate_resource_max( RESOURCE_HEALTH );

    sim -> print_debug( "{} loses Steadfast as the Peaks: health pct change {}%, current health: {} -> {}, max: {} -> {}",
                        player -> name(), health_change * 100.0,
                        old_health, player -> resources.current[ RESOURCE_HEALTH ],
                        old_max_health, player -> resources.max[ RESOURCE_HEALTH ] );
  }
};

// Last Stand ======================================================================

struct last_stand_buff_t : public warrior_buff_t<buff_t>
{
  double health_change;
  last_stand_buff_t( warrior_t& p, util::string_view n, const spell_data_t* s ) :
    base_t( p, n, s ), health_change( data().effectN( 1 ).percent() )
  {
    add_invalidate( CACHE_BLOCK );
    set_cooldown( timespan_t::zero() );
  }

  void start( int stacks, double value, timespan_t duration ) override
  {
    warrior_buff_t<buff_t>::start( stacks, value, duration );

    double old_health = player -> resources.current[ RESOURCE_HEALTH ];
    double old_max_health = player -> resources.max[ RESOURCE_HEALTH ];

    player -> resources.initial_multiplier[ RESOURCE_HEALTH ] *= 1.0 + health_change;
    player -> recalculate_resource_max( RESOURCE_HEALTH );
    player -> resources.current[ RESOURCE_HEALTH ] *= 1.0 + health_change; // Update health after the maximum is increased

    sim -> print_debug( "{} gains Last Stand: health pct change {}%, current health: {} -> {}, max: {} -> {}",
                        player -> name(), health_change * 100.0,
                        old_health, player -> resources.current[ RESOURCE_HEALTH ],
                        old_max_health, player -> resources.max[ RESOURCE_HEALTH ] );
  }

  void expire_override( int, timespan_t ) override
  {
    double old_max_health = player -> resources.max[ RESOURCE_HEALTH ];
    double old_health = player -> resources.current[ RESOURCE_HEALTH ];

    player -> resources.initial_multiplier[ RESOURCE_HEALTH ] /= 1.0 + health_change;
    // Last Stand isn't like other health buffs, the player doesn't lose health when it expires (unless it's over the cap)
    // player -> resources.current[ RESOURCE_HEALTH ] /= 1.0 + health_change;
    player -> recalculate_resource_max( RESOURCE_HEALTH );

    sim -> print_debug( "{} loses Last Stand: health pct change {}%, current health: {} -> {}, max: {} -> {}",
                        player -> name(), health_change * 100.0,
                        old_health, player -> resources.current[ RESOURCE_HEALTH ],
                        old_max_health, player -> resources.max[ RESOURCE_HEALTH ] );
  }
};

// Demoralizing Shout ================================================================

struct debuff_demo_shout_t : public warrior_buff_t<buff_t>
{
  int extended;
  debuff_demo_shout_t( warrior_td_t& p, warrior_t* w )
    : base_t( p, "demoralizing_shout_debuff", w -> find_spell( 1160 ) ),
      extended( 0 )
  {
    cooldown -> duration = timespan_t::zero(); // Cooldown handled by the action
    default_value = data().effectN( 1 ).percent();
  }

  bool trigger( int stacks, double value, double chance, timespan_t duration ) override
  {
    extended = 0; // counts extra seconds gained on each debuff past the initial trigger
    return base_t::trigger( stacks, value, chance, duration );
  }
};

}  // end namespace buffs

// ==========================================================================
// Warrior Character Definition
// ==========================================================================

warrior_td_t::warrior_td_t( player_t& target, warrior_t& p ) : actor_target_data_t( &target, &p ), warrior( p )
{
  target.register_on_demise_callback( &p, [ this ]( player_t* ) { target_demise(); } );
  using namespace buffs;

  hit_by_fresh_meat = false;
  dots_deep_wounds = target.get_dot( "deep_wounds", &p );
  dots_rend        = target.get_dot( "rend_dot", &p );
  dots_gushing_wound = target.get_dot( "gushing_wound", &p );

  debuffs_colossus_smash = make_buff( *this , "colossus_smash", p.spell.colossus_smash_debuff );

  debuffs_fatal_mark = make_buff( *this, "fatal_mark", p.spell.fatal_mark_debuff );

  debuffs_honed_reflexes = make_buff( *this, "honed_reflexes", p.talents.warrior.honed_reflexes->effectN( 5 ).trigger() );

  debuffs_demoralizing_shout = new buffs::debuff_demo_shout_t( *this, &p );

  debuffs_punish = make_buff( *this, "punish", p.talents.protection.punish -> effectN( 2 ).trigger() );

  debuffs_ravaged = make_buff( *this, "ravaged", p.spell.ravaged_debuff );

  debuffs_taunt = make_buff( *this, "taunt", p.find_class_spell( "Taunt" ) );

  debuffs_devastating_focus = make_buff( *this, "devastating_focus", p.spell.devastating_focus_debuff );

  debuffs_phalanx = make_buff( *this, "phalanx_debuff", p.spell.phalanx_debuff );

  // Colossus
  debuffs_wrecked              = make_buff( *this, "wrecked", p.spell.wrecked_debuff )
                                    ->set_refresh_behavior( buff_refresh_behavior::DURATION );

  // Slayer
  debuffs_overwhelmed          = make_buff( *this, "overwhelmed", p.spell.overwhelmed_debuff );

  // Mountain Thane
}

void warrior_td_t::target_demise()
{
  if ( !target->is_enemy() )
    return;

  // Don't pollute results at the end-of-iteration deaths of everyone
  if ( source->sim->event_mgr.canceled )
    return;

  warrior_t* p = debug_cast<warrior_t*>( source );

  if ( p -> talents.warrior.war_machine->ok() )
  {
    p->resource_gain( RESOURCE_RAGE, p -> talents.warrior.war_machine -> effectN( 1 ).trigger() -> effectN( 1 ).resource( RESOURCE_RAGE ),
                          p->gain.war_machine_demise );
  }
}

// warrior_t::init_buffs ====================================================

void warrior_t::create_buffs()
{
  parse_player_effects_t::create_buffs();

  using namespace buffs;

  buff.revenge =
      make_buff( this, "revenge", find_spell( 5302 ) )
      ->set_default_value( find_spell( 5302 )->effectN( 1 ).percent() )
      ->set_cooldown( spec.revenge_trigger -> internal_cooldown() );

  buff.avatar = make_buff( this, "avatar", spell.avatar )
      ->set_cooldown( timespan_t::zero() );

  buff.collateral_damage = make_buff( this, "collateral_damage", find_spell( 334783 ) );

  buff.champions_spear = make_buff( this, "champions_spear", find_spell( 376080 ) );

  buff.wild_strikes = make_buff( this, "wild_strikes", talents.warrior.wild_strikes->effectN( 2 ).trigger() )
      ->set_cooldown( talents.warrior.wild_strikes->internal_cooldown() )
      ->set_trigger_spell( talents.warrior.wild_strikes );

  buff.berserker_rage = make_buff( this, "berserker_rage", spell.berserker_rage )
      ->set_cooldown( timespan_t::zero() );

  buff.bounding_stride = make_buff( this, "bounding_stride", find_spell( 202164 ) )
    ->set_chance( talents.warrior.bounding_stride->ok() )
    ->set_default_value( find_spell( 202164 )->effectN( 1 ).percent() );

  buff.bladestorm =
      make_buff( this, "bladestorm", talents.slayer.unrelenting_onslaught->ok() && talents.shared.bladestorm.ok() ? find_spell( 446035 ) : talents.shared.bladestorm )
      ->disable_ticking( true )
      ->set_cooldown( timespan_t::zero() );

  buff.battle_stance = make_buff( this, "battle_stance", talents.warrior.battle_stance )
    ->set_activated( true )
    ->set_default_value( talents.warrior.battle_stance->effectN( 1 ).percent() )
    ->add_invalidate( CACHE_CRIT_CHANCE );

  buff.berserker_stance = make_buff( this, "berserker_stance", talents.warrior.berserker_stance )
    ->set_activated( true )
    ->set_default_value( talents.warrior.berserker_stance->effectN( 1 ).percent() );

  buff.defensive_stance = make_buff( this, "defensive_stance", talents.warrior.defensive_stance )
    ->set_activated( true )
    ->add_invalidate( CACHE_PLAYER_DAMAGE_MULTIPLIER );

  buff.battle_shout_highlight = make_buff( this, "battle_shout_highlight", find_spell( 1271909 ) );

  buff.battlelord = make_buff( this, "battlelord", spell.battlelord_buff );

  buff.crushing_combo = make_buff( this, "crushing_combo", talents.arms.crushing_combo->effectN( 1 ).trigger() );

  buff.die_by_the_sword = make_buff( this, "die_by_the_sword", talents.arms.die_by_the_sword )
    ->set_default_value( talents.arms.die_by_the_sword->effectN( 2 ).percent() )
    ->set_cooldown( timespan_t::zero() )
    ->add_invalidate( CACHE_PARRY );

  buff.enrage = make_buff( this, "enrage", find_spell( 184362 ) )
     ->add_invalidate( CACHE_ATTACK_HASTE )
     ->add_invalidate( CACHE_RUN_SPEED )
     ->set_default_value( find_spell( 184362 )->effectN( 1 ).percent() )
     ->set_duration( find_spell( 184362 )->duration() )
     ->set_constant_behavior( buff_constant_behavior::NEVER_CONSTANT );

  buff.frenzy = make_buff( this, "frenzy", find_spell(335082) )
                          ->set_stack_behavior( buff_stack_behavior::ASYNCHRONOUS )
                          ->set_disable_async_expire_events_removal( true );

  buff.heroic_leap_movement   = make_buff( this, "heroic_leap_movement" );
  buff.charge_movement        = make_buff( this, "charge_movement" );
  buff.intervene_movement     = make_buff( this, "intervene_movement" );
  buff.shield_charge_movement = make_buff( this, "shield_charge_movement" );

  buff.hack_and_slash = make_buff( this, "hack_and_slash", talents.fury.hack_and_slash->effectN( 1 ).trigger() );

  buff.into_the_fray = make_buff( this, "into_the_fray", find_spell( 202602 ) )
    ->set_chance( talents.protection.into_the_fray->ok() )
    ->set_default_value( find_spell( 202602 )->effectN( 1 ).percent() )
    ->add_invalidate( CACHE_HASTE );

  buff.last_stand = new buffs::last_stand_buff_t( *this, "last_stand", talents.protection.last_stand->effectN( 1 ).trigger() );

  buff.whirlwind = make_buff( this, "whirlwind", spell.whirlwind_buff );

  // reflection NYI
  buff.spell_reflection = make_buff( this, "spell_reflection", talents.warrior.spell_reflection->effectN( 2 ).trigger() )
    -> set_cooldown( 0_ms ); // handled by the ability

  buff.sweeping_strikes = make_buff( this, "sweeping_strikes", spec.sweeping_strikes)
                              ->set_cooldown( 0_s );  // Handled by the action

  if ( sim->dbc->wowv() < wowv_t( 12, 1, 0 ) )
    buff.tactical_edge = make_buff( this, "tactical_edge", talents.arms.tactical_edge->effectN( 1 ).trigger() )
                          ->set_default_value_from_effect( 1 )
                          ->set_initial_stack( talents.arms.tactical_edge.ok() ? talents.arms.tactical_edge->effectN( 1 ).trigger()->max_stacks() : 1 );

  buff.ignore_pain = new ignore_pain_buff_t( this );

  buff.ravager = make_buff( this, "ravager", find_spell( 228920 ) )
                    ->set_refresh_behavior( buff_refresh_behavior::DURATION )
                    ->set_cooldown( timespan_t::zero() )
                    ->set_tick_time_behavior( buff_tick_time_behavior::HASTED );

  buff.martial_prowess = make_buff( this, "martial_prowess", talents.arms.martial_prowess->effectN( 1 ).trigger() )
                            ->set_cooldown( talents.arms.martial_prowess->internal_cooldown() );

  buff.recklessness = make_buff( this, "recklessness", spell.recklessness_buff )
    ->set_cooldown( timespan_t::zero() )
    ->set_stack_change_callback( [this]( buff_t*, int, int new_stack ) {
      if ( new_stack == 0 && buff.fury_mid2_4pc_crit  && buff.fury_mid2_4pc_crit->up() )
        buff.fury_mid2_4pc_crit->expire();
    });

  buff.sudden_death = make_buff( this, "sudden_death", spell.sudden_death_buff );

  buff.shield_block = make_buff( this, "shield_block", spell.shield_block_buff )
    ->set_cooldown( timespan_t::zero() )
    ->add_invalidate( CACHE_BLOCK );

  buff.shield_wall = make_buff( this, "shield_wall", spell.shield_wall )
    ->set_default_value( spell.shield_wall->effectN( 1 ).percent() )
    ->set_cooldown( timespan_t::zero() );

  buff.bloodcraze = make_buff( this, "bloodcraze", talents.fury.bloodcraze->effectN( 1 ).trigger() );

  buff.scent_of_blood = make_buff( this, "scent_of_blood", talents.fury.scent_of_blood->effectN( 1 ).trigger() );

  buff.ragedrinker = make_buff( this, "ragedrinker", talents.fury.ragedrinker->effectN( 1 ).trigger() );

  buff.executioners_precision = make_buff( this, "executioners_precision", talents.arms.executioners_precision->effectN( 1 ).trigger() )
                                  ->set_cooldown( talents.arms.executioners_precision->internal_cooldown() );

  buff.executioners_wrath = make_buff( this, "executioners_wrath", talents.fury.executioners_wrath->effectN( 2 ).trigger() );

  buff.surge_of_adrenaline = make_buff( this, "surge_of_adrenaline", find_spell( 1265560 ) )
                              ->set_chance( 1.0 );

  buff.bloodborne = make_buff( this, "bloodborne", talents.fury.bloodborne->effectN( 1 ).trigger() )
                                        ->set_trigger_spell( talents.fury.bloodborne );

  buff.berserk = make_buff( this, "berserk", find_spell( 1269349) )
                    ->set_stack_behavior( buff_stack_behavior::ASYNCHRONOUS )
                    ->set_disable_async_expire_events_removal( true )
                    ->set_trigger_spell( talents.fury.rampaging_berserker_1 );

  buff.seeing_red = make_buff( this, "seeing_red", find_spell( 386486 ) );
      // In game it looks like it tracks stacks dynamically, but the actual amount of rage spent is stored in the value
      // As a result, rage tracking is accurate on the buff tooltip, but the number of stacks equals round(value / 2.5)
      // We will treat this as a single stack in simc, and handle everything in the value
      buff.seeing_red->set_max_stack( 1 )
        ->set_default_value( 0 );

  buff.violent_outburst = make_buff( this, "violent_outburst", find_spell( 386478 ) );

  buff.brace_for_impact = make_buff( this, "brace_for_impact", talents.protection.brace_for_impact->effectN( 1 ).trigger() )
                         -> set_default_value( talents.protection.brace_for_impact->effectN( 1 ).trigger()->effectN( 1 ).percent() )
                         -> set_initial_stack( 1 );

  buff.best_served_cold = make_buff( this, "best_served_cold", find_spell( 1234772 ) );

  // Colossus
  buff.colossal_might       = make_buff( this, "colossal_might", find_spell( 440989 ) )
                                ->set_refresh_behavior( buff_refresh_behavior::DURATION );

  buff.celeritous_conclusion_haste = make_buff( this, "celeritous_conclusion_haste", find_spell( 1270843 ) );
  buff.celeritous_conclusion_crit  = make_buff( this, "celeritous_conclusion_crit", find_spell( 1270846 ) );

  buff.cut_to_the_bone      = make_buff( this, "cut_to_the_bone", find_spell( 1270840 ) )
                                ->set_cooldown( talents.colossus.cut_to_the_bone->internal_cooldown() );

  // Slayer
  buff.executioner          = make_buff( this, "executioner", find_spell( 445584 ) )
                              ->set_disable_async_expire_events_removal( true )
                              ->set_stack_behavior( buff_stack_behavior::ASYNCHRONOUS );
  buff.imminent_demise      = make_buff( this, "imminent_demise", find_spell( 445606 ) );
  buff.brutal_finish        = make_buff( this, "brutal_finish", find_spell( 446918 ) );
  buff.fierce_followthrough = make_buff( this, "fierce_followthrough", find_spell( 458689 ) );
  buff.opportunist          = make_buff( this, "opportunist", find_spell( 456120 ) );
  buff.violent_euphoria     = make_buff( this, "violent_euphoria", find_spell( 1270731 ) );

  // Mountain Thane
  buff.thunder_blast          = make_buff( this, "thunder_blast", find_spell( 435615 ) );
  buff.steadfast_as_the_peaks = new buffs::steadfast_as_the_peaks_buff_t( *this, "steadfast_as_the_peaks", find_spell( 437152 ) );
  buff.burst_of_power         = make_buff( this, "burst_of_power", find_spell( 437121 ) )
                                  ->set_initial_stack_to_max_stack()
                                  ->set_cooldown( talents.mountain_thane.burst_of_power -> internal_cooldown() )
                                  ->set_chance( talents.mountain_thane.burst_of_power->proc_chance() );

  // Arms Apex
  buff.master_of_warfare_proc = make_buff( this, "master_of_warfare_proc", find_spell( 1269391 ) )
                                        ->set_trigger_spell( talents.arms.master_of_warfare_1 )
                                        ->set_cooldown( talents.arms.master_of_warfare_1->internal_cooldown() );

  buff.master_of_warfare = make_buff( this, "master_of_warfare", spell.master_of_warfare_2_buff )
                                ->set_disable_async_expire_events_removal( true )
                                ->set_stack_behavior( buff_stack_behavior::ASYNCHRONOUS );

  buff.heroic_might_accumulator = make_buff( this, "heroic_might_accumulator", find_spell( 1292058 ) );
  buff.heroic_might = make_buff( this, "heroic_might", find_spell( 1292058 ) )
                                  ->set_default_value_from_effect( 1 );

  // Protection Apex
  buff.phalanx = make_buff( this, "phalanx", spell.phalanx_buff );

  // Tier MID2
  // Arms
  buff.winding_up = make_buff( this, "winding_up", find_spell( 1300670 ) );
  // Fury
  if ( sim->dbc->wowv() >= wowv_t( 12, 1, 0 ) )
    buff.fury_mid2_4pc_crit = make_buff( this, "fury_mid2_4pc_crit" )
                                ->set_default_value( sets->set( WARRIOR_FURY, MID2, B4 )->effectN( 2 ).percent() )
                                ->set_max_stack( as<int>( sets->set( WARRIOR_FURY, MID2, B4 )->effectN( 3 ).base_value() ) )
                                ->set_pct_buff_type( STAT_PCT_BUFF_CRIT );
  // Protection
  buff.vengeful_shield = make_buff( this, "vengeful_shield", find_spell( 1300681 ) );
}

// warrior_t::init_special_effects() ====================================
void warrior_t::init_special_effects()
{
  parse_player_effects_t::init_special_effects();
}


// warrior_t::init_finished =============================================
void warrior_t::init_finished()
{
  parse_player_effects();
  parse_player_effects_t::init_finished();
}

// warrior_t::init_rng ==================================================
void warrior_t::init_rng()
{
  parse_player_effects_t::init_rng();
  rppm.revenge          = get_rppm( "revenge_trigger", spec.revenge_trigger );
  if ( talents.protection.best_served_cold->ok() )
    rppm.revenge->set_modifier( rppm.revenge->get_modifier() + talents.protection.best_served_cold->effectN( 3 ).percent() );

  rppm.sudden_death     = get_rppm( "sudden death", talents.shared.sudden_death );
  rppm.whirling_blade    = get_rppm( "whirling_blade", talents.protection.whirling_blade );
}

// warrior_t::validate_fight_style ==========================================
bool warrior_t::validate_fight_style( fight_style_e style ) const
{
  if ( specialization() == WARRIOR_PROTECTION )
  {
    switch ( style )
    {
      case FIGHT_STYLE_DUNGEON_ROUTE:
      case FIGHT_STYLE_DUNGEON_SLICE:
        return false;
      default:
        return true;
    }
  }
  return true;
}

// warrior_t::validate_actor ==============================================

bool warrior_t::validate_actor()
{
  // Arms and Protection may not use a 2H main-hand with any off-hand item.
  // Fury may dual-wield two 2H weapons, so it is exempt from this check.
  if ( specialization() != WARRIOR_FURY && main_hand_weapon.group() == WEAPON_2H &&
       off_hand_weapon.type != WEAPON_NONE )
  {
    throw sc_invalid_player_argument(
        fmt::format( "Player {} has an Off-Hand weapon equipped with a 2h.", name() ) );
    return false;
  }

  return player_t::validate_actor();
}

// warrior_t::init_scaling ==================================================

void warrior_t::init_scaling()
{
  parse_player_effects_t::init_scaling();

  if ( specialization() == WARRIOR_FURY )
  {
    scaling->enable( STAT_WEAPON_OFFHAND_DPS );
  }

  if ( specialization() == WARRIOR_PROTECTION )
  {
    scaling->enable( STAT_BONUS_ARMOR );
  }

  scaling->disable( STAT_AGILITY );
}

// warrior_t::init_gains ====================================================

void warrior_t::init_gains()
{
  parse_player_effects_t::init_gains();

  gain.archavons_heavy_hand             = get_gain( "archavons_heavy_hand" );
  gain.avatar                           = get_gain( "avatar" );
  gain.avoided_attacks                  = get_gain( "avoided_attacks" );
  gain.battlelord                       = get_gain( "battlelord" );
  gain.bloodsurge                       = get_gain( "bloodsurge" );
  gain.charge                           = get_gain( "charge" );
  gain.critical_block                   = get_gain( "critical_block" );
  gain.execute                          = get_gain( "execute" );
  gain.frothing_berserker               = get_gain( "frothing_berserker" );
  gain.just_warming_up                  = get_gain( "just_warming_up" );
  gain.melee_crit                       = get_gain( "melee_crit" );
  gain.melee_main_hand                  = get_gain( "melee_main_hand" );
  gain.melee_off_hand                   = get_gain( "melee_off_hand" );
  gain.revenge                          = get_gain( "revenge" );
  gain.shield_charge                    = get_gain( "shield_charge" );
  gain.shield_slam                      = get_gain( "shield_slam" );
  gain.champions_spear                  = get_gain( "champions_spear" );
  gain.booming_voice                    = get_gain( "booming_voice" );
  gain.thunder_blast                    = get_gain( "thunder_blast" );
  gain.thunder_clap                     = get_gain( "thunder_clap" );
  gain.whirlwind                        = get_gain( "whirlwind" );
  gain.instigate                        = get_gain( "instigate" );
  gain.war_machine_demise               = get_gain( "war_machine_demise" );

  gain.ceannar_rage           = get_gain( "ceannar_rage" );
  gain.cold_steel_hot_blood   = get_gain( "cold_steel_hot_blood" );
  gain.endless_rage           = get_gain( "endless_rage" );
  gain.lord_of_war            = get_gain( "lord_of_war" );
  gain.rage_from_damage_taken = get_gain( "rage_from_damage_taken" );
  gain.ravager                = get_gain( "ravager" );
  gain.simmering_rage         = get_gain( "simmering_rage" );
  gain.execute_refund         = get_gain( "execute_refund" );
  gain.thorims_might          = get_gain( "thorims_might" );
  gain.burst_of_power         = get_gain( "burst_of_power" );
}

// warrior_t::init_position ====================================================

void warrior_t::init_position()
{
  parse_player_effects_t::init_position();
}

// warrior_t::init_procs ======================================================

void warrior_t::init_procs()
{
  parse_player_effects_t::init_procs();
  proc.battlelord          = get_proc( "Battlelord Mortal Strike reset");
  proc.battlelord_wasted   = get_proc( "Battlelord Mortal Strike reset wasted" );
  proc.delayed_auto_attack = get_proc( "delayed_auto_attack" );
  proc.tactician           = get_proc( "tactician" );
}

// warrior_t::default_potion ================================================

std::string warrior_t::default_potion() const
{
  std::string fury_pot =
      ( true_level > 80 )
          ? "lights_potential_2"
          : ( true_level > 70 )
                ? "tempered_potion_3"
                : "disabled";

  std::string arms_pot =
      ( true_level > 80 )
          ? "lights_potential_2"
          : ( true_level > 70 )
                ? "tempered_potion_3"
                : "disabled";

  std::string protection_pot =
      ( true_level > 80 )
          ? "liquid_luster_2"
          : ( true_level > 70 )
                ? "tempered_potion_3"
                : "disabled";

  switch ( specialization() )
  {
    case WARRIOR_FURY:
      return fury_pot;
    case WARRIOR_ARMS:
      return arms_pot;
    case WARRIOR_PROTECTION:
      return protection_pot;
    default:
      return "disabled";
  }
}

// warrior_t::default_flask =================================================

std::string warrior_t::default_flask() const
{
  if ( specialization() == WARRIOR_PROTECTION && true_level > 80 )
    return "flask_of_the_shattered_sun_2";

  if ( specialization() == WARRIOR_FURY && true_level > 80 )
    return "flask_of_the_magisters_2";

  return ( true_level > 80 )
             ? "flask_of_the_blood_knights_2"
             : ( true_level > 70 )
                   ? "flask_of_alchemical_chaos_3"
                   : "disabled";
}

// warrior_t::default_food ==================================================

std::string warrior_t::default_food() const
{
  std::string fury_food = ( true_level > 80 )
                              ? "harandar_celebration"
                              : ( true_level > 70 )
                                    ? "the_sushi_specia"
                                    : "disabled";

  std::string arms_food = ( true_level > 80 )
                              ? "harandar_celebration"
                              : ( true_level > 70 )
                                    ? "the_sushi_specia"
                                    : "disabled";

  std::string protection_food = ( true_level > 80 )
                              ? "harandar_celebration"
                              : ( true_level > 70 )
                                    ? "the_sushi_specia"
                                    : "disabled";

  switch ( specialization() )
  {
    case WARRIOR_FURY:
      return fury_food;
    case WARRIOR_ARMS:
      return arms_food;
    case WARRIOR_PROTECTION:
      return protection_food;
    default:
      return "disabled";
  }
}

// warrior_t::default_rune ==================================================

std::string warrior_t::default_rune() const
{
  return ( true_level >= 80 ) ? "void_touched"
                               : ( true_level >= 70 ) ? "crystallized" : "disabled";
}

// warrior_t::default_temporary_enchant =====================================

std::string warrior_t::default_temporary_enchant() const
{
  std::string fury_temporary_enchant = ( true_level > 80 )
                              ? "main_hand:thalassian_phoenix_oil_2/off_hand:thalassian_phoenix_oil_2"
                              : "disabled";

  std::string arms_temporary_enchant = ( true_level > 80 )
                              ? "main_hand:thalassian_phoenix_oil_2"
                              : "disabled";

  std::string protection_temporary_enchant = ( true_level > 80 )
                              ? "main_hand:thalassian_phoenix_oil_2"
                              : "disabled";
  switch ( specialization() )
  {
    case WARRIOR_FURY:
      return fury_temporary_enchant;
    case WARRIOR_ARMS:
      return arms_temporary_enchant;
    case WARRIOR_PROTECTION:
      return protection_temporary_enchant;
    default:
      return "disabled";
  }
}

// warrior_t::init_actions ==================================================

void warrior_t::init_action_list()
{
  if ( !action_list_str.empty() )
  {
    parse_player_effects_t::init_action_list();
    return;
  }

  if ( main_hand_weapon.type == WEAPON_NONE )
  {
    if ( !quiet )
    {
      sim->errorf( "Player %s has no weapon equipped at the Main-Hand slot.", name() );
    }

    quiet = true;
    return;
  }

  clear_action_priority_lists();

  switch ( specialization() )
  {
    case WARRIOR_FURY:
        warrior_apl::fury( this );
      break;
    case WARRIOR_ARMS:
        warrior_apl::arms( this );
      break;
    case WARRIOR_PROTECTION:
      warrior_apl::protection( this );
      break;
    default:
      apl_default();  // DEFAULT
      break;
  }

  // Default
  use_default_action_list = true;
  parse_player_effects_t::init_action_list();
}

// warrior_t::init_blizzard_action_list ====================================

void warrior_t::init_blizzard_action_list()
{
  player_t::init_blizzard_action_list();

  if ( main_hand_weapon.type == WEAPON_NONE )
  {
    if ( !quiet )
      sim->errorf( "Player %s has no weapon equipped at the Main-Hand slot.", name() );
    quiet = true;
    return;
  }

  action_priority_list_t* pre_c = get_action_priority_list( "precombat" );
  switch ( specialization() )
  {
    case WARRIOR_ARMS:
      pre_c->add_action( "battle_stance,toggle=on" );
      break;
    case WARRIOR_FURY:
      pre_c->add_action( "berserker_stance,toggle=on" );
      break;
    case WARRIOR_PROTECTION:
      pre_c->add_action( "battle_stance,toggle=on" );
      break;
    default:
      break;
  }

  action_priority_list_t* default_ = get_action_priority_list( "default" );
  default_->add_action( "auto_attack" );  // Add before generating the other actions so its always the highest priority
  default_->add_action( "charge,if=time<=0.5|movement.distance>5" );

  action_priority_list_t* cooldowns = get_action_priority_list( "cooldowns" );

  switch ( specialization() )
  {
    case WARRIOR_ARMS:
      cooldowns->add_action( "avatar" );
      break;
    case WARRIOR_FURY:
      cooldowns->add_action( "recklessness" );
      cooldowns->add_action( "avatar" );
      break;
    case WARRIOR_PROTECTION:
      cooldowns->add_action( "demoralizing_shout,if=talent.booming_voice.enabled" );
      cooldowns->add_action( "shield_charge" );
      cooldowns->add_action( "avatar" );
      cooldowns->add_action( "shield_block,if=buff.shield_block.remains<=10" );
      cooldowns->add_action( "shield_wall" );
      cooldowns->add_action( "ignore_pain,if=rage>=65" );
      break;
    default:
      break;
  }
}

// warrior_t::parse_assisted_combat_rule ===============================
parsed_assisted_combat_rule_t warrior_t::parse_assisted_combat_rule( const assisted_combat_rule_data_t& rule,
                                                        const assisted_combat_step_data_t& step ) const
{
  // Blizz uses 5 in their apl, making the condition <5, however, this should be <6 to align with
  // distance targeting, as well, this makes it work correctly in simc
  if ( rule.condition_type == AC_TARGET_DISTANCE_LESS && rule.condition_value_1 == 5 )
  {
    assisted_combat_rule_data_t rule_copy = rule;
    rule_copy.condition_value_1 = 6;
    return { player_t::parse_assisted_combat_rule( rule_copy, step ), true };
  }

  // New rule added to slam in midnight, refers to old legion-era Rampage! (209694), so ignoring for now
  if ( rule.condition_type == AC_AURA_MISSING_PLAYER && rule.condition_value_1 == 209694 )
  {
    return { "", true };
  }

  return player_t::parse_assisted_combat_rule( rule, step );
}

// warrior_t::parse_assisted_combat_step ===============================Add commentMore actions
void warrior_t::parse_assisted_combat_step( const assisted_combat_step_data_t& step,
                                                 action_priority_list_t* assisted_combat )
{
  return player_t::parse_assisted_combat_step( step, assisted_combat );
}

// warrior_t::action_names_from_spell_id ===============================
std::vector<std::string> warrior_t::action_names_from_spell_id( unsigned int spell_id ) const
{
  // If we need to do spell id replacements for blizz apl, see DK module for an example
  return player_t::action_names_from_spell_id( spell_id );
}

// warrior_t::arise() ======================================================

void warrior_t::arise()
{
  parse_player_effects_t::arise();
}

// warrior_t::combat_begin ==================================================

  // Bloodsurge Event ========================================================

  struct bloodsurge_event_t : public event_t
  {
    warrior_t* player;
    bloodsurge_event_t( warrior_t* p, timespan_t delay )
    : event_t ( *p, delay ),
    player( p )
    {
    }

    const char* name() const override
    {
      return "bloodsurge execute event";
    }

    void execute() override
    {
      double rend_targets = 0;
      for ( auto t : player->sim->target_non_sleeping_list )
      {
        warrior_td_t* td = player->get_target_data( t );
        if ( t->is_enemy() && td->dots_rend->is_ticking() )
          rend_targets++;
      }
      if ( rend_targets > 0 )
      {
        double proc_chance = player->talents.shared.bloodsurge->effectN( 1 ).percent();
        proc_chance *= std::sqrt( 1 / rend_targets ) * rend_targets;
        if ( rng().roll( proc_chance ) )
        {
          player->resource_gain( RESOURCE_RAGE, player->spell.bloodsurge_energize->effectN( 1 ).resource( RESOURCE_RAGE ), player->gain.bloodsurge );
        }
      }

      make_event<bloodsurge_event_t>( sim(), player, player->talents.shared.bloodsurge->effectN( 1 ).period() * player->cache.spell_haste() );
    }
  };

void warrior_t::combat_begin()
{
  if ( !sim->fixed_time )
  {
    if ( warrior_fixed_time )
    {
      for ( auto* p : sim->player_list )
      {
         if ( p->specialization() != WARRIOR_FURY && p->specialization() != WARRIOR_ARMS )
        {
          warrior_fixed_time = false;
          break;
        }
      }
      if ( warrior_fixed_time )
      {
        sim->fixed_time = true;
        sim->error(
            "To fix issues with the target exploding <20% range due to execute, fixed_time=1 has been enabled. This "
            "gives similar results" );
        sim->error(
            "to execute's usage in a raid sim, without taking an eternity to simulate. To disable this option, add "
            "warrior_fixed_time=0 to your sim." );
      }
    }
  }
  parse_player_effects_t::combat_begin();
  buff.into_the_fray -> trigger( into_the_fray_friends < 0 ? buff.into_the_fray -> max_stack() : into_the_fray_friends + 1 );

  if ( talents.shared.bloodsurge->ok() )
  {
    make_event<bloodsurge_event_t>( *sim, this, talents.shared.bloodsurge->effectN( 1 ).period() * cache.spell_haste());
  }
}

// Into the fray

struct into_the_fray_callback_t
{
  warrior_t* w;
  double fray_distance;
  into_the_fray_callback_t( warrior_t* p ) : w( p ), fray_distance( 0 )
  {
    fray_distance = p->talents.protection.into_the_fray->effectN( 1 ).base_value();
  }

  void operator()( player_t* )
  {
    size_t i            = w->sim->target_non_sleeping_list.size();
    size_t buff_stacks_ = w->into_the_fray_friends;
    while ( i > 0 && buff_stacks_ < w->buff.into_the_fray->data().max_stacks() )
    {
      i--;
      player_t* target_ = w->sim->target_non_sleeping_list[ i ];
      if ( w->get_player_distance( *target_ ) <= fray_distance )
      {
        buff_stacks_++;
      }
    }
    if ( w->buff.into_the_fray->current_stack != as<int>( buff_stacks_ ) )
    {
      w->buff.into_the_fray->expire();
      w->buff.into_the_fray->trigger( static_cast<int>( buff_stacks_ ) );
    }
  }
};

// warrior_t::create_actions ================================================

void warrior_t::create_actions()
{
  if ( talents.shared.deep_wounds->ok() || talents.arms.mortal_wounds->ok() || talents.colossus.decimator->ok() )
    active.deep_wounds = new deep_wounds_t( this );
  if ( talents.arms.fatality->ok() )
    active.fatality = new fatality_t( this );

  if ( talents.protection.tough_as_nails->ok() )
  {
    active.tough_as_nails = new tough_as_nails_t( this );
  }

  if( talents.slayer.slayers_dominance->ok() )
  {
    active.slayers_strike = new slayers_strike_t( this );
  }

  if ( talents.protection.whirling_blade->ok() )
  {
    active.ravager_whirling_blade = new ravager_t( "ravager_whirling_blade", this );
  }

  if ( sets->has_set_bonus( WARRIOR_PROTECTION, MID2, B4 ) )
    active.bloody_rebuke = new bloody_rebuke_dot_t( this );

  parse_player_effects_t::create_actions();
}

void warrior_t::activate()
{
  parse_player_effects_t::activate();

  // If the value is equal to -1, don't use the callback and just assume max stacks all the time
  if ( talents.protection.into_the_fray->ok() && into_the_fray_friends >= 0 )
  {
    sim->target_non_sleeping_list.register_callback( into_the_fray_callback_t( this ) );
  }
}

// warrior_t::reset =========================================================

void warrior_t::reset()
{
  parse_player_effects_t::reset();
  first_rampage_attack_missed = false;
  slayers_strike_attempts_since_last_proc = 0;
  master_of_warfare_attempts_since_last_proc = 0;
  fury_mid2_2pc_extensions = 0;

  for ( auto* td : target_data.get_entries() )
  {
    if( td )
      td->hit_by_fresh_meat = false;
  }
}

// Movement related overrides. =============================================

void warrior_t::moving()
{
}

void warrior_t::interrupt()
{
  buff.charge_movement->expire();
  buff.heroic_leap_movement->expire();
  buff.intervene_movement->expire();
  buff.shield_charge_movement->expire();

  parse_player_effects_t::interrupt();
}

void warrior_t::teleport( double, timespan_t )
{
  // All movement "teleports" are modeled.
}

void warrior_t::trigger_movement( double distance, movement_direction_type direction )
{
  if ( talents.protection.into_the_fray->ok() && into_the_fray_friends >= 0 )
  {
    into_the_fray_callback_t( this );
  }

  else
  {
    parse_player_effects_t::trigger_movement( distance, direction );
  }
}

// warrior_t::composite_attribute ================================

double warrior_t::composite_attribute( attribute_e attr ) const
{
  double p = parse_player_effects_t::composite_attribute( attr );

  if ( attr == ATTR_STRENGTH )
  {
    // Arma 2022 Nov 13 Note that unless we handle str manually in the armor calcs Attt for prot ends up looping here.
    // As Str and armor are both looping in the stat cache
    // As we have it implemented properly in the armor calcs, this can be globally enabled.
    // get_attribute -> composite_attribute -> bonus_armor -> composite_bonus_armor -> strength -> get_attribute
    //if ( specialization() != WARRIOR_PROTECTION )
    if ( specialization() == WARRIOR_PROTECTION )
      p += ( talents.warrior.armored_to_the_teeth->effectN( 3 ).percent() * cache.armor() );
    else
      p += ( talents.warrior.armored_to_the_teeth->effectN( 2 ).percent() * cache.armor() );
  }

  return p;
}

// warrior_t::composite_attribute_multiplier ================================

double warrior_t::composite_attribute_multiplier( attribute_e attr ) const
{
  double m = parse_player_effects_t::composite_attribute_multiplier( attr );

  return m;
}

// warrior_t::matching_gear_multiplier ======================================

double warrior_t::matching_gear_multiplier( attribute_e attr ) const
{
  return parse_player_effects_t::matching_gear_multiplier( attr );
}

// warrior_t::composite_armor_multiplier ==========================================

double warrior_t::composite_armor_multiplier() const
{
  double ar = parse_player_effects_t::composite_armor_multiplier();

  // Handle this manually, as we can't auto apply armor for prot due to attt
  auto reinforced_plates_armor_mult = talents.warrior.reinforced_plates->effectN( 2 ).percent();

  // Arma 2022 Nov 10.  To avoid an infinite loop, we manually calculate the str benefit of armored to the teeth here, and apply the armor we would gain from it
  if ( talents.warrior.armored_to_the_teeth->ok() && specialization() == WARRIOR_PROTECTION )
  {
    auto q = spec.vanguard -> effectN( 1 ).percent() *
              talents.warrior.armored_to_the_teeth -> effectN( 3 ).percent() *
              ( 1+reinforced_plates_armor_mult) *
              ( 1+talents.protection.armor_specialization->effectN( 1 ).percent());
    ar *= 1 + ( q/(1 - q) );
  }

 // Generally Modify Armor% (101)

  ar *= 1.0 + reinforced_plates_armor_mult;

  ar *= 1.0 + talents.protection.armor_specialization -> effectN( 1 ).percent();

  return ar;
}

// warrior_t::composite_bonus_armor ==========================================

double warrior_t::composite_bonus_armor() const
{
  double ba = parse_player_effects_t::composite_bonus_armor();

  // Arma 2022 Nov 10.
  // We have to use base strength here, and then multiply by all the various STR buffs, while avoiding multiplying by Armored to the teeth.
  // This is to prevent an infinite loop between Attt using the cache.armor() and composite_bonus_armor using cache.strength()
  // We have to add all str buffs to this, if we want to avoid vanguard missing anything.  Not ideal.

  if ( specialization() == WARRIOR_PROTECTION )
  {
    // Pulls strength using the base player_t functions.  We call these directly to avoid using the warrior_t versions, as armor contribution from
    // attt is calculated during composite_armor_multiplier
    auto current_str = util::floor( parse_player_effects_t::composite_attribute( ATTR_STRENGTH ) * parse_player_effects_t::composite_attribute_multiplier( ATTR_STRENGTH ) );
    // if there is anything else in warrior_t::composite_attribute_multiplier that applies to str, like focused_vigor for instance
    // it needs to be added here as well
    ba += spec.vanguard -> effectN( 1 ).percent() * current_str;
  }

  // If in the future if blizz changes behavior, and we want to go back to using the two caches, we can use the below code
  //if( specialization() == WARRIOR_PROTECTION )
  //  ba += spec.vanguard -> effectN( 1 ).percent() * cache.strength();

  return ba;
}

// warrior_t::composite_block ================================================

double warrior_t::composite_block() const
{
  // this handles base block and and all block subject to diminishing returns
  double block_subject_to_dr = cache.mastery() * mastery.critical_block->effectN( 2 ).mastery_value();
  double b                   = parse_player_effects_t::composite_block_dr( block_subject_to_dr );

  // shield block adds 100% block chance
  if ( buff.shield_block -> up() )
  {
    b += spell.shield_block_buff -> effectN( 1 ).percent();
  }

  return b;
}

// warrior_t::composite_block_value ===========================================

double warrior_t::composite_block_value( const action_state_t* s ) const
{
  double bv = parse_player_effects_t::composite_block_value( s );

  if ( buff.brace_for_impact->check() )
  {
    bv *= 1.0 + buff.brace_for_impact->check() *
                  talents.protection.brace_for_impact->effectN( 1 ).trigger()->effectN( 2 ).percent();
  }

  return bv;
}

// warrior_t::composite_parry_rating() ========================================

double warrior_t::composite_parry_rating() const
{
  double p = parse_player_effects_t::composite_parry_rating();

  return p;
}

// warrior_t::composite_parry =================================================

double warrior_t::composite_parry() const
{
  double parry = parse_player_effects_t::composite_parry();

  if ( buff.die_by_the_sword->check() )
  {
    parry += talents.arms.die_by_the_sword->effectN( 1 ).percent();
  }
  return parry;
}

// warrior_t::composite_attack_power_multiplier ==============================

double warrior_t::composite_attack_power_multiplier() const
{
  double ap = parse_player_effects_t::composite_attack_power_multiplier();

  if ( mastery.critical_block -> ok() )
  {
    ap *= 1.0 + mastery.critical_block -> effectN( 5 ).mastery_value() * cache.mastery();
  }

  if ( talents.warrior.battlefield_commander.ok() )
    ap *= 1.0 + talents.warrior.battlefield_commander->effectN( 6 ).percent();
  return ap;
}

// warrior_t::composite_melee_crit_chance =========================================

double warrior_t::composite_melee_crit_chance() const
{
  double c = parse_player_effects_t::composite_melee_crit_chance();
  return c;
}

// warrior_t::composite_leech ==============================================

double warrior_t::composite_leech() const
{
  double m = parse_player_effects_t::composite_leech();

  return m;
}

// warrior_t::target_block_resolution =======================================

block_result_e warrior_t::target_block_resolution( const action_state_t* s ) const
{
  // Only direct physical attacks may be blocked
  if ( s->result_type == result_amount_type::DMG_DIRECT && s->action->get_school() == SCHOOL_PHYSICAL &&
       s->action->type == ACTION_ATTACK )
  {
    auto block_chance = cache.block();
    auto crit_block_chance = cache.mastery() * mastery.critical_block->effectN( 1 ).mastery_value();

    if ( rng().roll( block_chance ) )
    {
      if ( rng().roll( crit_block_chance ) )
        return BLOCK_RESULT_CRIT_BLOCKED;
      else
        return BLOCK_RESULT_BLOCKED;
    }
  }

  return BLOCK_RESULT_UNBLOCKED;
}

// warrior_t::resource_gain =================================================

double warrior_t::resource_gain( resource_e r, double a, gain_t* g, action_t* action )
{
  if ( buff.recklessness->check() && r == RESOURCE_RAGE )
  {
    bool do_not_double_rage = false;

    do_not_double_rage      = ( g == gain.ceannar_rage || g == gain.simmering_rage ||
                                  g == gain.frothing_berserker || g == gain.thorims_might );

    if ( !do_not_double_rage )  // FIXME: remove this horror after BFA launches, keep Simmering Rage
    {
      if ( buff.recklessness->check() )
        a *= 1.0 + spell.recklessness_buff->effectN( 1 ).percent();
    }
  }
  return parse_player_effects_t::resource_gain( r, a, g, action );
}

// warrior_t::invalidate_cache ==============================================

void warrior_t::invalidate_cache( cache_e c )
{
  parse_player_effects_t::invalidate_cache( c );

  if ( mastery.critical_block->ok() )
  {
    if ( c == CACHE_MASTERY )
    {
      parse_player_effects_t::invalidate_cache( CACHE_BLOCK );
      parse_player_effects_t::invalidate_cache( CACHE_ATTACK_POWER );
    }
    if ( c == CACHE_CRIT_CHANCE )
    {
      parse_player_effects_t::invalidate_cache( CACHE_PARRY );
    }
  }
  if ( c == CACHE_MASTERY && mastery.master_of_arms->ok() )
    parse_player_effects_t::invalidate_cache( CACHE_PLAYER_DAMAGE_MULTIPLIER );

  if ( c == CACHE_MASTERY && mastery.unshackled_fury->ok() )
  {
    parse_player_effects_t::invalidate_cache( CACHE_PLAYER_DAMAGE_MULTIPLIER );
  }
  if ( c == CACHE_STRENGTH && spec.vanguard -> ok() )
  {
    parse_player_effects_t::invalidate_cache( CACHE_BONUS_ARMOR );
  }
  if ( c == CACHE_ARMOR && talents.warrior.armored_to_the_teeth->ok() )
  {
    parse_player_effects_t::invalidate_cache( CACHE_STRENGTH );
  }
  if ( c == CACHE_BONUS_ARMOR && talents.warrior.armored_to_the_teeth->ok() )
  {
    parse_player_effects_t::invalidate_cache( CACHE_STRENGTH );
  }
}

// warrior_t::primary_role() ================================================

role_e warrior_t::primary_role() const
{
  if ( parse_player_effects_t::primary_role() == ROLE_TANK )
    return ROLE_TANK;

  if ( parse_player_effects_t::primary_role() == ROLE_DPS || parse_player_effects_t::primary_role() == ROLE_ATTACK )
    return ROLE_ATTACK;

  if ( specialization() == WARRIOR_PROTECTION )
  {
    return ROLE_TANK;
  }
  return ROLE_ATTACK;
}

// warrior_t::convert_hybrid_stat ==============================================

stat_e warrior_t::convert_hybrid_stat( stat_e s ) const
{
  // this converts hybrid stats that either morph based on spec or only work
  // for certain specs into the appropriate "basic" stats
  switch ( s )
  {
    case STAT_AGI_INT:
      return STAT_NONE;
    case STAT_STR_AGI_INT:
    case STAT_STR_AGI:
    case STAT_STR_INT:
      return STAT_STRENGTH;
    case STAT_SPIRIT:
      return STAT_NONE;
    case STAT_BONUS_ARMOR:
        return s;
    default:
      return s;
  }
}

void warrior_t::assess_damage( school_e school, result_amount_type type, action_state_t* s )
{
  parse_player_effects_t::assess_damage( school, type, s );

  if ( s->result == RESULT_DODGE || s->result == RESULT_PARRY )
  {
   if ( rppm.revenge->trigger() )
    {
      buff.revenge->trigger();
    }
  }

  // Generate 3 Rage on auto-attack taken.
  // TODO: Update with spelldata once it actually exists
  // Arma Feb 1 2023 - We check that damage was actually done, as otherwise, flasks that did not do damage were
  // giving us rage
  else if ( ! s -> action -> special && cooldown.rage_from_auto_attack->up() && s->result_raw > 0.0 )
  {
    resource_gain( RESOURCE_RAGE, 3.0, gain.rage_from_damage_taken, s -> action );
    cooldown.rage_from_auto_attack->start( cooldown.rage_from_auto_attack->duration );
  }

  if ( talents.protection.tough_as_nails->ok() && cooldown.tough_as_nails_icd -> up() &&
    ( s -> block_result == BLOCK_RESULT_BLOCKED || s -> block_result == BLOCK_RESULT_CRIT_BLOCKED ) &&
    s -> action -> player -> is_enemy() )
  {
    if ( s -> block_result == BLOCK_RESULT_CRIT_BLOCKED )
      debug_cast<tough_as_nails_t*>(active.tough_as_nails)->critical_block = true;
    else
      debug_cast<tough_as_nails_t*>(active.tough_as_nails)->critical_block = false;
    active.tough_as_nails -> execute_on_target( s -> action -> player );
  }
}

// warrior_t::target_mitigation ============================================

void warrior_t::target_mitigation( school_e school, result_amount_type dtype, action_state_t* s )
{
  parse_player_effects_t::target_mitigation( school, dtype, s );

  if ( s->block_result == BLOCK_RESULT_CRIT_BLOCKED )
  {
    double block_value = s->target_block_value;
    double block_resist = util::calculate_armor_resist( block_value, s->action->player->current.armor_coeff, 2.0 );

    s->result_amount *= 1.0 - block_resist;

    if ( sim->debug )
    {
      sim->print_debug(
        "{} {} damage to {} reduced by {:.7g}% from crit block (block value={:.7g}, armor coeff={:.7g}).",
        *s->action->player, *s->action, *s->target, block_resist * 100, block_value,
        s->action->player->current.armor_coeff );
    }
  }
}

// warrior_t::create_options ================================================

void warrior_t::create_options()
{
  parse_player_effects_t::create_options();

  add_option( opt_bool( "non_dps_mechanics", non_dps_mechanics ) );
  add_option( opt_bool( "warrior_fixed_time", warrior_fixed_time ) );
  add_option( opt_int( "into_the_fray_friends", into_the_fray_friends ) );
  add_option( opt_int( "never_surrender_percentage", never_surrender_percentage ) );
}

// warrior_t::create_profile ================================================

std::string warrior_t::create_profile( save_e type )
{
  if ( specialization() == WARRIOR_PROTECTION && primary_role() == ROLE_TANK )
  {
    position_str = "front";
  }

  return parse_player_effects_t::create_profile( type );
}

// warrior_t::copy_from =====================================================

void warrior_t::copy_from( player_t* source )
{
  parse_player_effects_t::copy_from( source );

  warrior_t* p = debug_cast<warrior_t*>( source );

  non_dps_mechanics     = p->non_dps_mechanics;
  warrior_fixed_time    = p->warrior_fixed_time;
  into_the_fray_friends = p->into_the_fray_friends;
  never_surrender_percentage = p -> never_surrender_percentage;
}

void warrior_t::parse_player_effects()
{
  parse_effects( buff.bounding_stride );

  auto parse_movement_proxy_effect = [ this ]( buff_t* b, const spelleffect_data_t& eff )
  {
    if ( eff.ok() )
    {
      add_parse_entry( non_stacking_movement_effects )
        .set_buff( b )
        .set_type( USE_CURRENT )
        .set_eff( &eff )
        .print_debug( this );
    }
  };

  parse_movement_proxy_effect( buff.heroic_leap_movement, talents.warrior.heroic_leap->effectN( 2 ) );
  parse_movement_proxy_effect( buff.charge_movement, spell.charge->effectN( 1 ) );
  parse_movement_proxy_effect( buff.intervene_movement, talents.warrior.intervene->effectN( 1 ) );
  parse_movement_proxy_effect( buff.shield_charge_movement, talents.protection.shield_charge->effectN( 1 ) );

  parse_effects( buff.wild_strikes, talents.warrior.wild_strikes );

  parse_effects( buff.battle_stance, effect_mask_t( true ).disable( 4 ) );

  // Stance Mastery for Defensive stance is not working in game as of Dec 04 2025
  parse_effects( buff.defensive_stance, effect_mask_t( true ).disable( 2, 5, 6 ) );

  if ( specialization() != WARRIOR_PROTECTION )
    parse_effects( buff.defensive_stance, effect_mask_t( false ).enable( 2 ) );

  parse_effects( buff.spell_reflection );

  parse_target_effects( d_fn( &warrior_td_t::debuffs_honed_reflexes ), talents.warrior.honed_reflexes->effectN( 5 ).trigger() );

  if ( specialization() == WARRIOR_ARMS )
  {
    parse_effects( buff.die_by_the_sword );

    if ( main_hand_weapon.group() == WEAPON_2H )
      parse_effects( mastery.master_of_arms );
  }
  else if ( specialization() == WARRIOR_FURY )
  {
    parse_effects( buff.frenzy, talents.fury.frenzy );
    parse_effects( buff.surge_of_adrenaline );

    if ( talents.warrior.stance_mastery->ok() )
      parse_effects( buff.berserker_stance, effect_mask_t( false ).enable( 6 ) );

    parse_effects( buff.enrage, effect_mask_t( false ).enable( 3 ) );
    if ( talents.fury.frenzied_enrage->ok() )
      parse_effects( buff.enrage, effect_mask_t( false ).enable( 1, 2 ) );
    if ( talents.fury.powerful_enrage->ok() )
      parse_effects( buff.enrage, effect_mask_t( false ).enable( 5, 6 ) );

    parse_effects( buff.berserk );
  }
  else if ( specialization() == WARRIOR_PROTECTION )
  {
    parse_effects( buff.into_the_fray );
    parse_effects( buff.avatar, effect_mask_t( false ).enable( 8 ) );
    parse_effects( buff.shield_wall );
    parse_effects( spec.vanguard, PARSE_PASSIVE );

    parse_target_effects( d_fn( &warrior_td_t::debuffs_demoralizing_shout ), talents.protection.demoralizing_shout );
    parse_target_effects( d_fn( &warrior_td_t::debuffs_punish ), talents.protection.punish->effectN( 2 ).trigger() );
  }

  // Colossus
  parse_effects( buff.celeritous_conclusion_haste );

  // Slayer
  parse_effects( buff.violent_euphoria );

  // Mountain Thane
}

/* Report Extension Class
 * Here you can define class specific report extensions/overrides
 */
class warrior_report_t : public player_report_extension_t
{
public:
  warrior_report_t( warrior_t& player ) : p( player )
  {
  }

  void cdwaste_table_header( report::sc_html_stream& os )
  {
    os << "<table class=\"sc\" style=\"float: left;margin-right: 10px;\">\n"
       << "<tr>\n"
       << "<th></th>\n"
       << "<th colspan=\"3\">Seconds per Execute</th>\n"
       << "<th colspan=\"3\">Seconds per Iteration</th>\n"
       << "</tr>\n"
       << "<tr>\n"
       << "<th>Ability</th>\n"
       << "<th>Average</th>\n"
       << "<th>Minimum</th>\n"
       << "<th>Maximum</th>\n"
       << "<th>Average</th>\n"
       << "<th>Minimum</th>\n"
       << "<th>Maximum</th>\n"
       << "</tr>\n";
  }

  void cdwaste_table_footer( report::sc_html_stream& os )
  {
    os << "</table>\n";
  }

  void cdwaste_table_contents( report::sc_html_stream& os )
  {
    size_t n = 0;
    for ( size_t i = 0; i < p.cd_waste_exec.size(); i++ )
    {
      const data_t* entry = p.cd_waste_exec[ i ];
      if ( entry->second.count() == 0 )
      {
        continue;
      }

      const data_t* iter_entry = p.cd_waste_cumulative[ i ];

      action_t* a          = p.find_action( entry->first );
      std::string name_str = entry->first;
      if ( a )
      {
        name_str = report_decorators::decorated_action(*a);
      }
      else
      {
        name_str = util::encode_html( name_str );
      }

      std::string row_class_str;
      if ( ++n & 1 )
        row_class_str = " class=\"odd\"";

      os.printf( "<tr%s>", row_class_str.c_str() );
      os << "<td class=\"left\">" << name_str << "</td>";
      os.printf( "<td class=\"right\">%.3f</td>", entry->second.mean() );
      os.printf( "<td class=\"right\">%.3f</td>", entry->second.min() );
      os.printf( "<td class=\"right\">%.3f</td>", entry->second.max() );
      os.printf( "<td class=\"right\">%.3f</td>", iter_entry->second.mean() );
      os.printf( "<td class=\"right\">%.3f</td>", iter_entry->second.min() );
      os.printf( "<td class=\"right\">%.3f</td>", iter_entry->second.max() );
      os << "</tr>\n";
    }
  }

  void html_customsection( report::sc_html_stream& os ) override
  {
    // Custom Class Section
    os << "\t\t\t\t<div class=\"player-section custom_section\">\n";
    /*// Custom Class Section
    os << "\t\t\t\t<div class=\"player-section custom_section\">\n"
    << "\t\t\t\t\t<h3 class=\"toggle open\">Custom Section</h3>\n"
    << "\t\t\t\t\t<div class=\"toggle-content\">\n";

    os << p.name();

    os << "\t\t\t\t\t\t</div>\n" << "\t\t\t\t\t</div>\n";*/
    if ( !p.cd_waste_exec.empty() )
    {
      os << "\t\t\t\t\t<h3 class=\"toggle open\">Cooldown waste details</h3>\n"
         << "\t\t\t\t\t<div class=\"toggle-content\">\n";

      cdwaste_table_header( os );
      cdwaste_table_contents( os );
      cdwaste_table_footer( os );

      os << "\t\t\t\t\t</div>\n";

      os << "<div class=\"clear\"></div>\n";
    }
    os << "\t\t\t\t\t</div>\n";
  }

private:
  warrior_t& p;
};

struct warrior_module_t : public module_t
{
  warrior_module_t() : module_t( WARRIOR )
  {
  }

  player_t* create_player( sim_t* sim, util::string_view name, race_e r = RACE_NONE ) const override
  {
    auto p              = new warrior_t( sim, name, r );
    p->report_extension = std::unique_ptr<player_report_extension_t>( new warrior_report_t( *p ) );
    return p;
  }

  bool valid() const override
  {
    return true;
  }

  void register_hotfixes() const override
  {
    // hotfix::register_effect( "Warrior", "2026-8-13", "Rampaging Ruin damage halved by offhand weapon penalty", 1324375,
    //                           hotfix::HOTFIX_FLAG_LIVE )
    //      .field( "ap_coefficient" )
    //      .operation( hotfix::HOTFIX_SET )
    //      .modifier( 1.861445 )
    //      .verification_value( 3.72289 );
  }

  void register_actor_initializers( sim_t* sim ) const override
  {
    sim->register_actor_initializer( INIT_ACTOR_CREATE_BUFFS + offset(), []( player_t* p ) {
      if ( !p->is_player() )
        return;

      bool has_external_rallying = !p->external_buffs.rallying_cry.empty();
      bool has_talent_rallying = p->type == WARRIOR && debug_cast<warrior_t*>( p )->talents.warrior.rallying_cry.ok();

      if ( has_external_rallying || has_talent_rallying )
      {
        auto buff = make_buff<buffs::rallying_cry_t>( p );

        if ( has_external_rallying )
        {
          p->register_timed_buff_triggers( buff, p->external_buffs.rallying_cry );
        }

        if ( has_talent_rallying )
        {
          debug_cast<warrior_t*>( p )->buff.rallying_cry = buff;
        }
      }
    }, "create_buffs_warrior" );
  }
};
}  // UNNAMED NAMESPACE

const module_t* module_t::warrior()
{
  static warrior_module_t m;
  return &m;
}
